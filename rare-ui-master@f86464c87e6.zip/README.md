rare-ui

UI Coding Style Guide
----------------------
Please follow the coding standards and practices from following style guide.

https://confluence.elevancehealth.com/x/kKQVQ
