const crypto = require('crypto');
const fs = require('fs');

const timestamp = new Date().toISOString();
const hash = crypto.createHash('sha256').update(timestamp).digest('hex');

fs.writeFileSync('src/environments/build-hash.ts', `export const BUILD_HASH = '${hash}';`);