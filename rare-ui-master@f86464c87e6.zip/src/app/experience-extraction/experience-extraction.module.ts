import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ExperienceExtractionComponent } from './experience-extraction.component';
import { ExperienceExtractionRoutes } from './experience-extraction.routes';
import { ExperienceExtractionProcessComponent } from '../shared/components/experience-extraction-process/experience-extraction-process.component';
import { ConfirmationService } from 'primeng/api';

@NgModule({
  declarations: [
    ExperienceExtractionComponent
  ],
  imports: [
    ExperienceExtractionProcessComponent,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(ExperienceExtractionRoutes)
  ],
  providers:[
    ConfirmationService
  ]
})
export class ExperienceExtractionModule { }
