
import { Component, inject } from '@angular/core';
import { AuthenticationService } from '../shared/services/authentication.service';

@Component({
  selector: 'app-experience-extraction',
  templateUrl: './experience-extraction.component.html',
  styleUrls: ['./experience-extraction.component.scss'],
  standalone: false
})
export class ExperienceExtractionComponent {
  
  private authService = inject(AuthenticationService);
  isAdminRole = this.authService.isUserRoleAdmin(this.authService.userRole.value);
}
