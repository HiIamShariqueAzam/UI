import { Routes } from '@angular/router';
import { ExperienceExtractionComponent } from './experience-extraction.component';

export const ExperienceExtractionRoutes: Routes = [
  {
    path: '',
    component: ExperienceExtractionComponent
  }
];
