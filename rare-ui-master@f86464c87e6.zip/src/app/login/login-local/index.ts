﻿export * from './login-local.component';
