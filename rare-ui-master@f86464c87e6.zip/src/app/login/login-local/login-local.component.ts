﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService, CacheService, CommonService } from 'src/app/shared/services';
import { HttpClient } from '@angular/common/http';
import { LoginGroup } from 'src/app/shared/models/loginGroup';
import { UserService } from 'src/app/shared/services/user.service';
import { ResourceConfigService } from 'src/app/shared/services/resource-config.service';

@Component({ templateUrl: 'login-local.component.html', standalone: false })
export class LoginLocalComponent implements OnInit {
  loginForm: FormGroup<LoginGroup>;
  availableUserGroupsList: Array<any> = [];
  userGroupsList: Array<any> = [];
  selectedUsergroup: any;
  isDissble: boolean;
  overrideConfigServerValues = false;
  constructor(
    private httpClient: HttpClient,
    private formBuilder: FormBuilder,
    private cacheService: CacheService,
    private commonService: CommonService,
    private resourceConfigService: ResourceConfigService,
    private authenticationService: AuthenticationService,
    private userService: UserService
  ) {
    this.authenticationService.changeShowMenu(false);
  }

  isDropdownDisabled(rolegroup) {
    if (
      rolegroup === 'RARE_APP_READ_ONLY' &&
      this.commonService.getUserRoles() &&
      this.commonService.getUserRoles().includes('READONLY') &&
      this.commonService.getUserRoles().includes('ADMIN')
    ) {
      this.isDissble = true;
      return true;
    } else {
      return false;
    }
  }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      usergroup: ['', Validators.required]
    });
    this.authenticationService.getUserRoleGroups().then((data) => {
      for (let rolegroups of data) {
        let usergroup = {
          label: rolegroups['usergroup'],
          value: rolegroups['usergroup'],
          disabled: this.isDropdownDisabled(rolegroups['usergroup'])
        };
        this.userGroupsList.push(usergroup);
      }
      this.availableUserGroupsList = this.userGroupsList;
    });
    if (this.commonService.getUserRoles() && this.commonService.getUserRoles().find((role) => role === 'READONLY')) {
      this.selectedUsergroup = ['RARE_APP_READ_ONLY'];
    }

    if (!this.authenticationService.getUserLoggedInUsingSiteminder()) {
      // Update the URL to point to non-local ex: 'https://rare-ui.uw.dev.elevancehealth.com/api/rare/v1/appresource';
      this.setConfigurationsURL('http://localhost:9080/api/rare/v1/appresource');
    }
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  onSubmit() {
    if (!this.authenticationService.getUserLoggedInUsingSiteminder()) {
      // If NOT User LoggedIn
      // In the Login Componennt this will be retrieved from Siteminder SSO
      this.authenticationService.changeAppEnvironment('DEV');
      this.authenticationService.changeUserID('');
      this.authenticationService.changeUserName('');
      this.authenticationService.changeUserEmail('');
      this.authenticationService.changeUserRole('');
      if (this.overrideConfigServerValues) {
        // Factor Data Manager URL (This setting only for testing in local)
        // http://localhost:9010/api/rare/v1
        this.cacheService.setFactorManagerMainUrl('https://rare-factor-data-manager.2dev.apps.ent-ocp4-np1-har.antmdc.internal.das/api/rare/v1');
        // https://rare-factor-data-manager.dev.apps.ent-ocp4-np1-har.antmdc.internal.das/api/rare/v1
        this.commonService.setFactorManagerMainUrl('https://rare-factor-data-manager.2dev.apps.ent-ocp4-np1-har.antmdc.internal.das/api/rare/v1');
        this.commonService.setTablesUrl('/manager/tables');
        // Calculator Premium Medical URL (This setting only for testing in local)
        this.commonService.setCalculatorPremiumMedicalUrl('http://localhost:6070/api/rare/v1');
        this.commonService.setReQuoteUrl('http://localhost:8000/');
        // Calculator Sold Rates URL (This setting only for testing in local)
        this.commonService.setCalculatorSoldRatesUrl('http://localhost:8021/api/rare/v1');
        // Print Engine URL (This setting only for testing in local)
        this.commonService.setPrintEngineUrl('http://localhost:8050/api/rare/v1');
        // http://localhost:9080/api/rare/v1
        // https://rare-ui.2dev.elevancehealth.com/api/rare/v1
        this.commonService.setRareUIUrl('http://localhost:9080/api/rare/v1');
        this.cacheService.setRareUIUrl('http://localhost:9080/api/rare/v1');
        //https://rare-dev.nginx.ent-ocp4-np1-har.antmdc.internal.das/api/rare/v1
        this.commonService.setRareUINginxUrl('http://localhost:9080/api/rare/v1');
        this.commonService.setAnalyticsBaseUrl('http://localhost:9099/');
        this.commonService.setVisionBaseUrl('http://localhost:7000/api/rare/v1');
        this.commonService.setProductLevelAdjustments('true');
        this.commonService.setProgressBarTimeOut(5000);
        this.commonService.setToggleSmallGroupIntake('true');
        this.commonService.setMedicalCacheRefreshUrl('http://localhost:6005/api/rare/v1/cache/refresh');
        this.commonService.setDentalCacheRefreshUrl('http://localhost:5005/api/rare/v1/cache/refresh');
        this.commonService.setVisionCacheRefreshUrl('http://localhost:4005/api/rare/v1/cache/refresh');
        this.commonService.setGatewayCacheRefreshUrl('http://localhost:8009/api/v1/refreshCache');
        this.commonService.setFactorManagerExternalUrl('http://localhost:9010/api/rare/v1');
        this.commonService.setFactorMigationEnabled('true');
      }
    }
    let usergroupObject = this.loginForm.get('usergroup').value;
    this.userService.setUserGlobalData(usergroupObject.join(), true);
    this.commonService.getQuotedLegalEntityList();
  }

  ngOnDestroy() {}

  setConfigurationsURL(configUrl) {
    this.httpClient.get<any>(configUrl).subscribe((resources) => {
      this.resourceConfigService.setConfigResourceData(resources);
      this.commonService.setRareUIUrl(resources['RARE_UI_URL']);
      this.cacheService.setRareUIUrl(resources['RARE_UI_URL']);
    });
  }
}
