import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { LoginLocalComponent } from './login-local.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MultiSelectModule,
    DialogModule,
    ReactiveFormsModule,
    SelectModule,
    RouterModule.forChild([{ path: '', component: LoginLocalComponent, pathMatch: 'full' }]),
    ButtonModule
  ],
  declarations: [LoginLocalComponent],
  exports: [LoginLocalComponent],
  providers: [],
  schemas: [NO_ERRORS_SCHEMA]
})
export class LoginLocalModule {}
