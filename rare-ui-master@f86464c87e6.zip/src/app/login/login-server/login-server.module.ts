import { NgModule } from '@angular/core';
import { LoginServerComponent } from './login-server.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthModule, OidcSecurityService } from 'angular-auth-oidc-client';
import { ButtonModule } from 'primeng/button'
import { ProgressSpinnerModule } from 'primeng/progressspinner';;
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AuthModule.forRoot({}),
    RouterModule.forChild([{ path: '', component: LoginServerComponent, pathMatch: 'full' }]),
    ButtonModule,
    ProgressSpinnerModule
  ],
  declarations: [LoginServerComponent],
  exports: [LoginServerComponent],
  providers: [
    //  OidcConfigService,
    OidcSecurityService
  ]
})
export class LoginServerModule {}
