﻿import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { CommonService, AuthenticationService } from 'src/app/shared/services';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginForm } from 'src/app/shared/models/loginForm';
import { UserService } from 'src/app/shared/services/user.service';
import { ActivatedRoute } from '@angular/router';

@Component({ templateUrl: 'login-server.component.html' , standalone: false })
export class LoginServerComponent implements OnInit, OnDestroy {
  loginForm: FormGroup<LoginForm>;
  showServiceIDLoginSection: boolean = false;
  isFromDefaultRoute: boolean = false;

  constructor(
    private httpClient: HttpClient,
    private commonService: CommonService,
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private oidcSecurityService: OidcSecurityService,
    private userService: UserService,
    private router: ActivatedRoute
  ) {
    this.showServiceIDLoginSection = commonService.getShowServiceIDLoginPage();
     this.router.queryParams.subscribe(params => {
        this.isFromDefaultRoute = params['fromDefault'] === 'true';
    });
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      serviceID: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login() {
    this.oidcSecurityService.authorize();
  }

  loginWithServiceID() {
    const headerOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: 'Basic ' + btoa(this.loginForm.get('serviceID').value + ':' + this.loginForm.get('password').value)
      })
    };
    this.httpClient.get('authenticateserviceid', headerOptions).subscribe((resources) => {
      if (resources['AUTHENTICATE_SERVICE_ID'] == 'true') {
        this.authenticationService.changeUserID(this.loginForm.get('serviceID').value);
        this.authenticationService.changeUserName(this.loginForm.get('serviceID').value);
        this.authenticationService.changeUserEmail('srcRAREsvcID@us.ad.wellpoint.com');
        let userRoles: any = [];
        if (Object.prototype.hasOwnProperty.call(resources, 'TEST_AUTOMATION_SERVICE_ID_ACCESS_ROLES')) {
         userRoles = resources['TEST_AUTOMATION_SERVICE_ID_ACCESS_ROLES'];
        }
        console.log('userRoles_check', userRoles);
        this.authenticationService.getEnvironmentGroups().then((data) => {
          for (let environmentgroups of data) {
            if (this.authenticationService.getAppEnvironment() == environmentgroups['environment']) {
              if (String(userRoles).indexOf(environmentgroups['usergroup']) !== -1) {
                this.authenticationService.changeSiteminderAuthenticated(true);
                this.authenticationService.setUserLoggedInUsingSiteminder(true);
                this.authenticationService.changeShowMenu(true);
                this.userService.setUserGlobalData(userRoles);
              } else {
                this.authenticationService.changeShowMenu(false);
                this.authenticationService.changeSiteminderAuthenticated(false);
                this.authenticationService.setUserLoggedInUsingSiteminder(false);
                alert(
                  "You don't have permisssion to access this application. Please contact RARE team <dl-RARE-IT@anthem.com> for access related questions...!"
                );
              }
            }
          }
        });
      } else {
        alert('Incorrect Service ID Credentials..!');
      }
    });
  }

  ngOnDestroy() {}
}
