import { Component, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { NavigationEnd } from '@angular/router';
import { CommonConstants } from '../shared/constants/common.constants';
import { AuthenticationService } from '../shared/services/authentication.service';
import { CommonService } from '../shared/services/common.service';
import { SafeResourceUrl } from '@angular/platform-browser';

@Component({ selector: 'app', templateUrl: './app.component.html' , standalone: false })
export class AppComponent {
  isSparkWidgetExpanded = false;
  showChatWidget = true;
  sanitizedIframeUrl: SafeResourceUrl | null = null;
  buttonPosition: { right: number; bottom: number } | null = null;
  windowPosition: { right: number; bottom: number } | null = null;
  private dragElement: 'button' | 'window' | null = null;
  private dragStart = { x: 0, y: 0 };
  private isDragging = false;
  private readonly BOUNDARY_PADDING = 5;

  constructor(private router: Router, private authService: AuthenticationService, private commonService: CommonService) {

    this.checkloginPathForWidget();
    
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe(() => {
      this.checkloginPathForWidget();
    });

    // Listen for user role changes
    this.authService.userRole.subscribe(() => {
      this.checkSparkWidgetVisibility();
    });
  }

  ngOnInit(): void {
    const iframeUrl = this.commonService.getCustomSparkWidgetUrl();
    if (iframeUrl) {
    this.sanitizedIframeUrl = this.commonService.sanitizeUrl(iframeUrl);
    }
  }

  
  private checkloginPathForWidget() {
    this.checkSparkWidgetVisibility();
  }
  

  private checkSparkWidgetVisibility() {
    const currentUrl = this.router.url;
    const onLoginRoute = CommonConstants.LOGIN_ROUTES.some(route => currentUrl.includes(route));
    const userRole = this.authService.getUserRole();
    
    // Show widget only for high precedence roles (Admin, Actuarial, Underwriter)
    // Hide for SG/LG only or any other roles
    const shouldShowBasedOnRoles = this.checkHighPrecedenceRoles(userRole);

    // Update widget visibility - hide on login routes or based on role logic
    this.showChatWidget = !onLoginRoute && shouldShowBasedOnRoles;
  }

  checkHighPrecedenceRoles(userRole) {
    if (userRole && (userRole.includes('ADMIN') || userRole.includes('ACTUARIAL') || userRole.includes('UNDERWRITER'))) {
      return true;
    } else {
      return false;
    }
  }
  
  toggleSparkWidget(event: MouseEvent) {
    if (this.isDragging) {
      this.isDragging = false;
      return;
    }
    this.isSparkWidgetExpanded = !this.isSparkWidgetExpanded;
    if (this.isSparkWidgetExpanded) {
      this.syncWindowToButton();
    }
  }

  startDrag(event: MouseEvent, element: 'button' | 'window') {
    if (event.button !== 0) return;
    event.stopPropagation(); // Prevent click from bubbling
    
    // Initialize position from current element position if not set
    const el = element === 'button' 
      ? document.getElementById('chat-toggle-btn')
      : document.getElementById('chat-window');
    
    if (el && !this.buttonPosition && element === 'button') {
      const rect = el.getBoundingClientRect();
      this.buttonPosition = {
        right: window.innerWidth - rect.right,
        bottom: window.innerHeight - rect.bottom
      };
    } else if (el && !this.windowPosition && element === 'window') {
      const rect = el.getBoundingClientRect();
      this.windowPosition = {
        right: window.innerWidth - rect.right,
        bottom: window.innerHeight - rect.bottom
      };
    }
    
    this.dragElement = element;
    this.dragStart = { x: event.clientX, y: event.clientY };
    this.isDragging = false;
  }

  @HostListener('document:mousemove', ['$event'])
  onDragMove(event: MouseEvent) {
    if (!this.dragElement) return;
    
    const deltaX = this.dragStart.x - event.clientX;
    const deltaY = event.clientY - this.dragStart.y;
    
    if (Math.abs(deltaX) > this.BOUNDARY_PADDING || Math.abs(deltaY) > this.BOUNDARY_PADDING) {
      this.isDragging = true;
    }
    
    if (this.isDragging) {
      const boundaries = this.getViewportBoundaries();
      
      if (this.dragElement === 'button' && this.buttonPosition) {
        this.buttonPosition = this.calculateConstrainedPosition(
          this.buttonPosition.right + deltaX,
          this.buttonPosition.bottom - deltaY,
          'chat-toggle-btn',
          boundaries
        );
      } else if (this.dragElement === 'window' && this.windowPosition) {
        this.windowPosition = this.calculateConstrainedPosition(
          this.windowPosition.right + deltaX,
          this.windowPosition.bottom - deltaY,
          'chat-window',
          boundaries
        );
      }
      
      this.dragStart = { x: event.clientX, y: event.clientY };
    }
  }

  @HostListener('document:mouseup')
  onDragEnd() {
    this.dragElement = null;
  }

  private getViewportBoundaries() {
    const header = document.querySelector('app-global-header');
    const footer = document.querySelector('app-global-footer');
    return {
      headerHeight: header?.clientHeight || 0,
      footerHeight: footer?.clientHeight || 0
    };
  }

  private calculateConstrainedPosition(
    newRight: number,
    newBottom: number,
    elementId: string,
    boundaries: { headerHeight: number; footerHeight: number }
  ): { right: number; bottom: number } {
    const element = document.getElementById(elementId);
    if (!element) {
      return { right: newRight, bottom: newBottom };
    }
    
    const width = element.offsetWidth;
    const height = element.offsetHeight;
    
    const minBottom = boundaries.footerHeight + this.BOUNDARY_PADDING;
    const maxBottom = window.innerHeight - boundaries.headerHeight - height - this.BOUNDARY_PADDING;
    const minRight = this.BOUNDARY_PADDING;
    const maxRight = window.innerWidth - width - this.BOUNDARY_PADDING;
    
    return {
      right: this.constrainValue(newRight, minRight, maxRight),
      bottom: this.constrainValue(newBottom, minBottom, maxBottom)
    };
  }

  private constrainValue(value: number, min: number, max: number): number {
    return Math.max(min, Math.min(value, max));
  }

  private syncWindowToButton() {
    if (this.buttonPosition) {
      this.windowPosition = {
        right: this.buttonPosition.right + 10,
        bottom: this.buttonPosition.bottom + 60
      };
    } else {
      // Use default CSS position offset
      this.windowPosition = { right: 12, bottom: 70 };
    }
  }
  
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event) {
    const target = event.target as Element;
    const clickedOutside = !target.closest('#chat-toggle-btn') && !target.closest('#chat-window');
    
    if (this.isSparkWidgetExpanded && clickedOutside) {
      this.isSparkWidgetExpanded = false;
    }
  }
}
