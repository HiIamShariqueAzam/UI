import { inject } from '@angular/core';
import { Routes, RouterModule, CanMatchFn, Router } from '@angular/router';

/*ALGR-126751 - Removed home module and added login as the default route */
export const defaultRedirectCanMatch: CanMatchFn = () => {
  const router = inject(Router);
  return router.createUrlTree(['/login'], {
    queryParams: { fromDefault: 'true' },
  });
};

const appRoutes: Routes = [
  { path: '', pathMatch: 'full', canMatch: [defaultRedirectCanMatch], children: [] },
  {
    path: 'forbidden',
    loadChildren: () => import('../login/login-server/login-server.module').then((m) => m.LoginServerModule)
  },
  {
    path: 'unauthorized',
    loadChildren: () => import('../login/login-server/login-server.module').then((m) => m.LoginServerModule)
  },
  {
    path: 'login',
    loadChildren: () => import('../login/login-server/login-server.module').then((m) => m.LoginServerModule)
  },
  {
    path: 'login-local',
    loadChildren: () => import('../login/login-local/login-local.module').then((m) => m.LoginLocalModule)
  },
  {
    path: 'login-with-serviceid',
    loadChildren: () => import('../login/login-server/login-server.module').then((m) => m.LoginServerModule)
  },
  {
    path: 'import-factors',
    loadChildren: () => import('../factor-maintenance/import-factors/import-factors.module').then((m) => m.ImportFactorsModule)
  },
  {
    path: 'export-factors',
    loadChildren: () => import('../factor-maintenance/export-factors/export-factors.module').then((m) => m.ExportFactorsModule)
  },
  {
    path: 'remove-factors',
    loadChildren: () => import('../factor-maintenance/remove-factors/remove-factors.module').then((m) => m.RemoveFactorsModule)
  },
  {
    path: 'cache-refresh',
    loadChildren: () => import('../factor-maintenance/cache-refresh/cache-refresh.module').then((m) => m.CacheRefreshModule)
  },
  {
    path: 'opportunity/create-opportunity-new',
    loadChildren: () => import('../opportunity/create-opportunity-new/create-opportunity-new.module').then((m) => m.CreateOpportunityNewModule)
  },
  {
    path: 'quote/uw-rate',
    loadChildren: () => import('../quotes/uw-adjustment/medical/medical.module').then((m) => m.MedicalModule)
  },
  {
    path: 'opportunity',
    loadChildren: () => import('../opportunity/opportunity-search/opportunity-search.module').then((m) => m.OpportunitySearchModule)
  },
  {
    path: 'quote',
    loadChildren: () => import('../quotes/quote-search/quote-search.module').then((m) => m.QuoteSearchModule)
  },
  {
    path: 'admin',
    loadChildren: () => import('../admin/admin.module').then((m) => m.AdminModule)
  },
  {
    path: 'token',
    loadChildren: () => import('../token/token.module').then((m) => m.TokenModule)
  },
  {
    path: 'healthcheck',
    loadChildren: () => import('../health-check/health-check.module').then((m) => m.HealthCheckModule)
  },
  {
    path: 'soldRate',
    loadChildren: () => import('../quotes/uw-adjustment/sold-rate/sold-rate.module').then((m) => m.SoldRateModule)
  },
  {
    path: 'soldRates',
    loadChildren: () => import('../quotes/uw-adjustment/sold-rates/sold-rates.module').then((m) => m.SoldRatesModule)
  },
  {
    path: 'quote/uw-rate-vision',
    loadChildren: () => import('../quotes/uw-adjustment/vision/vision.module').then((m) => m.VisionModule)
  },
  {
    path: 'quote/uw-rate-dental',
    loadChildren: () => import('../quotes/uw-adjustment/dental/dental.module').then((m) => m.DentalModule)
  },
  {
    path: 'quote/uw-rate-supplemental-health',
    loadChildren: () => import('../quotes/uw-adjustment/supplemental-health/supplemental-health.module').then((m) => m.SupplementalHealthModule)
  },
  {
    path: 'generate-report',
    loadChildren: () => import('../report-generate-management/report-generate-management.module').then((m) => m.ReportGenerateManagementModule)
  },
  {
    path: 'group',
    loadChildren: () => import('../renewals/renewals.module').then((m) => m.RenewalsModule)
  },
  {
    path: 'files',
    loadChildren: () => import('../files/files.module').then((m) => m.FilesModule)
  },
  {
    path: 'analytics-reports',
    loadChildren: () => import('../analytics-reports/analytics-reports.module').then((m) => m.AnalyticsReportsModule)
  },
  {
    path: 'factor-migration',
    loadChildren: () => import('../factor-maintenance/migration/migration.module').then((m) => m.MigrationModule)
  },
  {
    path: 'experience-extraction',
    loadChildren: () => import('../experience-extraction/experience-extraction.module').then((m) => m.ExperienceExtractionModule)
  },

  // otherwise redirect to login
  { path: '**', redirectTo: 'login' }
];

export const AppRoutingModule = RouterModule.forRoot(appRoutes, {});
