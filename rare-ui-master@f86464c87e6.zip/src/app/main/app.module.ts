import { NgModule, provideAppInitializer, inject, provideZoneChangeDetection } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideAnimations } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientService } from 'src/app/shared/services/http-client.service';
import { DatePipe } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { AuthConfigModule } from './auth-config.module';
import { AppInitService } from './services/app-init.service';
import { AuthInterceptorService } from './services/auth-interceptor.service';
import { IdleTimeoutComponent } from './idle-timeout/idle-timeout.component';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { IdleTimeoutService } from './services/idle-timeout.service';
import { providePrimeNG } from 'primeng/config';
import Aura from '@primeuix/themes/aura';
import { CommonModule } from '@angular/common';
import { OktaTokenInterceptorService } from './services/okta-token-interceptor.service';

@NgModule({
  declarations: [AppComponent, IdleTimeoutComponent],
  imports: [
    NgbModule,
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FormsModule,
    SharedModule,
    AuthConfigModule,
    DialogModule,
    ButtonModule,
    ToastModule,
    CommonModule
  ],
  providers: [
    provideAnimations(),
    provideHttpClient(withInterceptorsFromDi()),
    HttpClientService,
    DatePipe,
    AppInitService,
    IdleTimeoutService,
    provideZoneChangeDetection(),
    MessageService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: OktaTokenInterceptorService,
      multi: true
    },
    provideAppInitializer(() => {
      const appInitService = inject(AppInitService);
      return appInitService.Init();
    }),
    providePrimeNG({
      theme: {
        preset: Aura,
        options: {
          darkModeSelector: false || 'none'
        }
      }
    })
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
