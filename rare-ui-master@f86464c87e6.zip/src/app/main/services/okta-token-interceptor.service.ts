import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, ReplaySubject, Subscription } from 'rxjs';
import { switchMap, catchError, take, shareReplay, tap, finalize, filter } from 'rxjs/operators';
import { OidcSecurityService, PublicEventsService, EventTypes } from 'angular-auth-oidc-client';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/shared/services/common.service';
import { AuthenticationService } from '../../shared/services';
import { StringUtils } from '../../shared/utils/string-utils';

/**
 * Okta Token Interceptor
 * Automatically injects Okta access token into API requests
 *
 * Features:
 * - Validates token before injection
 * - Automatic retry on 401 with token refresh
 * - Queues requests during token refresh to prevent race conditions
 * - Environment-aware logging
 * - Precise URL pattern matching
 * - Secure token handling
 */
@Injectable()
export class OktaTokenInterceptorService implements HttpInterceptor {
  private isRefreshing = false;
  private cachedToken: string | null = null;
  private tokenExpiry: number | null = null;
  private tokenFetchInProgress$: Observable<string> | null = null;
  private refreshTokenSubject: ReplaySubject<string | null> = new ReplaySubject<string | null>(1);
  private isRedirectingToLogin = false;
  private silentRenewTimer: any = null;
  private renewSubscription: Subscription | null = null;

  constructor(
    private oidcSecurityService: OidcSecurityService,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private publicEventsService: PublicEventsService
  ) {
    this.renewSubscription = this.publicEventsService
      .registerForEvents()
      .pipe(filter((event) => event.type === EventTypes.NewAuthenticationResult))
      .subscribe(() => {
        this.scheduleSilentRenewBeforeRTExpires();
      });
  }

  /**
   * Intercepts HTTP requests and adds Okta Bearer token
   * @param req - The outgoing HTTP request
   * @param next - The next handler in the chain
   * @returns Observable of the HTTP event with token attached
   */
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (this.shouldSkipTokenInjection(req.url)) {
      return next.handle(req);
    }
    if (!this.shouldInterceptUrl(req.url)) {
      return next.handle(req);
    }

    if (window.location.href.indexOf('localhost') != -1 || StringUtils.isEqualIgnoreCase(this.commonService.getSecurityAuthMode(), 'CUSTOM_ONLY')) {
      return this.handleLocalRequest(req, next);
    }

    return this.handleRequestWithToken(req, next);
  }

  /**
   * Handles the request by adding token and managing errors
   * @param req - The HTTP request
   * @param next - The next handler
   * @returns Observable of HTTP event
   */
  private handleRequestWithToken(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return this.oidcSecurityService.getAccessToken().pipe(
      take(1),
      switchMap((token: string | null) => {
        if (!token) {
          this.log('warn', 'No access token available', req.url);
          return next.handle(req);
        }

        // ✅ FIX: Always send token if we have one, even if isAuthenticated is false
        // The server will return 401 if token is invalid/expired, and we'll handle it via retry logic
        // This prevents requests being sent WITHOUT token when token is expired but still in storage
        this.log('debug', 'Adding token to request', req.url);
        const clonedRequest = this.addTokenToRequest(req, token);
        return next.handle(clonedRequest).pipe(
          catchError((error: HttpErrorResponse) => this.handleHttpError(error, req, next))
        );
      })
    );
  }

  /**
   * Clones request and adds Authorization header
   * @param req - Original request
   * @param token - Access token
   * @returns Cloned request with token
   */
  private addTokenToRequest(req: HttpRequest<any>, token: string): HttpRequest<any> {
    return req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  private redirectToLogin(): void {
    if (this.isRedirectingToLogin) {
      this.log('warn', 'Redirect already in progress, skipping duplicate call');
      return;
    }

    this.isRedirectingToLogin = true;
    if (this.silentRenewTimer) {
      clearTimeout(this.silentRenewTimer);
      this.silentRenewTimer = null;
    }
    if (this.renewSubscription) {
      this.renewSubscription.unsubscribe();
      this.renewSubscription = null;
    }
    this.log('info', 'Redirecting to login due to session expiry');

    try {
      this.oidcSecurityService.logoffLocal();

      // Small delay to ensure logoff completes
      setTimeout(() => {
        try {
          if (this.commonService.getShowServiceIDLoginPage() == true) {
            this.log('info', 'Redirecting to Service ID login page');
            this.commonService.redirectServiceIDLoginPage();
          } else {
            this.log('info', 'Redirecting to Okta authorization');
            this.oidcSecurityService.authorize();
          }

          // Fallback: If redirect doesn't happen within 2 seconds, force navigation
          setTimeout(() => {
            const currentPath = window.location.pathname;
            if (!currentPath.includes('/login') && !currentPath.includes('authorize') && !currentPath.includes('oauth')) {
              this.log('error', 'Auth redirect failed, forcing window navigation to /login');
              window.location.href = '/login';
            }
            // Reset flag after redirect check
            this.isRedirectingToLogin = false;
          }, 2000);
        } catch (redirectError) {
          this.log('error', 'Failed to redirect to login', redirectError);
          this.isRedirectingToLogin = false;
          // Force browser navigation as last resort
          window.location.href = '/login';
        }
      }, 100);
    } catch (error) {
      this.log('error', 'Failed to logoff local session', error);
      this.isRedirectingToLogin = false;
      // Fallback redirect
      window.location.href = '/login';
    }
  }

  /**
   * Handles HTTP errors with retry logic for 401
   * @param error - HTTP error response
   * @param req - Original request
   * @param next - Next handler
   * @returns Observable that either retries or throws error
   */
  private handleHttpError(error: HttpErrorResponse, req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (error.status === 401) {
      if (!this.isRefreshing) {
        // First 401 - trigger token refresh
        this.log('warn', '401 Unauthorized - attempting token refresh', req.url);
        this.isRefreshing = true;
        this.refreshTokenSubject = new ReplaySubject<string | null>(1);

        return this.oidcSecurityService.forceRefreshSession().pipe(
          take(1),
          switchMap((refreshResult) => {
            // forceRefreshSession() resolves (not rejects) on invalid_grant — Okta returns
            // a 400 response which the library swallows and maps to isAuthenticated: false.
            // catchError will NOT fire for this case; must check the result here.
            if (!refreshResult?.isAuthenticated) {
              this.isRefreshing = false;
              this.refreshTokenSubject.next(null);
              this.refreshTokenSubject.complete();
              this.log('warn', 'Token refresh failed - session expired (invalid_grant)', req.url);
              this.showSessionExpiredDialog();
              this.redirectToLogin();
              return throwError(() => new Error('Session expired - please login again'));
            }

            this.log('info', 'Token refresh successful, retrying request', req.url);
            return this.oidcSecurityService.getAccessToken();
          }),
          take(1),
          switchMap((newToken: string | null) => {
            this.isRefreshing = false;
            this.refreshTokenSubject.next(newToken);
            this.refreshTokenSubject.complete();

            if (newToken) {
              this.log('debug', 'Retrying request with refreshed token', req.url);
              const clonedRequest = this.addTokenToRequest(req, newToken);
              return next.handle(clonedRequest).pipe(
                catchError((retryError: HttpErrorResponse) => {
                  if (retryError.status === 401) {
                    this.log('error', 'Retry failed with 401 after token refresh - logging out', req.url);
                    return throwError(() => retryError);
                  }
                  return throwError(() => retryError);
                })
              );
            }
            this.redirectToLogin();
            return throwError(() => error);
          }),
          catchError((refreshError: any) => {
            // Handles genuine thrown errors: network failures (ERR_CONNECTION_RESET),
            // library exceptions, or errors re-thrown from switchMap above.
            // Note: invalid_grant is NOT caught here — handled in switchMap above.
            this.isRefreshing = false;
            this.refreshTokenSubject.next(null);
            this.refreshTokenSubject.complete();
            this.log('error', 'Token refresh threw unexpected error', refreshError);
            this.showSessionExpiredDialog();
            this.redirectToLogin();
            return throwError(() => new Error('Authentication failed - please login again'));
          })
        );
      } else {
        // Subsequent 401s while refreshing - queue them
        this.log('debug', '401 during refresh - queueing request', req.url);
        return this.refreshTokenSubject.pipe(
          take(1),
          switchMap((token: string | null) => {
            if (token) {
              this.log('debug', 'Retrying queued request with refreshed token', req.url);
              const clonedRequest = this.addTokenToRequest(req, token);
              return next.handle(clonedRequest).pipe(
                catchError((retryError: HttpErrorResponse) => {
                  // If retry also fails with 401, don't retry again
                  if (retryError.status === 401) {
                    this.log('error', 'Queued retry failed with 401 - logging out', req.url);
                    return throwError(() => retryError);
                  }
                  return throwError(() => retryError);
                })
              );
            }
            this.redirectToLogin();
            return throwError(() => error);
          })
        );
      }
    }

    this.log('error', `HTTP ${error.status} error`, error.message);
    return throwError(() => error);
  }

  /**
   * Schedules a proactive silent renew via forceRefreshSession before the RT
   * 2-hour absolute cap is reached.
   *
   * Triggered by PublicEventsService.NewAuthenticationResult — fires after every
   * successful token renewal by the library (proactive or reactive).
   * Only one timer runs at a time (guarded by silentRenewTimer).
   *
   * Timing:
   *   AT lifetime = 3600s, renewTimeBeforeTokenExpiresInSeconds = 1800s
   *   Library renews at T+0:30. Timer fires at T+0:55 (1500s = 25 min later),
   *   before the next library renewal at T+1:00.
   *   forceRefreshSession() uses the still-valid RT to get a new AT+RT,
   *   resetting the RT sliding window — session continues uninterrupted.
   *   On failure: toast shown, redirect after 5s.
   */
  private scheduleSilentRenewBeforeRTExpires(): void {
    if (this.silentRenewTimer) {
      return;
    }
    const delayMs = (3600 - 1800 - 300) * 1000; // 1500s = 25 min
    this.silentRenewTimer = setTimeout(() => {
      this.log('info', 'Proactive silent renew — resetting RT sliding window');
      this.oidcSecurityService.forceRefreshSession().pipe(take(1)).subscribe({
        next: () => {
          this.log('info', 'Silent renew successful - RT sliding window reset');
          this.silentRenewTimer = null;
        },
        error: (err: any) => {
          this.log('warn', 'Silent renew failed - network issue or session expired', err);
          this.silentRenewTimer = null;
          window.dispatchEvent(new CustomEvent('session-renew-failed', {
            detail: { reason: 'silent_renew_failed' }
          }));
          setTimeout(() => this.redirectToLogin(), 5000);
        }
      });
    }, delayMs);
  }

  /**
   * Show session expired dialog before redirect
   * Emits event for IdleTimeoutComponent to display session timeout dialog
   */
  private showSessionExpiredDialog(): void {
    this.log('info', 'Triggering session expired dialog');
    sessionStorage.setItem('sessionExpiredReason', 'refresh_token_expired');
    window.dispatchEvent(new CustomEvent('session-expired', {
      detail: { reason: 'refresh_token_expired' }
    }));
  }

  /**
   * Determines if URL should have token injected based on configured patterns
   * @param url - Request URL
   * @returns True if token should be injected
   */
  private shouldInterceptUrl(url: string): boolean {
    return this.matchesDefaultPatterns(url);
  }

  /**
   * Checks if URL matches default API patterns
   * @param url - Request URL
   * @returns True if matches default patterns
   */
  private matchesDefaultPatterns(url: string): boolean {
    try {
      const urlObj = new URL(url, window.location.origin);
      const pathname = urlObj.pathname;
      return pathname.includes('/api/') || pathname.includes('/ui/');
    } catch {
      return url.includes('/api/') || url.includes('/ui/');
    }
  }

  /**
   * Determines if token injection should be skipped for specific URLs
   * Skips: Okta endpoints, config endpoints, health checks, token generation, external URLs, assets
   * @param url - Request URL
   * @returns True if token injection should be skipped
   */
  private shouldSkipTokenInjection(url: string): boolean {

    if (url.includes('.okta.com') || url.includes('oauth2') || url.includes('openid-configuration')) {
      return true;
    }

    if (url.includes('/appresource')) {
      return true;
    }

    if (window.location.hostname === 'localhost') {
      if (url.includes('/create/token')) {
        return true;
      }
    }

    const assetExtensions = ['.js', '.css', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.woff', '.woff2', '.ttf'];
    if (assetExtensions.some((ext) => url.toLowerCase().endsWith(ext))) {
      return true;
    }

    return this.isExternalUrl(url);
  }

  /**
   * Checks if URL is external (different origin)
   * @param url - Request URL
   * @returns True if URL is external
   */
  private isExternalUrl(url: string): boolean {
    try {
      if ((!url.startsWith('http://') && !url.startsWith('https://')) || window.location.hostname === 'localhost') {
        return false;
      }
      const urlObj = new URL(url);
      const currentOrigin = window.location.origin;
      return urlObj.origin !== currentOrigin;
    } catch {
      return false;
    }
  }

  /**
   * Environment-aware logging
   * @param level - Log level (warn, error, info)
   * @param message - Log message
   * @param data - Optional data to log
   */
  private log(level: 'warn' | 'error' | 'info' | 'debug', message: string, data?: any): void {
    if (environment.production) {
      return;
    }

    const prefix = '[OktaTokenInterceptor]';
    const sanitizedData = typeof data === 'string' && data.includes('?') ? data.split('?')[0] + '?[query params hidden]' : data;

    switch (level) {
      case 'warn':
        console.warn(`${prefix} ${message}`, sanitizedData || '');
        break;
      case 'error':
        console.error(`${prefix} ${message}`, sanitizedData || '');
        break;
      case 'info':
        console.info(`${prefix} ${message}`, sanitizedData || '');
        break;
      case 'debug':
        console.debug(`${prefix} ${message}`, sanitizedData || '');
        break;
    }
  }

  /**
   * Handles local development requests with cached token
   * @param req - The HTTP request
   * @param next - The next handler
   * @returns Observable of HTTP event
   */
  private handleLocalRequest(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (this.isTokenValid()) {
      const cloned = this.addTokenToRequest(req, this.cachedToken!);
      return next.handle(cloned);
    }

    return this.getOrFetchToken().pipe(
      switchMap((token: string) => {
        const cloned = this.addTokenToRequest(req, token);
        return next.handle(cloned);
      })
    );
  }

  /**
   * Checks if cached token is still valid
   * @returns True if token exists and is not expired
   */
  private isTokenValid(): boolean {
    if (!this.cachedToken || !this.tokenExpiry) {
      return false;
    }

    const currentTime = Math.floor(Date.now() / 1000);
    const bufferTime = 60;
    return this.tokenExpiry > currentTime + bufferTime;
  }

  /**
   * Gets cached token or fetches a new one
   * Prevents multiple simultaneous token fetch requests
   * @returns Observable of token string
   */
  private getOrFetchToken(): Observable<string> {
    if (this.tokenFetchInProgress$) {
      this.log('info', 'Token fetch already in progress, waiting...');
      return this.tokenFetchInProgress$;
    }

    this.log('info', 'Initiating new token fetch');
    const body = {
      subject: 'rare-ui',
      origin: 'rare-ui',
      userName: this.authenticationService.getUserName(),
      userID: this.authenticationService.getUserID()
    };

    this.tokenFetchInProgress$ = this.commonService.generateToken(body).pipe(
      tap({
        next: (token: string) => {
          this.log('info', 'Token received from API');
          this.cachedToken = token;
          this.tokenExpiry = this.extractTokenExpiry(token);
          this.log('info', 'Token fetched and cached', `Expiry: ${new Date(this.tokenExpiry! * 1000).toISOString()}`);
        },
        error: (error) => {
          this.log('error', 'Token fetch failed in tap', error);
          this.tokenFetchInProgress$ = null;
        }
      }),
      finalize(() => {
        this.log('info', 'Token fetch finalized, clearing in-progress flag');
        this.tokenFetchInProgress$ = null;
      }),
      shareReplay({ bufferSize: 1, refCount: true })
    );

    return this.tokenFetchInProgress$;
  }

  /**
   * Extracts expiry time from JWT token
   * @param token - JWT token
   * @returns Expiry timestamp in seconds, or null if invalid
   */
  private extractTokenExpiry(token: string): number | null {
    try {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload.exp || 3500;
    } catch (error) {
      this.log('error', 'Failed to decode token', error);
      return null;
    }
  }
}
