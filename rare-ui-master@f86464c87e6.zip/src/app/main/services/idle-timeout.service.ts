import { Injectable, NgZone } from '@angular/core';
import { ConfigService } from './config.service';

/**
 * Service to manage idle timeout functionality in the application.
 * Tracks user activity and triggers warning or timeout actions
 * when the user has been idle for a specified period.
 */
@Injectable({
  providedIn: 'root'
})
export class IdleTimeoutService {
  /** The key used to store the last activity timestamp in local storage. */
  private lastActivityKey: string = 'idleTimeoutLastActivity';

  /** Callback function to handle the warning state. */
  private handleWarning: () => void;

  /** Callback function to handle the timeout state. */
  private handleTimeout: () => void;
  
  /** Callback function to close warning dialog on user activity */
  private closeWarningCallback: () => void;
  
  public config: any;

  /** Flag to track if warning has been triggered */
  private warningTriggered: boolean = false;

  /** Flag to track if timeout has been triggered */
  private timeoutTriggered: boolean = false;
  /**
   * Constructor for IdleTimeoutService.
   * @param {NgZone} ngZone - Angular NgZone to manage change detection.
   * @param configService
   */
  constructor(
    private ngZone: NgZone,
    private configService: ConfigService
  ) {}

  /**
   * Initializes the idle timeout service with the provided callbacks.
   * @param {() => void} handleWarningCallback - Callback to execute when the warning period starts.
   * @param {() => void} handleTimeoutCallback - Callback to execute when the timeout period is reached.
   * @param {() => void} closeWarningCallback - Callback to close warning dialog on user activity.
   */
  initIdleService(handleWarningCallback: () => void, handleTimeoutCallback: () => void, closeWarningCallback?: () => void) {
    this.configService.getConfig().subscribe((data) => {
      this.config = data;
      if (this.config['IDLE_TIMEOUT_ENABLED']) {
        this.handleWarning = handleWarningCallback;
        this.handleTimeout = handleTimeoutCallback;
        this.closeWarningCallback = closeWarningCallback;
        this.setLastActivity();
        this.setupEventListeners();
        this.startCheck();
      }
    });
  }

  /**
   * Sets up event listeners to track user activity.
   * Resets the last activity time whenever an input event is detected.
   */
  private setupEventListeners() {
    ['mousemove', 'keydown', 'scroll', 'click'].forEach((event) => {
      window.addEventListener(event, this.setLastActivity.bind(this));
    });
  }

  /**
   * Updates the last activity timestamp in local storage.
   */
  private setLastActivity() {
    const now = Date.now();
    localStorage.setItem(this.lastActivityKey, now.toString());
    
    // Close warning dialog if user becomes active while warning is shown
    if (this.warningTriggered && this.closeWarningCallback) {
      this.closeWarningCallback();
    }
    
    this.warningTriggered = false;
    this.timeoutTriggered = false;
  }

  /**
   * Retrieves the last activity timestamp from local storage.
   * @returns {number} - The timestamp of the last recorded activity.
   */
  private getLastActivity(): number {
    const time = localStorage.getItem(this.lastActivityKey);
    return time ? parseInt(time, 10) : Date.now();
  }

  /**
   * Starts the periodic check for idle time.
   * Runs the check outside Angular's zone to avoid triggering change detection unnecessarily.
   */
  private startCheck() {
    this.ngZone.runOutsideAngular(() => {
      window.setInterval(() => {
        this.ngZone.run(() => this.checkIdleTime());
      }, this.config['IDLE_TIMEOUT_CHECK_INTERVAL']);
    });
  }

  /**
   * Checks the elapsed idle time and triggers the appropriate callbacks
   * for warning or timeout based on the configured periods.
   */
  private checkIdleTime() {
    const elapsedTime = Date.now() - this.getLastActivity();

    if (elapsedTime >= this.config['IDLE_TIMEOUT_WARNING'] && elapsedTime < this.config['IDLE_TIMEOUT']) {
      if (!this.warningTriggered) {
        this.warningTriggered = true;
        this.handleWarning();
      }
    }

    if (elapsedTime >= this.config['IDLE_TIMEOUT']) {
      if (!this.timeoutTriggered) {
        this.timeoutTriggered = true;
        this.handleTimeout();
      }
    }
  }
}
