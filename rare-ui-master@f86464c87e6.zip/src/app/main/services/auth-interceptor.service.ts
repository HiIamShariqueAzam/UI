import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { ConfigService } from './config.service';
import { switchMap } from 'rxjs/operators';
import { CommonConstants } from '../../shared/constants/common.constants';
import { CommonService } from 'src/app/shared/services';

/**
 * AuthInterceptorService is an HTTP interceptor that modifies outgoing HTTP requests
 * to include an environment parameter based on the configuration retrieved from ConfigService.
 */
@Injectable()
export class AuthInterceptorService implements HttpInterceptor {
  /**
   * Constructor for AuthInterceptorService.
   * @param {ConfigService} configService - The service used to fetch configuration data.
   */
  constructor(private configService: ConfigService, private commonService: CommonService) {}

  /**
   * Intercepts HTTP requests and adds an environment parameter to the request URL
   * if the request URL matches specific substrings.
   * @param {HttpRequest<any>} req - The outgoing HTTP request.
   * @param {HttpHandler} next - The next interceptor in the chain or the backend.
   * @returns {Observable<HttpEvent<any>>} - An observable of the HTTP event.
   */
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Check if the request URL matches specific substrings
    if (this.commonService.getOktaInterceptUrls()?.some((url: string): boolean => req.url.includes(url))) {
      // Fetch configuration data and modify the request URL to include the environment parameter
      return from(this.configService.getConfig().toPromise()).pipe(
        switchMap((data): Observable<HttpEvent<any>> => {
          const clonedRequest: HttpRequest<any> = req.clone({
            setParams: { app_id: CommonConstants.APP_NAME.concat('_').concat(data['RARE_APPLICATION_ENV']) }
          });
          return next.handle(clonedRequest);
        })
      );
    }
    // If the request URL does not match, pass the original request
    return next.handle(req);
  }
}
