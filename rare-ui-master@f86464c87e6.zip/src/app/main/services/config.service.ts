import { Injectable, Injector } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { shareReplay, tap } from 'rxjs/operators';
import { BUILD_HASH } from 'src/environments/build-hash';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CommonService } from 'src/app/shared/services';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private config$: Observable<any>;
  private commonService: CommonService;

  constructor(private httpClient: HttpClient, private injector: Injector) {}

/* ALGR-123967 - caching the appResource response in browser to improve performance */
  getConfig(): Observable<any> {
    const customUrl = '/api/rare/v1/appresource?key=';
    return this.updateAPIInLocalStorage(customUrl,true,'',CommonConstants.APP_RESOURCE);
  }

/* ALGR-124672 - caching the static API response in local storage to improve performance */
  updateAPIInLocalStorage(apiUrl: string, isAppResource: boolean, headers: any, storageKey: string) {
    const hashedKey = BUILD_HASH;
    const LAST_HASH_KEY = 'last-build-hash';
    const cacheResponse = this.getResponseInLocalStorage(hashedKey, storageKey,LAST_HASH_KEY);
    const lastCacheKey = JSON.parse(localStorage.getItem(LAST_HASH_KEY));
    const customUrl = apiUrl + hashedKey;
    if (cacheResponse && lastCacheKey === hashedKey) {
      return of(cacheResponse);
    }
    if (isAppResource) {
      if (!this.config$) {
        this.config$ = this.httpClient.get<any>(customUrl).pipe(tap(response => {
          this.getCommonService().setExpiryDateForStaticApi(response['EXPIRY_DATE_FOR_STATIC_API']);
          this.setResponseInLocalStorage(response, storageKey, hashedKey, LAST_HASH_KEY);
        }),
          shareReplay({bufferSize: 1, refCount: true}));
      }
      return this.config$;
    } else {
      return this.httpClient.get<any>(customUrl, { headers: headers }).pipe(tap(response => {
        this.setResponseInLocalStorage(response, storageKey, hashedKey, LAST_HASH_KEY);
      }))
    }

  }
  setResponseInLocalStorage(response: any, storageKey: string, hashedKey: string, lastHashKey: string) {
    let responseData = localStorage.getItem(hashedKey);
    let responseList = {};
    const expiryDate = new Date();
    const expiry = 'expiry';
    const expiryDateInHours = expiryDate.getTime() + (this.getCommonService().getExpiryDateForStaticApi() * 60 * 60 * 1000);
    if (StringUtils.isEmpty(responseData)) {
      this.removeResponseFromLocalStorage(hashedKey, lastHashKey);
    } else {
      let responseKeys = Object.keys(JSON.parse(responseData));
      if (responseKeys?.length) {
        responseKeys.forEach(key => {
          if (!StringUtils.isEqual(key, storageKey)) {
            responseList[key] = JSON.parse(responseData)?.[key];
          }
        });
      }
    }
    if(!StringUtils.isEmpty(response)){
    responseList[storageKey] = { value: response };
    responseList[expiry] = expiryDateInHours;
    localStorage.setItem(hashedKey, JSON.stringify(responseList));
    localStorage.setItem(lastHashKey, JSON.stringify(hashedKey));
    }
  }
  getResponseInLocalStorage(key: string, storageKey: string,lastHashKey:string) {
    const responseObject = localStorage.getItem(key);
    if (!responseObject) {
      return null;
    }
    const response = JSON.parse(responseObject);
    const currentTime = new Date();
    if (currentTime.getTime() > response?.expiry) {
      this.removeResponseFromLocalStorage(key,lastHashKey);
      return null;
    }
    return response?.[storageKey]?.value;
  }
  getCommonService() {
    if (!this.commonService) {
      this.commonService = this.injector.get(CommonService);
    }
    return this.commonService;
  }
  removeResponseFromLocalStorage(key: string,lastHashKey:string) {
    localStorage.removeItem(key);
    localStorage.removeItem(lastHashKey);
  }
}
