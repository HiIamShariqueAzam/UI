import { Injectable } from '@angular/core';
import { AbstractSecurityStorage } from 'angular-auth-oidc-client';
import * as CryptoJS from 'crypto-js';
import { SessionKeyService } from './session-key.service';

@Injectable({
  providedIn: 'root'
})
export class EncryptedStorageService implements AbstractSecurityStorage {
  constructor(private sessionKeyService: SessionKeyService) {
    // NA
  }

  private getSessionKey(): string {
    return this.sessionKeyService.getSessionKey();
  }

  read(key: string): any {
    const item = localStorage.getItem(key);
    if (!item) {
      return null;
    }
    const secretKey = this.getSessionKey();
    if (!secretKey) {
      return null;
    }
    try {
      const bytes = CryptoJS.AES.decrypt(item, secretKey);
      // Wrong key produces an empty/garbage decode; treat that as "not present"
      // rather than handing the OIDC client a corrupt state/nonce value.
      return bytes.toString(CryptoJS.enc.Utf8) || null;
    } catch {
      // Data was encrypted under a session key we no longer have
      // (cookie/localStorage desync). Behave as if the value is absent.
      return null;
    }
  }

  write(key: string, value: any): void {
    let secretKey = this.getSessionKey();
    if (!secretKey) {
      // No session key yet (first write, or the key cookie expired/was cleared).
      // Mint one and use it immediately so the value is actually persisted —
      // the previous implementation dropped the write here, which wiped the
      // OIDC authStateControl/authNonce mid-renew and caused "incorrect state".
      secretKey = this.sessionKeyService.generateSessionKey();
    }
    const encryptedValue = CryptoJS.AES.encrypt(value, secretKey).toString();
    localStorage.setItem(key, encryptedValue);
  }

  remove(key: string): void {
    localStorage.removeItem(key);
  }

  clear(): void {}
}
