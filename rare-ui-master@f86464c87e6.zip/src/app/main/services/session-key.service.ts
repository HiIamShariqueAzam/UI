import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class SessionKeyService {
  private readonly keyName = 'r256';
  private readonly key = 'another-secret-key';

  constructor(private cookieService: CookieService) {}

  generateSessionKey(): string {
    // Generate a random string to act as the session secret key
    const randomKey = CryptoJS.lib.WordArray.random(16).toString();
    const encryptedKey = CryptoJS.AES.encrypt(randomKey, this.key).toString();
    const expiryDate = new Date();
    expiryDate.setHours(expiryDate.getHours() + 8);
    this.cookieService.set(this.keyName, encryptedKey, expiryDate, '/', '', true, 'Strict');
    return randomKey;
  }

  getSessionKey(): string {
    const encryptedKey = this.cookieService.get(this.keyName);
    if (encryptedKey) {
      const bytes = CryptoJS.AES.decrypt(encryptedKey, this.key);
      return bytes.toString(CryptoJS.enc.Utf8);
    }
    return '';
  }

  removeSession() {
    this.cookieService.delete(this.keyName);
  }
}
