import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ResourceConfigService } from '../../shared/services/resource-config.service';
import { AuthenticationService, CommonService } from '../../shared/services';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { UserService } from '../../shared/services/user.service';
import { Router } from '@angular/router';
import { ConfigService } from './config.service';

/**
 * AppInitService is a service class in Angular.
 * It is responsible for initializing the application and handling the authorization process.
 * It has a config property that holds the configuration data fetched from '/appresource'.
 * It uses HttpClient for making HTTP requests, ResourceConfigService for setting the configuration data,
 * CommonService for handling redirections and OidcSecurityService for authorizing the user.
 *
 * @property {any} config - The configuration data fetched from '/appresource'.
 * @property {HttpClient} httpClient - The HttpClient used for making HTTP requests.
 * @property {ResourceConfigService} resourceConfig - The service used for setting the configuration data.
 * @property {CommonService} commonService - The service used for handling redirections.
 * @property {OidcSecurityService} oidcSecurityService - The service used for authorizing the user.
 */
@Injectable()
export class AppInitService {
  public config: any;
  authentication: any;
  isAuthenticated$: any;

  constructor(
    private router: Router,
    private userService: UserService,
    private resourceConfig: ResourceConfigService,
    private commonService: CommonService,
    private configService: ConfigService,
    private oidcSecurityService: OidcSecurityService,
    private authenticationService: AuthenticationService
  ) {}
  /**
   * This is the end of the httpLoaderFactory function. The function is responsible for making an HTTP GET request to a specified URL
   * and mapping the response to a configuration object that is used to initialize the StsConfigHttpLoader.
   * The StsConfigHttpLoader is then returned by the function.
   */
  Init() {
    return new Promise<boolean>((resolve) => {
      this.configService
        .getConfig()
        .toPromise()
        .then((data) => {
          this.config = data;
          this.resourceConfig.setConfigResourceData(data);
          const appURL = window.location.toString();
          if (appURL.includes('.temp.')) {
            this.commonService.setShowServiceIDLoginPage(true);
            this.commonService.redirectServiceIDLoginPage();
            resolve(true);
          } else {
            this.commonService.setShowServiceIDLoginPage(false);
            this.authorize(resolve);
          }
        });
      if (window.location.href.indexOf('localhost') != -1) {
        resolve(true);
      }
    });
  }

  /**
   * Resolves the app initializer only once the Okta session has been established.
   * While the user is unauthenticated the initializer stays pending so the router
   * never performs its initial navigation and no application route is rendered
   * before the redirect to Okta takes place.
   */
  private authorize(resolve: (value: boolean) => void) {
    if (this.commonService.getShowServiceIDLoginPage() == true) {
      this.commonService.redirectServiceIDLoginPage();
      resolve(true);
    } else {
      this.isAuthenticated$ = this.oidcSecurityService.isAuthenticated$;

      this.oidcSecurityService.checkAuth().subscribe({
        next: (auth: any) => {
          this.authentication = auth;
          if (this.authentication.isAuthenticated) {
            resolve(true);
            this.oidcSecurityService.userData$.subscribe((userInfo) => {
              let userData = userInfo['userData'];
              if (userData) {
                let userRoles = userData['roles'];
                let filteredGroups = userData['filteredgroups'];
                if (userRoles && userRoles.length > 0) {
                  this.authenticationService.changeUserID(userData['sub']);
                  this.authenticationService.changeUserEmail(userData['email']);
                } else {
                  this.authenticationService.changeUserID(userData['domainID']);
                  this.authenticationService.changeUserEmail(userData['mail']);
                }
                this.authenticationService.changeUserName(userData['firstname'] + ' ' + userData['lastname']);
                this.authenticationService.getEnvironmentGroups().then((data) => {
                  for (let environmentGroups of data) {
                    if (this.authenticationService.getAppEnvironment() == environmentGroups['environment']) {
                      const groups = userRoles && userRoles.length > 0 ? userRoles : filteredGroups;
                      if (groups && String(groups).indexOf(environmentGroups['usergroup']) !== -1) {
                        this.authenticationService.changeSiteminderAuthenticated(true);
                        this.authenticationService.setUserLoggedInUsingSiteminder(true);
                        this.authenticationService.changeShowMenu(true);
                        this.userService.setUserGlobalData(groups);
                      } else {
                        this.routeToUnauthorized();
                      }
                    }
                  }
                });
              }
            });
          } else {
            this.oidcSecurityService.authorize();
          }
        },
        error: (_error: any) => {
          this.oidcSecurityService.logoffLocal();
          this.oidcSecurityService.authorize();
        }
      });
    }
  }

  private routeToUnauthorized() {
    this.authenticationService.changeShowMenu(false);
    this.authenticationService.changeSiteminderAuthenticated(false);
    this.authenticationService.setUserLoggedInUsingSiteminder(false);
    this.oidcSecurityService.logoff();
    console.error('User has no groups assigned...!');
    alert("You don't have permission to access this application. Please contact RARE team <dl-RARE-IT@anthem.com> for access related questions...!");
    this.router.navigate(['/unauthorized']);
  }

  /**
   * AppInitService is a service class in Angular.
   * It is responsible for initializing the application and handling the authorization process.
   * It has a config property that holds the configuration data fetched from '/appresource'.
   * It uses HttpClient for making HTTP requests, ResourceConfigService for setting the configuration data,
   * CommonService for handling redirections and OidcSecurityService for authorizing the user.
   *
   * @property {any} config - The configuration data fetched from '/appresource'.
   * @property {HttpClient} httpClient - The HttpClient used for making HTTP requests.
   * @property {ResourceConfigService} resourceConfig - The service used for setting the configuration data.
   * @property {CommonService} commonService - The service used for handling redirections.
   * @property {OidcSecurityService} oidcSecurityService - The service used for authorizing the user.
   */
  private getUrlParameter(urlToCheck: any, name: any): string {
    if (!urlToCheck) {
      return '';
    }

    if (!name) {
      return '';
    }

    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    const regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    const results = regex.exec(urlToCheck);
    return results === null ? '' : decodeURIComponent(results[1]);
  }
}
