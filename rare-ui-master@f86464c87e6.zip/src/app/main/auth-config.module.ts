import { AuthModule, StsConfigHttpLoader, StsConfigLoader, LogLevel, AbstractSecurityStorage } from 'angular-auth-oidc-client';
import { NgModule } from '@angular/core';
import { map } from 'rxjs/operators';
import { ConfigService } from './services/config.service';
import { EncryptedStorageService } from './services/encryption.service';
import { SessionKeyService } from './services/session-key.service';

/**
 * This is the end of the httpLoaderFactory function. The function is responsible for making an HTTP GET request to a specified URL
 * and mapping the response to a configuration object that is used to initialize the StsConfigHttpLoader.
 * The StsConfigHttpLoader is then returned by the function.
 */
export const httpLoaderFactory = (configService: ConfigService) => {
  const config$ = configService.getConfig().pipe(
    map((customConfig: any) => {
      return {
        authority: customConfig['OKTA_SERVER_URL'],
        redirectUrl: customConfig['OKTA_REDIRECT_URL'],
        clientId: customConfig['OKTA_CLIENT_ID'],
        scope: 'openid ehprofile filteredgroups offline_access',
        responseType: 'code',
        silentRenew: true,  // ✅ ENABLE silent token renewal
        silentRenewUrl: window.location.origin + '/silent-renew.html',  // ✅ Iframe fallback when refresh token fails
        useRefreshToken: true,  // ✅ USE refresh tokens for renewal (primary strategy)

        // ✅ PROACTIVE REFRESH STRATEGY for Okta's sliding window:
        // - Okta refresh token: 90 min initial + 30 min extension (one-time) = 2 hour absolute max
        // - Access token: 60 min lifetime (expires_in: 3600)
        // - Refresh 30 min before expiry → fires at T+0:30, T+1:00, T+1:30
        // - refreshTokenExtensionUsed flag in interceptor guards against invalid_grant on 3rd attempt
        // - On RT exhaustion: non-prod shows session expired modal, prod redirects cleanly to login
        renewTimeBeforeTokenExpiresInSeconds: 1800,  // 30 min before expiry

        refreshTokenRetryInSeconds: 3,  // Retry quickly if refresh fails
        tokenRefreshInSeconds: 60,  // Check token validity every 60 seconds
        ignoreNonceAfterRefresh: true,  // ✅ Required for refresh token flow
        triggerRefreshWhenIdTokenExpired: false,  // ✅ Prevent unplanned extra refresh driven by ID token expiry
        maxIdTokenIatOffsetAllowedInSeconds: 120,
        // ✅ secureStorage intentionally omitted - uses injected AbstractSecurityStorage (EncryptedStorageService)
        logLevel: LogLevel.Warn,  // Reduce noise from expected token expiration errors
        autoUserInfo: false  // ✅ Don't fetch user info on every refresh (performance)
      };
    })
  );

  return new StsConfigHttpLoader(config$);
};

@NgModule({
  imports: [
    AuthModule.forRoot({
      loader: {
        provide: StsConfigLoader,
        useFactory: httpLoaderFactory,
        deps: [ConfigService, EncryptedStorageService]
      }
    })
  ],
  providers: [SessionKeyService, { provide: AbstractSecurityStorage, useClass: EncryptedStorageService }],
  exports: [AuthModule]
})
export class AuthConfigModule {}
