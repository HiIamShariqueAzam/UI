import { Component, HostBinding, OnInit, OnDestroy } from '@angular/core';
import { IdleTimeoutService } from '../services/idle-timeout.service';
import { AuthenticationService } from '../../shared/services';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

/**
 * Component to handle idle timeout functionality in the application.
 * Displays warning and timeout dialogs based on user inactivity.
 */
@Component({
  selector: 'app-idle-timeout',
  templateUrl: './idle-timeout.component.html',
  styleUrls: ['./idle-timeout.component.css'],
  standalone: false
})
export class IdleTimeoutComponent implements OnInit, OnDestroy {
  /** Flag to indicate whether the warning dialog is visible. */
  showWarningDialog: boolean = false;

  /** Flag to indicate whether the warning dialog is fading out. */
  @HostBinding('class.warning-fading-out')
  warningFadingOut: boolean = false;

  /** Flag to indicate whether the timeout dialog is visible. */
  showTimeoutDialog: boolean = false;

  position: 'center' | 'top' | 'bottom' | 'left' | 'right' | 'topleft' | 'topright' | 'bottomleft' | 'bottomright' = 'top';

  /** Event listener for session expired events from token interceptor */
  private sessionExpiredListener: ((event: any) => void) | null = null;

  /** Event listener for silent renew failure toast notification */
  private sessionRenewFailedListener: ((event: any) => void) | null = null;

  /**
   * Constructor for IdleTimeoutComponent.
   * @param {Router} router - Angular Router for navigation.
   * @param {IdleTimeoutService} idleService - Service to manage idle timeout functionality.
   * @param {AuthenticationService} authenticationService - Service to handle user authentication.
   */
  constructor(
    private router: Router,
    private idleService: IdleTimeoutService,
    private authenticationService: AuthenticationService,
    private messageService: MessageService
  ) {}

  /**
   * Lifecycle hook that is called after the component is initialized.
   * Initializes the idle timeout service with warning and timeout handlers.
   * Also listens for session expired events from token refresh failures.
   */
  ngOnInit(): void {
    this.idleService.initIdleService(this.handleWarning.bind(this), this.handleTimeout.bind(this), this.closeWarningDialog.bind(this));

    // Listen for session expired events from OktaTokenInterceptor
    this.sessionExpiredListener = (event: any) => {
      if (event.detail?.reason === 'refresh_token_expired') {
        // Mark that we've shown the dialog
        sessionStorage.setItem('sessionTimeoutDialogShown', 'true');

        // Show session timeout dialog
        this.showTimeoutDialog = true;
        this.showWarningDialog = false;

        // Clear flag after brief delay
        setTimeout(() => {
          sessionStorage.removeItem('sessionTimeoutDialogShown');
        }, 100);
      }
    };
    window.addEventListener('session-expired', this.sessionExpiredListener);

    this.sessionRenewFailedListener = () => {
      this.messageService.add({
        key: 'session-warn',
        severity: 'warn',
        summary: 'Session Error',
        detail: 'A network issue interrupted your session. Redirecting to login in 5 seconds...',
        life: 5000
      });
    };
    window.addEventListener('session-renew-failed', this.sessionRenewFailedListener);

    // Check if session expired before component loaded (e.g., page refresh during timeout)
    const expiredReason = sessionStorage.getItem('sessionExpiredReason');
    if (expiredReason === 'refresh_token_expired') {
      sessionStorage.setItem('sessionTimeoutDialogShown', 'true');
      this.showTimeoutDialog = true;
      sessionStorage.removeItem('sessionExpiredReason');
    }
  }

  /**
   * Handles the warning state when the user is about to be timed out.
   * Displays the warning dialog if no other dialog is currently shown.
   */
  handleWarning() {
    if (this.router.url === '/login') {
      return;
    }
    if (!this.showWarningDialog && !this.showTimeoutDialog) {
      this.showWarningDialog = true;
    }
  }

  /**
   * Handles the timeout state when the user has been idle for too long.
   * Displays the timeout dialog and hides the warning dialog if applicable.
   */
  handleTimeout() {
    if (this.router.url === '/login') {
      return;
    }
    if (!this.showTimeoutDialog) {
      // Dismiss warning immediately (no fade-out) so the timeout dialog takes over cleanly
      this.showWarningDialog = false;
      this.warningFadingOut = false;
      this.showTimeoutDialog = true;
    }
  }

  /**
   * Closes the warning dialog without logging the user out.
   * Applies a slow fade-out animation before hiding the dialog.
   */
  closeWarningDialog() {
    if (!this.showWarningDialog) {
      return;
    }
    this.warningFadingOut = true;
    setTimeout(() => {
      this.showWarningDialog = false;
      this.warningFadingOut = false;
    }, 400);
  }

  /**
   * Closes the timeout dialog and logs the user out.
   */
  closeTimeoutDialog() {
    this.showTimeoutDialog = false;
    this.authenticationService.logout(true);
  }

  /**
   * Lifecycle hook that is called when the component is destroyed.
   * Cleans up event listeners.
   */
  ngOnDestroy(): void {
    if (this.sessionExpiredListener) {
      window.removeEventListener('session-expired', this.sessionExpiredListener);
      this.sessionExpiredListener = null;
    }
    if (this.sessionRenewFailedListener) {
      window.removeEventListener('session-renew-failed', this.sessionRenewFailedListener);
      this.sessionRenewFailedListener = null;
    }
  }
}
