import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsDataloadComponent } from './analytics-dataload.component';

describe('AnalyticsDataloadComponent', () => {
  let component: AnalyticsDataloadComponent;
  let fixture: ComponentFixture<AnalyticsDataloadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnalyticsDataloadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsDataloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
