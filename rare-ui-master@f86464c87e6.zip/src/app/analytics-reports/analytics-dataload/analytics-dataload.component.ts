import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AnalyticsData } from 'src/app/shared/models/analyticsData';
import { AnalyticsService } from '../services/analytics.service';
import { StringUtils } from 'src/app/shared/utils/string-utils';
@Component({
  selector: 'app-analytics-dataload',
  templateUrl: './analytics-dataload.component.html',
  styleUrls: ['./analytics-dataload.component.css'],
  standalone: false
})
export class AnalyticsDataloadComponent implements OnInit {
  dataLoad_form: FormGroup<AnalyticsData>;
  selcetedFromDate: any;
  selectedToDate: any;
  quoteTable:boolean=true;
  otherTable:boolean=true;
  soldTable :boolean=true;
  curvRiskScoreTable :boolean=true;
  groupCreditsTable :boolean=true;
  selectedMode:any;
  constructor(private fb: FormBuilder, private analyticsService: AnalyticsService) { }
  validateDate(dateFrom: string, dateTo: string) {
    return (formGroup: FormGroup) => {
      const datefrom = formGroup.controls[dateFrom];
      const dateto = formGroup.controls[dateTo];
      if ((new Date(datefrom.value)) > (new Date(dateto.value))) {
        datefrom.setErrors({ invalidFromDate: true });
      }
      else {
        if (datefrom.hasError('required')) {
          datefrom.setErrors(null);
          datefrom.setErrors({ required: true });
        }
        else {
          datefrom.setErrors(null);
        }
      }
    }
  }
  getSelectedTable() {
    if (StringUtils.isEmpty(this.selectedMode)) {
      return true;
    }
  }
  ngOnInit(): void {
    this.dataLoad_form = this.fb.group({
      fromdate: [''],
      todate: [''],
    },
      {
        validator: this.validateDate('fromdate', 'todate'),
      }

    );
  }
  clickedFromDate() {
    this.showEmptyFromDate = this.showEmptyToDate = false;
    let element: HTMLElement = document.querySelectorAll('.fromdate .p-inputtext')[0] as HTMLElement;
    this.selcetedFromDate = element;
    if (typeof (element) != 'undefined') {
      element.click();
    }
    if (document.querySelector(".fromDateCalendar"))
      (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar-blue.svg";
    (<HTMLImageElement>document.querySelector(".toDateCalendar")).src = "./assets/calendar.svg";
  }
  clickedToDate() {
    this.showEmptyFromDate = this.showEmptyToDate = false;
    let element: HTMLElement = document.querySelectorAll('.todate .p-inputtext')[0] as HTMLElement;
    this.selectedToDate = element;
    if (typeof (element) != 'undefined') {
      element.click();
    }
    if (document.querySelector(".toDateCalendar"))
      (<HTMLImageElement>document.querySelector(".toDateCalendar")).src = "./assets/calendar-blue.svg";
    (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar.svg";
  }
  focusFromDateEle() {
    if (this.selcetedFromDate) {
      this.selcetedFromDate.focus();
    }
  }
  focusToDateEle() {
    if (this.selectedToDate) {
      this.selectedToDate.focus();
    }
  }
  formSubmitted: boolean = false;
  showEmptyFromDate: boolean = false;
  showEmptyToDate: boolean = false;
  searchClicked() {
    let form = this.dataLoad_form;
    if ((form.get("fromdate").value === "" || form.get("fromdate").value === null)) {
      this.showEmptyFromDate = true;
      return;
    }
    if ((form.get("todate").value === "" || form.get("todate").value === null)) {
      this.showEmptyToDate = true;
      return;
    }
    else {
      this.showEmptyFromDate = false;
      this.showEmptyToDate = false;
    }
    this.formSubmitted = true;
    if (this.dataLoad_form.invalid) {
      return;
    }
    this.analyticsService.loadAnalyticsData(form,this.selectedMode).subscribe(data => {
      alert("data loading process is " + data.status);
    })
  }
}