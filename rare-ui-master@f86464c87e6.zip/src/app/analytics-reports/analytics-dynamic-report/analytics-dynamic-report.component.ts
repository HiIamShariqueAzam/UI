import { DatePipe } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { AnalyticsReportCriteria, AnalyticsReportData } from 'src/app/shared/models/reports';
import { AuthenticationService, CommonService, DateFormatPipe, PrintExhibitService } from 'src/app/shared/services';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { AnalyticsService } from '../services/analytics.service';

@Component({
  selector: 'app-analytics-dynamic-report',
  templateUrl: './analytics-dynamic-report.component.html',
  styleUrls: ['./analytics-dynamic-report.component.css'],
  standalone: false,
})
export class AnalyticsDynamicReportComponent implements OnInit, OnDestroy {
  private eventSources: EventSource[] = [];
  dataLoad_form: FormGroup<any>;
  dynamic_form: FormGroup<any>;
  public dynamic_analyticsForm: FormGroup = this.formBuilder.group({});
  selectedMode: any;
  selectedReport: any;
  stepperItems: MenuItem[];
  ui_filter_criteria: AnalyticsReportCriteria[];
  reports = [];
  activeIndex: number = 0;
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  fieldRequired = false;
  selectedForm: any;
  initialForm:any;
  batchMsg: string;
  formData: AnalyticsReportData[];
  selectedDropdownValue : any;
  constructor(private formBuilder: FormBuilder, public datepipe: DatePipe, private analyticsService: AnalyticsService,
    private commonService: CommonService, private peService: PrintExhibitService, private authenticationService: AuthenticationService,
    private dateFormatPipe: DateFormatPipe) {
  }
  createForm(formdata: AnalyticsReportData[], reportName?: string) {
    for (const forms of formdata) {
      if (forms.reportName == reportName) {
        this.ui_filter_criteria = forms.reportCriteria;
        this.ui_filter_criteria.sort((a, b) => (+a["fieldOrder"] > +b["fieldOrder"]) ? 1 : ((+b["fieldOrder"] > +a["fieldOrder"]) ? -1 : 0))
        for (const control of forms.reportCriteria) {
          const validatorsToAdd = [];
          if (StringUtils.isEqual(control.mandatory, 'Y')) {
            validatorsToAdd.push(Validators.required);
          }
          this.dynamic_analyticsForm.addControl(
            control.fieldName,
            this.formBuilder.control('', validatorsToAdd)
          );
          this.dynamic_analyticsForm.controls[control.fieldName].setValue(control.selectedDefaultValue?.toString() ? control.selectedDefaultValue?.toString() : '');
          if (StringUtils.isEqual(control.fieldDisabled, 'Yes')) {
            this.dynamic_analyticsForm.controls[control.fieldName].disable();
          }
        }
      }
    }
  }
  changeReportData() {
    if (!StringUtils.isEmpty(this.formData)) {
      for (const forms of this.formData) {
        if (StringUtils.isEqual(this.selectedReport?.code, forms.reportName)) {
          this.selectedForm = JSON.parse(JSON.stringify(forms));
          this.createForm(this.formData, this.selectedReport.code);
          break;
        }
      }
    }
    if (!StringUtils.isEmpty(this.selectedReport)) {
      this.activeIndex = 1;
    }
  }
  ngOnInit(): void {
    this.analyticsService.getDynamicReport()
      .subscribe((formData: AnalyticsReportData[]) => {
        this.initialForm = JSON.parse(JSON.stringify(formData));
        this.formData = formData;
        if (this.formData) {
          for (const forms of this.formData) {
            this.reports.push(
              { name: forms.reportName, code: forms.reportName })
          }
          this.reports.sort((reportA, reportB) => reportA.name.localeCompare(reportB.name));
        }
      });
    this.dynamic_form = this.formBuilder.group({
      reportname: ['']

    })
    this.stepperItems = [{
      label: 'Select Report',
      command: (event: any) => {
        this.activeIndex = 0;
      }
    },
    {
      label: 'Input Data',
      command: (event: any) => {
        this.activeIndex = 1;
      }
    },
    {
      label: 'Confirmation',
      command: (event: any) => {
        this.activeIndex = 2;
      }
    }
    ];

    this.selectedDropdownValue = ['LG'];
  }
  dateAlert() {
    if (!StringUtils.isEmpty(this.dynamic_analyticsForm.value?.contract_effective_date_end) && this.dynamic_analyticsForm.value?.contract_effective_date_start > this.dynamic_analyticsForm.value?.contract_effective_date_end) {
      alert(CommonConstants.DATE_ERROR);
      return true;
    }
    else {
      return false;
    }
  }
  clickedCalendar(dateType) {
    if (StringUtils.isEqual(dateType, CommonConstants.CONTRACT_EFFECTIVEDATE_END)) {
      let element: HTMLElement = document.querySelector('#contract_effective_date_end .p-inputtext') as HTMLElement;
      this.dateButtonClick(element);
    }
    if (StringUtils.isEqual(dateType, CommonConstants.CONTRACT_EFFECTIVEDATE_START)) {
      let element: HTMLElement = document.querySelector('#contract_effective_date_start .p-inputtext') as HTMLElement;
      this.dateButtonClick(element);
    }
  }
  dateButtonClick(element: HTMLElement) {
    if (!StringUtils.isEmpty(typeof (element))) {
      element.click();
    }
  }
  resetToFirstStep()
  {
    this.selectedReport = null;
    this.activeIndex = 0;
    this.ui_filter_criteria = [];
    this.fieldRequired = false;
    this.dynamic_analyticsForm = this.formBuilder.group({});
    this.formData=JSON.parse(JSON.stringify(this.initialForm))
  }
  navigationToPrev() {
    if (this.activeIndex == 1) {
     this.resetToFirstStep();
    }
    if (this.activeIndex == 2) {
      this.activeIndex = 1;
    }
  }
  setDateValues() {
    if (!StringUtils.isEmpty(this.dynamic_analyticsForm.value.contract_effective_date_start)) {
      this.dynamic_analyticsForm.get('contract_effective_date_start').setValue(this.datepipe.transform(this.dynamic_analyticsForm.value.contract_effective_date_start, CommonConstants.DATE_FORMAT))
    }
    if (!StringUtils.isEmpty(this.dynamic_analyticsForm.value.contract_effective_date_end)) {
      this.dynamic_analyticsForm.get('contract_effective_date_end').setValue(this.datepipe.transform(this.dynamic_analyticsForm.value.contract_effective_date_end, CommonConstants.DATE_FORMAT))
    }
  }
  navigationToNext() {
    this.setDateValues();
    if (this.dateAlert()) {
      return;
    }
    if (this.dynamic_analyticsForm.invalid) {
      this.fieldRequired = true
      return;
    }
    this.selectedForm[CommonConstants.EMAIL_ID] = this.authenticationService.getUserEmail();
    for (const params of this.selectedForm.reportCriteria) {
      Object.keys(this.dynamic_analyticsForm.controls).forEach(key => {
        delete params.fieldDefaultValues;
        delete params.selectedDefaultValue;
        delete params.fieldDisabled
        delete params.fieldLabel
        delete params.fieldOrder
        if (params.fieldName == key) {
          params[CommonConstants.SELECTED_VALUES] = this.dynamic_analyticsForm.get(key).value.toString().replaceAll('"', '');
        }
        if (StringUtils.isEqual(params.fieldDataType, CommonConstants.DATE)) {
          params.selectedValues = this.dateFormatPipe.transform(params.selectedValues, CommonConstants.DATE_FORMAT_MONTH);
        }
      });
    }
    this.analyticsService.getDynamicReportDownload(this.selectedForm).subscribe(response => {
      if (!StringUtils.isEmpty(response.processId)) {
        this.processId = response.processId;
        this.showProgress = true;
        this.progressPercent = 1;
        this.progressStyle = CommonConstants.PROGRESS_BAR_WARNING;
        var source = this.commonService.listenForStream(this.processId);
        this.eventSources.push(source);
        source.addEventListener(CommonConstants.DOWNLOAD_REPORT_DATA_STATUS_STARTED, (event: any) => {
          this.progressStyle = "";
          let eventData = JSON.parse(event.data);
          var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
          this.progressPercent = percent;
          this.progressMessage = eventData.message;
        });
        source.addEventListener(CommonConstants.DOWNLOAD_REPORT_DATA_STATUS_COMPLETE, (message: any) => {
          source.close();
          let eventData = JSON.parse(message.data);
          this.progressStyle = CommonConstants.PROGRESS_BAR_SUCCESSS;
          this.progressPercent = 100;
          let messageStr =eventData.message.toString().split("|");
          this.progressMessage = messageStr[0];
          this.batchMsg = messageStr[1];
          let fileExt = CommonConstants.XSLX;
          CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet") + fileExt;
          let fileName = this.commonService.getExportFilename();
          let contentData = eventData.payload?.contentData;
          if (!StringUtils.isEmpty(contentData)) {
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
            this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            setTimeout(() => {
              this.showProgress = false;
              this.resetToFirstStep();
            }, this.commonService.getProgressBarTimeOut());
          }
          else {
            setTimeout(() => {
              this.showProgress = false;
              this.resetToFirstStep();
            }, 30000);
          }
        });
        source.addEventListener(CommonConstants.FAILED, (message: any) => {
          source.close();
          let eventData = JSON.parse(message.data);
          console.error("Received event : ", JSON.stringify(message.data));
          this.progressPercent = 90;
          this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
          this.progressMessage = eventData.message;
          setTimeout(() => {
            this.showProgress = false;
            this.resetToFirstStep();
          }, this.commonService.getProgressBarTimeOut());
        });
        source.addEventListener(CommonConstants.ERROR, (message: any) => {
          console.error("Received error event, with ready status :" + source.readyState);
          if (source.readyState == EventSource.CLOSED) {
            this.progressPercent = 90;
            this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
            this.progressMessage = CommonConstants.FAILED_MESSAGE;
          }
        });
      }
    })
    if (this.activeIndex == 1) {
      this.activeIndex = 2;
    }
  }
  getSelected() {
    if (!StringUtils.isEmpty(this.selectedMode)) {
      return true;
    }
    else {
      return false;
    }
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }

  onSelectClick(event: any, label: string) {
    if (label === 'autoBatchRuns') {
      const value = event.value || event.target?.innerText;
      this.ui_filter_criteria.forEach((criteria: any) => {
        if (criteria.fieldName === 'quoteStatus') {
          // For MultiDropDown, ensure 'Pending Exhibit' is included
          let currentValue = this.dynamic_analyticsForm.get('quoteStatus').value || [];
          if (value === 'Yes') {
            if (!currentValue.includes('Pending Exhibit')) {
              currentValue = [...currentValue, 'Pending Exhibit'];
              this.dynamic_analyticsForm.get('quoteStatus').setValue(currentValue);
            }
          } else if (value === 'No') {
            currentValue = currentValue.filter((v: string) => v !== 'Pending Exhibit');
            this.dynamic_analyticsForm.get('quoteStatus').setValue(currentValue);
          }
        }
      });
    }
  }
}
