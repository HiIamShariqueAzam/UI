import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsDynamicReportComponent } from './analytics-dynamic-report.component';

describe('AnalyticsDynamicReportComponent', () => {
  let component: AnalyticsDynamicReportComponent;
  let fixture: ComponentFixture<AnalyticsDynamicReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnalyticsDynamicReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AnalyticsDynamicReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
