import { Component, OnInit } from '@angular/core';
import { AnalyticsService } from './services/analytics.service';
@Component({
  selector: 'app-analytics-reports',
  templateUrl: './analytics-reports.component.html',
  styleUrls: ['./analytics-reports.component.css'],
  standalone: false
})
export class AnalyticsReportsComponent implements OnInit {

  constructor(private analyticsService: AnalyticsService) {
  }
  initialChartResponse: any;
  ngOnInit() {
    this.analyticsService.getAPIAnalyticsData().subscribe(data => {
      this.initialChartResponse = data;
    })
  }
}
