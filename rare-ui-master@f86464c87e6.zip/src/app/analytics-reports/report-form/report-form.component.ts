import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { JsonFormData } from 'src/app/shared/models/reports';
@Component({
  selector: 'app-report-form',
  templateUrl: './report-form.component.html',
  styleUrls: ['./report-form.component.css'],
  standalone: false
})
export class ReportFormComponent implements OnInit {

  constructor(private http: HttpClient) { }
  public formData: JsonFormData;
  ngOnInit() {
    this.http.get('/assets/report.json')
      .subscribe((formData: JsonFormData) => {
        this.formData = formData;
      });
  }
}
