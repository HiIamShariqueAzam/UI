import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SoldReportComponent } from './sold-report.component';

describe('SoldReportComponent', () => {
  let component: SoldReportComponent;
  let fixture: ComponentFixture<SoldReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SoldReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SoldReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
