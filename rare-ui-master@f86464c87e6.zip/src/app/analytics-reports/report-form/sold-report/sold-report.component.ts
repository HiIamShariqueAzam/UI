import {
  Component,
  OnChanges,
  Input,
  SimpleChanges,
  OnDestroy
} from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService, PrintExhibitService } from 'src/app/shared/services';
import { JsonFormControls, JsonFormData } from 'src/app/shared/models/reports';
import { DatePipe } from '@angular/common';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { AnalyticsService } from '../../services/analytics.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { AnalyticsConstants } from '../../analyticsConstants';

@Component({
  selector: 'app-sold-report',
  templateUrl: './sold-report.component.html',
  styleUrls: ['./sold-report.component.css'],
  standalone: false,
})
export class SoldReportComponent implements OnChanges, OnDestroy {
  private eventSources: EventSource[] = [];
  @Input() jsonFormData: JsonFormData;
  public analyticsForm: FormGroup = this.formBuilder.group({});
  reportName: string;
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  dateRequired = false;
  multiselectEle: any;
  constructor(private formBuilder: FormBuilder, private commonService: CommonService, private peService: PrintExhibitService,
    public datepipe: DatePipe, private analyticsService: AnalyticsService) { }

  ngOnChanges(changes: SimpleChanges) {
    if (!changes.jsonFormData.firstChange) {
      this.createForm(this.jsonFormData.controls);
      this.reportName = this.jsonFormData.reportName
    }
  }
  createForm(controls: JsonFormControls[]) {
    for (const control of controls) {
      const validatorsToAdd = [];
      for (const [key, value] of Object.entries(control.validators)) {
        switch (key) {
          case 'min':
            validatorsToAdd.push(Validators.min(value));
            break;
          case 'max':
            validatorsToAdd.push(Validators.max(value));
            break;
          case 'required':
            if (value) {
              validatorsToAdd.push(Validators.required);
            }
            break;
          case 'requiredTrue':
            if (value) {
              validatorsToAdd.push(Validators.requiredTrue);
            }
            break;
          case 'email':
            if (value) {
              validatorsToAdd.push(Validators.email);
            }
            break;
          case 'minLength':
            validatorsToAdd.push(Validators.minLength(value));
            break;
          case 'maxLength':
            validatorsToAdd.push(Validators.maxLength(value));
            break;
          case 'pattern':
            validatorsToAdd.push(Validators.pattern(value));
            break;
          case 'nullValidator':
            if (value) {
              validatorsToAdd.push(Validators.nullValidator);
            }
            break;
          default:
            break;
        }
      }
      this.analyticsForm.addControl(
        control.name,
        this.formBuilder.control(control.value, validatorsToAdd)
      );
    }
  }
  ngAfterViewInit() {
    this.multiselectEle = (document.querySelector('.ui-multiselect'));
    if (this.multiselectEle != null) {
      this.multiselectEle.setAttribute('tabindex', -1);
    }
  }
  displayOptionsPannel() {
    if (this.multiselectEle) {
      this.multiselectEle.focus();
    }
  }
  clickedCalendar(dateType) {
    if (StringUtils.isEqual(dateType, CommonConstants.FROM_DATE)) {
      let element: HTMLElement = document.querySelector('#fromDate .p-inputtext') as HTMLElement;
      this.dateButtonClick(element);
    }
    if (StringUtils.isEqual(dateType, CommonConstants.TO_DATE)) {
      let element: HTMLElement = document.querySelector('#toDate .p-inputtext') as HTMLElement;
      this.dateButtonClick(element);
    }
  }
  dateButtonClick(element: HTMLElement) {
    if (!StringUtils.isEmpty(typeof (element))) {
      element.click();
    }
  }
  setDateValues() {
    if (!StringUtils.isEmpty(this.analyticsForm.value.fromDate)) {
      this.analyticsForm.get(CommonConstants.FROM_DATE).setValue(this.datepipe.transform(this.analyticsForm.value.fromDate, CommonConstants.DATE_FORMAT))
    }
    if (!StringUtils.isEmpty(this.analyticsForm.value.toDate)) {
      this.analyticsForm.get(CommonConstants.TO_DATE).setValue(this.datepipe.transform(this.analyticsForm.value.toDate, CommonConstants.DATE_FORMAT))
    }
  }
  dateAlert() {
    if (this.analyticsForm.value.fromDate > this.analyticsForm.value.toDate) {
      alert(CommonConstants.DATE_ERROR);
      return true;
    }
    else {
      return false;
    }
  }
  onSubmit() {
    // this.setDateValues();
    if (this.dateAlert()) {
      return;
    }
    if (this.analyticsForm.invalid) {
      this.dateRequired = true
      return;
    }
    else {
      Object.keys(this.analyticsForm.controls).forEach(key => {
        if (StringUtils.isEqual(key, AnalyticsConstants.TEST_QUOTES)) {
          if (this.analyticsForm.value[key] == true) {
            this.analyticsForm.value[key] = CommonConstants.TEST
          }
          else {
            this.analyticsForm.value[key] = ''
          }
        }
        if (StringUtils.isEqual(key, AnalyticsConstants.INCLUDE_RISK_SCORE)) {
          if (this.analyticsForm.value[key] == true) {
            this.analyticsForm.value[key] = AnalyticsConstants.INCLUDE
          }
          else {
            this.analyticsForm.value[key] = ''
          }
        }
      });
      this.downloadReport()
    }
  }
  downloadReport() {
    const filterObj = {
      name: this.jsonFormData.reportName,
      filterData: this.analyticsForm.value
    }
    if (!StringUtils.isEmpty(filterObj?.filterData?.fromDate)) {
      filterObj.filterData.fromDate = this.datepipe.transform(filterObj.filterData.fromDate, CommonConstants.DATE_FORMAT);
    }
    if (!StringUtils.isEmpty(filterObj?.filterData?.toDate)) {
      filterObj.filterData.toDate = this.datepipe.transform(filterObj.filterData.toDate, CommonConstants.DATE_FORMAT);
    }
    this.analyticsService.getSoldReport(filterObj, this.jsonFormData.reportValue).subscribe(APIResponse => {
      if (!StringUtils.isEmpty(APIResponse.processId)) {
        this.processId = APIResponse.processId;
        this.showProgress = true;
        this.progressPercent = 1;
        this.progressStyle = CommonConstants.PROGRESS_BAR_WARNING;
        var source = this.commonService.listenForStream(this.processId);
        this.eventSources.push(source);
        source.addEventListener(CommonConstants.DOWNLOAD_REPORT_DATA_STATUS_STARTED, (event: any) => {
          this.progressStyle = "";
          let eventData = JSON.parse(event.data);
          var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
          this.progressPercent = percent;
          this.progressMessage = eventData.message;
        });
        source.addEventListener(CommonConstants.DOWNLOAD_REPORT_DATA_STATUS_COMPLETE, (message: any) => {
          source.close();
          let eventData = JSON.parse(message.data);
          this.progressStyle = CommonConstants.PROGRESS_BAR_SUCCESSS;
          this.progressPercent = 100;
          this.progressMessage = eventData.message;
          let fileExt = CommonConstants.XSLX;
          CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet") + fileExt;
          let fileName = this.commonService.getExportFilename();
          let contentData = eventData.payload.contentData;
          const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
          setTimeout(() => {
            this.showProgress = false;
          }, this.commonService.getProgressBarTimeOut());
        });
        source.addEventListener(CommonConstants.FAILED, (message: any) => {
          source.close();
          let eventData = JSON.parse(message.data);
          console.error("Received event : ", JSON.stringify(message.data));
          this.progressPercent = 90;
          this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
          this.progressMessage = eventData.message;
          this.hideProgressBar();
        });
        source.addEventListener(CommonConstants.ERROR, (message: any) => {
          console.error("Received error event, with ready status :" + source.readyState);
          if (source.readyState == EventSource.CLOSED) {
            this.progressPercent = 90;
            this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
            this.progressMessage = CommonConstants.FAILED_MESSAGE;
            this.hideProgressBar();
          }
        });
      }
    },
      error => {
        alert("Error in getting response for Download: " + error);
      }
    )
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }
}
