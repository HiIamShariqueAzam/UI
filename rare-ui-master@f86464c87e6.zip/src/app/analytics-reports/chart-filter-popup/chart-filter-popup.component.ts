import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/shared/services';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ChartFilterForm } from 'src/app/shared/models/chartFilter';
import { AnalyticsService } from '../services/analytics.service';
import { CommonConstants } from "../../shared/constants/common.constants";
import { CommonUtil } from 'src/app/shared/utils/common-util';

@Component({
  selector: 'app-chart-filter-popup',
  templateUrl: './chart-filter-popup.component.html',
  styleUrls: ['./chart-filter-popup.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class ChartFilterPopupComponent implements OnInit, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() filterChartData;
  availableStates: any[];
  selectedState: any = [];
  availableLOB: any = [];
  selectedLOB: any = [];
  availableOppTypes: any = [];
  selectedOppType: any = [];
  availableFundingTypes: any = [];
  availableMarketSegments: any = [];
  availableMBS: any = [];
  selectedFundingType: any = [];
  selectedMarketSegment: any = [];
  selectedMBS: any = [];
  showEmptyFromDate: boolean = false;
  showEmptyToDate: boolean = false;
  showEmptyTimePeriod3Date: boolean = false;
  chartFilter_form: FormGroup<ChartFilterForm>;
  selectedToDate: any;
  selcetedFromDate: any;
  selectedTimePeriod3Date: any;
  chartType=[];
  dateType=[];
  @Output() emittingUpdatedChart = new EventEmitter<any>();
  @Output() emitChartLoader = new EventEmitter<any>();
  constructor(
    private fb: FormBuilder,
    config: NgbModalConfig,
    private modalService: NgbModal,
    private commonService: CommonService,
    private router: Router,
    private analyticsService: AnalyticsService
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }
  selectedChart:string;
  DEFAULT_DATE_TYPE = 'QUOTE_DATE';

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  ngOnInit() {
    this.chartType = [
      {label: 'Line', value: 'line'},
      {label: 'Bar', value: 'bar'}
    ];

    this.chartFilter_form = this.fb.group({
      fromdate: [''],
      todate: [''],
      timePeriod3: [''],
      state: [''],
      lob: [''],
      opportunityType: [''],
      fundingType: [''],
      marketSegment: [''],
      mbs: [''],
      chartType: '',
      dateType: this.DEFAULT_DATE_TYPE
    });
    this.availableStates = this.commonService.getStateList();
    this.availableLOB = [
      { "label": "Medical", "value": "Medical" },
      { "label": "Vision", "value": "Vision" },
      { "label": "Dental", "value": "Dental" },
      { "label": "Supp Health", "value": "suppHealth" }
    ];
    this.availableOppTypes = [
      { "label": "New Business Local", "value": "New Business Local" },
      { "label": "Renewal Local", "value": "Renewal Local" }
    ];
    this.availableFundingTypes = [
      { "label": "FI", "value": "FI" },
      { "label": "ABF", "value": "ABF" }
    ];
    this.availableMarketSegments = [
      { "label": "SG", "value": "SG" },
      { "label": "LG", "value": "LG" }
    ];
    this.availableMBS = [
      { "label": "Key", "value": "Key" },
      { "label": "Non-Key", "value": "Non-Key" },
      { "label": "SG", "value": "SG" }
    ];
    this.dateType = [
      {label: 'Quoted Date', value: 'QUOTE_DATE'},
      {label: 'Contract Effective Date', value: 'CONTRACT_EFFECTIVEDATE'}
    ];
    this.setDefaultValues();
  }
  setDefaultValues() {
    this.selectedLOB = [];
    this.selectedState = [];
    this.selectedOppType = [];
    this.selectedFundingType = [];
    this.selectedMBS = [];
    this.selectedMarketSegment = [];
    this.availableStates.forEach(element => {
      this.selectedState.push(element.label)
    });
    this.availableLOB.forEach(element => {
      this.selectedLOB.push(element.value)
    });
    this.availableOppTypes.forEach(element => {
      this.selectedOppType.push(element.label)
    });
    this.availableFundingTypes.forEach(element => {
      this.selectedFundingType.push(element.label)
    });
    this.availableMarketSegments.forEach(element => {
      this.selectedMarketSegment.push(element.label)
    });
    this.availableMBS.forEach(element => {
      this.selectedMBS.push(element.label)
    });
    this.chartFilter_form.controls.dateType.setValue(this.DEFAULT_DATE_TYPE);
    this.chartFilter_form.controls.todate.setValue(CommonConstants.EMPTY_STRING);
    this.chartFilter_form.controls.fromdate.setValue(CommonConstants.EMPTY_STRING);
    this.chartFilter_form.controls.timePeriod3.setValue(CommonConstants.EMPTY_STRING);
  }

  clickedFromDate() {
    this.showEmptyFromDate = false;
    let element: HTMLElement = document.querySelectorAll('.fromdate .p-inputtext')[0] as HTMLElement;
    this.selcetedFromDate = element;
    if (typeof (element) != 'undefined') {
      element.click();
    }
    if (document.querySelector(".fromDateCalendar")) {
      (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar-blue.svg";
    }
  }

  clickedToDate() {
    this.showEmptyToDate = false;
    let element: HTMLElement = document.querySelectorAll('.todate .p-inputtext')[0] as HTMLElement;
    this.selectedToDate = element;
    if (typeof (element) != 'undefined') {
      element.click();
    }
    if (document.querySelector(".toDateCalendar"))
      (<HTMLImageElement>document.querySelector(".toDateCalendar")).src = "./assets/calendar-blue.svg";
    (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar.svg";
  }
  clickedTimePeriod3() {
    this.showEmptyTimePeriod3Date = false;
    let element: HTMLElement = document.querySelectorAll('.timePeriod3 .p-inputtext')[0] as HTMLElement;
    this.selectedTimePeriod3Date = element;
    if (typeof (element) != 'undefined') {
      element.click();
    }
    if (document.querySelector(".timePeriod3Calendar"))
      (<HTMLImageElement>document.querySelector(".timePeriod3Calendar")).src = "./assets/calendar-blue.svg";
    (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar.svg";
    (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar.svg";
  }
  onSubmit(chartFilter_form: FormGroup<ChartFilterForm>) {
    this.emitChartLoader.emit(true);
    const chartType=this.chartFilter_form.controls.chartType.value;
    const chartName = this.filterChartData.chartName;
    let filterObject = this.constructJSONReq(chartFilter_form);
    this.analyticsService.changeChartData(filterObject).subscribe(filterResponse => {
      if (filterResponse) {
        this.emitChartLoader.emit(false)
        this.emittingUpdatedChart.emit({filterResponse, filterObject, chartType, chartName});
        this.chartFilter_form.controls.chartType.reset();
      }
    }, error => {
      this.setDefaultValues();
    })
    if (chartFilter_form.invalid) {
      return;
    }
  }
  constructJSONReq(chartFilter_form: FormGroup<ChartFilterForm>) {
    let arr = [];
    if (chartFilter_form.get("fromdate").value && chartFilter_form.get("todate").value) {
      arr.push(this.formatDateForGraph(chartFilter_form.get("fromdate").value));
      arr.push(this.formatToDateByMonth(chartFilter_form.get("todate").value));
    }
    if (this.filterChartData.displayTimePeriod3 && chartFilter_form.get("timePeriod3").value) {
      arr.push(this.formatToDateByMonth(chartFilter_form.get("timePeriod3").value));
    }
    let obj = {
      'dateRange': arr, // dates in the request format
      'states': chartFilter_form.controls.state.value,
      'lob': chartFilter_form.controls.lob.value,
      'opportunityType': chartFilter_form.controls.opportunityType.value,
      'fundingType': chartFilter_form.controls.fundingType.value,
      'marketSegment': chartFilter_form.controls.marketSegment.value,
      'mbs': chartFilter_form.controls.mbs.value,
      'chartName': this.filterChartData.chartName,
      'testQuotes': "TEST",
      'dates': { // dates in format used by the form control
        'toDate': chartFilter_form.controls.todate.value,
        'fromDate': chartFilter_form.controls.fromdate.value,
        'timePeriod3': chartFilter_form.controls.timePeriod3.value,
      },
      'dateType': chartFilter_form.controls.dateType.value,
      'chartType': chartFilter_form.controls.chartType.value
    }
    return obj;
  }
  formatDateForGraph(date: Date) {
    return date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
  }
  formatToDateByMonth(date: Date) {
    const getDate = new Date(date.getFullYear(), (date.getMonth() + 1), 0).getDate();
    return date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + getDate;
  }
  onSave() {
    this.onSubmit(this.chartFilter_form);
  }
  onCancel() {
    this.chartFilter_form.controls.chartType.reset();
  }

  /**
   * Set filters for chart filter popup form controls
   * If no filters provided then it sets default values
   * @param filters
   */
  setFilters(filters) {
    if (filters && Object.keys(filters).length > 0) {
      this.chartFilter_form.patchValue({
        dateType: filters.dateType,
        fromdate: filters.dates.fromDate,
        todate: filters.dates.toDate,
        state: filters.states,
        lob: filters.lob,
        opportunityType: filters.opportunityType,
        fundingType: filters.fundingType,
        marketSegment: filters.marketSegment,
        mbs: filters.mbs,
        chartType: filters.chartType,
        timePeriod3: filters.dates.timePeriod3
      });
    } else {
      this.setDefaultValues()
    }
  }
}
