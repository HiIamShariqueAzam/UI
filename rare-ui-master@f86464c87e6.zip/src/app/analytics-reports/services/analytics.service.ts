import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable, throwError } from 'rxjs';
import { DateFormatPipe } from 'src/app/shared/pipes/date-format-pipe';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {

  constructor(
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private http: HttpClient,
    private dateFormatPipe: DateFormatPipe) { }

  getAPIAnalyticsData() {
    const header = this.commonService.setRequestHeaders();
    let metadata = {
      "userid": this.authenticationService.getUserID(),
      "username": this.authenticationService.getUserName()
    }
    let rareUiRequest = {
      "metadata": null,
      "data": {

      }
    }
    rareUiRequest.metadata = metadata;
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/uw-analytics/chart/data', rareUiRequest, { headers: header });
  }

  getAPIExcelData(chartData, chartName) {
    let headers = this.commonService.setRequestHeaders();
    let metadata = {
      "userid": this.authenticationService.getUserID(),
      "username": this.authenticationService.getUserName(),
    }
    chartData["metadata"] = metadata;
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/uw-analytics/chart/downloadChartDataToExcel", chartData, { headers: headers });
  }

  changeChartData(obj) {
    let headers = this.commonService.setRequestHeaders();
    let req = this.commonService.constructChartFilterRequest(obj);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/uw-analytics/chart/data', req, { headers: headers });
  }
  
  loadAnalyticsData(form: FormGroup,flowname): Observable<any> {
    let dateArray = <any>[];
    Object.keys(form.controls).forEach(key => {
      if (form.value[key] != "" && form.value[key] != null) {
        if (key == "fromdate" || key == "todate") {
          const fromdate = new Date(form.value[key]);
          let date = this.dateFormatPipe.transform(fromdate, "yyyy-MM-ddTHH:mm:ss.SSS");
          dateArray.push(date);
        }
      }
    });
    let urlComponents = "?eventStartDate=" + dateArray[0];
    let headers = this.commonService.setRequestHeaders();
    if (form.value["todate"]) {
      urlComponents = urlComponents + '&eventEndDate=' + dateArray[1];
    }
      urlComponents = urlComponents + '&flowNames=' + flowname;
      return this.http.get<any>(this.commonService.getRareUiUrl() + "/uw-analytics/data/loadquotesummary" + urlComponents, { headers: headers });
  }
  getSoldReport(data, endpoint) {
    let headers = this.commonService.setRequestHeaders();
    let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/' + endpoint, requestData, { headers: headers }).pipe(catchError(err => {
      return throwError(err);
    }));
  }
  getDynamicReport() {
    let headers = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/uw-analytics/report/dynamicReport', { headers: headers }).pipe(catchError(err => {
      return throwError(err);
    }));
  }
  getDynamicReportDownload(data) {
    let headers = this.commonService.setRequestHeaders();
    let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/uw-analytics/report/downloadDynamicReport', requestData, { headers: headers }).pipe(catchError(err => {
      return throwError(err);
    }));
  }
}
