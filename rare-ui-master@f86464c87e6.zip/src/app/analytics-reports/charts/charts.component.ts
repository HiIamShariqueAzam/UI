import { AfterViewInit, Component, ElementRef, Input, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Chart, registerables } from "chart.js";
import { CommonService, PrintExhibitService } from 'src/app/shared/services';
import { AnalyticsConstants } from 'src/app/analytics-reports/analyticsConstants';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { AnalyticsService } from '../services/analytics.service';
import { ChartFilterPopupComponent } from '../chart-filter-popup/chart-filter-popup.component';
import { ChartInfo } from 'src/app/shared/models/chart-info';
import { CommonUtil } from 'src/app/shared/utils/common-util';

Chart.register(...registerables);
enum chartHeadingValues {
  COMPARE_QUOTE_COUNTS_CHARTS = "COMPARE_QUOTE_COUNTS_CHARTS",
  LG_CHART_BY_MONTH_BY_FUNDINGTYPE = "LG_CHART_BY_MONTH_BY_FUNDINGTYPE",
  LG_CHART_BY_MONTH_LOB_DENTAL = "LG_CHART_BY_MONTH_LOB_DENTAL",
  LG_CHART_BY_MONTH_LOB_MEDICAL = "LG_CHART_BY_MONTH_LOB_MEDICAL",
  LG_CHART_BY_MONTH_LOB_VISION = "LG_CHART_BY_MONTH_LOB_VISION",
  LG_CHART_BY_MONTH_LOB_SUPP_HEALTH = "LG_CHART_BY_MONTH_LOB_SUPP_HEALTH",
  LG_Grand_Total_CHART_BY_Monthly = "LG_Grand_Total_CHART_BY_Monthly",
  LG_STATE_CHART = "LG_STATE_CHART",
  LG_STATE_CHART_BY_YEAR = "LG_STATE_CHART_BY_YEAR",
  Quote_Vol_by_LOB = "Quote Vol. by LOB",
  Quote_Vol_by_Market_Segment = "Quote Vol. by Market Segment",
  SG_CHART_BY_MONTH_BY_FUNDINGTYPE = "SG_CHART_BY_MONTH_BY_FUNDINGTYPE",
  SG_Grand_Total_CHART_BY_Monthly = "SG_Grand_Total_CHART_BY_Monthly",
  SG_STATE_CHART = "SG_STATE_CHART",
  SG_STATE_CHART_BY_YEAR = "SG_STATE_CHART_BY_YEAR"
}
@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css'],
  standalone: false,
})
export class ChartsComponent implements OnInit, AfterViewInit, OnDestroy {
  private eventSources: EventSource[] = [];
  @Input() initialChartResponse;
  objConstruct: any;
  objConstructSG: any;
  objConstructLOB: any;
  objConstructMKTSEG: any;
  objConstructLG: any;
  objConstructSGYear: any;
  objConstructLGYear: any;
  objConstructVisionLGStateMonth: any
  objConstructMedicalLGStateMonth: any
  objConstructDentalLGStateMonth: any
  objConstructSuppHealthLGStateMonth: any
  objConstructAllQuotesCountMonth: any
  objConstructFundingLGMonth: any
  objConstructFundingSGMonth: any
  objConstructLGGrand: any;
  objConstructSGGrand: any;
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  showLoader: boolean = false;
  chartTitleToDownload: string;
  filterCriteria:any;
  @ViewChild('QuoteVolByLOB', { static: true }) QuoteVolByLOBRef: ElementRef
  @ViewChild('LGVolByStateByMonth', { static: true }) LGVolByStateByMonthRef: ElementRef
  @ViewChild('SGVolByStateByMonth', { static: true }) SGVolByStateByMonthRef: ElementRef
  @ViewChild('TotalsByMarketByMonth', { static: true }) TotalsByMarketByMonthRef: ElementRef
  @ViewChild('SGvolumeYear', { static: true }) SGvolumeYearele: ElementRef
  @ViewChild('LGvolumeYear', { static: true }) LGvolumeYearele: ElementRef
  @ViewChild('LGGrandMonth', { static: true }) LGGrandMonthele: ElementRef
  @ViewChild('SGGrandMonth', { static: true }) SGGrandMonthele: ElementRef
  @ViewChild('LGFundingTypeMonth', { static: true }) LGFundingTypeMonthele: ElementRef
  @ViewChild('SGFundingTypeMonth', { static: true }) SGFundingTypeMonthele: ElementRef
  @ViewChild('VisionLGStateMonth', { static: true }) VisionLGStateMonthele: ElementRef
  @ViewChild('MedicalLGStateMonth', { static: true }) MedicalLGStateMonthele: ElementRef
  @ViewChild('DentalLGStateMonth', { static: true }) DentalLGStateMonthele: ElementRef
  @ViewChild('suppHealthLGStateMonth', { static: true }) suppHealthLGStateMonthele: ElementRef
  @ViewChild('AllQuoteCountMonth', { static: true }) AllQuoteCountMonthele: ElementRef
  @ViewChild(ChartFilterPopupComponent) chartFilterPopup: ChartFilterPopupComponent;
  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  private QuoteVolByLOB: Chart;
  private LGVolByStateByMonth: Chart;
  private SGVolByStateByMonth: Chart;
  private TotalsByMarketByMonth: Chart;
  private SGvolumeYear: Chart;
  private LGvolumeYear: Chart;
  private LGGrandMonth: Chart;
  private SGGrandMonth: Chart;
  private LGFundingTypeMonth: Chart;
  private SGFundingTypeMonth: Chart;
  private MedicalLGStateMonth: Chart;
  private VisionLGStateMonth: Chart;
  private DentalLGStateMonth: Chart;
  private suppHealthLGStateMonth: Chart;
  private AllQuoteCountMonth: Chart;
  datapoints = [];
  label = [];
  datapointsSG = [];
  labelSG = [];
  bgColor = [];
  datapointsSGYear = [];
  datapointsLOB = []
  labelLOB = []
  labelSGYear = [];
  datapointsLGYear = [];
  labelLGYear = [];
  datapointsVisionLGStateMonth = [];
  labelVisionLGStateMonth = [];
  datapointsMediaclLGStateMonth = [];
  labelMediaclLGStateMonth = [];
  datapointsDenLGStateMonth = [];
  labelDenLGStateMonth = [];
  datapointsSuppHealthLGStateMonth = [];
  labelSuppHealthLGStateMonth = [];
  datapointsAllQuoteCountMonth = [];
  labelAllQuoteCountMonth = [];
  datapointsFundingLGMonth = [];
  labelFundingLGMonth = [];
  datapointsFundingSGMonth = [];
  labelFundingSGMonth = [];
  datapointsMKTSEG = [];
  labelMKTSEG = []
  datapointsSGGrand = [];
  labelSGGrand = []
  datapointsLGGrand = [];
  labelLGGrand = []
  pagenumber: number = 1;
  colorMap = new Map<string, string>([
    ["CA", "rgba(255, 99, 132, 1)"],
    ["CO", "rgba(54, 162, 235, 1)"],
    ["CT", "rgba(255, 206, 86, 1)"],
    ["GA", "rgba(75, 192, 192, 1)"],
    ["IN", "rgba(153, 102, 255, 1)"],
    ["KY", "rgba(255, 159, 64, 1)"],
    ["ME", "green"],
    ["MO", "#fc6203"],
    ["NH", "#fc1303"],
    ["NV", "#a5fc03"],
    ["NY", "#03fc6f"],
    ["OH", "#03fce3"],
    ["VA", "#fc03f0"],
    ["WI", "#5c5950"],
    ["DENTAL", "rgba(255, 99, 132, 1)"],
    ["MEDICAL", "rgba(54, 162, 235, 1)"],
    ["VISION", "rgba(255, 206, 86, 1)"],
    ["SUPPHEALTH", "rgba(0, 0, 0, 1)"],
    ["LG", "rgba(255, 99, 132, 1)"],
    ["SG", "rgba(54, 162, 235, 1)"],
    ["ABF", "rgba(255, 99, 132, 1)"],
    ["ASO", "rgba(54, 162, 235, 1)"],
    ["FI", "rgba(255, 206, 86, 1)"],
    ["DENTAL-FI-LG", "rgba(255, 99, 132, 1)"],
    ["DENTAL-FI-SG", "rgba(54, 162, 235, 1)"],
    ["MEDICAL-ABF-LG", "rgba(255, 206, 86, 1)"],
    ["MEDICAL-ABF-SG", "rgba(75, 192, 192, 1)"],
    ["MEDICAL-FI-LG", "rgba(153, 102, 255, 1)"],
    ["MEDICAL-FI-SG", "rgba(255, 159, 64, 1)"],
    ["SUPPHEALTH-FI-LG", "rgba(0, 0, 0, 1)"],
    ["VISION-FI-LG", "green"],
    ["VISION-FI-SG", "#fc6203"]
  ])

  charts = [
    new ChartInfo('COMPARE_QUOTE_COUNTS_CHARTS', 'Trend Comparison for Quote Volume'),
    new ChartInfo('LG_CHART_BY_MONTH_BY_FUNDINGTYPE', 'FundingType totals by Month for LG'),
    new ChartInfo('LG_CHART_BY_MONTH_LOB_DENTAL', 'Dental LG Volume by State by Month'),
    new ChartInfo('LG_CHART_BY_MONTH_LOB_MEDICAL', 'Medical LG Volume by State by Month'),
    new ChartInfo('LG_CHART_BY_MONTH_LOB_VISION', 'Vision LG Volume by State by Month'),
    new ChartInfo('LG_CHART_BY_MONTH_LOB_SUPP_HEALTH', 'Supp Health LG Volume by State by Month'),
    new ChartInfo('LG_Grand_Total_CHART_BY_Monthly', 'LG Grand Total by Month'),
    new ChartInfo('LG_STATE_CHART', 'LG Volume by State by Month'),
    new ChartInfo('LG_STATE_CHART_BY_YEAR', 'LG Volume by State by Year'),
    new ChartInfo('Quote Vol. by LOB', 'Quote Volume by LOB'),
    new ChartInfo('Quote Vol. by Market Segment', 'Totals by Market by Month'),
    new ChartInfo('SG_CHART_BY_MONTH_BY_FUNDINGTYPE', 'FundingType totals by Month for SG'),
    new ChartInfo('SG_Grand_Total_CHART_BY_Monthly', 'SG Grand Total by Month'),
    new ChartInfo('SG_STATE_CHART', 'SG Volume by State by Month'),
    new ChartInfo('SG_STATE_CHART_BY_YEAR', 'SG Volume by State by Year')
  ];

  constructor(private commonService: CommonService, private peService: PrintExhibitService, private analyticsService: AnalyticsService) { }
  ngAfterViewInit() {
    if (this.chartFilterPopup.modalContent && this.chartFilterPopup.modalHeader && this.chartFilterPopup.modalFooter) {
      const content = this.chartFilterPopup.modalContent.nativeElement;
      const header = this.chartFilterPopup.modalHeader.nativeElement;
      const footer = this.chartFilterPopup.modalFooter.nativeElement;

      CommonUtil.modalPopup(content, [header, footer]);
    }

    Chart.defaults.elements.line.tension = 0.2;
    Chart.defaults.elements.line.fill = false;
    Chart.defaults.scale.min = 0;
    this.LGVolByStateByMonth = new Chart(this.LGVolByStateByMonthRef.nativeElement, {
      type: 'line',
      data: this.objConstruct
    });
    this.MedicalLGStateMonth = new Chart(this.MedicalLGStateMonthele.nativeElement, {
      type: 'line',
      data: this.objConstructMedicalLGStateMonth
    });
    this.VisionLGStateMonth = new Chart(this.VisionLGStateMonthele.nativeElement, {
      type: 'line',
      data: this.objConstructVisionLGStateMonth
    });
    this.SGVolByStateByMonth = new Chart(this.SGVolByStateByMonthRef.nativeElement, {
      type: 'line',
      data: this.objConstructSG
    });
    this.SGvolumeYear = new Chart(this.SGvolumeYearele.nativeElement, {
      type: 'bar',
      data: this.objConstructSGYear
    });
    this.LGvolumeYear = new Chart(this.LGvolumeYearele.nativeElement, {
      type: 'bar',
      data: this.objConstructLGYear
    });
    this.TotalsByMarketByMonth = new Chart(this.TotalsByMarketByMonthRef.nativeElement, {
      type: 'line',
      data: this.objConstructMKTSEG,
    });
    this.LGGrandMonth = new Chart(this.LGGrandMonthele.nativeElement, {
      type: 'line',
      data: this.objConstructLGGrand,
    });
    this.SGGrandMonth = new Chart(this.SGGrandMonthele.nativeElement, {
      type: 'line',
      data: this.objConstructSGGrand,
    });
    this.QuoteVolByLOB = new Chart(this.QuoteVolByLOBRef.nativeElement, {
      type: 'bar',
      data: this.objConstructLOB,
    });
    this.SGFundingTypeMonth = new Chart(this.SGFundingTypeMonthele.nativeElement, {
      type: 'bar',
      data: this.objConstructFundingSGMonth,
    });
    this.LGFundingTypeMonth = new Chart(this.LGFundingTypeMonthele.nativeElement, {
      type: 'bar',
      data: this.objConstructFundingLGMonth,
    });
    this.DentalLGStateMonth = new Chart(this.DentalLGStateMonthele.nativeElement, {
      type: 'line',
      data: this.objConstructDentalLGStateMonth,
    });
    this.suppHealthLGStateMonth = new Chart(this.suppHealthLGStateMonthele.nativeElement, {
      type: 'line',
      data: this.objConstructSuppHealthLGStateMonth,
    });
    this.AllQuoteCountMonth = new Chart(this.AllQuoteCountMonthele.nativeElement, {
      type: 'bar',
      data: this.objConstructAllQuotesCountMonth,
    });
  }
  firstpage() {
    switch (this.pagenumber) {
      case 2: this.pagenumber = 1;
        break;
      case 3: this.pagenumber = 2;
        break;
      case 4: this.pagenumber = 3;
        break;
    }
  }
  secondpage() {
    switch (this.pagenumber) {
      case 1: this.pagenumber = 2;
        break;
      case 2: this.pagenumber = 3;
        break;
      case 3: this.pagenumber = 4;
        break;
    }
  }
  compare(a, b) {
    if (a.label < b.label) {
      return -1;
    }
    if (a.label > b.label) {
      return 1;
    }
    return 0;
  }
  filterChartData = {
    'chartName': null,
    'chartLabel': null,
    'displayTimePeriod3': false,
  };
  openMonthlyTrendChartFilterPopup(chartLabel: string) {
    let chart: ChartInfo = this.charts.find(chart => StringUtils.isEqualIgnoreCase(chart.chartLabel, chartLabel));
    if (chart?.filters) {
      this.chartFilterPopup.setFilters(chart.filters)
    }
    this.charts.forEach(charts => {
      if (charts.chartLabel == chartLabel) {
        this.filterChartData.chartLabel = charts.chartLabel;
        this.filterChartData.chartName = charts.chartName
      }
    });
    this.filterChartData.displayTimePeriod3 = chartLabel == this.charts[0].chartLabel;
  }

  /**
   * Store filters for the chart
   * @param chartName -> as a string
   * @param filter -> as an object of values from popup fields
   */
  storeFilter(chartName: string, filter: {}) {
    let chart: ChartInfo =
      this.charts.find(chart => StringUtils.isEqualIgnoreCase(chart.chartName, chartName));
    if (chart) {
      chart.filters = filter;
    }
  }

  emittingUpdatedChart(filterAPIResponse) {
    this.filterCriteria=filterAPIResponse.filterObject
    this.initialChartResponse = filterAPIResponse.filterResponse;
    this.storeFilter(filterAPIResponse.chartName, filterAPIResponse.filterObject);
    const chartType=filterAPIResponse.chartType && filterAPIResponse.chartType.value ? filterAPIResponse.chartType.value:'';
    switch (this.filterChartData.chartLabel) {
      case "LG Volume by State by Month":
        this.LGVolByStateByMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.LG_STATE_CHART, this.objConstruct, this.LGVolByStateByMonth, 'borderColor',chartType)
        break;
      case "Quote Volume by LOB":
        this.QuoteVolByLOB=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.Quote_Vol_by_LOB, this.objConstructLOB, this.QuoteVolByLOB, 'backgroundColor',chartType)
        break;
      case "SG Volume by State by Month":
        this.SGVolByStateByMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.SG_STATE_CHART, this.objConstructSG, this.SGVolByStateByMonth, 'borderColor',chartType)
        break;
      case "Totals by Market by Month":
        this.TotalsByMarketByMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.Quote_Vol_by_Market_Segment, this.objConstructMKTSEG, this.TotalsByMarketByMonth, 'borderColor',chartType)
        break;
      case "SG Volume by State by Year":
        this.SGvolumeYear=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.SG_STATE_CHART_BY_YEAR, this.objConstructSGYear, this.SGvolumeYear, 'backgroundColor',chartType)
        break;
      case "LG Volume by State by Year":
        this.LGvolumeYear=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.LG_STATE_CHART_BY_YEAR, this.objConstructLGYear, this.LGvolumeYear, 'backgroundColor',chartType)
        break;
      case "LG Grand Total by Month":
        this.LGGrandMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.LG_Grand_Total_CHART_BY_Monthly, this.objConstructLGGrand, this.LGGrandMonth, 'borderColor',chartType)
        break;
      case "SG Grand Total by Month":
        this.SGGrandMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.SG_Grand_Total_CHART_BY_Monthly, this.objConstructSGGrand, this.SGGrandMonth, 'borderColor',chartType)
        break;
      case "Trend Comparison for Quote Volume":
        this.AllQuoteCountMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.COMPARE_QUOTE_COUNTS_CHARTS, this.objConstructAllQuotesCountMonth, this.AllQuoteCountMonth, 'backgroundColor',chartType)
        break;
      case "FundingType totals by Month for LG":
        this.LGFundingTypeMonth=this.updateChartData(filterAPIResponse.filterResponse, "LG_CHART_BY_MONTH_BY_FUNDINGTYPE", this.objConstructFundingLGMonth, this.LGFundingTypeMonth, 'backgroundColor',chartType)
        break;
      case "FundingType totals by Month for SG":
        this.SGFundingTypeMonth= this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.SG_CHART_BY_MONTH_BY_FUNDINGTYPE, this.objConstructFundingSGMonth, this.SGFundingTypeMonth, 'backgroundColor',chartType)
        break;
      case "Vision LG Volume by State by Month":
        this.VisionLGStateMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.LG_CHART_BY_MONTH_LOB_VISION, this.objConstructVisionLGStateMonth, this.VisionLGStateMonth, 'borderColor',chartType)
        break;
      case "Medical LG Volume by State by Month":
        this.MedicalLGStateMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.LG_CHART_BY_MONTH_LOB_MEDICAL, this.objConstructMedicalLGStateMonth, this.MedicalLGStateMonth, 'borderColor',chartType)
        break;
      case "Dental LG Volume by State by Month":
        this.DentalLGStateMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.LG_CHART_BY_MONTH_LOB_DENTAL, this.objConstructDentalLGStateMonth, this.DentalLGStateMonth, 'borderColor',chartType)
        break;
      case "Supp Health LG Volume by State by Month":
        this.suppHealthLGStateMonth=this.updateChartData(filterAPIResponse.filterResponse, chartHeadingValues.LG_CHART_BY_MONTH_LOB_SUPP_HEALTH, this.objConstructSuppHealthLGStateMonth, this.suppHealthLGStateMonth, 'borderColor',chartType)
        break;
    }
  }
  updateChartData(filterResponse, chartName, chartObj, chartNameRef, colorType,chartType) :Chart{
    chartObj.labels = filterResponse.chartDataMap[chartName].labels.sort(this.compare);
    chartObj.datasets = filterResponse.chartDataMap[chartName].datasets.sort(this.compare);
    chartType= StringUtils.isEmpty(chartType) ?  chartNameRef.config.type:chartType;
    let chartContext = chartNameRef.ctx;
    if (chartNameRef) {
      chartNameRef.destroy();
    }
    if(StringUtils.isEqual(chartType,AnalyticsConstants.BAR))
    {
      colorType=AnalyticsConstants.BACKGROUND_COLOR;
      chartNameRef.config.type=AnalyticsConstants.BAR
    }
    else if(StringUtils.isEqual(chartType,AnalyticsConstants.LINE))
    {
      colorType=AnalyticsConstants.BORDER_COLOR;
      chartNameRef.config.type=AnalyticsConstants.LINE
    }
    chartObj.datasets.forEach((dataset) => {
      dataset[colorType] = this.colorMap.has(dataset.label) ? this.colorMap.get(dataset.label): '';
    });
    chartNameRef = new Chart(chartContext, {
      type: chartType,
      data: chartObj
    })
    return chartNameRef;
  }
  emitChartLoader(filterResponse) {
    this.showLoader = filterResponse;
  }
  ngOnInit() {
    this.bgColor = ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)', 'rgba(75, 192, 192, 1)'
      , 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)', 'green', '#fc6203', '#fc1303', '#a5fc03', '#03fc6f', '#03fce3', '#fc03f0']
    this.initialChartResponse.chartDataMap["LG_Grand_Total_CHART_BY_Monthly"]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsLGGrand.push(chartData.data);
      this.labelLGGrand.push(chartData.label)
    });
    const newdatasetLGGrand = this.labelLGGrand.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsLGGrand[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructLGGrand = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_Grand_Total_CHART_BY_Monthly]?.labels,
      datasets: newdatasetLGGrand
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.SG_Grand_Total_CHART_BY_Monthly]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsSGGrand.push(chartData.data);
      this.labelSGGrand.push(chartData.label)
    });
    const newdatasetSGGrand = this.labelSGGrand.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsSGGrand[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructSGGrand = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.SG_Grand_Total_CHART_BY_Monthly]?.labels,
      datasets: newdatasetSGGrand
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.Quote_Vol_by_LOB]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsLOB.push(chartData.data);
      this.labelLOB.push(chartData.label)
    });
    const newdatasetLOB = this.labelLOB.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsLOB[index];
      newDataobj["backgroundColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructLOB = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.Quote_Vol_by_LOB]?.labels,
      datasets: newdatasetLOB
    }
    this.initialChartResponse.chartDataMap["Quote Vol. by Market Segment"]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsMKTSEG.push(chartData.data);
      this.labelMKTSEG.push(chartData.label)
    });
    const newdatasetMKTSEG = this.labelMKTSEG.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsMKTSEG[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructMKTSEG = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.Quote_Vol_by_Market_Segment]?.labels,
      datasets: newdatasetMKTSEG
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.LG_STATE_CHART]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapoints.push(chartData.data);
      this.label.push(chartData.label)
    });
    const newdataset = this.label.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapoints[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstruct = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_STATE_CHART]?.labels,
      datasets: newdataset
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.SG_STATE_CHART]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsSG.push(chartData.data);
      this.labelSG.push(chartData.label)
    });
    const newdatasetSG = this.labelSG.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsSG[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructSG = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.SG_STATE_CHART]?.labels,
      datasets: newdatasetSG
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.LG_STATE_CHART_BY_YEAR]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsLGYear.push(chartData.data);
      this.labelLGYear.push(chartData.label)
    });
    const newdatasetLGYear = this.labelLGYear.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsLGYear[index];
      newDataobj["backgroundColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructLGYear = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_STATE_CHART_BY_YEAR]?.labels,
      datasets: newdatasetLGYear
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.SG_STATE_CHART_BY_YEAR]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsSGYear.push(chartData.data);
      this.labelSGYear.push(chartData.label)
    });
    const newdatasetSGYear = this.labelSGYear.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsSGYear[index];
      newDataobj["backgroundColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructSGYear = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.SG_STATE_CHART_BY_YEAR]?.labels,
      datasets: newdatasetSGYear
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_MEDICAL]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsMediaclLGStateMonth.push(chartData.data);
      this.labelMediaclLGStateMonth.push(chartData.label)
    });
    const newdatasetMedLGStateMonth = this.labelMediaclLGStateMonth.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsMediaclLGStateMonth[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructMedicalLGStateMonth = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_MEDICAL]?.labels,
      datasets: newdatasetMedLGStateMonth
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_VISION]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsVisionLGStateMonth.push(chartData.data);
      this.labelVisionLGStateMonth.push(chartData.label)
    });
    const newdatasetVisLGStateMonth = this.labelVisionLGStateMonth.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsVisionLGStateMonth[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructVisionLGStateMonth = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_VISION]?.labels,
      datasets: newdatasetVisLGStateMonth
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_DENTAL]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsDenLGStateMonth.push(chartData.data);
      this.labelDenLGStateMonth.push(chartData.label)
    });
    const newdatasetDenLGStateMonth = this.labelDenLGStateMonth.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsDenLGStateMonth[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructDentalLGStateMonth = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_DENTAL]?.labels,
      datasets: newdatasetDenLGStateMonth
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_SUPP_HEALTH]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsSuppHealthLGStateMonth.push(chartData.data);
      this.labelSuppHealthLGStateMonth.push(chartData.label)
    });
    const newdatasetSuppHealthLGStateMonth = this.labelSuppHealthLGStateMonth.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsSuppHealthLGStateMonth[index];
      newDataobj["borderColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructSuppHealthLGStateMonth = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_LOB_SUPP_HEALTH]?.labels,
      datasets: newdatasetSuppHealthLGStateMonth
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.COMPARE_QUOTE_COUNTS_CHARTS]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsAllQuoteCountMonth.push(chartData.data);
      this.labelAllQuoteCountMonth.push(chartData.label)
    });
    const newdatasetAllQuotesCountMonth = this.labelAllQuoteCountMonth.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsAllQuoteCountMonth[index];
      newDataobj["backgroundColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructAllQuotesCountMonth = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.COMPARE_QUOTE_COUNTS_CHARTS]?.labels,
      datasets: newdatasetAllQuotesCountMonth
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_BY_FUNDINGTYPE]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsFundingLGMonth.push(chartData.data);
      this.labelFundingLGMonth.push(chartData.label)
    });
    const newdatasetFundingLGMonth = this.labelFundingLGMonth.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsFundingLGMonth[index];
      newDataobj["backgroundColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructFundingLGMonth = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.LG_CHART_BY_MONTH_BY_FUNDINGTYPE]?.labels,
      datasets: newdatasetFundingLGMonth
    }
    this.initialChartResponse.chartDataMap[chartHeadingValues.SG_CHART_BY_MONTH_BY_FUNDINGTYPE]?.datasets.sort(this.compare).forEach(chartData => {
      this.datapointsFundingSGMonth.push(chartData.data);
      this.labelFundingSGMonth.push(chartData.label)
    });
    const newdatasetFundingSGMonth = this.labelFundingSGMonth.map((chartLabel, index) => {
      let newDataobj = {};
      newDataobj["label"] = chartLabel;
      newDataobj["data"] = this.datapointsFundingSGMonth[index];
      newDataobj["backgroundColor"] = this.colorMap.has(chartLabel) ? this.colorMap.get(chartLabel): '';
      return newDataobj;
    })
    this.objConstructFundingSGMonth = {
      labels: this.initialChartResponse.chartDataMap[chartHeadingValues.SG_CHART_BY_MONTH_BY_FUNDINGTYPE]?.labels,
      datasets: newdatasetFundingSGMonth
    }
  }

  downloadExcel(chartname: string) {
    let data = this.initialChartResponse.chartDataMap[chartname];
    this.charts.forEach(chartLabels => {
      if (chartLabels.chartName == chartname) {
        this.chartTitleToDownload = chartLabels.chartLabel;
      }
    });
    let obj = {
      'data': {
        'chartTitle': this.chartTitleToDownload,
        'chartName': chartname,
        'chartData': data,
        'filterData':this.filterCriteria
      }
    }
    this.analyticsService.getAPIExcelData(obj, chartname).subscribe(response => {
      if (response.processId != null && response.processId != undefined) {
        this.processId = response.processId;
        this.showProgress = true;
        this.progressPercent = 1;
        this.progressStyle = "progress-bar-warning";
        let source = this.commonService.listenForStream(this.processId);
        this.eventSources.push(source);
        source.addEventListener("DOWNLOAD_CHART_DATA_STATUS_STARTED", (event: any) => {
          this.progressStyle = "";
          let eventData = JSON.parse(event.data);
          this.progressPercent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
          this.progressMessage = eventData.message;
        });
        source.addEventListener('DOWNLOAD_CHART_DATA_STATUS_COMPLETE', (message: any) => {
          source.close();
          let eventData = JSON.parse(message.data);
          this.progressStyle = "progress-bar-success";
          this.progressPercent = 100;
          this.progressMessage = eventData.message;
          let fileExt = '.xlsx';
          CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet") + fileExt;
          let fileName = this.commonService.getExportFilename();
          let contentData = eventData.payload.contentData;
          const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
          setTimeout(() => {
            this.showProgress = false;
          }, this.commonService.getProgressBarTimeOut());
        });
        source.addEventListener('FAILED', (message: any) => {
          source.close();
          let eventData = JSON.parse(message.data);
          console.error("Received event : ", JSON.stringify(message.data));
          this.progressPercent = 90;
          this.progressStyle = "progress-bar-danger";
          this.progressMessage = eventData.message;
        });
        source.addEventListener('error', (message: any) => {
          console.error("Received error event, with ready status :" + source.readyState);
          if (source.readyState == EventSource.CLOSED) {
            this.progressPercent = 90;
            this.progressStyle = "progress-bar-danger";
            this.progressMessage = "Failed to fetch progress because of communication failure";
          }
        });
      }
    }, error => {
      alert("Error in getting response for Download: " + error);
    });
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }
}
