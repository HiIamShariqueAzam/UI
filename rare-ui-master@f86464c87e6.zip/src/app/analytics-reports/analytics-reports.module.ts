import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnalyticsReportsComponent } from './analytics-reports.component';
import { RouterModule } from '@angular/router';
import { ChartModule } from 'primeng/chart';
import { ChartsComponent } from './charts/charts.component';
import { AnalyticsDataloadComponent } from './analytics-dataload/analytics-dataload.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiSelectModule } from 'primeng/multiselect';
import { ChartFilterPopupComponent } from './chart-filter-popup/chart-filter-popup.component';
import { SoldReportComponent } from './report-form/sold-report/sold-report.component';
import { ReportFormComponent } from './report-form/report-form.component';
import { AnalyticsDynamicReportComponent } from './analytics-dynamic-report/analytics-dynamic-report.component';
import { AccordionModule } from 'primeng/accordion';
import { StepsModule } from 'primeng/steps';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
@NgModule({
    declarations: [AnalyticsReportsComponent, ChartsComponent, AnalyticsDataloadComponent, ChartFilterPopupComponent,SoldReportComponent,ReportFormComponent, AnalyticsDynamicReportComponent],
    imports: [
        CommonModule,
        ChartModule,
        FormsModule,
        ReactiveFormsModule,
        MultiSelectModule,
        AccordionModule,
        CardModule,
        StepsModule,
        ButtonModule,
        DatePickerModule,
        SelectModule,
        RouterModule.forChild([
            { path: '', component: AnalyticsReportsComponent, pathMatch: 'full' },
            { path: 'load-data', component: AnalyticsDataloadComponent, pathMatch: 'full' },
            { path: 'sold-report', component: ReportFormComponent , pathMatch: 'full' },
            { path: 'dynamic-report', component: AnalyticsDynamicReportComponent , pathMatch: 'full' }
        ])
    ],
    exports: [ChartFilterPopupComponent]
})
export class AnalyticsReportsModule { }
