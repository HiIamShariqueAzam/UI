export class AnalyticsConstants {
    public static BACKGROUND_COLOR='backgroundColor';
    public static BORDER_COLOR='borderColor';
    public static LINE='line';
    public static BAR='bar';
    public static TEST_QUOTES='testQuotes';
    public static INCLUDE_RISK_SCORE='includeRiskScore';
    public static INCLUDE='include';
 }