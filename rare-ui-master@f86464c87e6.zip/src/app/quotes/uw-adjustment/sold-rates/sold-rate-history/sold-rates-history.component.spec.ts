import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SoldRatesHistoryComponent } from './sold-rates-history.component';

describe('SoldRateHistoryComponent', () => {
  let component: SoldRatesHistoryComponent;
  let fixture: ComponentFixture<SoldRatesHistoryComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SoldRatesHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoldRatesHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
