import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SoldRatesComponent } from './sold-rates.component';

describe('SoldRateComponent', () => {
  let component: SoldRatesComponent;
  let fixture: ComponentFixture<SoldRatesComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SoldRatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoldRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
