import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MultiSelect } from 'primeng/multiselect';
import { ReportsService } from 'src/app/report-generate-management/services/reports.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { RareConstants } from 'src/app/shared/models/rareConstants';
import { SoldRatesForm } from 'src/app/shared/models/soldRate';
import { DateFormatPipe } from 'src/app/shared/pipes/date-format-pipe';
import { AuthenticationService, CommonService, PrintExhibitService } from 'src/app/shared/services';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { NumberUtils } from 'src/app/shared/utils/number-utils';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CommonQuoteService } from '../../services/common-quote.service';
import { SoldConstants } from '../sold-rate/sold-constants';
import { SoldRatesService } from './services/sold-rates.service';
import { SoldRatesConstants } from './sold-rates-constants';
import { AdditionalProductComponent } from './additional-product/additional-product.component';
import { Select } from 'primeng/select';

export class RateInfo {
  'eeRate': number;
  'esRate': number;
  'efRate': number;
  'ecRate': number;
  'ekRate': number;
  'compositeRate': number;
}
@Component({
  selector: 'app-sold-rate',
  templateUrl: './sold-rates.component.html',
  styleUrls: ['./sold-rates.component.css'],
  standalone: false
})
export class SoldRatesComponent implements OnInit, OnDestroy {
      availableLobs: string[] = [];
    private _lastProgramType: string = '';
  /**
   * @param programType
   * @param event The change event from the input
   * @param contractCode The contract code or plan identifier (if needed)
   */
  rateGuaranteeMonths: number | null = null;
  hasPlanLevelInfo: boolean = false;
  groupOptionsMap: { [programType: string]: any[] } = {};
  selectedGroupProgramsToRemove: any[] = [];
  isProgramTypeDisabled: boolean = false;
  showGroupCreditsTable: boolean = true;
  submittedTransitionData: Array<{ programDesc: string, rate: number, rateType: string, unitType?: string, programType?: string }> = [];
  submittedTransitionHistoryData: Array<{
    submittedTimestamp: string,
    groupCreditsAndFunds: Array<{ programDesc: string, rate: number, rateType: string, unitType?: string, programType?: string }>
  }> = [];
  selectedGroupCreditsToRemove: any[] = [];
  private eventSources: EventSource[] = [];
  form: FormGroup;
  public isCollapse = false;
  public isCollapses = false;
  public isCollapsed = false;
  groupCreditsRateTypes: any[] = [];
  originalGroupCreditsRateTypes: any[] = [];
  quotes: any;
  cols: any[];
  rowData: any[];
  rowDataHistory: any[];
  selectedRate: any;
  categoryList: any[] = [];
  flagCategoryChanged;
  soldRateFullResponse;
  map;
  ratingTransID;
  opportunityID;
  quoteHeaderID;
  lob;
  groupName;
  contractEffDate: any;
  responseData;
  checked;
  responseDataHistory;
  displayDialog: boolean;
  empCategory: any[] = [];
  empCategoryHistory: any[] = [];
  nonEmpCategory: any[] = [];
  planName: any[] = [];
  planTypes: any[] = [];
  fundingTypes: any[] = [];
  contractCodes: any[] = [];
  currentContractCodes: any[] = [];
  lobValues: string[] = [];
  formData;
  fundingType;
  empCategoryData;
  empCategoryFactor;
  planNamesBackup;
  contractCodeBackup;
  CCValue: any = CommonConstants.EMPTY_STRING;
  CCCValue: any = CommonConstants.EMPTY_STRING;
  errorValue;
  additionalProgramErrorValue;
  successMessage: any;
  failureMessage: any;
  alertData: any;
  lob_FT: any[];
  isLoading: boolean = true;
  div_visible: boolean = false;
  enablePrintOnSold: boolean = false;
  showSaveAlert: boolean = false;
  showSubmitAlert: boolean = false;
  showErrorAlert: boolean = false;
  disableSubmit: boolean = true;
  onSubmitFlag = false;
  onChangeLob: boolean = true;
  quoteOrigin: string;
  empCatValue;
  lobValue;
  soldRates_form: FormGroup<SoldRatesForm>;
  historyData: any[] = [];
  selectedRatingPlanID: string;
  selectedRatingPlanIDs: string[];
  selectedPlan;
  selectedProducts: any[];
  selectedContractCodes: any[];
  selectedContractCode;
  selectedCurrentContractCode;
  selectedLOB: string = CommonConstants.EMPTY_STRING;
  classCode;
  caseNumber;
  priorCaseNumber;
  caseNumberUpdate;
  selectedPlanType: string = CommonConstants.EMPTY_STRING;
  selectedFundingType: string = CommonConstants.EMPTY_STRING;
  employmentCategory: any[] = [];
  selectedEmpCategory;
  planValue: any = CommonConstants.EMPTY_STRING;
  selectedRowsToRemove: any[] = [];
  dubEmpCats: string = CommonConstants.EMPTY_STRING;
  selectedSoldRatePlan: any = [];
  action: any = 'save';
  contractCodeRemove: any;
  isReadOnlyRole: boolean = false;
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  isRenewalLocalPresent: boolean = false;
  isMedicalRenewalLocalPresent: boolean = false;
  lobAndOppTypeMap = new Map<string, string>();
  submitOptions = [];
  selectedSubmitValue: string[] = [];
  selectedGroupCreditsRateTypes: string = '';
  lobAdded = new Map<string, string>();
  medActiveRemoved = new Map<string, boolean>();
  visActiveRemoved = new Map<string, boolean>();
  denActiveRemoved = new Map<string, boolean>();
  shpActiveRemoved = new Map<string, boolean>();
  mapOfContractCodeAndAdditionalProgram = new Map<String, Object[]>();
  programValues: string[] = [];
  levelType: string[] = [];
  PMPM: number;
  selectedRateType: string;
  selectedUnitType: string;
  rateTypesAdditional: any[] = [];
  availableRateTypes: any[] = [];
  availableUnitTypes: any[] = [];
  isEdit: boolean = false;
  addRateInfo: any;
  planTypesAdditional: any[] = [];
  selectedProgramType: string = CommonConstants.EMPTY_STRING;
  descriptionReason: string = CommonConstants.EMPTY_STRING;
  selectedPlanTypeAdditional;
  isIncludeInRates: boolean = false;
  includeInRates: string;
  state: string = '';
  factorEffectiveDate: string;
  quoteEffectiveDate: string;
  rateEffDate: Date | string;
  displayProgramDialog: boolean = false;
  rateGuarMonths: Date | string;
  displayProgramDialogUpdate: boolean = false;
  updateRateEffDateOnEdit: any;
  rateInfo: { key: string; value: string }[] = [
    { key: 'Employee', value: 'eeRate' },
    { key: 'Employee+Spouse', value: 'esRate' },
    { key: 'Employee+Child', value: 'ekRate' },
    { key: 'Employee+Children', value: 'ecRate' },
    { key: 'Employee+Family', value: 'efRate' }
  ];
  soldRateFullResponseModified;
  showAdditionalProgramsPopUp: boolean = false;
  selectedAdditionalProgramEmpCategory: any[] = [];
  additionalProgramEmpCategoryList: any[] = [];
  mapOfContractCodeAndSelectedEmpCategories = new Map<String, String[]>();
  isCurrentPlanMapped: boolean = false;
  selectedRatingPlanIdUpdate: string;
  isCaseNoSaved: boolean = false;
  savedCaseNumber = CommonConstants.EMPTY_STRING;
  isEnrollmentMismatch: boolean = false;
  isEnrollmentTotalMismatch: boolean = false;
  currentPlansArray = [];
  selectedGroupFundsToRemove: any[] = [];
  outputTier: number;
  enrollmentValidationErrors: { [key: string]: boolean } = {};
  enrollmentColumnTotals: { [key: string]: number } = {};
  subsequentSoldRequestsExist: boolean = false;
  showSubmitButtonAfterActionSubmit: boolean = false;
  displayAddProductDialog: boolean = false;
  lobValuesForAddProduct: string[] = ['Vision', 'Dental'];
  rateTypeOptions: string[] = [];
  unitTypeOptions: Array<{unitType: string, dfltInd: string}> = [];
  savedRateTypeForUpdate: string = 'Tiered';
  savedUnitTypeForUpdate: string = 'PCPM';
  selectedLOBForAddProduct: string = CommonConstants.EMPTY_STRING;
  additionalProductData: any;
  caseNumberForAddProduct: string;
  AddOptions: string[] = ['Add Plan', 'Add Additional Product'];
  displayDialogUpdateForAddProduct: boolean = false;
  productNameUpdate: string = CommonConstants.EMPTY_STRING;
  soldContractCodeUpdate: string = CommonConstants.EMPTY_STRING;
  classCodeUpdate: string = CommonConstants.EMPTY_STRING;
  additionalCategoryList: any[] = [];
  additionalProductDataObj:any[] = [];
  isAdditionalProductDataAdded: boolean = false;
  formDataUpdateForAddProduct: any;
  showAddlProductTab: boolean = false;
  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  @ViewChild('dropdownRef') select: Select;
  @ViewChild(AdditionalProductComponent) private AdditionalProductComponent!: AdditionalProductComponent;
  activeTab: any = 1;
  isAcceptedOrRejected: boolean = false;
  addToMedicalForHRAHSA: boolean = false;
  addlproductemptyObj: any;
  renewalASIsSoldEnabled: boolean = false;
  AddAsIsOptions: string[] = [];
  showRateEffDate: boolean = true;
  rateEffDateUpdate: any;
  contractEffDateUpdate: any;
  rateGuarMonthsUpdate: any;
  updatedContractEffDatesByLOB: { [key: string]: string } = {};
  selectedOriginalLOB: string;
  myForm: FormGroup;

    constructor(
    private dateFormatPipe: DateFormatPipe,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private _decimalPipe: DecimalPipe,
    public datepipe: DatePipe,
    private authService: AuthenticationService,
    private soldRatesService: SoldRatesService,
    private commonService: CommonService,
    private peService: PrintExhibitService,
    private commonQuoteService: CommonQuoteService,
    private reportsService: ReportsService
  ) {}

  onNavigateTab(data: string) {
    let tabData = data.split('-');
    if (tabData[0] === RareConstants.medical) {
      this.lob = tabData[0];
      this.fundingType = this.commonService.getFundingTypeforTab(tabData[0], tabData[1]);
      this.backToMedical(tabData);
    }
    if (tabData[0] === RareConstants.vision) {
      this.lob = tabData[0];
      this.fundingType = tabData[1];
      this.backToVision();
    }
    if (tabData[0] === RareConstants.dental) {
      this.lob = tabData[0];
      this.fundingType = tabData[1];
      this.backToDental();
    }
    if (StringUtils.isEqualIgnoreCase(tabData[0], CommonConstants.SuppHealth)) {
      this.lob = tabData[0];
      this.fundingType = tabData[1];
      this.backToSuppHealth();
    }
  }

  backToMedical(tabData) {
    this.router.navigate(['quote/uw-rate'], {
      queryParams: {
        ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
        opportunityID: this.opportunityID,
        quoteHeaderID: this.quoteHeaderID,
        lob: this.lob,
        groupName: this.groupName,
        fundingType: this.fundingType,
        availableTabs: this.lob_FT,
        quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1])
      }
    });
  }

  backToVision() {
    if (this.commonService.isVisionEnabled == 'true') {
      this.router.navigate(['quote/uw-rate-vision'], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(this.lob, this.fundingType),
          opportunityID: this.opportunityID,
          quoteHeaderID: this.quoteHeaderID,
          lob: this.lob,
          groupName: this.groupName,
          fundingType: this.fundingType,
          availableTabs: this.lob_FT,
          quoteOrigin: this.quoteOrigin
        }
      });
    }
  }

  onlyHasGroupCreditsAndFunds(rowData: any): boolean {
    if (!rowData.additionalPrograms || rowData.additionalPrograms.length === 0) {
      return false;
    }
  }

  openGroupCreditsEditDialog(item: any) {
    this.displayProgramDialogUpdate = true;
    if (item && (Array.isArray(this.levelType) && this.levelType.includes('Group'))) {
      this.selectedProgramType = item.programType;
    } else {
      this.selectedProgramType = '';
    }
    this.updateGroupCreditsRateTypes();
    if (item && item.programDesc) {
      this.selectedGroupCreditsRateTypes = item.programDesc;
      // Find the selected option for programDesc
      const selectedOption = this.groupCreditsRateTypes.find(opt => opt.value === item.programDesc);
      this.availableRateTypes = (selectedOption?.rateTypes || []).map(rt => ({ label: rt, value: rt }));
      this.availableUnitTypes = (selectedOption?.unitTypes || []).map(ut => {
        if (typeof ut === 'object' && ut.unitType) {
          return { label: ut.unitType, value: ut.unitType, dfltindc: ut.dfltindc };
        } else {
          // fallback for old API
          return { label: ut, value: ut };
        }
      });
      if (item.rateType && this.availableRateTypes.length > 0) {
        const match = this.availableRateTypes.find(rt => rt.value.toLowerCase() === item.rateType.toLowerCase());
        this.selectedRateType = match ? match.value : this.availableRateTypes[0].value;
      } else {
        this.selectedRateType = this.availableRateTypes.length > 0 ? this.availableRateTypes[0].value : '';
      }
      if (item.unitType && this.availableUnitTypes.length > 0) {
        const matchUnit = this.availableUnitTypes.find(ut => ut.value.toLowerCase() === item.unitType.toLowerCase());
        this.selectedUnitType = matchUnit ? matchUnit.value : this.availableUnitTypes[0].value;
      } else {
        this.selectedUnitType = this.availableUnitTypes.length > 0 ? this.availableUnitTypes[0].value : '';
      }
      if (selectedOption) {
        selectedOption.rate = item.rate;
      }
    } else {
      this.selectedGroupCreditsRateTypes = '';
      this.selectedRateType = '';
      this.selectedUnitType = '';
    }
  }

   // Helper for template: check if option is selected (for multi/single select)
  isProgramDescSelected(optionValue: string): boolean {
    if (Array.isArray(this.selectedGroupCreditsRateTypes)) {
      return this.selectedGroupCreditsRateTypes.includes(optionValue);
    }
    return this.selectedGroupCreditsRateTypes === optionValue;
  }

  UpdateAdditionalProgram() {
    if (Array.isArray(this.levelType) && this.levelType.includes('Group')) {
      if (!this.selectedGroupCreditsRateTypes) {
        this.additionalProgramErrorFlag = true;
        this.additionalProgramErrorValue = 'Please Enter Program Desc Value';
        return;
      }
      const programDesc = this.selectedGroupCreditsRateTypes;
      const found = this.groupCreditsRateTypes.find(rt => rt.value === programDesc);
      const idx = this.submittedTransitionData.findIndex(row => row.programDesc === programDesc);
      if (idx !== -1) {
        this.submittedTransitionData[idx].rate = found?.rate || 0;
        this.submittedTransitionData[idx].rateType = this.selectedRateType;
        this.submittedTransitionData[idx].unitType = this.selectedUnitType;
      } else {
        this.submittedTransitionData.push({ programDesc, rate: found?.rate || 0, rateType: this.selectedRateType, unitType: this.selectedUnitType, programType: this.selectedProgramType });
      }
      this.showSaveAlert = true;
      this.displayProgramDialogUpdate = false;
      this.alertData = 'BuyUps/Credits Updated Successfully';
      this.successMessage = true;
      this.formResetProgram();
      return;
    }
  }

  backToDental() {
    this.router.navigate(['quote/uw-rate-dental'], {
      queryParams: {
        ratingTransID: this.commonService.getTransIDforTab(this.lob, this.fundingType),
        opportunityID: this.opportunityID,
        quoteHeaderID: this.quoteHeaderID,
        lob: this.lob,
        groupName: this.groupName,
        fundingType: this.fundingType,
        availableTabs: this.lob_FT,
        quoteOrigin: this.quoteOrigin
      }
    });
  }

  backToSuppHealth() {
    this.router.navigate(['quote/uw-rate-supplemental-health'], {
      queryParams: {
        ratingTransID: this.commonService.getTransIDforTab(this.lob, this.fundingType),
        opportunityID: this.opportunityID,
        quoteHeaderID: this.quoteHeaderID,
        lob: this.lob,
        groupName: this.groupName,
        fundingType: this.fundingType,
        availableTabs: this.lob_FT,
        quoteOrigin: this.quoteOrigin
      }
    });
  }

  ngOnInit() {
    this.updateHasPlanLevelInfo();
    this.renewalASIsSoldEnabled = this.commonService.getRenewalSoldAsIsEnabled();
    this.authService.userRoleTextToDisplay.subscribe((data) => {
      if (data.includes('Read Only')) {
        this.isReadOnlyRole = true;
      }
    });
    this.route.queryParams.subscribe((params) => {
      this.ratingTransID = params['ratingTransID'];
      this.opportunityID = params['opportunityID'];
      this.quoteHeaderID = params['quoteHeaderID'];
      this.lob = params['lob'];
      this.groupName = params['groupName'];
      this.fundingType = params['fundingType'];
      this.lob_FT = params['availableTabs'];
      this.state = params['state'];
      this.factorEffectiveDate = params['factorEffectiveDate'];
      this.quoteOrigin = params['quoteOrigin'];
    });
    // Set hasPlanLevelInfo on init
    this.hasPlanLevelInfo = Array.isArray(this.rowData) && this.rowData.length > 0 && Array.isArray(this.cols) && this.cols.length > 0;

    this.soldRates_form = this.fb.group({
      caseNumber: ['', [Validators.required]],
      caseNumberUpdate: ['', [Validators.required]],
      classValue: ['', [Validators.required]],
      ccCodeOverride: ['', [Validators.required]],
      classValueUpdate: ['', [Validators.required]],
      ccCodeOverrideUpdate: ['', [Validators.required]],
      ccValue: ['', [Validators.required]],
      cccValue: ['', [Validators.required]],
      includeInRates: ['']
    });
    this.enablePrintOnSold = false;
    this.loadSoldRates();
    this.flagCategoryChanged = 0;
    this.commonService.setOpportunityId(this.opportunityID);
    this.commonService.setquoteHeaderId(this.quoteHeaderID);
    this.commonService.setRatingTransID(this.ratingTransID);

    sessionStorage.setItem('addedAdditionalPrograms', '');
  }

  updateHasPlanLevelInfo(): void {
    this.hasPlanLevelInfo = Array.isArray(this.rowData) && this.rowData.length > 0 && Array.isArray(this.cols) && this.cols.length > 0;
  }

  hasCompositeRate(empCat: any): boolean {
    return empCat?.tierRate?.compositeRate != null && empCat?.tierRate?.compositeRate !== undefined;
  }

  getRateValue(empCat: any, field: string): any {
    if (!empCat?.tierRate) {
      return null;
    }
    return empCat.tierRate[field];
  }

  getCompositeRate(empCat: any): number | null {
    return empCat?.tierRate?.compositeRate || null;
  }

  get filteredProgramValues(): string[] {
    // Count plan-level rows for Medical and non-Medical
    const hasMedicalPlanLevel = Array.isArray(this.rowData) && this.rowData.some(plan => plan.lob && StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical) && plan.employmentCategory && plan.employmentCategory.length > 0 && !plan.isAdditionalProduct);
    const hasOtherLobPlanLevel = Array.isArray(this.rowData) && this.rowData.some(plan => plan.lob && !StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical) && plan.employmentCategory && plan.employmentCategory.length > 0 && !plan.isAdditionalProduct);

    // If both Medical and other LOB plan-level rows exist, show all program types
    if (hasMedicalPlanLevel && hasOtherLobPlanLevel) {
      return this.programValues;
    }
    // If only non-Medical plan-level rows exist, show only group-level program types
    if (!hasMedicalPlanLevel && hasOtherLobPlanLevel) {
      return this.programValues.filter(p => this.isGroupLevelProgramType(p));
    }
    // If only Medical plan-level rows exist, show all program types
    if (hasMedicalPlanLevel) {
      return this.programValues;
    }
    // If no plan-level rows exist, show only group-level program types
    return this.programValues.filter(p => this.isGroupLevelProgramType(p));
  }

  isTabDisabled(tabName: string) {
    return this.commonQuoteService.shouldDisableTab(tabName);
  }

  private groupCreditsJustSubmitted = false;
  loadSoldRates(skipGroupCreditsReload: boolean = false) {
    this.soldRateFullResponse = [];
    this.selectedSoldRatePlan = [];
    this.responseData = [];
    this.responseDataHistory = [];
    this.historyData = [];
    this.empCategory = [];
    this.showAdditionalProgramsPopUp = false;
    this.selectedAdditionalProgramEmpCategory = [];
    this.additionalProgramEmpCategoryList = [];
    if (this.ratingTransID) {
      this.soldRatesService.getSoldRatesHistoryGrid(this.opportunityID, this.quoteHeaderID, this.fundingType).subscribe((responseHistory) => {
        if (responseHistory && responseHistory.length > 0) {
          this.populateSoldRatesHistory(responseHistory);
          this.isCaseNoSaved = true;
          this.savedCaseNumber = responseHistory[0].caseNumber;
          this.responseDataHistory = responseHistory;
          this.enablePrintOnSold = !this.soldHistoryHasOnlySuppHealthPlans();
          for (let resp of responseHistory) {
            if (resp.submittedTimestamp && resp.submittedTimestamp != null) {
              resp.submittedTimestamp = this.dateFormatPipe.transform(resp.submittedTimestamp, 'MM/dd/yyyy hh:mm a');
            }
            resp.plan.forEach((plan) => {
              if (StringUtils.isEqual(plan.lob, RareConstants.suppHealth) && plan.ageBandTierRates) {
                plan.employmentCategory.forEach((ageBandsEmploymentCategory, index) => {
                  const rateInfo = {
                    eeRate: plan.ageBandTierRates[index].eeRate,
                    esRate: plan.ageBandTierRates[index].esRate,
                    efRate: plan.ageBandTierRates[index].efRate,
                    ecRate: plan.ageBandTierRates[index].ecRate,
                    ekRate: plan.ageBandTierRates[index].ekRate
                  };
                  ageBandsEmploymentCategory.rateInfo = rateInfo;
                  ageBandsEmploymentCategory.ageBand = `${plan.ageBandTierRates[index].ageBandStart}-${plan.ageBandTierRates[index].ageBandEnd}`;
                });
              }
            });
            this.historyData.push(resp.plan);
          }
          this.submittedTransitionHistoryData = [];
          responseHistory.forEach(historyItem => {
            if (historyItem.groupCreditsAndFunds && historyItem.groupCreditsAndFunds.rateSplits) {
              let submissionArray = [];
              historyItem.groupCreditsAndFunds.rateSplits.forEach(split => {
                if (Array.isArray(split.rateTypes)) {
                  split.rateTypes.forEach(rt => {
                    let unitType = split.unitType;
                    if (!unitType) {
                      let foundOption = (this.groupOptionsMap[split.programType] || []).find(opt => opt.value === rt.programDesc);
                      if (foundOption && Array.isArray(foundOption.unitTypes) && foundOption.unitTypes.length > 0) {
                        unitType = foundOption.unitTypes[0];
                      } else {
                        unitType = 'Flat Dollar';
                      }
                    }
                    submissionArray.push({
                      programDesc: rt.programDesc,
                      rate: rt?.rate || 0,
                      rateType: split.rateType,
                      unitType: unitType,
                      programType: split.programType || this.selectedProgramType
                    });
                  });
                }
              });
              if (submissionArray.length > 0) {
                this.submittedTransitionHistoryData.push({
                  submittedTimestamp: historyItem.submittedTimestamp,
                  groupCreditsAndFunds: submissionArray
                });
              }
            }
          });
        }
      });

      this.soldRateFullResponse = this.soldRatesService.getSoldRatesGrid(this.opportunityID, this.quoteHeaderID, this.fundingType).subscribe((response) => {
        this.isLoading = false;
        this.soldRateFullResponse = response;
        this.enabledAsIsSoldForRenewalPlans(this.soldRateFullResponse);
        this.showAddlProductTab = response?.data?.soldAddlProductLobs?.length > 0;
        this.lobValuesForAddProduct = response?.data?.soldAddlProductLobs || this.lobValuesForAddProduct;
        
        if (response?.additionalProducts) {
          this.rateTypeOptions = response.additionalProducts.rateTypes;
          this.unitTypeOptions = response.additionalProducts.unitTypes;
        }
        
        // Extract LOBs from responseDataQuotes and store in a variable
        if (Array.isArray(response.data.quotes)) {
          this.availableLobs = response.data.quotes.map(q => q.lob).filter((lob, idx, arr) => arr.indexOf(lob) === idx);
        } else {
          this.availableLobs = [];
        }

        this.checkSubsequentSoldRequestsExist(response.data.quotes);
        if (
          !skipGroupCreditsReload &&
          !this.groupCreditsJustSubmitted &&
          response.data.groupCreditsAndFunds &&
          response.data.groupCreditsAndFunds.rateSplits
        ) {
          // Only push if submittedTimestamp is null or undefined
          const submittedTimestamp = response.data.groupCreditsAndFunds.submittedTimestamp;
          if (submittedTimestamp === null || submittedTimestamp === undefined) {
            this.submittedTransitionData = [];
            response.data.groupCreditsAndFunds.rateSplits.forEach(split => {
              if (Array.isArray(split.rateTypes)) {
                split.rateTypes.forEach(rt => {
                  // Try to get unitType from API, else fallback to first available for this programDesc, else 'Flat Dollar'
                  let unitType = split.unitType;
                  if (!unitType) {
                    let foundOption = (this.groupOptionsMap[split.programType] || []).find(opt => opt.value === rt.programDesc);
                    if (foundOption && Array.isArray(foundOption.unitTypes) && foundOption.unitTypes.length > 0) {
                      unitType = foundOption.unitTypes[0];
                    } else {
                      unitType = 'Flat Dollar';
                    }
                  }
                  this.submittedTransitionData.push({
                    programDesc: rt.programDesc,
                    rate: rt?.rate || 0,
                    rateType: split.rateType,
                    unitType: unitType,
                    programType: split.programType || this.selectedProgramType,
                  });
                });
              }
            });
          }
        }
        // Restructure Modified: the two lines below have been introduced
        response.sfOpportunityType = this.getOpportunityType(response.data);
        response.quotedSubscribers = this.getQuotedSubscribers(response.data);
        this.outputTier = this.getOutputTier(response.data);
        
        this.isRenewalLocalPresent = this.isRenewalLocalPresentInSFOpportunityType(response);
        this.isMedicalRenewalLocalPresent = this.checkOppTypeForLOBInSFOpportunityType(response, CommonConstants.Medical, CommonConstants.RENEWAL_LOCAL);
        if (this.isRenewalLocalPresent) {
          this.cols = this.isMedicalRenewalLocalPresent ? SoldRatesConstants.RENEWAL_COLS : SoldRatesConstants.NEWBUSINESS_COLS;
          //V2 Modified: FIX FOR current plans. Get from quotes
          this.soldRateFullResponse.currentPlans = this.getCurrentPlansInQuote(this.soldRateFullResponse);
          if (this.currentContractCodes.length == 0 && this.soldRateFullResponse?.currentPlans && this.soldRateFullResponse?.currentPlans?.length > 0) {
            this.soldRateFullResponse.currentPlans.forEach((fullResponseCurrentPlans) => {
              this.currentPlansArray.push(fullResponseCurrentPlans.id);
              this.currentContractCodes.push({
                label: fullResponseCurrentPlans.planName,
                value: fullResponseCurrentPlans.contractCode
              });
            });
          }
        } else {
          this.cols = SoldRatesConstants.NEWBUSINESS_COLS;
        }
        // Restructure Modified: this below has changed from response.plan to response.data
        this.responseData = this.iterateThroughQuotes(response.data);
        this.soldRateFullResponse.mappedMedTierLivesMap = this.populateMedicalTierLivesMap(response.data);
        if (this.isRenewalLocalPresent) {
          this.responseData.forEach((plan) => {
            if ((!StringUtils.isEqual(plan.status, 'Pre-Sold') || !StringUtils.isEqual(plan.status, 'Sold-Pending UW Review') || !StringUtils.isEqual(plan.status, 'Sold Modified'))
                  && StringUtils.isUndefined(plan?.currentContractCode)) {
              delete plan?.currentContractCode;
            }
          });
          let initialEnrollments;
          let mappedCurrentPlansArray = [];
          let portfolioSoldNotifcationPlans = this.responseData.filter((responseDataPlans) =>
            this.checkSoldConditions(responseDataPlans, CommonConstants.PORTFOLIO_PLAN_TYPE)
          );
          for (let plan of this.responseData) {
            if (this.checkSoldConditions(plan, CommonConstants.FEATURE_PLAN_TYPE)) {
              if (plan.currPlanIds.length == 1) {
                mappedCurrentPlansArray.push(plan.currPlanIds[0]);
                this.soldRateFullResponse?.currentPlans?.forEach((fullResponseCurrentPlans) => {
                  if (StringUtils.isEqual(plan.currPlanIds[0], fullResponseCurrentPlans.id)) {
                    plan.currentContractCode = fullResponseCurrentPlans.contractCode;
                    initialEnrollments = this.soldRateFullResponse.mappedMedTierLivesMap[fullResponseCurrentPlans.contractCode];
                  }
                });
                this.assignEnrollments(plan, initialEnrollments);
              }
            }
          }
          if (portfolioSoldNotifcationPlans.length == 1) {
            let uniqueCurrentPlan = this.currentPlansArray.filter((currentPlansArrayList) => !mappedCurrentPlansArray.includes(currentPlansArrayList));
            if (uniqueCurrentPlan.length == 1) {
              for (let plan of this.responseData) {
                if (this.checkSoldConditions(plan, CommonConstants.PORTFOLIO_PLAN_TYPE)) {
                  plan.currentContractCode = this.soldRateFullResponse.currentPlans.filter((currentPlan) =>
                    StringUtils.isEqual(currentPlan.id, uniqueCurrentPlan.toString())
                  )[0].contractCode;
                  initialEnrollments = this.soldRateFullResponse.mappedMedTierLivesMap[plan.currentContractCode];
                  this.assignEnrollments(plan, initialEnrollments);
                }
              }
            }
          }
        }
        if (this.responseData) {
          this.responseData = this.responseData.sort(function (plan1, plan2) {
            return plan1.quotedContractCode > plan2.quotedContractCode ? 1 : plan1.quotedContractCode < plan2.quotedContractCode ? -1 : 0;
          });
        }
        //The tierRate at this time is the quotedTierRates from QLI and this will change
        //whenever there are additionalProgram additions/inclusions
        //quotedTierRate is created as new attribute to store these original/quoted values
        //and will be used when the plan is added again.
        for (let plan of this.responseData) {
          plan['quotedTierRates'] = plan.tierRate;
        }

        // V2 Modified: fix the contract date in the new structure
        // let ctrctDate = new Date(this.getEffectiveDate(response.data));
        const effDateValue = this.getEffectiveDate(response.data);
        const contractEffDateRaw = effDateValue ? effDateValue : this.getContractEffectiveDate(response.data);
        // Convert yyyy-MM-dd to MM-dd-yyyy format for UI display
        const contractEffDateFormatted = this.convertYYYYMMDDtoMMDDYYYY(contractEffDateRaw);
        this.contractEffDate = this.parseMMDDYYYYtoDate(contractEffDateFormatted.replace(/-/g, '/'));
        if (response.data.caseNumber) {
          this.soldRates_form.controls.caseNumber.setValue(response.data.caseNumber);
          this.caseNumber = response.data.caseNumber;
        }
        if (response.data.priorCaseNumber) {
          this.priorCaseNumber = response.data.priorCaseNumber;
        }
        this.submitOptions = [];
        this.lobAdded = new Map<string, string>();
        this.planTypesAdditional = [];
        for (let plan of this.responseData) {
          if ((plan.status === 'Pre-Sold' || plan.status === 'Sold-Pending UW Review' || plan.status === 'Sold Modified') && plan.employmentCategory) {
            for (let {} of plan.employmentCategory) {
              this.lobAdded.set(plan.contractCode, plan.lob);
            }
            if (!this.submitOptions.find((x) => x === plan.lob)) {
              this.submitOptions.push(plan.lob);
            }
            plan.employmentCategory = plan.employmentCategory.sort(function (a, b) {
              return a.emplymntCtgryCd > b.emplymntCtgryCd ? 1 : a.emplymntCtgryCd < b.emplymntCtgryCd ? -1 : 0;
            });
            this.isCaseNoSaved = true;
            this.savedCaseNumber = plan.caseNumber;
            this.empCategory.push(plan);
            this.updateHasPlanLevelInfo();
            if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical)) {
              this.showAdditionalProgramsPopUp = true;
              this.getIncludeInRates(plan.fundingType);
              this.planTypesAdditional.push({
                label: plan.contractCodePlanName,
                value: plan.contractCodePlanName
              });
            } else if (!plan.isAdditionalProduct) {
              let index = 0;
              const planAgeBands = plan.ageBandTierRates?.sort((a, b) => a.ageBandStart - b.ageBandStart) ?? [];
              // Adding this for sold notification for Supp Health
              if (plan.ageBandTierRates && plan['employmentCategory'] && plan['employmentCategory'].length == 1) {
                let count = 0;
                plan.ageBandTierRates.forEach((ageBand) => {
                  let empCatJson = JSON.parse(JSON.stringify(plan['employmentCategory'][0]));
                  const tierRates = {
                    eeRate: ageBand.eeRate,
                    esRate: ageBand.esRate,
                    efRate: ageBand.efRate,
                    ecRate: ageBand.ecRate,
                    ekRate: ageBand.ekRate
                  };
                  empCatJson.tierRate = tierRates;
                  if (count > 0) {
                    plan['employmentCategory'].push(empCatJson);
                  }
                  count++;
                });
              }
              for (let employmentCategory of plan['employmentCategory']) {
                let employmentCategoryFactor = this.getFactor(plan.lob, employmentCategory.emplymntCtgryCd);
                employmentCategory['tierRate'] = {};
                if (plan.tierRate) {
                  employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(plan.tierRate.eeRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(plan.tierRate.esRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(plan.tierRate.efRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(plan.tierRate.ecRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(plan.tierRate.ekRate) * Number(employmentCategoryFactor));
                  // Add composite rate if present (don't multiply by factor since it's a single rate)
                  if (plan.tierRate.compositeRate !== undefined && plan.tierRate.compositeRate !== null) {
                    employmentCategory.tierRate.compositeRate = this.roundValueToTwoDecimals(Number(plan.tierRate.compositeRate));
                  }
                  index = 0;
                } else {
                  const ageBandTierRates = planAgeBands[index];
                  if(ageBandTierRates) {
                  employmentCategory.ageBand = `${ageBandTierRates.ageBandStart}-${ageBandTierRates.ageBandEnd}`;
                  employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.eeRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.esRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.efRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.ecRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.ekRate) * Number(employmentCategoryFactor));
                  index = index + 1;
                  }
                  if (index == planAgeBands.length) {
                    index = 0;
                  }
                }
              }
            }
          } else {
            this.nonEmpCategory.push(plan);
            if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical)) {
              this.mapOfContractCodeAndSelectedEmpCategories = new Map<String, String[]>();
            }
            if (plan.contractCode) plan.contractCode = plan.quotedContractCode;
          }
        }
        ///Restructure Modified: check this.empCategory and this.empCategoryHistory data population
        this.addRatesFromAdditionalProducts();
        
        this.rowData = this.empCategory;
        this.rowData = this.rowData.filter(plan => plan.employmentCategory.length > 0);
        // Force change detection by creating new array reference
        this.rowData = [...this.rowData];
        this.submitOptions = this.submitOptions.filter(lob =>
          this.rowData.some(row => row.lob === lob)
        );
        this.updateHasPlanLevelInfo();
        this.rowDataHistory = this.empCategoryHistory;
        this.disableSubmitButton();
        if (this.showSaveAlert || this.showSubmitAlert) {
          this.div_visible = false;
          this.successMessage = true;
          if (!this.isAcceptedOrRejected) {
          this.alertData = this.showSaveAlert ? 'Sold updates saved' : 'Click print to generate sold rate sheet';
          }
          if (!this.isAcceptedOrRejected && this.showSubmitAlert) this.generateReport('submit');
          this.showSubmitAlert = false;
        }
        this.hideAlertMessages();
        if (this.onSubmitFlag) {
          this.callSubmitAfterSave();
        }
        //V2 Modified: get contract date in the new structure - remove commented out line
        this.quoteEffectiveDate = this.getContractEffectiveDate(response.data);
        this.programValues = [];
        this.rateTypesAdditional = [];
        // Find all unique fundingTypes with status 'Released' in responseData
        let releasedFundingTypes: string[] = [];
        if (Array.isArray(this.responseData)) {
          releasedFundingTypes = this.responseData
            .filter(plan => plan.lob && plan.lob.toLowerCase() === 'medical' && plan.status && plan.status.toLowerCase() === 'released' && plan.fundingType)
            .map(plan => plan.fundingType)
            .filter((ft, idx, arr) => arr.indexOf(ft) === idx);
        }
        // If none found, fallback to this.fundingType
        if (releasedFundingTypes.length === 0) {
          releasedFundingTypes = this.fundingType;
        }
        this.soldRatesService.getSoldRatesAdditionalPrograms(this.state, this.factorEffectiveDate, this.quoteEffectiveDate, releasedFundingTypes).subscribe((res) => {
          if (Array.isArray(res)) {
            this.programValues = [];
            this.levelType = [];
            this.rateTypesAdditional = [];
            this.groupCreditsRateTypes = [];
            this.originalGroupCreditsRateTypes = [];
            this.groupOptionsMap = {};
            for (let element of res) {
              if (element.programType) {
                this.programValues.push(element.programType);
              }
              if (element.levelType) {
                this.levelType.push(element.levelType);
              }
              if (element.levelType === 'Group' && Array.isArray(element.programs)) {
                const groupPrograms = element.programs
                  .filter(prog => prog.programDesc)
                  .map(prog => ({
                    label: prog.programDesc,
                    value: prog.programDesc,
                    rate: prog.rate,
                    splitSubType: prog.splitSubType,
                    splitType: prog.splitType,
                    rateTypes: prog.rateTypes || [],
                    unitTypes: prog.unitTypes || []
                  }));
                if (!this.groupOptionsMap[element.programType]) {
                  this.groupOptionsMap[element.programType] = [];
                }
                this.groupOptionsMap[element.programType] = [
                  ...this.groupOptionsMap[element.programType],
                  ...groupPrograms
                ];
              } else if (element.levelType === 'Plan' && Array.isArray(element.programs)) {
                // Collect all unique rateTypes from all plan-level programs
                for (let prog of element.programs) {
                  if (Array.isArray(prog.rateTypes)) {
                    for (let rateType of prog.rateTypes) {
                      if (rateType && !this.rateTypesAdditional.some(rt => rt.value === rateType)) {
                        this.rateTypesAdditional.push({
                          label: rateType,
                          value: rateType
                        });
                      }
                    }
                  }
                }
              }
            }
            // Set initial groupCreditsRateTypes based on selectedProgramType
            this.updateGroupCreditsRateTypes();
          }
        });
        this.addRatesFromIncludedAdditionalPrograms();
      });
    }
  }

  //As part of ALGR-92136 the rateInfo in the QLI always has the original
  //rates i.e. rates without AdditionalPrograms. However, whenever we need
  //to display the rates in UI we will always show them with the additionalProgram rates
  //which are available in the rateSplit nodes of the plan object for the UI response (its not same as QLI)
  //in QLI the rateSplit will be under soldRequest node of QLI
  addRatesFromIncludedAdditionalPrograms() {
    //V2 Modified: changed to get plans in the responseData in the new v2 structure
    var soldPlans = this.responseData;
    if (soldPlans) {
      for (var soldPlan of soldPlans) {
        if (StringUtils.isEqual(soldPlan.lob, 'Medical') && soldPlan['employmentCategory']) {
          for (var employmentCategory of soldPlan['employmentCategory']) {
            var employmentCategoryFactor = this.getFactor('Medical', employmentCategory.emplymntCtgryCd);

            if (!employmentCategoryFactor) {
              employmentCategoryFactor = 1;
            }

            if (!this.mapOfContractCodeAndSelectedEmpCategories.get(soldPlan.contractCode)) {
              this.mapOfContractCodeAndSelectedEmpCategories.set(soldPlan.contractCode, []);
            }
            this.mapOfContractCodeAndSelectedEmpCategories.get(soldPlan.contractCode).push(employmentCategory.emplymntCtgryCd);

            employmentCategory['tierRate'] = {};
            employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.eeRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.esRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.efRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.ecRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.ekRate) * Number(employmentCategoryFactor));
            if (employmentCategory['rateSplits']) {
              for (var rateSplit of employmentCategory['rateSplits']) {
                if (Array.isArray(this.levelType) && this.levelType.includes('Group')) {
                  continue;
                }
                if (StringUtils.isEqualIgnoreCase(rateSplit.splitIncluded, 'yes')) {
                  var rateArray = rateSplit['rates'];
                  employmentCategory.tierRate.eeRate = employmentCategory.tierRate.eeRate + this.getRequiredRatesFromRateArray(rateArray, 'ee');
                  employmentCategory.tierRate.esRate = employmentCategory.tierRate.esRate + this.getRequiredRatesFromRateArray(rateArray, 'es');
                  employmentCategory.tierRate.efRate = employmentCategory.tierRate.efRate + this.getRequiredRatesFromRateArray(rateArray, 'ef');
                  employmentCategory.tierRate.ecRate = employmentCategory.tierRate.ecRate + this.getRequiredRatesFromRateArray(rateArray, 'ec');
                  employmentCategory.tierRate.ekRate = employmentCategory.tierRate.ekRate + this.getRequiredRatesFromRateArray(rateArray, 'ek');
                }
              }
            }
          }
        }
      }
    }
  }

  updateRateEffDate = (rateEffDate, CCValueUpdate, isAdditional?: boolean, isUpdate?: boolean) => {
    // PrimeNG p-datepicker emits event object, use event.value
    const dateValue = rateEffDate && rateEffDate.value ? rateEffDate.value : rateEffDate;
    // Use rowData if available, else fallback to responseData
    const plans = Array.isArray(this.soldRateFullResponse) && this.soldRateFullResponse.length > 0
      ? this.soldRateFullResponse
      : (Array.isArray(this.responseData) ? this.responseData : []);
    if (dateValue && (CCValueUpdate || isAdditional)) {
      if (isAdditional) {
        const planToUpdate = this.responseData.find(p => p.lob === (this.selectedOriginalLOB || this.lob));
        const contractEndDate = planToUpdate?.rateEndDate;
        // Use the latest edited rate effective date if available
        let latestEffDate = rateEffDate;
        if (planToUpdate && latestEffDate && contractEndDate) {
          // planToUpdate.rateEffectiveDate = this.datepipe.transform(latestEffDate, 'MM/dd/yyyy');
          const start = new Date(latestEffDate);
          const end = new Date(contractEndDate);
         let rateGuaranteeMonths: any = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
          this.rateGuarMonths = rateGuaranteeMonths;
          this.rateGuarMonthsUpdate = rateGuaranteeMonths;
        }
      } else {
        plans.filter(plan =>
          plan.contractCode === CCValueUpdate.label || plan.quotedContractCode === CCValueUpdate.label || plan.quotedContractCode === CCValueUpdate || plan.contractCode === CCValueUpdate
        ).forEach(plan => {
          if (plan) {

              let rateEffectiveDate = this.datepipe.transform(dateValue, 'MM/dd/yyyy');
              this.updateRateEffDateOnEdit = rateEffectiveDate;

            if (rateEffectiveDate && plan.rateEndDate) {
              const start = new Date(rateEffectiveDate);
              const end = new Date(plan.rateEndDate);
              if(isUpdate) {
                let rateGuaranteeMonths: any = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
                this.rateGuarMonths = rateGuaranteeMonths;
              } else {
              plan.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
              this.rateGuarMonths = plan.rateGuaranteeMonths;
              }
            }
          }
        });
      }
    }
  }

  updateRateGuaranteeMonths(rateGuarMonths, CCValueUpdate): void {
    // If event is from input[type=number], get value
    const months = rateGuarMonths && rateGuarMonths.value ? rateGuarMonths.value : rateGuarMonths;
    if (months && CCValueUpdate) {
      this.rowData.filter(plan =>
        plan.contractCode === CCValueUpdate.label || plan.quotedContractCode === CCValueUpdate.label
      ).forEach(plan => {
        if (plan && plan.rateEndDate) {
          // Calculate new rateEffDate: rateEndDate - (months - 1) months
          const effDate = new Date(plan.rateEffectiveDate);
          const newEndDate = this.commonQuoteService.calculateRateEndDate(effDate, months);
          plan.rateEndDate = this.datepipe.transform(newEndDate, 'MM/dd/yyyy');
          // plan.rateGuaranteeMonths = months;
        }
      });
    }
  }

  addRatesFromAdditionalProducts() {
    // Update both responseData and empCategory since rowData is populated from empCategory
    var soldPlans = this.empCategory.length > 0 ? this.empCategory : this.responseData;
    if (soldPlans) {
      for (var soldPlan of soldPlans) {
        if (soldPlan['employmentCategory'] && soldPlan['isAdditionalProduct'] === true) {
          for (var employmentCategory of soldPlan['employmentCategory']) {
            if (!employmentCategory['tierRate']) {
              employmentCategory['tierRate'] = {};
            }
            employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate?.eeRate));
            employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate?.esRate));
            employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate?.efRate));
            employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate?.ecRate));
            employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate?.ekRate));
            if (soldPlan.tierRate?.compositeRate !== undefined && soldPlan.tierRate?.compositeRate !== null) {
              employmentCategory.tierRate.compositeRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.compositeRate));
            }
          }
        }
      }
    }
  }

  removeQuotedLOBFormAddProducts(addProductsLobs: string[]) {
    this.lobValuesForAddProduct = addProductsLobs.filter(lob => !this.lobValues.includes(lob));
    this.lobValuesForAddProduct = Array.from(new Set(this.lobValuesForAddProduct));
    let rowDataLength = this.rowData.filter(plan => !plan.isAdditionalProduct && plan.lob === CommonConstants.Medical).length;
    let rowDataLengthWithCategory = this.rowData.filter(plan => !plan.isAdditionalProduct && plan.lob === CommonConstants.Medical && plan.employmentCategory.length > 0).length
    if (this.rowData && this.rowData.length > 0) {
      if (rowDataLength === 0) {
        this.lobValuesForAddProduct = this.lobValuesForAddProduct.filter(lob => lob !== CommonConstants.HSAAdmin && lob !== CommonConstants.HRAAdmin);
      } else if (rowDataLengthWithCategory === 0) {
        this.lobValuesForAddProduct = this.lobValuesForAddProduct.filter(lob => lob !== CommonConstants.HSAAdmin && lob !== CommonConstants.HRAAdmin);
      }
      else {
        if (!this.lobValuesForAddProduct.includes(CommonConstants.HSAAdmin) && addProductsLobs.includes(CommonConstants.HSAAdmin)) {
          this.lobValuesForAddProduct.push(CommonConstants.HSAAdmin);
        }
        if (!this.lobValuesForAddProduct.includes(CommonConstants.HRAAdmin) && addProductsLobs.includes(CommonConstants.HRAAdmin)) {
          this.lobValuesForAddProduct.push(CommonConstants.HRAAdmin);
        }
      }
    }
  }

  roundValueToTwoDecimals(value) {
    return Math.round(+Number(value).toFixed(2) * 100) / 100;
  }

  //rates is an array which has the rates for all tiers
  //we need to iterate and get the rate for the requiredTier
  //and get the rates. If no match is found, return ZERO
  getRequiredRatesFromRateArray(rateArray, tierForWhichRateIsRequired) {
    for (const rate of rateArray) {
      if (StringUtils.isEqualIgnoreCase(rate.tier, tierForWhichRateIsRequired)) {
        return rate.rate;
      }
    }
    return 0;
  }
  soldratesdateformat() {
    this.soldRateFullResponse?.data?.quotes?.forEach(quote => {
      quote?.plans?.forEach(plan => {
        if (plan.rateEffectiveDate) {
          plan.rateEffectiveDate = this.datepipe.transform(plan.rateEffectiveDate, 'MM/dd/yyyy');
        }
      });
    });
  }
  callSubmitAfterSave() {
    this.soldratesdateformat();
    this.onSubmitFlag = false;
    let _SoldRatePlansWithCat = Object.assign({}, this.soldRateFullResponse);

    _SoldRatePlansWithCat.plan = [];
    for (var i = 0; i < this.responseData.length; i++) {
      if (
        this.responseData[i].employmentCategory &&
        this.responseData[i].employmentCategory.length > 0 &&
        this.selectedSubmitValue.includes(this.responseData[i].lob)
      ) {
        _SoldRatePlansWithCat.plan.push(this.responseData[i]);
        const index = this.submitOptions.indexOf(this.responseData[i].lob);
        if (index !== -1) {
          this.submitOptions.splice(index, 1);
        }
      }
    }

    // Convert contract effective date from Date object to yyyy-MM-dd format for API
    const contractEffDateForAPI = this.datepipe.transform(this.contractEffDate, 'MM-dd-yyyy');
    let contractEndDateFormatted = this.convertMMDDYYYYtoYYYYMMDD(contractEffDateForAPI);
    _SoldRatePlansWithCat.effectiveDate = contractEndDateFormatted;
    const rateinfoJson = { data: this.buildSubmitJson(_SoldRatePlansWithCat, true, false) };

    this.removeEmptyPlanQuotes(rateinfoJson);

    if (rateinfoJson.data['plan'].length > 0) {
      this.div_visible = true;
      this.soldRatesService.submitSoldRates(rateinfoJson).subscribe(
        () => {
          this.showSubmitAlert = true;
          this.showSaveAlert = false;
          this.groupCreditsJustSubmitted = true;
          this.loadSoldRates(true); // skip group credits reload so UI clears
          this.removeSubmittedLobs(rateinfoJson);
          this.submittedTransitionData = [];
          
          // Clear stored contract effective dates after submit
          this.updatedContractEffDatesByLOB = {};
        },
        () => {
          this.showErrorAlert = true;
          this.div_visible = false;
          this.alertData = 'Error Encountered, Please contact dl-RARE-IT';
          this.failureMessage = true;
        }
      );
    }
  }

  /**
   * Removes empty plan quotes from the given rateinfoJson object.
   * An empty plan quote is defined as a quote that does not have any plans or all plans have a status other than 'Pre-Sold'.
   * @param rateinfoJson - The rateinfoJson object containing the quotes.
   */
  removeEmptyPlanQuotes(rateinfoJson) {
    let existingQuotes = rateinfoJson['data']['data']['quotes'];
    if (existingQuotes && existingQuotes.length > 0) {
      let nonEmptyPlanQuotes = [];
      for (let quote of existingQuotes) {
        if (quote.plans && quote.plans.length > 0) {
          let preSoldPlansExists = false;
          for (let plan of quote.plans) {
            if (plan.status && plan.status == CommonConstants.PRE_SOLD) {
              preSoldPlansExists = true;
              break;
            }
          }
          if (preSoldPlansExists) {
            nonEmptyPlanQuotes.push(quote);
          }
        }
      }
      rateinfoJson['data']['data']['quotes'] = nonEmptyPlanQuotes;
    }
  }

  //if LOB is submitted successfully then remove that from the submit dropDown
  //and use the submit dropDown values to determine whether to
  //keep submit enabled or disabled
  removeSubmittedLobs(rateinfoJson) {
    for (let plan of rateinfoJson.data['plan']) {
      var lob = plan.lob;
      this.selectedSubmitValue = Array.from(this.selectedSubmitValue);
      const index = this.selectedSubmitValue.indexOf(lob);
      if (index !== -1) {
        this.selectedSubmitValue.splice(index, 1);
      }
    }
  }

  getFactor(lob, category) {
    if (lob.toLowerCase() === RareConstants.medicalLC && this.soldRateFullResponse.employmentCategoryMedical) {
      for (let medFactor of this.soldRateFullResponse.employmentCategoryMedical) {
        if (medFactor.emplymntCtgryCd?.toLowerCase() === category.toLowerCase()) return medFactor.emplymntCtgryFctr;
      }
    }
    if (lob.toLowerCase() === RareConstants.visionLC && this.soldRateFullResponse.employmentCategoryVision) {
      for (let visFactor of this.soldRateFullResponse.employmentCategoryVision) {
        if (visFactor.emplymntCtgryCd?.toLowerCase() === category.toLowerCase()) return visFactor.emplymntCtgryFctr;
      }
    }
    if (lob.toLowerCase() === RareConstants.dentalLC && this.soldRateFullResponse.employmentCategoryDental) {
      for (let denFactor of this.soldRateFullResponse.employmentCategoryDental) {
        if (denFactor.emplymntCtgryCd?.toLowerCase() === category.toLowerCase()) return denFactor.emplymntCtgryFctr;
      }
    }
    if (StringUtils.isEqualIgnoreCase(lob, RareConstants.suppHealth) && this.soldRateFullResponse.employmentCategorySuppHealth) {
      for (let suppHealthFactor of this.soldRateFullResponse.employmentCategorySuppHealth) {
        if (suppHealthFactor.emplymntCtgryCd && StringUtils.isEqualIgnoreCase(suppHealthFactor.emplymntCtgryCd, category))
          return suppHealthFactor.emplymntCtgryFctr;
      }
    }
  }

  removeSuccessMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.alertData = ' ';
    this.showSaveAlert = false;
    this.showErrorAlert = false;
    this.showSubmitAlert = false;
    this.isCurrentPlanMapped = false;
    this.isEnrollmentMismatch = false;
    this.isEnrollmentTotalMismatch = false;
  }

  getPlanNameAndCC(lob, fundType, planType) {
    this.planName = [];
    this.contractCodes = [];
    for (let resp of this.responseData) {
      if (resp.lob === lob && resp.fundingType === fundType && resp.planTypeRequested === planType) {
        this.planName.push({
          quotedContractCode: resp.quotedContractCode,
          contractCode: resp.contractCode ? resp.contractCode : resp.quotedContractCode,
          productName: resp.productName || '',
          ratingPlanID: resp.ratingPlanID
        });
        if (!this.contractCodes.find((x) => x.value === resp.quotedContractCode)) {
          this.contractCodes.push({
            label: resp.quotedContractCode,
            value: resp.quotedContractCode
          });
        }
      }
    }
    if (this.planName.length === 1 && !StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)) {
      this.getRatesByCC(this.contractCodes[0].label);
      this.getRates(this.planName[0].ratingPlanID);
    }
  }

  refreshPlanDropdown() {
    this.planName = [];
    this.contractCodes = [];
    this.planNamesBackup = this.planName;
    for (let resp of this.responseData) {
      this.planName.push({
        quotedContractCode: resp.quotedContractCode,
        contractCode: resp.contractCode,
        productName: resp.productName || ''
      });
      if (!this.contractCodes.find((x) => x.value === resp.quotedContractCode)) {
        this.contractCodes.push({
          label: resp.quotedContractCode,
          value: resp.quotedContractCode
        });
      }
      if (!this.lobValues.find((x) => x === resp.lob) && !resp.isAdditionalProduct) {
        this.lobValues.push(resp.lob);
      }
    }
    this.planNamesBackup = this.planName;
    this.contractCodeBackup = this.contractCodes;

    this.disableSubmitButton();
  }

  refreshData(isAdditional?: boolean, addNewPlanData?: boolean) {
    this.enrollmentValidationErrors = {};
    this.isEnrollmentTotalMismatch = false;
    for (let resp of this.responseData) {
      if (!this.contractCodes?.find((x) => x.value === resp.quotedContractCode)) {
        if (this.contractCodes) {
          this.contractCodes.push({
            label: resp.quotedContractCode,
            value: resp.quotedContractCode
          });
        }
      }
    }
    if (!isAdditional) {
      this.contractCodeBackup = this.contractCodes;
      this.empCategory = [];
      for (let soldPlans of this.responseData) {
        if (!soldPlans.isAdditionalProduct) {
          if (soldPlans.employmentCategory) {
            soldPlans.employmentCategory = soldPlans.employmentCategory.sort(function (a, b) {
              return a.emplymntCtgryCd > b.emplymntCtgryCd ? 1 : a.emplymntCtgryCd < b.emplymntCtgryCd ? -1 : 0;
            });
            if (this.isMedicalRenewalLocalPresent) {
              if (!StringUtils.isUndefined(soldPlans.currentContractCode))
                soldPlans.currentContractCode = soldPlans.currentContractCode ? soldPlans.currentContractCode : this.selectedCurrentContractCode;
            }
            soldPlans['externalSoldQuote'] = false;
            soldPlans['state'] = '';
            // Update rateEffDate for all selected Supp Health plans if multiple are selected
            if (StringUtils.isEqualIgnoreCase(soldPlans.lob, RareConstants.suppHealth) && this.rateEffDate) {
              if (Array.isArray(this.selectedRatingPlanIDs) && this.selectedRatingPlanIDs.length > 0) {
                if (this.selectedRatingPlanIDs.includes(soldPlans.ratingPlanID)) {
                  soldPlans.rateEffectiveDate = this.datepipe.transform(this.rateEffDate, 'MM/dd/yyyy');
                }
              } else if (this.selectedRatingPlanID && soldPlans.ratingPlanID === this.selectedRatingPlanID) {
                soldPlans.rateEffectiveDate = this.datepipe.transform(this.rateEffDate, 'MM/dd/yyyy');
              }
            }
            this.empCategory.push(soldPlans);
            if (this.rowData.length !== this.empCategory.length && this.rowData.filter(plan => plan.isAdditionalProduct).length > 0 && !addNewPlanData) {
              const additionalProducts = this.rowData.filter(plan => plan.isAdditionalProduct);
              this.empCategory.push(...additionalProducts);
            }
          } else {
            this.nonEmpCategory.push(soldPlans);
          }
        }
      }
    }
    if(isAdditional){
      let employmentCategoryObj = this.createEmploymentCategoryObj();
      let rateObj = this.additionalProductData?.rateInfo[0];
      this.getSelectedOriginalLOB(this.soldRateFullResponse);
      delete rateObj.empCategory;
      // Update rateGuaranteeMonths when adding a plan
      const planToUpdate = this.responseData.find(p => p.lob === this.selectedOriginalLOB);
      const contractEndDate = planToUpdate?.rateEndDate;
      // Use the latest edited rate effective date if available
      let latestEffDate = this.additionalProductData.rateEffectiveDate || planToUpdate.rateEffectiveDate;
      if (planToUpdate && latestEffDate && contractEndDate) {
        // planToUpdate.rateEffectiveDate = this.datepipe.transform(latestEffDate, 'MM/dd/yyyy');
        const start = new Date(latestEffDate);
        const end = new Date(contractEndDate);
        // planToUpdate.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
      }
      let obj = {
        // addlProductID: this.generateUUID(),
        caseName: "",
        caseNumber: this.additionalProductData.caseNumber,
        commissionType: "",
        commissionValue: 0,
        contractCode: this.additionalProductData.soldContractCode,
        contractEffDate: this.additionalProductData.contractEffectiveDate,
        currentContractCode: "",
        embeddedDental: 0,
        embeddedVision: 0,
        employmentCategory: employmentCategoryObj,
        fundingType: this.additionalProductData.selectedFundingType,
        lob: this.additionalProductData.selectedLOBForAddProduct,
        network: "",
        planTypeRequested: "",
        priorCaseNumber: undefined,
        productCategoryCode: null,
        productCode: null,
        productName: this.additionalProductData.productName,
        quoteReason: this.responseData.find(p => p.lob === this.selectedOriginalLOB)?.quoteReason || null,
        quoteLineItemID: "",
        quotedContractCode: "",
        quotedTierRates: {
          eeRate: 0,
          esRate: 0,
          efRate: 0,
          ecRate: 0,
          ekRate: 0
        },
        rateEffectiveDate: this.datepipe.transform(this.additionalProductData.rateEffectiveDate, 'MM/dd/yyyy'),
        //rateGuaranteeMonths: planToUpdate?.rateGuaranteeMonths ? planToUpdate?.rateGuaranteeMonths : this.responseData.find(p => p.lob === CommonConstants.Medical)?.rateGuaranteeMonths || '',
        rateGuaranteeMonths: this.additionalProductData.rateGuarMonths,
        rateType: this.additionalProductData.rateType,
        unitType: this.additionalProductData.unitType,
        rateTierFactor: {
          "4-tier": {} // Replace with actual object
        },
        ratingPlanID: this.ratingTransID,
        rxRebateOffSet: 0,
        status: "Pre-Sold",
        isAdditionalProduct: true,
        tierRate: rateObj
      };
      this.additionalCategoryList.push(...this.categoryList.map(category => category.label));
      this.lobAdded.set(this.additionalProductData?.soldContractCode, this.additionalProductData?.selectedLOBForAddProduct);
      this.additionalProductDataObj.push(obj);
      this.empCategory = this.rowData;
      if (!this.empCategory.find(plan => plan.contractCode === obj.contractCode && plan.lob === obj.lob && plan.fundingType === obj.fundingType && plan.productName === obj.productName && plan.employmentCategory?.length === obj.employmentCategory?.length)) {
        this.empCategory.push(obj);
      }
      if (!this.submitOptions.find((x) => x === obj.lob)) {
        this.submitOptions.push(obj.lob);
      }
    }
    this.empCategory = this.empCategory.sort(function (a, b) {
      return a.quotedContractCode > b.quotedContractCode ? 1 : a.quotedContractCode < b.quotedContractCode ? -1 : 0;
    });
    const additionalProducts = this.rowData.filter(
      item => item.isAdditionalProduct && !this.empCategory.includes(item)
    );
    this.empCategory.push(...additionalProducts);
    this.rowData = this.empCategory;
    this.submitOptions = this.submitOptions.filter(lob =>
      this.rowData.some(row => row.lob === lob)
    );
    this.addToMedicalForHRAHSA = this.rowData.filter(plan => StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical)).length > 0;
    this.updateHasPlanLevelInfo();
    this.disableSubmitButton();
  }

  createEmploymentCategoryObj() {
    const CategoryObj: { employmentClassCode: string | undefined; emplymntCtgryCd: string; enrollments: { ee: number; ef: number; ek: number; es: number; ec: number; }; rateInfo: any; wgsSubGroupNumber: string; }[] = []; // Specify the type for the array
    this.selectedEmpCategory?.forEach((category: string) => { // Specify the type for category
      const obj: any = {
        employmentClassCode: this.additionalProductData?.classCode,
        emplymntCtgryCd: category,
        enrollments: { ee: 0, ef: 0, ek: 0, es: 0, ec: 0 },
        tierRate: this.additionalProductData.rateInfo.find(rate => rate.empCategory === category),
        wgsSubGroupNumber: ""
      };
      CategoryObj.push(obj);
    });
    return CategoryObj;
  }

  generateUUID(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  disableSubmitButton() {
    if (this.rowData.length > 0) this.disableSubmit = false;
    else this.disableSubmit = true;
  }

  showDialogToAdd() {
    //when the add button is clicked - clear out all existing fields
    this.resetForm();
    this.formData = null;
    this.enrollmentValidationErrors = {};
    this.isEnrollmentTotalMismatch = false;
    this.displayDialog = true;
    this.soldCCvalue = '';
    this.errorFlag = false;
    this.errorValue = '';
    for (let resp of this.responseData) {
      if (resp.lob === 'Medical') {
        this.showAdditionalProgramsPopUp == true;
        if (resp.planIsRemoved) {
          resp.planIsRemoved = false;
        }
      }
      if (resp.lob === 'Vision' || resp.lob === 'Dental') {
        if (resp.planIsRemoved) {
          resp.planIsRemoved = false;
        }
      }
      if (!this.lobValues.find((x) => x === resp.lob) && !resp.isAdditionalProduct) {
        this.lobValues.push(resp.lob);
      }
    }
    this.removeQuotedLOBFormAddProducts(this.lobValuesForAddProduct)
    this.soldRates_form.controls.ccCodeOverride.setValue('');
  }

  showDialogToAddProduct() {

    this.displayAddProductDialog = true;
    this.formData = null;
    this.soldCCvalue = '';
    this.errorFlag = false;
    this.errorValue = '';
    if (!this.caseNumber) {
      this.caseNumberForAddProduct = this.savedCaseNumber;
    }
    this.selectedLOBForAddProduct = null;
  }

  getLOBForAddProduct = (value) => {
    this.selectedLOBForAddProduct = value;
    this.fundingTypes = [];
    this.selectedPlanType = '';
    this.fundingTypes.push({
      label: 'FI',
      value: 'FI'
    },{
      label: 'ASO',
      value: 'ASO'
    });
    let lob = this.selectedOriginalLOB ? this.selectedOriginalLOB : RareConstants.medical
    this.getRateEffDate(lob, this.selectedFundingType);
     if ((StringUtils.isEqualIgnoreCase(value, RareConstants.vision) || StringUtils.isEqualIgnoreCase(value, RareConstants.dental))) {
      this.getRateGuarMonths(value);
    } else {
      this.getRateGuarMonths(lob);
    }
    if (this.fundingTypes.length === 1) this.getFundingType(this.fundingTypes[0].value);
    this.categoryList = [];
    this.categoryList = CommonUtil.getSortedList(this.getCategoryList(lob, 'A'));
    
    // Check if there's a stored contract effective date for this LOB and use it
    if (this.updatedContractEffDatesByLOB[value]) {
      // Convert stored date from yyyy-MM-dd format to MM-dd-yyyy format for the datepicker
      const storedDate = this.updatedContractEffDatesByLOB[value];
      const uiFormattedDate = this.convertYYYYMMDDtoMMDDYYYY(storedDate);
      this.contractEffDate = this.parseMMDDYYYYtoDate(uiFormattedDate.replace(/-/g, '/'));
    } else {
      // Reset contractEffDate to default value when no stored date exists for this LOB
      const effDateValue = this.getContractEffectiveDateMedical(this.soldRateFullResponse?.data);
      const contractEffDateRaw = effDateValue ? effDateValue : this.getContractEffectiveDate(this.soldRateFullResponse?.data);
      // Convert yyyy-MM-dd to MM-dd-yyyy format for UI display
      const contractEffDateFormatted = this.convertYYYYMMDDtoMMDDYYYY(contractEffDateRaw);
      this.contractEffDate = this.parseMMDDYYYYtoDate(contractEffDateFormatted.replace(/-/g, '/'));
    }
    for (let resp of this.responseData) {
      if (this.selectedFundingType === resp.fundingType) {
        if (resp.caseNumber) {
          this.soldRates_form.controls.caseNumber.setValue(resp.caseNumber);
          this.caseNumber = resp.caseNumber;
        }
        if (resp.priorCaseNumber) {
          this.priorCaseNumber = resp.priorCaseNumber;
        }
      }
    }
    this.addRateInfo = {
      Active: new RateInfo(),
      Cobra: new RateInfo(),
      'Over 65 Retiree': new RateInfo(),
      'Retiree All': new RateInfo(),
      'Under 65 Retiree': new RateInfo()
    };
  }

  getRateEffDate(lob: string, fundingType?: string) {
    if (this.soldRateFullResponse && this.soldRateFullResponse.data && Array.isArray(this.soldRateFullResponse.data.quotes)) {
      const selectedQuote = this.soldRateFullResponse.data.quotes.find(quote => StringUtils.isEqualIgnoreCase(quote.lob, lob) && (!fundingType || StringUtils.isEqualIgnoreCase(quote.fundingType, fundingType)));
      if (selectedQuote && selectedQuote.rateEffectiveDate && typeof selectedQuote.rateEffectiveDate === 'string') {
        this.rateEffDate = this.parseMMDDYYYYtoDate(selectedQuote.rateEffectiveDate);
      }
    }
  }

 getRateGuarMonths(lob: string) {
    if (this.soldRateFullResponse && this.soldRateFullResponse.data && Array.isArray(this.soldRateFullResponse.data.quotes)) {
      let selectedQuote = this.soldRateFullResponse.data.quotes.find(quote => StringUtils.isEqualIgnoreCase(quote.lob, lob));
      
      // If selectedQuote is undefined, check for medical quote or use first quote (index 0)
      if (!selectedQuote) {
        // First try to find medical quote
        selectedQuote = this.soldRateFullResponse?.data?.quotes?.find(quote => StringUtils.isEqualIgnoreCase(quote.lob, RareConstants.medical));
        
        // If no medical quote found, use the first quote (index 0) as fallback
        if (!selectedQuote && this.soldRateFullResponse?.data?.quotes?.length > 0) {
          selectedQuote = this.soldRateFullResponse?.data?.quotes[0];
        }
      }

      if (selectedQuote && selectedQuote.rateGuaranteeMonths && typeof selectedQuote.rateGuaranteeMonths === 'string') {
        this.rateGuarMonths = selectedQuote.rateGuaranteeMonths;
      }

      if ((StringUtils.isEqualIgnoreCase(lob, RareConstants.vision) || StringUtils.isEqualIgnoreCase(lob, RareConstants.dental)) && selectedQuote?.marketSegment === 'SG') {
        this.rateGuarMonths = '24';
      }
    }
  }

  getLOB(value) {
    this.onChangeLob = false;
    setTimeout(() => {
      this.onChangeLob = true;
    });
    this.selectedLOB = value;
    this.selectedOriginalLOB = value;
    this.getRateEffDate(this.selectedLOB, this.selectedFundingType);
    this.getRateGuarMonths(this.selectedLOB);
    this.errorFlag = false;
    this.planTypes = [];
    this.fundingTypes = [];
    this.selectedPlanType = '';
    this.selectedFundingType = '';
    this.planValue = '';
    this.CCValue = '';
    this.CCCValue = '';
    this.empCatValue = '';
    this.selectedPlan = '';
    this.selectedRatingPlanID = '';
    this.formData = null;
    this.selectedProducts = null;
    this.selectedContractCodes = null;
    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && !this.fundingTypes.find((x) => x.value === resp.fundingType)) {
        if (resp.fundingType === 'FI' && (this.checkSoldTableHasFundingType() === 'FI' || !this.checkSoldTableHasFundingType())) {
          this.fundingTypes.push({
            label: 'FI',
            value: 'FI'
          });
        } else if (resp.fundingType === 'ABF' && (this.checkSoldTableHasFundingType() === 'ABF' || !this.checkSoldTableHasFundingType())) {
          this.fundingTypes.push({
            label: 'ABF',
            value: 'ABF'
          });
        }
      }
    }
    if (this.fundingTypes.length === 1) this.getFundingType(this.fundingTypes[0].value);
    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)) {
      this.selectAllProductsForSuppHealth();
    }
    this.caseNumberForAddProduct = this.caseNumber;
  }

  selectAllProductsForSuppHealth() {
    let selectedProducts = [];
    let selectedQuotedContractCodes = [];
    let selectedRatingPlanIDs = [];
    this.responseData.forEach((product) => {
      if (StringUtils.isEqualIgnoreCase(product.lob, RareConstants.suppHealth)) {
        selectedProducts.push({
          quotedContractCode: product.quotedContractCode,
          contractCode: product.contractCode,
          productName: product.productName,
          ratingPlanID: product.ratingPlanID
        });
        selectedRatingPlanIDs.push(product.ratingPlanID);
        const quotedContractCode = product.quotedContractCode;

        let isContractCodeSelected = selectedQuotedContractCodes.some((selectedContractCode) => {
          return selectedContractCode.value === quotedContractCode;
        });

        if (!isContractCodeSelected) {
          selectedQuotedContractCodes.push({
            label: product.quotedContractCode,
            value: product.quotedContractCode
          });
        }
      }
    });
    this.selectedProducts = selectedProducts;
    this.selectedContractCodes = selectedQuotedContractCodes;
    this.selectedRatingPlanIDs = selectedRatingPlanIDs;

    const soldContractCodes: string[] = selectedQuotedContractCodes.map((soldContractCode) => soldContractCode.value);
    const contractCodes = soldContractCodes.join(', ');
    this.soldRates_form.controls.ccCodeOverride.setValue(contractCodes);

    this.categoryList = [];
    this.categoryList = this.getCategoryList(this.selectedLOB, 'A');
  }

  checkSoldTableHasFundingType() {
    let fundType;
    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && resp.employmentCategory && resp.employmentCategory.length > 0) {
        fundType = resp.fundingType;
      }
    }
    return fundType;
  }

  getFundingType = (value) => {
    this.selectedFundingType = value;
    this.getRateEffDate(this.selectedLOB, this.selectedFundingType);
    this.errorFlag = false;
    this.planTypes = [];
    this.selectedPlanType = '';
    this.planValue = '';
    this.CCValue = '';
    this.CCCValue = '';
    if(this.activeTab !== 2){
    this.empCatValue = '';
    }
    this.selectedPlan = '';
    this.selectedRatingPlanID = '';
    this.formData = null;
    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && this.selectedFundingType === resp.fundingType && !this.planTypes.find((x) => x.value === resp.planTypeRequested)) {
        if (resp.planTypeRequested === 'F') {
          this.planTypes.push({
            label: 'Featured Plan',
            value: 'F'
          });
        } else {
          this.planTypes.push({
            label: 'Portfolio Plan',
            value: 'P'
          });
        }
      }
    }

    if (this.planTypes.length === 1) this.getPlanType(this.planTypes[0].value);

    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && this.selectedFundingType === resp.fundingType) {
        if (resp.caseNumber) {
          this.soldRates_form.controls.caseNumber.setValue(resp.caseNumber);
          this.caseNumber = resp.caseNumber;
        }
        if (resp.priorCaseNumber) {
          this.priorCaseNumber = resp.priorCaseNumber;
        }
      }
    }
  }

  shouldHideRateRow(rateValue: string): boolean {
    if (Array.isArray(this.levelType) && this.levelType.includes('Group')) {
      return !this.selectedGroupCreditsRateTypes.includes(rateValue);
    }
    if (!this.selectedRateType) return false;
    if (Array.isArray(this.selectedRateType)) {
      return this.selectedRateType.indexOf(rateValue) === -1;
    }
    return rateValue !== this.selectedRateType;
  }

  getGroupCreditsProgramDescOptions() {
    return this.groupCreditsRateTypes?.map(rt => ({ label: rt.label, value: rt.value })) || [];
  }

  /**
   * Updates the groupCreditsRateTypes array based on the selected program type.
   */
  updateGroupCreditsRateTypes() {
    // Only clear selectedGroupCreditsRateTypes if the program type actually changed
    if (this._lastProgramType !== this.selectedProgramType) {
      this.selectedGroupCreditsRateTypes = '';
      this._lastProgramType = this.selectedProgramType;
    }
    if (this.selectedProgramType && this.groupOptionsMap[this.selectedProgramType]) {
      this.groupCreditsRateTypes = [...this.groupOptionsMap[this.selectedProgramType]];
    } else {
      this.groupCreditsRateTypes = [];
    }


    // Dynamically set available rate types and unit types for dropdowns based on selected program desc
    if (
      Array.isArray(this.levelType) && this.levelType.includes('Group') &&
      typeof this.selectedGroupCreditsRateTypes === 'string' && this.selectedGroupCreditsRateTypes
    ) {
      const selectedOption = this.groupCreditsRateTypes.find(opt => opt.value === this.selectedGroupCreditsRateTypes);
      this.availableRateTypes = (selectedOption?.rateTypes || []).map(rt => ({
        label: rt,
        value: rt
      }));
      this.availableUnitTypes = (selectedOption?.unitTypes || []).map(ut => {
        if (typeof ut === 'object' && ut.unitType) {
          return { label: ut.unitType, value: ut.unitType, dfltindc: ut.dfltindc };
        } else {
          // fallback for old API
          return { label: ut, value: ut };
        }
      });
      // Set default Rate Type to 'Composite' if available, else first available, only if not already set or not in availableRateTypes
      if (this.availableRateTypes.length > 0) {
        const composite = this.availableRateTypes.find(rt => rt.value && rt.value.toLowerCase() === 'composite');
        if (!this.selectedRateType || !this.availableRateTypes.some(rt => rt.value === this.selectedRateType)) {
          this.selectedRateType = composite ? composite.value : this.availableRateTypes[0].value;
        }
      } else {
        this.selectedRateType = '';
      }
      // Default Unit Type to dfltindc === 'Y' if available, otherwise first available
      if (this.availableUnitTypes.length > 0) {
        const defaultUnit = this.availableUnitTypes.find(ut => ut.dfltindc === 'Y');
        this.selectedUnitType = defaultUnit ? defaultUnit.value : this.availableUnitTypes[0].value;
      } else {
        this.selectedUnitType = '';
      }
    } else {
      this.availableRateTypes = [];
      this.availableUnitTypes = [];
      this.selectedRateType = '';
      this.selectedUnitType = '';
    }
  }

  getPlanType(value) {
    this.onChangeLob = false;
    setTimeout(() => {
      this.onChangeLob = true;
    });
    this.selectedPlanType = value;
    this.planValue = '';
    this.CCValue = '';
    this.CCCValue = '';
    this.empCatValue = '';
    this.selectedPlan = '';
    this.selectedRatingPlanID = '';
    this.selectedContractCode = '';
    this.selectedCurrentContractCode = '';
    this.errorFlag = false;
    this.formData = null;
    this.getPlanNameAndCC(this.selectedLOB, this.selectedFundingType, this.selectedPlanType);
  }

  getPlanDataForProduct(map, value): any {
    let objFound = map.find((x) => x.ratingPlanID === value);
    return objFound || {};
  }

  getPlanNameForProduct(map, value): string {
    let objFound = this.getPlanDataForProduct(map, value);
    return objFound.productName || '';
  }

  getCurrentPlan(value) {
    let contractData;
    let currentContractCodes = [];
    contractData = this.responseData.find((responseData) => responseData.ratingPlanID === value);
    if (StringUtils.isEqualIgnoreCase(this.selectedPlanType, 'F')) {
      // V2 Modified: currPlanId has changed to currPlanIds array in V2 response
      contractData.currPlanIds.forEach((currentData) => {
        this.soldRateFullResponse.currentPlans.forEach((fullResponseCurrentPlans) => {
          if (currentData == fullResponseCurrentPlans.id) {
            currentContractCodes.push({
              label: fullResponseCurrentPlans.planName,
              value: fullResponseCurrentPlans.contractCode
            });
          }
        });
      });
    }
    if (currentContractCodes.length == 1) {
      this.CCCValue = {
        label: currentContractCodes[0].label,
        value: currentContractCodes[0].value
      };
      this.selectedCurrentContractCode = currentContractCodes[0].value;
    }
  }

  getRates(value) {
    this.selectedPlan = this.getPlanNameForProduct(this.planName, value);
    this.selectedRatingPlanID = value;
    this.additionalProgramErrorFlag = false;
    this.dataReset();
    this.formData = null;
    this.selectedEmpCategory = null;
    this.empCatValue = '';
    this.lobValue = '';
    let contractData;
    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth) && value) {
      const selectedProducts = value ?? [];
      let soldContractCodes = selectedProducts.map((selectedProduct) => selectedProduct.quotedContractCode);
      soldContractCodes = soldContractCodes.join(', ');
      let selectedQuotedContractCodes = [];
      let selectedRatingPlanIDs = [];
      selectedProducts.forEach((selectedProduct) => {
        let isContractCodeSelected = selectedQuotedContractCodes.some((selectedContractCode) => {
          return selectedContractCode.value === selectedProduct.quotedContractCode;
        });
        selectedRatingPlanIDs.push(selectedProduct['ratingPlanID']);
        if (!isContractCodeSelected) {
          selectedQuotedContractCodes.push({
            label: selectedProduct.quotedContractCode,
            value: selectedProduct.quotedContractCode
          });
        }
      });
      this.selectedContractCodes = selectedQuotedContractCodes;
      this.selectedRatingPlanIDs = selectedRatingPlanIDs;
      this.soldRates_form.controls.ccCodeOverride.setValue(soldContractCodes);
    } else {
      contractData = this.responseData.find((x) => x.ratingPlanID === value);
      this.CCValue = {
        label: contractData.quotedContractCode,
        value: contractData.quotedContractCode
      };
      this.selectedContractCode = contractData.quotedContractCode;
      this.soldRates_form.controls.ccCodeOverride.setValue(contractData.contractCode);
    }
    if (this.isMedicalRenewalLocalPresent && StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.medical)) this.getCurrentPlan(value);
    this.categoryList = [];
    this.categoryList = CommonUtil.getSortedList(this.getCategoryList(this.selectedLOB, 'A'));
  }

  getRatesByCCC(selectedCurrentPlan) {
    this.selectedCurrentContractCode = selectedCurrentPlan.value;
  }

    buildSubmitJson(_SoldRatePlansWithCat, isSubmit?: boolean, isSave?: boolean): any {
    let _rateInfo = Object.assign({}, _SoldRatePlansWithCat);
    let groupCreditsAndFundsMap = {};
    if (_rateInfo['plan'] && Array.isArray(_rateInfo['plan'])) {
      _rateInfo['plan'].forEach((plan) => {
        if (Array.isArray(plan.additionalPrograms)) {
          const keepPrograms = [];
          plan.additionalPrograms.forEach((ap) => {
            if (this.isGroupLevelProgramType && this.isGroupLevelProgramType(ap.programType)) {
              if (!groupCreditsAndFundsMap[ap.programType]) {
                groupCreditsAndFundsMap[ap.programType] = {
                  programType: ap.programType,
                  rateTypes: [],
                  rateType: ap.rateType,
                };
              }
              // Build rateTypes entry
              if (ap.rateTypes && Array.isArray(ap.rateTypes)) {
                ap.rateTypes.forEach(rt => {
                  groupCreditsAndFundsMap[ap.programType].rateTypes.push(rt);
                });
              } else {
                // Fallback: try to build from ap fields
                groupCreditsAndFundsMap[ap.programType].rateTypes.push({
                  programDesc: ap.programDesc || (Array.isArray(ap.contractCodePlanName) ? ap.contractCodePlanName[0] : ''),
                  rate: ap.rate,
                  splitType: ap.splitType,
                  splitSubType: ap.splitSubType
                });
              }
            } else {
              keepPrograms.push(ap);
            }
          });
          plan.additionalPrograms = keepPrograms;
        }
      });
    }
    // --- Continue with employmentCategory logic ---
    _rateInfo['plan'].forEach((plan, index) => {
      const tierRate = plan['tierRate'];
      const asoFeeRate = plan['asoFee'];
      const sslPremiumRate = plan['sslPremium'];
      const aslPremiumRate = plan['aslPremium'];
      const terminalLiabilityRate = plan['terminalLiabilityFund'];
      const maxPaidClaimsRate = plan['maxPaidClaimsFund'];
      const empCategoryInfo = plan['employmentCategory'];
      let empCategoryArray = [] as Array<any>;
      if (empCategoryInfo) {
        empCategoryInfo.forEach((element) => {
          let factor = this.getFactor(plan['lob'], element['emplymntCtgryCd']);
          var rateInfo: RateInfo = this.calculateRate(factor, tierRate);
          var asoFee: RateInfo = this.calculateRate(factor, asoFeeRate);
          var sslPremium: RateInfo = this.calculateRate(factor, sslPremiumRate);
          var aslPremium: RateInfo = this.calculateRate(factor, aslPremiumRate);
          var terminalLiability: RateInfo = this.calculateRate(factor, terminalLiabilityRate);
          var maxPaidClaimsFund: RateInfo = this.calculateRate(factor, maxPaidClaimsRate);
          empCategoryArray.push({
            emplymntCtgryCd: element['emplymntCtgryCd'],
            employmentClassCode: element['employmentClassCode'],
            wgsSubGroupNumber: element['wgsSubGroupNumber'],
            rateInfo: rateInfo,
            asoFee: asoFee,
            sslPremium: sslPremium,
            aslPremium: aslPremium,
            terminalLiabilityFund: terminalLiability,
            maxPaidClaimsFund: maxPaidClaimsFund,
            enrollments: element['enrollments'],
            rateSplits: element['rateSplits']
          });
        });
        _rateInfo['plan'][index]['employmentCategory'] = empCategoryArray;
      }
      empCategoryArray = null;
    });
    const groupCreditsAndFunds = [];
    let isMedicalAdded = this.selectedSubmitValue?.includes(RareConstants.medical);
    if (this.submittedTransitionData && this.submittedTransitionData.length > 0) {
      // Group by programType, rateType, and unitType
      const fundsGroups = {};
      this.submittedTransitionData.forEach(item => {
        const rateTypeKey = item.rateType ? item.rateType.toLowerCase() : '';
        const programTypeKey = item.programType || this.selectedProgramType;
        const unitTypeKey = item.unitType || '';
        const groupKey = `${programTypeKey}__${rateTypeKey}__${unitTypeKey}`;
        if (!fundsGroups[groupKey]) fundsGroups[groupKey] = [];
        fundsGroups[groupKey].push(item);
      });
      Object.keys(fundsGroups).forEach(groupKey => {
        const groupItems = fundsGroups[groupKey];
        const unitType = groupItems.length > 0 ? groupItems[0].unitType : '';
        const programType = groupItems.length > 0 && groupItems[0].programType ? groupItems[0].programType : this.selectedProgramType;
        const rateTypeKey = groupItems.length > 0 && groupItems[0].rateType ? groupItems[0].rateType.toLowerCase() : '';
        // Choose correct options array based on programType
        let optionsArr = this.groupOptionsMap[programType] || [];
        groupCreditsAndFunds.push({
          programType: programType,
          rateTypes: groupItems.map(item => {
            const opt = optionsArr.find(opt => opt.value === item.programDesc);
            return {
              programDesc: item.programDesc,
              rate: item.rate,
              splitType: opt?.splitType,
              splitSubType: opt?.splitSubType || item.programDesc || ''
            };
          }),
          rateType: rateTypeKey,
          unitType: unitType,
        });
      });
    }
    if (groupCreditsAndFunds.length > 0) {
      if (isSubmit) {
        if (isMedicalAdded) {
          _rateInfo['groupCreditsAndFunds'] = groupCreditsAndFunds;
        } else {
          if ('groupCreditsAndFunds' in _rateInfo?.data) {
            delete _rateInfo?.data['groupCreditsAndFunds'];
          }
        }
      } else if (isSave) {
        _rateInfo['groupCreditsAndFunds'] = groupCreditsAndFunds;
      }
    }
    return _rateInfo;
  }

  calculateRate(factor, tierRate): any {
    if (tierRate) {
      var rateInfo: RateInfo = new RateInfo();
      rateInfo.eeRate = parseFloat(this.buildRateInfo(factor, tierRate.eeRate));
      rateInfo.esRate = parseFloat(this.buildRateInfo(factor, tierRate.esRate));
      rateInfo.efRate = parseFloat(this.buildRateInfo(factor, tierRate.efRate));
      rateInfo.ecRate = parseFloat(this.buildRateInfo(factor, tierRate.ecRate));
      rateInfo.ekRate = parseFloat(this.buildRateInfo(factor, tierRate.ekRate));
      if (tierRate.compositeRate !== undefined && tierRate.compositeRate !== null) {
        rateInfo.compositeRate = parseFloat(this.buildRateInfo(factor, tierRate.compositeRate));
      }
      return rateInfo;
    } else {
      return null;
    }
  }

  convertToDecimal(tierRate): any {
    return this._decimalPipe.transform(tierRate, '1.2-2');
  }

  buildRateInfo(factor, tierRate): any {
    if (tierRate === null || tierRate === undefined) {
      return 0;
    }
    const converted = isNaN(factor) ? this.convertToDecimal(tierRate) : this.convertToDecimal(factor * tierRate);
    if (converted === null || converted === undefined) {
      return 0;
    }
    return converted.replace(/[^\d\.\-]/g, '');
  }

  submitSoldRates($event) {
    if ($event.target.name === 'Manual Submit') {
      this.action = $event.target.name;
    }

    this.saveSoldRates(false, true);
    this.onSubmitFlag = true;

    if ((this.selectedSubmitValue?.includes(RareConstants.vision)
      || this.selectedSubmitValue?.includes(RareConstants.dental)
      || this.selectedSubmitValue?.includes(RareConstants.suppHealth))
       && (this.isCurrentPlanMapped && !this.selectedSubmitValue?.includes(RareConstants.medical))) {
      this.isCurrentPlanMapped = false;
    }

    if (
      (this.isCurrentPlanMapped && StringUtils.isEqual(this.alertData, SoldConstants.CURRENT_PLAN_MAP_MSG)) ||
      (this.isEnrollmentMismatch && StringUtils.isEqual(this.alertData, SoldConstants.ENROLLMENT_MISMATCH_MSG))
    )

    this.onSubmitFlag = false;
    //clear out sessiondata for additionalPrograms when SUBMIT is done
    sessionStorage.setItem('addedAdditionalPrograms', '');
  }

  updateAction(action) {
    this.action = action;
  }

   saveSoldRates(isSave?: boolean, isSubmit?: Boolean) {
    this.isAcceptedOrRejected = false;
    this.isEnrollmentMismatch = false;
    this.isEnrollmentTotalMismatch = false;
    this.isCurrentPlanMapped = false;
    
    let hasValidationErrors = false;
    let hasNonMedicalPlans;
     if (isSubmit) {
       hasNonMedicalPlans = this.selectedSubmitValue?.every(plan => plan !== RareConstants.medical);
     } else {
       hasNonMedicalPlans = this.rowData?.filter(plan => plan.lob === RareConstants.medical).length === 0;
     }
    if (!hasNonMedicalPlans && this.hasActiveEmploymentCategories()) {
      hasValidationErrors = this.validateEnrollmentTotals();
      if (hasValidationErrors) {
        this.isEnrollmentTotalMismatch = true;
        this.div_visible = false;
        this.alertData = SoldConstants.ENROLLMENT_MISMATCH_MSG;
        return;
      }
    }
    
    if (this.selectedSoldRatePlan.length == 0) {
      this.updatedSoldRatePlan({}, '', '');
    }
    for (let i = 0; i < this.selectedSoldRatePlan.length; i++) {
      this.selectedSoldRatePlan[i]['ActionPerformed'] = this.action;
    }
    this.removeSuccessMsg();
    let _SoldRatePlansWithCat = Object.assign({}, this.soldRateFullResponse);
    _SoldRatePlansWithCat.plan = this.responseData;
    // Convert contract effective date from Date object to yyyy-MM-dd format for API
    const contractEffDateForAPI = this.datepipe.transform(this.contractEffDate, 'MM-dd-yyyy');
    let contractEndDateFormatted = this.convertMMDDYYYYtoYYYYMMDD(contractEffDateForAPI);
    _SoldRatePlansWithCat.effectiveDate = contractEndDateFormatted;
    _SoldRatePlansWithCat.caseNumber = this.savedCaseNumber;
    this.div_visible = true;
    if (this.isMedicalRenewalLocalPresent) {
      let medicalPlans = this.responseData.filter(
        (medPlans) =>
          StringUtils.isEqualIgnoreCase(medPlans.lob, RareConstants.medical) &&
          StringUtils.isEqualIgnoreCase(medPlans.status, 'Pre-Sold') &&
          medPlans?.employmentCategory?.length != 0
      );
      this.isCurrentPlanMapped = medicalPlans.some((medPlans) => StringUtils.isUndefined(medPlans.currentContractCode));
    }

    if (this.isCurrentPlanMapped && this.selectedSubmitValue?.includes(RareConstants.medical)) {
      this.showErrorAlert = true;
      this.div_visible = false;
      this.alertData = SoldRatesConstants.CURRENT_PLAN_MAP_MSG;
      return;
    }

    if (
      this.selectedSubmitValue?.includes(RareConstants.vision) ||
      this.selectedSubmitValue?.includes(RareConstants.dental) ||
      this.selectedSubmitValue?.includes(RareConstants.suppHealth) ||
      this.selectedSubmitValue.length == 0
    ) {
      this.isCurrentPlanMapped = false;
    }

    let enrollments = this.checkEnrollmentCount(_SoldRatePlansWithCat);
    if (this.isCurrentPlanMapped) {
      this.showErrorAlert = true;
      this.div_visible = false;
      this.alertData = SoldRatesConstants.CURRENT_PLAN_MAP_MSG;
      return;
    }
    if (!StringUtils.isUndefined(_SoldRatePlansWithCat?.quotedSubscribers) && this.isMedicalRenewalLocalPresent) {
      if (
        enrollments != _SoldRatePlansWithCat.quotedSubscribers &&
        (this.selectedSubmitValue?.includes(RareConstants.medical) ||
          (this.submitOptions?.includes(RareConstants.medical) && StringUtils.isEqual(this.action, CommonConstants.save)))
      ) {
        this.isEnrollmentMismatch = true;
        this.showErrorAlert = true;
        this.div_visible = false;
        this.alertData = SoldConstants.ENROLLMENT_MISMATCH_MSG;
        return;
      }
    }
     // Now build the final payload with groupCreditsAndFunds
     let payloadWithGroupCreditsAndFunds = this.buildSubmitJson(_SoldRatePlansWithCat, false, true);
     if(!this.isAdditionalProductDataAdded) {
       payloadWithGroupCreditsAndFunds = this.addAdditionalProductDataPlans(payloadWithGroupCreditsAndFunds);
     }
    _SoldRatePlansWithCat.caseNumber = this.savedCaseNumber;
    // Pass groupCreditsAndFunds at the correct level for save
    if (payloadWithGroupCreditsAndFunds.groupCreditsAndFunds) {
      payloadWithGroupCreditsAndFunds._groupCreditsAndFundsForSave = payloadWithGroupCreditsAndFunds.groupCreditsAndFunds;
    }
    // Sync edited rateEffectiveDate from rowData to responseData before building payload
    this.responseData.forEach(respPlan => {
      const match = this.rowData.find(rowPlan =>
        rowPlan.ratingPlanID === respPlan.ratingPlanID &&
        rowPlan.lob === respPlan.lob &&
        rowPlan.fundingType === respPlan.fundingType &&
        rowPlan.contractCode === respPlan.contractCode
      );
      if (match && match.rateEffectiveDate) {
        respPlan.rateEffectiveDate = match.rateEffectiveDate;
      }
    });
    this.soldRatesService.saveSoldRates(payloadWithGroupCreditsAndFunds, this.opportunityID, this.selectedSoldRatePlan, this.action).subscribe(
      (response) => {
        if (response.code === 'success') {
          // Store updated contract effective dates for additional products after save
          if (payloadWithGroupCreditsAndFunds?.data?.quotes) {
            payloadWithGroupCreditsAndFunds.data.quotes.forEach(quote => {
              if (quote.contractEffectiveDate && quote.plans) {
                // Check if this quote has additional products
                const hasAdditionalProducts = quote.plans.some(plan => plan.isAdditionalProduct);
                if (hasAdditionalProducts) {
                  // Store the contract effective date for this LOB
                  this.updatedContractEffDatesByLOB[quote.lob] = quote.contractEffectiveDate;
                }
              }
            });
          }
          
          this.showSaveAlert = true;
          this.selectedSoldRatePlan = [];
          this.selectedRowsToRemove = [];
          this.isAdditionalProductDataAdded = false;
          this.additionalProductDataObj = [];
          this.programValues = [];
          this.levelType = [];
          this.rateTypesAdditional = [];
          this.groupCreditsRateTypes = [];
          this.originalGroupCreditsRateTypes = [];
          this.groupOptionsMap = {};
          this.loadSoldRates();
          this.updateSubmitOptionsAfterRemove();
        } else if (response.exceptions) {
          this.showErrorAlert = true;
          this.div_visible = false;
          this.alertData = response.exceptions.exceptions[0].message;
          this.failureMessage = true;
          this.isAdditionalProductDataAdded = false;
        } else if (this.onSubmitFlag) {
          this.loadSoldRates();
          this.updateSubmitOptionsAfterRemove();
        }
      },
      (error) => {
        console.error(error);
        this.showErrorAlert = true;
        this.div_visible = false;
        this.alertData = 'Error Encountered, Please contact dl-RARE-IT';
        this.failureMessage = true;
        this.isAdditionalProductDataAdded = false;
      }
    );

    //clear out sessiondata for additionalPrograms when save is done
    sessionStorage.setItem('addedAdditionalPrograms', '');
    this.mapOfContractCodeAndAdditionalProgram = new Map<String, Object[]>();
  }

  getSelectedOriginalLOB(plansPayload) {
    if (!this.selectedOriginalLOB) {
      if (plansPayload?.data?.quotes && plansPayload?.data?.quotes.length > 0 && plansPayload.data.quotes.find(quote => quote.lob === RareConstants.medical)) {
        this.selectedOriginalLOB = RareConstants.medical;
      } else {
        this.selectedOriginalLOB = (plansPayload?.data?.quotes && plansPayload.data.quotes.length > 0 ? plansPayload.data.quotes[0].lob : RareConstants.medical);
      }
    }
  }
  addAdditionalProductDataPlans(plansPayload) {
    this.getSelectedOriginalLOB(plansPayload);
    if (this.additionalProductDataObj.length > 0) {
      this.soldratesdateformat();
      
      // Update existing quotes' contractEffectiveDate with the stored dates per LOB
      // Only update quotes that have additional products and have stored dates
      plansPayload.data.quotes.forEach(quote => {
        if (this.updatedContractEffDatesByLOB[quote.lob]) {
          // Check if this quote has additional products before updating
          const hasAdditionalProducts = quote.plans && quote.plans.some(plan => plan.isAdditionalProduct);
          if (hasAdditionalProducts) {
            // Use the stored contract effective date for this LOB
            quote.contractEffectiveDate = this.updatedContractEffDatesByLOB[quote.lob];
          }
        }
      });
      
      this.additionalProductDataObj.forEach((additionalProduct) => {
      let quoteObj = {
        abfCommissionType: "",
        abfCommissionValue: null,
        acsFactor: null,
        aggSLCorridor: null,
        marketSegment: this.soldRateFullResponse?.data?.quotes.find(p => p.lob === this.selectedOriginalLOB)?.marketSegment || null,
        contractEffectiveDate: this.updatedContractEffDatesByLOB[additionalProduct.lob] || plansPayload.data.quotes.find(quote => quote.lob === this.selectedOriginalLOB)?.contractEffectiveDate,
        contractEffectiveDateIncurred: plansPayload.data.quotes.find(quote => quote.lob === this.selectedOriginalLOB)?.contractEffectiveDateIncurred,
        contractEndDate: null,
        currentPlans: [],
        employmentCategoryAddlProduct: plansPayload.data.quotes.find(quote => quote.lob === this.selectedOriginalLOB)?.employmentCategoryMedical,
        estimatedMembers: null,
        fundingType: additionalProduct.fundingType,
        lob: additionalProduct.lob,
        state: this.state,
        mappedMedTierLivesMap: {
        },
        opportunityType: plansPayload.data.quotes.find(quote => quote.lob === this.selectedOriginalLOB)?.opportunityType,
        outputTier: null,
        plans: [additionalProduct],
        quoteOrigin: null,
        quotedSubscribers: null,
        quotingType: null,
        rateEffectiveDate: additionalProduct?.rateEffectiveDate,
        rateEndDate: plansPayload.data.quotes.find(quote => quote.lob === this.selectedOriginalLOB)?.rateEndDate,
        rateGuaranteeMonths: additionalProduct?.rateGuaranteeMonths,
        ratingTransID: additionalProduct.ratingPlanID,
        soldAddlProduct: true,
        sslDeductible: null,
        status: CommonConstants.PRE_SOLD,
        surplusRefund: null
      };

        let quote = plansPayload?.data?.quotes?.find(quote => quote.lob === quoteObj.lob);
        if (quote) {
          quote.plans = [...quote.plans, ...quoteObj.plans];
        } else {
          plansPayload.data.quotes.push(quoteObj);
        }
      this.isAdditionalProductDataAdded = true;
    });
  }

    return plansPayload;

  }

  createFileName(): string {
    let visFlag = false;
    let medFlag = false;
    let denFlag = false;
    let _SoldRatePlansWithCat = this.responseData;
    const planList = _SoldRatePlansWithCat;
    planList.forEach((plan) => {
      if (plan['lob'] === RareConstants.medical && plan['status'] === 'Sold') {
        medFlag = true;
      } else if (plan['lob'] === RareConstants.vision && plan['status'] === 'Sold') {
        visFlag = true;
      } else if (plan['lob'] === RareConstants.dental && plan['status'] === 'Sold') {
        denFlag = true;
      }
    });
    let contractEndDateFormatted = this.datepipe.transform(this.getEffectiveDate(this.soldRateFullResponse.data), 'yyyyMMdd');
    let submittedTimeStamp = this.datepipe.transform(new Date(), 'yyyyMMdd-hhmmss');
    const lobName = medFlag && visFlag ? 'MED' : !medFlag && visFlag ? 'VIS' : !medFlag && denFlag ? 'DEN' : 'MED';
    const returnValue =
      _SoldRatePlansWithCat[0]['caseName'] +
      '-' +
      contractEndDateFormatted +
      '-' +
      this.quoteHeaderID +
      '-' +
      submittedTimeStamp +
      '-' +
      lobName +
      '-RARE-FINALRATES';
    return returnValue;
  }

  generateReport(actionType: string) {
    this.reportsService
      .getGeneratedReport(
        null,
        null,
        null,
        null,
        this.opportunityID,
        this.quoteHeaderID,
        this.fundingType,
        this.getOpportunityType(this.soldRateFullResponse.data),
        this.createFileName(),
        null,
        null,
        null,
        null,
        null,
        null,
        true,
        actionType
      )
      .subscribe(
        (response) => {
          this.div_visible = false;
          if (response.status === 200) {
            this.processId = response.body.processId;
            this.showProgress = true;
            this.progressPercent = 1;
            this.progressStyle = 'progress-bar-warning';
            var source = this.commonService.listenForStream(this.processId);
            this.eventSources.push(source);
            source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
              this.progressStyle = '';
              let eventData = JSON.parse(event.data);
              var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            });
            source.addEventListener('SEND_EXHIBIT_TO_UI', (message: any) => {
              let eventData = JSON.parse(message.data);
              var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
              let fileExt = '.xlsx';
              CommonService.exportFilename = eventData.metaData.fileName ? eventData.metaData.fileName : 'sheet' + fileExt;
              let fileName = this.commonService.getExportFilename();
              if (eventData?.payload?.contentData) {
                let contentData = eventData.payload.contentData;
                const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
                this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
              }
            });
            source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
              source.close();
              let eventData = JSON.parse(message.data);
              this.progressStyle = 'progress-bar-success';
              this.progressPercent = 100;
              this.progressMessage = eventData.message;
              setTimeout(() => {
                this.showProgress = false;
              }, this.commonService.getProgressBarTimeOut());
            });
            source.addEventListener('FAILED', (message: any) => {
              source.close();
              console.error('Received event : ', JSON.stringify(message.data));
              this.progressPercent = 90;
              this.progressStyle = 'progress-bar-danger';
              this.progressMessage = 'Error in getting response for Export';
            });
          }
        },
        (error) => {
          this.div_visible = false;
          alert('Error in getting response for Export: ' + error);
        }
      );
  }

  downloadFile(blob: any, filename: string) {
    var binaryData = [];
    binaryData.push(blob);

    /*Workaround for IE11 download issue*/
    // IE doesn't allow using a blob object directly as link href
    // instead it is necessary to use msSaveOrOpenBlob
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(new Blob(binaryData, { type: '' }), filename);
      return;
    } else {
      // create hidden dom element (so it works in all browsers)
      const url = window.URL.createObjectURL(new Blob(binaryData, { type: '' })); // <-- work with blob directly
      const a = document.createElement('a');
      a.setAttribute('style', 'display:none;');
      document.body.appendChild(a);

      // create file, attach to hidden element and open hidden element
      a.href = url;
      a.download = filename;
      a.click();
    }
  }

  getPlanData(map, value): any {
    let objFound = map.find((x) => x.quotedContractCode === value);
    return objFound || {};
  }

  getPlanName(map, value): string {
    let objFound = this.getPlanData(map, value);
    return objFound.productName || '';
  }

  getPlanNameObj(map, value): string {
    let objFound = map.find((x) => x.quotedContractCode === value && x.fundingType === this.selectedFundingType);
    return objFound || '';
  }

  getProductsByContractCode(products, quotedContractCode): any[] {
    return products.filter((product) => product.quotedContractCode === quotedContractCode);
  }

  getRatesByCC(value) {
    this.selectedContractCode = value;
    this.dataReset();
    this.formData = null;
    this.selectedEmpCategory = null;
    this.empCatValue = '';
    this.lobValue = '';
    this.selectedPlan = this.getPlanName(this.responseData, value);

    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, CommonConstants.SuppHealth) && value) {
      const selectedQuotedContractCodes = value ?? [];
      let soldContractCodes = selectedQuotedContractCodes.map((selectedQuotedContractCode) => selectedQuotedContractCode.value);
      soldContractCodes = soldContractCodes.join(', ');

      let selectedProducts = [];
      let selectedRatingPlanIDs = [];
      selectedQuotedContractCodes.forEach((selectedQuotedContractCode) => {
        const products = this.getProductsByContractCode(this.responseData, selectedQuotedContractCode.value);
        products?.forEach((product) => {
          selectedProducts.push({
            quotedContractCode: selectedQuotedContractCode.value,
            contractCode: product['contractCode'],
            productName: product['productName'],
            ratingPlanID: product['ratingPlanID']
          });
          selectedRatingPlanIDs.push(product['ratingPlanID']);
        });
      });
      this.selectedProducts = selectedProducts;
      this.selectedRatingPlanIDs = selectedRatingPlanIDs;
      this.soldRates_form.controls.ccCodeOverride.setValue(soldContractCodes);
    } else {
      this.planValue = {
        quotedContractCode: this.selectedContractCode,
        contractCode: this.getPlanNameObj(this.responseData, value)['contractCode'],
        productName: this.selectedPlan,
        ratingPlanID: this.getPlanNameObj(this.responseData, value)['ratingPlanID']
      };
      this.selectedRatingPlanID = this.getPlanNameObj(this.responseData, value)['ratingPlanID'];
      this.soldRates_form.controls.ccCodeOverride.setValue(this.planValue.contractCode);
    }
    if (this.isMedicalRenewalLocalPresent && this.selectedLOB == 'Medical') this.getCurrentPlan(this.selectedRatingPlanID);
    this.categoryList = [];
    this.categoryList = this.getCategoryList(this.selectedLOB, 'A');
  }

  getSoldContractCode = (value) => {
    this.soldCCvalue = value;
  }

  getCategoryList(lob, forType) {
    let categoryListArray = [];
    let defaultCategoryList = [];
    if (StringUtils.isEqualIgnoreCase(lob, RareConstants.medical)) {
      for (let cat of this.soldRateFullResponse.employmentCategoryMedical) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    } else if (StringUtils.isEqualIgnoreCase(lob, RareConstants.vision)) {
      for (let cat of this.soldRateFullResponse.employmentCategoryVision) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    } else if (StringUtils.isEqualIgnoreCase(lob, RareConstants.dental)) {
      for (let cat of this.soldRateFullResponse.employmentCategoryDental) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    } else if (StringUtils.isEqualIgnoreCase(lob, RareConstants.suppHealth)) {
      for (let cat of this.soldRateFullResponse.employmentCategorySuppHealth) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    }

    if (defaultCategoryList.length) {
      defaultCategoryList.sort();
      this.empCatValue = defaultCategoryList;
      this.getCategory(defaultCategoryList);
    }

    categoryListArray.sort(function (a, b) {
      if (a && b) {
        if (a.label && b.label) {
          return a.label.localeCompare(b.label);
        } else {
          return a.localeCompare(b);
        }
      }
    });
    return categoryListArray;
  }

  setCategoryList(forType, categoryListArray: any[], cat: any, defaultCategoryList: any[]) {
    if (StringUtils.isEqualIgnoreCase(forType, 'A')) {
      categoryListArray.push({
        label: cat.emplymntCtgryCd,
        value: cat.emplymntCtgryCd
      });
      if (StringUtils.isEqualIgnoreCase(cat.dfltInd, 'Y')) {
        defaultCategoryList.push(cat.emplymntCtgryCd);
      }
    } else {
      categoryListArray.push(cat.emplymntCtgryCd);
    }
  }

  //This is invoked when AddPlan popup is reset
  resetForm() {
    if (this.activeTab === 2) {
      this.AdditionalProductComponent?.resetForm();
    } else {
      this.revertReplacingOfTierRatesWithQuotedRates();
      this.formReset();
    }
    this.errorFlag = false;
    this.errorValue = '';
  }

  getEmpCategoryFactor(value, lob?) {
    if (StringUtils.isEmpty(lob)) lob = this.selectedLOB;

    this.empCategoryData = null;
    if ((lob.toLowerCase() === RareConstants.medicalLC && this.soldRateFullResponse.employmentCategoryMedical) || this.selectedProgramType) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategoryMedical.find((x) => x.emplymntCtgryCd === value);
    }

    if (lob.toLowerCase() === RareConstants.visionLC && this.soldRateFullResponse.employmentCategoryVision) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategoryVision.find((x) => x.emplymntCtgryCd === value);
    }

    if (lob.toLowerCase() === RareConstants.dentalLC && this.soldRateFullResponse.employmentCategoryDental) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategoryDental.find((x) => x.emplymntCtgryCd === value);
    }

    if (StringUtils.isEqualIgnoreCase(lob, RareConstants.suppHealth) && this.soldRateFullResponse.employmentCategorySuppHealth) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategorySuppHealth.find((x) => x.emplymntCtgryCd === value);
    }

    return this.empCategoryData.emplymntCtgryFctr;
  }

  checkActiveExistCommon(ratingPlanID: string) {
    let empCat;
    empCat = this.responseData.find((x) => x.ratingPlanID === ratingPlanID);
    let classCodeExists = false;
    if (empCat && empCat.employmentCategory) {
      empCat.employmentCategory.find((x) => {
        if (
          (x.employmentClassCode === '' && typeof this.classCode === 'undefined') ||
          x.employmentClassCode === this.classCode
        ) {
          classCodeExists = true;
        }
      });
    }
    const isActive = this.selectedEmpCategory && this.selectedEmpCategory.find((e) => e === 'Active');
    if ((!empCat || !empCat.employmentCategory || !empCat.employmentCategory.length) && isActive) {
      return true;
    } else if ((!empCat || !empCat.employmentCategory || !empCat.employmentCategory.length) && !isActive) {
      return false;
    } else if (empCat && empCat.employmentCategory && empCat.employmentCategory.length) {
      if (
        (classCodeExists && !empCat.employmentCategory.find((e) => e.emplymntCtgryCd === 'Active' &&
          ((e.employmentClassCode === '' && typeof this.classCode === 'undefined') || e.employmentClassCode === this.classCode)
        )) ||
        (!classCodeExists && !isActive)
      ) {
        return false;
      } else if (!classCodeExists && isActive) {
        return true;
      }
    }
    return true;
  }

  checkActiveExist() {
    return this.checkActiveExistCommon(this.selectedRatingPlanID);
  }

  checkActiveExistSuppHealth() {
    return this.selectedRatingPlanIDs.some((ratingPlanID) => this.checkActiveExistCommon(ratingPlanID));
  }

  updateEnrollment(rowData, empCat, enterdValue, key) {
    rowData.employmentCategory.forEach((rowDataEmpCat) => {
      if (rowDataEmpCat.emplymntCtgryCd == empCat.emplymntCtgryCd && rowDataEmpCat.employmentClassCode == empCat.employmentClassCode) {
        rowDataEmpCat.enrollments[key] = Number(enterdValue);
      }
    });
  }

  onEnrollmentChange(key, rowData, empCat, event) {
    let enterdValue = event.target.value.replace('%', '').replace(',', '');
    if (StringUtils.isEqualIgnoreCase(key, 'eeRateEnrollment')) this.updateEnrollment(rowData, empCat, enterdValue, 'ee');
    if (StringUtils.isEqualIgnoreCase(key, 'ekRateEnrollment')) this.updateEnrollment(rowData, empCat, enterdValue, 'ek');
    if (StringUtils.isEqualIgnoreCase(key, 'efRateEnrollment')) this.updateEnrollment(rowData, empCat, enterdValue, 'ef');
    if (StringUtils.isEqualIgnoreCase(key, 'ecRateEnrollment')) this.updateEnrollment(rowData, empCat, enterdValue, 'ec');
    if (StringUtils.isEqualIgnoreCase(key, 'esRateEnrollment')) this.updateEnrollment(rowData, empCat, enterdValue, 'es');
    
    const hasNonMedicalPlans = this.rowData?.filter(plan => plan.lob === RareConstants.medical).length === 0;
    if (!hasNonMedicalPlans && this.hasActiveEmploymentCategories()) {
      
       if (this.validateEnrollmentTotals()) {
        this.isEnrollmentTotalMismatch = true;
        this.div_visible = false;
        this.alertData = SoldConstants.ENROLLMENT_MISMATCH_MSG;
        return;
      }
    }
  }

  prepareEmpCatObj(empCat, forType, classCode, lob?) {
    let obj = {
      emplymntCtgryCd: '',
      employmentClassCode: '',
      wgsSubGroupNumber: ''
    };
    if (this.isMedicalRenewalLocalPresent && StringUtils.isEqualIgnoreCase(lob, RareConstants.medical)) {
      if (empCat == 'Active') {
        let planListResponseData = this.responseData;
        planListResponseData = planListResponseData.filter(
          (planListResponseData) => !StringUtils.isEqualIgnoreCase(planListResponseData.ratingPlanID, this.selectedRatingPlanIdUpdate)
        );
        let existContractMapping = planListResponseData.find(
          (responseData) =>
            responseData.currentContractCode == this.selectedCurrentContractCode &&
            responseData?.employmentCategory &&
            responseData?.employmentCategory?.length > 0
        );
        if (existContractMapping) {
          obj['enrollments'] = { ee: 0, ef: 0, ek: 0, es: 0, ec: 0 };
        } else {
          let initialEnrollments = this.soldRateFullResponse.mappedMedTierLivesMap[this.selectedCurrentContractCode];
          obj['enrollments'] = {
            ee: initialEnrollments?.EE,
            ef: initialEnrollments?.EF,
            ek: initialEnrollments?.EK,
            es: initialEnrollments?.ES,
            ec: initialEnrollments?.EC
          };
        }
      } else {
        obj['enrollments'] = { ee: 0, ef: 0, ek: 0, es: 0, ec: 0 };
      }
    }
    if (forType === 'C') {
      obj['emplymntCtgryCd'] = empCat;
      obj['employmentClassCode'] = classCode;
      obj['wgsSubGroupNumber'] = '';
      return obj;
    } else {
      obj['emplymntCtgryCd'] = empCat;
      obj['employmentClassCode'] = '';
      obj['wgsSubGroupNumber'] = '';
      return obj;
    }
  }

  checkEmpCatExist(obj) {
    return this.checkEmpCatExistCommon(obj, [this.selectedRatingPlanID]);
  }

  checkEmpCatExistSuppHealth(obj) {
    return this.checkEmpCatExistCommon(obj, this.selectedRatingPlanIDs);
  }

  /**
   * Common method for checking existing empCat
   * This common function is a refactor of the previous checkEmpCatExist that takes an array of strings
   * @param obj
   * @param selectedRatingPlanIDs
   */
  checkEmpCatExistCommon(obj, selectedRatingPlanIDs) {
    return selectedRatingPlanIDs.some((selectedRatingPlanID) => {
      let planEmpCat = this.responseData.find((x) => x.ratingPlanID === selectedRatingPlanID).employmentCategory;
      if (planEmpCat?.length > 0) {
        for (let i = 0; i < planEmpCat.length; i++) {
          if (planEmpCat[i].employmentClassCode == null) {
            planEmpCat[i].employmentClassCode = '';
          }
        }
      }
      let isplanEmpCatExists = planEmpCat?.find(
        (x) => x.emplymntCtgryCd === obj.emplymntCtgryCd && x.employmentClassCode.toLowerCase() === obj.employmentClassCode.toLowerCase()
      );
      if (isplanEmpCatExists) return true;
      else return false;
    });
  }

  checkDubEmpCatExist() {
    this.dubEmpCats = '';
    if (this.formData?.employmentCategory) {
      for (let empCat of this.selectedEmpCategory) {
        let obj;
        if (this.soldRates_form.controls.classValue.value) {
          obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value);
        } else {
          obj = this.prepareEmpCatObj(empCat, 'WC', '');
        }
        if (this.checkEmpCatExist(obj)) {
          this.dubEmpCats = this.dubEmpCats + empCat + ', ';
        }
      }
    }
    if (this.dubEmpCats) return true;
    else return false;
  }

  checkDubEmpCatExistSuppHealth() {
    this.dubEmpCats = '';
    return this.formData.some((selectedProduct) => {
      if (selectedProduct.employmentCategory) {
        for (let empCat of this.selectedEmpCategory) {
          let obj;
          if (this.soldRates_form.controls.classValue.value) {
            obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value);
          } else {
            obj = this.prepareEmpCatObj(empCat, 'WC', '');
          }
          if (this.checkEmpCatExistSuppHealth(obj)) {
            this.dubEmpCats = this.dubEmpCats + empCat + ', ';
          }
        }
      }
      if (this.dubEmpCats) return true;
      else return false;
    });
  }

  saveQLI() {
    if(this.activeTab === 2) {
      this.AdditionalProductComponent.saveAdditionalProduct();
    } else {
    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)) {
      this.saveQLISuppHealth();
      return;
    }
    if (
      this.selectedContractCode &&
      this.selectedLOB &&
      this.selectedFundingType &&
      this.soldRates_form.controls.caseNumber.value &&
      this.soldRates_form.controls.ccCodeOverride.value &&
      this.selectedEmpCategory &&
      this.selectedEmpCategory.length > 0 &&
      this.checkActiveExist()
    ) {
      this.isCaseNoSaved = true;
      this.savedCaseNumber = this.soldRates_form.controls.caseNumber.value;
      if (this.selectedLOB === 'Medical') {
        if (this.mapOfContractCodeAndSelectedEmpCategories && this.mapOfContractCodeAndSelectedEmpCategories.has(this.selectedContractCode)) {
          let employmentCategoryList = this.mapOfContractCodeAndSelectedEmpCategories.get(this.selectedContractCode);
          for (let addedEmpCategory of this.selectedEmpCategory) {
            if (!employmentCategoryList.find((x) => x === addedEmpCategory)) {
              employmentCategoryList.push(addedEmpCategory);
            }
          }
          this.mapOfContractCodeAndSelectedEmpCategories.delete(this.selectedContractCode);
          this.mapOfContractCodeAndSelectedEmpCategories.set(
            JSON.parse(JSON.stringify(this.selectedContractCode)),
            JSON.parse(JSON.stringify(employmentCategoryList))
          );
        } else {
          this.mapOfContractCodeAndSelectedEmpCategories.set(
            JSON.parse(JSON.stringify(this.selectedContractCode)),
            JSON.parse(JSON.stringify(this.selectedEmpCategory))
          );
        }
      }
      if (this.isMedicalRenewalLocalPresent && StringUtils.isEmpty(this.selectedCurrentContractCode) && this.selectedLOB == 'Medical') {
        this.errorFlag = true;
        this.errorValue = SoldRatesConstants.CURRENT_PLAN_SELECT_MSG;
      } else if (!this.planRetireeValidation(false)) {
        this.errorFlag = true;
        this.errorValue = SoldRatesConstants.RETIREE_VALIDATION_MSG;
      } else {
        for (let i = 0; i < this.selectedEmpCategory.length; i++) {
          this.isRateSplitsAvailable(this.formData, i);
        }
        if (this.selectedLOB === 'Medical') {
          this.showAdditionalProgramsPopUp = true;
        }
        if (!this.checkDubEmpCatExist()) {
          for (let empCat of this.selectedEmpCategory) {
            this.errorFlag = false;
            if (this.formData.employmentCategory) {
              let obj;
              if (this.soldRates_form.controls.classValue.value) {
                obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB);
              } else {
                obj = this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB);
              }
              this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value;
              this.updatedSoldRatePlan(obj, 'add', this.selectedRatingPlanID);
              this.soldCCvalueUpdated = this.soldCCvalue;
              obj['tierRate'] = {};
              obj.tierRate.eeRate = this.roundValueToTwoDecimals(
                this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat)
              );
              obj.tierRate.esRate = this.roundValueToTwoDecimals(
                this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat)
              );
              obj.tierRate.efRate = this.roundValueToTwoDecimals(
                this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat)
              );
              obj.tierRate.ecRate = this.roundValueToTwoDecimals(
                this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat)
              );
              obj.tierRate.ekRate = this.roundValueToTwoDecimals(
                this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat)
              );

              this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).employmentCategory.push(obj);
              // Update rateGuaranteeMonths when adding a plan
              const planToUpdate = this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID);
              const contractEndDate = planToUpdate?.rateEndDate;
              // Use the latest edited rate effective date if available
              let latestEffDate = this.rateEffDate || planToUpdate.rateEffectiveDate;
              let latestGuaranteeMonths = this.rateGuarMonths || planToUpdate.rateGuaranteeMonths;
              if (planToUpdate && latestEffDate && contractEndDate) {
                planToUpdate.rateEffectiveDate = this.datepipe.transform(latestEffDate, 'MM/dd/yyyy');
                const start = new Date(latestEffDate);
                const end = new Date(contractEndDate);
                planToUpdate.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
              }
              if (planToUpdate && latestGuaranteeMonths) {
                planToUpdate.rateGuaranteeMonths = latestGuaranteeMonths;
              }
            } else {
              let obj1;
              if (this.soldRates_form.controls.classValue.value) {
                obj1 = [this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB)];
              } else {
                obj1 = [this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB)];
              }
              this.selectedRatingPlanIdUpdate = '';
              this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value;
              this.updatedSoldRatePlan(obj1[0], 'add', this.selectedRatingPlanID);

              obj1.forEach((emplyCat) => {
                emplyCat['tierRate'] = {};
                emplyCat.tierRate.eeRate = this.roundValueToTwoDecimals(
                  this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat)
                );
                emplyCat.tierRate.esRate = this.roundValueToTwoDecimals(
                  this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat)
                );
                emplyCat.tierRate.efRate = this.roundValueToTwoDecimals(
                  this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat)
                );
                emplyCat.tierRate.ecRate = this.roundValueToTwoDecimals(
                  this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat)
                );
                emplyCat.tierRate.ekRate = this.roundValueToTwoDecimals(
                  this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat)
                );
              });

              this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).employmentCategory = obj1;
              // Update rateGuaranteeMonths when adding a plan (for new employmentCategory array)
              const planToUpdate2 = this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID);
              const contractEndDate2 = planToUpdate2?.rateEndDate;
              let latestEffDate2 = this.rateEffDate || planToUpdate2.rateEffectiveDate;
              let latestguaranteeMonths2 = this.rateGuarMonths || planToUpdate2.rateGuaranteeMonths;
              if (planToUpdate2 && latestEffDate2 && contractEndDate2) {
                planToUpdate2.rateEffectiveDate = this.datepipe.transform(latestEffDate2, 'MM/dd/yyyy');
                const start = new Date(latestEffDate2);
                const end = new Date(contractEndDate2);
                planToUpdate2.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
              }
              if (planToUpdate2 && latestguaranteeMonths2) {
                planToUpdate2.rateGuaranteeMonths = latestguaranteeMonths2;
              }
            }
            this.lobAdded.set(this.selectedContractCode, this.selectedLOB);
            if (!this.submitOptions.find((x) => x === this.selectedLOB)) {
              this.submitOptions.push(this.selectedLOB);
            }
          }
          if (!this.errorFlag) {
            this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value
              ? this.soldRates_form.controls.ccCodeOverride.value
              : this.selectedContractCode;
            this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID).currentContractCode = this.selectedCurrentContractCode;
            this.updateCaseNumberByLobAndFT(this.selectedLOB, this.selectedFundingType, 'C');

            this.refreshData(false, true);
            this.updateRateGuaranteeMonths(this.rateGuarMonths, this.CCValue);
            this.updateRateEffDate(this.rateEffDate, this.CCValue);

            this.displayDialog = false;
            this.formReset();
          }
        } else {
          this.errorFlag = true;
          this.errorValue = "Entered Class already exists for the Category Code '" + this.dubEmpCats + "'";
        }
      }
    } else {
      if (!this.checkActiveExist()) this.errorValue = 'Please Select Employment Category Code Active to proceed';

      if (!this.selectedPlan) this.errorValue = 'Please Select Plan';

      if (!this.soldRates_form.controls.ccCodeOverride.value) this.errorValue = 'Please Enter Sold Contract Code to proceed';

      this.validateFormSaveCommon();

      this.errorFlag = true;
    }
    this.updateAdditionalProgramsAppliesTo();

  }
  }

  validateFormSaveCommon() {
    if (!this.soldRates_form.controls.caseNumber.value) this.errorValue = 'Please Enter Case Number to proceed';

    if (!this.selectedEmpCategory) this.errorValue = 'Please Select Employment Category Code';

    if (!this.selectedPlanType) this.errorValue = 'Please Select Plan Type';

    if (!this.selectedFundingType) this.errorValue = 'Please Select Sold Funding Type';

    if (!this.selectedLOB) this.errorValue = 'Please Select LOB';
    else if (!this.errorValue && !this.planRetireeValidation(false)) this.errorValue = SoldRatesConstants.RETIREE_VALIDATION_MSG;
  }

  saveQLISuppHealth() {
    if (
      this.selectedContractCodes &&
      this.selectedLOB &&
      this.selectedFundingType &&
      this.soldRates_form.controls.caseNumber.value &&
      this.soldRates_form.controls.ccCodeOverride.value &&
      this.selectedEmpCategory &&
      this.selectedEmpCategory.length > 0 &&
      this.checkActiveExistSuppHealth()
    ) {
      this.errorFlag = false;
      this.isCaseNoSaved = true;
      this.savedCaseNumber = this.soldRates_form.controls.caseNumber.value;
      if (!this.checkDubEmpCatExistSuppHealth()) {
        for (let empCat of this.selectedEmpCategory) {
          this.errorFlag = false;
          if (this.formData && this.formData.length > 0) {
            this.formData.forEach((selectedProduct, index) => {
              if (selectedProduct.employmentCategory) {
                let obj;
                if (this.soldRates_form.controls.classValue.value) {
                  obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB);
                } else {
                  obj = this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB);
                }
                this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).contractCode =
                  this.soldRates_form.controls.ccCodeOverride.value.split(', ')[index];
                this.updatedSoldRatePlan(obj, 'add', selectedProduct.ratingPlanID);
                this.soldCCvalueUpdated = this.soldCCvalue;

                if (selectedProduct.ageBandTierRates) {
                  let employmentCategoryCodeAgeBands = [];
                  const ageBandTierRates = selectedProduct.ageBandTierRates.sort((a, b) => a.ageBandStart - b.ageBandStart);
                  ageBandTierRates.forEach((ageBand) => {
                    let ageBands = JSON.parse(JSON.stringify(obj));
                    ageBands.ageBand = `${ageBand.ageBandStart}-${ageBand.ageBandEnd}`;
                    const tierRates = {
                      eeRate: this.roundValueToTwoDecimals(ageBand.eeRate * this.getEmpCategoryFactor(empCat)),
                      esRate: this.roundValueToTwoDecimals(ageBand.esRate * this.getEmpCategoryFactor(empCat)),
                      efRate: this.roundValueToTwoDecimals(ageBand.efRate * this.getEmpCategoryFactor(empCat)),
                      ecRate: this.roundValueToTwoDecimals(ageBand.ecRate * this.getEmpCategoryFactor(empCat)),
                      ekRate: this.roundValueToTwoDecimals(ageBand.ekRate * this.getEmpCategoryFactor(empCat))
                    };
                    ageBands.tierRate = tierRates;
                    employmentCategoryCodeAgeBands.push(ageBands);
                  });
                  this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).employmentCategory.push(...employmentCategoryCodeAgeBands);
                } else {
                  obj['tierRate'] = {};
                  obj.tierRate.eeRate = this.roundValueToTwoDecimals(
                    this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat)
                  );
                  obj.tierRate.esRate = this.roundValueToTwoDecimals(
                    this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat)
                  );
                  obj.tierRate.efRate = this.roundValueToTwoDecimals(
                    this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat)
                  );
                  obj.tierRate.ecRate = this.roundValueToTwoDecimals(
                    this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat)
                  );
                  obj.tierRate.ekRate = this.roundValueToTwoDecimals(
                    this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat)
                  );
                  this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).employmentCategory.push(obj);
                }
                // Update rateGuaranteeMonths and rateEffectiveDate for this plan
                const planToUpdate = this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID);
                const contractEndDate = planToUpdate?.rateEndDate;
                let latestEffDate = this.rateEffDate || planToUpdate.rateEffectiveDate;
                if (planToUpdate && latestEffDate && contractEndDate) {
                  planToUpdate.rateEffectiveDate = this.datepipe.transform(latestEffDate, 'MM/dd/yyyy');
                  const start = new Date(latestEffDate);
                  const end = new Date(contractEndDate);
                  planToUpdate.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
                }
                let latestGuaranteeMonths = this.rateGuarMonths || planToUpdate.rateGuaranteeMonths;
                if (planToUpdate && latestGuaranteeMonths) {
                  planToUpdate.rateGuaranteeMonths = latestGuaranteeMonths;
                }
              } else {
                let obj1;
                if (this.soldRates_form.controls.classValue.value) {
                  obj1 = [this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB)];
                } else {
                  obj1 = [this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB)];
                }
                this.selectedRatingPlanIdUpdate = '';
                this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).contractCode =
                  this.soldRates_form.controls.ccCodeOverride.value.split(', ')[index];
                this.updatedSoldRatePlan(obj1[0], 'add', selectedProduct.ratingPlanID);
                obj1.forEach((emplyCat) => {
                  emplyCat['tierRate'] = {};
                  if (selectedProduct.ageBandTierRates) {
                    const ageBands = selectedProduct.ageBandTierRates.sort((a, b) => a.ageBandStart - b.ageBandStart);
                    ageBands.forEach((ageBand, index) => {
                      const ageBandRange = `${ageBand.ageBandStart}-${ageBand.ageBandEnd}`;
                      const tierRates = {
                        eeRate: this.roundValueToTwoDecimals(ageBand.eeRate * this.getEmpCategoryFactor(empCat)),
                        esRate: this.roundValueToTwoDecimals(ageBand.esRate * this.getEmpCategoryFactor(empCat)),
                        efRate: this.roundValueToTwoDecimals(ageBand.efRate * this.getEmpCategoryFactor(empCat)),
                        ecRate: this.roundValueToTwoDecimals(ageBand.ecRate * this.getEmpCategoryFactor(empCat)),
                        ekRate: this.roundValueToTwoDecimals(ageBand.ekRate * this.getEmpCategoryFactor(empCat))
                      };
                      if (index === 0) {
                        emplyCat.ageBand = ageBandRange;
                        emplyCat.tierRate = tierRates;
                      } else {
                        let ageBandRow = JSON.parse(JSON.stringify(emplyCat));
                        ageBandRow.ageBand = ageBandRange;
                        ageBandRow.tierRate = tierRates;
                        obj1.push(ageBandRow);
                      }
                    });
                  } else {
                    emplyCat.tierRate.eeRate = this.roundValueToTwoDecimals(
                      this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat)
                    );
                    emplyCat.tierRate.esRate = this.roundValueToTwoDecimals(
                      this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat)
                    );
                    emplyCat.tierRate.efRate = this.roundValueToTwoDecimals(
                      this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat)
                    );
                    emplyCat.tierRate.ecRate = this.roundValueToTwoDecimals(
                      this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat)
                    );
                    emplyCat.tierRate.ekRate = this.roundValueToTwoDecimals(
                      this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat)
                    );
                  }
                });

                this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID).employmentCategory = obj1;
                // Update rateGuaranteeMonths and rateEffectiveDate for this plan (for new employmentCategory array)
                const planToUpdate2 = this.responseData.find((x) => x.ratingPlanID === selectedProduct.ratingPlanID);
                const contractEndDate2 = planToUpdate2?.rateEndDate;
                let latestEffDate2 = this.rateEffDate || planToUpdate2.rateEffectiveDate;
                if (planToUpdate2 && latestEffDate2 && contractEndDate2) {
                  planToUpdate2.rateEffectiveDate = this.datepipe.transform(latestEffDate2, 'MM/dd/yyyy');
                  const start = new Date(latestEffDate2);
                  const end = new Date(contractEndDate2);
                  planToUpdate2.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
                }
                let latestGuaranteeMonths2 = this.rateGuarMonths || planToUpdate2.rateGuaranteeMonths;
                if (planToUpdate2 && latestGuaranteeMonths2) {
                  planToUpdate2.rateGuaranteeMonths = latestGuaranteeMonths2;
                }
              }
              this.lobAdded.set(selectedProduct.quotedContractCode, this.selectedLOB);
            });
          }
        }
        if (!this.errorFlag) {
          this.selectedRatingPlanIDs.forEach((selectedRatingPlanID, index) => {
            this.responseData.find((plan) => plan.ratingPlanID === selectedRatingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value
              ? this.soldRates_form.controls.ccCodeOverride.value.split(', ')[index]
              : this.findContractCodeByRatingPlanID(this.selectedProducts, selectedRatingPlanID).contractCode;
          });

          this.selectedRatingPlanIDs.forEach((selectedRatingPlanID) => {
            this.responseData.find((plan) => plan.ratingPlanID === selectedRatingPlanID).currentContractCode = this.findContractCodeByRatingPlanID(
              this.selectedProducts,
              selectedRatingPlanID
            ).contractCode;
          });
          this.updateCaseNumberByLobAndFT(this.selectedLOB, this.selectedFundingType, 'C');

          this.refreshData(false, true);
          this.selectedContractCodes = this.CCCValue;
          console.log('Selected Contract Codes:', this.selectedContractCodes);
          this.updateRateEffDate(this.rateEffDate, this.CCValue);
          this.displayDialog = false;
          this.formReset();
        }
      } else {
        this.errorFlag = true;
        this.errorValue = "Entered Class already exists for the Category Code '" + this.dubEmpCats + "'";
      }
    } else {
      if (!this.checkActiveExistSuppHealth()) this.errorValue = 'Please Select Employment Category Code Active to proceed';
      if (this.selectedProducts && this.selectedProducts.length === 0) this.errorValue = 'Please Select Products';
      if (!this.soldRates_form.controls.ccCodeOverride.value) this.errorValue = 'Please Enter Sold Contract Code to proceed';
      this.validateFormSaveCommon();

      this.errorFlag = true;
    }
    this.updateAdditionalProgramsAppliesTo();
    if (!this.submitOptions.find((x) => x === RareConstants.suppHealth)) {
      this.submitOptions.push(RareConstants.suppHealth);
    }
  }

  findContractCodeByRatingPlanID(selectedProducts: any[], ratingPlanID: string) {
    return selectedProducts.find((selectedProduct) => selectedProduct.ratingPlanID === ratingPlanID);
  }
  omit_special_char = (event) => {
    var k;
    k = event.charCode;
    return (k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57);
  }

  onPaste = (event: ClipboardEvent) => {
    event.preventDefault();
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    let trimmedText = pastedText.replace(/[^a-zA-Z0-9]/g, '');
    let inputElement = <HTMLInputElement>(
      document.getElementById('caseNumber') || 
      document.getElementById('caseNumberUpdate')
    );
    if (inputElement) {
    inputElement.value = trimmedText;
    this.caseNumber = trimmedText;
    }
  }

  updateCaseNumberByLobAndFT(lob, FT, type) {
    for (let resp of this.responseData) {
      if (lob === resp.lob && FT === resp.fundingType) {
        if (type === 'C') resp['caseNumber'] = this.soldRates_form.controls.caseNumber.value;
        else if (type === 'U') {
          resp['caseNumber'] = this.soldRates_form.controls.caseNumberUpdate.value;
          this.soldRateFullResponse.caseNumber = this.soldRates_form.controls.caseNumberUpdate.value;
        }
      }
    }
  }

  prepareRemoveObj(selectedRow, selectedEmpCat) {
    var rowObj = {
      quotedContractCode: selectedRow.quotedContractCode,
      contractCode: selectedRow.contractCode,
      lob: selectedRow.lob,
      fundingType: selectedRow.fundingType,
      emplymntCtgryCd: selectedEmpCat.emplymntCtgryCd,
      employmentClassCode: selectedEmpCat.employmentClassCode
    };
    this.contractCodeRemove = selectedRow.quotedContractCode;
    return rowObj;
  }

  addRowToRemove(selectedRow, selectedEmpCat, event) {
    // Dynamic group-level removal logic
    if (this.isGroupLevelProgramType(selectedRow.programType)) {
      if (event.target.checked) {
        if (!this.selectedGroupProgramsToRemove.includes(selectedRow)) {
          this.selectedGroupProgramsToRemove.push(selectedRow);
        }
      } else {
        const idx = this.selectedGroupProgramsToRemove.indexOf(selectedRow);
        if (idx > -1) this.selectedGroupProgramsToRemove.splice(idx, 1);
      }
      return;
    }
    const planLevelRow = {
      quotedContractCode: selectedRow.quotedContractCode,
      contractCode: selectedRow.contractCode,
      lob: selectedRow.lob,
      fundingType: selectedRow.fundingType,
      emplymntCtgryCd: selectedEmpCat.emplymntCtgryCd,
      employmentClassCode: selectedEmpCat.employmentClassCode,
      wgsSubGroupNumber: selectedEmpCat.wgsSubGroupNumber,
      isAdditionalProduct: selectedRow.isAdditionalProduct
    };
    if (event.target.checked) {
      // Add if not already present
      const exists = this.selectedRowsToRemove.some(row =>
        row.quotedContractCode === planLevelRow.quotedContractCode &&
        row.fundingType === planLevelRow.fundingType &&
        row.lob === planLevelRow.lob &&
        row.emplymntCtgryCd === planLevelRow.emplymntCtgryCd &&
        row.employmentClassCode === planLevelRow.employmentClassCode &&
        row.wgsSubGroupNumber === planLevelRow.wgsSubGroupNumber &&
        row.isAdditionalProduct === planLevelRow.isAdditionalProduct
      );
      if (!exists) {
        this.selectedRowsToRemove.push(planLevelRow);
      }
    } else {
      // Remove if present
      for (let i = 0; i < this.selectedRowsToRemove.length; i++) {
        const row = this.selectedRowsToRemove[i];
        if (
          row.quotedContractCode === planLevelRow.quotedContractCode &&
          row.fundingType === planLevelRow.fundingType &&
          row.lob === planLevelRow.lob &&
          row.emplymntCtgryCd === planLevelRow.emplymntCtgryCd &&
          row.employmentClassCode === planLevelRow.employmentClassCode &&
          row.wgsSubGroupNumber === planLevelRow.wgsSubGroupNumber
        ) {
          this.selectedRowsToRemove.splice(i, 1);
          break;
        }
      }
    }
  }

  removeRows() {
    // Remove from all group-level programs dynamically
    if (Array.isArray(this.selectedGroupProgramsToRemove) && this.selectedGroupProgramsToRemove.length > 0 && Array.isArray(this.submittedTransitionData)) {
      this.submittedTransitionData = this.submittedTransitionData.filter(item => !this.selectedGroupProgramsToRemove.includes(item));
      this.selectedGroupProgramsToRemove = [];
    }
    // Existing Plan Level Info logic
    this.planTypesAdditional = [];
    for (let j = 0; j < this.selectedRowsToRemove.length; j++) {
      if(!this.selectedRowsToRemove[j].isAdditionalProduct) {
      for (let i = 0; i < this.responseData.length; i++) {
        const plan = this.responseData[i];
        const selectedRow = this.selectedRowsToRemove[j];
        if (plan && selectedRow) {
          if (
            StringUtils.isEqualIgnoreCase(selectedRow.quotedContractCode, plan.quotedContractCode) &&
            StringUtils.isEqualIgnoreCase(selectedRow.fundingType, plan.fundingType) &&
            StringUtils.isEqualIgnoreCase(selectedRow.lob, plan.lob)
          ) {
            if (Array.isArray(plan.employmentCategory)) {
              const before = plan.employmentCategory.length;
              plan.employmentCategory = plan.employmentCategory.filter(ec => {
                const match = (
                  selectedRow.emplymntCtgryCd === ec.emplymntCtgryCd &&
                  selectedRow.employmentClassCode === ec.employmentClassCode &&
                  (selectedRow.wgsSubGroupNumber === undefined || selectedRow.wgsSubGroupNumber === ec.wgsSubGroupNumber)
                );
                return !match;
              });
            }
            if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical)) {
              let key = plan.contractCodePlanName + '|' + selectedRow.emplymntCtgryCd;
              if (this.mapOfContractCodeAndAdditionalProgram && this.mapOfContractCodeAndAdditionalProgram.has(key)) {
                this.mapOfContractCodeAndAdditionalProgram.delete(key);
              }
              this.getIncludeInRates(plan.fundingType);
              if (Array.isArray(plan.employmentCategory)) {
                plan.employmentCategory.forEach(ec => {
                  this.planTypesAdditional.push({
                    label: ec.contractCodePlanName,
                    value: ec.contractCodePlanName
                  });
                });
              }
            }
            if (Array.isArray(plan.employmentCategory) && plan.employmentCategory.length === 0) {
              plan.planIsRemoved = true;
              plan.additionalPrograms = null;
              if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical)) {
                if (!this.medActiveRemoved) this.medActiveRemoved = new Map<string, boolean>();
                this.medActiveRemoved.set(plan.quotedContractCode, true);
                if (this.lobAdded) this.lobAdded.delete(CommonConstants.Medical);
              } else if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.vision)) {
                if (!this.visActiveRemoved) this.visActiveRemoved = new Map<string, boolean>();
                this.visActiveRemoved.set(plan.quotedContractCode, true);
                if (this.lobAdded) this.lobAdded.delete(CommonConstants.Vision);
              } else if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.dental)) {
                if (!this.denActiveRemoved) this.denActiveRemoved = new Map<string, boolean>();
                this.denActiveRemoved.set(plan.quotedContractCode, true);
                if (this.lobAdded) this.lobAdded.delete(CommonConstants.Dental);
              } else if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.suppHealth)) {
                if (!this.shpActiveRemoved) this.shpActiveRemoved = new Map<string, boolean>();
                this.shpActiveRemoved.set(plan.quotedContractCode, true);
                if (this.lobAdded) this.lobAdded.delete(RareConstants.suppHealth);
              }
            }
          }
        }
      }
    }
    else {
      for (let i = 0; i < this.rowData.length; i++) {
        const plan = this.rowData[i];
        const selectedRow = this.selectedRowsToRemove[j];
        if (plan && selectedRow) {
          if ( selectedRow.isAdditionalProduct &&
            StringUtils.isEqualIgnoreCase(selectedRow.contractCode, plan.contractCode) &&
            StringUtils.isEqualIgnoreCase(selectedRow.fundingType, plan.fundingType) &&
            StringUtils.isEqualIgnoreCase(selectedRow.lob, plan.lob)
          ) {
            if (Array.isArray(plan.employmentCategory)) {
              plan.employmentCategory = plan.employmentCategory.filter(ec => {
                const match = (
                  selectedRow.emplymntCtgryCd === ec.emplymntCtgryCd &&
                  selectedRow.employmentClassCode === ec.employmentClassCode
                );
                return !match;
              });
            }
            // Remove from additionalProductDataObj
            if (Array.isArray(this.additionalProductDataObj)) {
              this.additionalProductDataObj = this.additionalProductDataObj.filter(obj => {
                return !(
                  obj.isAdditionalProduct &&
                  StringUtils.isEqualIgnoreCase(obj.contractCode, selectedRow.contractCode) &&
                  StringUtils.isEqualIgnoreCase(obj.fundingType, selectedRow.fundingType) &&
                  StringUtils.isEqualIgnoreCase(obj.lob, selectedRow.lob) &&
                  obj.productName === selectedRow.productName
                );
              });
            }
          }
        }
      }
    }
  }
    this.updateAdditionalProgramsAppliesTo();
    this.updateSubmitOptionsAfterRemove();
    this.formReset();
    this.removeQuotedLOBFormAddProducts(this.lobValuesForAddProduct);
    this.selectedRowsToRemove = [];
    // After removing, if all plan-level info rows are gone, clear rowData and empCategory, and update hasPlanLevelInfo
    const hasPlanLevelRows = Array.isArray(this.rowData) && this.rowData.some(plan => plan.employmentCategory && plan.employmentCategory.length > 0);
    if (!hasPlanLevelRows) {
      this.rowData = [];
      this.empCategory = [];
      this.updateHasPlanLevelInfo();
    }
  }

  updateSubmitOptionsAfterRemove() {
    this.submitOptions = [];
    this.rowData.forEach(plan => {
      if (plan.employmentCategory.length > 0) {
        if (!this.submitOptions.find((x) => x === plan.lob)) {
          this.submitOptions.push(plan.lob);
        }
      }
    });
    this.rowData = this.rowData.filter(plan => plan.employmentCategory.length > 0);

  }

  updateAdditionalProgramsAppliesTo() {
    this.planTypesAdditional = [];
    for (let p of this.rowData) {
      if (p.employmentCategory.length > 0 && StringUtils.isEqualIgnoreCase(p.lob, RareConstants.medical)) {
        this.getIncludeInRates(p.fundingType);
        this.planTypesAdditional.push({
          label: p.contractCodePlanName,
          value: p.contractCodePlanName
        });
      }
    }
  }

  // update
  displayDialogUpdate: boolean = false;
  disableUpdate: boolean = false;
  errorFlagUpdate: boolean = false;
  categoryListUpdate: any[] = [];
  planValueUpdate;
  planValueUpdateX;
  lobUpdate;
  CCValueUpdate;
  CCCValueUpdate;
  soldCCvalueUpdated;
  soldCCvalue;
  staticContractcode;
  empCatValueUpdate;
  empCatValueUpdateX;
  errorValueUpdate;
  formDataUpdate;
  empCategoryDataUpdate;
  empCategoryFactorUpdate;
  employmentClassCodeX;
  selectCCValueUpdate;
  fundingTypeUpdate;
  ratingPlanIdUpdate;
  selectCCCValueUpdate;
  // Added for tracking previous values for update logic
  prevRateEffectiveDate: string | null = null;
  prevRateGuarMonths: string | number | null = null;

  findRatingPlanID(contractCode, planName, lob, fundType) {
    return this.responseData.find((x) => x.quotedContractCode === contractCode && x.productName === planName && x.lob === lob && x.fundingType === fundType)
      .ratingPlanID;
  }

  getRatesByCCCUpdate(contract) {
    this.selectedCurrentContractCode = contract.value;
    this.selectCCCValueUpdate = contract.value;
  }

  showDialogToUpdate(SelectedRow, SelectedEmpCat) {
    this.formReset();
    this.refreshPlanDropdown();
    this.errorFlagUpdate = false;
    this.errorValueUpdate = null;

    this.selectPlanValueUpdate = SelectedRow.productName;
    this.rateEffDate = this.parseMMDDYYYYtoDate(SelectedRow.rateEffectiveDate);
    this.soldCCvalueUpdated = SelectedRow.contractCode ? SelectedRow.contractCode : SelectedRow.quotedContractCode;
    this.rateGuarMonths = SelectedRow.rateGuaranteeMonths;
    this.planValueUpdate = {
      quotedContractCode: SelectedRow.quotedContractCode,
      productName: this.selectPlanValueUpdate,
      contractCode: this.soldCCvalueUpdated
    };

    this.planValueUpdateX = SelectedRow.quotedContractCode;
    this.lobUpdate = SelectedRow.lob;
    this.fundingTypeUpdate = SelectedRow.fundingType;
    this.CCValueUpdate = {
      label: SelectedRow.quotedContractCode,
      value: SelectedRow.quotedContractCode
    };
    if (this.isMedicalRenewalLocalPresent && StringUtils.isEqualIgnoreCase(this.lobUpdate, RareConstants.medical)) {
      if (StringUtils.isEmpty(SelectedRow.currentContractCode)) {
        this.CCCValueUpdate = '';
        this.selectedCurrentContractCode = '';
      } else {
        this.soldRateFullResponse.currentPlans.forEach((soldRateFullResponseCurrentPlans) => {
          if (soldRateFullResponseCurrentPlans.contractCode == SelectedRow.currentContractCode) {
            this.CCCValueUpdate = {
              label: soldRateFullResponseCurrentPlans.planName,
              value: SelectedRow.currentContractCode
            };
          }
        });
        this.selectedCurrentContractCode = this.CCCValueUpdate?.value;
      }
      this.selectCCCValueUpdate = SelectedRow?.currentContractCode;
    }
    if(SelectedRow.isAdditionalProduct) {
      this.productNameUpdate = SelectedRow.productName;
      this.soldContractCodeUpdate = SelectedRow.contractCode ? SelectedRow.contractCode : '';
      this.classCodeUpdate = SelectedRow.employmentCategory[0].employmentClassCode ? SelectedRow.employmentCategory[0].employmentClassCode : '';
      this.empCatValueUpdate = SelectedRow.employmentCategory[0].emplymntCtgryCd ? SelectedRow.employmentCategory[0].emplymntCtgryCd : '';
      this.rateEffDateUpdate =  this.parseMMDDYYYYtoDate(SelectedRow.rateEffectiveDate) ?  this.parseMMDDYYYYtoDate(SelectedRow.rateEffectiveDate) : '';
      this.rateGuarMonthsUpdate = SelectedRow.rateGuaranteeMonths ? SelectedRow.rateGuaranteeMonths : '';
      
      // Get contract effective date from the quote level since plans don't have contractEffDate
      const quoteForLOB = this.soldRateFullResponse?.data?.quotes?.find(quote => quote.lob === SelectedRow.lob);
      const contractDate = quoteForLOB?.contractEffectiveDate || SelectedRow?.contractEffDate;
      this.contractEffDateUpdate = this.parseMMDDYYYYtoDate(this.datepipe.transform(contractDate, 'MM/dd/yyyy'));
      this.formDataUpdateForAddProduct = SelectedEmpCat;
      
      // Store saved rate type and unit type for update dialog
      // Infer rate type from data if not explicitly saved by backend
      let inferredRateType = 'Tiered';
      if (SelectedEmpCat && SelectedEmpCat.tierRate) {
        const hasCompositeRate = SelectedEmpCat.tierRate.compositeRate != null && SelectedEmpCat.tierRate.compositeRate !== '';
        const hasTierRates = SelectedEmpCat.tierRate.eeRate != null || SelectedEmpCat.tierRate.esRate != null;
        if (hasCompositeRate && !hasTierRates) {
          inferredRateType = 'Composite';
        }
      }
      
      this.savedRateTypeForUpdate = SelectedRow.rateType || inferredRateType;
      this.savedUnitTypeForUpdate = SelectedRow.unitType || 'PCPM';
      this.categoryList = CommonUtil.getSortedList(this.getCategoryList(RareConstants.medical, 'A'));
      this.additionalCategoryList.push(...this.categoryList.map(category => category.label));
      if(this.additionalProductDataObj.length === 0) {
        this.addlproductemptyObj = this.additionalProductDataObj;
        this.additionalProductDataObj = this.rowData.filter(plan => plan.isAdditionalProduct);
      }
      this.displayDialogUpdateForAddProduct = true;
    } else {
    this.displayDialogUpdate = true;
    this.empCatValueUpdate = SelectedEmpCat.emplymntCtgryCd;
    this.empCatValueUpdateX = SelectedEmpCat.emplymntCtgryCd;
    this.selectedRatingPlanIdUpdate = this.ratingPlanIdUpdate = this.findRatingPlanID(
      SelectedRow.quotedContractCode,
      SelectedRow.productName,
      SelectedRow.lob,
      SelectedRow.fundingType
    );
    this.categoryListUpdate = [];
    this.categoryListUpdate = this.getCategoryList(this.lobUpdate, 'U');

    this.getCategoryUpdate(this.empCatValueUpdate);
    }
    this.selectCCValueUpdate = SelectedRow.quotedContractCode;
    this.empCatValueUpdate = SelectedEmpCat.emplymntCtgryCd;
    this.empCatValueUpdateX = SelectedEmpCat.emplymntCtgryCd;
    this.employmentClassCodeX = SelectedEmpCat.employmentClassCode;
    this.soldRates_form.controls.caseNumberUpdate.setValue(SelectedRow.caseNumber);
    this.caseNumberUpdate = SelectedRow.caseNumber;
    if (SelectedEmpCat.employmentClassCode) this.soldRates_form.controls.classValueUpdate.setValue(SelectedEmpCat.employmentClassCode);
    else this.soldRates_form.controls.classValueUpdate.setValue('');

    if (this.empCatValueUpdate.toLowerCase() === 'active') {
      this.disableUpdate = true;
    } else {
      this.disableUpdate = false;
    }


  }
  selectPlanValueUpdate;

  getRatesUpdate(value) {
    this.selectPlanValueUpdate = this.getPlanName(this.planName, value);
    let contractData = this.getPlanData(this.responseData, value);
    this.lobUpdate = contractData.lob;
    this.CCValueUpdate = {
      label: contractData.quotedContractCode,
      value: contractData.quotedContractCode
    };
    this.soldCCvalueUpdated = contractData.quotedContractCode;
    this.selectCCValueUpdate = this.CCValueUpdate.value;
    this.empCatValueUpdate = '';

    let empCat = this.getPlanData(this.responseData, this.selectCCValueUpdate);
    if (!empCat.employmentCategory || empCat.employmentCategory.length === 0) {
      this.categoryListUpdate = [];
      this.categoryListUpdate.push('Active');
    } else {
      this.categoryListUpdate = [];
      this.categoryListUpdate = this.getCategoryList(this.lobUpdate, 'U');
    }
  }

  getRatesByCCUpdate(value) {
    this.CCValueUpdate = value;
    this.soldCCvalueUpdated = value;
    this.selectCCValueUpdate = this.CCValueUpdate.value;
    let planData = this.getPlanData(this.responseData, this.selectCCValueUpdate);
    this.lobUpdate = planData.lob;
    this.selectPlanValueUpdate = planData.productName || '';
    this.planValueUpdate = {
      quotedContractCode: this.CCValueUpdate.value,
      contractCode: this.soldCCvalueUpdated,
      productName: this.selectPlanValueUpdate
    };
    this.empCatValueUpdate = '';
  }

  getCategoryUpdate(value) {
    this.empCatValueUpdate = value;
    this.errorFlagUpdate = false;
    this.formDataUpdate = this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate);
    if (this.lobUpdate.toLowerCase() === RareConstants.medicalLC && this.soldRateFullResponse.employmentCategoryMedical) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategoryMedical.find((x) => x.emplymntCtgryCd === value);
    }

    if (this.lobUpdate.toLowerCase() === RareConstants.visionLC && this.soldRateFullResponse.employmentCategoryVision) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategoryVision.find((x) => x.emplymntCtgryCd === value);
    }

    if (this.lobUpdate.toLowerCase() === RareConstants.dentalLC && this.soldRateFullResponse.employmentCategoryDental) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategoryDental.find((x) => x.emplymntCtgryCd === value);
    }

    if (StringUtils.isEqualIgnoreCase(this.lobUpdate, RareConstants.suppHealth) && this.soldRateFullResponse.employmentCategorySuppHealth) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategorySuppHealth.find((x) => x.emplymntCtgryCd === value);
    }

    this.empCategoryFactorUpdate = this.empCategoryDataUpdate?.emplymntCtgryFctr;
  }

  isplanEmpCatExists(planEmpCat) {
    return planEmpCat.find(
      (x) =>
        x.emplymntCtgryCd === this.empCatValueUpdate &&
        x.employmentClassCode.toLowerCase() === this.soldRates_form.controls.classValueUpdate.value.toLowerCase()
    );
  }

  updateQLI() {
    this.errorFlagUpdate = false;
    this.errorValueUpdate = null;
    const plantoupdate = this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate);
    // const rateEffectiveDate = plantoupdate?.rateEffectiveDate;
    const rateEffectiveDate = this.updateRateEffDateOnEdit;
    const rateEndDate = plantoupdate?.rateEndDate;
    let latestGuaranteeMonths = plantoupdate?.rateGuaranteeMonths;

    // If rate effective date is changed, recalculate rate guarantee months
    if (
      plantoupdate &&
      typeof rateEffectiveDate !== 'undefined' &&
      rateEffectiveDate !== null &&
      rateEndDate &&
      (this.prevRateEffectiveDate !== rateEffectiveDate)
    ) {
      // Calculate and update rateGuaranteeMonths
      const start = new Date(rateEffectiveDate);
      const end = new Date(rateEndDate);
      plantoupdate.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
      this.prevRateEffectiveDate = rateEffectiveDate;
    }

    // If rate guarantee months is changed, recalculate rate end date
    if (
      plantoupdate &&
      typeof latestGuaranteeMonths !== 'undefined' &&
      latestGuaranteeMonths !== null &&
      latestGuaranteeMonths !== '' &&
      (this.prevRateGuarMonths !== this.rateGuarMonths)
    ) {
      plantoupdate.rateEffectiveDate = this.datepipe.transform(this.updateRateEffDateOnEdit, 'MM/dd/yyyy');
      plantoupdate.rateGuaranteeMonths = this.rateGuarMonths;
      // Only update rateEndDate if months changed
      if (rateEffectiveDate && this.rateGuarMonths) {
        const effDate = new Date(rateEffectiveDate);
        // months may be string, ensure number
        const monthsNum = typeof this.rateGuarMonths === 'string' ? parseInt(this.rateGuarMonths, 10) : Number(this.rateGuarMonths);
        if (!isNaN(monthsNum) && monthsNum > 0) {
          const newEndDate = this.commonQuoteService.calculateRateEndDate(effDate, monthsNum);
          plantoupdate.rateEndDate = this.datepipe.transform(newEndDate, 'MM/dd/yyyy');
          this.prevRateGuarMonths = Number(this.rateGuarMonths);
        }
      }
    }
    if (this.CCValueUpdate && this.lobUpdate && this.empCatValueUpdate && this.caseNumberUpdate && this.soldCCvalueUpdated) {
      this.isCaseNoSaved = true;
      this.savedCaseNumber = this.caseNumberUpdate;
      if (
        this.isMedicalRenewalLocalPresent &&
        StringUtils.isEqualIgnoreCase(this.lobUpdate, RareConstants.medical) &&
        StringUtils.isEmpty(this.CCCValueUpdate)
      ) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = SoldRatesConstants.CURRENT_PLAN_SELECT_MSG;
        return;
      }
      let obj;
      let obj1;
      if (this.soldRates_form.controls.classValueUpdate.value) {
        obj = this.prepareEmpCatObj(this.empCatValueUpdate, 'C', this.soldRates_form.controls.classValueUpdate.value, this.lobUpdate);
        obj1 = [this.prepareEmpCatObj(this.empCatValueUpdate, 'C', this.soldRates_form.controls.classValueUpdate.value, this.lobUpdate)];
      } else {
        obj = this.prepareEmpCatObj(this.empCatValueUpdate, 'WC', '', this.lobUpdate);
        obj1 = [this.prepareEmpCatObj(this.empCatValueUpdate, 'WC', '', this.lobUpdate)];
      }
      this.selectedRatingPlanIdUpdate = '';
      let isplanEmpCatClassCodeExists = [];
      let planEmpCat = this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory;
      if (!this.errorFlagUpdate && !this.planRetireeValidation(true)) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = SoldRatesConstants.RETIREE_VALIDATION_MSG;
        return;
      }

      if (planEmpCat) {
        obj['tierRate'] = {};
        const product = this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate);

        if (product.tierRate) {
          obj['tierRate'].eeRate = this.roundValueToTwoDecimals(product.tierRate.eeRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate));
          obj['tierRate'].esRate = this.roundValueToTwoDecimals(product.tierRate.esRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate));
          obj['tierRate'].efRate = this.roundValueToTwoDecimals(product.tierRate.efRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate));
          obj['tierRate'].ecRate = this.roundValueToTwoDecimals(product.tierRate.ecRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate));
          obj['tierRate'].ekRate = this.roundValueToTwoDecimals(product.tierRate.ekRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate));
        }

        obj1.forEach((ele) => {
          if (ele.emplymntCtgryCd === this.empCatValueUpdate) {
            ele['tierRate'] = {};
            const productUpdate = this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate);
            if (productUpdate.tierRate) {
              ele['tierRate'].eeRate = this.roundValueToTwoDecimals(
                productUpdate.tierRate.eeRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate)
              );
              ele['tierRate'].esRate = this.roundValueToTwoDecimals(
                productUpdate.tierRate.esRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate)
              );
              ele['tierRate'].efRate = this.roundValueToTwoDecimals(
                productUpdate.tierRate.efRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate)
              );
              ele['tierRate'].ecRate = this.roundValueToTwoDecimals(
                productUpdate.tierRate.ecRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate)
              );
              ele['tierRate'].ekRate = this.roundValueToTwoDecimals(
                productUpdate.tierRate.ekRate * this.getEmpCategoryFactor(this.empCatValueUpdate, this.lobUpdate)
              );
            }
          }
        });
        // Ensure submitOptions is rebuilt from filtered rowData, not responseData
        this.updateSubmitOptionsAfterRemove();

        this.updatedSoldRatePlan(obj, 'update', this.ratingPlanIdUpdate);
        isplanEmpCatClassCodeExists = planEmpCat.filter((x) => x.emplymntCtgryCd === obj.emplymntCtgryCd && x.employmentClassCode === obj.employmentClassCode);
        let isExistingClassCode = planEmpCat.find((x) => x.employmentClassCode === obj.employmentClassCode);
        if (isplanEmpCatClassCodeExists.length && this.employmentClassCodeX !== this.soldRates_form.controls.classValueUpdate.value) {
          this.errorFlagUpdate = true;
          this.errorValueUpdate = 'Given Employment Category Code with given classcode already exists';
          return;
        } else {
          if (!isExistingClassCode && obj.emplymntCtgryCd === 'Active') {
            if (planEmpCat.find((x) => x.employmentClassCode === this.employmentClassCodeX && x.emplymntCtgryCd === obj.emplymntCtgryCd)) {
              for (let num = 0; num < planEmpCat.length; num++) {
                if (planEmpCat[num].employmentClassCode === this.employmentClassCodeX) {
                  planEmpCat[num].employmentClassCode = this.soldRates_form.controls.classValueUpdate.value;
                }
              }
            }
          } else if (!isExistingClassCode && obj.emplymntCtgryCd !== 'Active') {
            if (planEmpCat.find((x) => x.employmentClassCode === this.employmentClassCodeX && x.emplymntCtgryCd === obj.emplymntCtgryCd)) {
              for (let num = 0; num < planEmpCat.length; num++) {
                if (planEmpCat[num].employmentClassCode === this.employmentClassCodeX) {
                  planEmpCat[num].employmentClassCode = this.soldRates_form.controls.classValueUpdate.value;
                }
              }
            } else {
              this.errorFlagUpdate = true;
              this.errorValueUpdate = 'Please Select Employment Category Code Active to proceed';
              return;
            }
          } else {
            for (let num = 0; num < planEmpCat.length; num++) {
              if (planEmpCat[num].employmentClassCode === this.employmentClassCodeX && planEmpCat[num].emplymntCtgryCd === obj.emplymntCtgryCd) {
                planEmpCat[num].employmentClassCode = this.soldRates_form.controls.classValueUpdate.value;
              }
            }
            if (
              this.isMedicalRenewalLocalPresent &&
              this.lobUpdate == 'Medical' &&
              planEmpCat.find((planEmpCat) => planEmpCat.emplymntCtgryCd === obj.emplymntCtgryCd)
            )
              planEmpCat.find((planEmpCat) => planEmpCat.emplymntCtgryCd === obj.emplymntCtgryCd).enrollments = obj?.enrollments;
          }
        }
      }

      //Handle Scenario - If plan is removed and without save and then same plan is added
      this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).planIsRemoved = false;

      if (this.isplanEmpCatExists(planEmpCat)) {
        if (
          this.soldCCvalueUpdated &&
          this.soldRates_form.controls.ccCodeOverrideUpdate.value &&
          this.soldCCvalueUpdated === this.soldRates_form.controls.ccCodeOverrideUpdate.value
        ) {
          this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).contractCode = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
          if (this.isMedicalRenewalLocalPresent && StringUtils.isEqualIgnoreCase(this.lobUpdate, RareConstants.medical))
            this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).currentContractCode = this.CCCValueUpdate?.value;
          this.updateCaseNumberByLobAndFT(this.lobUpdate, this.fundingTypeUpdate, 'U');
          this.displayDialogUpdate = false;
          this.refreshData(false, true);
          this.refreshPlanDropdown();
        } else if (!this.soldRates_form.controls.ccCodeOverrideUpdate.value) {
          this.responseData.find((x) => x.contractCode !== this.soldCCvalueUpdated).contractCode = null;
          this.updateCaseNumberByLobAndFT(this.lobUpdate, this.fundingTypeUpdate, 'U');
          this.displayDialogUpdate = false;
          this.refreshData(false, true);
          this.refreshPlanDropdown();
        } else {
          this.errorFlagUpdate = true;
          this.errorValueUpdate = 'Given Employment Category Code is already exists';
          this.displayDialogUpdate = true;
        }
      } else {
        if (this.soldRates_form.controls.ccCodeOverrideUpdate.value && this.soldCCvalueUpdated !== this.soldRates_form.controls.ccCodeOverrideUpdate.value) {
          this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).contractCode = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
          this.selectCCValueUpdate = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
          this.planValueUpdateX = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
        }
        if (planEmpCat) {
          this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory.push(obj);
        } else {
          this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory = obj1;
        }
        let planEmpCatX = this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory;
        let isplanEmpCatExistsX = planEmpCatX.find((x) => x.emplymntCtgryCd === this.empCatValueUpdateX && x.employmentClassCode === this.employmentClassCodeX);

        if (isplanEmpCatExistsX) {
          for (var i = 0; i < planEmpCatX.length; i++) {
            if (planEmpCatX[i].emplymntCtgryCd == this.empCatValueUpdateX && planEmpCatX[i].employmentClassCode == this.employmentClassCodeX) {
              this.responseData.find((x) => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory.splice(i, 1);
            }
          }
        }
        if (
          this.mapOfContractCodeAndSelectedEmpCategories &&
          this.mapOfContractCodeAndSelectedEmpCategories.has(this.soldRates_form.controls.ccCodeOverrideUpdate.value) &&
          this.lobUpdate === 'Medical'
        ) {
          let employmentCategoryList = this.mapOfContractCodeAndSelectedEmpCategories.get(this.soldRates_form.controls.ccCodeOverrideUpdate.value);
          let index = employmentCategoryList.indexOf(this.empCatValueUpdateX);
          employmentCategoryList.splice(index, 1);
          employmentCategoryList.push(this.empCatValueUpdate);
          this.mapOfContractCodeAndSelectedEmpCategories.delete(this.soldRates_form.controls.ccCodeOverrideUpdate.value);
          this.mapOfContractCodeAndSelectedEmpCategories.set(
            JSON.parse(JSON.stringify(this.soldRates_form.controls.ccCodeOverrideUpdate.value)),
            JSON.parse(JSON.stringify(employmentCategoryList))
          );
        }
        this.updateCaseNumberByLobAndFT(this.lobUpdate, this.fundingTypeUpdate, 'U');
        this.refreshData(false, true);
        this.refreshPlanDropdown();
        this.displayDialogUpdate = false;
      }
    } else {
      if (!this.caseNumberUpdate) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = 'Please Enter Case Number';
      }
      if (!this.soldCCvalueUpdated) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = 'Please Enter Contract Code';
      }
    }
  }
  // update

  errorFlag: boolean = false;
  additionalProgramErrorFlag: boolean = false;
  dataReset() {
    this.formData = null;
    this.empCategoryData = null;
    this.empCategoryFactor = 1;
    this.selectedEmpCategory = null;
  }
  formReset() {
    this.contractCodes = this.contractCodeBackup;
    this.planName = this.planNamesBackup;
    this.selectedPlan = null;
    this.selectedLOB = '';
    this.selectedPlanType = '';
    this.selectedRatingPlanID = '';
    this.selectedFundingType = '';
    this.selectedContractCode = null;
    this.formData = null;
    this.empCategoryData = null;
    this.empCategoryFactor = 1;
    this.selectedEmpCategory = null;
    this.planValue = '';
    this.CCValue = '';
    this.CCCValue = '';
    this.errorFlag = false;
    this.soldRates_form.controls.classValue.setValue('');
    this.soldRates_form.controls.ccCodeOverride.setValue('');
    this.soldRates_form.controls.caseNumber.setValue('');
    this.caseNumber = '';
    this.selectedRatingPlanIdUpdate = '';
    this.selectedProducts = null;
    this.selectedContractCodes = null;
    this.selectedRatingPlanIDs = null;
    this.enrollmentValidationErrors = {};
    this.isEnrollmentTotalMismatch = false;
  }

  preparePlanData(selectedPlan, planType, currentDate, selectedRatingPlanId) {
    let quotedContractCode;
    let contractCode, currentContractCode;
    if (planType !== 'Remove') {
      if (this.CCValue.value) quotedContractCode = this.CCValue.value;
      else if (this.CCValueUpdate) quotedContractCode = this.CCValueUpdate.value;
      else quotedContractCode = this.contractCodeRemove;
      if (this.soldRates_form.controls.ccCodeOverride.value) contractCode = this.soldRates_form.controls.ccCodeOverride.value;
      else if (this.soldCCvalueUpdated) contractCode = this.soldCCvalueUpdated;
      else contractCode = quotedContractCode;
      if (this.CCCValue.value) currentContractCode = this.CCCValue.value;
      else if (this.CCCValueUpdate) currentContractCode = this.CCCValueUpdate.value;
      else currentContractCode = this.contractCodeRemove;
    } else {
      quotedContractCode = selectedPlan.quotedContractCode;
      contractCode = selectedPlan.contractCode;
      currentContractCode = selectedPlan?.currentContractCode;
    }
    return {
      performedTime: currentDate,
      currentContractCode: currentContractCode ? currentContractCode : '',
      quotedContractCode: quotedContractCode ? quotedContractCode : '',
      empcategorycode: selectedPlan.emplymntCtgryCd ? selectedPlan.emplymntCtgryCd : '',
      empClass: selectedPlan.employmentClassCode ? selectedPlan.employmentClassCode : '',
      LOB: this.selectedLOB ? this.selectedLOB : this.lobUpdate ? this.lobUpdate : this.lob,
      action: planType,
      contractCode: contractCode ? contractCode : quotedContractCode,
      caseNumber: this.caseNumber ? this.caseNumber : this.caseNumberUpdate ? this.caseNumberUpdate : '',
      ratingPlanId: selectedRatingPlanId
    };
  }

  updatedSoldRatePlan(selectedPlan, planType, ratingPlanID) {
    let today = new Date();
    const getDate = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    let currentDate = getDate + ' ' + time;
    if (planType == 'add') {
      this.selectedSoldRatePlan.push(this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID));
    } else if (planType == 'update') {
      if (this.selectedSoldRatePlan.length !== 0) {
        let findIndex = this.selectedSoldRatePlan.findIndex(
          (x) => x.empcategorycode == this.empCatValueUpdateX && x.empClass === selectedPlan.employmentClassCode
        );
        if (findIndex !== -1) this.selectedSoldRatePlan[findIndex] = this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID);
        else this.selectedSoldRatePlan.push(this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID));
      } else {
        this.selectedSoldRatePlan = new Array(this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID));
      }
    } else if (planType == 'Remove') {
      for (let i = 0; i < selectedPlan.length; i++) {
        let findIndex = this.selectedSoldRatePlan.findIndex(
          (x) =>
            x.empcategorycode === selectedPlan[i].emplymntCtgryCd &&
            x.empClass === selectedPlan[i].employmentClassCode &&
            this.lob === x.LOB &&
            x.quotedContractCode === selectedPlan[i].quotedContractCode
        );
        if (findIndex == -1) {
          this.selectedSoldRatePlan.push(this.preparePlanData(selectedPlan[i], planType, currentDate, selectedPlan[i].ratingPlanId));
        } else {
          this.selectedSoldRatePlan.splice(findIndex, 1);
        }
      }
    } else {
      this.selectedSoldRatePlan.push(this.preparePlanData({}, '', currentDate, ratingPlanID));
    }
  }

  backClicked() {
    this.router.navigate(['/quote']);
  }

  clickedFromDate() {
    let element: HTMLElement = document.querySelectorAll('.overridedate .p-inputtext')[0] as HTMLElement;
    if (typeof element != 'undefined') {
      element.click();
    }
  }

  onRowSelect() {}

  disableManualSubmitBtn(): boolean {
    if((this.subsequentSoldRequestsExist && !this.showSubmitButtonAfterActionSubmit)) {
      return true;
    }
    if (!this.selectedSubmitValue || this.selectedSubmitValue.length === 0) {
      return true;
    }

    const hasNonMedicalPlans = this.selectedSubmitValue?.every(plan => plan !== RareConstants.medical);
    if (!hasNonMedicalPlans && this.hasActiveEmploymentCategories() && (this.isEnrollmentTotalMismatch || Object.values(this.enrollmentValidationErrors).some(error => error === true))) {
      return true;
    }
    return this.isReadOnlyRole || this.disableSubmit;
  }

  onlobSelect() {
    this.disableSubmit = !this.selectedSubmitValue?.length;
  }

  onMouseFocus(event) {
    this.multiSelect.show();
  }

  onDropdownMouseFocus(event) {
    this.select.show();
  }

  updateSubmitOptions() {
    this.submitOptions = [];

    if (this.medActiveRemoved.size > 0) {
      let medActiveRemoved = this.getByValue(this.medActiveRemoved, true);
      for (var i = 0; i < medActiveRemoved.length; ++i) {
        this.lobAdded.delete(medActiveRemoved[i]);
        this.setSelectedSubmitedValues(CommonConstants.Medical);
      }
    }
    if (this.visActiveRemoved.size > 0) {
      let visActiveRemoved = this.getByValue(this.visActiveRemoved, true);
      for (var i = 0; i < visActiveRemoved.length; ++i) {
        this.lobAdded.delete(visActiveRemoved[i]);
        this.setSelectedSubmitedValues(CommonConstants.Vision);
      }
    }
    if (this.denActiveRemoved.size > 0) {
      let denActiveRemoved = this.getByValue(this.denActiveRemoved, true);
      for (var i = 0; i < denActiveRemoved.length; ++i) {
        this.lobAdded.delete(denActiveRemoved[i]);
        this.setSelectedSubmitedValues(CommonConstants.Dental);
      }
    }
    if (this.shpActiveRemoved.size > 0) {
      let shpActiveRemoved = this.getByValue(this.shpActiveRemoved, true);
      for (var i = 0; i < shpActiveRemoved.length; ++i) {
        this.lobAdded.delete(shpActiveRemoved[i]);
        this.setSelectedSubmitedValues(RareConstants.suppHealth);
      }
    }

    let addedLobList = Array.from(this.lobAdded.values());
    for (let addedLob of addedLobList) {
      if (!this.submitOptions.find((x) => x === addedLob)) {
        this.submitOptions.push(addedLob);
      }
    }
    if (!this.submitOptions.includes('Medical')) {
      this.showAdditionalProgramsPopUp = false;
    }
    this.medActiveRemoved = new Map<string, boolean>();
    this.visActiveRemoved = new Map<string, boolean>();
    this.denActiveRemoved = new Map<string, boolean>();
    this.shpActiveRemoved = new Map<string, boolean>();

    this.submitOptions = this.submitOptions.filter(lob =>
      this.rowData.some(row => row.lob === lob)
    );
  }

  setSelectedSubmitedValues(lob) {
    const index = this.selectedSubmitValue.indexOf(lob);
    if (index !== -1) {
      this.selectedSubmitValue.splice(index, 1);
    }
  }

  getByValue(map, searchValue) {
    let keys = [];
    for (let [key, value] of map.entries()) {
      if (value === searchValue) keys.push(key);
    }
    return keys;
  }

  /**
   * Returns true if the given programType is a group-level program, based on the API response structure.
   */
  isGroupLevelProgramType(programType: string): boolean {
    if (!Array.isArray(this.programValues) || !Array.isArray(this.levelType)) return false;
    const idx = this.programValues.findIndex((pt: string) => pt === programType);
    if (idx === -1) return false;
    return this.levelType[idx] === 'Group';
  }

  saveAdditionalProgram() {
    this.additionalProgramErrorFlag = false;
    if (this.isGroupLevelProgramType(this.selectedProgramType)) {
      if (!this.selectedGroupCreditsRateTypes || this.selectedGroupCreditsRateTypes.length === 0) {
        this.additionalProgramErrorFlag = true;
        this.additionalProgramErrorValue = 'Please Enter Program Desc Value';
        // Do not close dialog or show success
        return;
      } else {
        this.additionalProgramErrorFlag = false;
        this.additionalProgramErrorValue = '';
        this.alertData = 'BuyUps/Credits Saved Successfully';
        this.addRatesFromAdditionalPrograms();
        if (this.selectedGroupCreditsRateTypes && this.groupCreditsRateTypes) {
          if (Array.isArray(this.levelType) && this.levelType.includes('Group')) {
            const desc = this.selectedGroupCreditsRateTypes;
            const found = this.groupCreditsRateTypes.find(rt => rt.value === desc);
            const idx = this.submittedTransitionData.findIndex(row => row.programDesc === desc);
            if (idx !== -1) {
              this.submittedTransitionData[idx].rate = found?.rate || 0;
              this.submittedTransitionData[idx].rateType = this.selectedRateType;
              this.submittedTransitionData[idx].unitType = this.selectedUnitType;
            } else {
              this.submittedTransitionData.push({ programDesc: desc, rate: found?.rate || 0, rateType: this.selectedRateType, unitType: this.selectedUnitType, programType: this.selectedProgramType });
            }
          }
        }
        this.showSaveAlert = true;
        this.displayProgramDialog = false;
        this.successMessage = true;
        this.formResetProgram();
      }
      return;
    }

    if (!this.descriptionReason || this.descriptionReason.length === 0) {
      this.additionalProgramErrorFlag = true;
      this.additionalProgramErrorValue = 'Please Enter Desc/Reason Value';
    }
    if (!this.additionalProgramErrorFlag) {
      this.selectedPlanTypeAdditional.forEach((selectedPlan) => {
        const contractCode = selectedPlan.split('-', 1)[0];
        if (this.mapOfContractCodeAndSelectedEmpCategories.get(contractCode)) {
          const countOfRequiredEmploymentCategories = this.mapOfContractCodeAndSelectedEmpCategories.get(contractCode).length;
          if (countOfRequiredEmploymentCategories != this.selectedAdditionalProgramEmpCategory.length) {
            this.additionalProgramErrorFlag = true;
            this.additionalProgramErrorValue = CommonConstants.EMPLOYMENT_CATEGORIES_FOR_SELECTED_PLANS_DO_NOT_MATCH;
          } else {
            const sortedListOfSelectedEmpCategories = CommonUtil.getSortedList(this.selectedAdditionalProgramEmpCategory);
            const sortedListOfExpectedCategories = CommonUtil.getSortedList(this.mapOfContractCodeAndSelectedEmpCategories.get(contractCode));
            if (JSON.stringify(sortedListOfSelectedEmpCategories) != JSON.stringify(sortedListOfExpectedCategories)) {
              this.additionalProgramErrorFlag = true;
              this.additionalProgramErrorValue = CommonConstants.EMPLOYMENT_CATEGORIES_FOR_SELECTED_PLANS_DO_NOT_MATCH;
            }
          }
        }
      });
    }
    if (!this.additionalProgramErrorFlag) {
      if (
        this.addRateInfo['Active'].eeRate &&
        this.addRateInfo['Active'].esRate &&
        this.addRateInfo['Active'].efRate &&
        this.addRateInfo['Active'].ecRate &&
        this.addRateInfo['Active'].ekRate
      ) {
        //do nothing as this means all rates are present and valid
      } else {
        this.additionalProgramErrorFlag = true;
        this.additionalProgramErrorValue = CommonConstants.ADDITIONAL_PROGRAM_RATES_NOT_VALID;
      }
    }
    if (!this.additionalProgramErrorFlag) {
      this.additionalProgramErrorValue = '';
      this.addRatesFromAdditionalPrograms();
      this.alertData = 'Additional Programs Saved Successfully';
      this.showSaveAlert = true;
      this.displayProgramDialog = false;
      this.successMessage = true;
      this.formResetProgram();
    }
  }

  addRatesFromAdditionalPrograms() {
    // Do not add Group level type as embedded plan-level info
    if (this.isGroupLevelProgramType(this.selectedProgramType)) {
      return;
    }
    var additionalProgram = {
      rateType: this.selectedRateType,
      contractCodePlanName: this.selectedPlanTypeAdditional,
      programType: this.selectedProgramType,
      rateInfo: this.addRateInfo,
      empCatValue: this.empCatValue,
      isIncludeInRates: this.isIncludeInRates,
      descriptionReason: this.descriptionReason
    };

    //Start - Ensure that only uniqueAdditionalPrograms are added
    //We should not consider any additionalProgram if its being added again
    //We use the combination of selectedPlanContractCode+selectedProgramType+descriptionReason+selectedRateType+EERate as uniqueKey
    //to determine if or not that additionalProgram was already added
    let listOfAlreadyAddedAdditionalProgramIds = [];
    if (sessionStorage.getItem('addedAdditionalPrograms')) {
      let commaSeparatedValues = sessionStorage.getItem('addedAdditionalPrograms');
      listOfAlreadyAddedAdditionalProgramIds = commaSeparatedValues.split(',');
    }

    let listOfUniqueIDOfAdditionalProgram = [];
    this.selectedPlanTypeAdditional.forEach((selectedPlan) => {
      //the data and its order in this key separated by | should NOT be changed as it is used in getAdditionalProgramDetails function
      listOfUniqueIDOfAdditionalProgram.push(
        selectedPlan + '|' + this.selectedProgramType + '|' + this.descriptionReason + '|' + this.selectedRateType + '|' + this.addRateInfo['Active'].eeRate
      );
    });

    let mapWithIsUniqueFlag = new Map();
    listOfUniqueIDOfAdditionalProgram.forEach((uniqueAdditionalProgramID) => {
      if (listOfAlreadyAddedAdditionalProgramIds.includes(uniqueAdditionalProgramID)) {
        mapWithIsUniqueFlag.set(uniqueAdditionalProgramID, false);
      } else {
        mapWithIsUniqueFlag.set(uniqueAdditionalProgramID, true);
        listOfAlreadyAddedAdditionalProgramIds.push(uniqueAdditionalProgramID);
        sessionStorage.setItem('addedAdditionalPrograms', listOfAlreadyAddedAdditionalProgramIds.join(','));
      }
    });
    //End - Ensure that only uniqueAdditionalPrograms are added

    //iterate through all the existing soldPlans
    this.rowData.forEach((soldPlan) => {
      let isAdditionalProgramsAddedToThisPlan = false;
      soldPlan.employmentCategory.forEach((empPlan) => {
        if (StringUtils.isEqualIgnoreCase(soldPlan.lob, RareConstants.medical)) {
          const currentSoldPlanNameWithContractCodePrefix = soldPlan.quotedContractCode + '-' + soldPlan.productName;
          const uniqueIDForThisSoldPlan =
            currentSoldPlanNameWithContractCodePrefix +
            '|' +
            this.selectedProgramType +
            '|' +
            this.descriptionReason +
            '|' +
            this.selectedRateType +
            '|' +
            this.addRateInfo['Active'].eeRate;
          if (this.selectedPlanTypeAdditional.includes(currentSoldPlanNameWithContractCodePrefix) && mapWithIsUniqueFlag.get(uniqueIDForThisSoldPlan) == true) {
            isAdditionalProgramsAddedToThisPlan = true;
            if (this.isIncludeInRates) {
              empPlan.tierRate.eeRate = empPlan.tierRate.eeRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].eeRate);
              empPlan.tierRate.esRate = empPlan.tierRate.esRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].esRate);
              empPlan.tierRate.efRate = empPlan.tierRate.efRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].efRate);
              empPlan.tierRate.ecRate = empPlan.tierRate.ecRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].ecRate);
              empPlan.tierRate.ekRate = empPlan.tierRate.ekRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].ekRate);
            }
          }
        }
      });
      if (isAdditionalProgramsAddedToThisPlan) {
        if (soldPlan['additionalPrograms']) {
          soldPlan['additionalPrograms'].push(additionalProgram);
        } else {
          soldPlan['additionalPrograms'] = [additionalProgram];
        }
      }
    });

    this.rowData.forEach((soldPlan) => {
      if (soldPlan.additionalPrograms && soldPlan.additionalPrograms.length > 0) {
        soldPlan.additionalPrograms.forEach((additionalProgram) => {
          additionalProgram.empCatValue.forEach((empCat) => {
            let rateInfoForEmploymentCategory = additionalProgram.rateInfo[empCat];
            let text = this.getIncludedRatesText(additionalProgram.isIncludeInRates, soldPlan.fundingType);
            let soldPlanAdditionalProgram = {
              contractCodePlanName: soldPlan.contractCodePlanName,
              rateInfo: rateInfoForEmploymentCategory,
              planName: soldPlan.productName,
              programType: additionalProgram.programType,
              isIncludeInRates: additionalProgram.isIncludeInRates,
              contractCode: soldPlan.contractCode,
              employmentCategoryCode: empCat,
              ratesText: text,
              description: additionalProgram.descriptionReason,
              rateType: additionalProgram.rateType
            };

            var uniqueMapKey = soldPlan.contractCodePlanName + '|' + empCat;

            if (!this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey)) {
              this.mapOfContractCodeAndAdditionalProgram.set(uniqueMapKey, []);
              if (soldPlan.additionalPrograms[0].contractCodePlanName.includes(soldPlan.contractCodePlanName)) {
                this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey).push(soldPlanAdditionalProgram);
              }
            } else {
              var isAdditionalProgramAdded = false;

              // checking unique key to avoid duplicate additionalProgram getting added
              this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey).forEach((additionalProgramInNestedLoop) => {
                if (
                  additionalProgramInNestedLoop['programType'] == additionalProgram.programType &&
                  additionalProgramInNestedLoop['description'] == additionalProgram.descriptionReason &&
                  additionalProgramInNestedLoop['programType'] == additionalProgram.programType &&
                  additionalProgramInNestedLoop['rateInfo'].eeRate == rateInfoForEmploymentCategory.eeRate &&
                  additionalProgramInNestedLoop['employmentCategoryCode'] == empCat &&
                  additionalProgramInNestedLoop['rateType'] == additionalProgram.rateType
                ) {
                  isAdditionalProgramAdded = true;
                }
              });
              if (!isAdditionalProgramAdded) {
                if (soldPlan.additionalPrograms[0].contractCodePlanName.includes(soldPlan.contractCodePlanName)) {
                  this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey).push(soldPlanAdditionalProgram);
                }
              }
            }
          });
        });
      }
    });

    for (let [key, value] of this.mapOfContractCodeAndAdditionalProgram) {
      if (value && value.length == 0) {
        this.mapOfContractCodeAndAdditionalProgram.delete(key);
      }
    }
    // Rest isIncludeInRates
    if(this.isIncludeInRates) {
      this.isIncludeInRates = false;
    }
  }

  getIncludedRatesText(ratesIncluded, fundingType) {
    if (StringUtils.isEqualIgnoreCase(fundingType, 'ABF') && (StringUtils.isEqualIgnoreCase(ratesIncluded.toString(), 'yes') || ratesIncluded === true)) {
      return CommonConstants.ADDITIONAL_PROGRAM_ADDED_TO_ADMIN;
    }
    if (StringUtils.isEqualIgnoreCase(fundingType, 'FI') && (StringUtils.isEqualIgnoreCase(ratesIncluded.toString(), 'yes') || ratesIncluded === true)) {
      return CommonConstants.ADDITIONAL_PROGRAM_ADDED_TO_TOTAL;
    }
    return CommonConstants.ADDITIONAL_PROGRAM_EMBEDDED;
  }

  openAdditionalProgramsPopUp() {
    //when the add additionalPrograms button is clicked - clear out all existing fields
    this.formResetProgram();
    this.removeSuccessMsg();
    this.formData = null;
    this.displayProgramDialog = true;
    this.soldRates_form.controls.ccCodeOverride.setValue('');
  }

  formResetProgram() {
    this.selectedProgramType = '';
    this.descriptionReason = '';
    this.PMPM = null;
    this.selectedPlanType = '';
    this.selectedEmpCategory = '';
    this.selectedFundingType = '';
    this.additionalProgramErrorFlag = false;
    this.selectedGroupCreditsRateTypes = null;
    this.isProgramTypeDisabled = false;
    if (this.originalGroupCreditsRateTypes) {
      this.groupCreditsRateTypes = JSON.parse(JSON.stringify(this.originalGroupCreditsRateTypes));
    }
  }

  getProgramType(value) {
  this.selectedProgramType = value;
  if (this.isGroupLevelProgramType(value)) {
    this.isProgramTypeDisabled = true;
  } else {
    this.isProgramTypeDisabled = false;
  }
  this.updateGroupCreditsRateTypes();
    this.additionalProgramErrorFlag = false;
    this.descriptionReason = '';
    this.selectedRateType = '';
    this.selectedPlanTypeAdditional = [];
    this.PMPM = null;

    this.planTypesAdditional.forEach((element) => {
      this.selectedPlanTypeAdditional.push(element.value);
    });

    if (Array.isArray(this.rateTypesAdditional) && this.rateTypesAdditional.length > 0) {
      this.selectedRateType = this.rateTypesAdditional[0].value;
    } else {
      this.selectedRateType = '';
    }

    this.selectedPlan = '';
    this.selectedRatingPlanID = '';
    this.formData = null;
    this.categoryList = [];
    for (let resp of this.responseData) {
      if (StringUtils.isEqualIgnoreCase(resp.lob, RareConstants.medical)) {
        this.selectedRatingPlanID = resp.ratingPlanID;
        break;
      }
    }
    this.categoryList = this.getCategoryList(RareConstants.medical, 'A');

    this.categoryList.sort((a, b) => {
      return a.label.localeCompare(b.label);
    });
    this.getCategory(this.empCatValue);
    this.addRateInfo = {
      Active: new RateInfo(),
      Cobra: new RateInfo(),
      'Over 65 Retiree': new RateInfo(),
      'Retiree All': new RateInfo(),
      'Under 65 Retiree': new RateInfo()
    };
  }

  editAdditionalEmpRates(empCatCode, empRate) {
    let outputTier = this.getOutputTierForLob(RareConstants.medical) + '-tier';
    if (empRate == 'Employee') {
      this.addRateInfo[empCatCode].esRate = Number((this.formData.rateTierFactor[outputTier].esFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2));
      this.addRateInfo[empCatCode].efRate = Number((this.formData.rateTierFactor[outputTier].efFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2));
      this.addRateInfo[empCatCode].ecRate = Number((this.formData.rateTierFactor[outputTier].ecFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2));
      this.addRateInfo[empCatCode].ekRate = Number((this.formData.rateTierFactor[outputTier].ekFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2));
    }
    if (empCatCode == 'Active') {
      this.categoryList.forEach((element) => {
        var empCategoryFctr = this.soldRateFullResponse.employmentCategoryMedical.find((x) => x.emplymntCtgryCd === element.value);
        this.addRateInfo[element.value].esRate = Number((this.addRateInfo['Active'].esRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2));
        this.addRateInfo[element.value].eeRate = Number((this.addRateInfo['Active'].eeRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2));
        this.addRateInfo[element.value].ekRate = Number((this.addRateInfo['Active'].ekRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2));
        this.addRateInfo[element.value].efRate = Number((this.addRateInfo['Active'].efRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2));
        this.addRateInfo[element.value].ecRate = Number((this.addRateInfo['Active'].ecRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2));
      });
    }
  }

  onChangeOfEEActiveTierDuplicate() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].eeRate = parseFloat(this.addRateInfo['Active'].eeRate);
    }
  }

  onChangeOfESActiveTierDuplicate() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].esRate = parseFloat(this.addRateInfo['Active'].esRate);
    }
  }

  onChangeOfEKActiveTierDuplicate() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].ekRate = parseFloat(this.addRateInfo['Active'].ekRate);
    }
  }

  onChangeOfEFActiveTierDuplicateOthers() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].efRate = parseFloat(this.addRateInfo['Active'].efRate);
    }
  }

  onChangeOfECActiveTierDuplicateOthers() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].ecRate = parseFloat(this.addRateInfo['Active'].ecRate);
    }
  }

  onChangeOfEEActiveTierDuplicateForAddlProduct = (event) => {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].eeRate = parseFloat(this.addRateInfo[event].eeRate);
    }
  }

  onChangeOfESActiveTierDuplicateForAddlProduct = (event) => {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].esRate = parseFloat(this.addRateInfo[event].esRate);
    }
  }

  onChangeOfEKActiveTierDuplicateForAddlProduct = (event) => {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].ekRate = parseFloat(this.addRateInfo[event].ekRate);
    }
  }

  onChangeOfEFActiveTierDuplicateOthersForAddlProduct = (event) => {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].efRate = parseFloat(this.addRateInfo[event].efRate);
    }
  }

  onChangeOfECActiveTierDuplicateOthersForAddlProduct = (event) => {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].ecRate = parseFloat(this.addRateInfo[event].ecRate);
    }
  }

  onChangeOfCompositeRateActiveDuplicateForAddlProduct = (event) => {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].compositeRate = parseFloat(this.addRateInfo[event].compositeRate);
    }
  }

  editPMPMAdditionalEmpRates() {
    let outputTier = this.getOutputTierForLob(RareConstants.medical) + '-tier';
    this.categoryList.forEach((element) => {
      var empCategoryFctr = this.soldRateFullResponse.employmentCategoryMedical.find((x) => x.emplymntCtgryCd === element.value);
      this.addRateInfo[element.value].esRate = Number(
        (
          this.formData.tierFactorMultiplier[outputTier] *
          this.PMPM *
          this.formData.rateTierFactor[outputTier].esFactor *
          empCategoryFctr.emplymntCtgryFctr
        ).toFixed(2)
      );
      this.addRateInfo[element.value].efRate = Number(
        (
          this.formData.tierFactorMultiplier[outputTier] *
          this.PMPM *
          this.formData.rateTierFactor[outputTier].efFactor *
          empCategoryFctr.emplymntCtgryFctr
        ).toFixed(2)
      );
      this.addRateInfo[element.value].eeRate = Number(
        (
          this.formData.tierFactorMultiplier[outputTier] *
          this.PMPM *
          this.formData.rateTierFactor[outputTier].eeFactor *
          empCategoryFctr.emplymntCtgryFctr
        ).toFixed(2)
      );
      this.addRateInfo[element.value].ecRate = Number(
        (
          this.formData.tierFactorMultiplier[outputTier] *
          this.PMPM *
          this.formData.rateTierFactor[outputTier].ecFactor *
          empCategoryFctr.emplymntCtgryFctr
        ).toFixed(2)
      );
      this.addRateInfo[element.value].ekRate = Number(
        (
          this.formData.tierFactorMultiplier[outputTier] *
          this.PMPM *
          this.formData.rateTierFactor[outputTier].ekFactor *
          empCategoryFctr.emplymntCtgryFctr
        ).toFixed(2)
      );
    });
  }

  getRateType(value) {
    this.selectedRateType = value;
    if (value !== 'PMPM') {
      this.PMPM = null;
    }
    this.addRateInfo = {
      Active: new RateInfo(),
      Cobra: new RateInfo(),
      'Under 65 Retiree': new RateInfo(),
      'Over 65 Retiree': new RateInfo(),
      'Retiree All': new RateInfo()
    };
  }
  valueChanged() {
    this.isEdit = !this.isEdit;
    this.soldRateFullResponse = this.soldRateFullResponseModified;
  }
  getCategoryAddtional(value) {
    this.additionalProgramErrorFlag = false;
    this.selectedEmpCategory = CommonUtil.getSortedList(value);
    this.selectedAdditionalProgramEmpCategory = this.selectedEmpCategory;
    this.formData = this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID);
    this.soldRateFullResponseModified = this.soldRateFullResponse;
  }

  getCategory = (value) => {
    if (this.selectedProgramType) {
      this.getCategoryAddtional(value);
      this.modifyTier(RareConstants.medical);
    } else {
      this.errorFlag = false;
      this.selectedEmpCategory = value;
      if (StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)) {
        let formData = [];
        this.selectedRatingPlanIDs.forEach((selectedRatingPlanID) => {
          let data = this.responseData.find((x) => x.ratingPlanID === selectedRatingPlanID);
          if (data) {
            formData.push(data);
          }
        });
        this.formData = formData;
      } else {
        this.formData = this.responseData.find((x) => x.ratingPlanID === this.selectedRatingPlanID);
      }
      this.replaceCurrentTierRatesWithOriginalQuotedRatesWhenAddingNewPlanInAddProgram();
    }
  }

  //When Add product popUp is opened - the rates that are displayed should be "QuotedRates"
  //i.e. they should not have any additionalPrograms "added"
  //This flow is triggered whenever Quoted Contract Code or Product Name dropDown is changed
  replaceCurrentTierRatesWithOriginalQuotedRatesWhenAddingNewPlanInAddProgram() {
    if (this.formData && this.formData['quotedTierRates']) {
      if (this.formData['additionalPrograms'] && !this.formData['tierRatesWithAdditionalPrograms']) {
        this.formData['tierRatesWithAdditionalPrograms'] = JSON.parse(JSON.stringify(this.formData.tierRate));
      }
      this.formData.tierRate = JSON.parse(JSON.stringify(this.formData.quotedTierRates));
    }
  }

  onAddPlanPopUpClose() {
    this.activeTab = 1;
    this.revertReplacingOfTierRatesWithQuotedRates;
  }

  revertReplacingOfTierRatesWithQuotedRates() {
    if (this.rowData) {
      for (var soldPlan of this.rowData) {
        if (soldPlan && soldPlan['tierRatesWithAdditionalPrograms']) {
          soldPlan.tierRate = JSON.parse(JSON.stringify(soldPlan['tierRatesWithAdditionalPrograms']));
        }
      }
    }
  }

  //This function has to be replaced as we have logic already existing and can be reused.
  modifyTier(lob) {
    let outputTier = this.getOutputTierForLob(lob) + '-tier';

    //do tier Modification only if its not already a 5 tier one
    if (outputTier !== '5-tier' && this.formData) {
      if (outputTier === '4-tier') {
        this.formData.rateTierFactor['4-tier'].ekFactor = this.formData.rateTierFactor['4-tier'].ecFactor;
        this.formData.outputTierFactor['4-tier'].ekFactor = this.formData.outputTierFactor['4-tier'].ecFactor;
      } else if (outputTier === '3-tier') {
        this.formData.rateTierFactor['3-tier'].esFactor = this.formData.rateTierFactor['3-tier'].e1Factor;
        this.formData.rateTierFactor['3-tier'].ekFactor = this.formData.rateTierFactor['3-tier'].e1Factor;
        this.formData.rateTierFactor['3-tier'].ecFactor = this.formData.rateTierFactor['3-tier'].efFactor;

        this.formData.outputTierFactor['3-tier'].esFactor = this.formData.outputTierFactor['3-tier'].e1Factor;
        this.formData.outputTierFactor['3-tier'].ekFactor = this.formData.outputTierFactor['3-tier'].e1Factor;
        this.formData.outputTierFactor['3-tier'].ecFactor = this.formData.outputTierFactor['3-tier'].efFactor;
      } else if (outputTier === '2-tier') {
        this.formData.rateTierFactor['2-tier'].esFactor = this.formData.rateTierFactor['2-tier'].efFactor;
        this.formData.rateTierFactor['2-tier'].ekFactor = this.formData.rateTierFactor['2-tier'].efFactor;
        this.formData.rateTierFactor['2-tier'].ecFactor = this.formData.rateTierFactor['2-tier'].efFactor;

        this.formData.outputTierFactor['2-tier'].esFactor = this.formData.outputTierFactor['2-tier'].efFactor;
        this.formData.outputTierFactor['2-tier'].ekFactor = this.formData.outputTierFactor['2-tier'].efFactor;
        this.formData.outputTierFactor['2-tier'].ecFactor = this.formData.outputTierFactor['2-tier'].efFactor;
      } else {
        this.formData.rateTierFactor['1-tier'].esFactor = this.formData.rateTierFactor['1-tier'].eeFactor;
        this.formData.rateTierFactor['1-tier'].ekFactor = this.formData.rateTierFactor['1-tier'].eeFactor;
        this.formData.rateTierFactor['1-tier'].ecFactor = this.formData.rateTierFactor['1-tier'].eeFactor;
        this.formData.rateTierFactor['1-tier'].efFactor = this.formData.rateTierFactor['1-tier'].eeFactor;

        this.formData.outputTierFactor['1-tier'].esFactor = this.formData.outputTierFactor['1-tier'].eeFactor;
        this.formData.outputTierFactor['1-tier'].ekFactor = this.formData.outputTierFactor['1-tier'].eeFactor;
        this.formData.outputTierFactor['1-tier'].ecFactor = this.formData.outputTierFactor['1-tier'].eeFactor;
        this.formData.outputTierFactor['1-tier'].efFactor = this.formData.outputTierFactor['1-tier'].eeFactor;
      }
    }
  }

  getIncludeInRates(fundingType) {
    if (fundingType == 'FI') {
      this.includeInRates = 'Total';
    }
    if (fundingType == 'ABF') {
      this.includeInRates = 'Admin';
    }
  }

  isNumber = (event: KeyboardEvent) => {
    if (event.ctrlKey || event.metaKey) return;
    if (
      event.key.length > 1 || event.key === 'Enter' || event.key === 'Escape'
    ) {
      return;
    }
    if (event.key >= '0' && event.key <= '9') return;
    const input = event.target as HTMLInputElement;
    if (
      event.key === '-' &&
      input.selectionStart === 0 &&
      !input.value.includes('-')
    ) {
      return;
    }
    if (
      (event.key === '.' || event.key === ',') &&
      !input.value.includes('.') &&
      !input.value.includes(',')
    ) {
      return;
    }
    event.preventDefault();
  }

  getSelectionStart(o) {
    return o.selectionStart;
  }

  isPMPMNumber(event) {
    return NumberUtils.isKeyPressForAValidNumber(event, 6);
  }

  getEnrollments(field, empCat) {
    if (StringUtils.isEqualIgnoreCase(field, 'eeRateEnrollment')) return empCat?.enrollments?.ee ? empCat.enrollments.ee : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'ekRateEnrollment')) return empCat?.enrollments?.ek ? empCat.enrollments.ek : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'efRateEnrollment')) return empCat?.enrollments?.ef ? empCat.enrollments.ef : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'ecRateEnrollment')) return empCat?.enrollments?.ec ? empCat.enrollments.ec : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'esRateEnrollment')) return empCat?.enrollments?.es ? empCat.enrollments.es : 0;
  }

  calculateEnrollmentColumnTotal(field: string): number {
    let total = 0;
    if (this.responseData) {
      for (let plan of this.responseData) {
        if (plan.employmentCategory) {
          for (let empCat of plan.employmentCategory) {
            if (empCat.emplymntCtgryCd === 'Active') {
              total += this.getEnrollments(field, empCat);
            }
          }
        }
      }
    }
    return total;
  }

  validateEnrollmentTotals(): boolean {
    const medicalQuote = this.soldRateFullResponse?.data?.quotes?.find(quote => StringUtils.isEqualIgnoreCase(quote.lob, RareConstants.medical));
    
    if (!medicalQuote?.medTierLivesMap) {
      return true;
    }

    if (!this.isRenewalLocalPresent) {
      this.enrollmentValidationErrors = {};
      this.isEnrollmentTotalMismatch = false;
      return false;
    }

    const medTierLivesMap = medicalQuote?.medTierLivesMap;

    if (!medTierLivesMap) {
      return true;
    }

    const fieldMapping = {
      'eeRateEnrollment': 'EE',
      'esRateEnrollment': 'ES',
      'ekRateEnrollment': 'EK',
      'efRateEnrollment': 'EF',
      'ecRateEnrollment': 'EC'
    };

    let userTotal = 0;
    let expectedTotal = 0;
    this.enrollmentValidationErrors = {};
    this.enrollmentColumnTotals = {};

    for (let field in fieldMapping) {
      const total = this.calculateEnrollmentColumnTotal(field);
      this.enrollmentColumnTotals[field] = total;
      userTotal += total;
      expectedTotal += medTierLivesMap[fieldMapping[field]] || 0;
    }

    this.isEnrollmentTotalMismatch = (userTotal !== expectedTotal);
    let hasErrors = false;
    for (let field in fieldMapping) {
      const total = this.enrollmentColumnTotals[field];
      const expectedValue = medTierLivesMap[fieldMapping[field]] || 0;
      
      if (total !== expectedValue) {
        this.enrollmentValidationErrors[field] = true;
        hasErrors = true;
      } else {
        this.enrollmentValidationErrors[field] = false;
      }
    }

    return hasErrors || this.isEnrollmentTotalMismatch;
  }

  isEnrollmentField(field: string): boolean {
    const enrollmentFields = ['eeRateEnrollment', 'esRateEnrollment', 'ekRateEnrollment', 'efRateEnrollment', 'ecRateEnrollment'];
    return enrollmentFields.includes(field);
  }

  shouldShowEnrollmentValidation(field: string): boolean {
    return this.hasActiveEmploymentCategories() && this.isEnrollmentField(field) && this.enrollmentValidationErrors[field];
  }

  hasActiveEmploymentCategories(): boolean {
    if (!this.responseData) {
      return false;
    }
    
    for (let plan of this.responseData) {
      if (plan.employmentCategory) {
        for (let empCat of plan.employmentCategory) {
          if (empCat.emplymntCtgryCd === 'Active') {
            return true;
          }
        }
      }
    }
    return false;
  }

  getColumnTotalTooltip(field: string): string {
    const total = this.enrollmentColumnTotals[field] || 0;
    const medicalQuote = this.soldRateFullResponse?.data?.quotes?.find(quote => StringUtils.isEqualIgnoreCase(quote.lob, RareConstants.medical));
    const medTierLivesMap = medicalQuote?.medTierLivesMap;
    
    let expectedValue = 0;
    if (medTierLivesMap) {
      const fieldMapping = {
        'eeRateEnrollment': 'EE',
        'esRateEnrollment': 'ES',
        'ekRateEnrollment': 'EK',
        'efRateEnrollment': 'EF',
        'ecRateEnrollment': 'EC'
      };
      expectedValue = medTierLivesMap[fieldMapping[field]] || 0;
    }
    
    return `Expected Enrollment Count: ${expectedValue}`;
  }

  rateSplitsExpand(rowData) {
    rowData.expanded = !rowData.expanded;
  }

  isRateSplitsAvailable(planData, index) {
    if (StringUtils.isEqualIgnoreCase(planData?.lob, 'Medical') && planData?.employmentCategory?.[index]?.rateSplits?.length) {
      return true;
    }
    if (StringUtils.isEqualIgnoreCase(planData?.lob, 'Medical') && planData?.additionalPrograms && !planData.planIsRemoved) {
      return true;
    }
    return false;
  }

  /* Display alert message to prevent multiple Retiree's added to sold plan */
  planRetireeValidation(isUpdate) {
    let isValid = true;
    const lob = 'Supp Health';
    const retireAll = 'Retiree All';
    const retire = 'Retiree';
    let isRetireeAll = this.empCatValue?.some((emp) => StringUtils.isEqualIgnoreCase(emp, retireAll));
    if (isUpdate && this.empCatValueUpdate) {
      isRetireeAll = StringUtils.isEqualIgnoreCase(this.empCatValueUpdate, retireAll);
    }
    if (!this.empCategory?.length && this.empCatValue?.length && !isUpdate && !StringUtils.isEqualIgnoreCase(this.selectedLOB, lob)) {
      isValid = this.RetireecommonValidation(isValid, retire, isRetireeAll);
    } else if (!this.historyRetireeValidation(isUpdate, retire, isRetireeAll, retireAll) && !StringUtils.isEqualIgnoreCase(this.selectedLOB, lob)) {
      isValid = false;
    }
    return isValid;
  }

  historyRetireeValidation(isUpdate, retire, isRetireeAll, retireAll) {
    let isValid = true;
    const classObj = { classValueUpdate: 'classValueUpdate', classValue: 'classValue' };
    let categoryDropdown = isUpdate ? this.empCatValueUpdate?.split(',') : this.empCatValue;
    let selectedContractcode = isUpdate ? this.soldRates_form.get('ccCodeOverrideUpdate')?.value : this.soldRates_form.get('ccCodeOverride')?.value;
    let selectedClassValue = isUpdate ? this.soldRates_form.get(classObj.classValueUpdate)?.value : this.soldRates_form.get(classObj.classValue)?.value;
    selectedClassValue = selectedClassValue ? selectedClassValue : '';
    if (this.empCategory && this.empCategory?.length) {
      const selectedRetireeLength = categoryDropdown?.filter((emp) => emp.includes(retire))?.length;
      const retireeOptionsLength = categoryDropdown?.filter((emp) => SoldRatesConstants.RETIREE_OPTIONS.indexOf(emp) != -1)?.length;
      this.empCategory.forEach((emp) => {
        if (StringUtils.isEqualIgnoreCase(emp.contractCode, selectedContractcode) && emp.employmentCategory?.length) {
          const historyEmpCategory = emp.employmentCategory.map((emp) => {
            return { category: emp.emplymntCtgryCd, class: emp.employmentClassCode };
          });
          const retireeAllLength = historyEmpCategory.filter(
            (emp) => StringUtils.isEqualIgnoreCase(emp.category, retireAll) && emp.class == selectedClassValue
          )?.length;
          const retireeLength = historyEmpCategory.filter(
            (emp) => SoldRatesConstants.RETIREE_OPTIONS.indexOf(emp.category) != -1 && emp.class == selectedClassValue
          )?.length;
          if (retireeLength && selectedRetireeLength > 1) {
            isValid = false;
          } else if (isRetireeAll && retireeLength) {
            isValid = false;
          } else if (retireeAllLength && retireeOptionsLength) {
            isValid = false;
          } else if (!isUpdate) {
            isValid = this.RetireecommonValidation(isValid, retire, isRetireeAll);
          }
        } else if (!isUpdate) {
          isValid = this.RetireecommonValidation(isValid, retire, isRetireeAll);
        }
      });
    }
    return isValid;
  }
  RetireecommonValidation(isValid, retire, isRetireeAll) {
    if (this.empCatValue?.filter((emp) => emp.includes(retire))?.length > 2) {
      isValid = false;
    } else if (isRetireeAll && this.empCatValue?.filter((emp) => SoldRatesConstants.RETIREE_OPTIONS.indexOf(emp) != -1)?.length == 1) {
      isValid = false;
    }
    return isValid;
  }

  getSoldRateColumnClass(column) {
    return `header-${column}`;
  }

  /**
   * This returns a warning message String in case Sold Rates include at least one Supp Health
   */
  getTooltipWarningMessage() {
    if (this.responseDataHistory.length > 0 && this.soldHistoryHasSuppHealthPlans()) {
      return CommonConstants.PRINT_TOOLTIP_SUPP_HEALTH_WARNING;
    }

    return CommonConstants.EMPTY_STRING;
  }

  /**
   * This checks if there is at least one Supp Health Sold Rate
   */
  soldHistoryHasSuppHealthPlans() {
    return this.responseDataHistory.some((history) => history.plan.some((plan) => StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.suppHealth)));
  }

  /**
   * This checks if all Sold Rates are Supp Health ones
   */
  soldHistoryHasOnlySuppHealthPlans() {
    return this.responseDataHistory.every(
      (history) => history.plan.length === history.plan.filter((plan) => StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.suppHealth)).length
    );
  }

  /**
   * This checks the enrollment count matches with quoted subscribers or not
   */
  checkEnrollmentCount(_SoldRatePlansWithCat) {
    let enrollments = 0;
    if (_SoldRatePlansWithCat?.plan) {
      _SoldRatePlansWithCat.plan.forEach((plan) => {
        if (
          StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical) &&
          !StringUtils.isUndefined(plan?.employmentCategory) &&
          plan?.employmentCategory?.length > 0
        ) {
          if (this.isRenewalLocalPresent && plan.planTypeRequested !== 'F' && !plan?.employmentCategory[0]?.enrollments &&
            (this.selectedSubmitValue?.includes(RareConstants.medical) ||
              (this.submitOptions?.includes(RareConstants.medical) && StringUtils.isEqual(this.action, CommonConstants.save)))
          ) {
            this.isCurrentPlanMapped = true;
            return;
          }
          plan?.employmentCategory?.forEach((empCat) => {
            if (empCat.emplymntCtgryCd === 'Active' && !StringUtils.isUndefined(empCat?.enrollments)) {
              Object.keys(empCat.enrollments).forEach((enrollmentKey) => {
                if (!StringUtils.isUndefined(empCat.enrollments[enrollmentKey])) enrollments = enrollments + empCat.enrollments[enrollmentKey];
              });
            }
          });
        }
      });
      return enrollments;
    }
  }
  /**
   * This snippet assign the enrollment count for plan
   */
  private assignEnrollments(plan: any, initialEnrollments: any) {
    plan.employmentCategory.forEach((empCat) => {
      if (StringUtils.isUndefined(empCat.enrollments)) {
        if (StringUtils.isEqual(empCat.emplymntCtgryCd, CommonConstants.ACTIVE)) {
          empCat[CommonConstants.ENROLLMENTS] = {
            ee: initialEnrollments?.EE,
            ef: initialEnrollments?.EF,
            ek: initialEnrollments?.EK,
            es: initialEnrollments?.ES,
            ec: initialEnrollments?.EC
          };
        }
      }
    });
  }
  private checkSoldConditions(plan: any, planTypeRequested) {
    return (
      StringUtils.isEqual(plan.planTypeRequested, planTypeRequested)
      && (StringUtils.isEqual(plan.status, CommonConstants.PRE_SOLD) || StringUtils.isEqual(plan.status, CommonConstants.SOLD_PENDING_UW_REVIEW) || StringUtils.isEqual(plan.status, CommonConstants.SOLD_MODIFIED))
      && StringUtils.isEqual(plan.lob, CommonConstants.Medical) && plan.employmentCategory && StringUtils.isUndefined(plan.currentContractCode)
    );
  }

  /**
   * Gets the opportunity type from quote level
   * as that is no longer available from root level
   * @param response
   */
  getOpportunityType(response) {
    const lobOpportunityMap = new Map();

    response?.quotes?.forEach((quote) => {
      const opportunityType = StringUtils.isEqual(quote.opportunityType, CommonConstants.RENEWAL_LOCAL)
        ? CommonConstants.RENEWAL_LOCAL
        : CommonConstants.NEW_BUSINESS_LOCAL;

      lobOpportunityMap.set(quote.lob, opportunityType);
    });

    return lobOpportunityMap;
  }

  isRenewalLocalPresentInSFOpportunityType(response): boolean {
    if (response?.sfOpportunityType) {
      for (const oppType of response.sfOpportunityType.values()) {
        if (oppType === CommonConstants.RENEWAL_LOCAL) {
          return true;
        }
      }
    }
    return false;
  }

  checkOppTypeForLOBInSFOpportunityType(response, lob, oppType) {
    return response?.sfOpportunityType?.get(lob) === oppType;
  }

  getQuotedSubscribers(response) {
    return response?.quotes?.find((quote) => StringUtils.isEqual(quote.lob, CommonConstants.Medical))?.quotedSubscribers;
  }

  /**
   * Find and return all plans from the quotes
   * Function implemented based on v2 API for fetching data
   */
  iterateThroughQuotes(data: any) {
    const quotes = data.quotes;
    let plans = [];
    quotes?.forEach((quote) => {
      // Taking employmentCategory objects from quote level
      this.populateEmploymentCategories(quote);
      quote?.plans?.forEach((plan) => {
        // Taking some fields from quote level, as all plans should have the same
        plan.lob = quote.lob;
        plan.caseNumber = data.caseNumber ?? quote.caseNumber;
        plan.caseName = data.caseName;
        plan.priorCaseNumber = data.priorCaseNumber;
        plan.rateGuaranteeMonths = plan.rateGuaranteeMonths;
        plan.rateEffectiveDate = plan.rateEffectiveDate;
        if(quote.soldAddlProduct) {
          plan.isAdditionalProduct = true;
        }

        plans.push(plan);

      });
    });
    return plans;
  }

  /**
   * Find and return all employmentCategories from the quote level
   * @param quote
   */
  populateEmploymentCategories(quote) {
    if (quote.employmentCategoryMedical) {
      this.soldRateFullResponse.employmentCategoryMedical = quote.employmentCategoryMedical;
    }
    if (quote.employmentCategoryDental) {
      this.soldRateFullResponse.employmentCategoryDental = quote.employmentCategoryDental;
    }
    if (quote.employmentCategoryVision) {
      this.soldRateFullResponse.employmentCategoryVision = quote.employmentCategoryVision;
    }
    if (quote.employmentCategorySuppHealth) {
      this.soldRateFullResponse.employmentCategorySuppHealth = quote.employmentCategorySuppHealth;
    }
  }

  /**
   * Find and return all populateMedicalTierLives data from the quote level
   * @param data
   */
  populateMedicalTierLivesMap(data) {
    const quotes = data.quotes;
    let mappedMedTierLivesMap = {};
    quotes.forEach((quote) => {
      const quoteMappedMedTierLivesMap = quote.mappedMedTierLivesMap;
      if (quoteMappedMedTierLivesMap) {
        Object.keys(quoteMappedMedTierLivesMap).forEach((key) => {
          mappedMedTierLivesMap[key] = quoteMappedMedTierLivesMap[key];
        });
      }
    });
    return mappedMedTierLivesMap;
  }

  /**
   * Moves the plan data from quote level to history root level
   * @param historyData
   */
  populateSoldRatesHistory(historyData) {
    historyData?.forEach((history) => {
      const quotes = history.quotes;
      let plans = [];
      quotes?.forEach((quote) => {
        quote.plans.forEach((plan) => {
          // Copying fields from quote level to plans
          plan.rateGuaranteeMonths = plan.rateGuaranteeMonths;
          plan.rateEffectiveDate = plan.rateEffectiveDate;
          plan.lob = quote.lob;
          if(quote.soldAddlProduct) {
            plan.isAdditionalProduct = true;
          }
          
          // Fix: Convert rateInfo to tierRate for history component display
          if (plan.employmentCategory && Array.isArray(plan.employmentCategory)) {
            plan.employmentCategory.forEach(empCat => {
              if (empCat.rateInfo && !empCat.tierRate) {
                empCat.tierRate = { ...empCat.rateInfo };
              }
            });
          }
        });
        plans = [...plans, ...quote.plans];
      });
      history.plan = plans;
    });
  }

  checkSubsequentSoldRequestsExist(responseData) {
    responseData?.forEach((response) => {
      if(!this.subsequentSoldRequestsExist) {
      const allPlansHaveRequests = response.plans?.filter(plan => plan?.subsequentSoldRequest === true).length > 0 && response.status === 'Sold-Pending UW Review';
      this.subsequentSoldRequestsExist = allPlansHaveRequests;
      }
    });
  }

  /**
   * Gets the Effective Contract Date from the response data
   * Since all plans contain the same Contract Date, we get it from the first plan
   * Function implemented based on v2 API for fetching data
   */
  getContractEffectiveDate(responseData) {
    return responseData?.quotes[0]?.contractEffectiveDate;
  }

  getContractEffectiveDateMedical(responseData) {
    return responseData?.quotes?.find(quote => quote.lob === 'Medical')?.contractEffectiveDate;
  }

    /**
   * Returns the contract effective date for display based on fundingType and lob from URL params.
   * If fundingType is FI and lob is Medical, returns contractEffDate for Medical/FI.
   * If fundingType is ABF and lob is Medical, returns contractEffDate for Medical/ABF.
   * Otherwise, returns the default contractEffDate.
   */
  getContractEffDateForDisplay(): Date | string | undefined {
    const fundingType = this.fundingType;
    const lob = this.lob;
    if (
      !this.soldRateFullResponse ||
      !this.soldRateFullResponse.data ||
      !Array.isArray(this.soldRateFullResponse.data.quotes)
    ) {
      return this.contractEffDate;
    }
    // Find the quote for the current lob and fundingType
    const quotes = this.soldRateFullResponse.data.quotes;
    const quote = quotes.find(q =>
      q && q.lob && q.fundingType &&
      String(q.lob).toLowerCase() === String(lob || '').toLowerCase() &&
      String(q.fundingType).toLowerCase() === String(fundingType || '').toLowerCase()
    );
    if (quote && quote.contractEffectiveDate) {
      return quote.contractEffectiveDate;
    }
    // Fallback: try to find by lob only
    const quoteByLob = quotes.find(q =>
      q && q.lob && String(q.lob).toLowerCase() === String(lob || '').toLowerCase()
    );
    if (quoteByLob && quoteByLob.contractEffectiveDate) {
      return quoteByLob.contractEffectiveDate;
    }
    // Fallback: use the default contractEffDate
    return this.contractEffDate;
  }

  /**
   * Gets the Effective Rate Date from the response data
   *  Since all plans contain the same Rate Effective Date, we get it from the first quote
   * @param responseData
   */
  getEffectiveDate(responseData) {
    return responseData?.quotes[0]?.rateEffectiveDate;
  }

  /**
   * Gets the outputTier from the response data
   *  Since all plans contain the same outputTier, we get it from the first quote
   * @param responseData
   */
  getOutputTier(responseData) {
    return responseData?.quotes[0]?.outputTier;
  }

  /**
   * Retrieves the output tier for a given line of business (LOB).
   *
   * @param lob The line of business to retrieve the output tier for.
   * @returns The output tier for the specified line of business, or the default output tier if not found.
   */
  getOutputTierForLob(lob) {
    const quote = this.soldRateFullResponse?.data?.quotes?.find((quote) => StringUtils.isEqualIgnoreCase(quote.lob, lob));
    if (quote) {
      return quote?.outputTier;
    }

    return this.outputTier;
  }

  /**
   * Gets the Current Plans from the Medical Quote in the response data
   * @param responseData
   */
  getCurrentPlansInQuote(responseData) {
    const quote = responseData?.data?.quotes?.find((quote) => StringUtils.isEqualIgnoreCase(quote.lob, CommonConstants.Medical));
    return quote?.currentPlans;
  }

  ngOnDestroy() {
    this.eventSources.forEach((source) => source.close());
    this.AddAsIsOptions = [];
  }

  actionSoldUpdates(action) {
    this.soldRatesService.actionSubsequentSoldNotification(this.opportunityID, this.quoteHeaderID, action).subscribe(
      (response) => {
        this.isAcceptedOrRejected = true;
        this.showSubmitAlert = true;
        this.showSaveAlert = false;
        this.successMessage = true;
        if(action === 'reject') {
        this.alertData = response;
        } else {
        this.alertData = CommonConstants.SOLD_NOTIFICATION_ACCEPTED_MESSAGE;
        }
        this.showSubmitButtonAfterActionSubmit = true;
        this.div_visible = true;
        this.subsequentSoldRequestsExist = false;
        this.loadSoldRates();
        setTimeout(() => {
          this.successMessage = false;
        }, 10000);
      },
      (error) => {
        this.isAcceptedOrRejected = false;
        this.showErrorAlert = true;
          this.div_visible = false;
          this.alertData = 'Error while actioning subsequent sold notification';
          this.failureMessage = true;
          setTimeout(() => {
            this.failureMessage = false;
          },  this.commonService.getProgressBarTimeOut());
      }

    );
  }

  addAdditionalProductDataToSoldRate(objData: any) {
    this.errorValue = objData.errorValue;
    this.errorFlag = objData.errorFlag;

    // Validate rate type consistency for the same Additional Product context
    if (!this.errorFlag && objData?.additionalProductData) {
      const newProduct = objData.additionalProductData;
      const existingPlan = this.rowData.find(plan => 
        plan.isAdditionalProduct &&
        plan.lob === newProduct.selectedLOBForAddProduct &&
        plan.fundingType === newProduct.selectedFundingType &&
        plan.productName === newProduct.productName &&
        plan.contractCode === newProduct.soldContractCode
      );
      
      if (existingPlan && existingPlan.rateType && existingPlan.rateType !== newProduct.rateType) {
        this.errorValue = `Cannot mix ${existingPlan.rateType} and ${newProduct.rateType} rate types for the same product. Please delete the existing plan or use ${existingPlan.rateType} rate type.`;
        this.errorFlag = true;
        return;
      }
    }

    if (!this.errorFlag) {
      if (objData?.additionalProductData && !this.empCategory.find(plan => plan.contractCode === objData?.additionalProductData?.soldContractCode && plan.lob === objData?.additionalProductData?.selectedLOBForAddProduct && plan.fundingType === objData?.additionalProductData?.selectedFundingType && plan.productName === objData?.additionalProductData?.productName && plan.employmentCategory.find(emp => objData?.additionalProductData?.selectedEmpCategory.find(e => e) === emp.emplymntCtgryCd))) {
        this.errorFlag = false;
        
        // Store the contract effective date by LOB when a product is successfully added
        const addedProduct = objData.additionalProductData;
        if (addedProduct && addedProduct.selectedLOBForAddProduct && addedProduct.contractEffectiveDate) {
          const lob = addedProduct.selectedLOBForAddProduct;
          const contractEffDate = addedProduct.contractEffectiveDate;
          
          // Store the contract effective date for this LOB
          this.updatedContractEffDatesByLOB[lob] = contractEffDate;
        }
      } else {
        this.errorValue = CommonConstants.CONTRACT_CODE_ALREADY_EXIST;
       return this.errorFlag = true;
      }
      this.additionalProductData = objData.additionalProductData;
      this.displayDialog = false;
      this.refreshData(true);
      let today = new Date();
      const getDate = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
      var time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
      let currentDate = getDate + ' ' + time;
      for (let empCat of this.selectedEmpCategory) {
        this.errorFlag = false;
        if (this.formData?.employmentCategory) {
          let obj;
          if (this.soldRates_form.controls.classValue.value) {
            obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB);
          } else {
            obj = this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB);
          }
          this.selectedSoldRatePlan.push(this.preparePlanData(obj, 'add', currentDate, null));
        }
      }
    }
  }

  onAdditionalProductPopUpClose = () => {
    this.displayDialog = false;
  }

   showAddlProductTabCondition(rowData) {
    return this.showAddlProductTab && ((rowData && rowData.length > 0) || (this.responseDataHistory && this.responseDataHistory.length > 0 && this.responseDataHistory.filter(e => e.plan.some(plan => plan.lob === CommonConstants.Medical || e.plan.lob === CommonConstants.SuppHealth || e.plan.lob === CommonConstants.Dental || e.plan.lob === CommonConstants.Vision))));
   }

  showDialogOnClick(event, number) {
    this.activeTab = number;
    this.errorValue = null;
    this.errorFlag = false;
    if (number === 2) {
      this.showDialogToAddProduct();
    }
  }

  onAddPlanPopUpCloseUpdate = () => {
    this.displayDialogUpdateForAddProduct = false;
  }

  updateAdditionalProductData(event) {
    if (event && !event.errorFlag) {
      this.errorFlagUpdate = false;
      this.displayDialogUpdateForAddProduct = false;
      if (event.additionalProductDataObj) {
        this.additionalProductDataObj = event.additionalProductDataObj;
      }
    } else {
      this.errorValueUpdate = CommonConstants.CONTRACT_CODE_ALREADY_EXIST;
      return this.errorFlagUpdate = true;
    }
    if (this.addlproductemptyObj?.length === 0) {
      this.additionalProductDataObj = [];
    }

  }

  enabledAsIsSoldForRenewalPlans(responseData) {
    responseData?.data?.quotes?.forEach(quote => {
      if (quote?.soldAsIsPlans?.length > 0 && this.renewalASIsSoldEnabled) {
        const option = 'As Is ' + quote.lob;
        if (!this.AddAsIsOptions.includes(option)) {
          this.AddAsIsOptions.push(option);
          this.myForm = new FormGroup({
            addAsIsOption: new FormControl(this.AddAsIsOptions[0])
          });
        }
      }

    })
  }

  onAddAsIsSoldClick(event) {
    let asIsSoldObj = this.soldRateFullResponse?.data?.quotes?.find(quote => 'As Is ' + quote.lob === event.target.innerText && quote?.soldAsIsPlans?.length > 0)?.soldAsIsPlans;
    let fundType = '';
    let planType = '';
    if (asIsSoldObj) {
      this.soldRateFullResponse?.data?.quotes?.forEach(quote => {
        this.isCaseNoSaved = true;

        quote.plans.forEach(plan => {
          let asIsSoldData = asIsSoldObj?.find(asIsPlan => (asIsPlan.contractCode === plan.contractCode || asIsPlan.quotedContractCode === plan.quotedContractCode) && asIsPlan.lob === plan.lob && asIsPlan.productName === plan.productName)

          if (asIsSoldData && plan) {
            fundType = asIsSoldData.fundingType;
            planType = asIsSoldData.planTypeRequested;
            let lob = asIsSoldData?.lob;
            this.getRateEffDate(lob);
            this.rateEffDate = this.datepipe.transform(this.rateEffDate, 'MM/dd/yyyy')
            if (this.rateEffDate && this.rateEffDate !== plan.rateEffectiveDate) {
              asIsSoldData.rateEffectiveDate = this.rateEffDate;
            } else {
              asIsSoldData.rateEffectiveDate = this.datepipe.transform(plan.rateEffectiveDate, 'MM/dd/yyyy');
            }

            if(asIsSoldData.contractCode !== asIsSoldData.quotedContractCode) {
              asIsSoldData.contractCode = asIsSoldData.quotedContractCode;
            }

            const planToUpdate = this.responseData?.find(p => p.lob === asIsSoldData?.lob);
            const contractEndDate = planToUpdate?.rateEndDate;
            // Use the latest edited rate effective date if available
            let latestEffDate = asIsSoldData?.rateEffectiveDate || planToUpdate?.rateEffectiveDate;
            if (planToUpdate && latestEffDate && contractEndDate) {
              planToUpdate.rateEffectiveDate = this.datepipe.transform(latestEffDate, 'MM/dd/yyyy');
              const start = new Date(latestEffDate);
              const end = new Date(contractEndDate);
              planToUpdate.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
            }
            asIsSoldData.rateGuaranteeMonths = planToUpdate.rateGuaranteeMonths;
            const planAgeBands = asIsSoldData.ageBandTierRates?.sort((a, b) => a.ageBandStart - b.ageBandStart) ?? [];
            let index = 0;
            for (var employmentCategory of asIsSoldData['employmentCategory']) {
              employmentCategory['tierRate'] = {};

              if (asIsSoldData.tierRate) {
                employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(asIsSoldData.tierRate?.eeRate* employmentCategory.emplymntCtgryFctr).toFixed(2));
                employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(asIsSoldData.tierRate?.esRate* employmentCategory.emplymntCtgryFctr).toFixed(2));
                employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(asIsSoldData.tierRate?.efRate* employmentCategory.emplymntCtgryFctr).toFixed(2));
                employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(asIsSoldData.tierRate?.ecRate* employmentCategory.emplymntCtgryFctr).toFixed(2));
                employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(asIsSoldData.tierRate?.ekRate* employmentCategory.emplymntCtgryFctr).toFixed(2));
                index = 0;
              } else {
                const ageBandTierRates = planAgeBands[index];
                if (ageBandTierRates) {
                  employmentCategory.ageBand = `${ageBandTierRates.ageBandStart}-${ageBandTierRates.ageBandEnd}`;
                  employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.eeRate));
                  employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.esRate));
                  employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.efRate));
                  employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.ecRate));
                  employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.ekRate));
                  index = index + 1;
                }
                if (index == planAgeBands.length) {
                  index = 0;
                }
              }
            }

            if (quote?.soldAsIsPlans?.length > 0) {
              Object.assign(plan, asIsSoldData);
              this.selectedOriginalLOB = asIsSoldData.lob;
            }

            this.rateEffDate = this.parseMMDDYYYYtoDate(asIsSoldData?.rateEffectiveDate);
            this.rateGuarMonths = asIsSoldData?.rateGuaranteeMonths;

            if (!this.submitOptions.find((x) => x === plan.lob)) {
              this.submitOptions.push(plan.lob);
            }
          }
        })
      })

      for (let plan of this.responseData) {
        this.savedCaseNumber = plan.caseNumber;
        if (plan.lob === event.target.innerText && plan.fundingType === fundType && plan.planTypeRequested === planType) {
          if (!this.contractCodes.find((x) => x.value === plan.quotedContractCode)) {
            this.contractCodes.push({
              label: plan.quotedContractCode,
              value: plan.quotedContractCode
            });
          }
        }

        let initialEnrollments;

        if (this.isRenewalLocalPresent
          && StringUtils.isEqual(plan.planTypeRequested, CommonConstants.FEATURE_PLAN_TYPE)
          && StringUtils.isEqual(plan.lob, CommonConstants.Medical)
          && plan.employmentCategory
          && plan.currPlanIds?.length == 1) {
          this.soldRateFullResponse?.currentPlans?.forEach((fullResponseCurrentPlans) => {
            if (StringUtils.isEqual(plan.currPlanIds[0], fullResponseCurrentPlans.id)) {
              initialEnrollments = this.soldRateFullResponse.mappedMedTierLivesMap[fullResponseCurrentPlans.contractCode];
            }
          });
          this.assignEnrollments(plan, initialEnrollments);
        }

      }

      this.refreshData(false, true);
      this.updateAdditionalProgramsAppliesTo();
    }

  }

  hideAlertMessages() {
    setTimeout(() => {
      this.successMessage = false;
      this.failureMessage = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  /**
   * Converts MM/DD/YYYY string to Date object
   */
  parseMMDDYYYYtoDate(dateStr) {
    if (!dateStr) return null;
    const parts = dateStr.split('/');
    if (parts.length !== 3) return null;
    const month = parseInt(parts[0], 10) - 1;
    const day = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    return new Date(year, month, day);
  }

  /**
   * Converts yyyy-MM-dd format to MM-dd-yyyy format for UI display
   */
  convertYYYYMMDDtoMMDDYYYY(dateStr: string): string {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${month}-${day}-${year}`;
  }

  /**
   * Converts MM-dd-yyyy format to yyyy-MM-dd format for API payload
   */
  convertMMDDYYYYtoYYYYMMDD(dateStr: string): string {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const month = parts[0];
    const day = parts[1];
    const year = parts[2];
    return `${year}-${month}-${day}`;
  }
}
