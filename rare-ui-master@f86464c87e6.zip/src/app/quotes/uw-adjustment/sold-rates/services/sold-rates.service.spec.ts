import { TestBed } from '@angular/core/testing';

import { SoldRatesService } from './sold-rates.service';

describe('SoldRateService', () => {
  let service: SoldRatesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SoldRatesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
