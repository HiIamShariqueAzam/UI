import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { StringUtils } from "../../../../shared/utils/string-utils";

@Injectable({
  providedIn: 'root'
})
export class SoldRatesService {

  constructor(
    private http: HttpClient,
    private commonService: CommonService) {
  }

  getSoldRatesGrid(opportunityID, quoteHeaderID, fundingType) {
    const headers = this.commonService.setRequestHeadersSoldRate();
    const url = `${this.commonService.getRareUiUrl()}/soldRates/restructure?opportunityID=${opportunityID}&quoteHeaderID=${quoteHeaderID}&fundingType=${fundingType}`;
    return this.http.get<any>(url, { headers: headers });
  }

  getSoldRatesHistoryGrid(opportunityID, quoteHeaderID, fundingType) {
    const headers = this.commonService.setRequestHeadersSoldRate();
    const url = `${this.commonService.getRareUiUrl()}/soldRates/restructure/history?opportunityID=${opportunityID}&quoteHeaderID=${quoteHeaderID}&fundingType=${fundingType}`;
    return this.http.get<any>(url, { headers: headers });
  }

  submitSoldRates(soldRates) {
    let headers = this.commonService.setSubmitHeadersSoldRate("meta-transid", soldRates.data?.data?.quotes[0]['ratingTransID']);
    let request = this.buildSubmitRequest(soldRates.data);
    let rareUiRequest = this.commonService.getRareUiRequest(request); 
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/ui/restructure/soldRates", rareUiRequest, { headers: headers });
  }

  private buildSubmitRequest(soldRatesData: any) {
    let quotes = this.populateEmploymentCategories(soldRatesData, soldRatesData.data.quotes);
    quotes = this.filterQuotePlansWithEmploymentCategory(quotes, soldRatesData.plan);
    let quoteOrigin = this.commonService.getQuoteOrigin(soldRatesData.data);
    const groupCreditsAndFunds = soldRatesData.data.groupCreditsAndFunds;
    quotes.forEach(quote => {
      if(!quote?.quoteOrigin) {
        quote.quoteOrigin = quoteOrigin
      }
    })
    // Build data object conditionally
    const dataPayload: any = {
      opportunityID: soldRatesData.data.opportunityID,
      quoteHeaderID: soldRatesData.data.quoteHeaderID,
      caseName: soldRatesData.data.caseName,
      caseNumber: soldRatesData.data.caseNumber,
      quotes: quotes,
      quoteOrigin: quoteOrigin
    };
    if (
      soldRatesData.data.groupCreditsAndFunds && (
        (Array.isArray(soldRatesData.data.groupCreditsAndFunds) && soldRatesData.data.groupCreditsAndFunds.length > 0) ||
        (typeof soldRatesData.data.groupCreditsAndFunds === 'object' && !Array.isArray(soldRatesData.data.groupCreditsAndFunds) && Object.keys(soldRatesData.data.groupCreditsAndFunds).length > 0)
      )
    ) {
      dataPayload.groupCreditsAndFunds = soldRatesData.data.groupCreditsAndFunds;
    }
    return {
      soldRates: {
        data: dataPayload,
        metaData: {
          metaTransID: "metaTransID",
          sourceSystem: "RARE",
          targetSystem: "RARE",
          messageType: "RateRequest",
          boomerangID: null,
          transmissionID: null
        }
      }
    };
  }

  saveSoldRates(soldRates, opportunityID, soldAuditTrail, action) {
    let headers = this.commonService.setRequestHeadersSoldRate();
    let request = this.buildSaveRequest(soldRates, soldAuditTrail, action);
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    return this.http.put<any>(this.commonService.getRareUiUrl() + "/soldRates/restructure/save?opportunityID=" + opportunityID, rareUiRequest, { headers: headers });
  }

  /**
   * Removes all quotes that do not have plans with employment category
   * @param quotes
   * @param plans
   * @private
   */
  private filterQuotePlansWithEmploymentCategory(quotes, plans) {
    quotes?.forEach(quote => {
      quote.plans = quote?.plans.filter(plan => plan.employmentCategory != null);
    })
    // Remove quotes which do not have any plans with emp
    return quotes?.filter(quote => plans.some(plan => StringUtils.isEqualIgnoreCase(quote.lob, plan.lob)));
  }

  private buildSaveRequest(soldRatesData: any, soldAuditTrail: any, action: string){
    let quotes = this.populateEmploymentCategories(soldRatesData, soldRatesData.data.quotes);
    // Use groupCreditsAndFunds from the special property if present
    const groupCreditsAndFunds = soldRatesData._groupCreditsAndFundsForSave || [];
    return {
      opportunityID: soldRatesData.data.opportunityID,
      quoteHeaderID: soldRatesData.data.quoteHeaderID,
      soldRates: {
        caseNumber: soldRatesData.caseNumber,
        groupCreditsAndFunds: groupCreditsAndFunds,
        quote: quotes,
        action: action,
        soldAuditTrail: soldAuditTrail
      }
    }
  }

  private populateEmploymentCategories(soldRatesData, quotes) {
    soldRatesData?.plan.forEach(plan => {
      quotes.forEach(quote => {
        if(!quote.soldAddlProduct) {
        let quotePlan = quote.plans?.find(quotePlan => StringUtils.isEqualIgnoreCase(quotePlan?.ratingPlanID, plan?.ratingPlanID));
        if (quotePlan) {
          quotePlan.employmentCategory = plan.employmentCategory;
          quote.caseName = plan.caseName;
        }
        }
        quote.caseNumber = soldRatesData.caseNumber;
      })
      
    })
    return quotes;
  }

  getSoldRatesAdditionalPrograms(state, factorEffDate, quoteEffDate, fundingType) {
    let headers = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + "/ui/manager/additional-programs?state=" + state + '&factorEffectiveDate=' + factorEffDate + '&quoteEffDate=' + quoteEffDate + '&fundingType=' + fundingType,
      { headers: headers })
  }

  actionSubsequentSoldNotification(opportunityID: string, quoteHeaderID: string, action: string) {
    const headers = this.commonService.setRequestHeadersSoldRate();
    const url = `${this.commonService.getRareUiUrl()}/soldRates/restructure/${action}/subsequentSoldRequest?opportunityID=${opportunityID}&quoteHeaderID=${quoteHeaderID}`;
    return this.http.get<any>(url, { headers: headers, responseType: 'text' as 'json' });
  }

}
