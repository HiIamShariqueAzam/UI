import { NgModule } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { SoldRatesComponent } from './sold-rates.component';
import { RouterModule } from '@angular/router';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import { DialogModule } from 'primeng/dialog';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { SoldRatesHistoryComponent } from './sold-rate-history/sold-rates-history.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { TooltipModule } from "primeng/tooltip";
import { DatePickerModule } from 'primeng/datepicker';
import { NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { AdditionalProductComponent } from './additional-product/additional-product.component';
@NgModule({
    declarations: [
        SoldRatesComponent,
        SoldRatesHistoryComponent,
        AdditionalProductComponent
    ],
    imports: [
        CommonModule, TableModule, ButtonModule, MultiSelectModule, SelectModule, FormsModule, CheckboxModule, DialogModule, DatePickerModule, ReactiveFormsModule, RouterModule.forChild([
            {path: '', component: SoldRatesComponent, pathMatch: 'full'}
        ]), ProgressSpinnerModule, ConfirmDialogModule, TooltipModule, NgbCollapseModule
    ],
    exports: [
        SoldRatesComponent,
        SoldRatesHistoryComponent
    ],
    providers: [
        RouterModule, DecimalPipe, DatePipe, ConfirmationService
    ]
})
export class SoldRatesModule { }
