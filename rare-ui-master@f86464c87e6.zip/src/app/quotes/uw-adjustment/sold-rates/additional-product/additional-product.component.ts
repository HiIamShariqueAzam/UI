import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild, input } from '@angular/core';
import { MultiSelect } from 'primeng/multiselect';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { DatePipe, DecimalPipe } from '@angular/common';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';

export class RateInfo {
  'eeRate': number;
  'esRate': number;
  'efRate': number;
  'ecRate': number;
  'ekRate': number;
  'compositeRate': number;
}
@Component({
  selector: 'app-additional-product',
  templateUrl: './additional-product.component.html',
  styleUrls: ['./additional-product.component.css'],
  standalone: false
})
export class AdditionalProductComponent implements OnInit, OnDestroy {
  quoteId: number;
  adjustmentId: number;
  isDataLoaded: boolean = false;
  isFormDirty: boolean = false;
  isFormSubmitted: boolean = false;
  @Input() rateGuarMonths: number | null = null;
  @Output() rateGuarMonthsChange = new EventEmitter<number | null>();
  @ViewChild('includeInRatesMultiSelect') includeInRatesMultiSelect: MultiSelect;
  @Input() priorCaseNumber: string;
  @Input() selectedLOBForAddProduct: string;
  @Input() lobValuesForAddProduct: Array<any>;
  @Input() selectedFundingType: string;
  @Input() fundingTypes: Array<any>;
  @Input() caseNumber: string;
  @Input() categoryList: Array<any>;
  @Input() empCatValue: Array<any>;
  @Input() isRenewalLocalPresent: boolean; // Changed to boolean
  @Input() isMedicalRenewalLocalPresent: boolean; // Changed to boolean
  @Input() classCode: string;
  @Input() selectedEmpCategory: string;
  @Input() selectedRateType: string;
  @Input() errorFlag: boolean; // Changed to boolean
  @Input() errorValue: string;
  @Input() displayAddProductDialog: boolean;
  @Input() rateInfo: any;
  @Input() addRateInfo: any;
  @Input() displayDialogUpdateForAddProduct: boolean;
  @Input() planValueUpdate: any;
  @Input() caseNumberUpdate: string;
  @Input() empCatValueUpdate: Array<any>;
  @Input() disableUpdate: boolean;
  @Input() categoryListUpdate: Array<any>;
  @Input() formDataUpdate: any;
  @Input() errorFlagUpdate: boolean; 
  @Input() errorValueUpdate: string;
  @Input() productNameUpdate: string;
  @Input() soldContractCodeUpdate: string;
  @Input() classCodeUpdate: string;
  @Input() formDataUpdateForAddProduct: any;
  @Input() additionalProductDataObj: any;
  @Input() lobUpdate: string;
  @Input() activeTab: number;
  @Input() addToMedicalForHRAHSA: boolean;
  @Input() showRateEffDate: boolean;
  @Input() isReadOnlyRole: boolean;
  @Input() rateEffDate: any;
  @Input() rateEffDateUpdate: any;
  @Input() rateGuarMonthsUpdate: any;
  @Input() responseData: any;
  @Input() contractEffDate: any;
  @Input() contractEffDateUpdate: any;
  @Input() getLOBForAddProduct: (event: any) => void;
  @Input() getFundingType: (event: any) => void;
  @Input() omit_special_char: (event: any) => void; // Changed to camelCase
  @Input() onPaste: (event: any) => void;
  @Input() getSoldContractCode: (event: any) => void;
  @Input() getCategory: (event: any) => void;
  @Input() isNumber: (event: any) => void;
  @Input() onChangeOfEEActiveTierDuplicateForAddlProduct: (cat: string) => void;
  @Input() onChangeOfESActiveTierDuplicateForAddlProduct: (cat: string) => void;
  @Input() onChangeOfEKActiveTierDuplicateForAddlProduct: (cat: string) => void;
  @Input() onChangeOfECActiveTierDuplicateOthersForAddlProduct: (cat: string) => void;
  @Input() onChangeOfEFActiveTierDuplicateOthersForAddlProduct: (cat: string) => void;
  @Input() onAdditionalProductPopUpClose: () => void;
  @Input() onAddPlanPopUpCloseUpdate: () => void;
  @Output() addDataToSoldRate = new EventEmitter<any>();
  @Output() updateAdditionalProductData = new EventEmitter<any>();
  @Input() updateRateEffDate: (event: any, value: string, isAdditional?: boolean) => void;
  @Input() rateTypeOptions: string[] = ['Tiered', 'Composite'];
  @Input() unitTypeOptions: Array<{unitType: string, dfltInd: string}> = [{unitType: 'PCPM', dfltInd: 'Y'}];
  @Input() savedRateTypeForUpdate: string;
  @Input() savedUnitTypeForUpdate: string;
  @Input() existingPlans: any[] = [];
  @Input() onChangeOfCompositeRateActiveDuplicateForAddlProduct: (cat: string) => void;

  soldContractCode: string;
  productName: string;
  isIncludeInRates: boolean = true;
  includeInRates = 'Medical';
  classCodeBeforeUpdate: string;
  selectedRateTypeForAddProduct: string = 'Tiered';
selectedUnitTypeForAddProduct: string = 'PCPM';

  constructor(public datepipe: DatePipe,
    private commonQuoteService: CommonQuoteService,
  ) { }

  ngOnInit() {
  this.classCodeBeforeUpdate = this.classCodeUpdate;
  
  // If updating, use saved rate type and unit type
  if (this.savedRateTypeForUpdate) {
    this.selectedRateTypeForAddProduct = this.savedRateTypeForUpdate;
  } else if (this.rateTypeOptions && this.rateTypeOptions.length > 0) {
    if (this.rateTypeOptions.includes('Tiered')) {
      this.selectedRateTypeForAddProduct = 'Tiered';
    } else {
      this.selectedRateTypeForAddProduct = this.rateTypeOptions[0];
    }
  }
  
  if (this.savedUnitTypeForUpdate) {
    this.selectedUnitTypeForAddProduct = this.savedUnitTypeForUpdate;
  } else if (this.unitTypeOptions && this.unitTypeOptions.length > 0) {
    const defaultUnit = this.unitTypeOptions.find(ut => ut.dfltInd === 'Y');
    if (defaultUnit) {
      this.selectedUnitTypeForAddProduct = defaultUnit.unitType;
    } else {
      this.selectedUnitTypeForAddProduct = this.unitTypeOptions[0].unitType;
    }
  }
}

  ngOnDestroy() {
    // Cleanup logic here
  }

  onAddPlanPopUpClose() {
    this.onAdditionalProductPopUpClose();
  }

  onRateTypeChange(newRateType: string) {
  if (!this.addRateInfo) return;
  if (newRateType === 'Composite') {
    this.clearTierRates();
  } else if (newRateType === 'Tiered') {
    this.clearCompositeRates();
  }
}

clearTierRates() {
  if (this.selectedEmpCategory && this.addRateInfo) {
    const categories = Array.isArray(this.selectedEmpCategory) ? this.selectedEmpCategory : [this.selectedEmpCategory];
    categories.forEach((empCat: string) => {
      if (this.addRateInfo[empCat]) {
        this.addRateInfo[empCat].eeRate = null;
        this.addRateInfo[empCat].esRate = null;
        this.addRateInfo[empCat].ekRate = null;
        this.addRateInfo[empCat].ecRate = null;
        this.addRateInfo[empCat].efRate = null;
      }
    });
  }
}

clearCompositeRates() {
  if (this.selectedEmpCategory && this.addRateInfo) {
    const categories = Array.isArray(this.selectedEmpCategory) ? this.selectedEmpCategory : [this.selectedEmpCategory];
    categories.forEach((empCat: string) => {
      if (this.addRateInfo[empCat]) {
        this.addRateInfo[empCat].compositeRate = null;
      }
    });
  }
}

  saveAdditionalProduct() {
    this.validateAddProductFormSaveCommon();
  }

  validateAddProductFormSaveCommon() {
    this.errorValue = '';
    this.categoryList.forEach((element) => {
  if (this.empCatValue.filter((empCat) => empCat === element.value).length > 0) {
    if (this.selectedRateTypeForAddProduct === 'Composite') {
      if (!this.addRateInfo[element.value].compositeRate) this.errorValue = 'Please Enter Composite Rate for ' + element.label;
    } else {
      if (!this.addRateInfo[element.value].efRate) this.errorValue = 'Please Enter Employee+Family Rate for ' + element.label;
      if (!this.addRateInfo[element.value].ecRate) this.errorValue = 'Please Enter Employee+Children Rate for ' + element.label;
      if (!this.addRateInfo[element.value].ekRate) this.errorValue = 'Please Enter Employee+Child Rate for ' + element.label;
      if (!this.addRateInfo[element.value].esRate) this.errorValue = 'Please Enter Employee+Spouse Rate for ' + element.label;
      if (!this.addRateInfo[element.value].eeRate) this.errorValue = 'Please Enter Employee Rate for ' + element.label;
    }
  }
});

    if (!this.selectedEmpCategory) this.errorValue = 'Please Select Employment Category Code';

    if (!this.soldContractCode) this.errorValue = 'Please Enter Sold Contract Code';
    if (!this.productName) this.errorValue = 'Please Enter Product Name';

    if (!this.selectedFundingType) this.errorValue = 'Please Select Sold Funding Type';

    if (!this.caseNumber) this.errorValue = 'Please Enter Case Number to proceed';

    if (!this.contractEffDate) this.errorValue = 'Please Enter Contract Effective Date to proceed';


    if (!this.errorValue) {
      this.errorFlag = false;
      let calculatedRateEndDate = null;
      if (this.rateEffDate && this.rateGuarMonths) {
        const effDate = new Date(this.rateEffDate);
        const newEndDate = this.commonQuoteService.calculateRateEndDate(effDate, this.rateGuarMonths);
        calculatedRateEndDate = this.datepipe.transform(newEndDate, 'MM/dd/yyyy');
      }
      let additionalProductData: any = {
        selectedLOBForAddProduct: this.selectedLOBForAddProduct,
        selectedFundingType: this.selectedFundingType,
        caseNumber: this.caseNumber,
        soldContractCode: this.soldContractCode,
        productName: this.productName,
        selectedEmpCategory: this.selectedEmpCategory,
        classCode: this.classCode,
        rateEffectiveDate: this.rateEffDate,
        contractEffectiveDate: this.convertMMDDYYYYtoYYYYMMDD(this.datepipe.transform(this.contractEffDate, 'MM-dd-yyyy')),
        rateGuarMonths: this.rateGuarMonths,
        rateEndDate: calculatedRateEndDate,
        rateType: this.selectedRateTypeForAddProduct,
        unitType: this.selectedUnitTypeForAddProduct,
        rateInfo: typeof this.addRateInfo === 'object' && this.addRateInfo !== null ? Object.keys(this.addRateInfo).map((key: string) => ({
            ...this.addRateInfo[key],
            empCategory: key,
            e1Rate: null,
            ageBandStart: null,
            ageBandEnd: null
          })) : []
        };
      let objData = {
        additionalProductData: additionalProductData,
        errorValue: this.errorValue,
        errorFlag: this.errorFlag
      }
      this.addDataToSoldRate.emit(objData);
    } else {
      this.errorFlag = true;
      let objData = {
        additionalProductData: null,
        errorValue: this.errorValue,
        errorFlag: this.errorFlag
      }
      this.addDataToSoldRate.emit(objData);
    }
  }

  resetForm() {
    this.errorFlag = false;
    this.errorValue = '';
    this.soldContractCode = '';
    this.productName = '';
    this.selectedLOBForAddProduct = null;
    this.selectedFundingType = '';
    this.selectedEmpCategory = '';
    this.addRateInfo = {};
  }

  getCategoryUpdate(event: any) {
    // this.getCategory(event);
  }

  updateRateGuaranteeMonths(rateGuarMonths, CCValueUpdate): void {
    // If event is from input[type=number], get value
    const months = rateGuarMonths && rateGuarMonths.value ? rateGuarMonths.value : rateGuarMonths;
    if (months && CCValueUpdate) {
      // Implement logic as needed for additional product
      if (this.additionalProductDataObj && this.additionalProductDataObj.plan) {
        const plan = this.additionalProductDataObj.plan;
        if (plan && plan.rateEndDate) {
          const effDate = new Date(plan.rateEffectiveDate);
          // You may need to inject and use CommonQuoteService as in sold-rates.component
          // const newEndDate = this.commonQuoteService.calculateRateEndDate(effDate, months);
          // plan.rateEndDate = this.datepipe.transform(newEndDate, 'MM/dd/yyyy');
          // plan.rateGuaranteeMonths = months;
        }
      }
    }
    this.rateGuarMonths = months;
    this.rateGuarMonthsChange.emit(months);
  }

  getRateGuaranteeMonths(rateEffDate: any) {
    // Update rateGuaranteeMonths when adding a plan
    const planToUpdate = this.responseData?.find(p => p.lob === CommonConstants.Medical);
    const contractEndDate = planToUpdate?.rateEndDate;
    // Use the latest edited rate effective date if available
    let latestEffDate = rateEffDate || planToUpdate?.rateEffectiveDate;
    if (planToUpdate && latestEffDate && contractEndDate) {
      planToUpdate.rateEffectiveDate = this.datepipe.transform(latestEffDate, 'MM/dd/yyyy');
      const start = new Date(latestEffDate);
      const end = new Date(contractEndDate);
      return planToUpdate.rateGuaranteeMonths = this.commonQuoteService.calculateRateGuaranteeMonths(start, end);
    }
  }

  updateQLI() {
    if (!this.additionalProductDataObj.find(plan => plan.contractCode === this.soldContractCodeUpdate && plan.lob === this.lobUpdate && plan.productName === this.productNameUpdate && this.classCodeBeforeUpdate === this.classCodeUpdate && plan.rateEffectiveDate === this.rateEffDateUpdate)) {
      this.additionalProductDataObj.forEach(dataObj => {
        if (dataObj.lob === this.lobUpdate && dataObj.contractCode === this.planValueUpdate.contractCode && dataObj.productName === this.planValueUpdate?.productName) {
          dataObj.productName = this.productNameUpdate;
          dataObj.contractCode = this.soldContractCodeUpdate;
          dataObj.caseNumber = this.caseNumberUpdate;
          dataObj.rateEffectiveDate = this.datepipe.transform(this.rateEffDateUpdate, 'MM/dd/yyyy');
          dataObj.contractEffectiveDate = this.convertMMDDYYYYtoYYYYMMDD(this.datepipe.transform(this.contractEffDateUpdate, 'MM-dd-yyyy'));
          // Use updated rate guarantee months if provided, else fallback to calculated value
          dataObj.rateGuaranteeMonths = this.rateGuarMonthsUpdate != null ? this.rateGuarMonthsUpdate : this.getRateGuaranteeMonths(this.rateEffDateUpdate);
          const effDate = new Date(dataObj.rateEffectiveDate);
          const newEndDate = this.commonQuoteService.calculateRateEndDate(effDate, dataObj.rateGuaranteeMonths);
          dataObj.rateEndDate = this.datepipe.transform(newEndDate, 'MM/dd/yyyy');
          dataObj.employmentCategory.forEach(empCat => {
            empCat.employmentClassCode = this.classCodeUpdate;
          });
        }
      })
      let updateObjData = {
        additionalProductData: this.additionalProductDataObj,
        errorValue: '',
        errorFlag: false
      }

      this.updateAdditionalProductData.emit(updateObjData)
    } else {
      let updateObjData;
      if (this.soldContractCodeUpdate === this.planValueUpdate.contractCode && this.productNameUpdate === this.planValueUpdate?.productName) {
        updateObjData = {
          additionalProductData: this.additionalProductDataObj,
          errorValue: '',
          errorFlag: false
        }
      } else {
        this.errorValueUpdate = CommonConstants.CONTRACT_CODE_ALREADY_EXIST;
        updateObjData = {
          additionalProductData: this.additionalProductDataObj,
          errorValue: this.errorValueUpdate,
          errorFlag: true
        }
      }
      this.updateAdditionalProductData.emit(updateObjData)
    }
  }

  /**
   * Converts yyyy-MM-dd format to MM-dd-yyyy format for UI display
   */
  convertYYYYMMDDtoMMDDYYYY(dateStr: string): string {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${month}-${day}-${year}`;
  }

  /**
   * Converts MM-dd-yyyy format to yyyy-MM-dd format for API payload
   */
  convertMMDDYYYYtoYYYYMMDD(dateStr: string): string {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const month = parts[0];
    const day = parts[1];
    const year = parts[2];
    return `${year}-${month}-${day}`;
  }

}