export class SoldRatesConstants
{
    public static CURRENT_PLAN_SELECT_MSG = "Please select current plan";
    public static CURRENT_PLAN_MAP_MSG = "Map the current plan to sold plan";
    public static ACTIVE = "active";
    public static NEWBUSINESS_COLS = [
        {
          "header": "Qted CC",
          "field": "quotedContractCode"
        },
        {
          "header": "Sold CC",
          "field": "contractCode"
        },
        {
          "header": "Empl Ctgry Cd",
          "field": "employmentCategoryCode"
        },
        {
          "header": "Class",
          "field": "classCode"
        },
        {
          "header": "LOB",
          "field": "lob"
        },
        {
          "header": "FA Type",
          "field": "fundingType"
        },
        {
          "header": "Product Name",
          "field": "productName"
        },
        {
          "header": "Age Band",
          "field": "ageBand"
        },
        {
          "header": "Composite",
          "field": "compositeRate"
        },
        {
          "header": "SINGLE (A & B)",
          "field": "eeRate"
        },
        {
          "header": "TWO PARTY (C & D)",
          "field": "esRate"
        },
        {
          "header": "EE + Child (E)",
          "field": "ekRate"
        },
        {
          "header": "EE + CH(N) (E & H)",
          "field": "ecRate"
        },
        {
          "header": "Family (F & G)",
          "field": "efRate"
        },
        {
          "header": "<65 Spouse of Mdcr Eligible (J)",
          "field": "medicareElgSpouseL65"
        },
        {
          "header": "<65 Spouse+Ch of Mdcr Eligible (K)",
          "field": "medicareElgSpouseChildL65"
        },
        {
          "header": "Comm Lvl",
          "field": "commissionValue"
        },
        {
          "header": "Comm Typ",
          "field": "commissionType"
        },
        {
          "header": "Embed Vis PSPM",
          "field": "embeddedVision"
        },
        {
          "header": "Embed Den PSPM",
          "field": "embeddedDental"
        },
        {
          "header": "Rt Eff Dt",
          "field": "rateEffectiveDate"
        },
        {
          "header": "Rt Grnte Mons",
          "field": "rateGuaranteeMonths"
        }
      ]
      public static RENEWAL_COLS= [
        {
          "header": "Qted CC",
          "field": "quotedContractCode"
        },
        {
          "header": "Sold CC",
          "field": "contractCode"
        },
        {
          "header": "Empl Ctgry Cd",
          "field": "employmentCategoryCode"
        },
        {
          "header": "Class",
          "field": "classCode"
        },
        {
          "header": "LOB",
          "field": "lob"
        },
        {
          "header": "FA Type",
          "field": "fundingType"
        },
        {
          "header": "Product Name",
          "field": "productName"
        },
        {
          "header": "Age Band",
          "field": "ageBand"
        },
        {
          "header": "Composite",
          "field": "compositeRate"
        },
        {
          "header": "SINGLE (A & B)",
          "field": "eeRate"
        },
        {
          "header": "TWO PARTY (C & D)",
          "field": "esRate"
        },
        {
          "header": "EE + Child (E)",
          "field": "ekRate"
        },
        {
          "header": "EE + CH(N) (E & H)",
          "field": "ecRate"
        },
        {
          "header": "Family (F & G)",
          "field": "efRate"
        },
        {
          "header": "SINGLE (A & B) Enroll",
          "field": "eeRateEnrollment"
        },
        {
          "header": "TWO PARTY (C & D) Enroll",
          "field": "esRateEnrollment"
        },
        {
          "header": "EE + Child (E) Enroll",
          "field": "ekRateEnrollment"
        },
        {
          "header": "Family (F & G) Enroll",
          "field": "efRateEnrollment"
        },
        {
          "header": "EE + CH(N) (E & H) Enroll",
          "field": "ecRateEnrollment"
        },
        {
          "header": "<65 Spouse of Mdcr Eligible (J)",
          "field": "medicareElgSpouseL65"
        },
        {
          "header": "<65 Spouse+Ch of Mdcr Eligible (K)",
          "field": "medicareElgSpouseChildL65"
        },
        {
          "header": "Comm Lvl",
          "field": "commissionValue"
        },
        {
          "header": "Comm Typ",
          "field": "commissionType"
        },
        {
          "header": "Embed Vis PSPM",
          "field": "embeddedVision"
        },
        {
          "header": "Embed Den PSPM",
          "field": "embeddedDental"
        },
        {
          "header": "Rt Eff Dt",
          "field": "rateEffectiveDate"
        },
        {
          "header": "Rt Grnte Mons",
          "field": "rateGuaranteeMonths"
        }
      ]

      // this is for when age banded rates are available
      public static WITH_AGE_BANDED_COLS = [
        {
          "header": "Qted CC",
          "field": "quotedContractCode"
        },
        {
          "header": "Sold CC",
          "field": "contractCode"
        },
        {
          "header": "Empl Ctgry Cd",
          "field": "employmentCategoryCode"
        },
        {
          "header": "Class",
          "field": "classCode"
        },
        {
          "header": "LOB",
          "field": "lob"
        },
        {
          "header": "FA Type",
          "field": "fundingType"
        },
        {
          "header": "Product Name",
          "field": "productName"
        },
        {
          "header": "Age Band",
          "field": "ageBand"
        },
        {
          "header": "Composite",
          "field": "compositeRate"
        },
        {
          "header": "SINGLE (A & B)",
          "field": "eeRate"
        },
        {
          "header": "TWO PARTY (C & D)",
          "field": "esRate"
        },
        {
          "header": "EE + Child (E)",
          "field": "ekRate"
        },
        {
          "header": "EE + CH(N) (E & H)",
          "field": "ecRate"
        },
        {
          "header": "Family (F & G)",
          "field": "efRate"
        },
        {
          "header": "SINGLE (A & B) Enroll",
          "field": "eeRateEnrollment"
        },
        {
          "header": "TWO PARTY (C & D) Enroll",
          "field": "esRateEnrollment"
        },
        {
          "header": "EE + Child (E) Enroll",
          "field": "ekRateEnrollment"
        },
        {
          "header": "Family (F & G) Enroll",
          "field": "efRateEnrollment"
        },
        {
          "header": "EE + CH(N) (E & H) Enroll",
          "field": "ecRateEnrollment"
        },
        {
          "header": "<65 Spouse of Mdcr Eligible (J)",
          "field": "medicareElgSpouseL65"
        },
        {
          "header": "<65 Spouse+Ch of Mdcr Eligible (K)",
          "field": "medicareElgSpouseChildL65"
        },
        {
          "header": "Comm Lvl",
          "field": "commissionValue"
        },
        {
          "header": "Comm Typ",
          "field": "commissionType"
        },
        {
          "header": "Embed Vis PSPM",
          "field": "embeddedVision"
        },
        {
          "header": "Embed Den PSPM",
          "field": "embeddedDental"
        },
        {
          "header": "Rt Eff Dt",
          "field": "rateEffectiveDt"
        },
        {
          "header": "Rt Grnte Mons",
          "field": "rateGuaranteeMonths"
        }
      ]
      public static RETIREE_VALIDATION_MSG = "Select only one retiree type for the sold plan";
      public static RETIREE_OPTIONS = ["Under 65 Retiree", "Over 65 Retiree"];
      public static PRESENTATION_CREDIT = "Presentation Credit";
      public static TRANSITION_CREDIT = "Transition Credit";
      public static GROUP_CREDITS = "Group Credits";
      public static GROUP_FUNDS = "Group Funds";
      public static GROUP_HOLIDAY = "Holiday Premium Credit";
      public static GROUP_CREDITS_AND_FUNDS = "Group Credits and Funds";
}
