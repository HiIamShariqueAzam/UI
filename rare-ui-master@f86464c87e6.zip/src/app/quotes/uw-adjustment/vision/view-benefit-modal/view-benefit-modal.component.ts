import { Component, OnInit, Input, AfterViewInit, ElementRef, ViewChild } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: 'app-view-benefit-modal-dental',
  templateUrl: './view-benefit-modal.component.html',
  styleUrls: ['./view-benefit-modal.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class ViewBenefitModalComponent implements OnInit, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() planBenefits: any;
  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  ngOnInit() {
  }

}
