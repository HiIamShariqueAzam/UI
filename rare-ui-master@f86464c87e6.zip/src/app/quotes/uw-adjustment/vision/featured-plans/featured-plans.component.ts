import { Component, OnInit, Input, OnChanges, SimpleChanges, LOCALE_ID, Inject, ViewEncapsulation, ChangeDetectorRef, Output, EventEmitter } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { VisionUtil } from "../vision.util";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { VisionConstants } from "../vision.constants";
import { DateUtil } from 'src/app/shared/utils/date-util';
import { CommonConstants } from "src/app/shared/constants/common.constants";


@Component({
  selector: 'app-featured-plans-vision',
  templateUrl: './featured-plans.component.html',
  styleUrls: ['./featured-plans.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal],
  encapsulation: ViewEncapsulation.None
})
export class FeaturedPlansVisionComponent implements OnInit, OnChanges {

  @Input() featuredPlans: any[];
  @Input() status;
  @Input() boundariesObjName;
  // @Input() vpc1;
  @Input() quotelevelFailData;
  @Input() guardrailBoundariesToQuoteDetails;
  @Input() reqTier;
  @Input() EE;
  @Input() EF;
  @Input() ES;
  @Input() E1;
  @Input() EK;
  @Input() EC;
  @Input() isReadOnlyRole;
  @Input() rareData;
  @Input() rareDataObj;
  @Input() visionPremiumComparison;
  @Input() isFactorChanged;
  @Input() adjustedPlans;
  @Output() onFeaturedPlanRateChange = new EventEmitter<any>()

  factorEffectiveDate:any;
  benefitsColSpanF: any;
  expandClicked: boolean = true;
  planColumnsF: any;
  alternateQuote: boolean;
  // featuredPlans: any = [];
  rateColumns: any[];
  // visionPremiumComparison: any;
  planColumnsAfter = [
    { header: VisionConstants.viewCalc },
    { header: VisionConstants.contractCode },
    { header: VisionConstants.planName },
    { header: VisionConstants.genAgentCommission },
    { header: VisionConstants.association },
    { header: VisionConstants.adjustmentType },
    { header: VisionConstants.salesAdjustment },
    { header: VisionConstants.applyCurrentRatio },
    { header: VisionConstants.planType }
  ];
  planColumnsRenewal = [
    { header: VisionConstants.viewCalc },
    { header: VisionConstants.contractCode },
    { header: VisionConstants.planName },
    { header: VisionConstants.genAgentCommission },
    { header: VisionConstants.planType }
  ];
  planColumnsBefore = [
    { header: VisionConstants.viewCalc },
    { header: VisionConstants.contractCode },
    { header: VisionConstants.planName },
    { header: VisionConstants.genAgentCommission },
    { header: VisionConstants.association },
    { header: VisionConstants.adjustmentType },
    { header: VisionConstants.salesAdjustment },
    { header: VisionConstants.applyCurrentRatio },
    { header: VisionConstants.planType },
    { header: VisionConstants.participationType },
    { header: VisionConstants.eyeExam },
    { header: VisionConstants.eyeExamPlus },
    { header: VisionConstants.prescriptionLens },
    { header: VisionConstants.frames },
    { header: VisionConstants.framesPlue },
    { header: VisionConstants.electiveContactLens },
    { header: VisionConstants.electiveContactLensPlus },
    { header: VisionConstants.nonElectiveContactLens },
  ];
  planColumnsBeforeSG = [
    { header: VisionConstants.viewCalc },
    { header: VisionConstants.contractCode },
    { header: VisionConstants.planName },
    { header: VisionConstants.genAgentCommission },
    { header: VisionConstants.planType },
    { header: VisionConstants.participationType },
    { header: VisionConstants.eyeExam },
    { header: VisionConstants.eyeExamPlus },
    { header: VisionConstants.prescriptionLens },
    { header: VisionConstants.frames },
    { header: VisionConstants.framesPlue },
    { header: VisionConstants.electiveContactLens },
    { header: VisionConstants.electiveContactLensPlus },
    { header: VisionConstants.nonElectiveContactLens },
  ];
  fiveTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employee+' +' +VisionConstants.spouse },
    { header: VisionConstants.employee+' +' +VisionConstants.child },
    { header: VisionConstants.employee+' +' +VisionConstants.children },
    { header: VisionConstants.employee+' +' +VisionConstants.Family },
  ];
  fourTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employee+' +' +VisionConstants.spouse },
    { header: VisionConstants.employee+' +' +VisionConstants.children },
    { header: VisionConstants.employee+' +' +VisionConstants.Family },
  ];
  threeTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employeePlusOne },
    { header: VisionConstants.employee+' +' +VisionConstants.Family },
  ];
  twoTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employee+' +' +VisionConstants.Family },
  ];
  oneTierColumns = [
    { header: VisionConstants.employee },
  ];

  opportunityType: string;
  marketSegment: string;
  columnSpan:number;
  planColumnsFSG: any;
  isRenewalQuote: any;
  viewCalcPlan: any;
  isChangedFlag = false;
  myArr = [];
  adjustedArr = [];
  
  constructor(private changeDet: ChangeDetectorRef, @Inject(LOCALE_ID) private locale: string) {

  }
  ngOnChanges(changes:SimpleChanges) {
    if (changes.rareData && !changes.rareData.firstChange) {
      this.rareData = this.rareData;
      this.expandClicked = true;
      if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup)) {
        this.benefitsExpand();
      }
      
      this.handleFeaturedPlans();
      this.benefitsCols();
    }
    if (changes.rareDataObj && !changes.rareDataObj.firstChange) {
      this.handleFeaturedPlans();
      this.rareDataObj = this.rareDataObj;
    }
    if (changes.featuredPlans && !changes.featuredPlans.firstChange) {
      this.featuredPlans = this.featuredPlans;
    }
    if (changes.visionPremiumComparison && !changes.visionPremiumComparison.firstChange) {
      this.visionPremiumComparison = this.visionPremiumComparison;
    }
     
  }
  // check if the quote is renewal
  disableInputIfQuoteISRenewal() {    
    return StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)
  }

  disableInputIfQuoteIsSG() {
      return (StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup))
  }
  
  // Check if the calc popup to be disabled or not
  isCalcPopudDisabled() {
    if (StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && !( StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && (this.rareData?.vision?.oppOrigin?.['altMarket'] || this.rareData?.vision?.alternateQuote))) {
      return true;
    } else if (StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)){
      return true;
    } else {
      return false;
    }
  }
  // Check if the quote is small group renewal and display the tiered enrollments
  isSGRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
    this.isRenewalQuote = this.rareData.opportunityType;
    if ((StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) || ((StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && this.rareData?.vision?.oppOrigin?.['altMarket']))) {
      return false;
    } else if (StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
      return true;
    } else if (StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal)) {
      return false;
    }
  }
}
  
  ngOnInit() {
    this.factorEffectiveDate=this.rareData.factorEffectiveDate;
    this.opportunityType = this.rareData?.opportunityType;
    this.marketSegment = this.rareData?.marketSegment;
    this.benefitsColSpanF = 1;    
    this.planColumnsF = this.planColumnsAfter;
    this.setDynamicTier(this.reqTier);
    this.handleFeaturedPlans();
    this.alternateQuote = this.rareData?.vision?.alternateQuote;
  }
  // Getting featured plans from rareData object
  handleFeaturedPlans() {
    this.featuredPlans = [];
    if (this.rareDataObj['vision'] && this.rareDataObj['vision'].proposedPlans) {
      this.columnSpan=8;
      this.featuredPlans = this.rareDataObj.vision.proposedPlans.filter(plan => {
        return plan.planTypeRequested == 'F'
      });
    }
    this.benefitsCols();
  }
  // Check when to show benefits columns 
  benefitsCols() {
    this.planColumnsFSG = this.planColumnsRenewal;
    if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup)) {
      this.planColumnsF = this.planColumnsRenewal;
      this.columnSpan=4;
      this.planColumnsF.length = 5;
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)) {
      this.commonColSpan();
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)) {
      this.commonColSpan();
    }
  }
  commonColSpan() {
    this.columnSpan=4;
    this.planColumnsF.length = 8;
  }
  // Check if the quote is new business local
  showNewBusiness() {
    if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup)) {
      return false;
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)) {
      return false;
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup)) {
      return true;
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)) {
      return false;
    }
  }
  // Show benefits columns based on condition
  showBenefits() {
    if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup)) {
      return true;
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)) {
      return true;
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup)) {
      return true;
    } else if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)) {
      return true;
    }
  }
  // Expanding benefits columns 
  benefitsExpand() {
    this.expandClicked = !this.expandClicked;
    if (this.expandClicked) {
      this.benefitsColSpanF = 1;
      if (StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
          this.planColumnsF = this.planColumnsRenewal;
        } else {
          this.planColumnsF = this.planColumnsAfter;
        }
        this.planColumnsFSG = this.planColumnsRenewal;
    } else {
      if (!this.getDateDiff()) {
        this.benefitsColSpanF = 9;
        this.planColumnsF = this.planColumnsBefore.filter(planHeaders => {
          if (!StringUtils.isEqual(planHeaders.header,VisionConstants.electiveContactLensPlus)) {
            return true;
          }
        });
        this.planColumnsFSG = this.planColumnsBeforeSG.filter(planHeaders => {
          if (!StringUtils.isEqual(planHeaders.header,VisionConstants.electiveContactLensPlus)) {
            return true;
          }
        });
      }
      else {
        this.benefitsColSpanF = 10;
        if (StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup)) {
          this.planColumnsF = this.planColumnsBeforeSG;
        } else {
          this.planColumnsF = this.planColumnsBefore;
        }
        this.planColumnsFSG = this.planColumnsBeforeSG;
      }
  }
  }
  // Setting the tier value dynamically
  setDynamicTier(tierValue) {
    if (tierValue == 5) {
      this.rateColumns = this.fiveTierColumns;
    }
    else if (tierValue == 4)
      this.rateColumns = this.fourTierColumns;
    else if (tierValue == 3)
      this.rateColumns = this.threeTierColumns;
    else if (tierValue == 2)
      this.rateColumns = this.twoTierColumns;
    else if (tierValue == 1)
      this.rateColumns = this.oneTierColumns;
  }
 
  // Assigning a plan object on click of view calc 
  createViewCalcPopup(visPlan) {
    this.viewCalcPlan = {}
    this.viewCalcPlan = visPlan;
  }
  getCurrRatio() {
    return this.rareData['vision'].useCurrentCarrierTierRatio || ''
  }
  // Evaluating the guardrails failure at plan level
  markGuardRailFailuresPlanLevel(guardRail, visPlan) {
   return VisionUtil.markGuardRailFailuresPlanLevel(guardRail, visPlan)
  }
  // Evaluating the guardrails failure at quote level
  markGuardRailFailuresQuoteLevel(guardRail) {
    if (this.quotelevelFailData && this.quotelevelFailData[guardRail]) {
      return "toolTipDiv";
    } else { return false; }
  }
 
  // Display the guardrail error message
  displayErrorMessage(eleID) {
    if (this.boundariesObjName.hasOwnProperty(eleID)) {
      return VisionUtil.displayGuardrailErrorMessage(eleID, this.boundariesObjName);
    }
  }

  // Get the commission value and check if it is PCPM or Others
  getCommissionVal(visPlan) {
    let val = visPlan.commissionValue ? visPlan.commissionValue : 0;
    if (StringUtils.isEqual(visPlan.commissionType, VisionConstants.pcpm)) {
      return VisionConstants.dollar + val + '/' + VisionConstants.pcpm;
    } 
    else if (StringUtils.isEqual(visPlan.commissionType, VisionConstants.other)) {
      return visPlan.commissionRule ? visPlan.commissionRule : '';
    }
    else {
      return val + VisionConstants.percent;
    }
  }

  // Calculate and get the tier rates
  getTierRates(visPlan, tierVal, ageBand?) {
    let outputTier = this.rareData['visionOutputTier'];
    if (this.disableInputIfQuoteISRenewal() && this.isFactorChanged) {
      this.rareDataObj.vision.proposedPlans.forEach(item => {
        if (item.ratingPlanID == visPlan.ratingPlanID) {
          if (outputTier == 1) {
            visPlan.rateInfo.single = this.roundedValue(visPlan.initialRates.single * this.isAdjustedPlansAvailable(visPlan));
          } else if (outputTier == 2) {
            visPlan.rateInfo.single = this.roundedValue(visPlan.initialRates.single * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.family = this.roundedValue(visPlan.initialRates.family * this.isAdjustedPlansAvailable(visPlan));
          } else if (outputTier == 3) {
            visPlan.rateInfo.single = this.roundedValue(visPlan.initialRates.single * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.eeOne = this.roundedValue(visPlan.initialRates.eeOne * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.family = this.roundedValue(visPlan.initialRates.family * this.isAdjustedPlansAvailable(visPlan));
          } else if (outputTier == 4) {
            visPlan.rateInfo.single = this.roundedValue(visPlan.initialRates.single * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.eeSpouse = this.roundedValue(visPlan.initialRates.eeSpouse * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.eeChildren = this.roundedValue(visPlan.initialRates.eeChildren * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.family = this.roundedValue(visPlan.initialRates.family * this.isAdjustedPlansAvailable(visPlan));
          } else if (outputTier == 5) {
            visPlan.rateInfo.single = this.roundedValue(visPlan.initialRates.single * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.eeSpouse = this.roundedValue(visPlan.initialRates.eeSpouse * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.eeChild = this.roundedValue(visPlan.initialRates.eeChild * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.eeChildren = this.roundedValue(visPlan.initialRates.eeChildren * this.isAdjustedPlansAvailable(visPlan));
            visPlan.rateInfo.family = this.roundedValue(visPlan.initialRates.family * this.isAdjustedPlansAvailable(visPlan));
          }
        }
      });
      this.returnVPC(tierVal, visPlan)
      return this.formatDisplayValue(visPlan.rateInfo[tierVal]);
    } else {
      return this.formatDisplayValue(visPlan.rateInfo[tierVal]);
    }
  }
  // Check if the adjusted plan is available in the adjusted plans array and return the adjusted factor
  // Return one if the adjusted factor is invalid or not found
  isAdjustedPlansAvailable(visPlan) {    
    if (this.adjustedPlans.length) {
      const findIndex = this.adjustedPlans.findIndex(obj => obj.ratingPlanID === visPlan.ratingPlanID);
      
      if (findIndex === -1) {
        return (visPlan.uwDiscret || 1);
      }
      if(!this.adjustedPlans[findIndex].uwAdjustment) {
          return (visPlan.uwDiscret || 1);
      
      } else {
      return this.adjustedPlans[findIndex].uwAdjustment == null ? 1 : this.adjustedPlans[findIndex].uwAdjustment;
      }
    } else {
      return (visPlan.uwDiscret || 1)
    }
  }

    roundedValue(value: number): number {
    return Math.round(value * 1000) / 1000;
  }

  // Format value for display to always show 2 decimal places
  formatDisplayValue(value: any): string {
    if (value === null || value === undefined || value === '') {
      return '';
    }
    const numValue = Number(value);
    if (isNaN(numValue)) {
      return '';
    }
    return numValue.toFixed(2);
  }

  // Assigning featured plans rates to quote rates in premium comparison array.
  returnVPC(tierVal, visPlan) {
    if (this.visionPremiumComparison) {
      const findIndex = this.visionPremiumComparison.planComparison.findIndex(obj => obj.quoteRatingPlanID === visPlan.ratingPlanID)
      this.visionPremiumComparison.planComparison.forEach(element => {
        if (visPlan.ratingPlanID == element.quoteRatingPlanID) {
          switch (Number(this.rareData['visionOutputTier'])) {
            case 1:
              if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = visPlan.rateInfo.single;
              }
              break;
              case 2:
                if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = visPlan.rateInfo.single;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = visPlan.rateInfo.family;
                }
                break;
              case 3:
                if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = visPlan.rateInfo.single;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.eeOne)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = visPlan.rateInfo.eeOne;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT3 = visPlan.rateInfo.family;
                }
                break;
              case 4:
                if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = visPlan.rateInfo.single;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.eeSpouse)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = visPlan.rateInfo.eeSpouse;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.eeChildren)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT3 = visPlan.rateInfo.eeChildren;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT4 = visPlan.rateInfo.family;
                }
                break;
              case 5:
                if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = visPlan.rateInfo.single;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.eeSpouse)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = visPlan.rateInfo.eeSpouse;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.eeChild)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT3 = visPlan.rateInfo.eeChild;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.eeChildren)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT4 = visPlan.rateInfo.eeChildren;
                } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                  this.visionPremiumComparison.planComparison[findIndex].quoteRates.ratesT5 = visPlan.rateInfo.family;
                }
                break;
              default: console.log('default')
          }
      }
      });
    } 
  }

  // Check if the uw entered valid number or not  
  isNumber(evt) {
    return VisionUtil.isNumber(evt);
  }
  
    overrideTierRate($event, visPlan, tierVal, ageBand?) {
      this.refreshVisPlanData(visPlan, ageBand);
      const stringValue = $event.target.value?.replace(/[^0-9.]/g, '');
      const value = Number(stringValue);
      // Format to 2 decimal places
      const formattedValue = Number(value.toFixed(2));
      
      if (ageBand) {
        visPlan.ageBandRateInfo[ageBand][tierVal] = formattedValue;
      } else {
        visPlan.rateInfo[tierVal] = formattedValue;
      }
      visPlan.wasProposedPlanRatesEdited = true;
      visPlan.isProposedPlanRatesEdited = CommonConstants.YES;
      this.updatePremiumComparison(formattedValue, visPlan, tierVal, ageBand);
      
      // Update the input field value to show formatted value
      $event.target.value = this.formatDisplayValue(formattedValue);
      if (!this.myArr.find(x => x === visPlan.planBenefits?.planName)) {
      this.myArr.push(visPlan.planBenefits?.planName);
    }
    this.constructAdjustedRates();
      
      // Trigger change detection to update the UI
      this.changeDet.detectChanges();
      let obj = {
      'visionPremiumComparison': this.visionPremiumComparison,
      'isChangedFlag': this.isChangedFlag,
      'myArr': this.myArr,
      'adjustedArr': this.adjustedArr
    }
    this.onFeaturedPlanRateChange.emit(obj);
    }

     private refreshVisPlanData(visPlan, ageBand) {
    const stringOutputTier = this.rareData['visionOutputTier'];
    const outputTier = Number(stringOutputTier);

    let planComparison: any
      = this.visionPremiumComparison?.planComparison.find(comparison => StringUtils.isEqualIgnoreCase(comparison.quoteRatingPlanID, visPlan.ratingPlanID));

      if(planComparison) {
      const planComparisonQuoteRates = planComparison.quoteRates;
      const visPlanRateInfo = visPlan.rateInfo;

      visPlanRateInfo.single = planComparisonQuoteRates.ratesT1;
      if (outputTier === 4 || outputTier === 5) {
        visPlanRateInfo.eeSpouse = planComparisonQuoteRates.ratesT2;
      }
      if (outputTier === 4) {
        visPlanRateInfo.eeChildren = planComparisonQuoteRates.ratesT3;
      }
      if (outputTier === 5) {
        visPlanRateInfo.eeChild = planComparisonQuoteRates.ratesT3;
        visPlanRateInfo.eeChildren = planComparisonQuoteRates.ratesT4;
      }
      this.setRateForFamilyFromComparisonRates(outputTier, visPlanRateInfo, planComparisonQuoteRates)
    }
    
  }

    updatePremiumComparison(value, visPlan, tierVal, ageBand) {
    const stringOutputTier = this.rareData['visionOutputTier'];
    const outputTier = Number(stringOutputTier);
    this.visionPremiumComparison?.planComparison.forEach((planComparison: any) => {
      if (StringUtils.isEqual(planComparison.quoteRatingPlanID, visPlan.ratingPlanID)) {
        planComparison.wasProposedPlanRatesEdited = true;
        planComparison.isProposedPlanRatesEdited = CommonConstants.YES;
        let planRates;
        if (ageBand) {
          planRates = planComparison.ageBandQuotedRates[ageBand];
        } else {
          planRates = planComparison.quoteRates;
        }
        switch (tierVal) {
          case CommonConstants.SINGLE:
            planRates.ratesT1 = value;
            break;
          case CommonConstants.EE_SPOUSE:
            if (outputTier === 4 || outputTier === 5) {
              planRates.ratesT2 = value;
            }
            break;
          case CommonConstants.EE_ONE:
            planRates.ratesT2 = value;
            break;
          case CommonConstants.EE_CHILD:
            planRates.ratesT3 = value;
            break;
          case CommonConstants.EE_CHILDREN:
            if (outputTier === 4) {
              planRates.ratesT3 = value;
            }
            if (outputTier === 5) {
              planRates.ratesT4 = value;
            }
            break;
          case CommonConstants.FAMILY:
            this.setRateForFamilyTier(outputTier, planRates, value);
            break;
        }
        this.recalculateYearlyTotals(planComparison);
      }
    })
  }

  recalculateYearlyTotals(planComparison) {
    const enrollments = planComparison.quoteEnrollments;
    const rates = planComparison.quoteRates;
    const ratesT1 = rates.ratesT1 || 0;
    const ratesT2 = rates.ratesT2 || 0;
    const ratesT3 = rates.ratesT3 || 0;
    const ratesT4 = rates.ratesT4 || 0;
    const ratesT5 = rates.ratesT5 || 0;

    const enrollT1 = enrollments.enrollT1 || 0;
    const enrollT2 = enrollments.enrollT2 || 0;
    const enrollT3 = enrollments.enrollT3 || 0;
    const enrollT4 = enrollments.enrollT4 || 0;
    const enrollT5 = enrollments.enrollT5 || 0;

    const monthlyTotal = (ratesT1 * enrollT1) +
      (ratesT2 * enrollT2) +
      (ratesT3 * enrollT3) +
      (ratesT4 * enrollT4) +
      (ratesT5 * enrollT5);

    planComparison.quoteRates.monthlyTotal = monthlyTotal;
    planComparison.quoteRates.yearlyTotal = monthlyTotal * 12;

    if (planComparison.currentRates &&
      planComparison.currentRates.yearlyTotal &&
      planComparison.currentRates.yearlyTotal > 0 &&
      planComparison.quoteRates.yearlyTotal !== null &&
      planComparison.quoteRates.yearlyTotal !== undefined) {

      const currentYearly = planComparison.currentRates.yearlyTotal;
      const quoteYearly = planComparison.quoteRates.yearlyTotal;

      planComparison.diffToCurrentRatePercentage = (quoteYearly - currentYearly) / currentYearly;
      planComparison.diffToCurrentMonthlyRate =
        planComparison.quoteRates.monthlyTotal - (planComparison.currentRates.monthlyTotal || 0);
      planComparison.diffToCurrentYearlyRate = quoteYearly - currentYearly;
    } else {
      planComparison.diffToCurrentRatePercentage = 0;
      planComparison.diffToCurrentMonthlyRate = 0;
      planComparison.diffToCurrentYearlyRate = 0;
    }
  }

   setRateForFamilyTier(outputTier, planRates, value) {
    switch (outputTier) {
      case 2:
        planRates.ratesT2 = value;
        break;
      case 3:
        planRates.ratesT3 = value;
        break;
      case 4:
        planRates.ratesT4 = value;
        break;
      case 5:
        planRates.ratesT5 = value;
        break;
    }
  }


   setRateForFamilyFromComparisonRates(outputTier, rates, planComparisonQuoteRates) {
    switch (outputTier) {
      case 2:
        rates.family = planComparisonQuoteRates.ratesT2;
        break;
      case 3:
        rates.family = planComparisonQuoteRates.ratesT3;
        break;
      case 4:
        rates.family = planComparisonQuoteRates.ratesT4;
        break;
      case 5:
        rates.family = planComparisonQuoteRates.ratesT5;
        break;
    }
  }

  // Updated the vision premium comparison after changing the tier rates
  updateVPC(visPlan, tierVal) {
    if (this.visionPremiumComparison !== undefined && this.visionPremiumComparison !== null) {
      this.visionPremiumComparison.planComparison.forEach(element => {
        if (element.quoteRatingPlanID == visPlan.ratingPlanID) {
          switch (Number(this.rareData['visionOutputTier'])) {
            case 1:
              if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                element.quoteRates.ratesT1 = this.getTierRates(visPlan, VisionConstants.single)
              }
              break;
            case 2:
              if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                element.quoteRates.ratesT1 = this.getTierRates(visPlan, VisionConstants.single)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                element.quoteRates.ratesT2 = this.getTierRates(visPlan, VisionConstants.family)
              }
              break;
            case 3:
              if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                element.quoteRates.ratesT1 = this.getTierRates(visPlan, VisionConstants.single)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.eeOne)) {
                element.quoteRates.ratesT2 = this.getTierRates(visPlan, VisionConstants.eeOne)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                element.quoteRates.ratesT3 = this.getTierRates(visPlan, VisionConstants.family)
              }
              break;
            case 4:
              if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                element.quoteRates.ratesT1 = this.getTierRates(visPlan, VisionConstants.single)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.eeSpouse)) {
                element.quoteRates.ratesT2 = this.getTierRates(visPlan, VisionConstants.eeSpouse)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.eeChildren)) {
                element.quoteRates.ratesT3 = this.getTierRates(visPlan, VisionConstants.eeChildren)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                element.quoteRates.ratesT4 = this.getTierRates(visPlan, VisionConstants.family)
              }
              break;
            case 5:
              if (StringUtils.isEqual(tierVal, VisionConstants.single)) {
                element.quoteRates.ratesT1 = this.getTierRates(visPlan, VisionConstants.single)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.eeSpouse)) {
                element.quoteRates.ratesT2 = this.getTierRates(visPlan, VisionConstants.eeSpouse)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.eeChild)) {
                element.quoteRates.ratesT3 = this.getTierRates(visPlan, VisionConstants.eeChild)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.eeChildren)) {
                element.quoteRates.ratesT4 = this.getTierRates(visPlan, VisionConstants.eeChildren)
              } else if (StringUtils.isEqual(tierVal, VisionConstants.family)) {
                element.quoteRates.ratesT5 = this.getTierRates(visPlan, VisionConstants.family)
              }
              break;
            default: console.log('default')
          }
        }
      });
    }
  }
  // Placin $ symbol before each rates
  changeRates(val, tierVal, visPlan) {
    visPlan.rateInfo[tierVal] = null;
    this.changeDet.detectChanges();
    var value = val;
    value = value.replace('$', '').replace(/,/g, '');
    visPlan.rateInfo['tierVal'] = (+value).toFixed(2); //change tier value
    visPlan.rateInfo['tierVal'] = Number(visPlan.rateInfo['tierVal']);
    return visPlan.rateInfo.tierVal;
  }

  getPlusBenefits(benefit) {
    if (StringUtils.isEmpty(benefit)) {
      return VisionConstants.NOT_APPLICABLE;
    }
    else {
      return benefit;
    }
  }
  getDateDiff() {
    const date = new Date('2025-01-01');
    const factorDate = new Date(this.factorEffectiveDate)
    return DateUtil.checkDateDifference(factorDate, date)
  }

    constructAdjustedRates() {
    this.adjustedArr = [];
    
    // Include ALL plans, not just edited ones
    for (let i = 0; i < this.featuredPlans.length; i++) {
      const planName = this.featuredPlans[i]['planBenefits']?.planName;
      const wasEdited = this.myArr.find(x => x === planName);
      
      // Get existing UW adjustment from adjustedPlans if available
      let uwAdjustment = 1; // Default
      if (this.adjustedPlans && this.adjustedPlans.length > 0) {
        const existingPlan = this.adjustedPlans.find(p => p.planName === planName);
        if (existingPlan && existingPlan.uwAdjustment !== undefined && existingPlan.uwAdjustment !== null) {
          uwAdjustment = existingPlan.uwAdjustment;
        }
      }
      
      // If plan was edited, recalculate UW adjustment
      if (wasEdited) {
        uwAdjustment = this.calculateUWAdjustmentFromDiff(this.featuredPlans[i]);
      }
      
      let adjustedObj = {
        "planName": planName,
        "ratingPlanID": this.featuredPlans[i]['ratingPlanID'],
        "single": this.featuredPlans[i]['rateInfo'].single,
        "eeSpouse": this.featuredPlans[i]['rateInfo'].eeSpouse,
        "eeChild": this.featuredPlans[i]['rateInfo'].eeChild,
        "eeChildren": this.featuredPlans[i]['rateInfo'].eeChildren,
        "eeOne": this.featuredPlans[i]['rateInfo'].eeOne,
        "family": this.featuredPlans[i]['rateInfo'].family,
        "uwAdjustment": uwAdjustment
      }
      this.adjustedArr.push(adjustedObj);
    }
    
    return this.adjustedArr;
  }
  
  calculateUWAdjustmentFromDiff(visPlan) {
    let calculatedUWAdjustment = 1;
    if (this.visionPremiumComparison && this.visionPremiumComparison.planComparison) {
      const planComparison = this.visionPremiumComparison.planComparison.find(
        plan => plan.quoteRatingPlanID === visPlan.ratingPlanID
      );
      if (planComparison) {
        if (planComparison.diffToCurrentRatePercentage !== undefined && planComparison.diffToCurrentRatePercentage !== null) {
          calculatedUWAdjustment = 1 + planComparison.diffToCurrentRatePercentage;
          calculatedUWAdjustment = Math.round(calculatedUWAdjustment * 1000) / 1000;
          visPlan.uwDiscret = calculatedUWAdjustment;
        }
      }
    }
    return calculatedUWAdjustment;
  }
}