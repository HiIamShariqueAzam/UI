import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from "@angular/core";
import { FormBuilder, FormGroup, FormGroupDirective } from "@angular/forms";
import { ActivatedRoute } from '@angular/router';
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { CommonService, ProcessQuoteDetailsService } from 'src/app/shared/services';
import { CommonUtil } from "src/app/shared/utils/common-util";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { VisionConstants } from "../vision.constants";
import { VisionUtil } from "../vision.util";


@Component({
  selector: "app-adjustments-vision",
  templateUrl: "./adjustments-vision.component.html",
  styleUrls: ["./adjustments-vision.component.css"],
  standalone: false
})
export class AdjustmentsVisionComponent implements OnChanges, OnInit {

  @Input() requestedTier;
  @Input() rareData;
  @Input() rareDataObj;
  @Input() isReadOnlyRole;
  @Input() status;
  @Input() disableAll;
  @Input() featuredPlans;
  @Input() uwLoaded;
  @Input() visionInputTier;
  @Input() showAdjustmentHistory;
  @Output() onFactorAdj = new EventEmitter<any>();
  @Input() declineResaonsFromUWAdjs: any;
  @Input() quoteDetailsObj: any;
  @Input() adjustedPlans;
  @Output() declineReaonsToBeChecked = new EventEmitter<any>();

  uwAdjustment = {};
  proposedPlans = [];
  isCollapsed: boolean = false ;
  form: FormGroup;
  activeTab: string = "Q";
  fundingType = 'FI';
  selectedTierRatioCalculationType: string;
  oppID:any;
  lob:any;
  transID:any;
  quoteHeaderID:any;
  quoteOrigin: string;
  actualDeclineReason: any;
  userTypedDeclineReasons: any;
  predefinedDeclineReasons: any[] = [];
  opportunityType: string;
  adjHistory = [];
  showCurrentRateRow: any = false;
  showStandardRateRow: any = false;
  isAdjError: boolean = false;
  errorMessage = VisionConstants.invalidValue;
  isRenewalQuote: any;
  isChangedFlag = false;
  myArr = [];
  adjustedArr = [];
  alternateQuote;
  private adjustmentHistoryLoaded = false;


  constructor(private fb: FormBuilder, private rootFormGroup: FormGroupDirective,
    private route:ActivatedRoute,private commonService:CommonService, private processQuoteService: ProcessQuoteDetailsService, private commonQuoteService: CommonQuoteService) {

  }
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.oppID = params[CommonConstants.OPPORTUNITY_ID];
      this.transID = params[CommonConstants.RATINGTRANS_ID];
      this.lob = params[CommonConstants.LOB];
      this.fundingType = params[CommonConstants.FUNDING_TYPE];
      this.quoteHeaderID = params[CommonConstants.QUOTEHEADER_ID];
      this.quoteOrigin = params[CommonConstants.QUOTE_ORIGIN];
    });
    console.log('adj', this.rareData);
    this.predefinedDeclineReasons = [];
    this.form = this.rootFormGroup.control;
    this.uwAdjustment = this.rareData;
    this.proposedPlans = this.rareData.vision.proposedPlans;
    this.opportunityType = this.rareData.opportunityType;
    this.alternateQuote = this.quoteDetailsObj.alternateQuote;
    if(this.predefinedDeclineReasons.length == 0){
      this.callDeclineOptionsBackend();
    }
    this.initializeAdjustmentForm();
    this.setFormValue();
    this.onFormValueChanges();
    this.showCurrentRateRowTable();
    let uWNotesSplit: any[] = [];
    if(typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
    this.rareData.uwAdjustment.uwNotesToSales.includes(";")){
      uWNotesSplit = this.rareData.uwAdjustment.uwNotesToSales.split(";")
    }else{
      if(typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null){
        uWNotesSplit.push(this.rareData.uwAdjustment.uwNotesToSales);
      }
    }
    if(uWNotesSplit != null && typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
    this.rareData.uwAdjustment.uwNotesToSales != ""){
      var declineChecboxes = this.predefinedDeclineReasons.filter(x=>{
        return uWNotesSplit.findIndex(t=> t === x) != -1
      });
      console.log("declineChecboxes: " + declineChecboxes);
      if(typeof(declineChecboxes) != 'undefined' && declineChecboxes != null){
        this.declineReaonsToBeChecked.emit(declineChecboxes);
      }
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.uwLoaded && !changes.uwLoaded.firstChange) {
      this.setFormValue();
    this.showCurrentRateRowTable();
    }
    if (changes.adjustedPlans && !changes.adjustedPlans.firstChange) {
      this.adjustedPlans = this.adjustedPlans;
    }
    if (changes.featuredPlans && !changes.featuredPlans.firstChange) {
      this.uwAdjustment = this.rareData;
    this.proposedPlans = this.rareData.vision.proposedPlans;
    this.initializeAdjustmentForm();
    this.setFormValue();
    this.showCurrentRateRowTable();
    }
    if (changes.rareData && !changes.rareData.firstChange) {
     this.rareData = this.rareData;
     this.initializeAdjustmentForm();
    this.setFormValue();
    this.showCurrentRateRowTable();
    }
    if(changes.declineResaonsFromUWAdjs){
      this.setDeclineReasonsToUWNotes(null, false);
    }
    if(typeof(this.processQuoteService.declineOptionsValues) != 'undefined' && this.processQuoteService.declineOptionsValues != null){
      this.processQuoteService.declineOptionsValues.subscribe(value => {
        if(value != null){
          this.processQuoteService.setDeclineOptionsChecked(value);
          this.setDeclineReasonsToUWNotes(value, true);
        }
      });
    }
    if(typeof(this.form) != 'undefined' && this.form != null){
      this.form.get(VisionConstants.uwNotesToSales).valueChanges.subscribe(val => {
       this.setNonAdjustmentFields('uwNotesToSales', val);
        this.processQuoteService.declineOptionsValues.subscribe(value => {
          if(value != null){
            this.setDeclineReasonsToUWNotes(value, true);
          }
        });
      });
    }
  }
  // setting non-adjustment fields
  setNonAdjustmentFields(key: string, val: any) {
    this.rareData.uwAdjustment[key] = val;
    this.userTypedDeclineReasons = val;
    this.processQuoteService.setUwNotesToSales(val);
  }
  // on changing the form values like uw notes to sales and uw comments
  onFormValueChanges() {
    this.form.get(VisionConstants.uwNotesToSales).valueChanges.subscribe(val => {
      this.setNonAdjustmentFields('uwNotesToSales', val);
      this.processQuoteService.declineOptionsValues.subscribe(value => {
        if(value != null){
          this.setDeclineReasonsToUWNotes(value, true);
        }
      });
    });
    this.form.get(VisionConstants.uwComments).valueChanges.subscribe(val => { this.setNonAdjustmentFields(VisionConstants.uwComments, val) });
  }

  // setting the active tab plan adjustment and quote adjustment
  setActiveTab(type: string) {
    this.activeTab = type;
  }
  calculatedFloatValue(factor: any): any {
    return VisionUtil.calculatedFloatValue(factor);
  }

  public resetAdjustmentHistoryFlag() {
    this.adjustmentHistoryLoaded = false;
  }

  // fetching the quote adjustment history
  adjustmentHistoryClicked() {
    if (this.adjustmentHistoryLoaded) {
      return;
    }
    this.adjustmentHistoryLoaded = true;
    this.commonQuoteService
    .getAdjustmentHistory(this.transID, this.oppID, this.quoteHeaderID, this.quoteOrigin, this.lob, this.fundingType)
    .subscribe(
      response => {
        if (response) {
          this.adjHistory = response.map((adjData, index) => {
            adjData['AdjNo'] = this.adjHistory.length - index;
            return adjData;
          });
        }
      }
    )
  }

  // Getting the tier factor value, standard tier rates and current tier rates
  getTierFactorValue(type: string, factor: string): number | string {
    let floatValue = 0;
    let currentRateTierFactor = this.featuredPlans[0]['factors'].currentRateTierFactor;
    let standardRateTierFactor= this.featuredPlans[0]['factors'].standardRateTierFactor;
    let standardTierRatio = this.featuredPlans[0]['factors'].tierRatioStandardPlanId;
    let currentTierRatio = this.featuredPlans[0]['factors'].tierRatioCurrentPlanId ? this.featuredPlans[0]['factors'].tierRatioCurrentPlanId : '';
    switch (type) {
      case "standard":
          floatValue = this.calculatedFloatValue(standardRateTierFactor[standardTierRatio][factor]);
        break;
      case "current":
          floatValue = this.calculatedFloatValue(currentRateTierFactor[currentTierRatio][factor]);
        break;
    }
    return floatValue ? floatValue.toFixed(3) : "";
  }
  initializeAdjustmentForm() {
    // this.adjustment_form = this.fb.group({
    //   uwNotesToSales: [""],
    //   uwComments: [""],
    //   salesNotetoUW: [""]
    // })
  }
  setFormValue() {
    if (this.featuredPlans) {
      let declineReasons;
      let statusReasons;
      if(typeof(this.rareData) != 'undefined' && this.rareData != null &&
      typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
      typeof(this.rareData.uwAdjustment.statusReasons) != 'undefined' && this.rareData.uwAdjustment.statusReasons != null
       && this.rareData.uwAdjustment.statusReasons.length > 0){
      declineReasons = this.rareData.uwAdjustment.statusReasons;
      this.rareData.uwAdjustment.statusReasons.forEach(element => {
        if(statusReasons == null){
          statusReasons = element;
        }else{
          if(!statusReasons.includes(element)){
            statusReasons = statusReasons != "" && !element.includes(statusReasons) ? statusReasons +  ';' + element : element;
          }
        }
      });
      localStorage.setItem("statusReasons"+"_"+this.quoteHeaderID+"_"+"Vision"+"_"+this.fundingType, statusReasons);
    }
      this.setDeclineReasonsToUWNotes(declineReasons, false);
      if(this.processQuoteService.uwNotesToSales != "" && typeof(this.actualDeclineReason) != 'undefined'
      && this.actualDeclineReason != null && this.rareData != null && typeof(this.rareData) != 'undefined' &&
      typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
      typeof(this.rareData.uwAdjustment.uwNotesToSales) != 'undefined' && this.rareData.uwAdjustment.uwNotesToSales != null){
        this.rareData.uwAdjustment.uwNotesToSales = this.processQuoteService.uwNotesToSales;
      }
      if(this.rareData != null && typeof(this.rareData) != 'undefined' &&
      typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
      typeof(this.rareData.uwAdjustment.uwNotesToSales) != 'undefined' && this.rareData.uwAdjustment.uwNotesToSales != null
      && this.rareData.uwAdjustment.uwNotesToSales != ""){
        this.form.get(VisionConstants.uwNotesToSales).setValue(this.rareData.uwAdjustment.uwNotesToSales || "", { emitEvent: false });
        this.userTypedDeclineReasons = this.rareData.uwAdjustment.uwNotesToSales;
        this.processQuoteService.setUwNotesToSales(this.rareData.uwAdjustment.uwNotesToSales);
        this.emitDeclineCheckboxOptions();
      }
      if(this.rareData != null && typeof(this.rareData) != 'undefined' &&
      typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
      typeof(this.rareData.uwAdjustment.uwComments) != 'undefined' && this.rareData.uwAdjustment.uwComments != null
      && this.rareData.uwAdjustment.uwComments != ""){
        this.form.get(VisionConstants.uwComments).setValue(this.rareData[VisionConstants.uwAdjustment][VisionConstants.uwComments] || "", { emitEvent: false });
      }
    this.form.get(VisionConstants.salesNotetoUW).setValue(this.rareData['vision'][VisionConstants.salesNotetoUW] || "", { emitEvent: false });
    this.form.get(VisionConstants.salesNotetoUW)?.disable();
    this.selectedTierRatioCalculationType = (this.featuredPlans[0].factors.tierRatioCalculationType) ||
        "Standard";
      }
  }

  // Getting the quote decline options
  callDeclineOptionsBackend(){
    let isVisionAca = this.commonService.isVisionAca(this.quoteDetailsObj);
    if (!isVisionAca) {
      this.commonQuoteService.getDeclineOptions(this.quoteDetailsObj,this.transID).subscribe(response => {
        if(typeof(response) != 'undefined' && response != null
        && typeof(response.data) != 'undefined' && response.data != null){
          response.data.forEach(element => {
            this.predefinedDeclineReasons.push(element);
          });
          this.setFormValue();
          this.emitDeclineCheckboxOptions();
        }
      });
    }
  }

  // Setting the quote decline reasons to UW notes
  setDeclineReasonsToUWNotes(reasons, formChanges){
    let userTypedDeclineReasonsSplit: any[] = [];
    let userSelectedDeclineReasons: any[] = [];

    if(this.rareData != null && typeof(this.rareData) != 'undefined' &&
    typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
    typeof(this.rareData.uwAdjustment.uwNotesToSales) != 'undefined' && this.rareData.uwAdjustment.uwNotesToSales != null
    && this.rareData.uwAdjustment.uwNotesToSales != ""){
      this.form.get(VisionConstants.uwNotesToSales).setValue(this.rareData.uwAdjustment.uwNotesToSales || "", { emitEvent: false });
      this.userTypedDeclineReasons = this.rareData.uwAdjustment.uwNotesToSales;
    }else if(typeof(this.form) != 'undefined'){
      this.userTypedDeclineReasons = this.form.get(VisionConstants.uwNotesToSales).value;
    }

      if(reasons != null && this.declineResaonsFromUWAdjs != null
        && reasons.length === this.declineResaonsFromUWAdjs.length){
        userSelectedDeclineReasons = this.declineResaonsFromUWAdjs;
      }else if(this.rareData != null && typeof(this.rareData) != 'undefined' &&
      typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
      this.rareData.uwAdjustment.uwNotesToSales != null && this.rareData.uwAdjustment.uwNotesToSales != "" && formChanges){
        userSelectedDeclineReasons = this.rareData.uwAdjustment.uwNotesToSales;
      }else{
        if(reasons == null || reasons.length == 0){
          if(typeof(localStorage.getItem("statusReasons"+"_"+this.quoteHeaderID+"_"+"Vision"+"_"+this.fundingType)) != 'undefined' && localStorage.getItem("statusReasons"+"_"+this.quoteHeaderID+"_"+"Vision"+"_"+this.fundingType) != null){
            let declineOptionArray = localStorage.getItem("statusReasons"+"_"+this.quoteHeaderID+"_"+"Vision"+"_"+this.fundingType).split(";");
            reasons = declineOptionArray;
          }
        }
        userSelectedDeclineReasons = reasons;
      }
          if(this.actualDeclineReason == 'undefined' || this.actualDeclineReason == null){
            if(this.userTypedDeclineReasons != null && userSelectedDeclineReasons != null &&
              this.userTypedDeclineReasons.includes(";")){
                let uWNotesSplitTrim: any[] = [];
              userTypedDeclineReasonsSplit  = this.userTypedDeclineReasons.split(";");
              if(userTypedDeclineReasonsSplit.length > 0){
                userTypedDeclineReasonsSplit.forEach(element => {
                  let newElement = element.trim();
                  uWNotesSplitTrim.push(newElement);
                });
              }
              if(this.predefinedDeclineReasons.length === 0){
                this.predefinedDeclineReasons = this.processQuoteService.declineOptionsFromBackend;
              }
              if(uWNotesSplitTrim && typeof(this.predefinedDeclineReasons) != 'undefined' && this.predefinedDeclineReasons != null
                && this.predefinedDeclineReasons.length){
                  this.actualDeclineReason = uWNotesSplitTrim.filter(x => {
                    return this.predefinedDeclineReasons.indexOf(x) == -1;
                  });
              }
            }else{
              this.actualDeclineReason = this.userTypedDeclineReasons;
            }
          }else{
            this.actualDeclineReason = "";
            let uWNotesSplitTrim: any[] = [];
            if(this.userTypedDeclineReasons != null){
              if(this.userTypedDeclineReasons.includes(";")){
                userTypedDeclineReasonsSplit  = this.userTypedDeclineReasons.split(";");
              }else{
                userTypedDeclineReasonsSplit.push(this.userTypedDeclineReasons);
              }
              if(userTypedDeclineReasonsSplit.length > 0){
                userTypedDeclineReasonsSplit.forEach(element => {
                  let newElement = element.trim();
                  uWNotesSplitTrim.push(newElement);
                });
              }
              var finalArray = uWNotesSplitTrim.filter(x=>{
                return this.predefinedDeclineReasons.findIndex(t=> t === x) === -1
              })
              if(finalArray.length > 0){
                finalArray.forEach(elementsArr => {
                  if(elementsArr === 'undefined'){
                    return;
                  }
                  if(this.actualDeclineReason == ""){
                    this.actualDeclineReason = elementsArr;
                  }else{
                    this.actualDeclineReason = this.actualDeclineReason + ';' + elementsArr;
                  }

                })
              }
            }else{
              this.actualDeclineReason = this.userTypedDeclineReasons;
            }
          }

          let finalUWNote;
          if(this.actualDeclineReason != null && this.actualDeclineReason.length > 0 &&
            this.actualDeclineReason.constructor === Array){
            let actualDeclineReason;
            this.actualDeclineReason.forEach(element=> {
              if(actualDeclineReason == null){
                actualDeclineReason = element;
             }else if(!actualDeclineReason.includes(element)){
                actualDeclineReason = actualDeclineReason + ';' + element;
             }
            });
            this.actualDeclineReason = actualDeclineReason;
          }
          if(userSelectedDeclineReasons != null && userSelectedDeclineReasons.length > 0){
            if(userSelectedDeclineReasons.constructor === Array){
              userSelectedDeclineReasons.forEach(element=> {
                if(element === 'undefined'){
                  return;
                }
                if(finalUWNote == null){
                  if(this.actualDeclineReason && this.actualDeclineReason.includes(element)){
                    finalUWNote = this.actualDeclineReason;
                  }else{
                   finalUWNote = typeof(this.actualDeclineReason) != 'undefined' && this.actualDeclineReason != null && this.actualDeclineReason != "" && !element.includes(this.actualDeclineReason) ? this.actualDeclineReason +  ';' +  element : element;
                  }
                   this.processQuoteService.setUwNotesToSales(finalUWNote);
                   this.processQuoteService.setUserTypedDeclineReasons(this.userTypedDeclineReasons);
                }else if(!finalUWNote.includes(element)){
                  finalUWNote = finalUWNote + ';' + element;
                  this.processQuoteService.setUwNotesToSales(finalUWNote);
                  this.processQuoteService.setUserTypedDeclineReasons(this.userTypedDeclineReasons);
                }
              });
              if(finalUWNote != null && finalUWNote.includes(";")){
                finalUWNote = CommonUtil.htmlEntitiesToString(finalUWNote);
                if(finalUWNote.includes("; ")){
                  finalUWNote = finalUWNote.split("; ").join(";");
                }
                finalUWNote = finalUWNote.split(";").join("; ");
                finalUWNote = CommonUtil.convertSpecialCharToASCII(finalUWNote);
              }
              this.processQuoteService.setUwNotesToSales(finalUWNote);
            }
          }else{
            finalUWNote = this.actualDeclineReason;
            if(finalUWNote != null && finalUWNote.includes(";")){
              finalUWNote = CommonUtil.htmlEntitiesToString(finalUWNote);
              if(finalUWNote.includes("; ")){
                finalUWNote = finalUWNote.split("; ").join(";");
              }
              finalUWNote = finalUWNote.split(";").join("; ");
              finalUWNote = CommonUtil.convertSpecialCharToASCII(finalUWNote);
            }
            this.processQuoteService.setUwNotesToSales(finalUWNote);
            this.processQuoteService.setUserTypedDeclineReasons(this.userTypedDeclineReasons);
          }
  }

  // Emitting the decline selected checkboxes to parent component
  emitDeclineCheckboxOptions(){
    let uWNotesSplit: any[] = [];
    let uWNotesSplitTrim: any[] = [];

    if(typeof(this.rareData) != 'undefined' && this.rareData != null &&
    typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
    typeof(this.rareData.uwAdjustment.uwNotesToSales) != 'undefined' && this.rareData.uwAdjustment.uwNotesToSales != null &&
    this.rareData.uwAdjustment.uwNotesToSales.includes(";")){
      uWNotesSplit = this.rareData.uwAdjustment.uwNotesToSales.split(";");
    }else if(typeof(this.rareData) != 'undefined' && this.rareData != null &&
    typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
    typeof(this.rareData.uwAdjustment.uwNotesToSales) != 'undefined' && this.rareData.uwAdjustment.uwNotesToSales != null){
      uWNotesSplit.push(this.rareData.uwAdjustment.uwNotesToSales);
    }
    if(uWNotesSplit.length > 0){
      uWNotesSplit.forEach(element => {
        let newElement = element.trim();
        uWNotesSplitTrim.push(newElement);
      });
    }
    if(this.predefinedDeclineReasons.length == 0){
      this.predefinedDeclineReasons = this.processQuoteService.declineOptionsFromBackend;
    }
    if(uWNotesSplit != null && typeof(this.rareData) != 'undefined' && this.rareData != null &&
    typeof(this.rareData.uwAdjustment) != 'undefined' && this.rareData.uwAdjustment != null &&
    typeof(this.rareData.uwAdjustment.uwNotesToSales) != 'undefined' && this.rareData.uwAdjustment.uwNotesToSales != null &&
    this.rareData.uwAdjustment.uwNotesToSales != ""){
      var declineChecboxes = this.predefinedDeclineReasons.filter(x=>{
        return uWNotesSplitTrim.findIndex(t=> t === x) != -1
      });
      if(typeof(declineChecboxes) != 'undefined' && declineChecboxes != null){
        const uniqueDeclineChecboxes = [...new Set(declineChecboxes)];
        this.declineReaonsToBeChecked.emit(uniqueDeclineChecboxes);
      }
    }else{
      this.declineReaonsToBeChecked.emit([]);
    }
  }

  // Getting the current rates ratios and standard rates ratios
  showCurrentRateRowTable() {
    this.adjustmentHistoryClicked();
    if (this.featuredPlans) {
      let currentTierRatio = this.featuredPlans[0]['factors'].tierRatioCurrentPlanId;
      if (currentTierRatio !== undefined && this.featuredPlans[0]['factors'].currentRateTierFactor[currentTierRatio].eeFactor && this.visionInputTier == this.requestedTier) {
        this.showCurrentRateRow = true;
      } else {
        this.showCurrentRateRow = false;
      }
      let standardTierRatio = this.featuredPlans[0]['factors'].tierRatioStandardPlanId;
      if (standardTierRatio !== undefined && this.featuredPlans[0]['factors'].standardRateTierFactor[standardTierRatio].eeFactor) {
        this.showStandardRateRow = true;
      } else {
        this.showStandardRateRow = false;
      }
    }

  }

  // On tier rates selection standard and current rate ratios
  onTierSelect(type: string) {
    this.selectedTierRatioCalculationType = type;
  }

  // Check if the uw entered valid number or not
  isNumber(evt) {
    return VisionUtil.isNumber(evt);
  }

  // Check if uw entered a valid number (factor)
  checkIfNull(plan){
    return VisionUtil.checkIfNull(plan)
  }

  isRenewalQuoteDisabled() {
    this.isRenewalQuote = this.rareData.opportunityType;

    if (StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
      this.activeTab = 'P';
      return true;
    } else {
      return false;
    }
  }

  // Fetch the plan adjustment factor for each plans. Assign 1 if the plan is new (not adjusted before)
  getUWAdjustment(plan) {
    if (this.isRenewalQuoteDisabled()) {
      if (this.rareData.uwAdjustment && this.rareData.uwAdjustment.adjustedRates?.length) {
        this.rareData.uwAdjustment.adjustedRates.forEach(item => {
          if (item.ratingPlanID == plan.ratingPlanID) {
            plan['uwAdjustment'] = item.uwAdjustment ? item.uwAdjustment : 1;
          }
        });
        return plan['uwAdjustment'];
      } else {
        return (plan.uwDiscret);
      }
    }
  }

  // Construct adjusted plans array on factor change
  onAdjChange(value, plan) {
    if (value == '' || value == undefined) {
      this.rareDataObj.vision.proposedPlans.forEach(element => {
        if (element.ratingPlanID == plan.ratingPlanID && element.planBenefits?.planName === plan.planBenefits?.planName) {
          element.factors['uwAdjustment'] = null;
          element.uwDiscret = null;
          if (this.adjustedPlans.length) {
            const findIndex = this.adjustedPlans.findIndex(planObj => planObj.ratingPlanID === plan['ratingPlanID'] && planObj.planName === plan.planBenefits?.planName);
            if (findIndex !== -1) {
              this.adjustedPlans[findIndex].uwAdjustment = null;
            }
          }
        }
      });
    } else {
      this.rareDataObj.vision.proposedPlans.forEach(element => {
        if (element.ratingPlanID == plan.ratingPlanID && element.planBenefits?.planName === plan.planBenefits?.planName) {
          element.factors['uwAdjustment'] = value;
          element.uwDiscret = value;
          const findIndex = this.adjustedPlans.findIndex(planObj => planObj.ratingPlanID === plan['ratingPlanID'] && planObj.planName === plan.planBenefits?.planName);
          if (findIndex !== -1) {
            this.adjustedPlans[findIndex].uwAdjustment = value;
            this.adjustedPlans[findIndex].rateInfo = element.rateInfo;
            this.adjustedPlans[findIndex].ageBandRateInfo = element.ageBandRateInfo;
          } else {
            // Plan not found, add it to adjustedPlans
            this.adjustedPlans.push({
              planName: element.planBenefits?.planName || plan.planName,
              ratingPlanID: element.ratingPlanID,
              uwAdjustment: value,
              single: element.rateInfo?.single,
              eeSpouse: element.rateInfo?.eeSpouse,
              eeChild: element.rateInfo?.eeChild,
              eeChildren: element.rateInfo?.eeChildren,
              eeOne: element.rateInfo?.eeOne,
              family: element.rateInfo?.family,
              rateInfo: element.rateInfo,
              ageBandRateInfo: element.ageBandRateInfo
            });
          }
          this.updatePremiumComparison(plan, value, false);
        }
      });
    }
    this.isChangedFlag = true;
    if (!this.myArr.find(x => x === plan.ratingPlanID)) {
      this.myArr.push(plan.ratingPlanID);
    }
    // Ensure all plans with UW adjustments are included, not just the edited one
    this.featuredPlans.forEach(featuredPlan => {
      const alreadyInAdjusted = this.adjustedPlans.find(p => p.planName === featuredPlan.planBenefits?.planName);
      if (!alreadyInAdjusted && (featuredPlan.uwDiscret || featuredPlan.factors?.uwAdjustment)) {
        // Plan has UW adjustment but not in adjustedPlans, add it
        this.adjustedPlans.push({
          planName: featuredPlan.planBenefits?.planName,
          ratingPlanID: featuredPlan.ratingPlanID,
          uwAdjustment: featuredPlan.uwDiscret || featuredPlan.factors?.uwAdjustment,
          single: featuredPlan.rateInfo?.single,
          eeSpouse: featuredPlan.rateInfo?.eeSpouse,
          eeChild: featuredPlan.rateInfo?.eeChild,
          eeChildren: featuredPlan.rateInfo?.eeChildren,
          eeOne: featuredPlan.rateInfo?.eeOne,
          family: featuredPlan.rateInfo?.family,
          rateInfo: featuredPlan.rateInfo,
          ageBandRateInfo: featuredPlan.ageBandRateInfo
        });
      }
    });
    this.constructRequest();
    let obj = {
      'isChangedFlagFactor': this.isChangedFlag,
      'myArrFactor': this.myArr,
      'adjustedPlans': this.adjustedPlans,
      'visionPremiumComparison': this.rareData.visionPremiumComparison,
    }
    this.onFactorAdj.emit(obj)
  }

   updatePremiumComparison(plan, adjustmentFactor, isCurrentRateEdit = false) {

    this.rareData.visionPremiumComparison.planComparison.forEach(planComp => {
      if (adjustmentFactor && planComp.quoteRatingPlanID === plan.ratingPlanID && planComp.quotePlanName === plan.planBenefits?.planName) {
        planComp.isProposedPlanRatesEdited = CommonConstants.NO_CHAR;
          plan = this.recalculateQuotedRates(planComp, adjustmentFactor);
      }
    })
  }


   recalculateQuotedRates(planComparison, adjustmentFactor) {
    this.calculateQuotedTierRates(planComparison.currentRates, planComparison.quoteRates, planComparison.quoteEnrollments, planComparison.quoteTier, adjustmentFactor)
    let enr = planComparison.quoteEnrollments['enrollT1'] ? planComparison.quoteEnrollments['enrollT1'] : 0;
    planComparison.quoteRates['monthlyTotal'] = (Math.round((planComparison.quoteRates['ratesT1'] + Number.EPSILON) * 100) / 100 * enr);
    return planComparison;
  }

  calculateQuotedTierRates(currentRates, quotedRates, enrollments, quoteTier, adjustmentFactor) {
    let monthlyRate = 0;
    for (let i = 1; i <= quoteTier; i++) {
      quotedRates['ratesT' + i] = this.roundedValue(currentRates['ratesT' + i] * (adjustmentFactor || 0));
    }
  }

  roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }

  // Constructing the requested object on click of save/release
  constructRequest() {
    this.adjustedArr = [];
    for (let i = 0; i < this.featuredPlans.length; i++) {
      if (this.myArr.find(x => x === this.rareDataObj.vision.proposedPlans[i]['ratingPlanID'])) {
        let adjustedObj = {
          "planName": this.rareDataObj.vision.proposedPlans[i]['planBenefits'].planName,
          "ratingPlanID": this.rareDataObj.vision.proposedPlans[i]['ratingPlanID'],
          "single": this.rareDataObj.vision.proposedPlans[i]['rateInfo'].single,
          "eeSpouse": this.rareDataObj.vision.proposedPlans[i]['rateInfo'].eeSpouse,
          "eeChild": this.rareDataObj.vision.proposedPlans[i]['rateInfo'].eeChild,
          "eeChildren": this.rareDataObj.vision.proposedPlans[i]['rateInfo'].eeChildren,
          "eeOne": this.rareDataObj.vision.proposedPlans[i]['rateInfo'].eeOne,
          "family": this.rareDataObj.vision.proposedPlans[i]['rateInfo'].family,
          "uwAdjustment": this.rareDataObj.vision.proposedPlans[i].factors.uwAdjustment
        }
       this.adjustedArr.push(adjustedObj);
      }
    }
    return this.adjustedArr;
  }

  onUwNoteToSalesEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.form.get(VisionConstants.uwNotesToSales).setValue(ASCII || "", { emitEvent: false });
    }
    else{
      this.form.get(VisionConstants.uwNotesToSales).setValue("", { emitEvent: false });
    }
  }

  onUwNoteToSelfEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.form.get(VisionConstants.uwComments).setValue(ASCII || "", { emitEvent: false });
    }
    else{
      this.form.get(VisionConstants.uwComments).setValue("", { emitEvent: false });
    }
  }
}
