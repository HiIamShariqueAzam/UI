import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { AdjustmentHistoryComponent } from './adjustment-history.component';

describe('AdjustmentHistoryComponent', () => {
  let component: AdjustmentHistoryComponent;
  let fixture: ComponentFixture<AdjustmentHistoryComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AdjustmentHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdjustmentHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
