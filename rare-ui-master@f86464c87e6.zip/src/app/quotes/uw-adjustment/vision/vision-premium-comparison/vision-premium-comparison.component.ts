import { Component, OnInit, Input, Output, EventEmitter, Inject, LOCALE_ID, SimpleChanges } from '@angular/core';
import { CommonService } from 'src/app/shared/services';
import { formatCurrency,getCurrencySymbol, formatPercent } from '@angular/common';
import { VisionUtil } from '../vision.util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { VisionConstants } from '../vision.constants';
import { VisionPremiumComparison } from 'src/app/shared/models/visionComparison';
import { PlanComparison, PlanRates, Enrollments } from "src/app/shared/models";

@Component({
  selector: 'app-vision-premium-comparison',
  templateUrl: './vision-premium-comparison.component.html',
  styleUrls: ['./vision-premium-comparison.component.css'],
  standalone: false
})
export class VisionPremiumComparisonComponent implements OnInit {

  @Input() vpc1: VisionPremiumComparison;
  @Input() featuredPlans;
  @Input() boundariesObjName;
  @Input() isChangedFlag;
  @Input() vpcLoaded;
  @Input() rareData;
  @Input() isReadOnlyRole;
  @Input() status;
  @Input() adjustedPlans;

  @Output()
  onVPCChange = new EventEmitter<any>();

  hideCurrentTier: boolean;
  hideRenewalTier: boolean;
  planCount = 0;
  opportunityType:any;
  marketSegment:any;
  isLGVisionQuote: boolean = false;

  constructor(private commonService: CommonService, @Inject(LOCALE_ID) private locale: string) {

  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.vpc1 && !changes.vpc1.firstChange) {
      this.vpc1 = this.vpc1;
      this.updateQuoteRatesFromAdjustments();
    }
    if (changes.featuredPlans && !changes.featuredPlans.firstChange) {
      this.featuredPlans = this.featuredPlans;
    }
    if (changes.adjustedPlans && !changes.adjustedPlans.firstChange) {
      this.updateQuoteRatesFromAdjustments();
    }
  }
  isRenewal: boolean = false;
  ngOnInit() {
    this.opportunityType = this.rareData['opportunityType'];
    this.marketSegment = this.rareData["marketSegment"];
    console.log(this.rareData)
    this.isRenewal = (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) );
    this.isLGVisionQuote = StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup);
  }
  isNumber(evt) {
    return VisionUtil.isNumber(evt);
  }

  isEnr(event) {
    return VisionUtil.isEnr(event);
  }
  isCurency(evt) {
    return VisionUtil.isCurency(evt);
  }

  updateVPC(val, tierNumber: number, plan: any, forType: string) {
    let vpcPlan = this.getVPCplan(plan.quoteRatingPlanID);
    if (StringUtils.isEqual(forType, 'C')) {
      plan.currentEnrollments['enrollT' + tierNumber] = Number(val);
      vpcPlan.currentEnrollments.totalEnroll = this.getTotalEnrollment(vpcPlan, "C");
      vpcPlan.currentRates.monthlyTotal = this.getMonthlyTotal(vpcPlan, "C");
      vpcPlan.currentRates.yearlyTotal = this.getAnnualTotal(vpcPlan, "C");
      vpcPlan.renewalRates.monthlyTotal = this.getMonthlyTotal(vpcPlan, "R");
      vpcPlan.renewalRates.yearlyTotal = this.getAnnualTotal(vpcPlan, "R");
    } else if (StringUtils.isEqual(forType, 'CR')) {
      var value = val;
      value = value.replace("$", "").replace(/,/g, "");
      if (isNaN(value)) {
        vpcPlan.currentRates["ratesT" + tierNumber] = Number(val);
      } else {
        vpcPlan.currentRates["ratesT" + tierNumber] = (+value).toFixed(2);
      }
      if (value == '') {
        vpcPlan.currentRates["ratesT" + tierNumber] = '';
      }
      vpcPlan.currentRates.monthlyTotal = this.getMonthlyTotal(vpcPlan, "C");
      vpcPlan.currentRates.yearlyTotal = this.getAnnualTotal(vpcPlan, "C");
    } else if (StringUtils.isEqual(forType, 'RR')) {
      var value = val;
      value = value.replace("$", "").replace(/,/g, "");
      if (isNaN(value)) {
        vpcPlan.renewalRates["ratesT" + tierNumber] = Number(val);
      } else {
        vpcPlan.renewalRates["ratesT" + tierNumber] = (+value).toFixed(2);
      }
      if (value == '') {
        vpcPlan.renewalRates["ratesT" + tierNumber] = '';
      }
      vpcPlan.renewalRates.monthlyTotal = this.getMonthlyTotal(vpcPlan, "R");
      vpcPlan.renewalRates.yearlyTotal = this.getAnnualTotal(vpcPlan, "R");
    }
    this.onVPCChange.emit(this.vpc1)
  }
  getMonthlyTotal(plan, forType: string) {
    let monthTotal = 0;
    if (StringUtils.isEqual(forType, 'C')) {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.currentEnrollments, plan.currentRates, i);
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.currentEnrollments, plan.renewalRates, i);
      }
    } else if (StringUtils.isEqual(forType, 'Q')) {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.quoteEnrollments, plan.quoteRates, i);
      }
    }
    return monthTotal;
  }
  getCalculatedRates(enrollment: Enrollments, rate: PlanRates, index: number): number {
    let tierRate: string = '' + rate["ratesT" + index];
    if (tierRate) {
      tierRate = tierRate.replace("$", "").replace(/,/g, "");
    }
    return tierRate && !isNaN(parseFloat(tierRate)) ? parseFloat(tierRate) * this.getCalculatedEnrollments(enrollment, index) * 1 : 0;
  }
  getAnnualTotal(plan, forType: string) {
    let yearTotal = 0;
    if (StringUtils.isEqual(forType, 'C')) {
      yearTotal = this.getMonthlyTotal(plan, forType) * 12;
    } else if (StringUtils.isEqual(forType, 'R')) {
      yearTotal = this.getMonthlyTotal(plan, forType) * 12;
    } else if (StringUtils.isEqual(forType, 'Q')) {
      yearTotal = this.getMonthlyTotal(plan, forType) * 12;
    }
    return VisionUtil.roundedValue(yearTotal);
  }
  displayPremiumComparison(plan) {
    if (plan.hasQuotedRates && (plan.currentTier == plan.quoteTier || plan.renewalTier == plan.quoteTier)) {
      return true;
    }
    if (plan.currenTier !== plan.quoteTier && plan.renewalTier !== plan.quoteTier) {
      return false;
    }
  }
  getMaxTier(plan): number {
    if(plan.quoteTier && plan.currentTier) {
      return (plan.currentTier > plan.quoteTier) ? plan.currentTier : plan.quoteTier;
    }
    return plan.currentTier || plan.quoteTier;
  }

  getColSpan(type: string, plan): number {
    if (this.isRenewalQuoteDisabled()) {
      if (StringUtils.isEqual(type, 'H')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      } else if (StringUtils.isEqual(type, 'GHC')) {
        return this.hasRenewalRates(plan) ? 3 : 3;
      } else if (StringUtils.isEqual(type, 'GHQ')) {
        return 3;
      } else if (StringUtils.isEqual(type, 'GHD')) {
        return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "R") && this.hasMonthlyTotal(plan, "C") ? 2 : 1;
      } else {
        if (this.hasRenewalRates(plan)) {
          if (!this.hasMonthlyTotal(plan, "C")) {
            return 7;
          } else {
            return this.getAbsoluteValue(this.getDifferencePecentage(plan, "C")) ? 7 : 8;
          }
        } else {
          return 6;
        }
      }
    }
    else  if (this.isSGRenewalQuoteDisabled()) {
      if (StringUtils.isEqual(type, 'H')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      } else if (StringUtils.isEqual(type, 'GHC')) {
        return this.hasRenewalRates(plan) ? 3 : 3;
      } else if (StringUtils.isEqual(type, 'GHQ')) {
        return 3;
      } else if (StringUtils.isEqual(type, 'GHD')) {
        return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "R") && this.hasMonthlyTotal(plan, "C") ? 2 : 1;
      } else {
        if (this.hasRenewalRates(plan)) {
          if (!this.hasMonthlyTotal(plan, "C")) {
            return 7;
          } else {
            return this.getAbsoluteValue(this.getDifferencePecentage(plan, "C")) ? 7 : 8;
          }
        } else {
          return 6;
        }
      }
    }
    else {
      if (StringUtils.isEqual(type, 'H')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      } else if (StringUtils.isEqual(type, 'GHC')) {
        return this.hasRenewalRates(plan) ? 4 : 3;
      } else if (StringUtils.isEqual(type, 'GHQ')) {
        return 3;
      } else if (StringUtils.isEqual(type, 'GHD')) {
        return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "R") && this.hasMonthlyTotal(plan, "C") ? 2 : 1;
      } else {
        if (this.hasRenewalRates(plan)) {
          if (!this.hasMonthlyTotal(plan, "C")) {
            return 7;
          } else {
            return this.getAbsoluteValue(this.getDifferencePecentage(plan, "C")) ? 7 : 8;
          }
        } else {
          return 6;
        }
      }
    }

  }
  getPlanRate(plan, tierValue: number, forType: string, index): string {
    let retValue;
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentRates && plan.currentRates["ratesT" + tierValue]) {
        retValue = plan.currentRates["ratesT" + tierValue];
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (plan.renewalRates && plan.renewalRates["ratesT" + tierValue]) {
        retValue = plan.renewalRates["ratesT" + tierValue];
      }
    } else {
      if (plan.quoteRates && plan.quoteRates["ratesT" + tierValue]) {
        retValue = plan.quoteRates["ratesT" + tierValue];
      }
    }
    if (isNaN(retValue)) {
      return retValue;
    }
    return formatCurrency(retValue, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
  }
  calculateRates(plan, tierValue, index) {
    return '' + plan.quoteRates['ratesT' + tierValue];
  }
  hasRenewalRates(plan): boolean {
    if (plan && plan.hasRenewalRates) {
      return true;
    }
    else
      return false;
  }
  hasMonthlyTotal(plan, forType: string): boolean {
    let total = this.getMonthlyRate(plan, forType);
    return total && total !== 0;
  }

  getTierName(plan, tierValue: number, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      if (tierValue <= plan.currentTier) {
        return this.getTierEmpDesc(tierValue, plan.currentTier);
      }
    } else {
      if (tierValue <= plan.quoteTier) {
        return this.getTierEmpDesc(tierValue, plan.quoteTier);
      }
    }
    return "";
  }
  getTierEmpDesc(tierNumber: number, availableTiers: number): string {
    return VisionUtil.getTierEmpDesc(tierNumber, availableTiers);
  }
  isTierApplicable(plan, tier: number, type: string): boolean {
    return type === 'Q' ? plan.quoteTier >= tier : plan.currentTier >= tier;
  }
  compareTierValues(plan, forType: string) {

    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentTier !== plan.quoteTier && plan.quoteTier == plan.renewalTier) {
        this.hideCurrentTier = true;
        return false;
      } else {
        this.hideCurrentTier = false;
        return true;
      }
    }
    if (StringUtils.isEqual(forType, 'R')) {
      if (plan.quoteTier !== plan.renewalTier && plan.quoteTier == plan.currentTier) {
        this.hideRenewalTier = true;
        return false;
      } else {
        this.hideRenewalTier = false;
        return true
      }
    }

  }
  getAnnualRate(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentRates && plan.currentRates.yearlyTotal) {
        this.vpc1.planComparison.forEach(ele => {
        })
        plan.currentRates.yearlyTotal = plan.currentRates.monthlyTotal * 12
        return plan.currentRates.yearlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (plan.renewalRates && plan.renewalRates.yearlyTotal) {
        plan.renewalRates.yearlyTotal = plan.renewalRates.monthlyTotal * 12
        return plan.renewalRates.yearlyTotal;
      }
    } else {
      if (plan.quoteRates) {
        plan.quoteRates.yearlyTotal = plan.quoteRates.monthlyTotal * 12;
        return plan.quoteRates.yearlyTotal;
      }
    }
    return 0;
  }
  getVPCplan(planID) {
    return this.vpc1.planComparison.find(x => x.quoteRatingPlanID === planID);
  }
  getTotalEnrollment(plan, forType: string) {
    let total = 0;
    if (StringUtils.isEqual(forType, 'C')) {
      for (let i = 1; i <= 5; i++) {
        total += this.getCalculatedEnrollments(plan.currentEnrollments, i);
      }
    } else if (StringUtils.isEqual(forType, 'Q')) {
      for (let i = 1; i <= 5; i++) {
        total += this.getCalculatedEnrollments(plan.quoteEnrollments, i);
      }
    }
    return total;
  }
  getCalculatedEnrollments(enrollment: Enrollments, index: number): number {
    let tierEnroll = enrollment["enrollT" + index];
    return tierEnroll && !isNaN(tierEnroll) ? tierEnroll * 1 : 0;
  }
  getAnnualRateDifference(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      plan.diffToCurrentYearlyRate = plan.quoteRates.yearlyTotal - plan.currentRates.yearlyTotal
      return plan.diffToCurrentYearlyRate;
    } else {
      plan.diffToRenewalYearlyRate = plan.quoteRates.yearlyTotal - plan.renewalRates.yearlyTotal
      return plan.diffToRenewalYearlyRate;
    }
  }
  getPercentage(value) {
    return value.toFixed(2) + '%';
  }
  getAbsoluteValue(value: number, type?: string): number | string {
    if (value && value != Infinity) {
      if (StringUtils.isEqual(type, 'percent')) {
        if (StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
          return formatPercent(Math.abs(value), this.locale, '1.1-1');
        } else {
          return formatPercent(Math.abs(value), this.locale, '1.0-2');
        }
      }
      return formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
    }
    return 0;
  }

  getPlanInfo(type: string, plan): string {
    return VisionUtil.getPlanInfo(type, plan);
  }
  getPlanEnrollment(plan, tierValue: number, forType: string): number {
    return VisionUtil.getPlanEnrollment(plan, tierValue, forType)
  }
  getEnrollmentTotal(plan, forType: string): number {
   return VisionUtil.getEnrollmentTotal(plan, forType);
  }
  getMonthlyRateDifference(plan, forType: string): number {
    return VisionUtil.getMonthlyRateDifference(plan, forType);
  }
  getMonthlyRate(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentRates && plan.currentRates.monthlyTotal) {
        return plan.currentRates.monthlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (plan.renewalRates && plan.renewalRates.monthlyTotal) {
        return plan.renewalRates.monthlyTotal;
      }
    } else {
      if (!this.isChangedFlag){
        return plan.quoteRates.monthlyTotal;
      } else {
        if (plan.quoteRates) {
          let rates = 0;
          for (let i = 1; i <= plan.quoteTier; i++) {
            let enr;
            enr = plan.quoteEnrollments['enrollT' + i] ? plan.quoteEnrollments['enrollT' + i] : 0;
            rates = rates + (Math.round((plan.quoteRates['ratesT' + i] + Number.EPSILON) * 100) / 100 * enr);
          }
          plan.quoteRates.monthlyTotal = rates;
          return plan.quoteRates.monthlyTotal;
        }
      }
    }
  }
  getDifferencePecentage(plan, forType: string): number {
    if(this.isRenewalQuoteDisabled()) {
      this.getMonthlyRate(plan, 'C');
      this.getEnrollmentTotal(plan, 'Q');
      this.getMonthlyRate(plan, 'Q');
      this.getAbsoluteValue(this.getMonthlyRateDifference(plan, 'C'));
      this.getAnnualRate(plan, 'C');
      this.getAnnualRate(plan, 'Q');
      this.getAbsoluteValue(this.getAnnualRateDifference(plan, 'C'));
    }


    // Otherwise, calculate the rate difference percentage as before
    if (StringUtils.isEqual(forType, 'C')) {
      if (this.isRenewalQuoteDisabled()) {
        plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.quoteRates.monthlyTotal * 12, plan.currentRates.yearlyTotal);
        return plan.diffToCurrentRatePercentage;
      } else {
        plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.quoteRates.yearlyTotal, plan.currentRates.yearlyTotal);
        return plan.diffToCurrentRatePercentage;
      }
    } else {
      plan.diffToRenewalRatePercentage = this.calculateRatePer(plan.quoteRates.yearlyTotal, plan.renewalRates.yearlyTotal);
      return plan.diffToRenewalRatePercentage;
    }
  }
  calculateRatePer(total, value) {
    let increase = total - value;//60974.16
    let diffPer = (increase / value);
    return diffPer;
  }
  classHighlighter(value): string {
    return value * 1 > 0 ? 'higher' : 'lesser';
  }
  hasMonthlyGrandTotal(forType: string): boolean {
    let total = this.getMonthlyTotalRate(forType);
    return total && total !== 0;
  }
  getColSpanGrand(): number {
    if (this.vpc1.hasRenewalRates) {
      if (this.getrenewalIncreasePercentage("R")) {
        if (!this.hasMonthlyGrandTotal("C")) {
          return 3;
        } else {
          return this.getTotalDifferencePecentage("C") ? 3 : 4;
        }
      } else {
        return 7;
      }
    } else {
      return 6;
    }
  }
  getrenewalIncreasePercentage(forType: string) {
    if (StringUtils.isEqual(forType, 'R')) {
      return this.vpc1.renewalIncreasePercentage ? this.vpc1.renewalIncreasePercentage : 0;
    }
  }
  getMonthlyTotalRate(forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      return (this.vpc1.currentMonthlyGrandTotal || 0);
    } else if (StringUtils.isEqual(forType, 'R')) {
      return (this.vpc1.renewalMonthlyGrandTotal || 0);
    } else {
      if (this.vpc1.quoteMonthlyGrandTotal) {
        let monthlyGrandTotal = 0;
        this.vpc1.planComparison.forEach(item => {
          if (item['hasQuotedRates']) {
            monthlyGrandTotal = monthlyGrandTotal + item.quoteRates.monthlyTotal;
            this.vpc1.quoteMonthlyGrandTotal = monthlyGrandTotal;

          }
        });
        return this.vpc1.quoteMonthlyGrandTotal;

      }
    }
  }
  getAnnualTotalRate(forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      return (this.vpc1.currentYearlyGrandTotal || 0);
    } else if (StringUtils.isEqual(forType, 'R')) {
      return (this.vpc1.renewalYearlyGrandTotal || 0);
    } else {
      if (this.vpc1.quoteYearlyGrandTotal) {
        this.vpc1.quoteYearlyGrandTotal = this.vpc1.quoteMonthlyGrandTotal * 12;
        return this.vpc1.quoteYearlyGrandTotal;
      }
    }
  }

  getMonthlyTotalRateDifference(forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      this.calculateGrandTotal();
      this.vpc1.diffToCurrentMonthlyTotal = this.vpc1.quoteMonthlyGrandTotal - this.vpc1.currentMonthlyGrandTotal;
      return this.vpc1.diffToCurrentMonthlyTotal ? this.vpc1.diffToCurrentMonthlyTotal : 0;
    } else {
      this.vpc1.diffToRenewalMonthlyTotal = this.vpc1.quoteMonthlyGrandTotal - this.vpc1.renewalMonthlyGrandTotal;
      return this.vpc1.diffToRenewalMonthlyTotal ? this.vpc1.diffToRenewalMonthlyTotal : 0;
    }
  }
  getAnnualTotalRateDifference(forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      this.calculateGrandTotal();
      this.vpc1.diffToCurrentYearlyTotal = this.vpc1.quoteYearlyGrandTotal - this.vpc1.currentYearlyGrandTotal;
      return this.vpc1.diffToCurrentYearlyTotal ? this.vpc1.diffToCurrentYearlyTotal : 0;
    } else {
      this.vpc1.diffToRenewalYearlyTotal = this.vpc1.quoteYearlyGrandTotal - this.vpc1.renewalYearlyGrandTotal;
      return this.vpc1.diffToRenewalYearlyTotal ? this.vpc1.diffToRenewalYearlyTotal : 0;
    }
  }
  getTotalDifferencePecentage(forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {

      this.vpc1.diffToCurrentRatePercentage = this.calculateRatePer(this.vpc1.quoteYearlyGrandTotal, this.vpc1.currentYearlyGrandTotal) * 100;
      this.calculateGrandTotal();
      return this.vpc1.diffToCurrentRatePercentage ? this.vpc1.diffToCurrentRatePercentage : 0;

    } else {
      this.vpc1.diffToRenewalRatePercentage = this.calculateRatePer(this.vpc1.quoteYearlyGrandTotal, this.vpc1.renewalYearlyGrandTotal) * 100;
      return this.vpc1.diffToRenewalRatePercentage ? this.vpc1.diffToRenewalRatePercentage : 0;
    }
  }
  currentPlansBenefitsList = [];
  onCurrentBenefits(plan: any){
    this.currentPlansBenefitsList = plan.currentPlanBenefits.length ? plan.currentPlanBenefits : null;
  }
  calculateGrandTotal() {
    this.vpc1.currentMonthlyGrandTotal = 0;
    this.vpc1.currentYearlyGrandTotal = 0;
    this.vpc1.quoteMonthlyGrandTotal = 0;
    this.vpc1.quoteYearlyGrandTotal = 0;
    this.vpc1.renewalMonthlyGrandTotal = 0;
    this.vpc1.renewalYearlyGrandTotal = 0;
    this.vpc1.planComparison.forEach((pc: PlanComparison) => {
      if (pc.quoteRates && pc.quoteRatingPlanID) {
        if (pc.currentRates.monthlyTotal && pc.currentRates.yearlyTotal != undefined) {
          this.vpc1.currentMonthlyGrandTotal += pc.currentRates.monthlyTotal;
          this.vpc1.currentYearlyGrandTotal += pc.currentRates.yearlyTotal;
        }
        this.vpc1.quoteMonthlyGrandTotal += pc.quoteRates.monthlyTotal;
        this.vpc1.quoteYearlyGrandTotal += pc.quoteRates.yearlyTotal;
        if (pc.hasRenewalRates) {
          this.vpc1.renewalMonthlyGrandTotal += pc.renewalRates.monthlyTotal;
          this.vpc1.renewalYearlyGrandTotal += pc.renewalRates.yearlyTotal;
        }
      }
    });
    if (this.vpc1.currentMonthlyGrandTotal)
      this.vpc1.diffToCurrentRatePercentage = this.vpc1.diffToCurrentMonthlyTotal / this.vpc1.currentMonthlyGrandTotal;
    else this.vpc1.diffToCurrentRatePercentage = 0;
  }
  markGuardRailFailuresPlanLevel(guardRail,visPlan) {
    if (this.featuredPlans) {
      let filteredEleList = {};
      let failedGuardRails = [];
      this.featuredPlans.forEach(element => {
        if (element.ratingPlanID == visPlan.quoteRatingPlanID) {
          if (element.failedGuardRails && element.failedGuardRails.length) {
            failedGuardRails = element.failedGuardRails;
          }
        }
      });
      if (visPlan.quoteRatingPlanID && failedGuardRails.length) {
       failedGuardRails.forEach(ele => {
          let guardrailRepRes = ele.split('.');
          filteredEleList[guardrailRepRes[guardrailRepRes.length - 1]] = 1;
        });
        let list = [];
        list = Object.keys(filteredEleList);
        if (list.find(x => x === guardRail)) {
          return true;
        } else {
          return false;
        }
      }
    }

  }
  premiumGuardrail: any;
  markGuardRailFailuresPremiumComparison() {
    if (this.vpc1 && this.vpc1['guardRailStatus'] && this.vpc1['guardRailStatus'].CPQuotedEnrollmentCount.status == 'Failed') {
      this.premiumGuardrail = (this.vpc1['guardRailStatus'].CPQuotedEnrollmentCount.value || '');
      return true;
    } else {
      return false;
    }
  }
  displayErrorMessage(eleID) {
    return VisionUtil.displayGuardrailErrorMessage(eleID, this.boundariesObjName, this.premiumGuardrail);
  }
  isRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
      if (StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && !this.rareData?.vision?.oppOrigin?.['altMarket']) {
        return true;
      } else {
        return false;
      }
    }
  }
  isSGRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
      if ((StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) || ((StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal) && this.rareData?.vision?.oppOrigin?.['altMarket']))) {
        return true;
      } else {
        return false;
      }
    }
  }

  updateQuoteRatesFromAdjustments() {
    if (!this.adjustedPlans || !this.vpc1 || !this.vpc1.planComparison) {
      return;
    }

    this.vpc1.planComparison.forEach((plan: any) => {
      const adjustedPlan = this.adjustedPlans.find((ap: any) => ap.ratingPlanID === plan.quoteRatingPlanID);
      if (adjustedPlan && adjustedPlan.uwAdjustment && adjustedPlan.uwAdjustment !== 1) {
        const adjustmentFactor = adjustedPlan.uwAdjustment;
        for (let tier = 1; tier <= 5; tier++) {
          const rateKey = 'ratesT' + tier;
          if (plan.quoteRates[rateKey] !== undefined) {
            const originalRate = plan.initialRates && plan.initialRates[rateKey] 
              ? plan.initialRates[rateKey] 
              : plan.quoteRates[rateKey] / adjustmentFactor;
            
            plan.quoteRates[rateKey] = originalRate * adjustmentFactor;
          }
        }
        this.calculatePlanTotals(plan);
      }
    });
    this.calculateGrandTotal();
  }

  private calculatePlanTotals(plan: any) {
    if (!plan.quoteEnrollments || !plan.quoteRates) {
      return;
    }
    let monthlyTotal = 0;
    for (let tier = 1; tier <= 5; tier++) {
      const enrollment = plan.quoteEnrollments['enrollT' + tier] || 0;
      const rate = plan.quoteRates['ratesT' + tier] || 0;
      monthlyTotal += rate * enrollment;
    }
    plan.quoteRates.monthlyTotal = monthlyTotal;
    plan.quoteRates.yearlyTotal = monthlyTotal * 12;
  }
  
}
