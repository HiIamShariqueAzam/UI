import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { MultiSelectModule } from 'primeng/multiselect';
import { RadioButtonModule } from 'primeng/radiobutton';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { ToastModule } from 'primeng/toast';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { OpportunitiesHistoryVisionComponent } from './opportunities-history-vision/opportunities-history-vision.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { ViewBenefitModalComponent } from './view-benefit-modal/view-benefit-modal.component';
import { VisionPremiumComparisonComponent } from './vision-premium-comparison/vision-premium-comparison.component';
import { AdjustmentsVisionComponent } from './adjustments-vision/adjustments-vision.component';
import { VisionComponent } from './vision.component';
import { ViewCalcModalComponent } from './view-calc-modal/view-calc-modal.component';
import { QuoteDetailsVisionComponent } from './quote-details/quote-details-vision.component';
import { FeaturedPlansVisionComponent } from './featured-plans/featured-plans.component';
import { PortfolioPlansVisionComponent } from './portfolio-plans/portfolio-plans.component';
import { ViewCalcNYModalComponent } from './view-calc-ny-modal/view-calc-ny-modal.component';
import { AdjustmentHistoryComponent } from './adjustment-history/adjustment-history.component';
import { DeclineQuoteModule } from '../common/decline-quote/decline-quote.module';
import { TooltipModule } from 'primeng/tooltip';
import { SharedModule } from 'src/app/shared/shared.module';
import { VisionExhibitOverridesComponent } from './exhibit-overrides/vision-exhibit-overrides.component';
import { DatePickerModule } from 'primeng/datepicker';

@NgModule({
    declarations: [
        VisionComponent,
        OpportunitiesHistoryVisionComponent,
        ViewBenefitModalComponent,
        VisionPremiumComparisonComponent,
        AdjustmentsVisionComponent,
        ViewCalcModalComponent,
        ViewCalcNYModalComponent,
        QuoteDetailsVisionComponent,
        FeaturedPlansVisionComponent,
        PortfolioPlansVisionComponent,
        AdjustmentHistoryComponent,
        VisionExhibitOverridesComponent
    ],
    imports: [
        CommonModule, TableModule, ButtonModule, ReactiveFormsModule, RadioButtonModule, FlexLayoutModule, FormsModule, ToastModule, NgbModule, ProgressSpinnerModule, ConfirmDialogModule, DialogModule,
        MultiSelectModule, DeclineQuoteModule, TooltipModule, SharedModule,DatePickerModule,
        RouterModule.forChild([
            // { path: '', component: UwAdjustmentVisionInterimComponent, pathMatch: 'full' },
            { path: 'longterm', component: VisionComponent, pathMatch: 'full' },
            { path: '', redirectTo: 'longterm', pathMatch: 'full' },
        ])
    ],
    bootstrap: [VisionComponent],
    providers: [DatePipe, ConfirmationService, MessageService],
    exports: [
        VisionComponent,
        OpportunitiesHistoryVisionComponent,
        ViewBenefitModalComponent,
        ViewCalcModalComponent,
        ViewCalcNYModalComponent,
        QuoteDetailsVisionComponent
    ]
})
export class VisionModule {

 }
