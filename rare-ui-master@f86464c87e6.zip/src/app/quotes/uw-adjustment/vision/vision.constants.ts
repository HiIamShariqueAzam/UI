
export class VisionConstants {

    public static renewalLocal: string = 'Renewal Local';
    public static newBusinessLocal: string = 'New Business Local';
    public static smallGroup: string = 'SG';
    public static largeGroup: string = 'LG';

    // Guardrail messages
    public static contractEffectiveDateMessage = 'Contract start date is in the past, request /update is submitted on ';
    public static visionCommissionPCPMMessage = 'Commission PCPM value is greater than ';
    public static visionCommisionNYFactorMessage = 'Commission is not between ';
    public static visionPremRateDifferenceMessage = 'Difference between quoted premium and anthem premium is more than ';
    public static visionCompetativeAdjustmentMessage = 'Competitive Rate Adjustment percent is not between ';
    public static visionExperienceClaimsMessage = 'Experience Claims is included';
    public static visionAdjustmentFactorMessage = 'Adjustment type is Beat';
    public static visionRateGuaranteeMonthsFactorMessage = 'Rate Guarantee months is greater than ';
    public static visionCommissionFactorMessage = 'Commission is greater than';

    public static contractEffectiveDateKey = 'contractEffectiveDate';
    public static visionCommissionPCPMKey = 'Vision Commission PCPM';
    public static visionCommisionNYFactorKey = 'Vision NY Commission Factor';
    public static visionPremRateDifferenceKey = 'Vision Premium Rate Diff';
    public static visionCompetativeAdjustmentKey = 'Vision Competitive Adjustment';
    public static visionExperienceClaimsKey = 'Experience Claims';
    public static visionAdjustmentFactorKey = 'Vision adjustmentType Factor';
    public static visionRateGuaranteeMonthsFactorKey = 'Vision Rate Guarantee Months Factor';
    public static visionCommissionFactorKey = 'Vision Commission Factor';
    public static visionPremiumComparisonKey = 'Vision Premium comparison';

    public static dollar = '$';
    public static percent = '%';
    public static pcpm = 'PCPM';
    public static other = 'Other';
    public static months = 'months';
    public static invalidValue = 'Invalid Value';
    public static single = 'single';
    public static family = 'family';
    public static eeOne = 'eeOne';
    public static eeSpouse = 'eeSpouse';
    public static eeChildren = 'eeChildren';
    public static eeChild = 'eeChild';

    // table headers
    public static viewCalc = 'View Calc';
    public static contractCode = 'Contract Code';
    public static planName = 'Plan Name';
    public static genAgentCommission = 'General Agent Commission';
    public static association = 'Association';
    public static adjustmentType = 'Adjustment Type';
    public static salesAdjustment = 'Sales Adjustment';
    public static applyCurrentRatio = 'Apply Current Ratio';
    public static planType = 'Plan Type';
    public static participationType = 'Participation Type';
    public static eyeExam = 'Eye Exam';
    public static prescriptionLens = 'Prescription Lens';
    public static frames = 'Frames';
    public static electiveContactLens = 'Elective Contact Lens';
    public static nonElectiveContactLens = 'Non Elective Contact Lens';
    public static errorInfo = 'Error Info';
    public static electiveContactLensPlus = 'Elective Contact Lens (PLUS)';
    public static framesPlue = 'Frames (PLUS)';
    public static eyeExamPlus = 'Eye Exam (PLUS)';

    public static employee = 'Employee';
    public static spouse = 'Spouse';
    public static child = 'Child';
    public static children = 'Children';
    public static employeePlusOne = 'Employee+1';
    public static Family = 'Family';
    public static one = 'One';
    public static employeePlusSpouse = 'Employee +Spouse';
    public static employeePlusChild = 'Employee +Child';
    public static employeePlusChildren = 'Employee +Children';
    public static employeePlusFamily = 'Employee +Family';
    


    // view calc NY
    public static claimCost = 'claimCost';
    public static mbrPerCntrctFctr = 'mbrPerCntrctFctr';
    public static fmlyDscntFctr = 'fmlyDscntFctr';
    public static pdtrcFctr = 'pdtrcFctr';
    public static cmpgnDiscFctr = 'cmpgnDiscFctr';
    public static initialRates = 'initialRates';
    public static rateInfo = 'rateInfo';
    public static competitiveRateAdjustmentPercent = 'competitiveRateAdjustmentPercent';
    public static calculatedFactors = 'calculatedFactors';
    public static admnCost = 'admnCost';
    public static totalAdminExpense = 'totalAdminExpense';
    public static totFctr = 'totFctr';

    // LOBs
    public static Vision = 'Vision';
    public static Medical = 'Medical';
    public static Dental = 'Dental';

    // Action
    public static releaseAction = 'release';
    public static declineAction = 'decline';

    // status
    public static releasedStatus = 'Released';
    public static modifiedStatus = 'Modified';
    public static declineStatus = 'decline';

    public static uwComments = 'uwComments';
    public static salesNotetoUW = 'salesNotetoUW';
    public static uwAdjustment = 'uwAdjustment';
    public static uwNotesToSales = 'uwNotesToSales';

    public static NOT_APPLICABLE = 'Not Applicable';
}