import { StringUtils } from "src/app/shared/utils/string-utils";
import { VisionConstants } from "./vision.constants";

export class VisionUtil {

  public static tierDescription: any = {
    "1-Tier": {
      "EE": VisionConstants.employee
    },
    "3-Tier": {
      "EE": VisionConstants.employee,
      "EF": VisionConstants.employee + ' + '+ VisionConstants.Family,
      "E1": VisionConstants.employee + ' + '+ VisionConstants.one
    },
    "4-Tier": {
      "EE": VisionConstants.employee,
      "EF": VisionConstants.employee + ' + '+ VisionConstants.Family,
      "ES": VisionConstants.employee + ' + '+ VisionConstants.spouse,
      "EC": VisionConstants.employee + ' + '+ VisionConstants.children
    },
    "5-Tier": {
      "EE": VisionConstants.employee,
      "EF": VisionConstants.employee + ' + '+ VisionConstants.Family,
      "EK": VisionConstants.employee + ' + '+ VisionConstants.child,
      "ES": VisionConstants.employee + ' + '+ VisionConstants.spouse,
      "EC": VisionConstants.employee + ' + '+ VisionConstants.children
    },
    "2-Tier": {
      "EE": VisionConstants.employee,
      "EF": VisionConstants.employee + ' + '+ VisionConstants.Family
    }
  };
  public static defaultTierNames = {
    "EE": VisionConstants.Family,
    "EF": VisionConstants.employee + ' + '+ VisionConstants.Family,
    "EK": VisionConstants.employee + ' + '+ VisionConstants.child,
    "EC": VisionConstants.employee + ' + '+ VisionConstants.children,
    "ES": VisionConstants.employee + ' + '+ VisionConstants.spouse,
    "E1": VisionConstants.employee + ' + '+ VisionConstants.one
  };

  // Vision Guardrail error messages
  public static displayGuardrailErrorMessage(eleID, boundariesObjName, premiumGuardrail?) {
    switch (eleID) {
      case VisionConstants.contractEffectiveDateKey:
        return VisionConstants.contractEffectiveDateMessage;
      case VisionConstants.visionCommissionPCPMKey:
        return VisionConstants.visionCommissionPCPMMessage + boundariesObjName[eleID]?.maxVal + VisionConstants.dollar;
      case VisionConstants.visionCommisionNYFactorKey:
        return VisionConstants.visionCommisionNYFactorMessage + boundariesObjName[eleID]?.minVal + VisionConstants.percent + ' and ' + boundariesObjName[eleID]?.maxVal + VisionConstants.percent;
      case VisionConstants.visionPremRateDifferenceKey:
        return VisionConstants.visionPremRateDifferenceMessage + boundariesObjName[eleID]?.maxVal + VisionConstants.percent;
      case VisionConstants.visionCompetativeAdjustmentKey:
        return VisionConstants.visionCompetativeAdjustmentMessage + boundariesObjName[eleID]?.minVal + VisionConstants.percent + ' and ' + boundariesObjName[eleID]?.maxVal + VisionConstants.percent;
      case VisionConstants.visionExperienceClaimsKey:
        return VisionConstants.visionExperienceClaimsMessage;
      case VisionConstants.visionAdjustmentFactorKey:
        return VisionConstants.visionAdjustmentFactorMessage;
      case VisionConstants.visionRateGuaranteeMonthsFactorKey:
        return VisionConstants.visionRateGuaranteeMonthsFactorMessage + boundariesObjName[eleID]?.maxVal + ' ' + VisionConstants.months;
      case VisionConstants.visionCommissionFactorKey:
        return VisionConstants.visionCommissionFactorMessage + boundariesObjName[eleID]?.maxVal + VisionConstants.percent;
      case VisionConstants.visionPremiumComparisonKey:
        return premiumGuardrail;
      default:
        return;
    }
  }

  public static getTierEmpDesc(tierNumber: number, availableTiers: number): string {
    let tieredValue = this.tierDescription[availableTiers + '-Tier'];
    if (!tieredValue) {
      tieredValue = this.defaultTierNames;
    }
    switch (availableTiers) {
      case 1:
        if (tierNumber == 1) {
          return tieredValue.EE;
        }
      case 2:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.EF;
        }
      case 3:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.E1;
        } else if (tierNumber == 3) {
          return tieredValue.EF;
        }
      case 4:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EC;
        } else if (tierNumber == 4) {
          return tieredValue.EF;
        }
      case 5:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EK;
        } else if (tierNumber == 4) {
          return tieredValue.EC;
        } else if (tierNumber == 5) {
          return tieredValue.EF;
        }
    }
    return '';
  }

  public static markGuardRailFailuresPlanLevel(guardRail,visPlan) {
    let filteredEleList = {};
    if (visPlan.ratingPlanID && visPlan.failedGuardRails && visPlan.failedGuardRails.length) {
      visPlan.failedGuardRails.forEach(ele => {
        let guardrailRepRes = ele.split('.');
        filteredEleList[guardrailRepRes[guardrailRepRes.length - 1]] = 1;
      });
      let list = [];
      list = Object.keys(filteredEleList);
      if (list.find(x => x === guardRail)) {
        return true;
      } else {
        return false;
      }
    }
  }
  public static isNumber(evt) {
    var el = evt.target;
    var charCode = evt.charCode;
    var number = el.value.split(".");
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false ;
    }
    if (number.length > 1 && charCode == 46) {
      return false ;
    }
    var caratPos = this.getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && number[1].length > 10) {
      return false ;
    }
    return true;
  }
  public static getSelectionStart(o) {
    return o.selectionStart;
  }

  public static  isCurency(evt) {
    var el = evt.target;
    var charCode = evt.charCode;
    var number = el.value.split(".");
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false ;
    }
    if (number.length > 1 && charCode == 46) {
      return false ;
    }
    var caratPos = this.getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && number[1].length > 1) {
      return false ;
    }
    return true;
  }
  public static isEnr(event) {
    if (event.charCode > 31 && (event.charCode < 48 || event.charCode > 57))
      return false;
    else
      return true;
  }

  public static checkIfNull(plan){
    plan['uwAdjustment'] = plan.factors.uwDiscretFctr;
    if(plan.factors.uwDiscretFctr == null || plan.factors.uwDiscretFctr == undefined ){
     return null;
    }
    else {
      if ((String(plan.factors.uwDiscretFctr).match(/^(\d?(\.\d{1,10})?)?$/g))) {
        if (String(plan.factors.uwDiscretFctr) !== '0' && String(plan.factors.uwDiscretFctr) !== '' && plan.factors.uwDiscretFctr !== undefined) {
          return null;
        } else {
          return true;
        }
      } else {
        return true;
      }
    }
  }

  public static getTierRates(tierNumber, visionOutputTier, viewCalcPlan, rates) {
    switch (Number(visionOutputTier)) {
      case 1:
        if (tierNumber == 1) {
          return viewCalcPlan[rates].single;
        }
      case 2:
        if (tierNumber == 1) {
          return viewCalcPlan[rates].single;
        } else if (tierNumber == 2) {
          return viewCalcPlan[rates].family;
        }
      case 3:
        if (tierNumber == 1) {
          return viewCalcPlan[rates].single;
        } else if (tierNumber == 2) {
          return viewCalcPlan[rates].eeOne;
        } else if (tierNumber == 3) {
          return viewCalcPlan[rates].family;
        }
      case 4:
        if (tierNumber == 1) {
          return viewCalcPlan[rates].single;
        } else if (tierNumber == 2) {
          return viewCalcPlan[rates].eeSpouse;
        } else if (tierNumber == 3) {
          return viewCalcPlan[rates].eeChildren;
        } else if (tierNumber == 4) {
          return viewCalcPlan[rates].family;
        }
      case 5:
        if (tierNumber == 1) {
          return viewCalcPlan[rates].single;
        } else if (tierNumber == 2) {
          return viewCalcPlan[rates].eeSpouse;
        } else if (tierNumber == 3) {
          return viewCalcPlan[rates].eeChild;
        } else if (tierNumber == 4) {
          return viewCalcPlan[rates].eeChildren;
        } else if (tierNumber == 5) {
          return viewCalcPlan[rates].family;
        }
    }
  }
  public static roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }
  public static calculatedFloatValue(factor: any): any {
    let floatValue = parseFloat(factor);
    if (isNaN(floatValue) || factor == "") {
      return "";
    } else {
      return floatValue !== 0 ? floatValue : "";
    }
  }
  public static getPlanEnrollment(plan, tierValue: number, forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      if (
        plan.currentEnrollments &&
        (plan.currentEnrollments["enrollT" + tierValue] ||
          plan.currentEnrollments["enrollT" + tierValue] == 0)
      ) {
        return plan.currentEnrollments["enrollT" + tierValue];
      }
    } else {
      if (
        plan.quoteEnrollments &&
        (plan.quoteEnrollments["enrollT" + tierValue] ||
          plan.quoteEnrollments["enrollT" + tierValue] == 0)
      ) {
        return plan.quoteEnrollments["enrollT" + tierValue];
      }
    }
    return 0;
  }
  public static getEnrollmentTotal(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentEnrollments && plan.currentEnrollments.totalEnroll) {
        return plan.currentEnrollments.totalEnroll;
      }
    } else {
      if (plan.quoteEnrollments && plan.quoteEnrollments.totalEnroll) {
        return plan.quoteEnrollments.totalEnroll;
      }
    }
    return 0;
  }
  public static getMonthlyRateDifference(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      plan.diffToCurrentMonthlyRate = plan.quoteRates.monthlyTotal - plan.currentRates.monthlyTotal
      return plan.diffToCurrentMonthlyRate
    } else {
      plan.diffToRenewalMonthlyRate = plan.quoteRates.monthlyTotal - plan.renewalRates.monthlyTotal
      return plan.diffToRenewalMonthlyRate;
    }
  }
  public static getPlanInfo(type: string, plan): string {
    if (StringUtils.isEqual(type, 'C')) {
      return 'Current Plan - ' + plan.currentplanName + ' (' + plan.currPlanId + ') ' + ' (' + plan.currentCarrierName + ')';
    }
    else {
      return 'Featured Plan - ' + plan.quotePlanName + ' (' + plan.quoteContractCode + ') ' + ' (' + plan.quoteLegalEntity + ')';
    }
  }
  public static toolTipData(MedPlan) {
    let errorData = '';
    if (MedPlan.errors && MedPlan.errors.rareError) {
      for (let error of MedPlan.errors.rareError) {
        if (errorData)
          errorData = errorData + ' , ' + error.overallErrorMessage;
        else
          errorData = error.overallErrorMessage;
      }
    }
    return errorData;
  }

  public static calculateRateGuaranteeMonths(date1: Date, date2: Date) {
    // Calculate the difference in months regardless of the day
    let months = (date2.getFullYear() - date1.getFullYear()) * 12 + (date2.getMonth() - date1.getMonth());
    // If the end date's day is greater than or equal to the start date's day, count as a full month
    if (date2.getDate() >= date1.getDate()) {
      months += 1;
    }
    // Always return at least 0
    return months <= 0 ? 0 : months;
  }
}
