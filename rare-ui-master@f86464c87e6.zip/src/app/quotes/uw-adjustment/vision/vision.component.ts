import { DatePipe, KeyValue, Location } from '@angular/common';
import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, Inject, LOCALE_ID, OnInit,Renderer2, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { MultiSelect } from 'primeng/multiselect';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { RateInfo } from 'src/app/shared/models';
import { AdjustmentVision } from 'src/app/shared/models/uwAdjustmentVision';
import { AuthenticationService, CommonService, PrintExhibitService, ProcessQuoteDetailsService } from 'src/app/shared/services';
import { OffCycleModalService } from 'src/app/shared/services/off-cycle-modal.service';
import { OffCycleModalComponent } from 'src/app/shared/components/off-cycle-modal/off-cycle-modal.component';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { DateUtil } from 'src/app/shared/utils/date-util';
import { isArray } from 'util';
import { CommonQuoteService } from '../../services/common-quote.service';
import { AdjustmentsVisionComponent } from './adjustments-vision/adjustments-vision.component';
import { VisionConstants } from './vision.constants';
import { VisionUtil } from './vision.util';
import { QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
import { UWAdjustmentChangeSetService } from '../medical/uw-adjust-changeset.service';

@Component({
  selector: 'app-vision',
  templateUrl: './vision.component.html',
  styleUrls: ['./vision.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class VisionComponent implements OnInit, AfterViewInit {


  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  private eventSources: EventSource[] = [];
  isFileUpload: boolean = false;

  declineQuoteBool: boolean=false;
  gridApi;
  gridColumnApi;
  adjustment_form: FormGroup<AdjustmentVision>;
  RateInfo: any;
  rareData: any = {};
  plans: RateInfo[];
  featuredPlans: RateInfo[];
  portfolioPlans: RateInfo[];
  calcDetails: any[];
  userSelectedTier: any;
  selectedQuoteAction: any;
  lobFundingType: any;
  public isCollapsed = false;
  public isAdjCollapsed = false;
  public div_visible = false;
  public disableSoldTab = false;
  visionPremiumComparison: any;
  showVisionPremiumComparison: boolean;
  opportunityData: any;
  AdjData: any;
  value: Date;
  contractStartDate: any;
  contractEndDate: any;
  factorEffectiveDate: any;
  reqTier: any;
  visionInputTier: any;
  accountName = 'Loading';
  state: any;
  salesRepName: any;
  noData: string = "Not Available";
  salesContactNo: any;
  totalMedEmp: any;
  empEnrolPlan: any;
  fundType: any;
  eligibleEmp: any;
  riskScore: any;
  medAgeSex: any;
  visPlans: any[];
  errorPlans: any[] = [];
  rateColumns: any[];
  totGroupSize: any;
  planColumnsE: any;
  planColumnsP: any;
  status: string;
  quoteError: any = '';
  quoteErrorMessage: boolean = false;
  disableAll: boolean = false;
  oldQuotesData: any;
  processId: any;
  quoteErrorCode: any = '';
  declineReasons: any[] = [];
  declineCheckboxes: any[] = [];

  showProgress: boolean = false;
  expandClicked: boolean = true;
  progressPercent: number = 0;
  progressStyle: string;
  progressMessage: any;
  addr1: any;
  addr2: any;
  compZipcode: any;
  scrollTop: any;
  censusID: any;
  opportunityType:string;
  marketSegment: string;
  quotingType: any;
  initializeQuote: boolean = false;
  factorsAndTierLivesLoaded: boolean = false;
  uwLoaded: boolean = false;
  vpcLoaded: boolean = false;
  allPlansLoaded: boolean = false;
  portfolioPlanLoaded: boolean = false;
  featuredPlanLoaded: boolean = false;
  erredPlanLoaded: boolean = false;
  searchAnywhere: string;

  hasPortfolioPlans: boolean = false;
  hasFeaturedPlans: boolean = false;
  hasErredPlans: boolean = false;

  noOfPlans: number = 0;
  noOfPlansLoadComplete: number = 0;
  releaseOptions: any[] = [];
  selectedReleaseOption:any;
  showAdjustmentHistory: boolean = false;
  exhibitVision: any[];
  hasPEOverrideError: boolean = false;

  @ViewChild(AdjustmentsVisionComponent) AdjustmentsVisionComponent;
  planColumnsBefore = [
    { header: VisionConstants.errorInfo },
    { header: VisionConstants.planType },
    { header: VisionConstants.contractCode },
    { header: VisionConstants.planName },
    { header: VisionConstants.genAgentCommission },
    { header: VisionConstants.association },
    { header: VisionConstants.adjustmentType },
    { header: VisionConstants.planType },
    { header: VisionConstants.participationType },
    { header: VisionConstants.eyeExam },
    { header: VisionConstants.prescriptionLens },
    { header: VisionConstants.frames },
    { header: VisionConstants.electiveContactLens },
    { header: VisionConstants.nonElectiveContactLens },
  ];

  planColumns = [
    { header: "Error Info" },
    { header: "Plan Type" },
  ];

  tierList = [
    { tier: '2' },
    { tier: '3' },
    { tier: '4' }
  ];
  actionList = [
    { action: 'Quote' },
    { action: 'Decline to Quote' }
  ]

  successMessage: any;
  failureMessage: any;
  warningMessage: any;
  loadingMessage = CommonConstants.QUOTE_DETAILS_LOADING_MESSAGE;
  alertData: any;
  metaTransID: string;
  ratingTransID: string;
  metaSenderApp: string;
  calcVisPlan: any;
  opportunityID: string;
  quoteHeaderID: string;
  quoteOrigin: string;
  lob: string;
  fundingType: string;
  quotedSubs: number;
  rateInfoResponse: any;
  alphaNumericPattern = "^[a-z0-9_]{8,15}$";
  exhibitInfo: any[];
  documents: any[];
  intervalId: any;
  sicCode: any;
  lobMedical = 'Medical';
  lob1: any;
  activeTab: any = 'featured';
  EE: any = 0;
  EF: any = 0;
  ES: any = 0;
  EC: any = 0;
  E1: any = 0;
  EK: any = 0;

  benefitsColSpanE: any;
  isExpandedF: any;
  isExpandedP: any;
  expandClickedF = false;
  expandClickedP = false;
  disableprint: boolean = false;
  isMEWARenOGQuote: boolean = false;
  portfolioPlanCount = 0;
  featuredPlanCount = 0;
  erredPlanCount = 0;
  errorPlanCount = 0;
  rateGuaranteeMonths: any;
  medEmp: any;
  transID: any;
  oppID: any;
  dateFormatMMDDYYYY: string = 'MM-dd-yyyy';
  isReadOnlyRole: boolean = false;
  userRole: any;
  quoteReason: any;
  statusReasons: any;
  visionPremComparison: any = {};
  isVPCChanged: boolean = false;
  multiselectEle: any;
    receivedEventsList: any = [];
  InitialRateData: any = {};
  virginGroup: any;
  waivers: number = 0;
  totEligibleEmp: any = 0;
  guardrailBoundaries: any;
  experienceIncluded: any;
  quoteDetailsObj = {};
  adjustedPlans = [];
  rareDataObjPortfolio: any = {};
  InitialFeaturedPlansData: any;
  rareDataObj: any = {};
  alternateQuote: boolean = false;
  exhibitVisionEnabled: boolean = false;
  adjustedArr: any = [];

  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  ngAfterViewInit() {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);

  }
  displayOptionsPannel() {
    if (this.multiselectEle) {
      this.multiselectEle.focus();
    }
  }

  constructor(@Inject(LOCALE_ID) private locale: string, private fb: FormBuilder, private commonService: CommonService, private router: Router, private route: ActivatedRoute, private changeDet: ChangeDetectorRef,
    private _location: Location, config: NgbModalConfig, private modalService: NgbModal, public datepipe: DatePipe, private authService: AuthenticationService, private processQuoteService: ProcessQuoteDetailsService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,private peService:PrintExhibitService, private commonQuoteService: CommonQuoteService,private elRef: ElementRef, private uwChangeSetService: UWAdjustmentChangeSetService, public offCycleModalService: OffCycleModalService) {
    config.backdrop = 'static';
    config.keyboard = false;
    this.disableSoldTab = true;
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.router.navigated = false;
        window.scrollTo(0, 0);
      }
    });
  }

  open(content) {
    this.modalService.open(content);
  }
  checkUserRole() {
    if (this.userRole.includes('ADMIN') || this.userRole.includes('READONLY')) {
      return true;
    } else if (this.userRole.includes('ADMIN') && !this.userRole.includes('READONLY')) {
      return false;
    }
  }
  updateContractEndDate(e: any) {
    this.contractEndDate = new Date(e);
  }

  createPopup(tempVisPlan: any) {
    console.log(tempVisPlan)
  }

  originalOrder = (a: KeyValue<string, any>, b: KeyValue<string, any>): number => {
    return 0;
  }

  isTabActive(plan) {
    this.activeTab = plan;
  }

  checkTabData() {
    const medicalPlanTabsWrapper = document.querySelector('.nav-pills-wrapper');
    const tabCount = medicalPlanTabsWrapper.querySelectorAll('li').length;
    if (tabCount == 2) {
      return 'tabWidth_2';
    }
    if (tabCount == 3) {
      return 'tabWidth_3';
    }
    if (tabCount > 3) {
      return 'tabWidth_4';
    }
    return 'tabWidth';
  }
  isReleased(status) {
    if (status === true) {
      return "releaseStyle";
    } else { return false; }
  }

  handleRateInitialResponse(metadata, data) {
    this.quoteError = '';
    this.listenPrintExhibit(data.processID);
    this.rareData.metadata = this.commonService.deepCopy(metadata);
    this.metaTransID = this.rareData.metadata.metaTransID;
    this.metaSenderApp = this.rareData.metadata.sourceSystem;
     this.mergeRateDataWithAsyncData(JSON.parse(JSON.stringify(data)));
    if (data.errors && data.errors.errorList) {
      for (let error of data.errors.errorList) {
        this.quoteErrorCode = error.code;
        if (this.quoteError)
          this.quoteError = this.quoteError + ' , ' + error.msg;
        else
          this.quoteError = error.msg;
      }

      this.quoteError = this.quoteError.replaceAll('. ,', '. ');
      if (this.quoteError) {
        this.quoteErrorMessage = true;
      }
    }
    this.accountName = data.accountName;
    let rareData = data;
    this.censusID = rareData['censusRefId'];
    this.addr1 = rareData['addr1'];
    this.addr2 = rareData['addr2'];
    this.compZipcode = rareData['companyZipCode'];
    this.virginGroup = rareData['virginGroup'];
    this.opportunityType = rareData['opportunityType'];
    this.quotingType = this.rareData['quotingType'];
    this.marketSegment = rareData['marketSegment'];
    this.quoteOrigin = rareData['quoteOrigin'] ? rareData['quoteOrigin']: null;
    this.experienceIncluded = data.vision.experienceClaimsAvailable ? data.vision.experienceClaimsAvailable : '';
    this.alternateQuote = this.rareData.vision.alternateQuote ? true : false;

 	  if (data.primaryUserInfo) {
      //If primaryUser exist then it takes priority
      this.salesRepName = data.primaryUserInfo.fullName ?
        data.primaryUserInfo.fullName : this.noData;
      this.salesContactNo = data.primaryUserInfo.contactNumber ?
        data.primaryUserInfo.contactNumber : this.noData;
    }else {
      this.salesRepName = this.noData;
      this.salesContactNo = this.noData;
    }
    this.status = data.status ? data.status : this.noData;

    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.visEligibilityLivesMap &&
      data.censusCalc.censusSubscriber.visEligibilityLivesMap.QuotedCount) {
      this.totEligibleEmp = data.censusCalc.censusSubscriber.visEligibilityLivesMap.QuotedCount ?
            data.censusCalc.censusSubscriber.visEligibilityLivesMap.EligibleCount : 0;
    }
    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.visEligibilityLivesMap &&
      data.censusCalc.censusSubscriber.visEligibilityLivesMap.QuotedCount) {
        this.quotedSubs = data.censusCalc.censusSubscriber.visEligibilityLivesMap.QuotedCount ?
        data.censusCalc.censusSubscriber.visEligibilityLivesMap.EligibleCount : 0;
      }
    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.visEligibilityLivesMap &&
      data.censusCalc.censusSubscriber.visEligibilityLivesMap.QuotedCount) {
        this.waivers = data.censusCalc.censusSubscriber.visEligibilityLivesMap.W ? data.censusCalc.censusSubscriber.visEligibilityLivesMap.W : 0;
      }
      this.disableSoldTab = !(data.soldEnabled == true || data.soldEnabled == "true");
    this.reqTier = data.visionOutputTier;
    this.visionInputTier = data.visionInputTier;
     this.quotedSubs = this.totEligibleEmp - this.waivers;
     this.factorEffectiveDate = data.factorEffectiveDate;
    this.quoteDetailsObj = {
      'censusID': this.censusID,
      'accountName': data.accountName,
      'opportunityID': this.oppID,
      'state': this.state = data.state ? data.state : this.noData,
      'address1': this.addr1,
      'address2': this.addr2,
      'compZipcode': this.compZipcode,
      'county': this.InitialRateData.county,
      'fundingType': this.fundingType,
      'virginGroup': this.virginGroup,
      'experienceIncluded': this.experienceIncluded,
      'salesRepName': this.salesRepName,
      'salesContactNo': this.salesContactNo,
      'factorEffectiveDate': data.factorEffectiveDate,
      'contractStartDate': data.contractEffectiveDate,
      'rateGuaranteeMonths': data.vision.rateGuaranteeMonths,
      'visionInputTier': data.visionInputTier,
      'reqTier': data.visionOutputTier,
      'quotedSubs': this.quotedSubs,
      'waivers': this.waivers,
      'totEligibleEmp': this.totEligibleEmp,
      'status': this.status,
      'quoteHeaderID': this.quoteHeaderID,
      'lob1': this.lob1,
      'oppID': this.oppID,
      'opportunityType' : this.opportunityType,
      'marketSegment' : this.marketSegment,
      'mbs' : data.mbs,
      'quotingType' : this.quotingType,
      'quoteOrigin' : this.quoteOrigin,
      'alternateQuote': this.rareData.vision.alternateQuote
    }

    this.declineQuoteBool=false;
    setTimeout(() => {
      this.declineQuoteBool=true;
    });
  }

  loadRateInfo() {
    this.quoteErrorCode = '';
    this.commonQuoteService.getRateInfoVision(this.transID, this.oppID, this.quoteHeaderID, this.quoteOrigin, this.lob1, this.fundingType).subscribe(response => {
      var source = this.commonService.listenForStream(response.processId);
      this.eventSources.push(source);
      source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS, (event: any) => {
        if (event && event.data) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data && data.payload.metadata) {
            this.isFileUpload = !!data.payload.data.isFileUpload;
            this.handleRateInitialResponse(data.payload.metadata, data.payload.data);
            this.initializeQuote = true;
          }
        }
      });
      source.addEventListener("OTHER_DETAILS_FETCH", (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.OTHER_DETAILS_FETCH)) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handleFactorsAndTierLives(data.payload.data);
            this.factorsAndTierLivesLoaded = true;


          }
        }
      });
      source.addEventListener(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH)) {
          this.receivedEventsList.push(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data ) {
            this.handleUWResponse(data.payload.data);

          }
          if (StringUtils.isUndefined(data.payload.data[CommonConstants.uwAdjustment])) {
            this.showAdjustmentHistory = false;
          } else {
            this.showAdjustmentHistory = true;
          }
        }
      });
      source.addEventListener(CommonConstants.VISION_PREMIUM_COMPARISON_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.VISION_PREMIUM_COMPARISON_FETCH)) {
          this.receivedEventsList.push(CommonConstants.VISION_PREMIUM_COMPARISON_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handleVPCResponse(data.payload.data);
            this.vpcLoaded = true;
          }
        }
      });
      source.addEventListener(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH)) {
          this.receivedEventsList.push(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handleGRFSKResponse(data.payload.data);
          }
        }
      });
      source.addEventListener(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH)) {
          this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH);
          if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            let dataObj = JSON.parse(JSON.stringify(data.payload.data));
            if (dataObj.dataExists) {
              this.hasFeaturedPlans = true;
              this.noOfPlans++;
            }
          } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });
      source.addEventListener(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH)) {
          this.receivedEventsList.push(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH);
          if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            let dataObj = JSON.parse(JSON.stringify(data.payload.data));
            if (dataObj.dataExists) {
              this.hasPortfolioPlans = true;
              this.noOfPlans++;
            }
          } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });
      source.addEventListener(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.receivedEventsList.push(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH);
          if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            let dataObj = JSON.parse(JSON.stringify(data.payload.data));
            if (dataObj.dataExists) {
              this.hasErredPlans = true;
              this.noOfPlans++;
            }
          } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });
      source.addEventListener(CommonConstants.FEATURED_PLAN_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_FETCH)) {
          this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handlePlanData(data.payload.data);
            this.loadFeaturedVisionPlans(data.payload.data);
            this.featuredPlanLoaded = true;
            this.noOfPlansLoadComplete++;
            if (!this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH);
              this.hasFeaturedPlans = true;
              this.noOfPlans++;
            }
            if (this.noOfPlans == this.noOfPlansLoadComplete &&
              this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.allPlansLoaded = true;
            }
          } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });
      source.addEventListener(CommonConstants.PORTFOLIO_PLAN_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_FETCH)) {
          this.receivedEventsList.push(CommonConstants.PORTFOLIO_PLAN_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handlePlanData(data.payload.data);
            this.loadPortFolioVisionPlans(data.payload.data);
            this.portfolioPlanLoaded = true;
            this.noOfPlansLoadComplete++;
            if (!this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH);
              this.hasPortfolioPlans = true;
              this.noOfPlans++;
            }
            if(this.noOfPlans == this.noOfPlansLoadComplete &&
              this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.allPlansLoaded = true;
            }


          } else if(this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if(this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });
      source.addEventListener(CommonConstants.ERROR_PLAN_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.ERROR_PLAN_FETCH)) {
          this.receivedEventsList.push(CommonConstants.ERROR_PLAN_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handlePlanData(data.payload.data);
            this.loadErrordMedicalPlans();
            this.noOfPlansLoadComplete++;
            if (!this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH);
              this.hasErredPlans = true;
              this.noOfPlans++;

            }
            if(this.noOfPlans == this.noOfPlansLoadComplete &&
              this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.allPlansLoaded = true;
            }

          } else if(this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if(this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });
      source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS_COMPLETE, (event: any) => {
        source.close();
        this.initializePlans();
      });

      source.addEventListener('FAILED', (message: any) => {
        source.close();
        console.error("Received fail event", message);
        this.div_visible = false;
      });
      this.div_visible = false;

    }, error => {
      console.error(error);
    });

  }

  onVPCChange(val) {
    this.isVPCChanged = true;
    this.visionPremiumComparison = val;
  }
  onFeaturedPlanRateChange(event) {
    this.visionPremiumComparison = event.visionPremiumComparison;
    this.isChangedFlag = event.isChangedFlag;
    this.myArr = event.myArr;

    // Merge adjustedPlans instead of overwriting to preserve all UW adjustments
    const newAdjustedArr = event.adjustedArr || [];
    const existingPlans = this.adjustedPlans || [];

    // Start with new plans from Featured Plans
    const mergedPlans = [...newAdjustedArr];

    // Add back existing plans that aren't in the new array
    existingPlans.forEach(existingPlan => {
      const alreadyExists = mergedPlans.find(p => p.ratingPlanID === existingPlan.ratingPlanID && p.planName === existingPlan.planName);
      if (!alreadyExists) {
        mergedPlans.push(existingPlan);
      }
    });

    this.adjustedPlans = mergedPlans;
    this.adjustedArr = this.adjustedPlans;
    this.isVPCChanged = true;
  }

  onFactorAdj(event) {
    this.isChangedFlag = event.isChangedFlagFactor;
    this.myArr = event.myArrFactor;
    this.adjustedPlans = event.adjustedPlans
    this.visionPremiumComparison = event.visionPremiumComparison;
  }

    constructRequestForNewBusiness() {
    const newBusinessArr = [];
    this.adjustedPlans = this.adjustedArr;
    if (this.adjustedPlans && this.adjustedPlans.length) {
      for (let i = 0; i < this.adjustedPlans.length; i++) {
        if (this.adjustedPlans[i].uwAdjustment == null) {
          this.adjustedPlans[i].uwAdjustment = 1;
        }
        let adjustedObj = {
          "planName": this.adjustedPlans[i].planName,
          "ratingPlanID": this.adjustedPlans[i]['ratingPlanID'],
          "single": this.adjustedPlans[i]['single']?.toString(),
          "eeSpouse": this.adjustedPlans[i]['eeSpouse']?.toString(),
          "eeChild": this.adjustedPlans[i]['eeChild']?.toString(),
          "eeChildren": this.adjustedPlans[i]['eeChildren']?.toString(),
          "eeOne": this.adjustedPlans[i]['eeOne']?.toString(),
          "family": this.adjustedPlans[i]['family']?.toString(),
          "uwAdjustment": this.adjustedPlans[i].uwAdjustment
        }
        newBusinessArr.push(adjustedObj);
      }
    }

    return newBusinessArr;
  }

  constructRequestForRenewal() {
    this.adjustedArr = [];
    if (this.adjustedPlans.length) {
      for (let i = 0; i < this.adjustedPlans.length; i++) {
        if (this.adjustedPlans[i].uwAdjustment == null) {
          this.adjustedPlans[i].uwAdjustment = 1;
        }
          const matchingPlan = this.rareDataObj.vision.proposedPlans.find(
            p => p.ratingPlanID === this.adjustedPlans[i].ratingPlanID
          );

          if (matchingPlan) {
            let adjustedObj = {
              "planName": this.adjustedPlans[i].planName,
              "ratingPlanID": this.adjustedPlans[i]['ratingPlanID'],
              "single": matchingPlan.initialRates.single,
              "eeSpouse": matchingPlan.initialRates.eeSpouse,
              "eeChild": matchingPlan.initialRates.eeChild,
              "eeChildren": matchingPlan.initialRates.eeChildren,
              "eeOne": matchingPlan.initialRates.eeOne,
              "family": matchingPlan.initialRates.family,
              "uwAdjustment": this.adjustedPlans[i].uwAdjustment
            }
            this.adjustedArr.push(adjustedObj);
          }
      }
    } else {
      for (let i = 0; i < this.rareDataObj.vision.proposedPlans.length; i++) {
          let adjustedObj = {
            "planName": this.rareDataObj.vision.proposedPlans[i]['planBenefits'].planName,
            "ratingPlanID": this.rareDataObj.vision.proposedPlans[i]['ratingPlanID'],
            "single": this.rareDataObj.vision.proposedPlans[i].initialRates.single,
            "eeSpouse": this.rareDataObj.vision.proposedPlans[i].initialRates.eeSpouse,
            "eeChild": this.rareDataObj.vision.proposedPlans[i].initialRates.eeChild,
            "eeChildren": this.rareDataObj.vision.proposedPlans[i].initialRates.eeChildren,
            "eeOne": this.rareDataObj.vision.proposedPlans[i].initialRates.eeOne,
            "family": this.rareDataObj.vision.proposedPlans[i].initialRates.family,
            "uwAdjustment": this.rareDataObj.vision.proposedPlans[i].uwDiscret
          }
         this.adjustedArr.push(adjustedObj);
      }
    }

    return this.adjustedArr;
  }
  loadErrordMedicalPlans(){
    this.erredPlanCount = 0;
    if (this.rareData['vision'] && this.rareData['vision'].proposedPlans) {
      this.rareData['vision'].proposedPlans.forEach(item => {
        if (item.errors && item.errors.metadata) {
          this.errorPlans.push(item);
          this.errorPlanCount++;
          this.erredPlanCount++;
        }
      });
    }
  }
  initializePlans(){
    let planTabs = ['featured', 'portfolio', 'erred'];
     if (planTabs.includes(this.activeTab) && this.activeTab == "featured") {
      this.activeTab = this.hasFeaturedPlans ? 'featured' : this.hasPortfolioPlans ? 'portfolio' : 'erred';
    }
  }
  handleUWResponse(data: any){
    let dataObj = JSON.parse(JSON.stringify(data));
    this.rareData.uwAdjustment = this.commonService.deepCopy(dataObj.uwAdjustment);
    this.InitialRateData.uwAdjustment = this.commonService.deepCopy(dataObj.uwAdjustment);
    this.uwLoaded = true;
    this.handleAdjustments();
    this.reloadChildComponents();
   }

  handleAdjustments() {
    if (this.rareData.uwAdjustment && this.rareData.uwAdjustment.adjustedRates?.length) {
      this.adjustedPlans = this.rareData.uwAdjustment.adjustedRates;
    }
  }

  isNewBusinessLocal(): boolean {
    return StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal);
  }

  loadPortFolioVisionPlans(data){
    this.portfolioPlanCount = 0;
    let dataObj = JSON.parse(JSON.stringify(data));
    this.rareDataObjPortfolio = this.commonService.deepCopy(dataObj);
     this.InitialRateData.vision.proposedPlans = this.commonService.deepCopy(dataObj.vision.proposedPlans);
    this.portfolioPlans = [];
    if (this.rareData['vision'] && this.rareData['vision'].proposedPlans) {
      this.rareData['vision'].proposedPlans.forEach(item => {
       if (item.planTypeRequested == "P") {
        this.portfolioPlans.push(item);
          this.portfolioPlanCount++;
        }
      });
    }
  }
  handlePlanData(data: any){
    let rateData = JSON.parse(JSON.stringify(data));
    if (this.rareData.vision && this.rareData.vision.proposedPlans) {
      let hasRateData = this.rareData.vision.proposedPlans;
      this.rareData.vision.proposedPlans = this.commonService.deepCopy(this.mergeArrays(hasRateData, rateData.vision.proposedPlans));
    } else if( this.rareData.vision){
      this.rareData.vision.proposedPlans = this.commonService.deepCopy(this.mergeArrays([], rateData.vision.proposedPlans));
    }
    if (this.InitialRateData.vision && this.InitialRateData.vision.proposedPlans) {
      let hasInitialRateData = this.InitialRateData.vision.proposedPlans;
      this.InitialRateData.vision.proposedPlans = this.commonService.deepCopy(this.mergeArrays(hasInitialRateData, rateData.vision.proposedPlans));
    } else if( this.rareData.vision){
      this.InitialRateData.vision.proposedPlans = this.commonService.deepCopy(this.mergeArrays([], rateData.vision.proposedPlans));
    }
    this.reloadChildComponents();
  }
  mergeArrays(...arrays) {
    let jointArray = []

    arrays.forEach(array => {
      jointArray = [...jointArray, ...array]
    });
    return [...new Set([...jointArray])]
  }
  mergeRateDataWithAsyncData(data: any){
    Object.keys(data).forEach(key => {
       if(this.rareData[key] !== data[key]){
          this.rareData[key] = this.commonService.deepCopy(data[key]);
       }
       if(this.InitialRateData[key] !== data[key]){
        this.InitialRateData[key] = this.commonService.deepCopy(data[key]);
     }
    });
    this.reloadChildComponents();
  }

  loadFeaturedVisionPlans(data) {
    let dataObj = JSON.parse(JSON.stringify(data));
    if (data)
     this.rareDataObj= this.commonService.deepCopy(dataObj);
      this.visPlans = data.vision.proposedPlans;
      this.InitialFeaturedPlansData = data.vision;
    this.featuredPlans = [];

    this.planLevelFailData = {};
    this.featuredPlanCount = 0;

    if (this.visPlans) {
      this.visPlans.forEach(item => {

          if (item.planTypeRequested == "F") {
            this.featuredPlans.push(item);
            this.featuredPlanCount++;
          }
          if (item.failedGuardRails)
            this.planLevelFailData = this.fetchPlanLevelFailRes(item.failedGuardRails);

      });
    }

    if (this.featuredPlanCount === 0) {
      (this.portfolioPlanCount > 0) ? this.activeTab = 'portfolio' : this.activeTab = 'erred';
    }
  }
  handleGRFSKResponse(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    this.rareData.failedGuardRails = this.commonService.deepCopy(dataObj.failedGuardRails);
    this.InitialRateData.failedGuardRails = this.commonService.deepCopy(dataObj.failedGuardRails);

    this.quotelevelFailData = dataObj.failedGuardRails
      ? this.fetchQuotelevelFailRes(dataObj.failedGuardRails) : '';
    this.reloadChildComponents();
  }

  handleVPCResponse(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    this.rareData.visionPremiumComparison = this.commonService.deepCopy(dataObj.visionPremiumComparison);
    this.visionPremiumComparison = this.commonService.deepCopy(dataObj.visionPremiumComparison);
    this.showVisionPremiumComparison = this.rareData['showVisionPremiumComparison'];
    this.InitialRateData.visionPremiumComparison = this.commonService.deepCopy(dataObj.visionPremiumComparison);
    this.visionPremiumComparison = this.commonService.deepCopy(dataObj.visionPremiumComparison);
    this.reloadChildComponents();
  }
  handleFactorsAndTierLives(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    if (dataObj.factors) {
      this.rareData['factors'] = this.commonService.deepCopy(dataObj.factors);
      this.InitialRateData.factors = this.commonService.deepCopy(dataObj.factors);
    }
    if (dataObj.calculatedTierLives) {
      this.rareData['calculatedTierLives'] = this.commonService.deepCopy(dataObj.calculatedTierLives);
      this.InitialRateData.calculatedTierLives = this.commonService.deepCopy(dataObj.calculatedTierLives);
    }
    if (dataObj.availableTiers) {
      this.rareData['availableTiers'] = this.commonService.deepCopy(dataObj.availableTiers);
      this.InitialRateData.availableTiers = this.commonService.deepCopy(dataObj.availableTiers);
    }
    if (dataObj?.factors?.visTblPeSheetSlcts) {
      this.buildExhibitSheets(this.commonService.deepCopy(dataObj.factors.visTblPeSheetSlcts));
    }
    if (dataObj.factors && dataObj.factors.visionGuardRails)
      this.guardrailBoundaries = this.fectchBoundaries(dataObj.factors.visionGuardRails);
      if (dataObj.calculatedTierLives) {
        if (dataObj.calculatedTierLives.visSplitTierLivesMap) {
          this.EE = dataObj.calculatedTierLives.visSplitTierLivesMap.EE ?
            dataObj.calculatedTierLives.visSplitTierLivesMap.EE : 0;
          this.EF = dataObj.calculatedTierLives.visSplitTierLivesMap.EF ?
            dataObj.calculatedTierLives.visSplitTierLivesMap.EF : 0;
          this.ES = dataObj.calculatedTierLives.visSplitTierLivesMap.ES ?
            dataObj.calculatedTierLives.visSplitTierLivesMap.ES : 0;
          this.EC = dataObj.calculatedTierLives.visSplitTierLivesMap.EC ?
            dataObj.calculatedTierLives.visSplitTierLivesMap.EC : 0;
          this.E1 = dataObj.calculatedTierLives.visSplitTierLivesMap.E1 ?
            dataObj.calculatedTierLives.visSplitTierLivesMap.E1 : 0;
          this.EK = dataObj.calculatedTierLives.visSplitTierLivesMap.EK ?
            dataObj.calculatedTierLives.visSplitTierLivesMap.EK : 0;
        }
      }
    this.reloadChildComponents();
  }
  guardrailBoundariesToQuoteDetails: any = {}
  reloadChildComponents() {
    this.rareData = this.commonService.deepCopy(this.rareData);
    this.InitialRateData = this.commonService.deepCopy(this.InitialRateData);
  }
  checkIfEventRecieved(eventType: string) {
    if (this.receivedEventsList && this.receivedEventsList.includes(eventType))
      return true;
    else
      return false;
  }
  loadPrintExhibitsInfo(callPrintExhibit: boolean, exhibitDocs: any) {
    if (callPrintExhibit) {
      this.commonQuoteService
        .getPrintExhibitInfo(this.transID, "Vision")
        .subscribe(
          response => {
            if (response != null) {
              this.documents = this.prepareUniquePrintExhibitList(response.exhibits);
            }
          },
          error => {
            console.error(error);
          }
        );
    } else {
      this.documents = this.prepareUniquePrintExhibitList(exhibitDocs);
    }
  }
  prepareUniquePrintExhibitList(exhibits): any[] {
    if (exhibits && isArray(exhibits)) {
      exhibits = exhibits.sort(function (a: any, b: any) {
        let dateA: any = new Date(a.submittedTimestamp);
        let dateB: any = new Date(b.submittedTimestamp);
        return dateB - dateA;
      });

      const result = [];
      const map = new Map();
      const peNameRegex = /(\d{4}-\d{2}-\d{2}T)(?!.*\1)/;
      for (const exhibit of exhibits) {
        if (!map.has(exhibit.exhibitDocId)) {
          map.set(exhibit.exhibitDocId, true);
          let name = exhibit.fileName.substring(0, exhibit.fileName.match(peNameRegex).index - 1);
          exhibit['peName'] = name;
          result.push(exhibit);
        }
      }
      return result;
    }
    return exhibits;
  }

  downloadPrintExhibitsFile(contentKey) {
    if (contentKey != null && contentKey != "") {
      contentKey = contentKey.replace("{", "%7B");
      contentKey = contentKey.replace("}", "%7D");
    }
    this.commonQuoteService.getFileFromFilenet(contentKey).subscribe(response => {
      if (response != null) {
        let contentData = response.contentData ? response.contentData : this.noData;
        let contentName = response.contentName ? response.contentName : this.noData;
        const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
        this.peService.createAndDownloadBlobFile(arrayBuffer, contentName);
      } else {
      }
    }, error => {
      console.log(error);
    });
  }

  currentTab: any;
  disableBackBtn: boolean
  ngOnInit() {
    this.exhibitVisionEnabled = this.commonService.getenabledExhibitOverrideVision();
    this.releaseOptions.push({"label": "Initial Release", "value": "initial"})
    // $(document).ready(function() {
    //   let modalContent: any = $(".modal-content");
    //   let modalHeader = $(".modal-body");
    //   let modalDialog = $(".modal-dialog");
    //   modalHeader.addClass("cursor-all-scroll");
    // });
    // $("#myModalRequoteVision").on("shown.bs.modal", function() {
    //   $(this)
    //     .find(".modal-body")
    //     .css({
    //       width: "auto",
    //       height: "auto",
    //       "max-width": "100%"
    //     });
    // });

    this.adjustment_form = this.fb.group({
      uwAdjustmentFactor: ['', [Validators.required]],
      employerRiskFactor: ['', Validators.required],
      salesAdjustmentFactor: ['', [Validators.required]],
      wholeHealthAdjustmentFactor: ['', [Validators.required]],
      outputTier: ['', [Validators.required]],
      uwNotesToSales: ['', Validators.required],
      uwComments: ['', [Validators.required]],
      salesNotetoUW: [''],
      contractEndDate: ['', Validators.required],
      exhibitName: ['', [Validators.required]],
      approvalStatus: ['', [Validators.required]],
      submittedTimestamp: ['', [Validators.required]],
      quoteReason: [''],
    }
    );

    window.scroll(0, 0);


    this.benefitsColSpanE = 10;
    this.isExpandedF = false;
    this.isExpandedP = false;

    this.planColumnsE = this.planColumnsBefore;

    this.route
      .queryParams
      .subscribe(params => {
        this.oppID = params[CommonConstants.OPPORTUNITY_ID];
        this.opportunityID = this.oppID;
        this.transID = params[CommonConstants.RATINGTRANS_ID];
        this.lob1 = params[CommonConstants.LOB];
        this.searchAnywhere = params[CommonConstants.SELECTED_SEARCH_ANYWHERE];
        this.fundingType = params[CommonConstants.FUNDING_TYPE];
        this.quoteHeaderID = params[CommonConstants.QUOTEHEADER_ID];
        this.lob_FT = params[CommonConstants.AVAILABLE_TABS];
        var disableAllBoolean = params[CommonConstants.DISABLE_ALL];
        this.disableBackBtn = params[CommonConstants.DISABLE_BACK_BTN];
        this.quoteOrigin = params[CommonConstants.QUOTE_ORIGIN];
        this.marketSegment = params[CommonConstants.MARKET_SEGMENT];
        if (disableAllBoolean != undefined && disableAllBoolean === 'true') {
          this.disableAll = true;
          this.adjustment_form.disable();
        } else {
          this.disableAll = false;
          this.adjustment_form.enable();
        }
        this.getCurrentTabList();
      });


    this.authService.userRoleTextToDisplay.subscribe(data => {
      if (data.includes('Read Only')) {
        this.isReadOnlyRole = true;
      }

    })

    this.selectedQuoteAction = { action: 'Quote' };
    this.userSelectedTier = '';
    this.loadRateInfo();
    this.loadPrintExhibitsInfo(true, null);
    this.userRole = this.authService.userRole['_value'];
    this.commonService.setOpportunityId(this.oppID);
    this.commonService.setquoteHeaderId(this.quoteHeaderID);
    const myDropdown = this.elRef.nativeElement.querySelector("releaseMouseHover");
    if(myDropdown){
      myDropdown.click();
    }
  }
  getRenDropdownClass() {
    return this.quoteDetailsObj['opportunityType'] == 'Renewal Local' ? 'renewal-bg' : '';
  }
  onMouseFocus(event){
    if(this.multiSelect){
    this.multiSelect.show();
    }
    event.stopPropagation();
  }
  onRelease(event) {
    if (event != null) {
      this.releaseType=this.selectedReleaseOption
    }
  }
  lob_FT: any[];
  onSubmit(form: FormGroup) {


  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  getCurrentTabList() {
    let tabList = this.commonService.getQuoteTabList();

    // Check if a Medical MEWA Renewal original quote exists in this opportunity
    this.checkMEWARenewalOriginalQuoteExists();

    if (tabList && tabList.length) {
      this.currentTab = this.commonService.getCurrentTab(this.transID , this.lob1);
    } else {
      this.commonQuoteService.getOpportunitesByOppID( this.oppID,  this.lob1).subscribe(
        response => {
          if (response != null) {
            let lob_FT = [];
            let lob_FT_TransID = [];
            for (var opp of response.opportunities) {
              if (opp && opp.quoteHeaderID === this.quoteHeaderID) {
                let data = (StringUtils.isEqual(opp.lob, VisionConstants.Medical) && StringUtils.isEqual(opp.opportunityType, VisionConstants.renewalLocal) && (StringUtils.isEqual(opp.quotingType, 'ACA') || StringUtils.isEqual(opp.quotingType, CommonConstants.MEWA))) ? opp.lob + '-'+ opp.quotingType : opp.lob + '-' + opp.fundingType;
                if (opp.marketSegment === this.marketSegment || (this.marketSegment === "undefined" || this.marketSegment === undefined)) {
                  if (!lob_FT.find(x => x === data)) {
                    lob_FT.push(data);
                  }
                  lob_FT_TransID.push({
                    tabName: data,
                    tabStatus: opp.status,
                    ratingTransID: opp.ratingTransID,
                    fundingType: opp.fundingType,
                    quoteOrigin: opp.quoteOrigin
                  });
                }
              }

            }
            this.lob_FT = lob_FT;
            lob_FT_TransID = lob_FT_TransID.filter( id => id.quoteOrigin != QUOTE_ORIGIN.AUTO_RUN_BATCH );
            this.commonService.setQuoteTabList(lob_FT_TransID);
            this.currentTab = this.commonService.getCurrentTab(this.transID, this.lob1);
          }
      });
    }
  }

  navigateToSoldRates() {
    this.router.navigate([CommonConstants.SOLD_RATES_URL], {
      queryParams: {
        ratingTransID: this.transID, opportunityID: this.oppID, quoteOrigin: this.quoteOrigin,
        quoteHeaderID: this.quoteHeaderID, lob: this.lob1, groupName: this.accountName, fundingType: this.fundingType, availableTabs: this.lob_FT,
        state:this.state,
        factorEffectiveDate:this.factorEffectiveDate
      }
    });
  }

  onQDMedical() {
    this.router.navigate(['quote/uw-rate'], {
      queryParams: {
        ratingTransID: this.transID, opportunityID: this.opportunityID, quoteOrigin: this.quoteOrigin,
        quoteHeaderID: this.quoteHeaderID, lob: this.lobMedical, groupName: this.accountName, fundingType: this.fundingType, availableTabs: this.lob_FT
      }
    });
  }

  onNavigateTab(data: string) {
    this.currentTab = data;
    let tabData = data.split("-");
    if (StringUtils.isEqual(tabData[0], VisionConstants.Vision)) {
      this.fundingType = tabData[1];
      this.ratingTransID = this.commonService.getTransIDforTab(tabData[0], tabData[1]);
      this.loadRateInfo();
    }
    if (StringUtils.isEqual(tabData[0], VisionConstants.Medical)) {
      this.router.navigate(['quote/uw-rate'], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]), opportunityID: this.opportunityID, quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1])
          ,quoteHeaderID: this.quoteHeaderID, lob: tabData[0], groupName: this.accountName, fundingType: this.commonService.getFundingTypeforTab(tabData[0], tabData[1]), availableTabs: this.lob_FT, quotingTypeFromTab: tabData[1],
          searchAnywhere: this.searchAnywhere
        }
      });
    }
    if (StringUtils.isEqual(tabData[0], VisionConstants.Dental)) {
      this.router.navigate(["quote/uw-rate-dental"], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
          opportunityID: this.opportunityID,
          quoteHeaderID: this.quoteHeaderID,
          lob: tabData[0],
          groupName: this.accountName,
          fundingType: tabData[1],
          availableTabs: this.lob_FT,
          quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
          searchAnywhere: this.searchAnywhere
        }
      });
    }
    if (StringUtils.isEqual(tabData[0], CommonConstants.SuppHealth)) {
      this.router.navigate(["quote/uw-rate-supplemental-health"], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
          opportunityID: this.opportunityID,
          quoteHeaderID: this.quoteHeaderID,
          lob: tabData[0],
          groupName: this.accountName,
          fundingType: tabData[1],
          availableTabs: this.lob_FT,
          quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
          searchAnywhere: this.searchAnywhere
        }
      });
    }
  }

  backClicked() {
    if(!this.storage.get('QuoteSearchQuery')){
      let searchQuery = {};
      searchQuery['quoteReason'] = this.rareData['quoteReason'] !== 'TEST' ? {"$nin":["TEST"]} : {"$in":["TEST"]};
      searchQuery['alternateQuote'] = this.alternateQuote === true ? { $in: [true, false] } : { $in: [false] };
      searchQuery['opportunityID'] = {"$regex":".*"+this.rareData['opportunityID']+".*"};
      searchQuery['quoteOrigin'] = { $in: ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch'] };
      this.storage.set('QuoteSearchQuery', JSON.stringify(searchQuery));
      this.storage.set('fundingType', "");
      this.storage.set('lob', "");
      this.storage.set('quoteHeaderID', "");
      this.storage.set('quoteOrigin', ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch']);
      this.storage.set('alternateQuote', searchQuery['alternateQuote']);
      this.storage.set('showOpportunities', 'true');
      this.storage.set('opportunityID', this.rareData['opportunityID']);
      this.storage.set('searchAnywhere', this.searchAnywhere);
      this.storage.set('quoteReason', this.rareData['quoteReason'] !== 'TEST' ? false : true);
      this.storage.set('pageLimit', 10);
    }
    this.storage.set('searchAnywhere', this.searchAnywhere);
    this.router.navigate(['/quote']);
  }

  removeFailureMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;

  }

  removeSuccessMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  removeWarningMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }


  clickedFromDate() {
    let element: HTMLElement = document.querySelectorAll('.overridedate .p-inputtext')[0] as HTMLElement;
    element.click();
  }

  createToolTip() {
    return "toolTipDivPlan";
  }

  toolTipData(MedPlan) {
    return VisionUtil.toolTipData(MedPlan);
  }

  getTierRates(visPlan, tierVal) {
    return visPlan.rateInfo[tierVal];
  }

  getCurrentRatio() {
    return this.rareData['vision'].useCurrentCarrierTierRatio ? this.rareData['vision'].useCurrentCarrierTierRatio : '';
  }
  getSelectionStart(o) {
    return o.selectionStart
  }
  isChangedFlag = false;
  myArr = [];

  reqObj = {};
  onApplyAdjustments(action: string) {
    window.scroll(0, 0);
    if (this.hasPEOverrideError) {
      this.alertData = "Please enter Mandatory fields in Exhibit Overrides section\n";
      this.setWarningFlag();
      window.scroll(0, 0);
      return;
    }
    if (
      (StringUtils.isEqual(action, VisionConstants.releaseAction) && (StringUtils.isEqual(this.status, VisionConstants.modifiedStatus) || this.myArr.length > 0) &&
        !this.adjustment_form.value.uwNotesToSales.trim())) {
      this.alertData = "Please enter UW notes to sales";
      this.setWarningFlag();
      return;
    }else {
      this.onSubmitApplyAdjustment(action);
    }
  }

  updatePEOverrideError(isError: boolean) {
    this.hasPEOverrideError = isError;
  }

  listenPrintExhibit(processId: any) {
    if (processId != null && processId != undefined && processId !== '') {
      var source = this.commonService.listenForStreamTrackAndFail(processId);
      this.eventSources.push(source);
      source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
        this.showProgress = true;
        this.progressStyle = "";
        let eventData = JSON.parse(event.data);
        var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
        this.progressPercent = percent;
        this.progressMessage = eventData.message;
      });
      source.addEventListener("SEND_EXHIBIT_TO_UI", (event: any) => {
        this.showProgress = true;
        if (event.data) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.exhibits) {
            this.loadPrintExhibitsInfo(true, this.commonService.deepCopy(data.payload.exhibits));
          }
        }
      });
      source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
        this.showProgress = true;
        source.close();
        this.commonQuoteService.cleanUpSSEEvents(processId);
        let eventData = JSON.parse(message.data);
        this.progressStyle = 'progress-bar-success';
        this.progressPercent = 100;
        this.progressMessage = eventData.message;
        let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
        if (element != undefined) {
          element.click();
        }
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      });
      source.addEventListener('FAILED', (message: any) => {
        this.showProgress = true;
        source.close();
        this.commonQuoteService.cleanUpSSEEvents(processId);
        this.progressStyle = 'progress-bar-danger';
        this.progressPercent = 90;
        this.progressMessage = 'Print exhibit generation or storage to FileNet failed.';
        this.hideProgressBar();
      });
      source.addEventListener('NO_EVENTS', (message: any) => {
        source.close();
      });
    }
  }

  isRenewalQuote: any;
  isRenewalQuoteCheck() {
    if (StringUtils.isEqual(this.rareData.opportunityType, VisionConstants.renewalLocal)) {
      return true;
    } else {
      return false;
    }
  }
  isInitialQuoteUpdate:boolean=false;
  releaseType:string;
  onSubmitApplyAdjustment(action: string) {
    this.div_visible = true;
    if (this.isChangedFlag && this.isRenewalQuoteCheck()) {
      this.adjustedArr = this.constructRequestForRenewal();
    } else if (!this.isRenewalQuoteCheck()) {
      this.adjustedArr = this.constructRequestForNewBusiness();
    }

    this.reqObj = this.contructReqObj();

    // Include off-cycle data for Declined, Lost, Termed, Transfer statuses OR Sold with user input
    CommonUtil.handleOffCycleData(
      this.reqObj,
      this.rareData,
      this.status?.toString() || '',
      action,
      this.offCycleModalService.offCycleSubmittedInCurrentSession,
      'Vision',
      'contractEffectiveDate'
    );

    // Reset flag after offCycle data is added to payload
    this.offCycleModalService.offCycleSubmittedInCurrentSession = false;

    if(StringUtils.isEqual(action, VisionConstants.declineAction)){
      if(typeof(this.processQuoteService.uwNotesToSales) != 'undefined'
      && this.processQuoteService.uwNotesToSales != null && this.processQuoteService.uwNotesToSales != ""){
        if(this.processQuoteService.uwNotesToSales.includes("; ")){
          this.processQuoteService.uwNotesToSales = this.processQuoteService.uwNotesToSales.split("; ").join(";");
        }
        this.processQuoteService.uwNotesToSales = this.processQuoteService.uwNotesToSales.split(";").join("; ");
        this.reqObj['uwAdjustment'].uwNotesToSales = this.processQuoteService.getUwNotesToSales();

        var checkobexsFound = this.processQuoteService.declineOptionsChecked.some(cbs => this.processQuoteService.uwNotesToSales.includes(cbs));

        if(this.processQuoteService.declineOptionsChecked.length === 5 && !checkobexsFound){
          let finalUWNote;
            if(this.processQuoteService.declineOptionsChecked != null && this.processQuoteService.declineOptionsChecked.length > 0){
              this.processQuoteService.declineOptionsChecked.forEach(element=> {
                if(finalUWNote == null){
                   finalUWNote = this.processQuoteService.uwNotesToSales != "" && !this.processQuoteService.uwNotesToSales.includes(element) ? this.processQuoteService.uwNotesToSales +  ';' + element : element;
                }else if(!finalUWNote.includes(element)){
                  finalUWNote = finalUWNote + ';' + element;
                }
              });
            }else{
              finalUWNote = this.processQuoteService.uwNotesToSales;
            }
            if(typeof(finalUWNote) != 'undefined' && finalUWNote.includes("; ")){
              finalUWNote = finalUWNote.split("; ").join(";");
            }
            finalUWNote = finalUWNote.split(";").join("; ");
            this.reqObj['uwAdjustment'].uwNotesToSales = finalUWNote;
        }

      }
      else{
        let noCheckboxesChecked: boolean = true;
        if(this.processQuoteService.declineOptionsChecked != null  && this.processQuoteService.declineOptionsChecked.length > 0){
          noCheckboxesChecked = false;
        }
        if(StringUtils.isEqual(action, VisionConstants.declineAction) && !noCheckboxesChecked){
          let declineChecboxes: any;
          if(this.reqObj['uwAdjustment'].uwNotesToSales != null){
            declineChecboxes = this.reqObj['uwAdjustment'].uwNotesToSales;
          }
          if(this.declineCheckboxes != null){
            if(this.declineCheckboxes.length == 0){
              this.declineCheckboxes = this.processQuoteService.declineOptionsChecked;
            }
            this.declineCheckboxes.forEach(element => {
              if(declineChecboxes == null){
                declineChecboxes = element;
              }else{
                if(!declineChecboxes.includes(element)){
                  declineChecboxes = declineChecboxes != "" && !element.includes(declineChecboxes) ? declineChecboxes +  ';' + element : element;
                }
              }
            });
            if(typeof(declineChecboxes) != 'undefined' && declineChecboxes != null &&
            declineChecboxes.includes("; ")){
              declineChecboxes = declineChecboxes.split("; ").join(";");
            }
            declineChecboxes = declineChecboxes.split(";").join("; ");
            this.reqObj['uwAdjustment'].uwNotesToSales = declineChecboxes;
          }
        }
      }
      let statusReason: any;
      let statusReasonsList: any[] = [];
      this.processQuoteService.declineOptionsValues.subscribe(checkboxesSelected => {
        if(checkboxesSelected != null && checkboxesSelected.length > 0){
          statusReasonsList = checkboxesSelected;
          checkboxesSelected.forEach(element => {
            if(statusReason == null){
              statusReason = element;
            }else{
              if(!statusReason.includes(element)){
                statusReason = statusReason != "" && !element.includes(statusReason) ? statusReason +  ';' + element : element;
              }
            }
          });
        }
        this.statusReasons = statusReason;
      });
      const setQuoteHeaderID = this.reqObj['opportunity'].quoteHeaderID;
      const setFundingType = this.reqObj['opportunity'].fundingType;
      localStorage.setItem("statusReasons"+"_"+setQuoteHeaderID+"_"+"Vision"+"_"+setFundingType, statusReason);
      this.reqObj['uwAdjustment'].statusReasons = statusReasonsList;
    }else{
      let statusReasonsToList: any[] = [];
      if(action == 'save' || action == 'release'){
        if(typeof(this.reqObj['uwAdjustment'].uwNotesToSales) != 'undefined' && this.reqObj['uwAdjustment'].uwNotesToSales != null && this.reqObj['uwAdjustment'].uwNotesToSales.includes(";")){
          this.reqObj['uwAdjustment'].uwNotesToSales = CommonUtil.htmlEntitiesToString(this.reqObj['uwAdjustment'].uwNotesToSales);
          if(typeof(this.reqObj['uwAdjustment'].uwNotesToSales) != 'undefined' && this.reqObj['uwAdjustment'].uwNotesToSales.includes("; ")){
            this.reqObj['uwAdjustment'].uwNotesToSales = this.reqObj['uwAdjustment'].uwNotesToSales.split("; ").join(";");
          }
          this.reqObj['uwAdjustment'].uwNotesToSales = this.reqObj['uwAdjustment'].uwNotesToSales.split(";").join("; ");
          this.reqObj['uwAdjustment'].uwNotesToSales = CommonUtil.convertSpecialCharToASCII(this.reqObj['uwAdjustment'].uwNotesToSales);
        }
        if(typeof(localStorage.getItem("statusReasons"+"_"+this.reqObj['opportunity'].quoteHeaderID+"_"+"Vision"+"_"+this.reqObj['opportunity'].fundingType)) != 'undefined' &&
        localStorage.getItem("statusReasons"+"_"+this.reqObj['opportunity'].quoteHeaderID+"_"+"Vision"+"_"+this.reqObj['opportunity'].fundingType) != null &&
        localStorage.getItem("statusReasons"+"_"+this.reqObj['opportunity'].quoteHeaderID+"_"+"Vision"+"_"+this.reqObj['opportunity'].fundingType).includes(";")){
          this.reqObj['uwAdjustment'].statusReasons = localStorage.getItem("statusReasons"+"_"+this.reqObj['opportunity'].quoteHeaderID+"_"+"Vision"+"_"+this.reqObj['opportunity'].fundingType).split(";");
        }else{
          if(localStorage.getItem("statusReasons"+"_"+this.reqObj['opportunity'].quoteHeaderID+"_"+"Vision"+"_"+this.reqObj['opportunity'].fundingType) != 'undefined' &&
          localStorage.getItem("statusReasons"+"_"+this.reqObj['opportunity'].quoteHeaderID+"_"+"Vision"+"_"+this.reqObj['opportunity'].fundingType) != null){
            statusReasonsToList.push(localStorage.getItem("statusReasons"+"_"+this.reqObj['opportunity'].quoteHeaderID+"_"+"Vision"+"_"+this.reqObj['opportunity'].fundingType));
            this.reqObj['uwAdjustment'].statusReasons = statusReasonsToList;
          }
        }
      }
    }

    if (this.exhibitVisionEnabled || (this.rareData['uwAdjustment'] && this.rareData['uwAdjustment']?.peOverrideData)) {
      let peOverrideDataChangeset: any = this.uwChangeSetService.getPEOverrideDataChangeSetDetails(this.rareData, this.InitialRateData, this.exhibitVision);
      if (peOverrideDataChangeset?.peOverrideValue) {
        this.rareData.uwAdjustment.peOverrideData.printExhibitEligibility = peOverrideDataChangeset.peOverrideValue.printExhibitEligibility;
        this.reqObj['uwAdjustment'].peOverrideData = this.rareData.uwAdjustment.peOverrideData;
      } else {
        this.reqObj['uwAdjustment'].peOverrideData = null;
      }
      this.reqObj['uwChangesetAdjustmentData'] = peOverrideDataChangeset?.changesetDetail;
    }

    if (StringUtils.isEqual(action, VisionConstants.declineAction) && (!this.reqObj['uwAdjustment'].uwNotesToSales)) {
      this.alertData = "Please enter UW notes to sales";
      this.setWarningFlag();
      return;
    }

    this.reqObj['uwAdjustment'].action = action;
    this.reqObj['opportunity'].quoteOrigin = this.quoteOrigin;
    if (StringUtils.isEqual(this.rareData.opportunityType, VisionConstants.renewalLocal)) {
      this.reqObj['opportunity'].opportunityType = VisionConstants.renewalLocal;
    } else {
      this.reqObj['opportunity'].opportunityType = VisionConstants.newBusinessLocal;
    }

    var useRouterLogic = this.commonQuoteService.useRouterLogicToProcess(action);
    if (this.releaseType != undefined && this.releaseType.length > 0) {
      this.isInitialQuoteUpdate = true;
    }
    else {
      this.isInitialQuoteUpdate = false;
    }
    this.commonQuoteService.onReleaseVisionQuote(this.metaTransID, this.metaSenderApp, this.transID, this.reqObj, action, useRouterLogic ,this.isInitialQuoteUpdate)
      .subscribe(
        (response: any) => {

          if (response.status === 200) {
            this.isVPCChanged = false;
            this.isChangedFlag = false;
            this.receivedEventsList = [];
            this.declineQuoteBool=false;
              setTimeout(() => {
                this.declineQuoteBool=true;
            });
            // After successful save, refresh adjustment history
            if (this.AdjustmentsVisionComponent) {
              this.AdjustmentsVisionComponent.resetAdjustmentHistoryFlag();
              this.AdjustmentsVisionComponent.adjustmentHistoryClicked();
            }
            if (StringUtils.isEqual(action, VisionConstants.releaseAction)) {
              this.processId = response.body.processId;
              if (undefined != this.processId) {
                this.clearPreviousAlerts();
                this.showProgress = true;
                this.progressPercent = 1;
                this.progressStyle = "progress-bar-warning";
                var source = this.commonService.listenForStream(this.processId);
                this.eventSources.push(source);

                source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener("ISOLATE_UWACTION_STATUS", (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener("SEND_EXHIBIT_TO_UI", (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener("VIS_SEND_EXHIBIT_TO_UI", (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);
                });

                source.addEventListener('ISOLATE_UWACTION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);
                  this.loadRateInfo();
                });

                source.addEventListener('FAILED', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processFailedEvent();
                });
              } else {
                //for direct release without PE
                this.processOthersAction(action);
              }
            } else {
              //for scenarios other than release
              this.processOthersAction(action);
              this.loadRateInfo();
            }
          } else {
            this.processErrorResponse(this.getErrorResponse(action));
          }
        },
        error => {
          this.loadRateInfo();
          this.processErrorResponse("System Error");
        }
      );
  }

  processDefaultEvents(event: any) {
    this.progressStyle = "";
    let eventData = JSON.parse(event.data);
    var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
    this.progressPercent = percent;
    this.progressMessage = eventData.message;
  }

  processExhibitDocsEvents(event: any){
    if (event.data) {
      let data = JSON.parse(event.data);
      if (data.payload && data.payload.exhibits) {
        this.loadPrintExhibitsInfo(false, this.commonService.deepCopy(data.payload.exhibits));
      }
    }
  }

  processEventComplete(message: any){
    let eventData = JSON.parse(message.data);
    this.progressStyle = "progress-bar-success";
    this.progressPercent = 100;
    this.progressMessage = eventData.message;
    this.loadPrintExhibitsInfo(true, null);
      let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
      element.click();
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
    this.loadRateInfo();
  }

  processFailedEvent(){
    this.progressStyle = "progress-bar-danger";
    this.progressMessage = "Print exhibit generation or storage to FileNet failed.";
    this.hideProgressBar();
  }

  processOthersAction(action: string){
    this.alertData = this.getSuccessResponse(action);
    this.setSuccessFlag();
  }

  processErrorResponse(errorResponse: string){
    this.alertData = errorResponse;
    this.setFailureFlag();
  }

  setWarningFlag() {
    this.div_visible = false;
    this.warningMessage = true;
    this.successMessage = false;
    this.failureMessage = false;
  }
  setSuccessFlag() {
    this.div_visible = false;
    this.successMessage = true;
    this.failureMessage = false;
    this.warningMessage = false;
  }
  setFailureFlag() {
    this.div_visible = false;
    this.failureMessage = true;
    this.successMessage = false;
    this.warningMessage = false;
  }

  clearPreviousAlerts() {
    this.div_visible = false;
    this.alertData = "";
    this.removeSuccessMsg();
    this.warningMessage = false;
  }

  getSuccessResponse(action: string) {
    switch (action) {
      case "release":
        return "Quote Released Successfully";
      case "decline":
        return "Quote Declined Successfully";
      case "requote":
        return "Submitted for ReQuote Successfully";
      default:
        return "Changes are saved successfully";
    }
  }

  getErrorResponse(action: string) {
    switch (action) {
      case "release":
        return "Error Releasing the Quote";
      case "decline":
        return "Error Declining the Quote";
      default:
        return "Error in getting response for Underwriter Adjustment";
    }
  }

  onDecline(declineReasons){
    this.declineReasons = declineReasons;
  }

  declineReaonsToBeChecked(declineReasons){
    this.declineCheckboxes = declineReasons;
  }



  onGeneratePrintExhibit() {
    this.disableprint = true;
    this.reqObj = this.contructReqObj();
    let openPEDropdown = false;
    this.commonQuoteService.generatePrintExhibit(this.reqObj, this.metaTransID, this.transID, this.quoteErrorCode).subscribe(
      (response) => {
        if (response.status === 200) {
          this.processId = response.body.processId;
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = "progress-bar-warning";
          var source = this.commonService.listenForStream(this.processId);
          this.eventSources.push(source);
          source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
            this.progressStyle = "";
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
          });
          source.addEventListener("SEND_EXHIBIT_TO_UI", (event: any) => {
            if (event.data) {
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.exhibits) {
                openPEDropdown = true;
                this.loadPrintExhibitsInfo(false, this.commonService.deepCopy(data.payload.exhibits));
              }
            }
          });
          source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
            source.close();
            this.commonQuoteService.cleanUpSSEEvents(this.processId);
            let eventData = JSON.parse(message.data);
            this.progressStyle = "progress-bar-success";
            this.progressPercent = 100;
            this.progressMessage = eventData.message;
            let contentData = eventData.payload.contentData;
            let contentName = eventData.payload.contentName;
            if (eventData.payload.contentMetadata) {
              contentName = eventData.payload.contentMetadata[0].value;
            }
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
            let isXLSX;
            if (contentName.includes('.xlsx'))
              isXLSX = "";
            else isXLSX = ".xlsx";
            this.peService.createAndDownloadBlobFile(arrayBuffer, contentName + isXLSX);

            this.disableprint = false;
            if (openPEDropdown) {
              let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
              element.click();
            }
            setTimeout(() => {
              this.showProgress = false;
              if (this.quoteErrorCode == 'E1403')
                this.loadRateInfo();
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener('FAILED', (message: any) => {
            source.close();
            this.commonQuoteService.cleanUpSSEEvents(this.processId);
            let eventData = JSON.parse(message.data);
            this.progressStyle = "progress-bar-danger";
            this.progressMessage = "Print exhibit generation or storage to FileNet failed.";
            this.hideProgressBar();
          });
        }

      },
      error => {
        this.disableprint = false;
        alert("Error while generating print exhibit");
      }
    );
  }

  contructReqObj() {
    let adjArr = [];
    adjArr = this.adjustedArr;
    let vpc;
    if (adjArr.length > 0 || this.isVPCChanged) {
      vpc = this.visionPremiumComparison;
    } else {
      vpc = null;
    }
    let reqObj = {
      "opportunity": {
        "opportunityID": this.rareData['opportunityID'],
        "quoteHeaderID": this.rareData['quoteHeaderID'],
        "lob": "Vision",
        "fundingType": "FI",
        "accountName": this.rareData['accountName'],
        "previousOutputTier": this.reqTier,
        "quotingType": this.rareData.quotingType,
        "ratingTransID": this.transID
      },
      "uwAdjustment": {
        "ratingTransID": this.transID,
        "action": "ADJUST",
        "adjustedRates": adjArr,
        "visionPremiumComparision": vpc,
        "outputTier": this.reqTier,
        "uwNotesToSales": this.adjustment_form.value.uwNotesToSales=='' ? null :this.adjustment_form.value.uwNotesToSales,
        "statusReasons": [],
        "uwComments": this.adjustment_form.value.uwComments=='' ? null :this.adjustment_form.value.uwComments,
        "salesNoteToUW": this.adjustment_form.value.salesNotetoUW,
        "assignedUWName": this.rareData['underwriterName'] ? this.rareData['underwriterName'] : '',
        "status": this.rareData.status,
        "vision": true
      },
      "quoteReason": this.addQuote()
    }
    return reqObj;
  }
  addQuote() {
    let quoteReason = this.adjustment_form.value.quoteReason;
    if (!quoteReason) {
      quoteReason = 'REAL';
    } else {
      quoteReason = 'TEST';
    }
    return quoteReason;
  }

  onScroll(event) {
    this.scrollTop = event.target.scrollTop
  }

  quotelevelFailData: any;
  fetchQuotelevelFailRes(array) {
    let filteredEleList = {};
    array.map((ele) => {
      let guardrailRepRes = ele.split('.');
      if (guardrailRepRes.length === 1) {
        filteredEleList[(guardrailRepRes[0])] = 1;
      }
      else {
        filteredEleList[guardrailRepRes[guardrailRepRes.length - 1]] = 1;
      }
    })
    return filteredEleList;
  }
  planLevelFailData: any;
  fetchPlanLevelFailRes(array) {
    let filteredEleList = {};
    array.map((ele) => {
      let guardrailRepRes = ele.split('.');
      if (guardrailRepRes.length === 1) {
        filteredEleList[(guardrailRepRes[0])] = 1;
      }
      else {
        filteredEleList[guardrailRepRes[guardrailRepRes.length - 1]] = 1;
        return filteredEleList;
      }
    })

  }

  markGuardRailFailuresQuoteLevel(guardRail) {
    if (this.quotelevelFailData && this.quotelevelFailData[guardRail]) {
      return "toolTipDiv";
    } else { return false; }
  }
  markGuardRailFailuresPlanLevel(guardRail, visPlan) {
   return VisionUtil.markGuardRailFailuresPlanLevel(guardRail, visPlan)
  }

  boundariesObjName = {}
  fectchBoundaries(guardRailsList) {
    let boundariesObj = {};
    guardRailsList.map((guardrailObj) => {
      if (StringUtils.isEqual(guardrailObj.guardName, 'Premium Guard Rail')) {
        boundariesObj[guardrailObj.guardName] = '$' + guardrailObj.minVal + ' - ' + '$' + guardrailObj.maxVal;
      } else {
        boundariesObj[guardrailObj.guardName] = guardrailObj.minVal + ' - ' + guardrailObj.maxVal;
        let obj = {
          minVal: guardrailObj.minVal,
          maxVal: guardrailObj.maxVal
        }
        this.boundariesObjName[guardrailObj.guardName] = obj;
        this.guardrailBoundariesToQuoteDetails = this.boundariesObjName;
      }
      return boundariesObj;
    })
    boundariesObj['state'] = this.state;
    return boundariesObj;
  }


  downLoadCensus() {
    this.commonQuoteService.downLoadCensus(this.censusID, this.lob, this.quoteHeaderID, this.opportunityType, this.rareData?.['groupNbr']);
  }
  isTabDisabled(tabName: String) {
    return this.commonQuoteService.shouldDisableTab(tabName);
  }
  isRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
    this.isRenewalQuote = this.rareData.opportunityType;
    if (StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
      return false;
    } else if (StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
      return true;
    } else if (StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal)) {
      return false;
    }
  }
}
  isSGRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
      this.isRenewalQuote = this.rareData.opportunityType;
      if (StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
        return true;
      }
      else {
        return false
      }
    }
  }

  onRequote(action) {
    this.reqObj = this.contructReqObj();
    this.reqObj['opportunity']['factorEffectiveDate'] = this.rareData.factorEffectiveDate ? this.rareData.factorEffectiveDate : '';
    this.reqObj["requestedScoreVersion"] = "NOT REQUESTED";
    this.accountName = 'Loading';
    this.commonQuoteService.onSpecialtyRequote(this.reqObj, this.metaTransID, this.transID, action).subscribe((response : any) => {
      if (response.status == 200) {
        this.accountName = this.rareData['accountName'];
        this.backClicked();
      }
    }, error => {
      this.failureMessage = true;
      this.alertData = this.commonQuoteService.specialtyRequoteErr;
      this.accountName = this.rareData['accountName'];
    })
  }
  isAutoQuote() {
    if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.smallGroup)) {
      return true;
    }
  }

  isNBLGAutoQuote() {
    if (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, VisionConstants.largeGroup) && this.rareData?.vision?.oppOrigin?.['altMarket']) {
      return true;
    }
    else {
      return false;
    }
  }

  checkRenewalBg(): boolean {
    return (this.rareData && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal));
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  disableAdjButton() {
    return this.disableAll || this.isReadOnlyRole || this.status == 'Failed' || this.isAutoQuote() || this.isNBLGAutoQuote()
  }

  buildExhibitSheets(exhibitSheetsData) {
    this.exhibitVision = [];
    exhibitSheetsData.forEach(exhibitSheetData => {
      let exhibitSheet: any = {};
      exhibitSheet.printExhibitTypeCode = exhibitSheetData.sheetCd;
      exhibitSheet.printExhibitSheetName = exhibitSheetData.sheetNm;
      exhibitSheet.sheetStatus = exhibitSheetData.dfltIncl === 'Y' ? 'Include' : 'Exclude';
      this.exhibitVision.push(exhibitSheet);
    });
  }

  private checkMEWARenewalOriginalQuoteExists(): void {
    this.commonQuoteService.getOpportunitesByOppID(this.oppID, this.lob1).subscribe(
      response => {
        if (response != null) {
          this.isMEWARenOGQuote = response.opportunities.some((opp: any) =>
            opp.lob === VisionConstants.Medical &&
            opp.quotingType === CommonConstants.MEWA &&
            opp.opportunityType === VisionConstants.renewalLocal &&
            opp.quoteHeaderID === this.quoteHeaderID &&
            !opp.alternateQuote
          );
        }
    });
  }

  // Off-Cycle functionality
  @ViewChild(OffCycleModalComponent, { static: false }) offCycleModalComponent!: OffCycleModalComponent;

  onOffCycleOpen() {
    const modalElements = this.offCycleModalComponent?.getModalElements();
    if (modalElements) {
      this.offCycleModalService.onOffCycleOpen(this.rareData, modalElements, CommonConstants.Vision);
    }
  }

  onOffCycleReasonChange() {
    this.offCycleModalService.onOffCycleReasonChange();
  }

  setDefaultOffCycleDate() {
    this.offCycleModalService.setDefaultOffCycleDate();
  }

  clickOffCycleDate() {
    this.offCycleModalService.clickOffCycleDate();
  }

  onOffCycleConfirm() {
    const success = this.offCycleModalService.onOffCycleConfirm(this.rareData, 'Vision');
    if (success) {
      this.successMessage = true;
      this.alertData = 'Off-Cycle contract end date has been updated successfully.';
      this.onApplyAdjustments('save');
    }
  }

  isContractStarted(): boolean {
    return this.offCycleModalService.isContractStarted(this.rareData?.['contractEffectiveDate']);
  }

  isSold(): boolean {
    return this.offCycleModalService.isSold(this.status?.toString() || '');
  }

  shouldShowOffCycleButton(): boolean {
    return this.offCycleModalService.shouldShowOffCycleButton(
      this.rareData?.['contractEffectiveDate'], 
      this.status?.toString() || '', 
      CommonConstants.Vision,
      this.rareData?.opportunityType
    );
  }
}
