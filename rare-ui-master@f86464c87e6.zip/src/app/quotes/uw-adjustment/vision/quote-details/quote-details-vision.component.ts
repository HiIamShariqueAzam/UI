import { Component, Input, OnChanges, OnInit, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormGroupDirective } from '@angular/forms';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { firstValueFrom } from 'rxjs';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { VisionConstants } from '../vision.constants';
import { VisionUtil } from '../vision.util';
import { QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
@Component({
  selector: 'app-quote-details-vision',
  templateUrl: './quote-details-vision.component.html',
  styleUrls: ['./quote-details-vision.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal],
  encapsulation: ViewEncapsulation.Emulated
})
export class QuoteDetailsVisionComponent implements OnInit, OnChanges {
  @Input() quoteDetailsObj;
  @Input() userRole;
  @Input() disableAll;
  @Input() boundariesObjName;
  @Input() featuredPlans;
  @Input() vpc1;
  @Input() quotelevelFailData;
  @Input() initializeQuote;
  @Input() guardrailBoundariesToQuoteDetails;
  @Input() oldQuotesData;
  @Input() rareData;
  @Input() statusReasons: any;
  @Input() isFileUpload;

  form: FormGroup;
  public isCollapsed = false;
  supportingDocLinks: any;
  urlData: any;
  opportunityType: string;
  marketSegment: string;
  quoteOrigin: string;
  quotingType: string;
  oppTypeToDisplay: string;
  readonly quoteOriginConstants = QUOTE_ORIGIN;
  showProgress = false;
  progressStyle;
  progressMessage;
  progressPercent;
  isSentToOpportunity: boolean = false;
  isUnifiedPayloadSubmission: boolean = false;
  ratingTransId;
  showSpecialitySendToOpp: boolean = false;
  lobFundingTypeMapForSendToOpp = this.commonService.getEnableSendToOppMap();
  peOverrideData: any;
  uwAdjustmentData: any;
  rateGuaranteeMonths: any;
  actualMbrCount: number = 0;
  groupNumber: any;

  constructor(
    private commonService: CommonService,
    private rootFormGroup: FormGroupDirective,
    private authService: AuthenticationService,
    private commonQuoteService: CommonQuoteService,
    private route: ActivatedRoute,
    private router: Router
  ) {
     this.showSpecialitySendToOpp = this.commonService.getRareSpecialitySendToOppEnabled();
  }

  ngOnChanges(changes: SimpleChanges) {
    if ((changes.quoteDetailsObj && !changes.quoteDetailsObj.firstChange) || (changes.oldQuotesData && !changes.oldQuotesData.firstChange)) {
      this.handleRateInitialResponse();
      this.oldQuotesData = this.oldQuotesData;
      // this.quoteDetailsObj.totEligibleEmp = this.quoteDetailsObj.totGroupSize - this.quoteDetailsObj.waivers
    }
    if (changes.guardrailBoundariesToQuoteDetails && !changes.guardrailBoundariesToQuoteDetails.firstChange) {
      this.handleRateInitialResponse();
    }
    if (changes.quotelevelFailData && !changes.quotelevelFailData.firstChange) {
      this.handleRateInitialResponse();
    }
    if (changes.boundariesObjName && !changes.boundariesObjName.firstChange) {
      this.handleRateInitialResponse();
      this.boundariesObjName = this.boundariesObjName;
    }

    if (changes.rareData && !changes.rareData.firstChange) {
      this.rareData = this.rareData;
      this.uwAdjustmentData = this.rareData['uwAdjustment'];
      if (this.uwAdjustmentData && this.uwAdjustmentData['peOverrideData']) {
        this.peOverrideData = this.uwAdjustmentData['peOverrideData'];
        this.peOverrideData.rateGuaranteeMonths = this.calculateOverriddenRateGuaranteeMonths(this.peOverrideData);
      }
    }
  }
  rateGuarenteeEffDate: any;
  rateGuarenteeEndDate: any;

  ngOnInit() {
   
    this.route.queryParamMap
      .subscribe((params) => {
        this.ratingTransId = params.get('ratingTransID');
      })
      .unsubscribe();

    this.form = this.rootFormGroup.control;
    this.opportunityType = this.rareData.opportunityType;
    this.oppTypeToDisplay = this.rareData.opportunityType.replace(' Local', '');
    this.marketSegment = this.rareData.marketSegment;
    this.quoteOrigin = this.rareData.quoteOrigin;
    this.quotingType = this.rareData.quotingType;
    this.groupNumber = this.rareData["groupNbr"];
    if (this.rareData?.censusCalc?.censusMember) {
      this.actualMbrCount = this.rareData?.censusCalc?.censusMember?.censusCount ? this.rareData?.censusCalc?.censusMember?.censusCount : 0;
    }
    this.rateGuaranteeMonths = this.rareData["vision"]["rateGuaranteeMonths"];
    if (this.rareData && this.rareData.vision && StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal)) {
      this.rateGuarenteeEffDate = this.rareData.vision.guaranteeEffectiveDate;
      this.rateGuarenteeEndDate = this.rareData.vision.guaranteeEndDate;
    }
    if (this.uwAdjustmentData && this.uwAdjustmentData['peOverrideData']) {
      this.peOverrideData = this.uwAdjustmentData['peOverrideData'];
      this.peOverrideData.rateGuaranteeMonths = this.calculateOverriddenRateGuaranteeMonths(this.peOverrideData);
    }

    this.getIsSentToOpportunity();
    this.handleRateInitialResponse();
    this.getQuoteHistoryData();
  }

  calculateOverriddenRateGuaranteeMonths(peOverrideData) {
    if (peOverrideData.rateGuaranteeEffectiveDate || peOverrideData.rateGuaranteeEndDate) {
      return this.commonQuoteService.calculateRateGuaranteeMonths(new Date(peOverrideData.rateGuaranteeEffectiveDate), new Date(peOverrideData.rateGuaranteeEndDate));
    } else {
      return null;
    }
  }

  isOverridden(original, overridden) {
    return !StringUtils.isEqual(String(original), String(overridden));
  }

  checkUserRole() {
    if (this.userRole.includes('ADMIN') || this.userRole.includes('READONLY') || this.userRole.includes('UNDERWRITER') || this.userRole.includes('RENEWALBATCH')) {
      return true;
    } else if (this.userRole.includes('ADMIN') && !this.userRole.includes('READONLY')) {
      return false;
    }
  }
  handleRateInitialResponse() {
    let quoteReason = this.rareData['quoteReason'];
    if (quoteReason == 'TEST') {
      this.form.controls.quoteReason.setValue(true);
    } else {
      this.form.controls.quoteReason.setValue(false);
    }
    this.authService.userRoleTextToDisplay.subscribe((data) => {
      if (data.includes('Read Only')) {
        this.form.controls.quoteReason.disable();
      }
    });
    this.supportingDocLinks = this.rareData.supportingDocLinks;
    this.quoteDetailsObj = {
      censusID: this.quoteDetailsObj.censusID,
      accountName: this.quoteDetailsObj.accountName,
      opportunityID: this.quoteDetailsObj.oppID,
      state: this.quoteDetailsObj.state,
      address1: this.quoteDetailsObj.address1,
      address2: this.quoteDetailsObj.address2,
      compZipcode: this.quoteDetailsObj.compZipcode,
      county: this.quoteDetailsObj.county,
      fundingType: this.quoteDetailsObj.fundingType,
      virginGroup: this.quoteDetailsObj.virginGroup,
      experienceIncluded: this.quoteDetailsObj.experienceIncluded,
      salesRepName: this.quoteDetailsObj.salesRepName,
      salesContactNo: this.quoteDetailsObj.salesContactNo,
      factorEffectiveDate: this.quoteDetailsObj.factorEffectiveDate,
      contractStartDate: this.quoteDetailsObj.contractStartDate,
      rateGuaranteeMonths: this.quoteDetailsObj.rateGuaranteeMonths,
      visionInputTier: this.quoteDetailsObj.visionInputTier,
      reqTier: this.quoteDetailsObj.reqTier,
      quotedSubs: this.quoteDetailsObj.quotedSubs,
      waivers: this.quoteDetailsObj.waivers,
      totEligibleEmp: this.quoteDetailsObj.totEligibleEmp,
      status: this.quoteDetailsObj.status,
      quoteHeaderID: this.quoteDetailsObj.quoteHeaderID,
      lob1: this.quoteDetailsObj.lob1,
      oppID: this.quoteDetailsObj.oppID,
      alternateQuote: this.quoteDetailsObj.alternateQuote,
      quotelevelFailData: this.quotelevelFailData,
      boundariesObjName: this.guardrailBoundariesToQuoteDetails,
      quoteHeaderIDURL: 'https://commercial.my.salesforce.com/?ec=302&startURL=%2Flightning%2Fr%2F0064N00000dNuCuQAK%2Frelated%2FCombinedAttachments%2Fview'
    };
    this.urlData = this.getCOM2url();
    if (
      typeof localStorage.getItem('statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + 'Vision' + '_' + this.quoteDetailsObj.fundingType) !=
        'undefined' &&
      localStorage.getItem('statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + 'Vision' + '_' + this.quoteDetailsObj.fundingType) != null
    ) {
      let statusReasons: any;
      if (
        localStorage.getItem('statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + 'Vision' + '_' + this.quoteDetailsObj.fundingType).includes(';')
      ) {
        if (
          localStorage
            .getItem('statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + 'Vision' + '_' + this.quoteDetailsObj.fundingType)
            .includes('; ')
        ) {
          statusReasons = localStorage
            .getItem('statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + 'Vision' + '_' + this.quoteDetailsObj.fundingType)
            .split('; ')
            .join(';');
        }
        statusReasons = localStorage
          .getItem('statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + 'Vision' + '_' + this.quoteDetailsObj.fundingType)
          .split(';')
          .join('; ');
      } else {
        statusReasons = localStorage.getItem(
          'statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + 'Vision' + '_' + this.quoteDetailsObj.fundingType
        );
      }
      this.statusReasons = 'Decline Reasons: ' + statusReasons;
    }
  }
  getCOM2url(): any {
    let supportingDocLinksKeywords = this.commonService.getSupportingDocLinksKeywords();
    return CommonUtil.getCOM2url(this.supportingDocLinks, supportingDocLinksKeywords);
  }
  // Evaluate the guardrail failure at quote level
  markGuardRailFailuresQuoteLevel(guardRail) {
    if (this.quotelevelFailData && this.quotelevelFailData[guardRail]) {
      return 'toolTipDiv';
    } else {
      return false;
    }
  }

  // Displaying the guardrail message
  displayErrorMessage(eleID) {
    if (Object.keys(this.boundariesObjName).length !== 0) {
      return VisionUtil.displayGuardrailErrorMessage(eleID, this.boundariesObjName);
    }
  }
  // Check if the quote is renewal local
  isRenewalQuoteDisabled() {
    if (this.rareData) {
      return StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal);
    }
  }
  // Downloading the census
  downLoadCensus() {
    this.commonQuoteService.downLoadCensus(
      this.rareData['censusRefId'],
      this.quoteDetailsObj.lob1,
      this.quoteDetailsObj.quoteHeaderID,
      this.rareData['opportunityType'],
      this.groupNumber
    );
  }
  stringConversion(value) {
    return StringUtils.convertToString(value);
  }

  getAccName() {
    if (this.quoteDetailsObj['accountName']) {
      return this.quoteDetailsObj['accountName'];
    }
  }

  getAddrOne() {
    if (this.quoteDetailsObj['address1']) {
      return this.quoteDetailsObj['address1'];
    }
  }

  getAddrTwo() {
    if (this.quoteDetailsObj['address2']) {
      return this.quoteDetailsObj['address2'];
    }
  }

  openOpp() {
    const url = '/opportunity/create-opportunity-new';
    if (url) {
      const pathToNavigate = '/opportunity/create-opportunity-new';
      const url = this.router.serializeUrl(
        this.router.createUrlTree([pathToNavigate], {
          queryParams: {
            opportunityID: this.quoteDetailsObj.opportunityID
          }
        })
      );
      localStorage.setItem('quoteHeaderID', this.quoteDetailsObj.quoteHeaderID);
      localStorage.setItem('opportunityID', this.quoteDetailsObj.opportunityID);
      localStorage.setItem('isLoginAgain', 'true');
      localStorage.setItem('assignedUserRoles', this.authService.getUserRole());
      localStorage.setItem('assignedUserRolesTextToDisplay', this.authService.getUserRoleTextToDisplay());
      localStorage.setItem('sendToOpp', 'true');
      localStorage.setItem('assignedUserLobs', this.authService.getUserLob());
      localStorage.setItem('assignedUserStates', this.authService.getUserState());
      localStorage.setItem('disableAll', 'false');
      window.open(url, '_blank');
    } else {
      alert("Opportunity Details doesn't exist");
    }
  }

  disableCensusDownload() {
    // Check census privilege only for renewals - if no privilege, disable download
    const isRenewal = StringUtils.isEqual(this.opportunityType, VisionConstants.renewalLocal);
    if (isRenewal) {
      const hasCensusPrivilege = this.authService.isCensusPrivilegedUser(this.commonService.getAssignedUserGroup());
      if (!hasCensusPrivilege) {
        return true;
      }
    }

    if(this.marketSegment === 'LG'&& this.quoteDetailsObj?.quotedSubs > 0 && !this.isFileUpload) {
      return false;
    } else if (this.marketSegment === 'LG' && isRenewal && !this.quoteDetailsObj?.alternateQuote) {
      return true;
    }
    return false;
  }

  sendToOppClicked() {
    this.showProgress = false;
    this.progressPercent = 20;
    this.progressStyle = 'progress-bar-warning';
    let quoteSelectorDetails = {
      quoteHeaderID: this.quoteDetailsObj.quoteHeaderID,
      lob: this.quoteDetailsObj.lob1,
      fundingType: this.quoteDetailsObj.fundingType
    }
    
    if(!this.quoteDetailsObj.alternateQuote) {
      quoteSelectorDetails = null
    }

    this.commonQuoteService
      .sendToOpportunitiesQuote(this.quoteDetailsObj.opportunityID, this.quoteDetailsObj.lob1, this.quoteDetailsObj.fundingType, this.ratingTransId, quoteSelectorDetails)
      .subscribe(
        (apiResponse) => {
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = 'progress-bar-warning';
          const apiStatus = apiResponse.data.status;
          if (apiStatus.code == '200') {
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            this.progressMessage = apiStatus.msg;

            // Set isSentToOpportunity to true and persist it
            this.isSentToOpportunity = true;
            localStorage.setItem(`isSentToOpportunity_${this.quoteDetailsObj.opportunityID}`, JSON.stringify(this.isSentToOpportunity));
          }
          setTimeout(() => {
            this.showProgress = false;
          }, this.commonService.getProgressBarTimeOut());

          this.isUnifiedPayloadSubmission = true;
        },
        (error) => {
          this.progressPercent = 90;
          this.progressStyle = 'progress-bar-danger';
          this.progressMessage = 'Error in getting response from Send To Opportunities';
          console.error('Error calling sendToOpportunities API:', error);
          setTimeout(() => {
            this.showProgress = false;
          }, this.commonService.getProgressBarTimeOut());
        }
      );
  }

  isRenewal() {
    return StringUtils.isEqualIgnoreCase(this.opportunityType, 'Renewal Local');
  }

  getQuoteHistoryData() {
    this.commonQuoteService
      .getOldQuotes(
        this.quoteDetailsObj.oppID,
        this.quoteDetailsObj.lob1,
        this.quoteDetailsObj.quoteHeaderID,
        this.quoteDetailsObj.fundingType,
        this.quoteOrigin,
        this.quoteDetailsObj.alternateQuote,
        this.quotingType,
        this.opportunityType
      )
      .subscribe(
        (response) => {
          let updatedQuotesData = [];
          if (response.opportunities.length) {
            this.oldQuotesData = response.opportunities;
            updatedQuotesData = this.oldQuotesData.map((quotesData, index) => {
              quotesData['Version'] = this.oldQuotesData.length - index;
              return quotesData;
            });
            this.oldQuotesData = updatedQuotesData;
          }
        },
        (error) => {
          console.error(error);
        }
      );
  }

  async getIsSentToOpportunity() {
    // Check localStorage for the persisted state of isSentToOpportunity
    const storedState = localStorage.getItem(`isSentToOpportunity_${this.quoteDetailsObj.opportunityID}`);
    if (storedState !== null) {
      this.isSentToOpportunity = JSON.parse(storedState);
    } else {
      this.isSentToOpportunity = false; // Default to false if no stored state

      // Fetch opportunities and update isSentToOpportunity if applicable
      let response = await firstValueFrom(this.commonQuoteService.getOpportunitesByOppID(this.quoteDetailsObj.opportunityID, this.quoteDetailsObj.lob));

      if (response != null) {
        for (var opp of response.opportunities) {
          if (opp && opp.opportunityID === this.quoteDetailsObj.opportunityID) {
            if (!this.isSentToOpportunity) {
              this.isSentToOpportunity = opp.isSentToOpportunity ?? false;

              // Persist the state in localStorage
              localStorage.setItem(`isSentToOpportunity_${this.quoteDetailsObj.opportunityID}`, JSON.stringify(this.isSentToOpportunity));
            }
          }
        }
      }

      if (this.isSentToOpportunity) {
        this.isUnifiedPayloadSubmission = true;
      }
    }
  }

  showSendToOppBasedOnConfig() {
    return (
      this.lobFundingTypeMapForSendToOpp &&
      Object.keys(this.lobFundingTypeMapForSendToOpp).includes(this.quoteDetailsObj.lob1)
    );
  }

  displayGuardrailErrorMessage(eleID, value) {
    switch (eleID) {
      case CommonConstants.IN_RATE_GUARANTEE:
        return CommonConstants.GAURD_RAIL_ERROR_MESSAGE_FOR_NOT_IN_RATE_GUARANTEE;
      default:
        return;
    }
  }

  failedGuardRailsForVisionQuote(failedGuardRails, name) {
    switch (name) {
      case CommonConstants.IN_RATE_GUARANTEE:
        return failedGuardRails?.includes(CommonConstants.Failed_Vision_Rate_Guarantee);
      case CommonConstants.LOSS_RATIO:
        return failedGuardRails?.includes(CommonConstants.GroupExpSummary_LossRatio);
      default:
        return;
    }
  }

  displayGuardrailErrorMessageForLossRatio() {
    return CommonConstants.GAURD_RAIL_ERROR_MESSAGE_FOR_LOSS_RATIO + ' ' + (this.rareData?.groupExperienceSummary?.lossRatio * 100).toFixed(2) + '%';
  }
}
