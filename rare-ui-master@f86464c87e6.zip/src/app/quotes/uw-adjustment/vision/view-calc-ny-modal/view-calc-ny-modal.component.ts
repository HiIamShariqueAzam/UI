import { Component, OnInit, Input, SimpleChanges, LOCALE_ID, Inject, AfterViewInit, ElementRef, ViewChild } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { formatCurrency, getCurrencySymbol } from '@angular/common';
import { CommonService, PrintExhibitService } from 'src/app/shared/services';
import { VisionConstants } from "../vision.constants";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: 'app-view-calc-ny-modal-vision',
  templateUrl: './view-calc-ny-modal.component.html',
  styleUrls: ['./view-calc-ny-modal.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class ViewCalcNYModalComponent implements OnInit, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() viewCalcPlan;
  @Input() visionPremiumComparison;
  @Input() rareData;

  downloadFailed : boolean = false ;
  reqTier: any;
  rateColumns: any[];
  fiveTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employeePlusSpouse },
    { header: VisionConstants.employeePlusChild },
    { header: VisionConstants.employeePlusChildren },
    { header: VisionConstants.employeePlusFamily },
  ];
  fourTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employeePlusSpouse },
    { header: VisionConstants.employeePlusChildren },
    { header: VisionConstants.employeePlusFamily },
  ];
  threeTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employeePlusOne },
    { header: VisionConstants.employeePlusFamily },
  ];
  twoTierColumns = [
    { header: VisionConstants.employee },
    { header: VisionConstants.employeePlusFamily },
  ];
  oneTierColumns = [
    { header: VisionConstants.employee },
  ];
  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    private commonService:CommonService,
    private peService:PrintExhibitService, private commonQuoteService: CommonQuoteService,
    @Inject(LOCALE_ID) private locale: string
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent?.nativeElement;
    const footer = this.modalFooter?.nativeElement;
  
      CommonUtil.modalPopup(content, [footer]);
  }
  
  ngOnChanges(changes: SimpleChanges) {
    if (changes.rareData && !changes.rareData.firstChange) {
      this.rareData = this.rareData;

    }
  }
  ngOnInit() {
    this.reqTier = Number(this.rareData.visionOutputTier);
    this.setDynamicTier(this.reqTier);
  }

  // Setting the rate tier columns in the table headers
  setDynamicTier(tierValue) {
    switch(tierValue) {
      case 5: this.rateColumns = this.fiveTierColumns;
        break;
      case 4: this.rateColumns = this.fourTierColumns;
        break;
      case 3: this.rateColumns = this.threeTierColumns;
        break;
      case 2: this.rateColumns = this.twoTierColumns;
        break;
      case 1: this.rateColumns = this.oneTierColumns;
        break;
      default: console.log('default case')
    }
  }
  getTableNameColspan() {
    return this.reqTier + 1;
  }
  getValue(type: string, tier: string) {
    switch(type) {
      case type = 'claimCost' :
        return formatCurrency(this.getClaimCost(type, tier), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case type = 'mbrPerCntrctFctr' :
        return this.getMemberPercentFactor(type, tier);
      case type = 'fmlyDscntFctr':
        return this.getFamilyFactor(type, tier);
      case type = 'pdtrcFctr':
        return this.getPediatricFacor(type, tier);
      case type = 'cmpgnDiscFctr':
        return this.getAssociation();
      case type = 'initialRates':
        return formatCurrency(this.getInitialRates(type, tier), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case type = 'rateInfo':
        return formatCurrency(this.getFinalRates(type, tier), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case type = 'competitiveRateAdjustmentPercent':
        return this.getCompetitiveRateAdjustmentPercent();
      case type = 'calculatedFactors':
        return formatCurrency(this.getTotalAdjClaimCost(type, tier), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case type = 'admnCost':
        return formatCurrency(this.getAdmnCost(), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case type = 'totalAdminExpense':
        return formatCurrency(this.getTotalAdminExpense(tier), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case type = 'totFctr':
        return this.getTotalFactorZ(tier);
      default : console.log('default case')
    }
  }
  getClaimCost(type: string, tier:string) {
    return this.viewCalcPlan.factors[type][tier];
  }
  getMemberPercentFactor(type: string, tier: string) {
    return this.viewCalcPlan.factors[type][tier];
  }
  getFamilyFactor(type, tier) {
    return this.viewCalcPlan.factors[type][tier] ? this.viewCalcPlan.factors[type][tier].toFixed(2) : '';
  }
  getPediatricFacor(type: string, tier: string) {
    return this.viewCalcPlan.factors[type][tier];
  }
  getAssociation() {
    return this.viewCalcPlan.factors.cmpgnDiscFctr;
  }
  getInitialRates(type: string, tier: string) {
    return this.viewCalcPlan[type][tier];
  }
  getFinalRates(type: string, tier: string) {
    return this.viewCalcPlan[type][tier];
  }
  getCompetitiveRateAdjustmentPercent() {
    return this.viewCalcPlan.competitiveRateAdjustmentPercent + '%';
  }
  getTotalAdjClaimCost(type: string, tier: string) {
    return this.viewCalcPlan.factors[type][tier].totalAdjClaimCost ? this.viewCalcPlan.factors[type][tier].totalAdjClaimCost : '';
  }
  getAdmnCost() {
    return this.viewCalcPlan.factors.admnCost
  }
  getTotalAdminExpense(tier: string) {
    return this.viewCalcPlan.factors['calculatedFactors'][tier].totAdminExpense ? this.viewCalcPlan.factors['calculatedFactors'][tier].totAdminExpense : 0;
  }
  getTotalFeesZ(type: string) {
    return this.viewCalcPlan.factors['calculatedFactors']['EE'][type] ? this.viewCalcPlan.factors['calculatedFactors']['EE'][type] : 0;
  }
  getTotalFactorZ(tier: string) {
    return this.viewCalcPlan.factors['calculatedFactors'][tier].totFctr ? this.viewCalcPlan.factors['calculatedFactors'][tier].totFctr.toFixed(2) : '0';
  }


  getOtherCommissionBlock(val: string) {
      return this.viewCalcPlan.factors[val] ? this.viewCalcPlan.factors[val] : 0;
  }
  getReqTier() {
    return this.reqTier;
  }
  downloadViewCalcExcel() {
    let obj = {};
    let data={}
    obj["planName"] = this.viewCalcPlan.planBenefits.planName;
    obj["quoteHeaderID"] = this.rareData.quoteHeaderID;
    obj["opportunityID"] = this.rareData.opportunityID;
    obj["state"] = this.rareData.state;
    obj["lob"] = this.viewCalcPlan.lob;
    obj["contractCode"] = this.viewCalcPlan.contractCode;
    obj["requiredTier"]=String(this.reqTier);
    if (this.reqTier == 2) {
      obj["claimCost"] = { "employee": this.getValue('claimCost', 'eeFactor'), "employeePlusFamily": this.getValue('claimCost', 'efFactor') }
      obj["costAdjustment"] = { "employee": this.getValue('competitiveRateAdjustmentPercent', 'eeFactor'), "employeePlusFamily": this.getValue('competitiveRateAdjustmentPercent', 'efFactor') }
      obj["adjustedCost"] = { "employee": this.getValue('calculatedFactors', 'EE'), "employeePlusFamily": this.getValue('calculatedFactors', 'EF') }
      obj["adminExpense"] = { "employee": this.getValue('admnCost', 'EE'), "employeePlusFamily": this.getValue('admnCost', 'EF') }
      obj["membersPerContract"] = { "employee": String(this.getValue('mbrPerCntrctFctr', 'eeFactor')), "employeePlusFamily": String(this.getValue('mbrPerCntrctFctr', 'efFactor')) }
      obj["totalAdminExpense"] = { "employee": this.getValue('totalAdminExpense', 'EE'), "employeePlusFamily": this.getValue('totalAdminExpense', 'EF') }
      obj["familyFactor"] = { "employee": this.getValue('fmlyDscntFctr', 'eeFactor'), "employeePlusFamily": this.getValue('fmlyDscntFctr', 'efFactor') };
      obj["pediatricFactor"] = { "employee": String(this.getValue('pdtrcFctr', 'eeFactor')), "employeePlusFamily": String(this.getValue('pdtrcFctr', 'efFactor')) };
      obj["totalFactors"] = { "employee": this.getValue('totFctr', 'EE'), "employeePlusFamily": this.getValue('totFctr', 'EF') };
      obj["initailRate"] = { "employee": this.getValue('initialRates', 'single'), "employeePlusFamily": this.getValue('initialRates', 'family') }
      obj["associaton"] = { "employee": this.getValue('cmpgnDiscFctr', 'eeFactor'), "employeePlusFamily": this.getValue('cmpgnDiscFctr', 'efFactor') };
      obj["finalRate"] = { "employee": this.getValue('rateInfo', 'single'), "employeePlusFamily": this.getValue('rateInfo', 'family') };
    }
    if (this.reqTier == 1) {
      obj["claimCost"] = { "employee": this.getValue('claimCost', 'eeFactor')}
      obj["costAdjustment"] = { "employee": this.getValue('competitiveRateAdjustmentPercent', 'eeFactor')}
      obj["adjustedCost"] = { "employee": this.getValue('calculatedFactors', 'EE')}
      obj["adminExpense"] = { "employee": this.getValue('admnCost', 'EE'),}
      obj["membersPerContract"] = { "employee": String(this.getValue('mbrPerCntrctFctr', 'eeFactor'))}
      obj["totalAdminExpense"] = { "employee": this.getValue('totalAdminExpense', 'EE')}
      obj["familyFactor"] = { "employee": this.getValue('fmlyDscntFctr', 'eeFactor')};
      obj["pediatricFactor"] = { "employee": String(this.getValue('pdtrcFctr', 'eeFactor'))};
      obj["totalFactors"] = { "employee": this.getValue('totFctr', 'EE')};
      obj["initailRate"] = { "employee": this.getValue('initialRates', 'single')}
      obj["associaton"] = { "employee": String(this.getValue('cmpgnDiscFctr', 'eeFactor'))};
      obj["finalRate"] = { "employee": this.getValue('rateInfo', 'single')};
    }
    if (this.reqTier == 3) {
      obj["claimCost"] = { "employee": this.getValue('claimCost', 'eeFactor'), "employeePlusOne": this.getValue('claimCost', 'e1Factor'), "employeePlusFamily": this.getValue('claimCost', 'efFactor') }
      obj["costAdjustment"] = { "employee": this.getValue('competitiveRateAdjustmentPercent', 'eeFactor'), "employeePlusOne": this.getValue('competitiveRateAdjustmentPercent', 'e1Factor'), "employeePlusFamily": this.getValue('competitiveRateAdjustmentPercent', 'efFactor') }
      obj["adjustedCost"] = { "employee": this.getValue('calculatedFactors', 'EE'), "employeePlusOne": this.getValue('calculatedFactors', 'E1'), "employeePlusFamily": this.getValue('calculatedFactors', 'EF') }
      obj["adminExpense"] = { "employee": this.getValue('admnCost', 'EE'), "employeePlusOne": this.getValue('admnCost', 'E1'), "employeePlusFamily": this.getValue('admnCost', 'EF') }
      obj["membersPerContract"] = { "employee": String(this.getValue('mbrPerCntrctFctr', 'eeFactor')), "employeePlusOne": String(this.getValue('mbrPerCntrctFctr', 'e1Factor')), "employeePlusFamily": String(this.getValue('mbrPerCntrctFctr', 'efFactor')) }
      obj["totalAdminExpense"] = { "employee": this.getValue('totalAdminExpense', 'EE'), "employeePlusOne": this.getValue('totalAdminExpense', 'E1'), "employeePlusFamily": this.getValue('totalAdminExpense', 'EF') }
      obj["familyFactor"] = { "employee": this.getValue('fmlyDscntFctr', 'eeFactor'), "employeePlusOne": this.getValue('fmlyDscntFctr', 'e1Factor'), "employeePlusFamily": this.getValue('fmlyDscntFctr', 'efFactor') };
      obj["pediatricFactor"] = { "employee": String(this.getValue('pdtrcFctr', 'eeFactor')), "employeePlusOne": String(this.getValue('pdtrcFctr', 'e1Factor')), "employeePlusFamily": String(this.getValue('pdtrcFctr', 'efFactor')) };
      obj["totalFactors"] = { "employee": this.getValue('totFctr', 'EE'), "employeePlusOne": this.getValue('totFctr', 'E1'), "employeePlusFamily": this.getValue('totFctr', 'EF') };
      obj["initailRate"] = { "employee": this.getValue('initialRates', 'single'), "employeePlusOne": this.getValue('initialRates', 'eeOne'), "employeePlusFamily": this.getValue('initialRates', 'family') }
      obj["associaton"] = { "employee": String(this.getValue('cmpgnDiscFctr', 'eeFactor')), "employeePlusOne": String(this.getValue('cmpgnDiscFctr', 'e1Factor')), "employeePlusFamily": String(this.getValue('cmpgnDiscFctr', 'efFactor')) };
      obj["finalRate"] = { "employee": this.getValue('rateInfo', 'single'), "employeePlusOne": this.getValue('rateInfo', 'eeOne'), "employeePlusFamily": this.getValue('rateInfo', 'family') };
    }

    if (this.reqTier == 4) {
      obj["claimCost"] = { "employee": this.getValue('claimCost', 'eeFactor'),"employeePlusSpouse":this.getValue('claimCost','esFactor'),"employeePlusChildren":this.getValue('claimCost','ecFactor'), "employeePlusFamily": this.getValue('claimCost', 'efFactor') }
      obj["costAdjustment"] = { "employee": this.getValue('competitiveRateAdjustmentPercent', 'eeFactor'),"employeePlusSpouse":this.getValue('competitiveRateAdjustmentPercent','esFactor'),"employeePlusChildren":this.getValue('competitiveRateAdjustmentPercent','ecFactor'), "employeePlusFamily": this.getValue('competitiveRateAdjustmentPercent', 'efFactor') }
      obj["adjustedCost"] = { "employee": this.getValue('calculatedFactors', 'EE'),"employeePlusSpouse":this.getValue('calculatedFactors','ES'),"employeePlusChildren":this.getValue('calculatedFactors','EC'), "employeePlusFamily": this.getValue('calculatedFactors', 'EF') }
      obj["adminExpense"] = { "employee": this.getValue('admnCost', 'EE'),"employeePlusSpouse":this.getValue('admnCost','ES'),"employeePlusChildren":this.getValue('admnCost','EC'), "employeePlusFamily": this.getValue('admnCost', 'EF') }
      obj["membersPerContract"] = { "employee": String(this.getValue('mbrPerCntrctFctr', 'eeFactor')),"employeePlusSpouse":String(this.getValue('mbrPerCntrctFctr','esFactor')),"employeePlusChildren":String(this.getValue('mbrPerCntrctFctr','ecFactor')), "employeePlusFamily": String(this.getValue('mbrPerCntrctFctr', 'efFactor')) }
      obj["totalAdminExpense"] = { "employee": this.getValue('totalAdminExpense', 'EE'),"employeePlusSpouse":this.getValue('totalAdminExpense','ES'),"employeePlusChildren":this.getValue('totalAdminExpense','EC'), "employeePlusFamily": this.getValue('totalAdminExpense', 'EF') }
      obj["familyFactor"] = { "employee": this.getValue('fmlyDscntFctr', 'eeFactor'),"employeePlusSpouse":this.getValue('fmlyDscntFctr','esFactor'),"employeePlusChildren":this.getValue('fmlyDscntFctr','ecFactor'), "employeePlusFamily": this.getValue('fmlyDscntFctr', 'efFactor') };
      obj["pediatricFactor"] = { "employee": String(this.getValue('pdtrcFctr', 'eeFactor')),"employeePlusSpouse":String(this.getValue('pdtrcFctr','esFactor')),"employeePlusChildren":String(this.getValue('pdtrcFctr','ecFactor')), "employeePlusFamily": String(this.getValue('pdtrcFctr', 'efFactor')) };
      obj["totalFactors"] = { "employee": this.getValue('totFctr', 'EE'),"employeePlusSpouse":this.getValue('totFctr','ES'),"employeePlusChildren":this.getValue('totFctr','EC'), "employeePlusFamily": this.getValue('totFctr', 'EF') };
      obj["initailRate"] = { "employee": this.getValue('initialRates', 'single'),"employeePlusSpouse":this.getValue('initialRates','eeSpouse'),"employeePlusChildren":this.getValue('initialRates','eeChildren'), "employeePlusFamily": this.getValue('initialRates', 'family') }
      obj["associaton"] = { "employee": String(this.getValue('cmpgnDiscFctr', 'eeFactor')),"employeePlusSpouse":String(this.getValue('cmpgnDiscFctr','esFactor')),"employeePlusChildren":String(this.getValue('cmpgnDiscFctr','ecFactor')), "employeePlusFamily": String(this.getValue('cmpgnDiscFctr', 'efFactor')) };
      obj["finalRate"] = { "employee": this.getValue('rateInfo', 'single'),"employeePlusSpouse":this.getValue('rateInfo','eeSpouse'),"employeePlusChildren":this.getValue('rateInfo','eeChildren'), "employeePlusFamily": this.getValue('rateInfo', 'family') };
    }

    if (this.reqTier == 5) {
      obj["claimCost"] = { "employee": this.getValue('claimCost', 'eeFactor'),"employeePlusSpouse":this.getValue('claimCost','esFactor'),"employeePlusChild": this.getValue('claimCost', 'ekFactor'),"employeePlusChildren":this.getValue('claimCost','ecFactor'), "employeePlusFamily": this.getValue('claimCost', 'efFactor') }
      obj["costAdjustment"] = { "employee": this.getValue('competitiveRateAdjustmentPercent', 'eeFactor'),"employeePlusSpouse":this.getValue('competitiveRateAdjustmentPercent','esFactor'),"employeePlusChild": this.getValue('competitiveRateAdjustmentPercent', 'ekFactor'),"employeePlusChildren":this.getValue('competitiveRateAdjustmentPercent','ecFactor'), "employeePlusFamily": this.getValue('competitiveRateAdjustmentPercent', 'efFactor') }
      obj["adjustedCost"] = { "employee": this.getValue('calculatedFactors', 'EE'),"employeePlusSpouse":this.getValue('calculatedFactors','ES'),"employeePlusChild": this.getValue('calculatedFactors', 'EK'),"employeePlusChildren":this.getValue('calculatedFactors','EC'), "employeePlusFamily": this.getValue('calculatedFactors', 'EF') }
      obj["adminExpense"] = { "employee": this.getValue('admnCost', 'EE'),"employeePlusSpouse":this.getValue('admnCost','ES'),"employeePlusChild": this.getValue('admnCost', 'EK'),"employeePlusChildren":this.getValue('admnCost','EC'), "employeePlusFamily": this.getValue('admnCost', 'EF') }
      obj["membersPerContract"] = { "employee": String(this.getValue('mbrPerCntrctFctr', 'eeFactor')),"employeePlusSpouse":String(this.getValue('mbrPerCntrctFctr','esFactor')),"employeePlusChild": String(this.getValue('mbrPerCntrctFctr', 'ekFactor')),"employeePlusChildren":String(this.getValue('mbrPerCntrctFctr','ecFactor')), "employeePlusFamily": String(this.getValue('mbrPerCntrctFctr', 'efFactor')) }
      obj["totalAdminExpense"] = { "employee": this.getValue('totalAdminExpense', 'EE'),"employeePlusSpouse":this.getValue('totalAdminExpense','ES'),"employeePlusChild": this.getValue('totalAdminExpense', 'EK'),"employeePlusChildren":this.getValue('totalAdminExpense','EC'), "employeePlusFamily": this.getValue('totalAdminExpense', 'EF') }
      obj["familyFactor"] = { "employee": this.getValue('fmlyDscntFctr', 'eeFactor'),"employeePlusSpouse":this.getValue('fmlyDscntFctr','esFactor'),"employeePlusChild": this.getValue('fmlyDscntFctr', 'ekFactor'),"employeePlusChildren":this.getValue('fmlyDscntFctr','ecFactor'), "employeePlusFamily": this.getValue('fmlyDscntFctr', 'efFactor') };
      obj["pediatricFactor"] = { "employee": String(this.getValue('pdtrcFctr', 'eeFactor')),"employeePlusSpouse":String(this.getValue('pdtrcFctr','esFactor')),"employeePlusChild": String(this.getValue('pdtrcFctr', 'ekFactor')),"employeePlusChildren":String(this.getValue('pdtrcFctr','ecFactor')), "employeePlusFamily": String(this.getValue('pdtrcFctr', 'efFactor')) };
      obj["totalFactors"] = { "employee": this.getValue('totFctr', 'EE'),"employeePlusSpouse":this.getValue('totFctr','ES'),"employeePlusChild": this.getValue('totFctr', 'EK'),"employeePlusChildren":this.getValue('totFctr','EC'), "employeePlusFamily": this.getValue('totFctr', 'EF') };
      obj["initailRate"] = { "employee": this.getValue('initialRates', 'single'),"employeePlusSpouse":this.getValue('initialRates','eeSpouse'),"employeePlusChild": this.getValue('initialRates', 'ekFactor'),"employeePlusChildren":this.getValue('initialRates','eeChildren'), "employeePlusFamily": this.getValue('initialRates', 'family') }
      obj["associaton"] = { "employee": String(this.getValue('cmpgnDiscFctr', 'eeFactor')),"employeePlusSpouse":String(this.getValue('cmpgnDiscFctr','esFactor')),"employeePlusChild": String(this.getValue('cmpgnDiscFctr', 'ekFactor')),"employeePlusChildren":String(this.getValue('cmpgnDiscFctr','ecFactor')), "employeePlusFamily": String(this.getValue('cmpgnDiscFctr', 'efFactor')) };
      obj["finalRate"] = { "employee": this.getValue('rateInfo', 'single'),"employeePlusSpouse":this.getValue('rateInfo','eeSpouse'),"employeePlusChild": this.getValue('rateInfo', 'ekFactor'),"employeePlusChildren":this.getValue('rateInfo','eeChildren'), "employeePlusFamily": this.getValue('rateInfo', 'family') };
    }
      obj["profit"] = String(this.getOtherCommissionBlock('prftPct'));
      obj["premiumTax"] = String(this.getOtherCommissionBlock('taxPct'));
      obj["commission"] = String(this.getOtherCommissionBlock('commissionValue'));
      obj["additionalAdminFee"] = String(this.getOtherCommissionBlock('addlAdminFee'));
      obj["totalFees"] = String(this.getTotalFeesZ('totFees'));
      data["data"]=obj;
      this.downloadViewCalcExcelFile(data);

  }
  downloadViewCalcExcelFile(viewCalcDetails) {
    this.commonQuoteService.getViewCalcExcel(this.rareData.metadata.metaTransID, this.rareData.metadata.ratingTransID, viewCalcDetails).subscribe(
      response => {
        this.downloadFailed = false;
           let processId = response.processId;
            var source = this.commonService.listenForStream(processId);
             source.addEventListener("SEND_EXHIBIT_TO_UI", (message: any) => {
              let eventData = JSON.parse(message.data);
              let fileExt = '.xlsx';
              CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet"+ fileExt) ;
              let fileName = this.commonService.getExportFilename();
              let contentData = eventData.payload.contentData;
              const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            });
      },
      error => {
        this.downloadFailed = true;
        var promise = new Promise<any>((resolve) => {
          setTimeout(() => {resolve(false); }, 10000);
          });
          promise.then((res) => {
            this.downloadFailed = false;
          });
      }
    );
  }
  setDefault()
  {
    this.downloadFailed = false;
  }
}
