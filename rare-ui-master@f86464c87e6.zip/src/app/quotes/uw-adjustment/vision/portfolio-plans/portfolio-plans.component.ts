import { Component, OnInit, Input, OnChanges, SimpleChanges, ViewEncapsulation } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-portfolio-plans-vision',
  templateUrl: './portfolio-plans.component.html',
  styleUrls: ['./portfolio-plans.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal],
  encapsulation: ViewEncapsulation.None
})
export class PortfolioPlansVisionComponent implements OnInit, OnChanges {

  @Input() status;
  @Input() reqTier;
  @Input() EE;
  @Input() EF;
  @Input() ES;
  @Input() E1;
  @Input() EK;
  @Input() EC;
  @Input() rareData;
  @Input() rareDataObjPortfolio;

  
  benefitsColSpanP: any;
  planColumnsP: any;
  expandClicked: boolean = true;
  planColumnsF: any;
  rateColumns: any[];
  portfolioPlans: any = [];
  scrollTop: any;
 
  planColumnsBeforePortfolio = [
    { header: 'Contract Code' },
    { header: 'Plan Name' },
    { header: 'Association' },
    { header: 'Plan Type' },
    { header: 'Participation Type' },
    { header: 'Eye Exam' },
    { header: 'Prescription Lens' },
    { header: 'Frames' },
    { header: 'Elective Contact Lens' },
    { header: 'Non Elective Contact Lens' },
  ];
  fiveTierColumns = [
    { header: 'Employee' },
    { header: 'Employee +Spouse' },
    { header: 'Employee +Child' },
    { header: 'Employee +Children' },
    { header: 'Employee +Family' },
  ];
  fourTierColumns = [
    { header: 'Employee' },
    { header: 'Employee +Spouse' },
    { header: 'Employee +Children' },
    { header: 'Employee +Family' },
  ];
  threeTierColumns = [
    { header: 'Employee' },
    { header: 'Employee+1' },
    { header: 'Employee +Family' },
  ];
  twoTierColumns = [
    { header: 'Employee' },
    { header: 'Employee +Family' },
  ];
  oneTierColumns = [
    { header: 'Employee' },
  ];
  
  ngOnChanges(changes:SimpleChanges) {
    if (changes.rareData && !changes.rareData.firstChange) {
      this.handlePortfolioPlans();
    }
  }
  ngOnInit() {
    this.benefitsColSpanP = 8;
    this.planColumnsP = this.planColumnsBeforePortfolio;
    this.setDynamicTier(this.reqTier);
    this.handlePortfolioPlans();
  }
  handlePortfolioPlans() {
    this.portfolioPlans = [];
    console.log(this.rareDataObjPortfolio)
    if (this.rareDataObjPortfolio['vision'] && this.rareDataObjPortfolio['vision'].proposedPlans) {
      this.rareDataObjPortfolio['vision'].proposedPlans.forEach(item => {
       if (item.planTypeRequested == "P") {
        this.portfolioPlans.push(item);
        }
      });
    }
  }
  setDynamicTier(tierValue) {
    if (tierValue == 5){
    this.rateColumns = this.fiveTierColumns;
    }
  else if (tierValue == 4)
    this.rateColumns = this.fourTierColumns;
  else if (tierValue == 3)
    this.rateColumns = this.threeTierColumns;
  else if (tierValue == 2)
    this.rateColumns = this.twoTierColumns;
  else if (tierValue == 1)
    this.rateColumns = this.oneTierColumns;
  }
  onScroll(event) {
    this.scrollTop = event.target.scrollTop
  }
}
