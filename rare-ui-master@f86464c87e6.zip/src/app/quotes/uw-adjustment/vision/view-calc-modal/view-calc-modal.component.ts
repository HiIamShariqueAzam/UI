import { Component, OnInit, Input, OnChanges, SimpleChanges, LOCALE_ID, Inject, AfterViewInit, ElementRef, ViewChild } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { formatCurrency,getCurrencySymbol, formatPercent } from '@angular/common';
import { CommonService, PrintExhibitService } from 'src/app/shared/services';
import { VisionUtil } from "../vision.util";
import { VisionConstants } from "../vision.constants";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: 'app-view-calc-modal-vision',
  templateUrl: './view-calc-modal.component.html',
  styleUrls: ['./view-calc-modal.component.css'],
  standalone: false,  
  providers: [NgbModalConfig, NgbModal]
})
export class ViewCalcModalComponent implements OnInit, OnChanges, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() viewCalcPlan;
  @Input() visionPremiumComparison;
  @Input() isChangedFlag;

  @Input() rareData;
  @Input() rareDataObj;
  Object = Object;
  downloadFailed : boolean = false ;
  reqTier: any;
  visionOutputTier: any;
  planColumnsF=[
    { header: 'Rate Tier'},
    { header: 'Book Rates'},
    { header: 'Commission'},
    { header: 'Rates After Commission'},
    { header: 'Sales Adjustment'},
    { header: 'Quoted Rates'},
  ];

  defaultTierNames = {
    "EE": "Employee",
    "EF": "Employee + Family",
    "EK": "Employee + Child",
    "EC": "Employee + Children",
    "ES": "Employee + Spouse",
    "E1": "Employee + One"
  };
  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    private commonService:CommonService,
    private peService:PrintExhibitService,
    @Inject(LOCALE_ID) private locale: string, private commonQuoteService: CommonQuoteService
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [footer]);
  }
  
  ngOnChanges(changes: SimpleChanges) {
    if (changes.viewCalcPlan && !changes.viewCalcPlan.firstChange) {
      this.viewCalcPlan = this.viewCalcPlan;
      this.getDiffPercentage();
    }
    if (changes.rareDataObj && !changes.rareDataObj.firstChange) {
      this.viewCalcPlan = this.viewCalcPlan;
      this.getDiffPercentage();
    }
  }

  // Downloading the calc popup details to excel
  downloadViewCalcExcel() {
    this.reqTier = this.rareData.visionOutputTier;
    let data={};
    let obj={}
    obj[CommonConstants.PLAN_NAME]=this.viewCalcPlan.planBenefits.planName;
    obj[CommonConstants.QUOTEHEADER_ID] = this.rareData.quoteHeaderID;
    obj[CommonConstants.OPPORTUNITY_ID] = this.rareData.opportunityID;
    obj[CommonConstants.LOB] = this.viewCalcPlan.lob;
    obj[CommonConstants.CONTRACT_CODE] = this.viewCalcPlan.contractCode;
    obj["Rate Tier"] = { "bookRates": "Book Rates", "commission": "Commission", "ratesAfterCommission": "Rates After Commission", "salesAdjustment": "Sales Adjustment", "quotedRates": "Quoted Rates" }
    switch(Number(this.reqTier)) {
      case 1 :
        obj[this.defaultTierNames.EE] =this.buildViewCalcExcel(1);
        break;
      case 2 :
        obj[this.defaultTierNames.EE] =this.buildViewCalcExcel(1);
        obj[this.defaultTierNames.EF] =this.buildViewCalcExcel(2);
        break;
      case 3 :
        obj[this.defaultTierNames.EE] =this.buildViewCalcExcel(1);
        obj[this.defaultTierNames.E1] =this.buildViewCalcExcel(2);
        obj[this.defaultTierNames.EF] =this.buildViewCalcExcel(3);
        break;
      case 4 :
        obj[this.defaultTierNames.EE] =this.buildViewCalcExcel(1);
        obj[this.defaultTierNames.ES] =this.buildViewCalcExcel(2);
        obj[this.defaultTierNames.EC] =this.buildViewCalcExcel(3);
        obj[this.defaultTierNames.EF] =this.buildViewCalcExcel(4);
        break;
      case 5 :
        obj[this.defaultTierNames.EE] =this.buildViewCalcExcel(1);
        obj[this.defaultTierNames.ES] =this.buildViewCalcExcel(2);
        obj[this.defaultTierNames.EK] =this.buildViewCalcExcel(3);
        obj[this.defaultTierNames.EC] =this.buildViewCalcExcel(4);
        obj[this.defaultTierNames.EF] =this.buildViewCalcExcel(5);
        break;
      default : console.log('default log');
    }
    obj["Premium"] = { "bookRates": "", "commission": "", "ratesAfterCommission": String(this.getAbsoluteValue(this.getRateWithCommPremium('RWC'))), "salesAdjustment": "", "quotedRates": String(this.getAbsoluteValue(this.getRateWithCommPremium('QR'))) }
    obj["Difference"] = { "bookRates": "", "commission": "", "ratesAfterCommission": "", "salesAdjustment": "", "quotedRates": this.getDiffPercentage() + "%" }
    data["data"]=obj
    this.downloadViewCalcExcelFile(data);
  }

  buildViewCalcExcel(tierValue) {
    return {
      bookRates: this.getValues(tierValue, 'bookRate'),
      commission: this.getValues(tierValue, 'commission'),
      ratesAfterCommission: this.getValues(tierValue, 'rateWithComm'),
      salesAdjustment : this.getValues(tierValue, 'salesAdj')+VisionConstants.percent,
      quotedRates: this.getValues(tierValue, 'quotedRates')
    }
    }
  // Calling the view calc popup download API
  downloadViewCalcExcelFile(viewCalcDetails) {
    this.commonQuoteService.getViewCalcExcel(this.rareData.metadata.metaTransID, this.rareData.metadata.ratingTransID, viewCalcDetails).subscribe(
      response => {
        this.downloadFailed = false;
           let processId = response.processId;
            var source = this.commonService.listenForStream(processId);
             source.addEventListener("SEND_EXHIBIT_TO_UI", (message: any) => {
              let eventData = JSON.parse(message.data);
              let fileExt = '.xlsx';
              CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet"+ fileExt) ;
              let fileName = this.commonService.getExportFilename();
              let contentData = eventData.payload.contentData;
              const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            });
      },
      error => {
        this.downloadFailed = true;
        var promise = new Promise<any>((resolve) => {
          setTimeout(() => {resolve(false); }, 10000);
          });
          promise.then((res) => {
            this.downloadFailed = false;
          });
      }
    );
  }
  setDefault()
  {
    this.downloadFailed = false;
  }

  // Getting the difference percentage
  getDiffPercentage() {
    return (this.viewCalcPlan?.factors.premiumDiffPct.toFixed(2) || 0)
  }
  ngOnInit() {
    this.visionOutputTier = this.rareData['visionOutputTier']
  }

  // Returning the vision output tier to span the row
  getRowSpan() {
    return this.rareData.visionOutputTier;
  }

  // Getting the tier names
  getTierName(tierValue: number, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
        return VisionUtil.getTierEmpDesc(tierValue, Number(this.rareData.visionOutputTier));
    }
  }

  // Formatting the currency type and percent
  getAbsoluteValue(value: number, type?: string): number | string {
    if (value && value != Infinity) {
      if (StringUtils.isEqual(type, 'percent')) {
        return formatPercent(Math.abs(value), this.locale, '1.0-2');
      }
      return formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
    }
    return 0;
  }

  // Common method to get values from each column
  getValues(tierVal, val) {
    switch(val) {
      case 'bookRate':
        return formatCurrency(this.getBookrates(tierVal), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case 'commission':
        return this.getCommissionVal();
      case 'rateWithComm':
        return formatCurrency(this.getRatesWithComm(tierVal), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      case 'salesAdj':
        return this.getSalesAdj();
      case 'quotedRates':
        return formatCurrency(this.getQuotedRates(tierVal), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      default:
        return;
    }
  }
  // Get the premium for Rates with commission and quoted rates column
  getRateWithCommPremium(forType: string) {
    if (StringUtils.isEqual(forType, 'RWC')) {
      return (this.viewCalcPlan.initialRates.monthlyPremium || '');
    } else {
      return (this.viewCalcPlan.rateInfo.monthlyPremium || '');
    }
  }

  // Get book rates column data
  getBookrates(tierNumber) {
    switch (Number(this.visionOutputTier)) {
      case 1:
        if (tierNumber == 1) {
          return this.viewCalcPlan.factors.t2EeRate;
        }
      case 2:
        if (tierNumber == 1) {
          return this.viewCalcPlan.factors.t2EeRate;
        } else if (tierNumber == 2) {
          return this.viewCalcPlan.factors.t2EfRate;
        }
      case 3:
        if (tierNumber == 1) {
          return this.viewCalcPlan.factors.t3EeRate;
        } else if (tierNumber == 2) {
          return this.viewCalcPlan.factors.t3E1Rate;
        } else if (tierNumber == 3) {
          return this.viewCalcPlan.factors.t3EfRate;
        }
      case 4:
        if (tierNumber == 1) {
          return this.viewCalcPlan.factors.t4EeRate;
        } else if (tierNumber == 2) {
          return this.viewCalcPlan.factors.t4EsRate;
        } else if (tierNumber == 3) {
          return this.viewCalcPlan.factors.t4EcRate;
        } else if (tierNumber == 4) {
          return this.viewCalcPlan.factors.t4EfRate;
        }
      case 5:
        if (tierNumber == 1) {
          return this.viewCalcPlan.factors.t5EeRate;
        } else if (tierNumber == 2) {
          return this.viewCalcPlan.factors.t5EsRate;
        } else if (tierNumber == 3) {
          return this.viewCalcPlan.factors.t5EkRate;
        } else if (tierNumber == 4) {
          return this.viewCalcPlan.factors.t5EcRate;
        } else if (tierNumber == 5) {
          return this.viewCalcPlan.factors.t5EfRate;
        }
    }
  }

  // Get the commission value
  getCommissionVal() {
    let val = this.viewCalcPlan.commissionValue ? this.viewCalcPlan.commissionValue : 0;
    if (StringUtils.isEqual(this.viewCalcPlan.commissionType, VisionConstants.pcpm)) {
      return VisionConstants.dollar + val + '/' + VisionConstants.pcpm;
    } else {
      return val + VisionConstants.percent;
    }
  }

  // Get the sales adjustment percentage
  getSalesAdj() {
    return (this.viewCalcPlan.competitiveRateAdjustmentPercent || 0);
  }

  // Get quoted rates
  getQuotedRates(tierNumber) {
    return VisionUtil.getTierRates(tierNumber, Number(this.visionOutputTier), this.viewCalcPlan, 'rateInfo');
  }
  // Get rates with commission
  getRatesWithComm(tierVal) {
    return VisionUtil.getTierRates(tierVal, Number(this.visionOutputTier), this.viewCalcPlan, 'initialRates');
  }

}
