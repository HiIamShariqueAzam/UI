import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeclineQuoteComponent } from './decline-quote.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from 'primeng/select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    DeclineQuoteComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MultiSelectModule,
    FormsModule,
    NgbModule,
    SelectModule
  ],
  exports:[
    DeclineQuoteComponent
  ]
})
export class DeclineQuoteModule { }
