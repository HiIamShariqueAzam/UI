import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MultiSelect } from 'primeng/multiselect';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { DeclineOptions } from 'src/app/shared/models/declineOptions';
import { CommonService, ProcessQuoteDetailsService } from 'src/app/shared/services';
import { StringUtils } from 'src/app/shared/utils/string-utils';

@Component({
  selector: 'app-decline-quote',
  templateUrl: './decline-quote.component.html',
  styleUrls: ['./decline-quote.component.css'],
  standalone: false,
})
export class DeclineQuoteComponent implements OnChanges, OnInit {
  @Input() quoteDetailsObj: any;
  @Input() disableAll: boolean;
  @Input() disableDeclineTab: boolean;
  @Input() disableDeclineNoCheckbox: boolean = true;
  @Input() declineCheckboxes: any;
  @Input() isReadOnlyRole: boolean = false;
  @Input() status: String;
  @Input() ratingTransID: any;

  @Output() userAction = new EventEmitter<any>();
  @Output() declineReasons = new EventEmitter<any>();

  @ViewChild(MultiSelect) multiSelect: MultiSelect;

  declineOptions: any[] = [];
  backendDeclineOptions: any[] = [];
  staticDeclineOptions: any[] = CommonConstants.staticDeclineOptions;
  decline_form: FormGroup<DeclineOptions>;
  selectedDeclineCheckbox: any;
  isRenewal = false;
  isMedicalAca = false;
  isMedicalMEWA = false;
  isVisionAca = false;
  alternateQuote: boolean;

  constructor(
    private commonService: CommonService,
    private fb: FormBuilder,
    private processQuoteService: ProcessQuoteDetailsService,
    private elRef: ElementRef,
    private commonQuoteService: CommonQuoteService
  ) {}

  ngOnInit(): void {
    this.isRenewal =
      this.quoteDetailsObj &&
      this.quoteDetailsObj.opportunityType &&
      this.quoteDetailsObj.opportunityType == 'Renewal Local' &&
      this.quoteDetailsObj['lob1'] == 'Medical';
      this.isMedicalAca = this.commonService.isMedicalAca(this.quoteDetailsObj);
      this.isMedicalMEWA = this.commonService.isMedicalMEWA(this.quoteDetailsObj);
    this.isVisionAca = this.commonService.isVisionAca(this.quoteDetailsObj);
    this.decline_form = this.fb.group({
      declineOptionsForm: ['']
    });

    if (!this.isMedicalAca || !this.isVisionAca) {
      this.commonQuoteService.getDeclineOptions(this.quoteDetailsObj, this.ratingTransID).subscribe(response => {
        if(typeof(response) != 'undefined' && response != null
        && typeof(response.data) != 'undefined' && response.data != null){
          response.data.forEach(element => {
            this.backendDeclineOptions.push(element);
            this.declineOptions.push({ label: element, value: element });
          });
          this.processQuoteService.setDeclineOptions(this.backendDeclineOptions);
          this.setDeclineCheckboxes();
        }
        this.setDeclineToQuoteOptionsByDefaultStatic();
      });
    }

    const myDropdown = this.elRef.nativeElement.querySelector('declineMouseHover');
    if (myDropdown) {
      myDropdown.click();
    }
    this.doSomething();
  }

  setDeclineToQuoteOptionsByDefaultStatic() {
    // this is for Supp Health decline to quote static options
    if (StringUtils.isEqual(this.quoteDetailsObj.lob, CommonConstants.SuppHealth) && !this.declineOptions.length) {
      this.staticDeclineOptions.forEach((options) => {
        this.declineOptions.push(options);
      });
    }
  }

  isDisableDeclineToQuotebtn(): boolean {
    return this.disableDeclineTab || this.disableAll || this.isReadOnlyRole || this.status == 'Failed' || this.isAutoQuote() || this.disableDeclineNoCheckbox;
  }

  doSomething() {
    setTimeout(() => {
      this.disableDeclineNoCheckbox = true;
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    let declineChecboxes: any;
    if (changes.declineCheckboxes) {
      if (this.declineCheckboxes != null) {
        this.declineCheckboxes.forEach((element) => {
          if (declineChecboxes == null) {
            declineChecboxes = element;
          } else {
            declineChecboxes = declineChecboxes + ',' + element;
          }
        });
        if(typeof(this.backendDeclineOptions) == 'undefined' && this.backendDeclineOptions == null){
          if(!this.isMedicalAca || !this.isVisionAca){
            this.commonQuoteService.getDeclineOptions(this.quoteDetailsObj, this.ratingTransID).subscribe(response => {
              if(typeof(response) != 'undefined' && response != null
              && typeof(response.data) != 'undefined' && response.data != null){

                response.data.forEach(element => {
                  this.backendDeclineOptions.push(element);
                  this.declineOptions.push({ label: element, value: element });
                });

                this.processQuoteService.setDeclineOptions(this.backendDeclineOptions);
                this.setDeclineCheckboxes();
              }
            });
          }
        }
        this.setDeclineCheckboxes();
      }
    }
  }

  setDeclineCheckboxes() {
    var declineList = [];
    declineList = this.declineCheckboxes.map((id) => this.backendDeclineOptions.find((decOps) => decOps === id));
    if (typeof this.decline_form != 'undefined') {
      this.decline_form.patchValue({
        declineOptionsForm: declineList
      });
      this.selectedDeclineCheckbox = declineList;
      if (declineList.length > 0) {
        this.disableDeclineNoCheckbox = false;
      } else {
        this.disableDeclineNoCheckbox = true;
      }
      this.processQuoteService.setDeclineOptionsChecked(declineList);
    }
    if (
      typeof localStorage.getItem(
        'statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + this.quoteDetailsObj.lob1 + '_' + this.quoteDetailsObj.fundingType
      ) != 'undefined' &&
      localStorage.getItem(
        'statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + this.quoteDetailsObj.lob1 + '_' + this.quoteDetailsObj.fundingType
      ) != null
    ) {
      let declineOptionArray = localStorage
        .getItem('statusReasons' + '_' + this.quoteDetailsObj.quoteHeaderID + '_' + this.quoteDetailsObj.lob1 + '_' + this.quoteDetailsObj.fundingType)
        .split(';');
      if (typeof this.decline_form != 'undefined' && this.decline_form != null) {
        this.decline_form.patchValue({
          declineOptionsForm: declineOptionArray
        });
        this.selectedDeclineCheckbox = declineOptionArray;
        if (declineOptionArray.length > 0) {
          this.disableDeclineNoCheckbox = false;
        }
      }
    }
  }

  onClick(action: string) {
    if (!this.disableDeclineNoCheckbox) {
      this.userAction.emit(action);
    }
  }

  onMouseFocus(event) {
    if (this.multiSelect) {
      this.multiSelect.show();
    }
    event.stopPropagation();
  }

  onDecline(event) {
    if (typeof this.decline_form != 'undefined' && this.decline_form != null && this.decline_form.get('declineOptionsForm').value.length > 0) {
      this.disableDeclineNoCheckbox = false;
    } else {
      this.disableDeclineNoCheckbox = true;
    }
    this.processQuoteService.declineOptionsValues.next(this.decline_form.get('declineOptionsForm').value);
    this.declineReasons.emit(this.decline_form.get('declineOptionsForm').value);
  }

  isAutoQuote() {
    if (
      this.quoteDetailsObj &&
      this.quoteDetailsObj.opportunityType == 'New Business Local' &&
      this.quoteDetailsObj.marketSegment == 'SG' &&
      this.quoteDetailsObj.lob1 == 'Vision'
    ) {
      return true;
    } else {
      return false;
    }
  }

  getRenDropdownClass() {
    return this.quoteDetailsObj['opportunityType'] == 'Renewal Local' ? 'renewal-bg' : '';
  }
}
