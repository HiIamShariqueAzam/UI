import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeclineQuoteComponent } from './decline-quote.component';

describe('DeclineQuoteComponent', () => {
  let component: DeclineQuoteComponent;
  let fixture: ComponentFixture<DeclineQuoteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeclineQuoteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclineQuoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
