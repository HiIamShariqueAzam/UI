import { NgModule } from "@angular/core";
import { CommonModule, DatePipe } from "@angular/common";
import { MedicalComponent } from "./medical.component";
import { MedicalPlanRatesComponent } from "./medical-plan-rates/medical-plan-rates.component";
import { ViewCalcRatesComponent } from "./view-calc-modal/view-calc-modal.component";
import { RouterModule } from "@angular/router";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { TableModule } from "primeng/table";
import { ButtonModule } from "primeng/button";
import { DatePickerModule } from "primeng/datepicker";
import { MultiSelectModule } from "primeng/multiselect";
import { RadioButtonModule } from "primeng/radiobutton";
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { ToastModule } from "primeng/toast";
import { CheckboxModule } from "primeng/checkbox";
import { ConfirmDialogModule } from "primeng/confirmdialog";
import { ConfirmationService } from "primeng/api";
import { DialogModule } from "primeng/dialog";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ProgressSpinnerModule } from "primeng/progressspinner";
import { MedicalPremiumComparisonComponent } from "./medical-premium-comparison/medical-premium-comparison.component";
import { ErredPlanGridComponent } from "./erred-plan-grid/erred-plan-grid.component";
import {
  assumptionsAndConditionsGridComponent
} from "./medical-assumptions-conditions-grid/medical-assumptions-conditions-component";
import { AdjustmentsComponent } from "./adjustments/adjustments.component";
import { OpportunitiesHistoryComponent } from "./opportunities-history/opportunities-history.component";
import { AdjustmentsHistoryComponent } from "./adjustments-history/adjustments-history.component";
import { ExhibitOverridesComponent } from "./exhibit-overrides/exhibit-overrides.component";
import { SelectButtonModule } from "primeng/selectbutton";
import { UnderwriterAdjustmentService } from "./uw-adjustment.service";
import { UWAdjustmentChangeSetService } from "./uw-adjust-changeset.service";
import { SitematchModalComponent } from "./sitematch-modal/sitematch-modal.component";
import { RequoteModalComponent } from "./requote-modal/requote-modal.component";
import { QuoteDetailsComponent } from "./quote-details/quote-details.component";
import { QuoteActionsComponent } from "./quote-actions/quote-actions.component";
import { PrintExhibitsComponent } from "./print-exhibits/print-exhibits.component";
import { SharedModule } from "src/app/shared/shared.module";
import { AbfRatesComponent } from "./abf-rates/abf-rates.component";
import { ExperienceSummaryModalComponent } from "./experience-summary/experience-summary.component";
import {
  ExperienceClaimCostComponent
} from "./experience-summary/experience-claim-cost/experience-claim-cost.component";
import {
  ExperienceRatesTableComponent
} from "./experience-summary/experience-rates-table/experience-rates-table.component";
import {
  ExperienceClaimsOnlyRatesComponent
} from "./experience-summary/experience-claims-only-rates/experience-claims-only-rates.component";
import {
  ExperienceLargeClaimsAnalysisComponent
} from "./experience-summary/experience-large-claims-analysis/experience-large-claims-analysis.component";
import {
  ExperienceLossRatiosComponent
} from "./experience-summary/experience-loss-ratios/experience-loss-ratios.component";
import { RenewalSummaryComponent } from "./renewal-summary/renewal-summary.component";
import { TooltipModule } from "primeng/tooltip";
import { DeclineQuoteModule } from "../common/decline-quote/decline-quote.module";
import {
  ExperienceCurrentRatesComponent
} from "./experience-summary/experience-current-rates/experience-current-rates.component";
import {
  AutorunBatchHistoryComponent
} from "./experience-summary/autorun-batch-history/autorun-batch-history.component";
import { MedicareRatesComponent } from "./medicare-rates/medicare-rates.component";
import { SelectModule } from "primeng/select";
import { ExpGrandTotalCalcService } from "./exp-grand-total-calc.service";
import { ExperienceExtractionProcessComponent} from "src/app/shared/components/experience-extraction-process/experience-extraction-process.component";
import { DataTableEditOveralyComponent } from "src/app/shared/components/data-table-edit-overaly/data-table-edit-overaly.component";
import { GroupExperienceComponent } from "src/app/shared/components/group-experience/group-experience.component";
import { DrawerModule } from "primeng/drawer";
import { ExperienceCurvEstimatedClaimCostComponent } from "./experience-summary/experience-curv-estimated-claim-cost/experience-curv-estimated-claim-cost.component";

@NgModule({
    declarations: [MedicalComponent,
        MedicalPlanRatesComponent,
        ViewCalcRatesComponent,
        MedicalPremiumComparisonComponent,
        ErredPlanGridComponent,
        assumptionsAndConditionsGridComponent,
        AdjustmentsComponent,
        OpportunitiesHistoryComponent,
        AdjustmentsHistoryComponent,
        ExhibitOverridesComponent,
        SitematchModalComponent,
        RequoteModalComponent,
        QuoteDetailsComponent,
        QuoteActionsComponent,
        PrintExhibitsComponent,
        AbfRatesComponent,
        MedicareRatesComponent,
        ExperienceSummaryModalComponent,
        ExperienceClaimCostComponent,
        ExperienceRatesTableComponent,
        ExperienceClaimsOnlyRatesComponent,
        RenewalSummaryComponent,
        ExperienceLargeClaimsAnalysisComponent,
        ExperienceLossRatiosComponent,
        ExperienceCurrentRatesComponent,
        AutorunBatchHistoryComponent,
        ExperienceCurvEstimatedClaimCostComponent
    ],
    imports: [
        CommonModule, TableModule, ButtonModule, ReactiveFormsModule, RadioButtonModule, FlexLayoutModule, SelectModule, MultiSelectModule, FormsModule, ToastModule, CheckboxModule, NgbModule, ProgressSpinnerModule, DialogModule, ConfirmDialogModule, SelectButtonModule, TooltipModule, DeclineQuoteModule,SharedModule, DatePickerModule,
        ConfirmDialogModule,
        RouterModule.forChild([
            { path: '', component: MedicalComponent, pathMatch: 'full' }
        ]),
        ExperienceExtractionProcessComponent,
        DataTableEditOveralyComponent,
        GroupExperienceComponent,
        DrawerModule,
        ConfirmDialogModule
    ],
    bootstrap: [MedicalComponent],
    providers: [DatePipe, ConfirmationService, UnderwriterAdjustmentService, UWAdjustmentChangeSetService, ExpGrandTotalCalcService],
    exports: [
        MedicalComponent,
        MedicalPlanRatesComponent,
        ViewCalcRatesComponent,
        ErredPlanGridComponent,
        MedicalPremiumComparisonComponent,
        AdjustmentsComponent,
        OpportunitiesHistoryComponent,
        AdjustmentsHistoryComponent,
        ExhibitOverridesComponent,
        SitematchModalComponent,
        RequoteModalComponent,
        QuoteDetailsComponent,
        QuoteActionsComponent,
        PrintExhibitsComponent,
        ExperienceSummaryModalComponent
    ]
})
export class MedicalModule {

 }
