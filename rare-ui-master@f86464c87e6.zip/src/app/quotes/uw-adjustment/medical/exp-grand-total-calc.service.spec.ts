import { TestBed } from '@angular/core/testing';

import { ExpGrandTotalCalcService } from './exp-grand-total-calc.service';

describe('ExpGrandTotalCalcService', () => {
  let service: ExpGrandTotalCalcService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExpGrandTotalCalcService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
