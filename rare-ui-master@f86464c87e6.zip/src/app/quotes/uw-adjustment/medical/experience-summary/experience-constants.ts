export class ExperienceConstants
{
    public static CLM='CLM';
    public static RET='RET';
    public static INPUT_CLAIMS='inputClaims';
    public static CREDIBLE_CLAIM_COST='credibleClaimCost';
    public static BLUECARD_FEE_TYPE='blueCardFeeType';
    public static RETENTION_TOOPTIP_TEXT='Retention Blue Card Fees - ';
    public static EXP_PERIOD_SUMMARY_MAP='experiencePeriodSummaryMap';
    public static MED_CLAIM_SUMMARY='medicalClaimSummary';
    public static PMPM=' PMPM';
    public static CLAIM_TOOLTIP_MSG='Includes Blue Card Fees - ';
    public static BLUECARD_CLAIM_AMOUNT='blueCardClaimsAmount';
    public static BLUECARD_RETENTION_PMPM='blueCardRetentionPMPM';
}