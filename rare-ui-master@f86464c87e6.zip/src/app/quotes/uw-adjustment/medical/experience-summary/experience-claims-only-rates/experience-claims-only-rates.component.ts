import { Component, OnInit, Input, Inject, LOCALE_ID } from "@angular/core";
import { formatCurrency, getCurrencySymbol, formatNumber, formatPercent } from '@angular/common';
import { StringUtils } from 'src/app/shared/utils/string-utils';

@Component({
  selector: "app-experience-claims-only-rates",
  templateUrl: "./experience-claims-only-rates.component.html",
  styleUrls: ["./experience-claims-only-rates.component.css"],
  standalone: false
})

export class ExperienceClaimsOnlyRatesComponent implements OnInit {
  @Input() experienceSumData: any;
  headers = [];
  footers = [];
  tierDescription: any = {
    "1-Tier": [
      { label: 'EE' }
    ],
    "2-Tier": [
      { label: 'EE' },
      { label: 'EF' },
    ],
    "3-Tier": [
      { label: 'EE' },
      { label: 'E1' },
      { label: 'EF' }
    ],
    "4-Tier": [
      { label: 'EE' },
      { label: 'ES' },
      { label: 'EC' },
      { label: 'EF' }
    ],
    "5-Tier": [
      { label: 'EE' },
      { label: 'ES' },
      { label: 'EK' },
      { label: 'EC' },
      { label: 'EF' },
    ]
  };

  tiredRatesKey = {
    EE: 'single',
    EF: 'family',
    EK: 'eeChild',
    ES: 'eeSpouse',
    EC: 'eeChildren',
    E1: 'eeOne'
  };
  fundingType: string = "FI";

  constructor(@Inject(LOCALE_ID) private locale: string) { }

  ngOnInit() {
    this.initializeComponentVariables();
  }

  initializeComponentVariables() {
    this.fundingType = this.experienceSumData['fundingType'];
    this.headers = [
      ...this.getFirstFieldHeader(),
      ...this.getMiddleFieldHeader()
    ];
    this.getFooters();
  }

  getFirstFieldHeader(): any[] {
    let firstHeader = [{
      label: '', subHeaders: [
        { label: 'Proposed plans', field: 'index' },
        { label: 'Contract code', field: 'contractCode' },
        { label: 'Plan Name', field: 'planName', class: "w-30" }
      ],
      field: 'planRateData',
      colspan: 3,
      formatType: 'string'
    }];
    return firstHeader;
  }

  getMiddleFieldHeader(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let colspan = this.experienceSumData['outputTier'];
    let subHeaders = JSON.parse(JSON.stringify(this.tierDescription[`${colspan}-Tier`]));
    subHeaders.forEach(element => {
      element['field'] = this.tiredRatesKey[element['label']];
    });
    let tiredRateHeaders = [
      {
        colspan, label: 'Total Rates', subHeaders,
        field: 'experienceOnlyFactors.expOnlyTieredRatesMap', formatType: 'flat-dollar'
      }
    ];
    return tiredRateHeaders;
  }

  getTableData(medicalDetail, header, subHeader, index) {
    if (subHeader.field === 'index') {
      return (index + 1);
    } else {
      let allHeaderFields = header.field.split('.');
      let value;
      allHeaderFields.forEach((field, i) => {
        if (i === 0) {
          value = (medicalDetail[field]) ? medicalDetail[field] : 0;
        } else {
          if (header.field == 'experienceOnlyFactors.expOnlyTieredRatesMap') {
            value = (value && value[field] && value[field][this.experienceSumData['outputTier'] + "-tier"]) ? value[field][this.experienceSumData['outputTier'] + "-tier"] : 0;
          } else {
            value = (value[field]) ? value[field] : 0;
          }
        }
      });
      value = (value && value[subHeader.field]) ? value[subHeader.field] : 0;
      if (value && subHeader.field === 'planName') {
        let planName = value.split(' - ');
        value = planName.length > 1 ? planName[1] : planName[0];
      }
      return this.getRoundedValue(value, header['formatType']);
    }
  }

  getFooters(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let totalMontlyRates = [];
    let claimsOnlyRateAction = [];
    totalMontlyRates = this.getFooterCommonFields('Total monthly Rates', 'experienceOnlyTotalMonthlyPremium', 'flat-dollar');
    claimsOnlyRateAction = this.getFooterCommonFields('Claims Only Rate Action', 'experienceOnlyRateActionPercent', 'percent');
    this.footers = [
      totalMontlyRates,
      claimsOnlyRateAction
    ];
  }

  getFooterCommonFields(label = '', headerField = '', formatType = ''): any[] {
    let footerRow = [];
    this.headers.forEach((element, index) => {
      if (index === 0) {
        let row = { colspan: element.colspan, label, formatType: '' };
        footerRow.push(row);
      } else {
        let labelValue = (this.experienceSumData[headerField]) ? this.experienceSumData[headerField] : 0;
        
        const hasCurrentPlans = this.experienceSumData?.currentPlanList?.length > 0;
        
        if (headerField === 'experienceOnlyRateActionPercent' && !hasCurrentPlans) {
          labelValue = 'NA';
          formatType = 'string';
        } else {
          let rates = this.experienceSumData?.['tierWiseExperienceOnlyMonthlyTotal']?.[this.experienceSumData['outputTier'] + "-tier"];
          if (!StringUtils.isUndefined(rates)) {
            if (headerField === 'experienceOnlyRateActionPercent')
              labelValue = (rates?.tierTotals && rates?.tierTotals?.['rateAction']) ? rates.tierTotals['rateAction'] : 0;
            if (headerField === 'experienceOnlyTotalMonthlyPremium')
              labelValue = (rates?.tierTotals && rates?.tierTotals?.['monthlyPremium']) ? rates.tierTotals['monthlyPremium'] : 0;
          }
        }
        
        let row = { colspan: element.colspan, label: labelValue, formatType };
        footerRow.push(row);
      }
    });
    return footerRow;
  }

  getRoundedValue(val, formatType = ''): any {
    let numExp = /^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/;
    // check is Number
    if (numExp.test(val) && formatType !== 'string') {
      val = parseFloat(val);
      if (formatType === 'flat-dollar') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'),
          undefined, '1.2-2');
      } else if (formatType === 'percent') {
        return formatPercent(val, this.locale, '1.0-2');
      } else {
        return formatNumber(val, this.locale, '1.0-2');
      }
    } else {
      return (val) ? val : '';
    }
  }
}
