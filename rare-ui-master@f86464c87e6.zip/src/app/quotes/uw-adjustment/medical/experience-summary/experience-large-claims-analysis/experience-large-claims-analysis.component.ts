import { Component, OnInit, Input, Inject, LOCALE_ID } from '@angular/core';
import { formatCurrency, getCurrencySymbol, formatNumber, formatPercent, DatePipe } from '@angular/common';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: 'app-experience-large-claims-analysis',
  templateUrl: './experience-large-claims-analysis.component.html',
  styleUrls: ['./experience-large-claims-analysis.component.css'],
  standalone: false,
})
export class ExperienceLargeClaimsAnalysisComponent implements OnInit {
  @Input() experienceSumData: any;
  @Input() opportunityData: any;
  @Input() alternateQuote: boolean;
  @Input() LGFItoSGAbfCrossSelling: boolean;
  headers = [];
  footers = [];
  largeClaimantsAnalysis = [];
  claimSummary = {};

  constructor(
    @Inject(LOCALE_ID) private locale: string,
    private datePipe: DatePipe
  ) {}

  ngOnInit() {
    this.initializeComponentVariables();
  }

  initializeComponentVariables() {
    if (this.opportunityData?.fundingType == 'FI') {
      this.largeClaimantsAnalysis = this.experienceSumData['largeClaimantDatasAboveThreshold'];
      this.largeClaimantsAnalysis.forEach((claimants) => {
        this.experienceSumData['experiencePeriods'].forEach((expPeriods) => {
          if (claimants.periodID == expPeriods.periodID) {
            claimants['periodStartDate'] = this.datePipe.transform(expPeriods.periodStartDate, 'MM/dd/yyyy');
            claimants['periodEndDate'] = this.datePipe.transform(expPeriods.periodEndDate, 'MM/dd/yyyy');
          }
        });
      });
      this.headers = [...this.getFirstFieldHeader()];
      this.headers.forEach((keys, index) => {
        if (StringUtils.isEqual(keys['field'], 'claimsOverSSL')) {
          this.headers.splice(index, 1);
        }
        if (StringUtils.isEqual(keys['field'], 'subscriberID')) {
          delete this.headers[index]['headerTooltip'];
        }
        if (StringUtils.isEqual(keys['field'], 'periodStartDate')) {
          this.headers[index].label = 'Exp From';
        }
        if (StringUtils.isEqual(keys['field'], 'periodEndDate')) {
          this.headers[index].label = 'Exp To';
        }
      });
      this.getFIFooters();
    } else {
      this.claimSummary = this.experienceSumData?.contractPeriodSummaryMap[1]?.claimSummary || {};
      this.largeClaimantsAnalysis = (this.claimSummary && this.claimSummary['largeClaimantsAnalysis']) || [];
      this.largeClaimantsAnalysis.forEach((claimants) => {
        let date = new Date(this.claimSummary['periodStartDate']);
        date.setFullYear(date.getFullYear() + 1);
        date.setDate(date.getDate() - 1);
        claimants['periodStartDate'] = this.datePipe.transform(this.claimSummary['periodStartDate'], 'MM/dd/yyyy');
        claimants['periodEndDate'] = this.datePipe.transform(date, 'MM/dd/yyyy');
      });
      this.headers = [...this.getFirstFieldHeader()];
      this.headers.forEach((keys, index) => {
        if (StringUtils.isEqual(keys['field'], 'excessAboveThreshold')) {
          this.headers.splice(index, 1);
        }
        if (StringUtils.isEqual(keys['field'], 'periodEndDate')) {
          this.headers.splice(index, 1);
        }
        if (StringUtils.isEqual(keys['field'], 'periodStartDate')) {
          this.headers[index].label = 'Claims Starting From';
        }
      });
      this.getFooters();
    }
  }

  getFirstFieldHeader(): any[] {
    let firstHeader = [
      {
        label: 'Subscriber #',
        field: 'subscriberID',
        formatType: 'string',
        headerTooltip: `Large Claimants with SSL-${this.getRoundedValue(this.experienceSumData?.largeClaimantSSLLimit, 'flat-dollar-zero-decimal')}`
      },
      {
        label: 'Plan Year From ',
        field: 'periodStartDate',
        formatType: 'string'
      },
      {
        label: 'Plan Year To',
        field: 'periodEndDate',
        formatType: 'string'
      },
      {
        label: 'Active/Cancelled',
        field: 'activeStatus',
        formatType: 'string'
      },
      {
        label: 'Emp/Dep',
        field: 'relationType',
        formatType: 'string'
      },
      {
        label: 'Total Amount',
        field: 'totalInputClaims',
        formatType: 'flat-dollar'
      },
      {
        label: 'Amount over SSL',
        field: 'claimsOverSSL',
        formatType: 'flat-dollar'
      },
      {
        label: 'Tot Amt over Threshold',
        field: 'excessAboveThreshold',
        formatType: 'flat-dollar'
      },
      {
        label: 'Diagnosis',
        formatType: 'flat-dollar',
        headerClass: 'w-28'
      }
    ];
    return firstHeader;
  }

  getTooltipText(fieldName: string = '', idx) {
    var tooltip =
      'Medical: ' +
      this.getRoundedValue(this.largeClaimantsAnalysis[idx]['inputMedicalClaims'] || 0, 'flat-dollar') +
      '\n RX: ' +
      this.getRoundedValue(this.largeClaimantsAnalysis[idx]['inputRXClaims'] || 0, 'flat-dollar');
    var toolTipForTotAmtOverThreshold =
      'Medical: ' +
      this.getRoundedValue(this.largeClaimantsAnalysis[idx]['proratedMedicalClaims'] || 0, 'flat-dollar') +
      '\n RX: ' +
      this.getRoundedValue(this.largeClaimantsAnalysis[idx]['proratedRXClaims'] || 0, 'flat-dollar');
    var toolTipForTotAmtOverSSL =
      'Medical: ' +
      this.getRoundedValue(this.largeClaimantsAnalysis[idx]['proratedMedicalClaims'] || 0, 'flat-dollar') +
      '\n RX: ' +
      this.getRoundedValue(this.largeClaimantsAnalysis[idx]['proratedRXClaims'] || 0, 'flat-dollar');
    if (fieldName == 'Total Amount') {
      return tooltip;
    } else if (fieldName == 'Tot Amt over Threshold') {
      return toolTipForTotAmtOverThreshold;
    } else if (fieldName == 'Amount over SSL') {
      return toolTipForTotAmtOverSSL;
    }
  }
  getFooters() {
    this.footers = [
      {
        label: 'Total',
        formatType: 'string',
        colspan: 4
      },
      {
        label: this.getTotalFooter('totalAmount'),
        formatType: 'flat-dollar'
      },
      {
        label: this.getTotalFooter('amountOverSSL'),
        formatType: 'flat-dollar'
      }
    ];
  }

  getFIFooters() {
    this.footers = [
      {
        label: 'Total',
        formatType: 'string',
        colspan: 5
      },
      {
        label: this.getTotalFooter('totalAmount'),
        formatType: 'flat-dollar'
      },
      {
        label: this.getTotalFooter('totalAmountOverThreshold'),
        formatType: 'flat-dollar'
      }
    ];
  }
  getTotalFooter(colName = '') {
    if (colName === 'amountOverSSL') {
      let totalLargeClaimantsOverSSL = this.claimSummary['totalLargeClaimantsOverSSL'] || 0;
      return this.getRoundedValue(totalLargeClaimantsOverSSL, 'flat-dollar');
    } else if (colName === 'totalAmount') {
      return this.largeClaimantsAnalysis.reduce((total, currenVal) => {
        return (currenVal['totalInputClaims'] || 0) + total;
      }, 0);
    } else if (colName === 'totalAmountOverThreshold') {
      return this.largeClaimantsAnalysis.reduce((total, currenVal) => {
        return (currenVal['excessAboveThreshold'] || 0) + total;
      }, 0);
    }
  }

  getRoundedValue(val, formatType = ''): any {
    let numExp = /^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/;
    // check is Number
    if (numExp.test(val) && formatType !== 'string') {
      val = parseFloat(val);
      if (formatType === 'flat-dollar') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      } else if (formatType === 'flat-dollar-zero-decimal') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.0-0');
      } else if (formatType === 'percent') {
        return formatPercent(val, this.locale, '1.0-2');
      } else {
        return formatNumber(val, this.locale, '1.0-2');
      }
    } else {
      return val ? val : '-';
    }
  }

  isEmptyValue(value) {
    return value === null || value === undefined || value === '' || value === 'null';
  }

  getClaimsBasisTitle() {
    let claimBasis = this.experienceSumData?.claimsBasis;
    if (claimBasis === 'Incurred' && !((this.alternateQuote && StringUtils.isEqual(this.opportunityData?.fundingType, CommonConstants.ABF)) || (this.LGFItoSGAbfCrossSelling))) {
      return (
        claimBasis +
        ', Threshold : ' +
        formatCurrency(this.experienceSumData?.thresholdLevel, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2')
      );
    }
    return claimBasis;
  }
}
