import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { CommonService, PrintExhibitService } from 'src/app/shared/services';
import { StringUtils } from "src/app/shared/utils/string-utils";

@Component({
  selector: "app-experience-summary-modal",
  templateUrl: "./experience-summary.component.html",
  styleUrls: ["./experience-summary.component.css"],
  standalone: false
})

export class ExperienceSummaryModalComponent implements OnInit {
  @Input() experienceSumData: any;
  @Input() opportunityData: any;
  @Input() displayModal: boolean;
  @Input() alternateQuote: boolean;
  @Input() LGFItoSGAbfCrossSelling: boolean;
  @Input() showABFCompAdj: boolean = false;
  @Input() hideRollingLossRatio: boolean;
  @Input() isABFtoABFAlternateRenewal: boolean;
  @Output() disableDisplayModal = new EventEmitter<boolean>();
  @Input() medicalInputTier:number;
  @Input() isCrossSelled: boolean;
  @Input() isSGMarketSegment: boolean;
  @Input() opportunityType: string;
  @Input() estimatedClaimsObj: any;
  @Input() quoteDetail: any;

  isViewCalc: boolean = false;
  accordionTab = {
    currentRates: true,
    manualClaimCost: true,
    curvEstimatedClaimsCost: true,
    claimsOnlyRates: true,
    experienceClaimCost: true,
    largeClaimsAnalysis: true,
    lossRatios: true,
    autorunBatchHistory: true
  }
  disablePrintIcon:boolean = false;
  isNewBusiness: boolean;
  newBusinessCurrentRatesEnabled: boolean;

  constructor(
    private commonService: CommonService,
    private peService : PrintExhibitService, private commonQuoteService: CommonQuoteService
  ) {}

  ngOnInit() { 
    this.isNewBusiness = StringUtils.isEqual(this.opportunityType, CommonConstants.NEW_BUSINESS_LOCAL);  
    if(this.isNewBusiness)  {
      this.disablePrintIcon = true;
    } 
   this.newBusinessCurrentRatesEnabled = this.commonService.getNBCurrentRatesEnabled();
  }

  ngOnChanges(): void {
    if (this.opportunityData.fundingType === 'ABF' && this.experienceSumData?.['outputTier'] !== undefined
       && this.experienceSumData?.['outputTier']?.toString() !== '4' && this.isSGMarketSegment && this.medicalInputTier !== this.experienceSumData?.['outputTier']) {
      this.disablePrintIcon = true;
    }
  }

  showCurrentRateTab() {
    if (!this.isNewBusiness) {
      return true;
    } else if (this.isNewBusiness && this.quoteDetail['groupExperienceSummary'] && this.experienceSumData?.currentPlanList) {
      if (Array.isArray(this.experienceSumData.currentPlanList) && this.experienceSumData.currentPlanList.length > 0 && this.isNewBusiness && this.newBusinessCurrentRatesEnabled) {
        return true;
      } else {
        return false;
      }
    } 
  }

  disableModal() {
    this.disableDisplayModal.emit(false);
    this.accordionTab = {
      currentRates: true,
      manualClaimCost: true,
      curvEstimatedClaimsCost: true,
      claimsOnlyRates: true,
      experienceClaimCost: true,
      largeClaimsAnalysis: true,
      lossRatios: true,
      autorunBatchHistory: true
    };
  }

  printExpSumm() {
    if(this.disablePrintIcon){
      return;
    }
    this.disablePrintIcon = true;
    let requestData = {
      opportunityID:  (this.opportunityData.opportunityID || ''),
      quoteHeaderID: (this.opportunityData.quoteHeaderID || ''),
      fundingType: (this.opportunityData.fundingType || ''),
      lob: (this.opportunityData.lob || ''),
      ratingTransID: (this.opportunityData.ratingTransID || ''),
      outputTier:this.experienceSumData['outputTier'].toString(),
      opportunityType: (this.opportunityType || '')
    }
    this.commonQuoteService.printRenewalExperienceSummary(requestData).subscribe(response => {
      if (response.status === 200) {
        let processId = response.body.processId;
        var source = this.commonService.listenForStream(processId);
        source.addEventListener("SEND_EXHIBIT_TO_UI", (message: any) => {
          let eventData = JSON.parse(message.data);
          let fileExt = '.xlsx';
          CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet"+ fileExt) ;
          let fileName = this.commonService.getExportFilename();
          let contentData = eventData.payload.contentData;
          const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
        });
        source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
          source.close();
          this.commonQuoteService.cleanUpSSEEvents(processId);
          this.disablePrintIcon = false;
        });
        source.addEventListener('FAILED', (message: any) => {
          source.close();
          this.disablePrintIcon = false;
          this.commonQuoteService.cleanUpSSEEvents(processId);
          alert("Failed to download experience summary.");
        });
      }
    },
      error => {
        this.disablePrintIcon = false;
        alert("Error while downloading experience summary.");
    });
  }

  isAutoRunBatchEnabled() {
    return this.commonService.isAutoRunBatchEnabled;
  }

  showEnrollmentMismatch(): boolean {
    const currentEnrollment = this.getCurrentPlanEnrollment();
    const proposedEnrollment = this.getProposedPlanEnrollment();
    return currentEnrollment !== proposedEnrollment && currentEnrollment > 0 && proposedEnrollment > 0;
  }

  getCurrentPlanEnrollment(): number {
    const currentPlanList = this.experienceSumData?.currentPlanList || [];
    return currentPlanList.reduce((sum, plan) => {
      const tierMap = plan.tierSubscriberLivesMap;
      if (!tierMap) return sum;
      
      // Sum all tier counts (use the tier that matches outputTier if available, otherwise sum all)
      const outputTier = this.experienceSumData?.outputTier || this.experienceSumData?.inputTier || 4;
      const tierKey = outputTier + '-tier';
      const tierData = tierMap[tierKey];
      
      if (tierData) {
        return sum + (tierData.eeCount || 0) + (tierData.esCount || 0) + 
               (tierData.e1Count || 0) + (tierData.efCount || 0) + 
               (tierData.ecCount || 0) + (tierData.ekCount || 0);
      }
      return sum;
    }, 0);
  }

  getProposedPlanEnrollment(): number {
    const proposedPlanList = this.experienceSumData?.proposedPlanList || [];
    return proposedPlanList.reduce((sum, plan) => {
      const tierMap = plan.tierSubscriberLivesMap;
      if (!tierMap) return sum;
      
      // Sum all tier counts (use the tier that matches outputTier if available, otherwise sum all)
      const outputTier = this.experienceSumData?.outputTier || this.experienceSumData?.inputTier || 4;
      const tierKey = outputTier + '-tier';
      const tierData = tierMap[tierKey];
      
      if (tierData) {
        return sum + (tierData.eeCount || 0) + (tierData.esCount || 0) + 
               (tierData.e1Count || 0) + (tierData.efCount || 0) + 
               (tierData.ecCount || 0) + (tierData.ekCount || 0);
      }
      return sum;
    }, 0);
  }

  hasLargeClaimants(): boolean {
    if (!this.experienceSumData) return false;
    
    if (this.experienceSumData.largeClaimantDatasAboveThreshold?.length > 0) {
      return true;
    }
    
    if (this.experienceSumData.contractPeriodSummaryMap?.[1]?.claimSummary?.largeClaimantsAnalysis) {
      return true;
    }
    
    return false;
  }
  
}
