import { formatCurrency, formatDate, formatNumber, formatPercent, getCurrencySymbol } from '@angular/common';
import { Component, Inject, Input, LOCALE_ID, OnChanges, OnInit } from "@angular/core";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { ExperienceConstants } from "../experience-constants";

enum CLAIM_TABS {
  MEDICAL = 'medical',
  RX = 'rx',
  TOTAL = 'total'
}
@Component({
  selector: "app-experience-claim-cost",
  templateUrl: "./experience-claim-cost.component.html",
  styleUrls: ["./experience-claim-cost.component.css"],
  standalone: false,
})

export class ExperienceClaimCostComponent implements OnInit, OnChanges {
  @Input() experienceSumData: any;
  @Input() alternateQuote;
  experienceClaimCostMedical: any[] = [];
  experienceClaimCostRX: any[] = [];
  experienceClaimCostTotal: any[] = [];
  cols = [
    {
      label: 'Exp From',
      formatType : 'date',
      value: 'periodStartDate'
    }, {
      label: 'Exp To',
      formatType: 'date',
      value : 'periodEndDate'
    }, {
      label: 'Claims',
      formatType: 'flat-dollar',
      value: 'inputClaims'
    }, {
      label: 'Clms over Pool limit',
      formatType: 'flat-dollar',
      value: 'claimsOverPoolingLimit'
    }, {
      label: 'Net Clms',
      formatType: 'flat-dollar',
      value: 'netClaims'
    }, {
      label: 'Mem Mon',
      value: 'memberMonths'
    }, {
      label: ' IBNR Adj ',
      value: 'ibnrAdjustmentFactor',
      formatType: 'percent',
    }, {
      label: 'Incurred Clms',
      value: 'incurredClaims',
      formatType: 'flat-dollar',
    }, {
      label: 'COC Adj Factor',
      value: 'costOfCareAdjustment'
    }, {
      label: 'Adj Trend Factor',
      value: 'adjustedTrendFactor',
      formatType: 'custom'
    }, {
      label: 'Pool Charge',
      value: 'poolCharge',
      formatType: 'custom'
    }, {
      label: 'Incurr Clms PMPM by Exp Period',
      value: 'totalIncurredClaims',
      formatType: 'flat-dollar',
    }, {
      label: 'Multi Year Weighted Clms Cost PMPM',
      value: 'blendedExperienceClaimsCost',
      formatType: 'flat-dollar',
      blended: true,
      rowspan: true
    }, {
      label: 'Blended Manual/Exp Claims PMPM',
      value: 'credibleClaimCost',
      formatType: 'flat-dollar',
      blended: true,
      rowspan: true
    },
  ];

  totalCols = [
    {
     label: 'Exp From',
     formatType : 'date',
     value: 'periodStartDate'
   }, {
     label: 'Exp To',
     formatType: 'date',
     value : 'periodEndDate'
   },{
     label: 'Claims',
     formatType: 'flat-dollar',
     value: 'inputClaims'
   }, {
     label: 'Clms over Pool limit',
     formatType: 'flat-dollar',
     value: 'claimsOverPoolingLimit'
   }, {
     label: 'Net Clms',
     formatType: 'flat-dollar',
     value: 'netClaims'
   },
   {
    label: 'Mem Mon',
    value: 'memberMonths'
  }, {
    label: 'Incurred Clms',
    value: 'incurredClaims',
    formatType: 'flat-dollar',
  },
   {
     label: 'Incurr Clms PMPM by Exp Period',
     value: 'totalIncurredClaims',
     formatType: 'flat-dollar',
   }, {
     label: 'Multi Year Weighted Clms Cost PMPM',
     value: 'blendedExperienceClaimsCost',
     formatType: 'flat-dollar',
     blended: true,
     rowspan: true
   }
 ];
  activeTab: CLAIM_TABS = CLAIM_TABS.TOTAL;

  constructor(@Inject(LOCALE_ID) private locale: string) { }

  ngOnInit() {

  }

  ngOnChanges() {
    if (this.experienceSumData && StringUtils.isEqual(this.experienceSumData?.claimsBasis?.toLowerCase(), 'incurred')) {
      this.cols.forEach((keys, index) => {
        if (StringUtils.isEqual(keys['value'], 'ibnrAdjustmentFactor')) {
          this.cols.splice(index, 1);
        }
      })
    }
    if(this.experienceSumData && this.experienceSumData.experiencePeriodSummaryMap) {
      let experiencePeriodSummaryMap = Object.values(this.experienceSumData.experiencePeriodSummaryMap);
      this.experienceClaimCostMedical = experiencePeriodSummaryMap.map( data => data['medicalClaimSummary']);
      this.experienceClaimCostRX = experiencePeriodSummaryMap.map( data => data['rxClaimSummary']);
      this.experienceClaimCostTotal = experiencePeriodSummaryMap.map( data => data['rxClaimSummary']);
      if(!this.experienceClaimCostMedical.length && this.experienceClaimCostRX.length && !this.experienceClaimCostTotal.length) {
        this.activeTab = CLAIM_TABS.RX;
      }else if(this.experienceClaimCostMedical.length && !this.experienceClaimCostRX.length && !this.experienceClaimCostTotal.length) {
        this.activeTab = CLAIM_TABS.MEDICAL;
      }else {
        this.activeTab = CLAIM_TABS.TOTAL;
      }
    }
  }

  public get claimTabs(): typeof CLAIM_TABS {
    return CLAIM_TABS;
  }

  getTooltipText(fieldName: string = '') {
    switch(fieldName) {
      case 'memberMonths':
        if (this.activeTab === CLAIM_TABS.RX  && this.experienceSumData['rxExperienceSummary'] && !this.isEmptyValue(this.experienceSumData['rxExperienceSummary']['credibilityFactor']) ) {
          let credibilityFactor =  this.experienceSumData['rxExperienceSummary']['credibilityFactor'];
          let convertedCF = formatPercent(parseFloat(credibilityFactor), this.locale, "1.0-0")
          return 'Credibility - ' + convertedCF;
        } else if (this.activeTab === CLAIM_TABS.MEDICAL && this.experienceSumData['medicalExperienceSummary'] && !this.isEmptyValue(this.experienceSumData['medicalExperienceSummary']['credibilityFactor'])) {
          let credibilityFactor =  this.experienceSumData['medicalExperienceSummary']['credibilityFactor'];
          let convertedCF = formatPercent(parseFloat(credibilityFactor), this.locale, "1.0-0")
          return 'Credibility - ' + convertedCF;
        } else {
          return '';
        }
      case 'netClaims':
        let experienceClaimCost = this.getTableData();
        let filterClaimCost = experienceClaimCost.filter( claim => {
          return Object.keys(claim['adjustmentNamesAndValues']).length;
        });
        return filterClaimCost.length > 0 ? 'Includes Embedded Vision Claims' : '';
      case 'claimsOverPoolingLimit':
        return 'Pooling Level - ' + this.experienceSumData['poolingLevel'];
      case ExperienceConstants.CREDIBLE_CLAIM_COST:
        if (StringUtils.isEqual(this.activeTab, CLAIM_TABS.MEDICAL) && StringUtils.isEqual(this.experienceSumData[ExperienceConstants.BLUECARD_FEE_TYPE], ExperienceConstants.RET) && !this.isEmptyValue(this.experienceSumData[ExperienceConstants.BLUECARD_FEE_TYPE]))
          return ExperienceConstants.RETENTION_TOOPTIP_TEXT + this.formatValue(this.experienceSumData?.[ExperienceConstants.EXP_PERIOD_SUMMARY_MAP]?.[1]?.[ExperienceConstants.MED_CLAIM_SUMMARY]?.[ExperienceConstants.BLUECARD_RETENTION_PMPM], 'flat-dollar') + ExperienceConstants.PMPM;
        else
          return false;
      default:
        return false;
    }
  }

  isEmptyValue(value) {
    return value === null || value === undefined || value === "";
  }

  isTabActive(plan: CLAIM_TABS) {
    this.activeTab = plan;
  }

  getTableData(): any[] {
    if (this.activeTab === CLAIM_TABS.RX) {
      return this.experienceClaimCostRX;
    } else if (this.activeTab === CLAIM_TABS.MEDICAL) {
      return this.experienceClaimCostMedical;
    } else if (this.activeTab === CLAIM_TABS.TOTAL) {
      return this.experienceClaimCostTotal;
    } else {
      return [];
    }
  }
  getTableHeaders(): any[] {
    if (this.activeTab === CLAIM_TABS.RX || this.activeTab === CLAIM_TABS.MEDICAL) {
      return this.cols;
    } else if (this.activeTab === CLAIM_TABS.TOTAL) {
      return this.totalCols;
    } else {
      return [];
    }
  }

  getRowSpan() {
    return (this.activeTab === CLAIM_TABS.RX) ? this.experienceClaimCostRX.length : (this.activeTab === CLAIM_TABS.MEDICAL) ?this.experienceClaimCostMedical.length : this.experienceClaimCostTotal.length;
  }

  formatValue(value = '', formatType = '' ,subField?): any {
    let result = '-';
    switch(formatType) {
      case 'flat-dollar':
        let val1 = (isNaN(parseFloat(value))) ? 0 : parseFloat(value);
        result = formatCurrency( val1, this.locale, getCurrencySymbol('USD', 'wide'));
        break;
      case 'percent':
        let val2 = (isNaN(parseFloat(value))) ? 0 : parseFloat(value);
        result = formatPercent( val2, this.locale, "1.0-2");
        break;
      case 'date':
        if(value) {
          result = formatDate(value, 'MM/dd/yyyy', this.locale);
        }
        break;
      case 'roundOff':
        let val3 = (isNaN(parseFloat(value))) ? 0 : parseFloat(value);
        result = formatNumber( val3, this.locale,  '1.2-2');
        break;
      case 'custom':
        if (subField == 'adjustedTrendFactor') {
          result = this.getFourDecimalValueFactor(value);
        }
        if (subField == 'poolCharge') {
          let chargeType = this.experienceClaimCostMedical[0]['poolChargeType']
          if (chargeType == 'Percent') {
            result = this.getFourDecimalValue(value);
          } if (chargeType == 'PMPM') {
            let val1 = (isNaN(parseFloat(value))) ? 0 : parseFloat(value);
            if (val1 == 0) {
              result = formatCurrency(val1, this.locale, getCurrencySymbol('USD', 'wide'));
            }
            else {
              result = formatCurrency(val1, this.locale, getCurrencySymbol('USD', 'wide'), "", "1.4-4");
            }
          }
        }
        break;
      default:
        result = value;
        break;
    }
    return result;
  }
  getFourDecimalValue(value) {
    let val2 = (isNaN(parseFloat(value))) ? 0 : parseFloat(value);
    let finalval = (Number(value*10) - 1*10)/10;
    if (val2 == 0) {
      return val2 + '%';
    }
    else {
      finalval = finalval * 1000000;
      return (parseInt(finalval.toString()) / 10000) + '%';
    }
  }
  getFourDecimalValueFactor(value) {
    let val2 = (isNaN(parseFloat(value))) ? 0 : parseFloat(value);
    if (val2 == 0) {
      return val2.toString();
    }
    else {
      val2 = val2 * 10000;
      return (parseInt(val2.toString()) / 10000).toString();
    }
  }
  getBlendedClaimCost(subField: string, prefix = ''): any {
    let field = (this.activeTab === CLAIM_TABS.RX) ? 'rxExperienceSummary' : 'medicalExperienceSummary';
    if ((this.activeTab === CLAIM_TABS.MEDICAL || this.activeTab === CLAIM_TABS.RX) && this.experienceSumData && this.experienceSumData[field] && this.experienceSumData[field][subField]) {
      let value = this.experienceSumData[field][subField];
      return this.formatValue(value, prefix);
    } else if(this.activeTab === CLAIM_TABS.TOTAL && this.experienceSumData &&  (( this.experienceSumData  ['medicalExperienceSummary'] && this.experienceSumData['medicalExperienceSummary'][subField]) || (
      this.experienceSumData['rxExperienceSummary'] && this.experienceSumData['rxExperienceSummary'][subField])) ) {
        let value = (this.experienceSumData['medicalExperienceSummary'][subField] || 0) + (this.experienceSumData['rxExperienceSummary'][subField] || 0);
        return this.formatValue(value, prefix);
    } else {
      return '$0';
    }
  }

  getIncurClmTooltipCond(subField: string, index: any) {
    let memMonths = 0;
    if(this.activeTab === CLAIM_TABS.MEDICAL || this.activeTab === CLAIM_TABS.RX) {
      let experienceClaimCost = (this.activeTab === CLAIM_TABS.RX) ? this.experienceClaimCostRX : this.experienceClaimCostMedical;
      memMonths = experienceClaimCost[index]['memberMonths']
    } else if(this.activeTab === CLAIM_TABS.TOTAL) {
      memMonths = this.experienceClaimCostMedical[index]['memberMonths'] + this.experienceClaimCostRX[index]['memberMonths'];
    }
    return subField === 'totalIncurredClaims' && memMonths > 0 ? true : false;
  }

  getTableBody(subField: string, formatType: string = '',index: any) {
    if(this.activeTab === CLAIM_TABS.RX) {
      if (subField === 'ibnrAdjustmentFactor') {
        let calcValue = ( this.experienceClaimCostRX[index]['ibnrErollmentAdjustmentFactor'] * (1 + this.experienceClaimCostRX[index][subField])-1);
        return this.formatValue(calcValue.toString(), formatType, subField);
    }
     return this.formatValue( this.experienceClaimCostRX[index][subField], formatType,subField);
    } else if(this.activeTab === CLAIM_TABS.MEDICAL) {
      if (subField === 'ibnrAdjustmentFactor') {
          let calcValue = (this.experienceClaimCostMedical[index]['ibnrErollmentAdjustmentFactor'] * (1 + this.experienceClaimCostMedical[index][subField]) - 1);
          return this.formatValue(calcValue.toString(), formatType, subField);
      }

      return this.formatValue( this.experienceClaimCostMedical[index][subField], formatType,subField);
    } else {
      let commonSubField = ['periodStartDate','periodEndDate', 'memberMonths'];
      if(commonSubField.includes(subField)) {
        let value = this.experienceClaimCostMedical[index][subField] || this.experienceClaimCostRX[index][subField];
        return (formatType) ? this.formatValue(value, formatType) : value;
      } else {
        let value = this.experienceClaimCostMedical[index][subField] + this.experienceClaimCostRX[index][subField];
        return this.formatValue(value, formatType);
      }
    }
  }

  getIncurrClmTooltipTxt(subField: string, index: any) {
    if (StringUtils.isEqual(subField, ExperienceConstants.INPUT_CLAIMS) && StringUtils.isEqual(this.experienceSumData[ExperienceConstants.BLUECARD_FEE_TYPE], ExperienceConstants.CLM)) {
      if (!StringUtils.isEqual(this.activeTab, CLAIM_TABS.RX))
        return ExperienceConstants.CLAIM_TOOLTIP_MSG + this.formatValue(this.experienceClaimCostMedical[index][ExperienceConstants.BLUECARD_CLAIM_AMOUNT], 'flat-dollar');
    }
    else{
      if(!this.getIncurClmTooltipCond(subField, index)){
        return false;
      }
      let multiYearWeight = '';
      if(this.activeTab === CLAIM_TABS.RX) {
        multiYearWeight = this.experienceClaimCostRX[index]['multiYearWeight'];
      } else if(this.activeTab === CLAIM_TABS.MEDICAL) {
        multiYearWeight = this.experienceClaimCostMedical[index]['multiYearWeight'];
      } else {
        multiYearWeight = this.experienceClaimCostMedical[index]['multiYearWeight'] || this.experienceClaimCostRX[index]['multiYearWeight'];
      }
      return `Multi Year Weight - ${this.formatValue(multiYearWeight, 'percent')}`;
    }
  }
  stringConversion(value)
  {
    return StringUtils.convertToString(value);
  }

  getIBNRAndEnrollTooltipCond(subField: string, index: number): boolean {
    let memMonths = 0;
    if(this.activeTab === CLAIM_TABS.MEDICAL || this.activeTab === CLAIM_TABS.RX) {
      let experienceClaimCost = (this.activeTab === CLAIM_TABS.RX) ? this.experienceClaimCostRX : this.experienceClaimCostMedical;
      memMonths = experienceClaimCost[index]['memberMonths']
    }
    return subField === 'ibnrAdjustmentFactor' ? true : false;
  }
  
  getIBNRAndEnrollTooltipText(subField: string, index: number): string | false {
    if (!this.getIBNRAndEnrollTooltipCond(subField, index)) {
      return false;
    }
  
    const dataSource = this.activeTab === CLAIM_TABS.RX
      ? this.experienceClaimCostRX
      : this.experienceClaimCostMedical;
  
      const ibnrAdjustmentFactor = dataSource[index]?.ibnrAdjustmentFactor !== undefined
      ? parseFloat(dataSource[index].ibnrAdjustmentFactor.toFixed(4))
      : 'N/A';
  
    const ibnrEnrollmentAdjustmentFactor = dataSource[index]?.ibnrErollmentAdjustmentFactor !== undefined
      ? parseFloat(dataSource[index].ibnrErollmentAdjustmentFactor.toFixed(6))
      : 'N/A';
    return `IBNR Enrl Adj Fctr: ${ibnrEnrollmentAdjustmentFactor}\nIBNR Fctr: ${ibnrAdjustmentFactor}`;
  }
}
