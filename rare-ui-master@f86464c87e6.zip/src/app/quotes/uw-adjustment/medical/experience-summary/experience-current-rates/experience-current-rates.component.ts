import { Component, OnInit, Input, Inject, LOCALE_ID } from '@angular/core';
import { formatCurrency, getCurrencySymbol, formatNumber, formatPercent } from '@angular/common';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
@Component({
  selector: 'app-experience-current-rates',
  templateUrl: './experience-current-rates.component.html',
  styleUrls: ['./experience-current-rates.component.css'],
  standalone: false,
})
export class ExperienceCurrentRatesComponent implements OnInit {
  @Input() selectedTab: string;
  @Input() experienceSumData: any;
  @Input() medicalInputTier: number;
  @Input() alternateQuote: boolean;
  @Input() LGFItoSGAbfCrossSelling: boolean;
  @Input() showABFCompAdj: boolean = false;
  @Input() isNewBusiness: boolean;
  @Input() quoteDetail: any;

  headers = [];
  footers = [];
  tierDescription: any = {
    '1-Tier': [{ label: 'EE' }],
    '2-Tier': [{ label: 'EE' }, { label: 'EF' }],
    '3-Tier': [{ label: 'EE' }, { label: 'E1' }, { label: 'EF' }],
    '4-Tier': [{ label: 'EE' }, { label: 'ES' }, { label: 'EC' }, { label: 'EF' }],
    '5-Tier': [{ label: 'EE' }, { label: 'ES' }, { label: 'EK' }, { label: 'EC' }, { label: 'EF' }]
  };
  subscriberMemberTierKey = {
    EE: 'eeCount',
    EF: 'efCount',
    EK: 'ekCount',
    ES: 'esCount',
    EC: 'ecCount',
    E1: 'e1Count'
  };

  tiredRatesKey = {
    EE: 'single',
    EF: 'family',
    EK: 'eeChild',
    ES: 'eeSpouse',
    EC: 'eeChildren',
    E1: 'eeOne'
  };
  fundingType: string = 'FI';
  planList: any = [];
  tiredRateHeaders = [];
  enrollmentMismatchMsg: string;
  missingEnrollmentOrRatesMsg: string;

  constructor(@Inject(LOCALE_ID) private locale: string) {}

  ngOnInit() {
    this.initializeComponentVariables();
  }

  initializeComponentVariables() {
    this.fundingType = this.experienceSumData['fundingType'];
    this.headers = [...this.getFirstFieldHeader(), ...this.getSubscriberMemberHeader(), ...this.getMiddleFieldHeader(), ...this.getLastFieldHeader()];
    this.getFooters();
    this.getCurrentRateErrorMsg();
  }

  getCurrentRateErrorMsg() {
    if(this.experienceSumData?.enrollmentMismatch || this.experienceSumData?.missingEnrollmentOrRates) {
    this.enrollmentMismatchMsg = this.experienceSumData?.enrollmentMismatchMessage;
    this.missingEnrollmentOrRatesMsg = this.experienceSumData?.missingEnrollmentOrRatesMessage;
    }
  }

  getFirstFieldHeader(): any[] {
    let planLabel = this.selectedTab === 'manualClaimCost' ? 'Proposed plans' : 'Current Plans';
    this.planList = this.experienceSumData
      ? StringUtils.isEqual('manualClaimCost', this.selectedTab)
        ? this.experienceSumData.proposedPlanList
        : this.experienceSumData.currentPlanList
      : [];
    let planField = 'planRateData';
    let firstHeader = [
      {
        label: '',
        subHeaders: [
          { label: planLabel, field: 'index' },
          { label: 'Contract code', field: 'contractCode' },
          { label: 'Plan Name', field: 'planName', class: 'w-30' }
        ],
        field: planField,
        colspan: 3,
        formatType: 'string'
      }
    ];
    return firstHeader;
  }

  getSubscriberMemberHeader(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let colspan = this.medicalInputTier;
    let subHeaders = JSON.parse(JSON.stringify(this.tierDescription[`${colspan}-Tier`]));
    subHeaders.forEach((element) => {
      element['field'] = this.subscriberMemberTierKey[element['label']];
    });
    let subscriberMemberHeader = [
      { colspan, label: 'Subscriber', subHeaders, field: 'subscriberCount' },
      { colspan, label: 'Members', subHeaders, field: 'memberCount' }
    ];

    return subscriberMemberHeader;
  }

  getMiddleFieldHeader(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let field = 'planRateData';
    let colspan = this.medicalInputTier;
    let subHeaders = JSON.parse(JSON.stringify(this.tierDescription[`${colspan}-Tier`]));
    subHeaders.forEach((element) => {
      element['field'] = this.tiredRatesKey[element['label']];
    });
    if ((this.isNewBusiness || this.fundingType === 'FI') || (StringUtils.isEqual(this.fundingType, CommonConstants.ABF) && !this.showABFCompAdj) || this.LGFItoSGAbfCrossSelling) {
      this.tiredRateHeaders = [{ colspan, label: 'Total Rates', subHeaders, field: `${field}.tieredRates.tierTotals`, formatType: 'flat-dollar' }];
      if(this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT') {
        const modifiedSubHeaders = subHeaders.filter(sh => sh.label === 'EE' || sh.label === 'EC').map(sh => ({
          ...sh,
          label: sh.label === 'EE' ? 'Adult' : 'Child'
        }));
        this.tiredRateHeaders = [{ colspan: modifiedSubHeaders.length, label: 'Total Rates', subHeaders: modifiedSubHeaders, field: `${field}.tieredRates.tierTotals`, formatType: 'flat-dollar' }];
      }
    } else {
      this.tiredRateHeaders = [
        { colspan, label: 'Total Rates', subHeaders, field: `${field}.tieredRates.tierTotals`, formatType: 'flat-dollar' },
        { colspan, label: 'ASO Admin', subHeaders, field: `${field}.tieredRates.asoAdminFee`, formatType: 'flat-dollar' },
        { colspan, label: 'SSL Rates', subHeaders, field: `${field}.tieredRates.sslPremium`, formatType: 'flat-dollar' },
        { colspan, label: 'ASL Rates', subHeaders, field: `${field}.tieredRates.aslPremium`, formatType: 'flat-dollar' },
        { colspan, label: 'Max Claims fund', subHeaders, field: `${field}.tieredRates.maxPaidClaim`, formatType: 'flat-dollar' },
        { colspan, label: 'Terminal Liability', subHeaders, field: `${field}.tieredRates.terminalLiability`, formatType: 'flat-dollar' }
      ];
    }
    return this.tiredRateHeaders;
  }

  getLastFieldHeader(): any[] {
    if (this.selectedTab !== 'manualClaimCost' || this.fundingType === 'FI') {
      return [];
    }
    let commonSubHeaders = [
      { label: 'ASO', field: 'asoAdminFee' },
      { label: 'SSL', field: 'sslPremium' },
      { label: 'ASL', field: 'aslPremium' },
      { label: 'Max claims', field: 'maxPaidClaim' },
      { label: 'TL', field: 'terminalLiability' },
      { label: 'Total', field: 'totalPremium' }
    ];
    let manualClaimHeader = [
      {
        label: 'Pure ABF Components',
        subHeaders: [...commonSubHeaders],
        field: 'pureComponentRates',
        colspan: 6,
        formatType: 'flat-dollar'
      },
      {
        label: 'Manual Gross PMPM',
        subHeaders: [{ label: 'ABF Clms cost', field: 'abfClaimsCost' }, ...commonSubHeaders],
        field: 'manualGrossPMPM',
        colspan: 7,
        formatType: 'flat-dollar'
      }
    ];
    return manualClaimHeader;
  }

  getTableData(medicalDetail, header, subHeader, index) {
    if (subHeader.field === 'index') {
      return index + 1;
    } else {
      // Condition for Manual Rate it its sub header Abf Claim Cost
      if (subHeader.field === 'abfClaimsCost') {
        let value = medicalDetail[subHeader.field] ? medicalDetail[subHeader.field] : 0;
        return this.getRoundedValue(value, header['formatType']);
      }
      let allHeaderFields = header.field.split('.');
      let value;
      allHeaderFields.forEach((field, i) => {
        if (i === 0) {
          value = medicalDetail[field] ? medicalDetail[field] : 0;
        } else {
          value = value[field] ? value[field] : 0;
        }
      });
      value = value && value[subHeader.field] ? value[subHeader.field] : 0;
      if (subHeader.field === 'planName' && value !== 0) {
        let planName = value?.split(' - ');
        value = planName.length > 1 ? planName[1] : planName[0];
      }
      if (header.label === 'Subscriber') {
        value = medicalDetail.tierSubscriberLivesMap[this.medicalInputTier + '-tier'];
        value = value && value[subHeader.field] ? value[subHeader.field] : 0;
      }
      if (header.label === 'Members') {
        value = medicalDetail.tierMemberLivesMap[this.medicalInputTier + '-tier'];
        value = value && value[subHeader.field] ? value[subHeader.field] : 0;
      }
      return this.getRoundedValue(value, header['formatType']);
    }
  }

  getFooters(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let total = [];
    let totalMontlyRates = [];
    let pureManualRateAction = [];
    let headerField = this.selectedTab === 'manualClaimCost' ? 'manualComponentRates' : 'currentComponentRates';
    totalMontlyRates = this.getFooterCommonFields('Total monthly Rates', headerField, 'flat-dollar');

    if (this.selectedTab === 'manualClaimCost') {
      pureManualRateAction = this.getFooterCommonFields('Pure manual Rate Action', 'currentToManualDiffPercent', 'percent');
    } else if (this.selectedTab !== 'manualClaimCost') {
      total = this.getCurrentFooterTotal();
    }
    if (this.isNewBusiness) {
      if (totalMontlyRates && totalMontlyRates[1].formatType === "flat-dollar" && totalMontlyRates[1].label !== "") {
        this.footers = [total, totalMontlyRates, pureManualRateAction];
      } else {
        this.footers = [total, pureManualRateAction];
      }
    } else {
      this.footers = [total, totalMontlyRates, pureManualRateAction];

    }
  }

  getFooterCommonFields(label = '', headerField = '', formatType = ''): any[] {
    let footerRow = [];
    let fields = {
      'Total Rates': 'totalPremium',
      'ASO Admin': 'asoAdminFee',
      'SSL Rates': 'sslPremium',
      'ASL Rates': 'aslPremium',
      'Max Claims fund': 'maxPaidClaim',
      'Terminal Liability': 'terminalLiability'
    };
    this.headers.forEach((element, index) => {
      if (index === 0) {
        let row = { colspan: element.colspan, label, formatType: '' };
        footerRow.push(row);
      } else if (index === 1 || index === 2) {
        let row = footerRow[0];
        row.colspan += element.colspan;
      } else {
        let subField = fields[element.label];
        let label = 0;
        if (headerField === 'currentToManualDiffPercent' && element.label === 'Total Rates') {
          label =
            this.experienceSumData['blendedCostSummary'] && this.experienceSumData['blendedCostSummary']['pureManualRateAction']
              ? this.experienceSumData['blendedCostSummary']['pureManualRateAction']
              : '';
        } else {
          label =
            this.experienceSumData['blendedCostSummary'] &&
            this.experienceSumData['blendedCostSummary'][headerField] &&
            this.experienceSumData['blendedCostSummary'][headerField][subField] != null
              ? this.experienceSumData['blendedCostSummary'][headerField][subField]
              : '';
        }
        let row = { colspan: element.colspan, label, formatType };
        footerRow.push(row);
      }
    });
    return footerRow;
  }

  getRoundedValue(val, formatType = ''): any {
    let numExp = /^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/;
    // check is Number
    if (numExp.test(val) && formatType !== 'string') {
      val = parseFloat(val);
      if (formatType === 'flat-dollar') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      } else if (formatType === 'percent') {
        return formatPercent(val, this.locale, '1.0-2');
      } else {
        return formatNumber(val, this.locale, '1.0-2');
      }
    } else {
      return val ? val : '';
    }
  }

  getCurrentFooterTotal(): any[] {
    let total = [];
    this.headers.forEach((element, index) => {
      if (index === 0) {
        let row = { colspan: element.colspan, label: 'Total', formatType: '' };
        total.push(row);
      } else if (element.label === 'Subscriber' || element.label === 'Members') {
        let row = [];
        element.subHeaders.forEach((e) => {
          row.push({ colspan: 1, label: 0, formatType: '' });
        });
        this.planList.forEach((medicalPlan) => {
          element.subHeaders.forEach((subEle, index) => {
            if (element.field === 'subscriberCount') {
              row[index].label += medicalPlan.tierSubscriberLivesMap[this.medicalInputTier + '-tier'][subEle.field];
            } else if (element.field === 'memberCount') {
              row[index].label += medicalPlan.tierMemberLivesMap[this.medicalInputTier + '-tier'][subEle.field];
            } else {
              row[index].label += medicalPlan[element.field][subEle.field];
            }
          });
        });
        total.push(...row);
      } else {
        let row = { colspan: element.colspan, label: '', formatType: '' };
        total.push(row);
      }
    });
    return total;
  }
}
