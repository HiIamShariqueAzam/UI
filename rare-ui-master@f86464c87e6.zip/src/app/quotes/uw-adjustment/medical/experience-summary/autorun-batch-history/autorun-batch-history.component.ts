import { Component, OnInit, Input, Inject, LOCALE_ID } from '@angular/core';
import { DatePipe, formatCurrency, formatNumber, formatPercent, getCurrencySymbol } from '@angular/common';
import { getABFFieldHeader, getFIFieldHeader } from 'src/app/renewals/renewals-constants';

@Component({
  selector: 'app-autorun-batch-history',
  templateUrl: './autorun-batch-history.component.html',
  styleUrls: ['./autorun-batch-history.component.css'],
  standalone: false,
})
export class AutorunBatchHistoryComponent implements OnInit {
  @Input() experienceSumData: any;
  @Input() opportunityData: any;
  @Input() alternateQuote: boolean;
  headers = [];
  footers = [];
  autoRunBatchHistory = [];
  claimSummary = {};

  constructor(
    @Inject(LOCALE_ID) private locale: string,
    private datePipe: DatePipe,
  ) {}

  ngOnInit() {
    if (this.experienceSumData['autoRunBatchExperienceSummaryDataList']) {
      this.autoRunBatchHistory = this.experienceSumData['autoRunBatchExperienceSummaryDataList'];
      this.initializeComponentVariables();
    }
  }

  initializeComponentVariables() { 
    this.autoRunBatchHistory?.forEach((history) => {
      let datePipeEn: DatePipe = new DatePipe('en-US');
      history['claimsAsOfDate'] = datePipeEn.transform(history['claimsAsOfDate'], 'MM/dd/yyyy'); 
      history['totalLargeClaims'] = history['totalLargeClaims'] ?  history['totalLargeClaims'] : '$0';
      history['totalOverSsl'] = history['totalOverSsl'] ? history['totalOverSsl'] : '$0';
      history['claimsOverThreshold'] = history['claimsOverThreshold'] ? history['claimsOverThreshold'] : '$0';
      history['surplusOrDeficit'] = history['surplusOrDeficit'] ? history['surplusOrDeficit'] : '$0';

    });
    if (this.opportunityData?.fundingType == 'FI') {
      this.headers = [...getFIFieldHeader.headers];
    } else {
      this.headers = [...getABFFieldHeader.headers];
    }
  }

  getRoundedValue(val, formatType = ''): any {
    let numExp = /^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/;
    // check is Number
    if (numExp.test(val) && formatType !== 'string') {
      val = parseFloat(val);
      if (formatType === 'flat-dollar') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      } else if (formatType === 'flat-dollar-zero-decimal') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.0-0');
      } else if (formatType === 'percent') {
        let val2 = isNaN(parseFloat(val)) ? 0 : parseFloat(val);
        return formatPercent(val2, this.locale, '1.0-2');
      } else {
        return formatNumber(val, this.locale, '1.0-2');
      }
    } else {
      return val ? val : '0';
    }
  }

}
