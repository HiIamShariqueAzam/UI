import { Component, Input, OnInit } from "@angular/core";

interface ConditionRow {
  condition: string;
  riskLevel: string;
  riskRange: string;
  subCount: number;
  estimate: string;
}

@Component({
  selector: "app-experience-curv-estimated-claim-cost",
  templateUrl: "./experience-curv-estimated-claim-cost.component.html",
  styleUrls: ["./experience-curv-estimated-claim-cost.component.css"],
  standalone: false,
})
export class ExperienceCurvEstimatedClaimCostComponent implements OnInit {
  @Input() experienceSumData: any;
  @Input() accordionTab;
  @Input() quoteDetail;

  curvRiskScore: any;
  conditionHistory: any;
  hitRate: any;
  conditions: ConditionRow[] = [];
  finalRow: any;
  totalRow: any;
  
  curvConditionalFlags: any;
  estimatedAllowedClaimsRange: any;
  hitRateValue: any;

  constructor() { }

  ngOnInit() {
    this.curvConditionalFlags = JSON.parse(this.quoteDetail?.curvConditionalFlags);
    this.estimatedAllowedClaimsRange = JSON.parse(this.quoteDetail?.estimatedAllowedClaimsRange);
    this.hitRateValue = this.quoteDetail.hitRate;

    this.initializeData();
  }

  private initializeData(): void {
    if (!this.estimatedAllowedClaimsRange) return;

    const rangeKeys = this.getRiskRanges();
    
    // Initialize CURV Risk Score (first range)
    this.curvRiskScore = {
      label: 'CURV Risk Score',
      value: this.quoteDetail?.riskScore,
      riskRange: rangeKeys[0],
      subCount: this.getSubCountForRange(rangeKeys[0]),
      estimate: this.getEstimateForRange(rangeKeys[0])
    };

    // Initialize Hit Rate (second range)
    this.hitRate = {
      label: 'Hit Rate',
      value: this.hitRateValue,
      riskRange: rangeKeys[1],
      subCount: this.getSubCountForRange(rangeKeys[1]),
      estimate: this.getEstimateForRange(rangeKeys[1])
    };

    // Initialize Condition History (third range)
    this.conditionHistory = {
      label: 'Condition History',
      riskRange: rangeKeys[2],
      subCount: this.getSubCountForRange(rangeKeys[2]),
      estimate: this.getEstimateForRange(rangeKeys[2])
    };

    // Initialize conditions array - preserve backend order
    this.conditions = [];
    if (this.curvConditionalFlags) {
      // Get condition entries in the order they appear in the backend response
      const conditionEntries = Object.entries(this.curvConditionalFlags);
      
      conditionEntries.forEach(([condition, riskLevel], index) => {
        const rangeIndex = 3 + index;
        const riskRange = rangeKeys[rangeIndex] || '';
        this.conditions.push({
          condition: condition,
          riskLevel: riskLevel as string,
          riskRange: riskRange,
          subCount: this.getSubCountForRange(riskRange),
          estimate: this.getEstimateForRange(riskRange)
        });
      });
    }

    // Initialize final row
    const finalRangeKey = rangeKeys[rangeKeys.length - 1];
    this.finalRow = {
      riskRange: finalRangeKey,
      subCount: this.getSubCountForRange(finalRangeKey),
      estimate: this.getEstimateForRange(finalRangeKey)
    };

    // Initialize total row
    this.totalRow = {
      subCount: this.getTotalSubCount(),
      estimate: this.getTotalEstimate()
    };
  }

  getRiskRanges(): string[] {
    if (!this.estimatedAllowedClaimsRange) return [];
    
    const keys = Object.keys(this.estimatedAllowedClaimsRange);
    
    // Sort keys numerically based on the starting value of the range
    return keys.sort((a, b) => {
      const startA = parseFloat(a.split(' ')[0]);
      const startB = parseFloat(b.split(' ')[0]);
      return startA - startB;
    });
  }

  getRiskRangeByIndex(index: number): string {
    const ranges = this.getRiskRanges();
    return ranges[index] || '';
  }

  getSubCountForRange(riskRange: string): number {
    if (!this.estimatedAllowedClaimsRange || !riskRange) return 0;
    const rangeData = this.estimatedAllowedClaimsRange[riskRange];
    return this.parseSubCount(rangeData);
  }

  getEstimateForRange(riskRange: string): string {
    if (!this.estimatedAllowedClaimsRange || !riskRange) return '$0';
    const rangeData = this.estimatedAllowedClaimsRange[riskRange];
    return this.parseEstimateValue(rangeData);
  }

  private parseSubCount(rangeData: string): number {
    if (rangeData && typeof rangeData === 'string') {
      const parts = rangeData.split('~');
      return parts[0] ? parseInt(parts[0], 10) : 0;
    }
    return 0;
  }

  private parseEstimateValue(rangeData: string): string {
    if (rangeData && typeof rangeData === 'string') {
      const parts = rangeData.split('~');
      const estimateValue = parts[1] ? parseInt(parts[1], 10) : 0;
      return '$' + estimateValue.toLocaleString();
    }
    return '$0';
  }

  getTotalSubCount(): number {
    if (!this.estimatedAllowedClaimsRange) return 0;
    return this.getRiskRanges().reduce((total, range) => {
      return total + this.getSubCountForRange(range);
    }, 0);
  }

  getTotalEstimate(): string {
    if (!this.estimatedAllowedClaimsRange) return '$0';
    const total = this.getRiskRanges().reduce((sum, range) => {
      const rangeData = this.estimatedAllowedClaimsRange[range];
      if (rangeData && typeof rangeData === 'string') {
        const parts = rangeData.split('~');
        const subCount = parts[0] ? parseInt(parts[0], 10) : 0;
        const estimateValue = parts[1] ? parseInt(parts[1], 10) : 0;
        return sum + (subCount * estimateValue);
      }
      return sum;
    }, 0);
    return '$' + total.toLocaleString();
  }

}
