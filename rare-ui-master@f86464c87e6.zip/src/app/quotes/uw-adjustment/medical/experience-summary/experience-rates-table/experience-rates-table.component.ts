import { Component, OnInit, Input, Inject, LOCALE_ID } from '@angular/core';
import { formatCurrency, getCurrencySymbol, formatNumber, formatPercent } from '@angular/common';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: 'app-experience-rates-table',
  templateUrl: './experience-rates-table.component.html',
  styleUrls: ['./experience-rates-table.component.css'],
  standalone: false,
})
export class ExperienceRatesTableComponent implements OnInit {
  @Input() selectedTab: string;
  @Input() experienceSumData: any;
  @Input() alternateQuote: boolean;
  @Input() LGFItoSGAbfCrossSelling: boolean;
  @Input() isABFtoABFAlternateRenewal: boolean;
  @Input() estimatedClaimsObj: any;
  @Input() isNewBusiness: boolean;
  headers = [];
  footers = [];
  tierDescription: any = {
    '1-Tier': [{ label: 'EE' }],
    '2-Tier': [{ label: 'EE' }, { label: 'EF' }],
    '3-Tier': [{ label: 'EE' }, { label: 'E1' }, { label: 'EF' }],
    '4-Tier': [{ label: 'EE' }, { label: 'ES' }, { label: 'EC' }, { label: 'EF' }],
    '5-Tier': [{ label: 'EE' }, { label: 'ES' }, { label: 'EK' }, { label: 'EC' }, { label: 'EF' }]
  };
  subscriberMemberTierKey = {
    EE: 'eeCount',
    EF: 'efCount',
    EK: 'ekCount',
    ES: 'esCount',
    EC: 'ecCount',
    E1: 'e1Count'
  };

  tiredRatesKey = {
    EE: 'single',
    EF: 'family',
    EK: 'eeChild',
    ES: 'eeSpouse',
    EC: 'eeChildren',
    E1: 'eeOne'
  };
  fundingType: string = 'FI';
  planList: any = [];
  tiredRateHeaders = [];

  constructor(@Inject(LOCALE_ID) private locale: string) {}

  ngOnInit() {
    this.initializeComponentVariables();
  }

  initializeComponentVariables() {
    this.fundingType = this.experienceSumData['fundingType'];
    this.headers = [...this.getFirstFieldHeader(), ...this.getSubscriberMemberHeader(), ...this.getMiddleFieldHeader(), ...this.getLastFieldHeader()];
    this.getFooters();
  }

  getFirstFieldHeader(): any[] {
    let planLabel = this.selectedTab === 'manualClaimCost' ? 'Proposed plans' : 'Current Plans';
    this.planList = this.experienceSumData
      ? StringUtils.isEqual('manualClaimCost', this.selectedTab)
        ? this.experienceSumData.proposedPlanList
        : this.experienceSumData.currentPlanList
      : [];
    let planField = 'planRateData';
    let firstHeader = [
      {
        label: '',
        subHeaders: [
          { label: planLabel, field: 'index' },
          { label: 'Contract code', field: 'contractCode' },
          { label: 'Plan Name', field: 'planName', class: 'w-30' }
        ],
        field: planField,
        colspan: 3,
        formatType: 'string'
      }
    ];
    return firstHeader;
  }

  getSubscriberMemberHeader(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let colspan = this.experienceSumData['outputTier'];
    let subHeaders = JSON.parse(JSON.stringify(this.tierDescription[`${colspan}-Tier`]));
    subHeaders.forEach((element) => {
      element['field'] = this.subscriberMemberTierKey[element['label']];
    });
    let subscriberMemberHeader = [
      { colspan, label: 'Subscriber', subHeaders, field: 'subscriberCount' },
      { colspan, label: 'Members', subHeaders, field: 'memberCount' }
    ];

    return subscriberMemberHeader;
  }

  getMiddleFieldHeader(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let field = 'planRateData';
    let colspan = this.experienceSumData['outputTier'];
    let subHeaders = JSON.parse(JSON.stringify(this.tierDescription[`${colspan}-Tier`]));
    subHeaders.forEach((element) => {
      element['field'] = this.tiredRatesKey[element['label']];
    });
    if (this.fundingType === 'FI') {
      this.tiredRateHeaders = [{ colspan, label: 'Total Rates', subHeaders, field: `${field}.tieredRates.tierTotals`, formatType: 'flat-dollar' }];
    } else {
      this.tiredRateHeaders = [
        { colspan, label: 'Total Rates', subHeaders, field: `${field}.tieredRates.tierTotals`, formatType: 'flat-dollar' },
        { colspan, label: 'ASO Admin', subHeaders, field: `${field}.tieredRates.asoAdminFee`, formatType: 'flat-dollar' },
        { colspan, label: 'SSL Rates', subHeaders, field: `${field}.tieredRates.sslPremium`, formatType: 'flat-dollar' },
        { colspan, label: 'ASL Rates', subHeaders, field: `${field}.tieredRates.aslPremium`, formatType: 'flat-dollar' },
        { colspan, label: 'Max Claims fund', subHeaders, field: `${field}.tieredRates.maxPaidClaim`, formatType: 'flat-dollar' },
        { colspan, label: 'Terminal Liability', subHeaders, field: `${field}.tieredRates.terminalLiability`, formatType: 'flat-dollar' }
      ];
    }
    return this.tiredRateHeaders;
  }

  getLastFieldHeader(): any[] {
    if (this.selectedTab !== 'manualClaimCost' || this.fundingType === 'FI') {
      return [];
    }
    let commonSubHeaders = [
      { label: 'ASO', field: 'asoAdminFee' },
      { label: 'SSL', field: 'sslPremium' },
      { label: 'ASL', field: 'aslPremium' },
      { label: 'Max claims', field: 'maxPaidClaim' },
      { label: 'TL', field: 'terminalLiability' },
      { label: 'Total', field: 'totalPremium' }
    ];
    let manualClaimHeader = [
      {
        label: 'Pure ABF Components',
        subHeaders: [...commonSubHeaders],
        field: 'pureComponentRates',
        colspan: 6,
        formatType: 'flat-dollar'
      },
      {
        label: 'Manual Gross PMPM',
        subHeaders: [{ label: 'ABF Clms cost', field: 'abfClaimsCost' }, ...commonSubHeaders],
        field: 'manualGrossPMPM',
        colspan: 7,
        formatType: 'flat-dollar'
      }
    ];
    return manualClaimHeader;
  }

  getTableData(medicalDetail, header, subHeader, index) {
    if (subHeader.field === 'index') {
      return index + 1;
    } else {
      // Condition for Manual Rate it its sub header Abf Claim Cost
      if (subHeader.field === 'abfClaimsCost') {
        let value = medicalDetail[subHeader.field] ? medicalDetail[subHeader.field] : 0;
        return this.getRoundedValue(value, header['formatType']);
      }
      let allHeaderFields = header.field.split('.');
      let value;
      allHeaderFields.forEach((field, i) => {
        if (i === 0) {
          value = medicalDetail[field] ? medicalDetail[field] : 0;
        } else {
          value = value[field] ? value[field] : 0;
        }
      });
      value = value && value[subHeader.field] ? value[subHeader.field] : 0;
      if (subHeader.field === 'planName') {
        let planName = value.split(' - ');
        value = planName.length > 1 ? planName[1] : planName[0];
      }
      if (header.label === 'Subscriber') {
        value = medicalDetail.tierSubscriberLivesMap[this.experienceSumData['outputTier'] + '-tier'];
        value = value && value[subHeader.field] ? value[subHeader.field] : 0;
      }
      if (header.label === 'Members') {
        value = medicalDetail.tierMemberLivesMap[this.experienceSumData['outputTier'] + '-tier'];
        value = value && value[subHeader.field] ? value[subHeader.field] : 0;
      }
      let rates;
      if (header.field.indexOf('tieredRates') !== -1) {
        rates = this.planList[index]?.planRateData?.tieredRatesMap?.[this.experienceSumData['outputTier'] + '-tier'];
        if (!StringUtils.isUndefined(rates)) {
          if (header.label === 'Total Rates') rates = rates?.tierTotals && rates?.tierTotals?.[subHeader.field] ? rates.tierTotals[subHeader.field] : 0;
          if (header.label === 'ASO Admin') rates = rates?.asoAdminFee && rates?.asoAdminFee?.[subHeader.field] ? rates.asoAdminFee[subHeader.field] : 0;
          if (header.label === 'SSL Rates') rates = rates?.sslPremium && rates?.sslPremium?.[subHeader.field] ? rates.sslPremium[subHeader.field] : 0;
          if (header.label === 'ASL Rates') rates = rates?.aslPremium && rates?.aslPremium?.[subHeader.field] ? rates.aslPremium[subHeader.field] : 0;
          if (header.label === 'Max Claims fund')
            rates = rates?.maxPaidClaim && rates?.maxPaidClaim?.[subHeader.field] ? rates.maxPaidClaim[subHeader.field] : 0;
          if (header.label === 'Terminal Liability')
            rates = rates?.terminalLiability && rates?.terminalLiability?.[subHeader.field] ? rates.terminalLiability[subHeader.field] : 0;
          return this.getRoundedValue(rates, header['formatType']);
        }
      }
      return this.getRoundedValue(value, header['formatType']);
    }
  }

  getFooters(): any[] {
    if (!this.experienceSumData['outputTier']) {
      return [];
    }
    let total = [];
    let totalMontlyRates = [];
    let pureManualRateAction = [];
    let headerField = this.selectedTab === 'manualClaimCost' ? 'manualComponentRates' : 'currentComponentRates';
    if(!this.isNewBusiness) {
    totalMontlyRates = this.getFooterCommonFields('Total monthly Rates', headerField, 'flat-dollar');
    }

    if (this.selectedTab === 'manualClaimCost' && !this.isNewBusiness) {
      pureManualRateAction = this.getFooterCommonFields('Pure manual Rate Action', 'currentToManualDiffPercent', 'percent');
    } else if (this.selectedTab !== 'manualClaimCost') {
      total = this.getCurrentFooterTotal();
    }
    this.footers = [total, totalMontlyRates, pureManualRateAction];
  }

  getFooterCommonFields(label = '', headerField = '', formatType = ''): any[] {
    let footerRow = [];
    let currentRow = label;
    let fields;
    
    // For Pure manual Rate Action: hide extra columns for alternates that are NOT ABF to ABF (e.g., FI to ABF)
    if (currentRow === 'Pure manual Rate Action' && this.alternateQuote && !this.isABFtoABFAlternateRenewal) {
      fields = {
        'Total Rates': 'totalPremium'
      };
    } else {
      fields = {
        'Total Rates': 'totalPremium',
        'ASO Admin': 'asoAdminFee',
        'SSL Rates': 'sslPremium',
        'ASL Rates': 'aslPremium',
        'Max Claims fund': 'maxPaidClaim',
        'Terminal Liability': 'terminalLiability'
      };
    }
    let rates = this.experienceSumData['blendedCostSummary']?.tierWiseManualMonthlyTotal?.[this.experienceSumData['outputTier'] + '-tier'];
    this.headers.forEach((element, index) => {
      if (index === 0) {
        let row = { colspan: element.colspan, label, formatType: '' };
        footerRow.push(row);
      } else if (index === 1 || index === 2) {
        let row = footerRow[0];
        row.colspan += element.colspan;
      } else {
        let subField = fields[element.label];
        let label = 0;
        if (headerField === 'currentToManualDiffPercent' && element.label === 'Total Rates') {
          label =
            this.experienceSumData['blendedCostSummary'] && this.experienceSumData['blendedCostSummary']['pureManualRateAction']
              ? this.experienceSumData['blendedCostSummary']['pureManualRateAction']
              : '';
        } else {
          label =
            this.experienceSumData['blendedCostSummary'] &&
            this.experienceSumData['blendedCostSummary'][headerField] &&
            this.experienceSumData['blendedCostSummary'][headerField][subField] != null
              ? this.experienceSumData['blendedCostSummary'][headerField][subField]
              : '';
        }
        if (element.label === 'Total Rates') {
          if (!StringUtils.isUndefined(rates)) {
            if (headerField === 'currentToManualDiffPercent')
              label = rates?.tierTotals && rates?.tierTotals?.['rateAction'] ? rates.tierTotals['rateAction'] : 0;
            if (headerField === 'manualComponentRates')
              label = rates?.tierTotals && rates?.tierTotals?.['monthlyPremium'] ? rates.tierTotals['monthlyPremium'] : 0;
          }
        }
        // Skip these columns for alternates that are NOT ABF to ABF (e.g., FI to ABF)
        if (!(currentRow === 'Pure manual Rate Action' && this.alternateQuote && !this.isABFtoABFAlternateRenewal)) {
          if (element.label === 'ASO Admin') {
            if (!StringUtils.isUndefined(rates)) {
              if (headerField === 'currentToManualDiffPercent')
                label = rates?.asoAdminFee && rates?.asoAdminFee?.['rateAction'] ? rates.asoAdminFee['rateAction'] : 0;
              if (headerField === 'manualComponentRates')
                label = rates?.asoAdminFee && rates?.asoAdminFee?.['monthlyPremium'] ? rates.asoAdminFee['monthlyPremium'] : 0;
            }
          }
          if (element.label === 'SSL Rates') {
            if (!StringUtils.isUndefined(rates)) {
              if (headerField === 'currentToManualDiffPercent')
                label = rates?.sslPremium && rates?.sslPremium?.['rateAction'] ? rates.sslPremium['rateAction'] : 0;
              if (headerField === 'manualComponentRates')
                label = rates?.sslPremium && rates?.sslPremium?.['monthlyPremium'] ? rates.sslPremium['monthlyPremium'] : 0;
            }
          }
          if (element.label === 'ASL Rates') {
            if (!StringUtils.isUndefined(rates)) {
              if (headerField === 'currentToManualDiffPercent')
                label = rates?.aslPremium && rates?.aslPremium?.['rateAction'] ? rates.aslPremium['rateAction'] : 0;
              if (headerField === 'manualComponentRates')
                label = rates?.aslPremium && rates?.aslPremium?.['monthlyPremium'] ? rates.aslPremium['monthlyPremium'] : 0;
            }
          }
          if (element.label === 'Max Claims fund') {
            if (!StringUtils.isUndefined(rates)) {
              if (headerField === 'currentToManualDiffPercent')
                label = rates?.maxPaidClaim && rates?.maxPaidClaim?.['rateAction'] ? rates.maxPaidClaim['rateAction'] : 0;
              if (headerField === 'manualComponentRates')
                label = rates?.maxPaidClaim && rates?.maxPaidClaim?.['monthlyPremium'] ? rates.maxPaidClaim['monthlyPremium'] : 0;
            }
          }
          if (element.label === 'Terminal Liability') {
            if (!StringUtils.isUndefined(rates)) {
              if (headerField === 'currentToManualDiffPercent')
                label = rates?.terminalLiability && rates?.terminalLiability?.['rateAction'] ? rates.terminalLiability['rateAction'] : 0;
              if (headerField === 'manualComponentRates')
                label = rates?.terminalLiability && rates?.terminalLiability?.['monthlyPremium'] ? rates.terminalLiability['monthlyPremium'] : 0;
            }
          }
        }
        let row = { colspan: element.colspan, label, formatType };
        footerRow.push(row);
      }
    });
    return footerRow;
  }

  getRoundedValue(val, formatType = ''): any {
    let numExp = /^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/;
    // check is Number
    if (numExp.test(val) && formatType !== 'string') {
      val = parseFloat(val);
      if (formatType === 'flat-dollar') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      } else if (formatType === 'percent') {
        return formatPercent(val, this.locale, '1.0-2');
      } else {
        return formatNumber(val, this.locale, '1.0-2');
      }
    } else {
      return val ? val : '';
    }
  }

  getCurrentFooterTotal(): any[] {
    let total = [];
    this.headers.forEach((element, index) => {
      if (index === 0) {
        let row = { colspan: element.colspan, label: 'Total', formatType: '' };
        total.push(row);
      } else if (element.label === 'Subscriber' || element.label === 'Members') {
        let row = [];
        element.subHeaders.forEach((e) => {
          row.push({ colspan: 1, label: 0, formatType: '' });
        });
        this.planList.forEach((medicalPlan) => {
          element.subHeaders.forEach((subEle, index) => {
            if (element.field === 'subscriberCount') {
              row[index].label += medicalPlan.tierSubscriberLivesMap[this.experienceSumData['outputTier'] + '-tier'][subEle.field];
            } else if (element.field === 'memberCount') {
              row[index].label += medicalPlan.tierMemberLivesMap[this.experienceSumData['outputTier'] + '-tier'][subEle.field];
            } else {
              row[index].label += medicalPlan[element.field][subEle.field];
            }
          });
        });
        total.push(...row);
      } else {
        let row = { colspan: element.colspan, label: '', formatType: '' };
        total.push(row);
      }
    });
    return total;
  }
}
