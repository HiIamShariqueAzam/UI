import { formatCurrency, formatDate, formatNumber, formatPercent, getCurrencySymbol } from '@angular/common';
import { Component, Inject, Input, LOCALE_ID, OnInit } from '@angular/core';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { StringUtils } from 'src/app/shared/utils/string-utils';

@Component({
  selector: 'app-experience-loss-ratios',
  templateUrl: './experience-loss-ratios.component.html',
  styleUrls: ['./experience-loss-ratios.component.css'],
  standalone: false,
})
export class ExperienceLossRatiosComponent implements OnInit {
  @Input() experienceSumData: any;
  @Input() opportunityData: any;
  @Input() alternateQuote: boolean;
  @Input() LGFItoSGAbfCrossSelling: boolean;
  @Input() hideRollingLossRatio: boolean;

  lossRatioDetails = [];
  abfLossRatioDetails = [
    { label: 'Claims Basis', field: 'claimsBasis' },
    { label: 'Rolling 12 Loss Ratio', field: 'experiencePeriodSummaryMap.1.lossRatio', formatType: 'percent' },
    { label: 'PY Rolling 12 Loss Ratio', field: 'experiencePeriodSummaryMap.2.lossRatio', formatType: 'percent' },
    { label: 'No. of Claimants Over Spec Threshold', field: 'contractPeriodSummaryMap.1.claimSummary.countOfClaimantsOverSSL' },
    { label: 'CY Total Claims Over SSL', field: 'contractPeriodSummaryMap.1.claimSummary.totalLargeClaimantsOverSSL', formatType: 'flat-dollar' },
    { label: 'CY Contract SSL Loss Ratio', field: 'contractPeriodSummaryMap.1.claimSummary.contractSpecificStopLossRatio', formatType: 'percent' },
    { label: 'PY Contract SSL Loss Ratio', field: 'contractPeriodSummaryMap.2.claimSummary.contractSpecificStopLossRatio', formatType: 'percent' },
    { label: 'CY Contract Max Claims Fund LR', field: 'contractPeriodSummaryMap.1.claimSummary.contractMaxClaimsFundLossRatio', formatType: 'percent' },
    { label: 'PY Contract Max Claims Fund LR', field: 'contractPeriodSummaryMap.2.claimSummary.contractMaxClaimsFundLossRatio', formatType: 'percent' },
    { label: 'CY Surplus/Deficit', field: 'contractPeriodSummaryMap.1.claimSummary.surplusDeficit', formatType: 'flat-dollar' },
    { label: 'Manual Only Suggested Increase', field: 'blendedCostSummary.pureManualRateAction', formatType: 'percent' },
    { label: 'Exp/Claims Only Suggested Increase', field: 'experienceOnlyRateActionPercent', formatType: 'percent' }
  ];

  abfAltLossRatioDetails = [
    { label: 'Claims Basis', field: 'claimsBasis' },
    { label: 'Rolling 12 Loss Ratio', field: 'experiencePeriodSummaryMap.1.lossRatio', formatType: 'percent' },
    { label: 'PY Rolling 12 Loss Ratio', field: 'experiencePeriodSummaryMap.2.lossRatio', formatType: 'percent' },
    { label: 'No. of Claimants Over Spec Threshold', field: 'contractPeriodSummaryMap.1.claimSummary.countOfClaimantsOverSSL' },
    { label: 'CY Total Claims Over SSL', field: 'contractPeriodSummaryMap.1.claimSummary.totalLargeClaimantsOverSSL', formatType: 'flat-dollar' },
    { label: 'Manual Only Suggested Increase', field: 'blendedCostSummary.pureManualRateAction', formatType: 'percent' },
    { label: 'Exp/Claims Only Suggested Increase', field: 'experienceOnlyRateActionPercent', formatType: 'percent' }
  ];

  fiLossRatioDetails = [
    { label: 'Claims Basis', field: 'claimsBasis' },
    { label: 'Rolling 12 Loss Ratio', field: 'experiencePeriodSummaryMap.1.lossRatio', formatType: 'percent' },
    { label: 'PY Rolling 12 Loss Ratio', field: 'experiencePeriodSummaryMap.2.lossRatio', formatType: 'percent' },
    { label: 'Manual Only Suggested Increase', field: 'blendedCostSummary.pureManualRateAction', formatType: 'percent' },
    { label: 'Exp/Claims Only Suggested Increase', field: 'experienceOnlyRateActionPercent', formatType: 'percent' }
  ];

  constructor(@Inject(LOCALE_ID) private locale: string) {}

  ngOnInit() {
    if (this.opportunityData?.fundingType == 'FI') {
      this.lossRatioDetails = this.fiLossRatioDetails;
    } else if ((this.alternateQuote && StringUtils.isEqual(this.opportunityData?.fundingType, CommonConstants.ABF)) || this.LGFItoSGAbfCrossSelling) {
      this.lossRatioDetails = this.abfAltLossRatioDetails;
    } else {
      this.lossRatioDetails = this.abfLossRatioDetails;
    }
  }

  getLRValues(field, formatType = '') {
    let rates = this.experienceSumData?.['blendedCostSummary']?.tierWiseManualMonthlyTotal?.[this.experienceSumData['outputTier'] + '-tier'];
    let exprates = this.experienceSumData?.['tierWiseExperienceOnlyMonthlyTotal']?.[this.experienceSumData['outputTier'] + '-tier'];
    let fieldArr = field.split('.');
    let value;
    for (let i = 0; i < fieldArr.length; i++) {
      let currentVal = fieldArr[i];
      if (i === 0 && this.experienceSumData[currentVal]) {
        value = this.experienceSumData[currentVal];
        if (!StringUtils.isUndefined(exprates)) {
          if (field === 'experienceOnlyRateActionPercent')
            value = exprates?.tierTotals && exprates?.tierTotals?.['rateAction'] ? exprates.tierTotals['rateAction'] : 0;
        }
      } else if (value && value[currentVal]) {
        value = value[currentVal];
        if (!StringUtils.isUndefined(rates)) {
          if (field === 'blendedCostSummary.pureManualRateAction')
            value = rates?.tierTotals && rates?.tierTotals?.['rateAction'] ? rates.tierTotals['rateAction'] : 0;
        }
      } else {
        value = 0;
        break;
      }
    }
    return this.formatValue(value, formatType);
  }

  formatValue(value = '', formatType = ''): any {
    let result = '-';
    switch (formatType) {
      case 'flat-dollar':
        let val1 = isNaN(parseFloat(value)) ? 0 : parseFloat(value);
        result = formatCurrency(val1, this.locale, getCurrencySymbol('USD', 'wide'));
        break;
      case 'percent':
        let val2 = isNaN(parseFloat(value)) ? 0 : parseFloat(value);
        result = formatPercent(val2, this.locale, '1.0-2');
        break;
      case 'date':
        if (value) {
          result = formatDate(value, 'MM/dd/yyyy', this.locale);
        }
        break;
      case 'roundOff':
        let val3 = isNaN(parseFloat(value)) ? 0 : parseFloat(value);
        result = formatNumber(val3, this.locale, '1.2-2');
        break;
      default:
        result = value;
        break;
    }
    return result;
  }
}
