import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges, Inject, LOCALE_ID } from "@angular/core";
import { KeyValue, getCurrencySymbol, formatCurrency } from "@angular/common";
import { UnderwriterAdjustmentService } from '../uw-adjustment.service';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: "app-medical-plan-rates",
  templateUrl: "./medical-plan-rates.component.html",
  styleUrls: ["./medical-plan-rates.component.css"],
  standalone: false,
})
export class MedicalPlanRatesComponent implements OnInit, OnChanges {
  RateInfo: any;
  @Input() quoteDetail: any;
  @Input() planType: string;
  @Input() planRateChange: any;
  @Input() disableAll: boolean;
  @Input() fundingType: string;
  @Input() allPlansDeleted: boolean;
  @Output() planSelected = new EventEmitter<any>();
  @Output() plansDeleted = new EventEmitter<any>();

  requestedTier: number = 1;
  guardrailBoundaries: any;
  lives: any;
  disableFields: boolean = true;
  comissionValue: string = "";
  isFailedQuote: boolean;
  plans: any[];
  hasMPC: boolean = false;
  hasMedicareRates:boolean= false;
  tierDescription: any;
  stateOptions: any[];
  selectedValue: any;
  rateColumns: any[];
  benefitsColSpan: number = 6;
  isExpanded: boolean = false;
  monthlyTotalColSpan: number = 17;
  colSpanForABF: number;
  expandClicked: boolean = false;
  expandClickedforABF: boolean = false;
  expandClickedforMedicare: boolean=false;

  allChecked: boolean = false;
  planColumns: any;
  removedAllPlans: boolean = false;
  scrollTop: any;
  siteMatchArray = [];
  planColumnsBefore = [

    { header: "View Calc" },
    { header: "Plan Name" },
    { header: "General Agent Commission" },
    { header: "Contract Code" },
    { header: "Network" },
    { header: "Product Category" },
    { header: "Product Code" },
    { header: "Deductible Ind/Fam" },
    { header: "Coinsurance" },
    { header: "Out Of Pocket Ind/Fam" },
  ];

  planColumnsAfter = [
    { header: "View Calc" },
    { header: "Plan Name" },
    { header: "General Agent Commission" },
    { header: "Contract Code" },
    { header: "Network" },
    { header: "Product Category" },
    { header: "Product Code" },
    { header: "Deductible Ind/Fam" },
    { header: "Coinsurance" },
    { header: "Out Of Pocket Ind/Fam" },
    { header: "Office Visit (PCP/Specialist/Preferred PCP) Copay" },
    { header: "Inpatient hospital copay" },
    { header: "Emergency room/urgent care copay" },
    { header: "Prescription drugs – retail" },
    { header: "Prescription drugs – mail order" }
  ];

  abfComponentKeys: string[] = ['asoFee', 'sslPremium', 'aslPremium', 'terminalLiabilityFund', 'maxPaidClaimsFund'];
  mewaComponentKeys:String[] =['medicareTieredRates'];
  acaQuote: boolean = false;
  isRenewal: boolean = false;

  constructor(@Inject(LOCALE_ID) private locale: string, private uwService: UnderwriterAdjustmentService) { }

  ngOnChanges(changes: SimpleChanges) {
    this.requestedTier = (this.quoteDetail && this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.outputTier)
      || (this.quoteDetail && this.quoteDetail.medicalOutputTier) || 1;
    if (changes.quoteDetail && !changes.quoteDetail.firstChange) {
      this.initializeComponentVariables();
    }
    if (changes.planRateChange && !changes.planRateChange.firstChange) {
      this.rateColumns = this.tierDescription[this.requestedTier + '-Tier'];
    }
    this.assignLivesData();
  }

  ngOnInit() {
    if (this.quoteDetail && this.quoteDetail.opportunityType == 'Renewal Local' && this.quoteDetail.quotingType != 'ACA') {
      this.isRenewal = true;
    }
    this.benefitsColSpan = 3;
    this.isExpanded = false;
    this.planColumns = this.planColumnsBefore;
    this.initalizeStateOptions();
    this.initializeComponentVariables();
    this.monthlyTotalColSpan = 12;
    this.updateACAQuoteColspan();

    if(this.acaQuote || this.quoteDetail.medical && this.quoteDetail.quotingType == CommonConstants.MEWA) {
        
    this.removedAllPlans = this.allPlansDeleted;
    const newObjectsOfficeVisits = [
      { header: "Office Visit - PCP (Pref/INN) Copay" },
      { header: "Office Visit - SPC (Pref/INN) Copay" }
    ];
    this.planColumnsAfter.splice(10, 1, ...newObjectsOfficeVisits);

      const newObjects = [
        { header: "Prescription drugs - network/drug list" },
        { header: "Prescription deductible" },
        { header: "Deductible applies to tiers" },
      ];
      this.planColumnsAfter.splice(14, 0, ...newObjects);
    }
    this.assignLivesData();
  }

  /**
   * Updates the colspan for the ACA quote based on the requested tier.
   */
  updateACAQuoteColspan() {
    if (this.acaQuote) {
      if (this.requestedTier == 1) {
        this.monthlyTotalColSpan = 8;
      } else if (this.requestedTier == 2) {
        this.monthlyTotalColSpan = 11;
      } else if (this.requestedTier == 3) {
        this.monthlyTotalColSpan = 12;
      } else if (this.requestedTier == 5) {
        this.monthlyTotalColSpan = 14;
      }
    }
  }

  initalizeStateOptions() {
    if (this.quoteDetail && this.quoteDetail.medical && this.quoteDetail.quotingType == 'ACA') {
      this.stateOptions = [{ label: 'Monthly Premium', value: 'Rates' }, { label: 'Enrollments', value: 'Enrollments' }];
      this.selectedValue = { label: 'Monthly Premium', value: 'Rates' };
    } else {
      this.stateOptions = [{ label: 'Rates', value: 'Rates' }, { label: 'Enrollments', value: 'Enrollments' }];
      this.selectedValue = { label: 'Rates', value: 'Rates' };
    }
  }

  initializeComponentVariables() {
    this.colSpanForABF = this.planType == 'F' ? 10 : 11;
    this.removedAllPlans = this.allPlansDeleted;
    if (this.quoteDetail) {
      if (this.quoteDetail?.factors?.medNetworkFactor) {
        this.siteMatchArray = [];
        let siteMatchData = this.quoteDetail?.factors?.medNetworkFactor;
        Object.keys(siteMatchData).forEach(siteMatchDetail => {
          if (StringUtils.isEqual(siteMatchData[siteMatchDetail].groupQualified, CommonConstants.NO)) {
            this.siteMatchArray.push(siteMatchDetail);
          }
        })
      }
      if (this.quoteDetail.medical && this.quoteDetail.quotingType == 'ACA') {
        this.acaQuote = true;
        this.disableFields = true;
        this.removeViewCalcHeader();
      }
      this.hasMPC = this.quoteDetail.medicalPremiumComparison;
      this.hasMedicareRates=this.quoteDetail?.factors?.mewaFactors?.medicareTieredRates;
      
      
      if (this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans) {

        if(this.acaQuote && this.planType == 'P') {
          this.plans = this.quoteDetail.medical.proposedPlans.filter(plan => {
            return  plan.status != "Failed"
          });
        }
        else{
          this.plans = this.quoteDetail.medical.proposedPlans.filter(plan => {
            return plan.planTypeRequested == this.planType && plan.status != "Failed"
          });
        }

      }
      if (this.planType == 'P' && this.plans) {
        this.setPortfolioPlanTrueByDefault();
      }
      this.tierDescription = (this.quoteDetail['factors'] && this.quoteDetail['factors'].tierDescription) || {};
      this.rateColumns = this.tierDescription[this.requestedTier + '-Tier'];
      this.isFailedQuote = !!(this.quoteDetail['status'] && this.quoteDetail['status'].toLowerCase() === "failed");
      this.disableFields = this.disableAll || this.isFailedQuote;
      this.comissionValue = this.getComissionValue();
      this.assignLivesData();
      this.guardrailBoundaries = this.fectchBoundaries(this.quoteDetail.factors && this.quoteDetail.factors.guardRails,
        this.quoteDetail.state);

      if (this.quoteDetail.medical && [CommonConstants.MEWA, CommonConstants.ACA].includes(this.quoteDetail.quotingType)) {
        this.disableFields = true;
      }
      if (this.quoteDetail.medical && this.quoteDetail.quotingType == CommonConstants.ACA) {
        this.removeViewCalcHeader();
      }
    }
  }

  private removeViewCalcHeader() {
    this.planColumns = this.planColumns.filter(columnname => columnname['header'] != 'View Calc');
  }
  getNetworkColor(medPlan, networkID) {
    return (this.siteMatchArray.includes(medPlan[networkID]) && !medPlan.includeInPrintExhibit) ? true : false
  }
  setPortfolioPlanTrueByDefault() {
    this.plans.forEach(pplan => {
      if (pplan.includeInPrintExhibit == undefined) {
        pplan.includeInPrintExhibit = true;
      }
    });
  }

  assignLivesData() {
    if (this.acaQuote) {
      const firstPlanWithSubscriberCount = this.quoteDetail?.medical?.proposedPlans?.find(plan => plan.planTypeRequested == 'P' &&
        plan.factors?.acaFactors?.subscriberCount
      );
      this.lives = firstPlanWithSubscriberCount?.factors?.acaFactors?.subscriberCount;
    } else if(this.quoteDetail.medical && this.quoteDetail.quotingType == CommonConstants.MEWA) {
      const firstPlanWithSubscriberCount = this.quoteDetail?.medical?.proposedPlans?.find(plan => plan.planTypeRequested == 'P' &&
        plan.factors?.mewaFactors?.subscriberCount
      );
      this.lives = firstPlanWithSubscriberCount?.factors?.mewaFactors?.subscriberCount;
    }
    else{
      this.lives = (this.quoteDetail['factors'] && this.quoteDetail['factors'].calculatedTierLives &&
        this.quoteDetail['factors'].calculatedTierLives[this.requestedTier + '-tier']) || {};
    }
  }


  getEnrollment(plan, type) {
    if (this.acaQuote) {
      return plan && plan.factors && plan.factors.acaFactors && plan.factors.acaFactors.subscriberCount && plan.factors.acaFactors.subscriberCount[type] ? plan.factors.acaFactors.subscriberCount[type] : 0;
    } else if(this.quoteDetail.medical && this.quoteDetail.quotingType == CommonConstants.MEWA) {
      return plan && plan.factors && plan.factors.mewaFactors && plan.factors.mewaFactors.subscriberCount && plan.factors.mewaFactors.subscriberCount[type] ? plan.factors.mewaFactors.subscriberCount[type] : 0;
    } else {
      return plan.lives && plan.lives[this.requestedTier + '-tier'][type];
    }
  }

  getRates(plan, type,planType) {
    let val = 0;
    if (this.acaQuote) {

      if(planType == 'P')
      {
        val = plan && plan.rateInfo && plan.rateInfo[type];
      }
      else{
      val = plan && plan.factors && plan.factors.acaFactors && plan.factors.acaFactors.monthlyPremium && plan.factors.acaFactors.monthlyPremium[type] ? plan.factors.acaFactors.monthlyPremium[type] : 0;
      }
    } else {
      val = plan && plan.rateInfo && plan.rateInfo[type] ? plan.rateInfo[type] : 0;
    }
    return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'),
      undefined, '1.2-2');
  }
  getTotalRates(plan) {
    let val = 0;
    if (this.acaQuote) {
      if(this.planType == 'P')
      {
          if (plan && plan.rateInfo) {
              val = (parseFloat(plan.rateInfo['single']) || 0) +
                    (parseFloat(plan.rateInfo['eeSpouse']) || 0) +
                    (parseFloat(plan.rateInfo['eeChildren']) || 0) +
                    (parseFloat(plan.rateInfo['family']) || 0);
          }
      }
      else{
        val = plan && plan.factors && plan.factors.acaFactors && plan.factors.acaFactors.totalMonthlyPremium ? plan.factors.acaFactors.totalMonthlyPremium : 0;
      }
    }
    return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'),
      undefined, '1.2-2');
  }

  getMontlyGrandTotalRates() {
    let val = 0;
    if (this.acaQuote) {
      val = this.quoteDetail['quoteAcaFactors'] && this.quoteDetail['quoteAcaFactors'].totalMonthlyPremium ? this.quoteDetail['quoteAcaFactors'].totalMonthlyPremium : 0;
    }
    return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'),
      undefined, '1.2-2');
  }
  updateEnrol(event, type, plan) {
    plan.lives[this.requestedTier + '-tier'][type] = event.target.value;
  }

  isNumber(event) {
    return !(event.charCode > 31 && (event.charCode < 48 || event.charCode > 57));
  }

  displayGuardRailError(plan) {
    let errorMessage = "";
    if (plan.failedGuardRails && Array.isArray(plan.failedGuardRails)) {
      plan.failedGuardRails.forEach(guardRailAttribute => {
        errorMessage = errorMessage + (errorMessage ? " and " : "") + this.guardrailBoundaries[guardRailAttribute];
      });
    }
    return errorMessage;
  }

  originalOrder = (a: KeyValue<string, any>, b: KeyValue<string, any>): number => { return 0; };

  benefitsExpand() {
    this.expandClicked = !this.expandClicked;

    if (this.expandClicked) {
      this.benefitsColSpan = this.quoteDetail?.quotingType == CommonConstants.MEWA || this.acaQuote ? 12 : 8;
      this.colSpanForABF = this.planType == 'F' ? 15 : 16;
      this.isExpanded = true;
      this.planColumns = this.planColumnsAfter;
      this.monthlyTotalColSpan = 17;
    } else {
      this.benefitsColSpan = 3;
      this.colSpanForABF = this.planType == 'F' ? 10 : 11;
      this.isExpanded = false;
      this.planColumns = this.planColumnsBefore;
      this.monthlyTotalColSpan = 12;
    }
    if (this.acaQuote) {
      this.removeViewCalcHeader();
      this.updateACAQuoteColspan();
    }
  }

  abfRatesExpand() {
    this.expandClickedforABF = !this.expandClickedforABF;
  }

   medicareRatesExpand(){
    this.expandClickedforMedicare = !this.expandClickedforMedicare;

   }

  createPopup(selectedPlan: any) {
    this.planSelected.emit(selectedPlan);
  }

  getBenefitData(node, data) {
    // Adding this to handle until the data is updated, once we have the data nodes
    // available in the mongo we don't need this section of if block
    if (data === 'officeVisitPCPCopay') {
      return this.generateOfficeVistsCopay(node['ovPreferedPCPCopay'], node['ovPCPCopay']);
    } else if (data === 'officeVisitSPCCopay') {
      return this.generateOfficeVistsCopay(node['ovPreferedSPCCopay'], node['ovSCPCopay']);
    } else if (data === 'productCode') {
      if (node && node['planBenefits'] && node['planBenefits'][data]) {
        return node['planBenefits'][data];
      } else if (node && node['planBenefits'] && !node['planBenefits']['productCategoryCode']) {
        return node['CDHPIndicator'] ? node['CDHPIndicator'] : '';
      }
    } else if (data === 'productCategoryCode') {
      if (node && node['planBenefits'] && node['planBenefits'][data]) {
        return node['planBenefits'][data];
      }
      return node['networkType'] ? node['networkType'] : '';
    } else {
      if (node && node[data]) {
        return node[data];
      } else {
        return;
      }
    }
  }

  getFormattedCommissionValue(commType: string, commissionAmount: number): string {
    let commissionType = commType.toLowerCase();
    if (commissionType === 'pmpm' || commissionType === 'pcpm' || commissionType === 'flat dollar') {
      /* ALGR-96591 - As part of graded commssion rounded commssion value to 2 decimal places */
      return '$' + (Math.round(commissionAmount * 100) / 100).toFixed(2) + " / " + commType;
    } else {
      return commissionAmount + " %";
    }
  }

  getComissionValue(): string {
    let returnValue = "";
    if (this.plans && this.plans.length > 0) {
      let commissionAmount = this.plans[0]['commissionValue'];
      let commissionType = (this.plans[0]['commissionType'] || "");
      if (!isNaN(parseFloat(commissionAmount))) {
        returnValue = this.getFormattedCommissionValue(commissionType, parseFloat(commissionAmount));
      } else {
        if (this.plans[0]['factors'] && this.plans[0]['factors']['generalAgentNewBusinessCommission']) {
          commissionAmount = this.plans[0]['factors']['generalAgentNewBusinessCommission']['retntnAmt'];
          commissionType = (this.plans[0]['factors']['generalAgentNewBusinessCommission']['retntnTypeCd'] || "");
          if (!isNaN(parseFloat(commissionAmount))) {
            returnValue = this.getFormattedCommissionValue(commissionType, parseFloat(commissionAmount));
          }
        }
      }
    }
    return returnValue;
  }

  removeSelectedPlans() {
    if (this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans) {
      this.quoteDetail.medical.proposedPlans.forEach(plan => {
        if (plan.planTypeRequested == this.planType && plan.markedForDelete) {
          plan.planTypeRequested = "R";
        }
      });
      this.plans = this.quoteDetail.medical.proposedPlans.filter(plan => {
        return plan.planTypeRequested == this.planType && plan.status != "Failed"
      });
    }
    if (this.plans && this.plans.length == 0) {
      this.removedAllPlans = true;
      this.plansDeleted.emit(true);
    }
    this.allChecked = false;
  }

  checkForSelectedPlans() {
    this.allChecked = this.plans.filter(plan => !plan.markedForDelete).length == 0;
  }

  selectAllPlans() {
    this.plans.forEach(plan => plan.markedForDelete = this.allChecked);
  }

  fectchBoundaries(guardRailsList, state) {
    let boundariesObj = {};
    guardRailsList && guardRailsList.map(guardrailObj => {
      if (guardrailObj.chkLvl != null && guardrailObj.chkLvl.toLowerCase() != "quote") {
        let message = guardrailObj.guardDesc || "";
        let key = guardrailObj.attrbNm;
        if (key && key.includes(".data.")) {
          key = key.replace(".data.", ".");
        }
        if (key && key.includes("[0].")) {
          key = key.replace("[0].", ".");
        }
        boundariesObj[key] = message.replace("{{min}}", guardrailObj.minVal).replace("{{max}}", guardrailObj.maxVal);
      }
      return boundariesObj;
    });
    boundariesObj["state"] = state;
    return boundariesObj;
  }
  onScroll(event) {
    this.scrollTop = event.target.scrollTop
  }

  togglePortfolioPlan(plan) {
    if (plan.includeInPrintExhibit != undefined) {
      plan.includeInPrintExhibit = !plan.includeInPrintExhibit;
    } else {
      plan.includeInPrintExbibit = true;
    }
    if (plan.toggled) {
      plan.toggled = !plan.toggled;
    } else {
      plan.toggled = true;
    }
    if (this.isRenewal && this.planType == 'F')
      this.uwService.featutePlanSupressSubject.next({
        plans: this.plans,
        plan: plan
      });
  }

  toggleAllPortfolioPlan() {
    this.plans.forEach(eachplan => {
      eachplan.includeInPrintExhibit = eachplan.includeInPrintExhibit != undefined ? !eachplan.includeInPrintExhibit : true
      eachplan.toggled = eachplan.toggled != undefined ? !eachplan.toggled : true;
    });

    if (this.isRenewal && this.planType == 'F')
      this.uwService.featutePlanSupressSubject.next({ plans: this.plans });
  }
  
  private generateOfficeVistsCopay(preferedOvCopay, innOvCopay) {
		if (preferedOvCopay && innOvCopay) {
			return preferedOvCopay + '/' + innOvCopay;
		} else if ((preferedOvCopay)) {
			return preferedOvCopay;
		} else if ((innOvCopay)) {
			return innOvCopay;
		}
		return "";
	}
  
}
