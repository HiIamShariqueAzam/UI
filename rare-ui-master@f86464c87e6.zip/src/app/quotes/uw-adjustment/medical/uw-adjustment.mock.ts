export const rateInfoResponse= {
    "metadata":{
       "meta-transid":"OH20200414184700-D",
       "rating-transId":"OH20200414184700-D",
       "sourceSystem":"COM2",
       "targetSystem":"RARE/ABACUS"
    },
    "data":{
       "opportunityID":"OH20200414184700-D",
       "opportunityName":"Bob's Bate",
       "opportunityType":"New Business",
       "quoteHeaderID":"OH20200414184700-D",
       "submittedTimestamp":"2020-04-14T18:48:33.002",
       "accountID":"0064N00000ZPcLSQA1",
       "accountName":"Bob's Bate",
       "addr1":"740 Main st.",
       "addr2":"Office 2",
       "city":"Mason",
       "state":"OH",
       "companyZip":"45050",
       "sicCode":"7999",
       "mbu":"100PLUS",
       "marketSegment":"100PLUS",
       "groupNbr":"dfd",
       "groupNameDBA":"dfdf",
       "contractEffectiveDate":"2020-04-01",
       "contractEndDate":"2021-03-31",
       "requestedDueDate":"2021-04-11",
       "factorEffectiveDate":"2020-01-01",
       "accountExecID":"US-AA85137",
       "accountExecName":"Jason Abrams",
       "accountExecContact":"614-433-8477",
       "accountExecEmailID":"jason.abrams@anthem.com",
       "salesSupportID":"US-HELTOJC",
       "salesSupportName":"Kristine George",
       "salesSupportContact":"216-573-4426",
       "salesSupportEmailID":"kristine.george@anthem.com",
       "salesOfficeAddr1":"Anthem BCBS",
       "salesOfficeAddr2":"740 W Peachtree St NW",
       "salesOfficeCity":"Atlanta",
       "salesOfficeState":"Georgia",
       "salesOfficeZip":"30308",
       "uwUserId":"US-AD63151",
       "uwUserName":"Matt Peter",
       "uwEmailID":"matt.peter@anthem.com",
       "broker":"Bob Brown",
       "brokerage":"Bob Broker Administrators",
       "commonOwnership":"No",
       "virginGroup":"No",
       "medicalInputTier":"4",
       "medicalOutputTier":"4",
       "dentalInputTier":"4",
       "dentalOutputTier":"4",
       "visionInputTier":"4",
       "visionOutputTier":"4",
       "overview":"Tell us about this prospect",
       "information":"Additional Info about client",
       "strategy":"proposed strategy to win the case",
       "support":"Support needed from organization",
       "probability":"chances to win the case",
       "nextSteps":"next steps to proceed with the case",
       "supportingDocLinks":[
          "htmlLink1",
          "htmlLink2"
       ],
       "productsQuoted":[
          "Medical"
       ],
       "medical":{
          "asoCommissionType":"PCPM",
          "asoCommissionDollars":"20",
          "salesMedicalDiscount":"0.05",
          "salesMedicalDiscountNote":"NB discount 5% applied",
          "stopLossCovg":[
             {
                "sslCommissionType":"PCPM",
                "sslCommissionValue":"5",
                "sslDeductible":"100000",
                "sslContractBasis":"12/12",
                "sslMedCovg":"Yes",
                "sslRxCovg":"Yes",
                "sslMaxAmt":"Unlimited",
                "aggSLCovg":"Yes",
                "aggSLCorridor":"125%",
                "aggSLContractBasis":"18/12",
                "aggSLMaxAmt":"Unlimited",
                "aggSLRxClaimswithMedExp":"Yes",
                "aggSLMedCovg":"Yes",
                "aggSLRxCovg":"Yes"
             }
          ],
          "prevCarriers":[
             "AETNA"
          ],
          "plans":[
             {
                "quoteLineItemID":"1101",
                "quoteDescription":"sd",
                "planTypeRequested":"F",
                "currentCarrierName":"AETNA",
                "currentPlan":"SMP HSA 2700-100%",
                "currentFundingType":"FI Non-Refunding (Non-Participating)",
                "currPlanEnrollT1":"245",
                "currPlanEnrollT2":"58",
                "currPlanEnrollT3":"120",
                "currPlanEnrollT4":"11",
                "currPlanEnrollT5":"0",
                "currRatesT1":"710.45",
                "currRatesT2":"640.45",
                "currRatesT3":"763.43",
                "currRatesT4":"810.25",
                "currRatesT5":"0",
                "rnwlRatesT1":"740.45",
                "rnwlRatesT2":"680.45",
                "rnwlRatesT3":"793.43",
                "rnwlRatesT4":"850.25",
                "rnwlRatesT5":"0",
                "EEContribution":"50",
                "DepContribution":"30",
                "proposedFundingType":"FI",
                "lob":"Medical",
                "planConstruct":"STD",
                "medicalParticipationRate":"0.51",
                "chamberOfCommerce":"TRUE",
                "premiumDelay":"30",
                "commissionValue":"20",
                "commissionType":"PCPM",
                "productID":"42378",
                "contractCode":"50N6",
                "networkType":"PPO",
                "CDHPIndicator":"PPO",
                "networkName":"Blue Access",
                "medPlanName":"OH_BA_20_5000_0p_7350",
                "rxPlanName":"OH_Rx_10c_40c_70c_25p_350_T2",
                "innDedIndividual":"500",
                "oonDedIndividual":"1500",
                "innDedFamily":"1000",
                "oonDedFamily":"3000",
                "innCoinsurance":"0.20",
                "oonCoinsurance":"0.50",
                "innOopMaxIndividual":"2700",
                "oonOopMaxIndividual":"8100",
                "innOopMaxFamily":"5400",
                "oonOopMaxFamily":"16200",
                "ovPCPCopay":"25",
                "ovSCPCopay":"50",
                "innIPHospCopay":"Ded & Coins",
                "innERCopay":"350",
                "innUCCopay":"75",
                "innRxRetail":"T4:$15/$50/",
                "innRxMailOrder":"$37.50/$150/",
                "rateInfo":{
                   "lob":"Medical",
                   "planConstruct":"STD",
                   "quoteLineItemID":"1101",
                   "productID":"42378",
                   "contractCode":"50N6",
                   "commissionType":"PCPM",
                   "commissionValue":"20",
                   "employmentCategoryCode":"ACTSB",
                   "single":"717.06",
                   "eeSpouse":"1576.09",
                   "eeChild":0,
                   "eeChildren":"1210.39",
                   "family":"2213.56",
                   "finalGrossPMPM":"563.17",
                   "monthlyPremium":193639,
                   "embeddedVision":"1.6",
                   "medicareElgSpouseL65":null,
                   "medicareElgSpouseChildL65":null
                },
                "trailLog":{
                   "general":{
                      "contractEffectiveDate":{
                         "value":"2020-04-01",
                         "description":"Contract Effective Date"
                      },
                      "medPlanId":{
                         "value":"OH_BA_20_5000_0p_7350",
                         "description":"Med Plan"
                      },
                      "eligibleSubCount":{
                         "value":"101.0000",
                         "description":"Eligible Sub Count"
                      },
                      "mbu":{
                         "value":"100PLUS",
                         "description":"Key/100+"
                      },
                      "chamberOfCommerce":{
                         "value":"Yes",
                         "description":"Chamber of Commerce?"
                      },
                      "participationRate":{
                         "value":"0.51",
                         "description":"Participation Rate"
                      },
                      "premiumDelay":{
                         "value":"30",
                         "description":"Premium Delay"
                      }
                   },
                   "medical":{
                      "startCost":{
                         "value":"335.24",
                         "description":"Medical Starting Cost",
                         "type":"PMPM"
                      },
                      "startCostAdjust":{
                         "value":"2.0387451",
                         "description":"Starting Cost Adjustment",
                         "type":"PMPM"
                      },
                      "relativity":{
                         "value":"0.66146",
                         "description":"Medical Relativity"
                      },
                      "areaFactor":{
                         "value":"0.863037",
                         "description":"Medical Area Factor"
                      },
                      "ageSexFactor":{
                         "value":"1.052150",
                         "description":"Medical Age/Sex Factor"
                      },
                      "trendEffectiveDate":{
                         "value":"2020-01-01",
                         "description":"Trend Effective Date"
                      },
                      "trendFactor":{
                         "value":"1.08",
                         "description":"Medical Trend Factor"
                      },
                      "trendingDays":{
                         "value":91,
                         "description":"Days of Trend"
                      },
                      "adjustedTrendFactor":{
                         "value":"1.0193593906744582",
                         "description":"Medical Trend Factor"
                      }
                   },
                   "drug":{
                      "startCost":{
                         "value":"58.35",
                         "description":"Rx Starting Cost",
                         "type":"PMPM"
                      },
                      "startCostAdjust":{
                         "value":"2.0387451",
                         "description":"Starting Cost Adjustment",
                         "type":"PMPM"
                      },
                      "relativity":{
                         "value":"0.66733",
                         "description":"Rx Relativity"
                      },
                      "areaFactor":{
                         "value":"0.863037",
                         "description":"Rx Area Factor"
                      },
                      "ageSexFactor":{
                         "value":"1.052150",
                         "description":"Rx Age/Sex Factor"
                      },
                      "trendEffectiveDate":{
                         "value":"2020-01-01",
                         "description":"Trend Effective Date"
                      },
                      "trendFactor":{
                         "value":"1.08",
                         "description":"Rx Trend Factor"
                      },
                      "trendingDays":{
                         "value":91,
                         "description":"Days of Trend"
                      },
                      "adjustedTrendFactor":{
                         "value":"1.0193593906744582",
                         "description":"Rx Trend Factor"
                      },
                      "ingenioRx":{
                         "value":1,
                         "description":"IngenioRx Cost of Care Adjustment"
                      }
                   },
                   "claimCost":{
                      "morbidity":{
                         "value":"0.7554204",
                         "description":"Morbidity"
                      },
                      "industry":{
                         "value":"1.12",
                         "description":"Industry Factor"
                      },
                      "groupSize":{
                         "value":1,
                         "description":"Group Size Factor"
                      },
                      "newBusiness":{
                         "value":"0.9487666",
                         "description":"New Business Factor"
                      },
                      "participationCalculation":{
                         "value":"1.00",
                         "description":"Participation Calculation Load"
                      },
                      "hottClaims":{
                         "value":"2.39",
                         "description":"Hott Claims",
                         "type":"PMPM"
                      },
                      "medicalClaims":{
                         "value":"335.910",
                         "description":"Medical Claims Cost",
                         "type":"PMPM"
                      },
                      "rxClaims":{
                         "value":"58.9855",
                         "description":"Rx Claims Cost",
                         "type":"PMPM"
                      },
                      "totalClaims":{
                         "value":"397.286",
                         "description":"Total Claims Cost",
                         "type":"PMPM"
                      }
                   },
                   "premium":{
                      "medicalAdminExpense":{
                         "value":"22.32",
                         "description":"Administrative Expense - Medical",
                         "type":"PMPM"
                      },
                      "medicalProfitMargin":{
                         "value":"0.09",
                         "description":"Profit Margin - Medical"
                      },
                      "rxProfitMargin":{
                         "value":"0.09",
                         "description":"Profit Margin - Drug"
                      },
                      "rebateRetention":{
                         "value":0,
                         "description":"Rebate Retention Credit",
                         "type":"PMPM"
                      },
                      "premiumDelayCharges":{
                         "value":0,
                         "description":"Grace Period / Premium Delay Interest Charge",
                         "type":"PMPM"
                      },
                      "addlAdmin":{
                         "value":0,
                         "description":"Additional Admin",
                         "type":"PMPM"
                      },
                      "acaInsurerFee":{
                         "value":"0.0208860750",
                         "description":"ACA Insurer Fee"
                      },
                      "cerpcori":{
                         "value":0,
                         "description":"CER PCORI Fee",
                         "type":"PMPM"
                      },
                      "generalAgent":{
                         "value":"5.874859",
                         "description":"General Agent Commission",
                         "type":"PMPM"
                      },
                      "stateTaxes":{
                         "value":"0.014",
                         "description":"State Premium Taxes"
                      },
                      "participationAdjustmenet":{
                         "value":"1.17",
                         "description":"Participation Adjustment"
                      },
                      "specialityDiscount":{
                         "value":1,
                         "description":"Speciality Discount (hits total premium)"
                      },
                      "grossBeforePMPM":{
                         "value":"568.85395788",
                         "description":"PMPM Before ARROW Risk Score",
                         "type":"PMPM"
                      },
                      "arrowRiskScore":{
                         "value":"1.0000",
                         "description":"ARROW Risk Score"
                      },
                      "chamberOfCommerce":{
                         "value":"0.99",
                         "description":"Chamber of Commerce"
                      },
                      "finalGrossPMPM":{
                         "value":"563.17",
                         "description":"Final Gross PMPM",
                         "type":"PMPM"
                      },
                      "monthlyPremium":{
                         "value":193639,
                         "description":"Total Monthly Premium (excls J & K)",
                         "type":"PMPM"
                      }
                   }
                }
             }
          ]
       },
       "riskScore":"1.0000"
    },
    "uwAdjustment":{
       "approvalStatus":"Pending",
       "medicalOutputTier":"4"
    },
    "factors":{
       "outputTierFactor":{
          "4-tier":{
             "eeFactor":"1.273252",
             "esFactor":"2.798607896",
             "ecFactor":"2.149249376",
             "efFactor":"3.930528924"
          },
          "2-tier":{
             "eeFactor":"1.482725",
             "efFactor":"3.878808600"
          }
       },
       "ageSexFactor":"1.052150"
    },
    "censusSubscriber":{
       "medEligibilityLivesMap":{
          "E":101
       },
       "medTierLivesMap":{
          "EE":20,
          "EF":81
       },
       "censusCount":101
    }
 };

 export const printExhibitResponse={
    "printExhibits":{
       "metaTransID":"OH20200429090900RTGWDEV",
       "lob":"Medical",
       "opportunityID":"OH20200429090900RTGWDEV",
       "quoteHeaderID":"OH20200429090900RTGWDEV",
       "opportunityName":"Bob's Bate",
       "documents":[
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{56E7E10A-82B2-4726-A1A8-CAF6824F7C9A}",
             "exhibitFundingType":"FI",
             "exhibitName":"Bob's Bate",
             "fileName":"Bob's Bate_Medical_PrintExhibit_2020-04-28T09_12_54_698",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-28T09:12:54.698"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{47517C6B-9F3C-4BFC-BF23-46229D58B21C}",
             "exhibitFundingType":"FI",
             "exhibitName":"Bob's Bate",
             "fileName":"Bob's Bate_Medical_PrintExhibit_2020-04-28T18_50_10_242",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-28T18:50:10.242"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{03D59402-69B0-4302-AEB9-F930DBF710ED}",
             "exhibitFundingType":"FI",
             "exhibitName":"Bob's Bate",
             "fileName":"Bob's Bate_Medical_PrintExhibit_2020-04-28T19_21_56_608",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-28T19:21:56.608"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{649AD6BD-81B2-4DE2-AF6A-7C8BACF122F8}",
             "exhibitFundingType":"FI",
             "exhibitName":"Bob's Bate",
             "fileName":"Bob's Bate_Medical_PrintExhibit_2020-04-28T19_25_06_223",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-28T19:25:06.223"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{42734B2F-7589-4EE2-8466-44578C1A3C37}",
             "exhibitFundingType":"FI",
             "exhibitName":"Bob's Bate",
             "fileName":"Bob's Bate_Medical_PrintExhibit_2020-04-28T20_02_52_574",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-28T20:02:52.574"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{4EAD29A3-F6D6-4706-82DC-71A01FF78E8A}",
             "exhibitFundingType":"FI",
             "exhibitName":"Test_Exhibit_3",
             "fileName":"Test_Exhibit_3_Medical_PrintExhibit_2020-04-28T21_56_48_281",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-28T21:56:48.281"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{18886230-CD1B-4495-A2C7-4481E83EC93D}",
             "exhibitFundingType":"FI",
             "exhibitName":"Testing",
             "fileName":"Testing_Medical_PrintExhibit_2020-04-29T02_30_15_183",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-29T02:30:15.183"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{E6A23D54-8193-4049-BB3C-8D2D5A31E619}",
             "exhibitFundingType":"FI",
             "exhibitName":"Testing",
             "fileName":"Testing_Medical_PrintExhibit_2020-04-29T02_30_57_386",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-29T02:30:57.386"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{6FA6051D-2360-4929-B285-1F6557E5F7FA}",
             "exhibitFundingType":"FI",
             "exhibitName":"",
             "fileName":"_Medical_PrintExhibit_2020-04-29T03_13_16_104",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-29T03:13:16.104"
          },
          {
             "ratingTransId":null,
             "fileNetStatus":"Complete",
             "exhibitDocId":"{B93D883D-8FAF-4BE7-B609-CC37CB8ADD46}",
             "exhibitFundingType":"FI",
             "exhibitName":"Bhasi_testing",
             "fileName":"Bhasi_testing_Medical_PrintExhibit_2020-04-29T04_21_51_014",
             "insertedTimestamp":null,
             "submittedTimestamp":"2020-04-29T04:21:51.014"
          }
       ]
    }
 };


 export const applyAdjRequest={
    "opportunity":{
       "opportunityID":"OH20200429090900RTGWDEV",
       "quoteHeaderID":"OH20200429090900RTGWDEV",
       "opportunityName":"Bob's Bate",
       "accountName":"Bob's Bate",
       "uwUserName":"Matt Peter",
       "approvalStatus":"Approved",
       "lob":"Medical"
    },
    "uwAdjustment":{
       "uwAdjustmentFactor":"0.1",
       "employerRiskFactor":"0.2",
       "salesAdjustmentFactor":"0.3",
       "wholeHealthAdjustmentFactor":"0.4",
       "uwNotesToSales":"test",
       "uwComments":"test",
       "contractEndDate":"",
       "exhibitName":"test",
       "approvalStatus":"quote",
       "submittedTimestamp":"2020-04-29 15:29:51.495"
    }
 };


 export const applyAdjResponse={
    "statusCode":"success",
    "statusMessage":"Rate calculation success"
 };


export const getFileResponse = {
    "contentData":"sample",
    "contentName":"Bob's Bate_Medical_PrintExhibit_2020-04-28T09_12_54_698.xlsx",
    "contentMIME":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "contentKey":"{56E7E10A-82B2-4726-A1A8-CAF6824F7C9A}",
    "contentSize":517933
 };


