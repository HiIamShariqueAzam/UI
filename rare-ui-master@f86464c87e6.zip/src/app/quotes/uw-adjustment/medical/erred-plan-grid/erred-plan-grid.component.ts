import { Component, OnInit, Output, Input, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: 'app-erred-plan-grid',
  templateUrl: './erred-plan-grid.component.html',
  styleUrls: ['./erred-plan-grid.component.css'],
  standalone: false,
})
export class ErredPlanGridComponent implements OnInit, OnChanges {
  RateInfo: any;
  @Input() quoteDetail: any;
  @Input() disableAll : boolean;
  @Input() allPlansDeleted : boolean;

  @Output() plansDeleted = new EventEmitter<any>();

  allChecked : boolean = false ;
  hasFailedPortfolioPlans: boolean = false ;
  plans: any[];
  validPlanTypes: string[] = ['F', 'P'];
  removedAllPlans: boolean = false;
  planColumns = [
    { header: "Error Info" },
    { header: "Plan Type" },
    { header: "Plan Name" },
    { header: "Contract Code" },
    { header: "Network" },
    { header: "Product Category" },
    { header: "Product Code" },
    { header: "Deductible Ind/Fam" },
    { header: "Coinsurance" },
    { header: "Out Of Pocket Ind/Fam" },
    { header: "Office Visit (PCP/Specialist/Preferred PCP) Copay" },
    { header: "Inpatient hospital copay" },
    { header: "Emergency room/urgent care copay" },
    { header: "Prescription drugs – retail" },
    { header: "Prescription drugs – mail order" }
  ];

  ngOnInit() {
    this.removedAllPlans = this.allPlansDeleted;
     
    if (this.quoteDetail.medical && [CommonConstants.ACA, CommonConstants.MEWA].includes(this.quoteDetail.quotingType)) {
      const newObjectsOfficeVisits = [
        { header: "Office Visit - PCP (Pref/INN) Copay" },
        { header: "Office Visit - SPC (Pref/INN) Copay" }
      ];
      this.planColumns.splice(10, 1, ...newObjectsOfficeVisits);
    }

    if (this.quoteDetail.medical && this.quoteDetail.quotingType == CommonConstants.MEWA) {
      const newObjects = [
        { header: "Prescription drugs - network/drug list" },
        { header: "Prescription deductible" },
        { header: "Deductible applies to tiers" },
      ];
      this.planColumns.splice(14, 0, ...newObjects);
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    this.removedAllPlans = this.allPlansDeleted;
    if(this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans){
      this.plans = this.quoteDetail.medical.proposedPlans.filter(plan => {
        return this.validPlanTypes.includes(plan.planTypeRequested) &&
        ((plan.errors && plan.rareError) || (!plan.status && !plan.factors ) || (plan.status && plan.status == "Failed"))
      });
    }
  }

  createToolTip(plan){
    return "toolTipDivPlan";
  }

  toolTipData(plan) {
    let errorData = '';
    if (plan.errors && plan.errors.rareError) {
      for (let error of plan.errors.rareError) {
        if (errorData)
          errorData = errorData + ' , ' + error.overallErrorMessage;
        else
          errorData = error.overallErrorMessage;
      }
    }
    return errorData;
  }

  checkForSelectedPlans(){
    this.allChecked = this.plans.filter(plan => plan.planTypeRequested === "P" && !plan.markedForDelete).length == 0 &&
      this.hasFailedPortfolioPlans;
  }

  selectAllPlans(selected: boolean, control: any) {
    this.plans.forEach(plan => plan.planTypeRequested  === "P" ? plan.markedForDelete = this.allChecked : plan.markedForDelete = false );
    this.checkForSelectedPlans();
    control.checked = this.allChecked;
  }

  removeSelectedPlans() {
    if(this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans){
      this.quoteDetail.medical.proposedPlans.forEach(plan => {
        if (plan.markedForDelete) {
          plan.planTypeRequested = "R";
        }
      });
      this.plans = this.quoteDetail.medical.proposedPlans.filter(plan => {
        return this.validPlanTypes.includes(plan.planTypeRequested) &&
        ((plan.errors && plan.rareError) || (!plan.status && !plan.factors ) || (plan.status && plan.status == "Failed"))
      });
    }
    this.checkForFailedPortFolioPlans();
    if(this.plans && this.plans.length == 0){
    this.removedAllPlans = true;
    this.plansDeleted.emit(true);
    }
    this.allChecked = false ;
  }

  checkForFailedPortFolioPlans() {
    this.hasFailedPortfolioPlans = this.plans.filter(plan => plan.planTypeRequested === "P").length == 0;
  }

  getBenefitData(node, data) {
    if (data === 'officeVisitPCPCopay') {
      return this.generateOfficeVistsCopay(node['ovPreferedPCPCopay'], node['ovPCPCopay']);
    } else if (data === 'officeVisitSPCCopay') {
      return this.generateOfficeVistsCopay(node['ovPreferedSPCCopay'], node['ovSCPCopay']);
    } else {
      if (node && node[data]) {
        return node[data];
      } else {
        return;
      }
    }
  }

  private generateOfficeVistsCopay(preferedOvCopay, innOvCopay) {
    if (preferedOvCopay && innOvCopay) {
      return preferedOvCopay + '/' + innOvCopay;
    } else if ((preferedOvCopay)) {
      return preferedOvCopay;
    } else if ((innOvCopay)) {
      return innOvCopay;
    }
    return "";
  }

}
