import { Injectable } from '@angular/core';
import { Enrollments, PlanComparison, PlanRates } from 'src/app/shared/models';
import { StringUtils } from 'src/app/shared/utils/string-utils';

@Injectable({
  providedIn: 'root',
})
export class ExpGrandTotalCalcService {
  
  calculateQuoteRates(mpc: any, proposedPlansCopy: any, quoteDetail: any, requestedTier: any, initialTier: any) {
    if (mpc && Object.keys(mpc).length > 0) {
      mpc.planComparison.forEach((pc: PlanComparison) => {
        pc = this.setEnrollmentsOnTierChange(pc, proposedPlansCopy, quoteDetail, requestedTier, initialTier, mpc);
      });
      mpc = this.calculateGrandTotal(mpc);
      return mpc;
    }
  } 

  private setEnrollmentsOnTierChange(pc: PlanComparison, proposedPlansCopy: any, quoteDetail: any, requestedTier: any, initialTier: any, mpc: any) {
    if (pc.quoteRates && pc.tempQuoteRatingPlanID) {
      let filteredPlan = this.getPlan(pc.tempQuoteRatingPlanID, proposedPlansCopy);
      pc.quoteTier = requestedTier * 1;
      if (filteredPlan) {
        pc.quoteRates = this.calculateRates(filteredPlan, requestedTier);
        if (quoteDetail && quoteDetail.medical && quoteDetail.medical.proposedPlans) {
          let plan = quoteDetail.medical.proposedPlans.find(p => p.contractCode == pc.quoteContractCode);
          if (plan && plan.includeInPrintExhibit != undefined && !plan.includeInPrintExhibit) {
            this.updateEnrolmentCounts(pc.quoteEnrollments, (requestedTier * 1));
            return pc;
          }
        }
        let isVirginGroup = (quoteDetail["virginGroup"]) || false;
        if (pc.quoteTier === initialTier) {
          if (mpc.userModified && !pc['calWholeCase']) {
            pc.quoteEnrollments = this.calculateQuoteEnrollments(
              this.getMPCinitialPlan(pc.quoteRatingPlanID, mpc).quoteEnrollments,
              requestedTier
            );
          }
          else if (pc.quoteTier === pc.currentTier && !isVirginGroup) {
            let cEnrollment = Object.assign({}, pc.currentEnrollments);
            pc.quoteEnrollments = this.calculateQuoteEnrollments(cEnrollment, requestedTier);
          }
          else {
            pc.quoteEnrollments = this.calculateEnrollments(filteredPlan,null,pc.currPlanId, quoteDetail, requestedTier);
          }
        }
        else {
          if (pc.quoteTier === pc.currentTier && !isVirginGroup) {
            let cEnrollment = Object.assign({}, pc.currentEnrollments);
            pc.quoteEnrollments = this.calculateQuoteEnrollments(cEnrollment, requestedTier);
          }
          else {
            pc.quoteEnrollments = this.calculateEnrollments(filteredPlan,null,pc.currPlanId, quoteDetail, requestedTier);
          }
        }
        pc.quoteRates = this.calculateQuoteTotal(pc.quoteRates, pc.quoteEnrollments);
      }
      pc = this.calculateQuoteDifferences(pc);
    }
    return pc;
  }
  
  getPlan(ratingPlanID: string, proposedPlansCopy: any) {
    let plan = proposedPlansCopy ? proposedPlansCopy.filter(pl => pl.ratingPlanID == ratingPlanID) : [];
    if (plan.length > 0) {
      return plan[0];
    }
    return null;
  }

  calculateRates(plan, requestedTier: number): PlanRates {
    let pr: PlanRates = new PlanRates();
    if (plan && plan.rateInfo) {
      pr.ratesT1 = plan.rateInfo.single || 0;
      switch (requestedTier * 1) {
        case 2:
          pr.ratesT2 = plan.rateInfo.family || 0;
          break;
        case 3:
          pr.ratesT2 = plan.rateInfo.eeOne || 0;
          pr.ratesT3 = plan.rateInfo.family || 0;
          break;
        case 4:
          pr.ratesT2 = plan.rateInfo.eeSpouse || 0;
          pr.ratesT3 = plan.rateInfo.eeChildren || 0;
          pr.ratesT4 = plan.rateInfo.family || 0;
          break;
        case 5:
          pr.ratesT2 = plan.rateInfo.eeSpouse || 0;
          pr.ratesT3 = plan.rateInfo.eeChild || 0;
          pr.ratesT4 = plan.rateInfo.eeChildren || 0;
          pr.ratesT5 = plan.rateInfo.family || 0;
          break;
      }
    }
    return pr;
  }

  updateEnrolmentCounts(enrolmentObj: any, tierLimit) {
    for (let tierVal = tierLimit; tierVal >= 1; tierVal--) {
      enrolmentObj['enrollT' + tierVal] = 0;
    }
  }

  calculateQuoteEnrollments(en, qt) {
    en.totalEnroll = 0;
    switch (qt * 1) {
      case 1:
        if (!en.enrollT1) en.enrollT1 = 0;
        en.enrollT2 = null;
        en.enrollT3 = null;
        en.enrollT4 = null;
        en.enrollT5 = null;
        break;
      case 2:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        en.enrollT3 = null;
        en.enrollT4 = null;
        en.enrollT5 = null;
        break;
      case 3:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        if (!en.enrollT3) en.enrollT3 = 0;
        en.enrollT4 = null;
        en.enrollT5 = null;
        break;
      case 4:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        if (!en.enrollT3) en.enrollT3 = 0;
        if (!en.enrollT4) en.enrollT4 = 0;
        en.enrollT5 = null;
        break;
      case 5:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        if (!en.enrollT3) en.enrollT3 = 0;
        if (!en.enrollT4) en.enrollT4 = 0;
        if (!en.enrollT5) en.enrollT5 = 0;
        break;
    }
    for (let i = 1; i <= 5; i++) {
      en.totalEnroll += this.getCalculatedEnrollments(en, i);
    }
    return en;
  }

  getCalculatedEnrollments(enrollment: Enrollments, index: number): number {
    let tierEnroll = enrollment["enrollT" + index];
    return tierEnroll && !isNaN(tierEnroll) ? tierEnroll * 1 : 0;
  }

  getMPCinitialPlan(planID, mpc: any) {
    let plan = mpc.planComparison.find(
      x => x.quoteRatingPlanID === planID
    );
    return JSON.parse(JSON.stringify(plan));
  }

  calculateEnrollments(plan, tier?: any, currentPlanIDFromPC?:any, quoteDetail?: any, requestedTier?: any): Enrollments {
    let en = new Enrollments();
    let index = tier ? (tier + '-tier') : (requestedTier + '-tier');
    let calculatedLives = (quoteDetail["factors"] && quoteDetail["factors"].calculatedTierLives) || {};
    let lives = calculatedLives ? calculatedLives[index] : {};
    if (!tier && requestedTier) {
      //this means that the underwriter has done a tierChange selection on the Renewal quoteDetailPage
      //in such cases as per ALGR-90969 use the actual census instead of wholecase
      let currentPlanID;
      if (StringUtils.isEmpty(currentPlanIDFromPC)) {
        if (typeof (plan.currPlanId) == 'string') {
          currentPlanID = plan.currPlanId;
        }
        else {
          currentPlanID = plan.currPlanId[0];
        }
      }
      else {
        currentPlanID = currentPlanIDFromPC;
      }
      var matchingPlanComparison;
      if (quoteDetail.medicalPremiumComparison && quoteDetail.medicalPremiumComparison.planComparison) {
        for (const element of quoteDetail.medicalPremiumComparison.planComparison) {
          if (element.currPlanId === currentPlanID) {
            matchingPlanComparison = element;
            break;
          }
        }
        if (matchingPlanComparison && matchingPlanComparison.tierAdjustedLivesMap && matchingPlanComparison.tierAdjustedLivesMap[index]) {
          lives = matchingPlanComparison.tierAdjustedLivesMap[index];
        }
      }
    }

    if (lives) {
      en.enrollT1 = lives.eeCount * 1;
      en.totalEnroll = 0;
      switch (tier ? (tier * 1) : (requestedTier * 1)) {
        case 2:
          en.enrollT2 = (lives.efCount || 0) * 1;
          break;
        case 3:
          en.enrollT2 = (lives.e1Count || 0) * 1;
          en.enrollT3 = (lives.efCount || 0) * 1;
          break;
        case 4:
          en.enrollT2 = (lives.esCount || 0) * 1;
          en.enrollT3 = (lives.ecCount || 0) * 1;
          en.enrollT4 = (lives.efCount || 0) * 1;
          break;
        case 5:
          en.enrollT2 = (lives.esCount || 0) * 1;
          en.enrollT3 = (lives.ekCount || 0) * 1;
          en.enrollT4 = (lives.ecCount || 0) * 1;
          en.enrollT5 = (lives.efCount || 0) * 1;
          break;
      }
      for (let i = 1; i <= 5; i++) {
        en.totalEnroll += this.getCalculatedEnrollments(en, i);
      }
    }
    return en;
  }

  calculateQuoteTotal(pr: PlanRates, en: Enrollments): PlanRates {
    pr.monthlyTotal = 0;
    for (let i = 1; i <= 5; i++) {
      pr.monthlyTotal += this.getCalculatedRates(en, pr, i);
    }
    pr.yearlyTotal = this.roundedValue(pr.monthlyTotal * 12);
    return pr;
  }

  getCalculatedRates(enrollment: Enrollments, rate: PlanRates, index: number): number {
    let tierRate: string = '' + rate["ratesT" + index];
    if (tierRate) {
      tierRate = tierRate.replace("$", "").replace(/,/g, "");
    }
    return tierRate && !isNaN(parseFloat(tierRate)) ? parseFloat(tierRate) * this.getCalculatedEnrollments(enrollment, index) * 1 : 0;
  }

  roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }

  calculateQuoteDifferences(pc: PlanComparison): PlanComparison {
    pc.diffToCurrentMonthlyRate = pc.quoteRates.monthlyTotal - pc.currentRates.monthlyTotal;
    pc.diffToCurrentYearlyRate = pc.quoteRates.yearlyTotal - pc.currentRates.yearlyTotal;
    if (pc.currentRates.monthlyTotal)
      pc.diffToCurrentRatePercentage = pc.diffToCurrentMonthlyRate / pc.currentRates.monthlyTotal;
    else pc.diffToCurrentRatePercentage = 0;
    if (pc.hasRenewalRates) {
      pc.diffToRenewalMonthlyRate = pc.quoteRates.monthlyTotal - pc.renewalRates.monthlyTotal;
      pc.diffToRenewalYearlyRate = pc.quoteRates.yearlyTotal - pc.renewalRates.yearlyTotal;
      pc.diffToRenewalRatePercentage = pc.diffToRenewalMonthlyRate / pc.renewalRates.monthlyTotal;
    }
    return pc;
  }

  calculateGrandTotal(mpc: any) {
    mpc.currentMonthlyGrandTotal = 0;
    mpc.currentYearlyGrandTotal = 0;
    mpc.quoteMonthlyGrandTotal = 0;
    mpc.quoteYearlyGrandTotal = 0;
    mpc.renewalMonthlyGrandTotal = 0;
    mpc.renewalYearlyGrandTotal = 0;
    let hasRenewalRates: boolean = false;
    mpc.planComparison.forEach((pc: PlanComparison) => {
      if (pc.quoteRates && pc.quoteRatingPlanID) {
        if (pc.currentRates.monthlyTotal && pc.currentRates.yearlyTotal != undefined) {
          mpc.currentMonthlyGrandTotal += pc.currentRates.monthlyTotal;
          mpc.currentYearlyGrandTotal += pc.currentRates.yearlyTotal;
        }
        if (pc.quoteRates.monthlyTotal && pc.quoteRates.yearlyTotal != undefined) {
          mpc.quoteMonthlyGrandTotal += pc.quoteRates.monthlyTotal;
          mpc.quoteYearlyGrandTotal += pc.quoteRates.yearlyTotal;
        }
        if (pc.hasRenewalRates) {
          mpc.renewalMonthlyGrandTotal += pc.renewalRates.monthlyTotal;
          mpc.renewalYearlyGrandTotal += pc.renewalRates.yearlyTotal;
          hasRenewalRates = true;
        }
      }
    });

    mpc.diffToCurrentMonthlyTotal = mpc.quoteMonthlyGrandTotal - mpc.currentMonthlyGrandTotal;
    mpc.diffToCurrentYearlyTotal = mpc.quoteYearlyGrandTotal - mpc.currentYearlyGrandTotal;
    if (mpc.currentMonthlyGrandTotal)
      mpc.diffToCurrentRatePercentage = mpc.diffToCurrentMonthlyTotal / mpc.currentMonthlyGrandTotal;
    else mpc.diffToCurrentRatePercentage = 0;

    if (hasRenewalRates) {
      mpc.diffToRenewalMonthlyTotal =
        mpc.quoteMonthlyGrandTotal - mpc.renewalMonthlyGrandTotal;
      mpc.diffToRenewalYearlyTotal =
        mpc.quoteYearlyGrandTotal - mpc.renewalYearlyGrandTotal;
      if (mpc.renewalMonthlyGrandTotal) {
        mpc.diffToRenewalRatePercentage = mpc.diffToRenewalMonthlyTotal / mpc.renewalMonthlyGrandTotal;
        mpc.differenceToCurrentRenewalYearlyTotal = mpc.renewalYearlyGrandTotal - mpc.currentYearlyGrandTotal;
        mpc.renewalIncreasePercentage = mpc.differenceToCurrentRenewalYearlyTotal / mpc.currentYearlyGrandTotal;
      } else {
        mpc.diffToRenewalRatePercentage = 0;
        mpc.renewalIncreasePercentage = 0;
      }
    }
    return mpc;
  }
  
}
