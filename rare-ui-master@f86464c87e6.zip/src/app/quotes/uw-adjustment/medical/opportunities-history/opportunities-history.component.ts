import { AfterViewInit, Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { RenewalsConstants } from 'src/app/renewals/renewals-constants';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { CommonUtil } from 'src/app/shared/utils/common-util';

@Component({
  selector: "app-opportunities-history",
  templateUrl: "./opportunities-history.component.html",
  styleUrls: ["./opportunities-history.component.css"],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class OpportunitiesHistoryComponent implements OnInit , AfterViewInit{

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  @Input() opportunities: any;
  @Input() isParentQuoteAutoRunBatch: boolean;
  @Input() isAutoRunHistory: boolean;
  @Input() quoteHistory: boolean;
  @ViewChild('closeModal') private closeModal: ElementRef;
  @ViewChild('myModal', { static: false }) modal: ElementRef;

  QuoteLEoption = 'Anthem';
  quoteNonWholeCaseStr = 'Non-Whole Case';
  lob_FT: any[];
  ratingTransID: string;
  quoteHeaderID: string;
  oppID: string;
  lob: string;
  quoteOrigin: string;
  userRole: any;
  userRoleTextToDisplay: any;
  insertedTimestamp: any;
  lob_FT_TransID = [];
  columns = [
    {
      header: 'Version',
      field: 'Version'
    },
    {
      header: 'Eff Date',
      field: 'contractEffectiveDate'
    },
    {
      header: 'Quote Name',
      field: 'quoteDescription'
    },
    {
      header: 'Submitted Time (EST)',
      field: 'submittedTimestamp'
    },
    {
      header: 'Status',
      field: 'status'
    },
    {
      header: 'UW Name',
      field: 'underwriterName'
    },
    {
      header: 'UW Notes',
      field: 'currentAdjustment'
    },
    {
      header: 'Batch Name',
      field: 'batchName'
    },
    {
      header: 'Last Updated (EST)',
      field: 'currentAdjustment'
    },
    {
      header: 'Last Updated by',
      field: 'currentAdjustment'
    },
    {
      header: 'Submitted by',
      field: 'submitterUserInfo'
    }
  ];

  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private router: Router,
    private commonQuoteService: CommonQuoteService
  ) {
    config.backdrop = 'static';
    config.keyboard = false;
  }


  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  } 
  
  ngOnInit() {
    this.userRole = this.authenticationService.userRole['_value'];
  }

  addClaimsAsoDDateCol(quoteHistory) {
    if ((this.isAutoRunHistory || this.isParentQuoteAutoRunBatch) && !quoteHistory) {
      let colLength = this.columns.filter((col) => col.field === 'claimsAsOfDate').length;
      if (colLength == 0) {
        const claimsAsOfDate = {
          header: 'Claims As Of Date',
          field: 'claimsAsOfDate'
        };
        this.columns.splice(2, 0, claimsAsOfDate);
      }
    } else {
      this.columns = this.columns.filter((col) => col.field !== 'claimsAsOfDate');
    }
  }

  open(quoteHistory: boolean) {
    this.addClaimsAsoDDateCol(quoteHistory);
    this.modal.nativeElement.style.display = 'block';
  }

  close() {
    this.modal.nativeElement.style.display = 'none';
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event): void {
    if (event.target == this.modal.nativeElement) {
      this.modal.nativeElement.style.display = 'none';
      return;
    }
  }

  formatDate(timestamp) {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  }

  onGoToPage(rowData, $event) {
    this.ratingTransID = rowData['ratingTransID'];
    this.quoteHeaderID = rowData['quoteHeaderID'];
    this.lob = rowData.lob;
    (this.quoteOrigin = rowData.quoteOrigin), (this.oppID = rowData.opportunityID);
    this.insertedTimestamp = rowData.insertedTimestamp;
    this.lob_FT_TransID = [];
    this.lob_FT = [];
    let gotMatchedRow: any = false;
    this.commonQuoteService.getOpportunitesByOppID(this.oppID, this.lob).subscribe(
      (response) => {
        if (response != null) {
          for (var opp of response.opportunities) {
            if (opp && opp.quoteHeaderID === this.quoteHeaderID) {
              let data =
                opp.lob == 'Medical'
                  ? opp.quotingType == 'ACA' || opp.quotingType == 'MEWA'
                    ? opp.lob + '-' + opp.quotingType
                    : opp.lob + '-' + rowData.fundingType
                  : opp.lob + '-' + opp.fundingType;
              if (!this.lob_FT.find((x) => x === data)) {
                this.lob_FT.push(data);
                this.lob_FT_TransID.push({
                  tabName: data,
                  ratingTransID: opp.ratingTransID,
                  fundingType: opp.fundingType,
                  quoteOrigin: opp.quoteOrigin
                });
              }
            }
          }
          this.lob_FT = this.lob_FT.sort(function (a, b) {
            return a > b ? 1 : a < b ? -1 : 0;
          });
          this.commonService.setQuoteTabList(this.lob_FT_TransID);
          gotMatchedRow = rowData.quoteOrigin == RenewalsConstants.AUTO_RUN_BATCH && rowData.current == true;
          this.authenticationService.userRoleTextToDisplay.subscribe((data) => {
            this.userRoleTextToDisplay = data;
          });
          if (this.ratingTransID) {
            const url = this.router.serializeUrl(
              this.router.createUrlTree(['/quote/uw-rate'], {
                queryParams: {
                  quoteHeaderID: this.quoteHeaderID,
                  opportunityID: this.oppID,
                  ratingTransID: this.ratingTransID,
                  lob: rowData.lob,
                  fundingType: rowData.fundingType,
                  availableTabs: this.lob_FT,
                  insertedTimestamp: this.insertedTimestamp,
                  isLoginAgain: true,
                  disableAll: true,
                  quoteOrigin: this.quoteOrigin,
                  marketSegment: rowData['marketSegment'],
                  isEnableQuoteHistory: gotMatchedRow ? gotMatchedRow : false // Here isEnableQuoteHistory data has been added in queryParams to show the quote History for Auto_Run_Batches where isCurrent=true.
                }
              })
            );
            if (/Edge/.test(navigator.userAgent)) {
              if (localStorage.getItem('isLoginAgain')) this.commonService.removeHistoryLocalStorage();
            }
            localStorage.setItem('quoteHeaderID', this.quoteHeaderID);
            localStorage.setItem('opportunityID', this.oppID);
            localStorage.setItem('ratingTransID', this.ratingTransID);
            localStorage.setItem('quoteOrigin', this.quoteOrigin);
            localStorage.setItem('lob', rowData.lob);
            localStorage.setItem('fundingType', rowData.fundingType);
            localStorage.setItem('insertedTimestamp', this.insertedTimestamp);
            localStorage.setItem('availableTabs', this.lob_FT.map((x) => x).join(','));
            localStorage.setItem('isLoginAgain', 'true');
            localStorage.setItem('assignedUserRoles', this.authenticationService.getUserRole());
            localStorage.setItem('assignedUserRolesTextToDisplay', this.authenticationService.getUserRoleTextToDisplay());
            localStorage.setItem('assignedUserLobs', this.authenticationService.getUserLob());
            localStorage.setItem('assignedUserStates', this.authenticationService.getUserState());
            localStorage.setItem('disableAll', 'true');
            localStorage.setItem('isEnableQuoteHistory', gotMatchedRow);
            localStorage.setItem('role', this.userRoleTextToDisplay);
            window.open(url, '_blank');
          } else {
            alert('Please select the Opportunity ');
          }
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }

  isDisableAction(opportunities) {
    return opportunities.current && (this.isParentQuoteAutoRunBatch || opportunities.quoteOrigin !== RenewalsConstants.AUTO_RUN_BATCH);
  }

  disableForReadonly() {
    if (this.userRole.includes('READONLY')) {
      return true;
    } else {
      return false;
    }
  }

  getTooltipcontent(value) {
   return  value?.length > 100 ? value: ''
  }

  showColValue(value) {
    if(value?.length > 100) {
      return value.substring(0, 100) + '...';
    } else  {
      return value;
    }
   }
}
