import { Component, Inject, OnInit, OnDestroy, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { AuthenticationService, CacheService, CommonService, PrintExhibitService, ProcessQuoteDetailsService } from 'src/app/shared/services';
import { OffCycleModalService } from 'src/app/shared/services/off-cycle-modal.service';
import { OffCycleModalComponent } from 'src/app/shared/components/off-cycle-modal/off-cycle-modal.component';
import { UnderwriterAdjustmentService } from './uw-adjustment.service';
import { UWAdjustmentChangeSetService } from './uw-adjust-changeset.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { DatePipe, Location } from '@angular/common';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { CommonQuoteService } from '../../services/common-quote.service';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { DateUtil } from 'src/app/shared/utils/date-util';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { RenewalsConstants } from 'src/app/renewals/renewals-constants';
import { RenewalsService } from 'src/app/renewals/services/renewals.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-medical',
  templateUrl: './medical.component.html',
  styleUrls: ['./medical.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class MedicalComponent implements OnInit, OnDestroy {
  private eventSources: EventSource[] = [];
  declineQuoteBool: boolean = false;
  gridApi;
  gridColumnApi;

  RateData: any = {};
  statusReasonsObj: any;
  InitialRateData: any = {};
  removedPlanids: any[];
  abfSLDefaultValues: any = {};
  public isAdjCollapsed = false;

  public div_visible = false;

  public disableSoldTab = false;

  public disableReleaseTab = false;

  public disableDeclineTab = false;
  showRequoteModal: boolean = false;
  sslDataLoaded: boolean = false;
  opportunityData: any = {};
  AdjData: any;
  changeSetDetail: any;
  disableprint: boolean = false;
  hasAdjustmentUpdates: boolean = false;
  accountName = 'Loading';
  hasAdjustmentErrors: any = {};
  hasPEOverrideError: boolean = false;
  noData: string = 'Not Available';
  hasRiskScore: boolean = false;
  hasFeaturedPlanFailures: boolean = false;
  tierRatioGuardrailFailure: boolean = false;
  hasPortfolioPlanFailures: boolean = false;
  portfolioPlanCount = 0;
  featuredPlanCount = 0;
  erredPlanCount = 0;

  portfolioPlanLoaded: boolean = false;
  featuredPlanLoaded: boolean = false;
  erredPlanLoaded: boolean = false;

  hasPortfolioPlans: boolean = false;
  hasFeaturedPlans: boolean = false;
  hasErredPlans: boolean = false;

  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  successMessage: any;

  failureMessage: any;
  warningMessage: any;
  loadingMessage = CommonConstants.QUOTE_DETAILS_LOADING_MESSAGE;

  alertData: any;

  metaTransID: string;
  status: string;
  isPending = false;
  selectedPlan: any;
  intervalId: any;
  estimatedClaimsObj: any;

  lobVision = CommonConstants.Vision;
  quoteError: any = '';
  quoteErrorCode: any = '';
  activeTab: any = CommonConstants.featured;
  adjustmentChange: any = {};
  disableAll: boolean = false;
  enableQuoteHistory: boolean = false;
  isApplyAdjustmentsave: boolean = false;

  userRole: any;
  quoteReason: any;
  reQuoteData: any;
  refreshPrintExhibits: any;
  currentTab: any;
  lob_FT: any[];
  userSelectionChanges: any;
  isReadOnlyRole: boolean = false;
  tierKey: any;
  initializeQuote: boolean = false;
  noOfPlans: number = 0;
  noOfPlansLoadComplete: number = 0;
  allPlansLoaded: boolean = false;
  uwLoaded: boolean = false;
  factorsAndTierLivesLoaded: boolean = false;
  receivedEventsList: any = [];
  allFeaturedPlanDeleted: boolean = false;
  allPortfolioPlanDeleted: boolean = false;
  allErrerdPlanDeleted: boolean = false;
  exhibitDocs: any = [];
  exhibitSheets: any = [];
  readonly messages = {
    errorMessageTier: 'Please select the Tier',
    errorMessageAdjFactor: 'Please Enter Adjustment Factor',
    errorMessageEmpRisk: 'Please Enter Employee Risk Factor',
    errorMessageDisc: 'Please Enter UW Discount',
    errorMessageOP: 'Please Enter Output Tier',
    errorMessageSalesNote: 'Please Enter note to sales',
    errorMessageSelfNote: 'Please Enter  note to self',
    errorMessageORDate: 'Please select Contract End Date Override',
    errorMessageExhibit: 'Please Enter Exhibit Name'
  };
  inValidRates: boolean;
  erFundLvlDfltVal: any = {};
  experienceSumData: any = {};
  declineReasons: any[] = [];
  declineCheckboxes: any[] = [];
  planSectionCollpse = false;
  statusReasons: string = '';
  releaseType: any[] = [];
  isOldRiskScoreVersion: boolean = true;
  public showAdjustmentHistory: boolean = true;
  whAdjustmentsDetails: any;
  uwAdjustmentFetchObject: any;
  displayStatusError = false;
  isInitialQuoteUpdate: boolean = false;
  quotingTypeFromTab: string;
  searchAnywhere: string;
  alternateQuote: boolean;
  LGFItoSGAbfCrossSelling: boolean;
  isCrossSelled: boolean;
  curvRiskScore: any;
  sseCurvRiskScore: string = null;
  enableRiskScoreFlash: boolean = true;
  disableAutoRunConvert: boolean = false;
  factorOrAdjustmentFetched$: Subject<void> = new Subject<void>();
  isSetRateAdjFormLoaded: boolean = false;

  groupExperienceData:any = null;

  constructor(
    private commonService: CommonService,
    private cacheService: CacheService,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthenticationService,
    private _location: Location,
    config: NgbModalConfig,
    private modalService: NgbModal,
    public datepipe: DatePipe,
    private uwService: UnderwriterAdjustmentService,
    private peService: PrintExhibitService,
    private uwChangeSetService: UWAdjustmentChangeSetService,
    private processQuoteService: ProcessQuoteDetailsService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private commonQuoteService: CommonQuoteService,
    public renewalsService: RenewalsService,
    private renderer: Renderer2,
    public offCycleModalService: OffCycleModalService
  ) {
    config.backdrop = 'static';
    config.keyboard = false;
    this.disableSoldTab = true;
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.router.navigated = false;
        window.scrollTo(0, 0);
      }
    });
  }

  open(content) {
    this.modalService.open(content);
  }
  checkUserRole() {
    if (this.userRole.includes(CommonConstants.ADMIN) || this.userRole.includes(CommonConstants.READONLY)) {
      return true;
    } else if (this.userRole.includes(CommonConstants.ADMIN) && !this.userRole.includes(CommonConstants.READONLY)) {
      return false;
    }
  }

  isTabActive(plan) {
    this.activeTab = plan;
  }
  checkTabData() {
    const medicalPlanTabsWrapper = document.querySelector('.nav-pills-wrapper');
    const tabCount = medicalPlanTabsWrapper.querySelectorAll('li').length;
    if (tabCount == 2) {
      return 'tabWidth_2';
    }
    if (tabCount == 3) {
      return 'tabWidth_3';
    }
    if (tabCount > 3) {
      return 'tabWidth_4';
    }
    return 'tabWidth';
  }

  checkIfEventRecieved(eventType: string) {
    if (this.receivedEventsList && this.receivedEventsList.includes(eventType)) return true;
    else return false;
  }

  reloadPage() {
    this.noOfPlans = 0;
    this.noOfPlansLoadComplete = 0;
    this.hasFeaturedPlans = false;
    this.hasPortfolioPlans = false;
    this.hasErredPlans = false;
    this.receivedEventsList = [];
    this.featuredPlanLoaded = false;
    this.hasPortfolioPlanFailures = false;
    this.hasFeaturedPlanFailures = false;
    this.portfolioPlanLoaded = false;
    this.erredPlanLoaded = false;
    this.allPlansLoaded = false;
    this.uwLoaded = false;
    this.factorsAndTierLivesLoaded = false;
    this.portfolioPlanCount = 0;
    this.featuredPlanCount = 0;
    this.erredPlanCount = 0;
    this.isSetRateAdjFormLoaded = false;
    this.loadRateInfo();
  }

  loadRateInfo() {
    this.quoteError = '';
    this.quoteErrorCode = '';
    this.commonQuoteService
      .getRateInfoInitialResponse(
        this.opportunityData.ratingTransID,
        this.opportunityData.opportunityID,
        this.opportunityData.quoteHeaderID,
        this.opportunityData.quoteOrigin,
        this.opportunityData.lob,
        this.opportunityData.fundingType
      )
      .subscribe(
        (response) => {
          let quotingType;
          var source = this.commonService.listenForStream(response.processId);
          this.eventSources.push(source);
          source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS, (event: any) => {
            if (event && event.data) {
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data && data.payload.metadata) {
                if(data?.payload?.data) {
                  this.estimatedClaimsObj = {
                    'estimatedAllowedClaims': data.payload.data?.estimatedAllowedClaims,
                    'curvReportLink': data.payload.data?.curvReportLink
                  }
                }
                this.handleRateInitialResponse(data.payload.metadata, data.payload.data);
                this.initializeQuote = true;
                quotingType = data.payload.data.quotingType;
                let fundingType = CommonConstants.MEWA == quotingType ? quotingType : this.opportunityData.fundingType;
                this.commonQuoteService
                  .getStatusReasonsOptions(this.opportunityData.lob, fundingType, this.opportunityData.ratingTransID)
                  .subscribe((response) => {
                    this.statusReasonsObj = response?.data ? response.data : {};
                  });
              }
            }
          });
          source.addEventListener(CommonConstants.OTHER_DETAILS_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.OTHER_DETAILS_FETCH)) {
              this.receivedEventsList.push(CommonConstants.OTHER_DETAILS_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handleFactorsAndTierLives(data.payload.data);
                this.factorsAndTierLivesLoaded = true;
              }
            }
          });
          source.addEventListener(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH)) {
              this.receivedEventsList.push(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handleUWResponse(data.payload.data);
                this.uwLoaded = true;
              }
              if (StringUtils.isUndefined(data.payload.data[CommonConstants.uwAdjustment])) {
                this.showAdjustmentHistory = false;
              } else {
                this.showAdjustmentHistory = true;
              }
            }
          });
          source.addEventListener(CommonConstants.MEDICAL_PREMIUM_COMPARISON_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.MEDICAL_PREMIUM_COMPARISON_FETCH)) {
              this.receivedEventsList.push(CommonConstants.MEDICAL_PREMIUM_COMPARISON_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handleMPCResponse(data.payload.data);
              }
              if (this.hasAdjustmentErrors) {
                this.updatePlanLevelAdjustments(this.hasAdjustmentErrors);
              }
            }
          });
          source.addEventListener(CommonConstants.ASSUMPTIONS_AND_CONDITIONS_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.ASSUMPTIONS_AND_CONDITIONS_FETCH)) {
              this.receivedEventsList.push(CommonConstants.ASSUMPTIONS_AND_CONDITIONS_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handleAssumptionsAndConditions(data.payload.data);
              }
            }
          });
          source.addEventListener(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH)) {
              this.receivedEventsList.push(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handleGRFSKResponse(data.payload.data);
              }
            }
          });
          source.addEventListener(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH);
              if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                let dataObj = JSON.parse(JSON.stringify(data.payload.data));
                if (dataObj.dataExists) {
                  this.hasFeaturedPlans = true;
                  this.noOfPlans++;
                }
              } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
            } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
              this.allPlansLoaded = true;
            }
          });
          source.addEventListener(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH);
              if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                let dataObj = JSON.parse(JSON.stringify(data.payload.data));
                if (dataObj.dataExists) {
                  this.hasPortfolioPlans = true;
                  this.noOfPlans++;
                }
              } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
            } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
              this.allPlansLoaded = true;
            }
          });
          source.addEventListener(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH);
              if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                let dataObj = JSON.parse(JSON.stringify(data.payload.data));
                if (dataObj.dataExists) {
                  this.hasErredPlans = true;
                  this.noOfPlans++;
                }
              } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
            } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
              this.allPlansLoaded = true;
            }
          });
          source.addEventListener(CommonConstants.AGGREGATED_PROPOSED_PLANS_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.AGGREGATED_PROPOSED_PLANS_FETCH)) {
              this.receivedEventsList.push(CommonConstants.AGGREGATED_PROPOSED_PLANS_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handlePlanData(data.payload.data);
                this.initializeMedicalPlans();
              }
            }
          });
          source.addEventListener(CommonConstants.FEATURED_PLAN_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_FETCH)) {
              this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handlePlanData(data.payload.data);
                this.loadFeaturedMedicalPlans();
                this.featuredPlanLoaded = true;
                this.noOfPlansLoadComplete++;
                if (!this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH)) {
                  this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH);
                  this.hasFeaturedPlans = true;
                  this.noOfPlans++;
                }
                if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                  this.allPlansLoaded = true;
                }
                if (this.hasAdjustmentErrors) {
                  this.updatePlanLevelAdjustments(this.hasAdjustmentErrors);
                }
              } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
            } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
              this.allPlansLoaded = true;
            }
          });
          source.addEventListener(CommonConstants.PORTFOLIO_PLAN_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_FETCH)) {
              this.receivedEventsList.push(CommonConstants.PORTFOLIO_PLAN_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handlePlanData(data.payload.data);
                this.loadPortFolioMedicalPlans();
                this.portfolioPlanLoaded = true;
                this.noOfPlansLoadComplete++;
                if (!this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH)) {
                  this.receivedEventsList.push(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH);
                  this.hasPortfolioPlans = true;
                  this.noOfPlans++;
                }
                if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                  this.allPlansLoaded = true;
                }
                if (this.hasAdjustmentErrors) {
                  this.updatePlanLevelAdjustments(this.hasAdjustmentErrors);
                }
              } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
            } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
              this.allPlansLoaded = true;
            }
          });
          source.addEventListener(CommonConstants.ERROR_PLAN_FETCH, (event: any) => {
            if (event && event.data && !this.checkIfEventRecieved(CommonConstants.ERROR_PLAN_FETCH)) {
              this.receivedEventsList.push(CommonConstants.ERROR_PLAN_FETCH);
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.data) {
                this.handlePlanData(data.payload.data);
                this.loadErrordMedicalPlans();
                this.noOfPlansLoadComplete++;
                if (!this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
                  this.receivedEventsList.push(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH);
                  this.hasErredPlans = true;
                  this.noOfPlans++;
                }
                if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                  this.allPlansLoaded = true;
                }
                if (this.hasAdjustmentErrors) {
                  this.updatePlanLevelAdjustments(this.hasAdjustmentErrors);
                }
              } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
                this.allPlansLoaded = true;
              }
            } else if (this.noOfPlans == this.noOfPlansLoadComplete && this.getEventReceivedStatus()) {
              this.allPlansLoaded = true;
            }
          });
          source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS_COMPLETE, (event: any) => {
            source.close();
            this.initializePlans();
            this.isSetRateAdjFormLoaded = true;
          });
          source.addEventListener(CommonConstants.FAILED, (message: any) => {
            this.accountName = CommonConstants.DISABLE_ALL;
            this.alertData = CommonConstants.ALERT_MESSAGE;
            source.close();
            console.error('Received fail event for : loadRateInfo()');
            this.div_visible = false;
          });
        },
        (error) => {
          this.div_visible = false;
          console.error(error);
        }
      );
    }

  ngOnInit() {
    window.scroll(0, 0);
    this.route.queryParams.subscribe((params) => {
      this.lob_FT = params[CommonConstants.AVAILABLE_TABS];
      this.quotingTypeFromTab = params[CommonConstants.QUOTINGTYPE_FROM_TAB];
      var disableAllBoolean = params[CommonConstants.DISABLE_ALL];
      this.disableAll = disableAllBoolean != undefined && disableAllBoolean === 'true';
      var enableQuoteHistoryBoolean = params[CommonConstants.IS_ENABLE_QUOTE_HISTORY];
      this.searchAnywhere = params[CommonConstants.SELECTED_SEARCH_ANYWHERE];
      this.enableQuoteHistory = !StringUtils.isUndefined(enableQuoteHistoryBoolean) && enableQuoteHistoryBoolean === 'true';
      this.userRole = params['role'];
      this.opportunityData = {
        opportunityID: params[CommonConstants.OPPORTUNITY_ID],
        quoteHeaderID: params[CommonConstants.QUOTEHEADER_ID],
        ratingTransID: params[CommonConstants.RATINGTRANS_ID],
        lob: params[CommonConstants.LOB],
        fundingType: params[CommonConstants.FUNDING_TYPE],
        quoteOrigin: params[CommonConstants.QUOTE_ORIGIN],
        marketSegment: params[CommonConstants.MARKET_SEGMENT],
        insertedTimestamp: params['insertedTimestamp']
      };
      this.checkUnderwriterList();
      this.getCurrentTabList(params['currentTab']);
    });
    this.loadRateInfo();
    this.refreshPrintExhibits = { refresh: true };
    this.userRole = this.authService.userRole['_value'];
    this.commonService.setOpportunityId(this.opportunityData.opportunityID);
    this.commonService.setquoteHeaderId(this.opportunityData.quoteHeaderID);


    this.factorOrAdjustmentFetched$.subscribe(()=> {
      this.setMissingCompAdjustmentData();
    })
  }

  checkUnderwriterList() {
    if (!Object.keys(this.commonQuoteService.underwriterList).length) {
      this.commonQuoteService.getUnderwriters();
    }
  }

  getCurrentTabList(currentTab) {
    let tabList = this.commonService.getQuoteTabList();
    if (tabList && tabList.length) {
      this.currentTab =
        currentTab === undefined ? this.commonService.getCurrentTab(this.opportunityData.ratingTransID, this.opportunityData['lob']) : currentTab;
    } else {
      this.commonQuoteService.getOpportunitesByOppID(this.opportunityData.opportunityID, this.opportunityData.lob).subscribe((response) => {
        if (response != null) {
          let lob_FT = [];
          let lob_FT_TransID = [];
          for (var opp of response.opportunities) {
            if (opp && opp.quoteHeaderID === this.opportunityData[CommonConstants.QUOTEHEADER_ID]) {
              let data =
                StringUtils.isEqual(opp.lob, CommonConstants.Medical) &&
                StringUtils.isEqual(opp.opportunityType, CommonConstants.RENEWAL_LOCAL) &&
                (StringUtils.isEqual(opp.quotingType, CommonConstants.ACA) || StringUtils.isEqual(opp.quotingType, CommonConstants.MEWA))
                  ? opp.lob + '-' + opp.quotingType
                  : opp.lob + '-' + opp.fundingType;
              if (opp.marketSegment === this.opportunityData.marketSegment) {
                if (!lob_FT.find((x) => x === data && x.opportunityType === opp.opportunityType)) {
                  lob_FT.push(data);
                }
                lob_FT_TransID.push({
                  tabName: data,
                  tabStatus: opp.status,
                  ratingTransID: opp.ratingTransID,
                  fundingType: opp.fundingType,
                  quoteOrigin: opp.quoteOrigin
                });
              }
            }
          }
          this.commonService.setQuoteTabList(lob_FT_TransID);
          this.currentTab =
            currentTab === undefined ? this.commonService.getCurrentTab(this.opportunityData.ratingTransID, this.opportunityData['lob']) : currentTab;
        }
      });
    }
  }

  isTabDisabled(tabName: string) {
    return this.commonQuoteService.shouldDisableTab(tabName);
  }

  roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }

  updatePlanLevelAdjustments(formStatus: any) {
    this.hasAdjustmentErrors = this.whAdjustmentsDetails = formStatus;
    let inclusivePlanTypes = ['F', 'P'];
    let componentTotalTierRates = {};
    if (this.RateData.uwAdjustment && this.RateData.medical && this.RateData.medical.proposedPlans) {
      if (this.RateData.opportunityType == CommonConstants.RENEWAL_LOCAL) {
        componentTotalTierRates = this.RateData.uwAdjustment['componentTierTotalRates'];
      }
      this.RateData.medical.proposedPlans.forEach((plan) => {
        if (inclusivePlanTypes.includes(plan.planTypeRequested) && plan.status && plan.status != 'Failed') {
          if (this.opportunityData.fundingType.toLowerCase() === 'fi' && this.RateData.opportunityType == CommonConstants.NEW_BUSINESS_LOCAL) {
            this.uwService.getPlanLevelAdjustments(plan, this.RateData);
          } else if (StringUtils.isEqual(this.RateData.opportunityType, CommonConstants.RENEWAL_LOCAL) &&
            StringUtils.isEqual(this.opportunityData?.fundingType, CommonConstants.ABF)
          ) {
            if(this.uwService.showComponentAdjustmentsForAlternates(this.RateData) && !this.LGFItoSGAbfCrossSelling) {
              this.uwService.getAbfExperienceAdjusments(plan, this.RateData, componentTotalTierRates);
            } else {
              this.uwService.getAbfAltExperienceAdjusments(plan, this.RateData, componentTotalTierRates);
            }
          } else if (this.RateData.opportunityType == CommonConstants.RENEWAL_LOCAL && this.opportunityData.fundingType == CommonConstants.FI) {
            if (!StringUtils.isUndefined(plan.currPlanId)) {
              let currPlanId;
              plan.currPlanId.forEach((planCurrId) => {
                currPlanId = planCurrId.toString();
              });
              let currentPlan = this.RateData.medical.currentPlans.filter((planID) => planID.id === currPlanId);
              this.uwService.getFiAdjusments(plan, this.RateData, currentPlan);
            } else {
              this.uwService.getFiAdjusments(plan, this.RateData);
            }
          } else if (this.opportunityData.fundingType == CommonConstants.ASO) {
            this.uwService.getMEWAAdjusments(plan, this.RateData);
          } else {
            this.uwService.getAbfAdjustments(plan, this.RateData);
          }
        }
      });
      this.adjustmentChange = { recalculate: true };
    }
  }

  ngOnDestroy() {
    this.eventSources.forEach((source) => source.close());
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  navigateToSoldRates() {
    this.router.navigate([CommonConstants.SOLD_RATES_URL], {
      queryParams: {
        ratingTransID: this.opportunityData.ratingTransID,
        opportunityID: this.opportunityData.opportunityID,
        quoteHeaderID: this.opportunityData.quoteHeaderID,
        lob: this.opportunityData.lob,
        groupName: this.accountName,
        fundingType: this.opportunityData.fundingType,
        availableTabs: this.lob_FT,
        state: this.RateData.state,
        factorEffectiveDate: this.RateData.factorEffectiveDate,
        quoteOrigin: this.opportunityData.quoteOrigin
      }
    });
  }

  onNavigateTab(data: string) {
    let quoteTabList = this.commonService.getQuoteTabList();
    let currentTabData = this.currentTab.split('-');
    if((StringUtils.isEqual(currentTabData[1], CommonConstants.ABF) && StringUtils.isEqual(currentTabData[0], CommonConstants.Medical)) ||
    (StringUtils.isEqual(currentTabData[1], CommonConstants.FI) && StringUtils.isEqual(currentTabData[0], CommonConstants.Medical))) {
    let filtered = Object.values(
      (Array.isArray(quoteTabList) ? quoteTabList : []).reduce((acc, item) => {
        if (!acc[item.tabName] || item.tabStatus ===  this.RateData.status && item.quoteOrigin === this.RateData.quoteOrigin) {
          acc[item.tabName] = item;
        }
        return acc;
      }, {})
    );
    quoteTabList = filtered;
    }
    this.commonService.setQuoteTabList(quoteTabList);
    this.currentTab = data;
    let tabData = data.split('-');
    let urlParams = {
      ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
      opportunityID: this.opportunityData.opportunityID,
      quoteHeaderID: this.opportunityData.quoteHeaderID,
      quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
      searchAnywhere: this.searchAnywhere,
      lob: tabData[0],
      groupName: this.accountName,
      fundingType: tabData[1],
      availableTabs: this.lob_FT,
      currentTab: this.currentTab
    };
    const quoteUrl = CommonConstants.quoteRoutingUrls[tabData[0]];
    if (StringUtils.isEqual(tabData[0], CommonConstants.Medical)) {
      urlParams[CommonConstants.QUOTINGTYPE_FROM_TAB] = tabData[1];
      urlParams.fundingType = this.commonService.getFundingTypeforTab(tabData[0], tabData[1]);
      this.div_visible = true;
      delete urlParams.groupName;
      this.router.navigate([quoteUrl], { queryParams: urlParams });
    }
    if (StringUtils.isEqual(tabData[0], CommonConstants.Vision) && StringUtils.isEqual(this.commonService.isVisionEnabled, 'true')) {
      this.router.navigate([quoteUrl], { queryParams: urlParams });
    }
    if (StringUtils.isEqual(tabData[0], CommonConstants.Dental) || StringUtils.isEqual(tabData[0], CommonConstants.SuppHealth)) {
      this.router.navigate([quoteUrl], { queryParams: urlParams });
    }
  }

  backClicked() {
    this.uwService.clearRateList();
    if (!this.storage.get('QuoteSearchQuery')) {
      let searchQuery = {};
      searchQuery['quoteReason'] = this.quoteReason !== 'TEST' ? { $nin: ['TEST'] } : { $in: ['TEST'] };
      searchQuery['alternateQuote'] = this.alternateQuote === true ? { $in: [true, false] } : { $in: [false] };
      searchQuery['quoteOrigin'] = { $in: ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch'] };
      searchQuery['opportunityID'] = { $regex: '.*' + this.opportunityData.opportunityID + '.*' };
      this.storage.set('QuoteSearchQuery', JSON.stringify(searchQuery));
      this.storage.set('alternateQuote', searchQuery['alternateQuote']);
      this.storage.set('showOpportunities', 'true');
      this.storage.set('opportunityID', this.opportunityData.opportunityID);
      this.storage.set('searchAnywhere', this.searchAnywhere);
      this.storage.set('quoteReason', this.quoteReason !== 'TEST' ? false : true);
      this.storage.set('pageLimit', 10);
    }
    this.storage.set('searchAnywhere', this.searchAnywhere);
    this.router.navigate(['/quote']);
  }

  removeFailureMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  removeSuccessMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  removeWarningMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  componentKeys: string[] = ['asoAdmin', 'sslPremium', 'aslPremium', 'terminalLiability', 'maxClaims'];

  getTypeForAbfComponent(key) {
    return {
      asoAdmin: 'ASO Admin',
      sslPremium: 'SSL Premium',
      aslPremium: 'ASL Premium',
      terminalLiability: 'Terminal Liability',
      maxClaims: 'Max Claims'
    }[key];
  }

  convertProperFormat(Adjustments, type, percentageComponent?) {
    let adjArray = [];
    let adjObj = {};
    if (type === 'C') {
      this.componentKeys.forEach((adjKey) => {
        if (Adjustments[adjKey]) {
          let retValue = {
            adjustmentType: this.getTypeForAbfComponent(adjKey),
            adjustmentFactorType: Adjustments[adjKey + 'Type'],
            adjustmentFactor: Adjustments[adjKey]
          };
          adjArray.push(retValue);
        }
      });
    } else if (type === 'R' && Object.keys(Adjustments).length && this.hasRblAdj(Adjustments, 'C')) {
      adjObj['rebalanceAdjustmentType'] = 'COMPONENT';
      adjObj['fromComponent'] = {};
      adjObj['toComponent'] = {};
      Object.keys(Adjustments).forEach((key) => {
        if (key.includes('Adj') && Adjustments[key]) {
          adjObj['fromComponent'][key.replace('Adj', '')] = Adjustments[key];
        } else if (key.includes('Allocation') && +Adjustments[key]) {
          adjObj['toComponent'][key.replace('Allocation', '')] = Adjustments[key];
        }
      });
    } else if (type === 'R' && Object.keys(percentageComponent).length && this.hasRblAdj(percentageComponent, 'P')) {
      adjObj['rebalanceAdjustmentType'] = 'PERCENTAGE';
      adjObj['percentageComponent'] = { ...percentageComponent };
    } else if (type === 'RTA') {
      adjObj['adjustedRateActionPercent'] = Number.parseFloat(Adjustments['adjustedRateActionPercent']);
      if (Adjustments['renewalWHAPercent']) {
        adjObj['renewalWHAPercent'] = Number.parseFloat(Adjustments['renewalWHAPercent']);
      }
      if (StringUtils.isEqual(this.opportunityData.fundingType, 'FI')) {
        adjObj['isFlatRateApplied'] = Adjustments['isFlatRateApplied'];
        if(Adjustments['formulaTieredRateActionPercent']!=null){
        adjObj['formulaTieredRateActionPercent']=Adjustments['formulaTieredRateActionPercent'];
        }
        if(Adjustments['uwTieredRateActionPercent']!=null){
        adjObj['uwTieredRateActionPercent']=Adjustments['uwTieredRateActionPercent'];
        }
      }
      if (this.opportunityData.fundingType == 'ABF') {
        adjObj['componentRateAction'] = {};
        adjObj['componentRateAction']['asoAdminFee'] = Number.parseFloat(this.getRateActionAdjValues(Adjustments, 'asoAdminFee'));
        adjObj['componentRateAction']['sslPremium'] = Number.parseFloat(this.getRateActionAdjValues(Adjustments, 'sslPremium'));
        adjObj['componentRateAction']['aslPremium'] = Number.parseFloat(this.getRateActionAdjValues(Adjustments, 'aslPremium'));
        adjObj['componentRateAction']['maxPaidClaim'] = Number.parseFloat(this.getRateActionAdjValues(Adjustments, 'maxPaidClaim'));
        adjObj['componentRateAction']['terminalLiability'] = Number.parseFloat(this.getRateActionAdjValues(Adjustments, 'terminalLiability'));
      }
    }
    return type === 'C' ? adjArray : adjObj;
  }

  private getRateActionAdjValues(Adjustments, field) {
    return Adjustments[field] ? Adjustments[field] : Adjustments.componentRateAction ? Adjustments.componentRateAction[field] : 0;
  }

  hasRblAdj(Adjustments, type) {
    let flag = false;
    if (Adjustments && Object.keys(Adjustments).length) {
      Object.keys(Adjustments).forEach((key) => {
        if (type === 'C' && key.includes('Adj') && Adjustments[key]) flag = true;
        if (type === 'P' && Adjustments[key]) flag = true;
      });
    }
    return flag;
  }

  hasRblValues(Adjustments) {
    let flag = false;
    if (Adjustments && Object.keys(Adjustments).length) {
      Object.keys(Adjustments).forEach((key) => {
        if (Adjustments[key]) flag = true;
      });
    }
    return flag;
  }

  onDecline(declineReasons) {
    this.declineReasons = declineReasons;
  }
  onRelease(releaseType) {
    this.releaseType = releaseType;
  }
  declineReaonsToBeChecked(declineReasons) {
    this.declineCheckboxes = declineReasons;
  }

  hasCompleteRblValues(Adjustments) {
    let flag = false;
    if (Adjustments && Object.keys(Adjustments).length) {
      Object.keys(Adjustments).forEach((key) => {
        if (!Adjustments[key] || Adjustments[key] == 0) flag = true;
      });
    }
    return flag;
  }

  onApplyAdjustments(action: string) {

    let hasSomeFormErrors = false;
    let errorMessage = 'Please fix below listed issues to proceed: \n\n';
    let errorCount: number = 1;
    if (Object.keys(this.hasAdjustmentErrors).length > 0) {
      if (this.RateData && this.RateData.opportunityType && this.opportunityData && this.opportunityData.fundingType) {
        if (this.RateData.opportunityType == CommonConstants.RENEWAL_LOCAL) {
          if (!this.hasAdjustmentErrors.customTierRatio && this.RateData.quotingType != CommonConstants.MEWA) {
            errorMessage += errorCount++ + '. Please fix the issue with the custom tier ratio\n';
            hasSomeFormErrors = true;
          }
          if (this.opportunityData.fundingType == CommonConstants.ABF && this.RateData.quotingType != CommonConstants.ACA) {
            if (!this.hasAdjustmentErrors.abfRateActionAdjustment) {
              errorMessage += errorCount++ + '. Please fix the issue in the Rate Action Adjustments Section\n';
              hasSomeFormErrors = true;
            }
          }
          if (this.opportunityData.fundingType == CommonConstants.FI && this.RateData.quotingType != CommonConstants.ACA) {
            if (!this.hasAdjustmentErrors.fiRateActionAdjustment) {
              errorMessage += errorCount++ + '. Please fix the issue in the Rate Action Adjustments Section\n';
              hasSomeFormErrors = true;
            }
          }
          if (this.opportunityData.fundingType == CommonConstants.ASO && this.RateData.quotingType == CommonConstants.MEWA) {
            if (!this.hasAdjustmentErrors.quoteAdjustments) {
              errorMessage += errorCount++ + '. Please fix the issue in the Quote Adjustments Section\n';
              hasSomeFormErrors = true;
            }
          }
        } else if (this.RateData.opportunityType == CommonConstants.NEW_BUSINESS_LOCAL) {
          if (!this.hasAdjustmentErrors.quoteAdjustments) {
            errorMessage += errorCount++ + '. Please enter Valid Factor in Adjustment Section\n';
            hasSomeFormErrors = true;
          }
          if (this.opportunityData.fundingType == CommonConstants.FI && !this.hasAdjustmentErrors.productAdjustments) {
            errorMessage += errorCount++ + '. Please enter Valid Factor in Product Adjustment Section\n';
            hasSomeFormErrors = true;
          }
          if (!this.hasAdjustmentErrors.customTierRatio && this.RateData.quotingType != CommonConstants.MEWA) {
            errorMessage += errorCount++ + '. Please fix the issue with the custom tier ratio\n';
            hasSomeFormErrors = true;
          }
          if (this.opportunityData.fundingType == CommonConstants.ABF) {
            if (!this.hasAdjustmentErrors.componentAdjustments) {
              errorMessage += errorCount++ + '. Please fix the issue with the Component Adjustments Section\n';
              hasSomeFormErrors = true;
            }
            if (!this.hasAdjustmentErrors.rebalanceAdjustments) {
              errorMessage += errorCount++ + '. Please fix the issue with the Rebalance Adjustments By Component Section\n';
              hasSomeFormErrors = true;
            }
            if (!this.hasAdjustmentErrors.percentageComponent) {
              errorMessage += errorCount++ + '. Please fix the issue with the Rebalance Adjustments By % of PMPM Section\n';
              hasSomeFormErrors = true;
            }
          }
        }
      }
    }
    this.displayStatusError = false;
    if (this.userSelectionChanges) {
      const statusReasonsFromMap = this.userSelectionChanges?.statusReasonMap
        ? this.userSelectionChanges?.statusReasonMap[this.userSelectionChanges?.status]
        : undefined;
      if (
        statusReasonsFromMap?.length > 0 &&
        (StringUtils.isUndefined(this.userSelectionChanges.selectedStatusReasons) || this.userSelectionChanges.selectedStatusReasons.length < 1) &&
        !StringUtils.isEqual(this.userSelectionChanges?.status, CommonConstants.releasedStatus)
      ) {
        this.displayStatusError = true;
      }
    }
    if (
      this.userSelectionChanges &&
      (StringUtils.isUndefined(this.userSelectionChanges.selectedStatusReasons) || this.userSelectionChanges.selectedStatusReasons.length < 1) &&
      this.displayStatusError
    ) {
      errorMessage += `${errorCount++}. Please select status reason\n`;
      hasSomeFormErrors = true;
    }

    if (this.inValidRates) {
      errorMessage += errorCount++ + '. Please enter Valid Enrollment / Rates in Premium Comparison\n';
      hasSomeFormErrors = true;
    } else {
      this.uwService.clearRateList();
    }

    if (this.hasPEOverrideError) {
      errorMessage += errorCount++ + '. Please enter Madatory fields in Exhibit Overrides section\n';
      hasSomeFormErrors = true;
    }

    if (
      this.RateData &&
      this.RateData.medical &&
      this.RateData.medical.proposedPlans &&
      !this.RateData.medical.proposedPlans.find((plan) => plan.planTypeRequested == 'F') &&
      !this.RateData.medical.proposedPlans.find((plan) => plan.planTypeRequested == 'P' && !plan.markedForDelete && plan.includeInPrintExhibit)
    ) {
      errorMessage += '. Please include atleast one portfolio plan in print exhibit';
      hasSomeFormErrors = true;
    }
    let initialTier = (this.InitialRateData.uwAdjustment && this.InitialRateData.uwAdjustment.outputTier) || this.InitialRateData.medicalOutputTier;

    let isPremiumComparisonChanged = false;
    window.scroll(0, 0);
    let adjustmentData: any = {};

    if (this.RateData.uwAdjustment) {

      let {
        quoteAdjustments,
        productAdjustments,
        componentAdjustments,
        rebalanceAdjustments,
        abfRateActionAdjustment,
        percentageComponent,
        customTierRatio,
        tierRatioCalculationType,
        outputTier,
        uwNotesToSales,
        statusReasons,
        uwComments,
        exhibitName
      } = this.RateData.uwAdjustment;
      if (action == 'decline') {
        if (
          typeof this.processQuoteService.uwNotesToSales != 'undefined' &&
          this.processQuoteService.uwNotesToSales != null &&
          this.processQuoteService.uwNotesToSales != ''
        ) {
          if (this.processQuoteService.uwNotesToSales.includes('; ')) {
            this.processQuoteService.uwNotesToSales = this.processQuoteService.uwNotesToSales.split('; ').join(';');
          }
          this.processQuoteService.uwNotesToSales = this.processQuoteService.uwNotesToSales.split(';').join('; ');
          uwNotesToSales = this.processQuoteService.getUwNotesToSales();

          var checkobexsFound = this.processQuoteService.declineOptionsChecked.some((cbs) => this.processQuoteService.uwNotesToSales.includes(cbs));

          if (this.processQuoteService.declineOptionsChecked.length === 5 && !checkobexsFound) {
            let finalUWNote;
            if (this.processQuoteService.declineOptionsChecked != null && this.processQuoteService.declineOptionsChecked.length > 0) {
              this.processQuoteService.declineOptionsChecked.forEach((element) => {
                if (finalUWNote == null) {
                  finalUWNote =
                    this.processQuoteService.uwNotesToSales != '' && !this.processQuoteService.uwNotesToSales.includes(element)
                      ? this.processQuoteService.uwNotesToSales + ';' + element
                      : element;
                } else if (!finalUWNote.includes(element)) {
                  finalUWNote = finalUWNote + ';' + element;
                }
              });
            } else {
              finalUWNote = this.processQuoteService.uwNotesToSales;
            }
            if (typeof finalUWNote != 'undefined' && finalUWNote.includes('; ')) {
              finalUWNote = finalUWNote.split('; ').join(';');
            }
            finalUWNote = finalUWNote.split(';').join('; ');
            uwNotesToSales = finalUWNote;
          }
        } else {
          let noCheckboxesChecked: boolean = true;
          if (this.processQuoteService.declineOptionsChecked != null && this.processQuoteService.declineOptionsChecked.length > 0) {
            noCheckboxesChecked = false;
          }
          if (action == 'decline' && !noCheckboxesChecked) {
            let declineChecboxes: any;
            if (uwNotesToSales != null) {
              declineChecboxes = uwNotesToSales;
            }
            if (this.declineCheckboxes != null) {
              if (this.declineCheckboxes.length == 0) {
                this.declineCheckboxes = this.processQuoteService.declineOptionsChecked;
              }
              this.declineCheckboxes.forEach((element) => {
                if (declineChecboxes == null) {
                  declineChecboxes = element;
                } else {
                  if (!declineChecboxes.includes(element)) {
                    declineChecboxes = declineChecboxes != '' && !element.includes(declineChecboxes) ? declineChecboxes + ';' + element : element;
                  }
                }
              });
              if (typeof declineChecboxes != 'undefined' && declineChecboxes != null && declineChecboxes.includes('; ')) {
                declineChecboxes = declineChecboxes.split('; ').join(';');
              }
              declineChecboxes = declineChecboxes.split(';').join('; ');
              uwNotesToSales = declineChecboxes;
            }
          }
        }
        let statusReason: any;
        let statusReasonsList: any[] = [];
        this.processQuoteService.declineOptionsValues.subscribe((checkboxesSelected) => {
          if (checkboxesSelected != null && checkboxesSelected.length > 0) {
            statusReasonsList = checkboxesSelected;
            checkboxesSelected.forEach((element) => {
              if (statusReason == null) {
                statusReason = element;
              } else {
                if (!statusReason.includes(element)) {
                  statusReason = statusReason != '' && !element.includes(statusReason) ? statusReason + ';' + element : element;
                }
              }
            });
          }
          this.statusReasons = statusReason;
        });
        localStorage.setItem(
          'statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType,
          statusReason
        );
        statusReasons = statusReasonsList;
      } else {
        let statusReasonsToList: any[] = [];
        if (action == 'save' || action == 'release') {
          if (typeof uwNotesToSales != 'undefined' && uwNotesToSales != null && uwNotesToSales.includes(';')) {
            uwNotesToSales = CommonUtil.htmlEntitiesToString(uwNotesToSales);
            if (typeof uwNotesToSales != 'undefined' && uwNotesToSales.includes('; ')) {
              uwNotesToSales = uwNotesToSales.split('; ').join(';');
            }
            uwNotesToSales = uwNotesToSales.split(';').join('; ');
            uwNotesToSales = CommonUtil.convertSpecialCharToASCII(uwNotesToSales);
          }
          this.isInitialQuoteUpdate = false;
          if (StringUtils.isEqual(action, CommonConstants.releaseAction) && this.releaseType?.length > 0) {
            if (this.releaseType.length > 0 && this.releaseType.includes(CommonConstants.INITIAL_RELEASE)) {
              this.isInitialQuoteUpdate = true;
            } else {
              this.isInitialQuoteUpdate = false;
            }
            const index = this.releaseType.indexOf(CommonConstants.INITIAL_RELEASE);
            if (index != -1) {
              this.releaseType.splice(index, 1);
            }
            if (!StringUtils.isEmpty(uwNotesToSales)) {
              if (!StringUtils.isUndefined(this.releaseType) && this.releaseType.length > 0 && StringUtils.isEqual(action, CommonConstants.releaseAction)) {
                this.releaseType.forEach((options) => {
                  if (!uwNotesToSales.includes(options)) {
                    uwNotesToSales = uwNotesToSales != '' && !options.includes(uwNotesToSales) ? uwNotesToSales + ';' + options : options;
                  }
                });
              }
            }
            let uWNotesSplitTrim: any[] = [];
            let userTypedReleaseReasonsSplit: any[] = [];
            userTypedReleaseReasonsSplit = uwNotesToSales.split(';');
            if (userTypedReleaseReasonsSplit.length > 0) {
              userTypedReleaseReasonsSplit.forEach((element) => {
                uWNotesSplitTrim.push(element.trim());
              });
            }
            let releaseOptions = [];
            if (this.statusReasonsObj?.Released?.length > 0) {
              releaseOptions = this.statusReasonsObj.Released.filter((value) => value != CommonConstants.INITIAL_RELEASE);
            }
            let actualReleaseReason = [];
            actualReleaseReason = uWNotesSplitTrim.filter((notes) => {
              return releaseOptions.indexOf(notes) == -1;
            });
            let predefinedReason = '';
            if (actualReleaseReason.length > 0) {
              actualReleaseReason.forEach((elementsArr) => {
                if (predefinedReason == '') {
                  predefinedReason = elementsArr;
                } else {
                  predefinedReason = predefinedReason + ';' + elementsArr;
                }
              });
            }
            if (!StringUtils.isUndefined(this.releaseType) && this.releaseType.length > 0 && StringUtils.isEqual(action, CommonConstants.releaseAction)) {
              if (!StringUtils.isEmpty(predefinedReason) && predefinedReason?.split(';').length > 0) {
                if (!predefinedReason.includes(this.releaseType.join('; '))) predefinedReason = predefinedReason + '; ' + this.releaseType.join('; ');
              } else {
                predefinedReason = this.releaseType.join('; ');
              }
            }
            uwNotesToSales = predefinedReason;
          }
          if (
            typeof localStorage.getItem(
              'statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType
            ) != 'undefined' &&
            localStorage.getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType) !=
              null &&
            localStorage
              .getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType)
              .includes(';')
          ) {
            statusReasons = localStorage
              .getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType)
              .split(';');
          } else {
            if (
              typeof localStorage.getItem(
                'statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType
              ) != 'undefined' &&
              localStorage.getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType) !=
                null
            ) {
              statusReasonsToList.push(
                localStorage.getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType)
              );
              statusReasons = statusReasonsToList;
            }
          }
        }
      }
      if (quoteAdjustments && Object.values(quoteAdjustments).every((val) => val == '')) {
        quoteAdjustments = undefined;
      }

      if (rebalanceAdjustments && rebalanceAdjustments.percentageComponent) {
        delete rebalanceAdjustments.percentageComponent;
        delete rebalanceAdjustments.rebalanceAdjustmentType;
      }

      if (componentAdjustments) {
        componentAdjustments = this.convertProperFormat(componentAdjustments, 'C');
      }

      if (rebalanceAdjustments || percentageComponent) {
        rebalanceAdjustments = this.convertProperFormat(rebalanceAdjustments, 'R', percentageComponent);
      }

      if (abfRateActionAdjustment) {
        abfRateActionAdjustment = this.convertProperFormat(abfRateActionAdjustment, 'RTA');
      }

      if (this.hasRblValues(rebalanceAdjustments ? rebalanceAdjustments.fromComponent : rebalanceAdjustments) && this.hasRblValues(percentageComponent)) {
        errorMessage += errorCount++ + '. Please enter rebalance adjustments either By Component / By % of PMPM\n';
        hasSomeFormErrors = true;
      }
      if (
        !this.hasRblValues(rebalanceAdjustments ? rebalanceAdjustments.fromComponent : rebalanceAdjustments) &&
        this.hasRblValues(percentageComponent) &&
        this.hasCompleteRblValues(percentageComponent)
      ) {
        errorMessage += errorCount++ + '. Please split Allocation across all the components in rebalance adjustments By % of PMPM\n';
        hasSomeFormErrors = true;
      }
      adjustmentData = JSON.parse(
        JSON.stringify({
          quoteAdjustments,
          productAdjustments,
          componentAdjustments,
          rebalanceAdjustments,
          abfRateActionAdjustment,
          customTierRatio,
          tierRatioCalculationType,
          outputTier,
          uwNotesToSales,
          statusReasons,
          uwComments,
          exhibitName,
          ...this.userSelectionChanges
        })
      );

      delete adjustmentData.quoteReason;

      if (
        (adjustmentData &&
          adjustmentData.rebalanceAdjustments &&
          adjustmentData.rebalanceAdjustments.fromComponent &&
          !Object.keys(adjustmentData.rebalanceAdjustments.fromComponent).length) ||
        (adjustmentData.rebalanceAdjustments &&
          adjustmentData.rebalanceAdjustments.percentageComponent &&
          !Object.keys(adjustmentData.rebalanceAdjustments.percentageComponent).length)
      ) {
        delete adjustmentData.rebalanceAdjustments;
      }
    }
    if (StringUtils.isEqual(action, CommonConstants.releaseAction)) {
      if (this.releaseType?.length > 0) {
        adjustmentData['statusReasons'] = JSON.parse(JSON.stringify(this.releaseType));
      } else {
        adjustmentData['statusReasons'] = undefined;
      }
    }
    if (this.userSelectionChanges && StringUtils.isEqual(action, CommonConstants.save)) {
      adjustmentData['statusReasons'] = this.userSelectionChanges?.selectedStatusReasons;
    }
    if (adjustmentData['statusReasons'] && adjustmentData['statusReasons'].length > 0) {
      const index = adjustmentData['statusReasons'].indexOf(CommonConstants.INITIAL_RELEASE);
      if (index != -1) adjustmentData['statusReasons'].splice(index, 1);
    }
    if (adjustmentData && adjustmentData.statusReasonMap) delete adjustmentData.statusReasonMap;

    if (adjustmentData && adjustmentData.selectedStatusReasons) delete adjustmentData.selectedStatusReasons;
    if (adjustmentData && adjustmentData.rebalanceAdjustments && !Object.keys(adjustmentData.rebalanceAdjustments).length)
      delete adjustmentData.rebalanceAdjustments;

    if (
      (action === 'decline' && !adjustmentData.uwNotesToSales.trim()) ||
      (action === 'release' &&
        !adjustmentData.uwNotesToSales.trim() &&
        (adjustmentData.quoteAdjustments ||
          adjustmentData.productAdjustments ||
          adjustmentData.componentAdjustments ||
          adjustmentData.rebalanceAdjustments ||
          adjustmentData.abfRateActionAdjustment))
    ) {
      errorMessage += errorCount++ + '. Please enter UW notes to sales\n';
      hasSomeFormErrors = true;
    }

    if (hasSomeFormErrors) {
      this.alertData = errorMessage;
      this.setWarningFlag();
      return;
    } else {
      this.alertData = '';
      this.warningMessage = false;
    }

    if (adjustmentData.tierRatioCalculationType != 'Custom') {
      delete adjustmentData.customTierRatio;
    }
    if (!adjustmentData.uwNotesToSales) {
      delete adjustmentData.uwNotesToSales;
    }
    if (!adjustmentData.uwComments) {
      delete adjustmentData.uwComments;
    }
    if (!adjustmentData.exhibitName) {
      delete adjustmentData.exhibitName;
    }
    let whSavingFormDetailsArray = [];
    if ((adjustmentData.abfRateActionAdjustment && this.whAdjustmentsDetails) || (adjustmentData.quoteAdjustments && this.whAdjustmentsDetails)) {
      this.whAdjustmentsDetails?.whAdjustmentsDetails?.SpecialityTypes?.forEach((specialityType) => {
        if (StringUtils.isEqual(specialityType.label, CommonConstants.OTHER)) {
          whSavingFormDetailsArray.push({
            value: specialityType.defaultValue,
            id: this.whAdjustmentsDetails.whAdjustmentsDetails.otherUnitType
          });
        } else {
          whSavingFormDetailsArray.push({
            value: specialityType.defaultValue,
            id: specialityType.value
          });
        }
      });
      if (StringUtils.isEqual(this.RateData.opportunityType, CommonConstants.NEW_BUSINESS_LOCAL) || this.RateData.quotingType == CommonConstants.MEWA)
        adjustmentData.quoteAdjustments[CommonConstants.DISCOUNT_SPLITS] = whSavingFormDetailsArray;
      else adjustmentData.abfRateActionAdjustment[CommonConstants.DISCOUNT_SPLITS] = whSavingFormDetailsArray;
    }
    let adjustmentChangeset = null;

    if (Object.keys(adjustmentData).length > 0) {

      adjustmentChangeset = this.uwChangeSetService.getAdjustmentChangeSetDetails(
        adjustmentData,
        this.InitialRateData,
        this.uwService.PRODUCT_SEPARATOR,
        this.opportunityData.fundingType
      );
    }

    this.opportunityData.accountName = this.accountName;
    this.opportunityData.previousOutputTier = initialTier;

    if (['requote', 'grpExpSubmit'].includes(action)) {
      if (this.reQuoteData.factorEffectiveDate) {

        this.opportunityData.factorEffectiveDate = this.datepipe.transform(this.reQuoteData.factorEffectiveDate, 'yyyy-MM-dd');

        if (this.reQuoteData.errFundingFactor !== '' && !isNaN(this.reQuoteData.errFundingFactor))
          this.opportunityData.employerFundingLevel = this.reQuoteData.errFundingFactor / 100;
      } else {
        this.alertData = 'Please enter Factor Effective Date';
        this.setWarningFlag();
        return;
      }
    }

    let mpcChangeDetails = this.uwChangeSetService.getPremiumComparisonChangeSet(this.RateData, this.InitialRateData);
    isPremiumComparisonChanged = this.uwChangeSetService.isPlanComparisonChanged(this.RateData, this.InitialRateData);
    if (isPremiumComparisonChanged) {
      this.RateData.medicalPremiumComparison.planComparison.forEach((x) => {
        x.quoteRatingPlanID = x.tempQuoteRatingPlanID;
      });
      this.InitialRateData.medicalPremiumComparison.planComparison.forEach((x) => {
        x.quoteRatingPlanID = x.tempQuoteRatingPlanID;
      });
      if (!StringUtils.isEmpty(mpcChangeDetails)) adjustmentData['medicalPremiumComparison'] = { ...this.RateData['medicalPremiumComparison'] };
    }

    let aAndCChangeset = this.uwChangeSetService.getAssumptionsChangeSetDetails(
      this.RateData['assumptionsAndConditions'],
      this.InitialRateData['assumptionsAndConditions']
    );
    if (aAndCChangeset) {
      adjustmentData['assumptionsAndConditions'] = this.RateData['assumptionsAndConditions'];
    }

    let perOVerrideData = this.uwChangeSetService.getPEOverrideDataChangeSetDetails(this.RateData, this.InitialRateData, this.exhibitSheets);
    let currentTier = (this.RateData.uwAdjustment && this.RateData.uwAdjustment.outputTier) || this.RateData.medicalOutputTier;
    if (perOVerrideData) {
      adjustmentData.peOverrideData = JSON.parse(JSON.stringify({ ...perOVerrideData.peOverrideValue }));
      if (adjustmentData.peOverrideData.lives) {
        if (adjustmentData.peOverrideData.lives.eeCount === '') delete adjustmentData.peOverrideData.lives.eeCount;

        if (adjustmentData.peOverrideData.lives.efCount === '') delete adjustmentData.peOverrideData.lives.efCount;

        if (adjustmentData.peOverrideData.lives.esCount === '') delete adjustmentData.peOverrideData.lives.esCount;

        if (adjustmentData.peOverrideData.lives.ecCount === '') delete adjustmentData.peOverrideData.lives.ecCount;

        if (adjustmentData.peOverrideData.lives.ekCount === '') delete adjustmentData.peOverrideData.lives.ekCount;

        if (adjustmentData.peOverrideData.lives.e1Count === '') delete adjustmentData.peOverrideData.lives.e1Count;
      }

      if (
        this.InitialRateData.uwAdjustment &&
        this.InitialRateData.uwAdjustment.peOverrideData &&
        this.InitialRateData.uwAdjustment.peOverrideData.lives &&
        initialTier == currentTier &&
        !adjustmentData.peOverrideData.lives
      )
        adjustmentData.peOverrideData.lives = this.InitialRateData.uwAdjustment.peOverrideData.lives;
      if (
        this.InitialRateData.uwAdjustment &&
        this.InitialRateData.uwAdjustment.peOverrideData &&
        this.InitialRateData.uwAdjustment.peOverrideData.contractEffectiveDate &&
        !adjustmentData.peOverrideData.contractEffectiveDate
      ) {
        adjustmentData.peOverrideData['contractEffectiveDate'] = this.InitialRateData.uwAdjustment.peOverrideData.contractEffectiveDate;
        adjustmentData.peOverrideData['contractEffectiveDateIncurred'] = this.InitialRateData.uwAdjustment.peOverrideData.contractEffectiveDateIncurred;
        adjustmentData.peOverrideData['contractEndDate'] = this.InitialRateData.uwAdjustment.peOverrideData.contractEndDate;
        adjustmentData.peOverrideData['quotedCount'] = this.InitialRateData.uwAdjustment.peOverrideData.quotedCount;
        adjustmentData.peOverrideData['eligibleCount'] = this.InitialRateData.uwAdjustment.peOverrideData.eligibleCount;
        adjustmentData.peOverrideData['waiverCount'] = this.InitialRateData.uwAdjustment.peOverrideData.waiverCount;
      }
      if (
        this.InitialRateData?.uwAdjustment &&
        this.InitialRateData?.uwAdjustment?.peOverrideData &&
        this.InitialRateData?.uwAdjustment?.peOverrideData?.includeExcludeInPE &&
        !adjustmentData?.peOverrideData?.includeExcludeInPE
      )
        adjustmentData.peOverrideData.includeExcludeInPE = this.InitialRateData.uwAdjustment.peOverrideData.includeExcludeInPE;
    } else if (initialTier != currentTier && !perOVerrideData && this.InitialRateData.uwAdjustment && this.InitialRateData.uwAdjustment.peOverrideData) {
      adjustmentData.peOverrideData = this.InitialRateData.uwAdjustment.peOverrideData;
      adjustmentData.peOverrideData.lives = null;
    }

    let mpcChangeset = isPremiumComparisonChanged ? mpcChangeDetails : null;
    let customTierRatioChangeset =
      adjustmentData.tierRatioCalculationType == 'Custom'
        ? this.uwChangeSetService.getCustomTierRatioChangeSetDetails(this.RateData, this.InitialRateData)
        : null;
    let removedPlanIdsList = this.uwChangeSetService.getRemovedPlanIdsList(this.RateData);
    this.removedPlanids = [];
    if (removedPlanIdsList.length > 0) {
      removedPlanIdsList.forEach((ele) => this.removedPlanids.push(ele.ratingPlanID));
    }

    let tierSelectionChangeSet = this.uwChangeSetService.getTierRatioSelectionChangeSetDetails(this.RateData, this.InitialRateData);
    this.opportunityData.quotingType = this.RateData.quotingType;
    this.opportunityData.marketSegment = this.RateData.marketSegment;
    this.opportunityData.opportunityType = this.RateData.opportunityType;
    this.opportunityData.quoteOrigin = this.RateData.quoteOrigin;
    if (StringUtils.isUndefined(adjustmentData.medicalPremiumComparison)) {
      if (
        this.RateData['medicalPremiumComparison'] &&
        !StringUtils.isEqual(
          this.RateData['medicalPremiumComparison']['includeInProposal'],
          this.InitialRateData['medicalPremiumComparison']['includeInProposal']
        )
      ) {
        adjustmentData['medicalPremiumComparison'] = {};
        adjustmentData['medicalPremiumComparison'] = this.RateData['medicalPremiumComparison'];
      }
    }
    this.AdjData = {
      opportunity: this.opportunityData,
      uwAdjustment: Object.keys(adjustmentData).length > 0 ? adjustmentData : null,
      quoteReason: this.userSelectionChanges?.quoteReason
    };

   // Include off-cycle data for Declined, Lost, Termed, Transfer statuses OR Sold with user input
      const currentStatus = this.userSelectionChanges?.status || this.RateData.status || '';
      const opportunityType = this.RateData?.opportunityType || '';
      const isNewBusiness = opportunityType === CommonConstants.NEW_BUSINESS_LOCAL;
      
      const requiresOffCycleData = ['Declined', 'Lost', 'Termed', 'Transfer'].includes(currentStatus) || action === 'decline';
      
      // For New Business: do NOT send off-cycle data for Declined, Lost, Termed, Transfer, or decline action
      // For Renewals: send off-cycle data for all terminal statuses
      if ((!isNewBusiness || !requiresOffCycleData) && (requiresOffCycleData || this.offCycleModalService.offCycleSubmittedInCurrentSession)) {
        if (!this.AdjData.uwAdjustment) {
          this.AdjData.uwAdjustment = {};
        }

        if (!this.AdjData.uwAdjustment.offCycle) {
          this.AdjData.uwAdjustment.offCycle = {};
        }

        // Use existing off-cycle data if present (user entered via modal)
        if (this.RateData.offCycle && this.RateData.offCycle.contractEndDate) {
          this.AdjData.uwAdjustment.offCycle.contractEndDate = this.RateData.offCycle.contractEndDate;
          this.AdjData.uwAdjustment.offCycle.lobs = this.RateData.offCycle.lobs || [this.RateData.lob || 'Medical'];

          // Always include status reason in the payload
          this.AdjData.uwAdjustment.offCycle.statusReason = this.RateData.offCycle.statusReason;

          // Set terminationFlag based on status
          if (requiresOffCycleData) {
            // Always true for terminal statuses
            this.AdjData.uwAdjustment.offCycle.terminationFlag = true;
          } else {
            // For Sold status, check if contract has started
            this.AdjData.uwAdjustment.offCycle.terminationFlag = DateUtil.isDateInPast(this.RateData.contractEffectiveDate);
          }
        } else if (requiresOffCycleData) {
          // Auto-calculate for terminal statuses when no user input
          this.AdjData.uwAdjustment.offCycle.contractEndDate = this.calculateDefaultOffCycleEndDate();
          this.AdjData.uwAdjustment.offCycle.lobs = [this.RateData.lob || 'Medical'];
          this.AdjData.uwAdjustment.offCycle.terminationFlag = true;
        }
        
        // Reset flag after offCycle data is added to payload
        this.offCycleModalService.offCycleSubmittedInCurrentSession = false;
      }

    let changeSetDetail = {};
    if (adjustmentChangeset) {
      changeSetDetail['adjustmentData'] = adjustmentChangeset;
    }
    if (removedPlanIdsList && removedPlanIdsList.length) {
      changeSetDetail['removedPlanids'] = removedPlanIdsList;
    }
    if (aAndCChangeset) {
      changeSetDetail['assumptionsAndConditions'] = aAndCChangeset;
    }
    if (mpcChangeset) {
      changeSetDetail['medicalPremiumComparison'] = mpcChangeset;
    }
    if (
      perOVerrideData &&
      perOVerrideData.changesetDetail &&
      perOVerrideData.changesetDetail['newValue'] &&
      !(Object.keys(perOVerrideData.changesetDetail['newValue']).length == 1 && Object.keys(perOVerrideData.changesetDetail['newValue'])[0] == 'ratingPlanID')
    ) {
      changeSetDetail['exhibitOverride'] = { ...perOVerrideData.changesetDetail };
    }
    if (customTierRatioChangeset) {
      changeSetDetail['customTierRatio'] = customTierRatioChangeset;
    }
    if (tierSelectionChangeSet) {
      changeSetDetail['tierRatioCalculationType'] = tierSelectionChangeSet;
    }
    if (
      this.RateData['medicalPremiumComparison'] &&
      this.RateData['medicalPremiumComparison']['includeInProposal'] !== this.InitialRateData['medicalPremiumComparison']['includeInProposal']
    ) {
      changeSetDetail['includeInProposal'] = this.RateData['medicalPremiumComparison']['includeInProposal'];
    }
    if (Object.keys(changeSetDetail).length) {
      this.changeSetDetail = { changeSetDetail };
    } else {
      this.changeSetDetail = null;
    }
    if (this.AdjData.uwAdjustment) {
      this.AdjData.uwAdjustment['medical'] = true;
    }
    if (['requote', 'grpExpSubmit'].includes(action)) {

      this.AdjData['requestedScoreVersion'] = this.reQuoteData.riskScoreVersionOpted;
      if (this.reQuoteData.riskScoreType) {
        this.AdjData['riskScoreType'] = this.reQuoteData.riskScoreType;
      }
      if (this.reQuoteData.stopLossCovg) {
        this.AdjData['stopLossCovg'] = this.reQuoteData.stopLossCovg;
      }
      if (this.reQuoteData.commissionValue && this.reQuoteData.selectedCommissionType) {
        this.AdjData['commissionValue'] = this.reQuoteData.commissionValue;
        this.AdjData['commissionType'] = this.reQuoteData.selectedCommissionType;
      }

      if (action === 'grpExpSubmit') {

        this.AdjData['groupExperience'] = this.groupExperienceData
        action = 'requote'
      }

      this.onSubmitForRequote(action);
    } else {
      this.onSubmitApplyAdjustment(action);
    }
  }

  getSuccessResponse(action: string) {
    switch (action) {
      case 'release':
        return 'Quote Released Successfully';
      case 'decline':
        return 'Quote Declined Successfully';
      case 'requote':
        return 'Submitted for ReQuote Successfully';
      case 'convert':
        return 'Submitted for convert Successfully';
      default:
        return 'Changes are saved successfully';
    }
  }

  getErrorResponse(action: string) {
    switch (action) {
      case 'release':
        return 'Error Releasing the Quote';
      case 'decline':
        return 'Error Declining the Quote';
      case 'convert':
        return 'Error converting the Quote';
      default:
        return 'Error in getting response for Underwriter Adjustment';
    }
  }

  customAssumAndConditionsToAscii(adjData) {
    if (adjData && adjData.length > 0) {
      adjData.forEach((element) => {
        if (element?.asmptnCndtnText) element.asmptnCndtnText = CommonUtil.stringToAscii(element.asmptnCndtnText);
      });
    }
    return adjData;
  }

  onSubmitApplyAdjustment(action: string) {
    if (this.allFeaturedPlanDeleted || this.allPortfolioPlanDeleted || this.allErrerdPlanDeleted) {
      this.activeTab = CommonConstants.featured;
    }
    this.div_visible = true;
    this.isSetRateAdjFormLoaded = false;
    if (this.AdjData[CommonConstants.uwAdjustment]?.assumptionsAndConditions) {
      this.AdjData[CommonConstants.uwAdjustment].assumptionsAndConditions = this.customAssumAndConditionsToAscii(
        this.AdjData[CommonConstants.uwAdjustment].assumptionsAndConditions
      );
    }
    var useRouterLogic = this.commonQuoteService.useRouterLogicToProcess(action);
    if (this.opportunityData.fundingType == CommonConstants.FI && this.opportunityData.opportunityType == CommonConstants.RENEWAL_LOCAL) {
      if (this.RateData?.uwAdjustment?.abfRateActionAdjustment?.isFlatRateApplied)
        this.AdjData[CommonConstants.uwAdjustment]['abfRateActionAdjustment']['isFlatRateApplied'] =
          this.RateData?.uwAdjustment?.abfRateActionAdjustment?.isFlatRateApplied;
    }

    if (
      StringUtils.isEqual(this.RateData.opportunityType, CommonConstants.RENEWAL_LOCAL) &&
      StringUtils.isEqual(this.opportunityData?.fundingType, CommonConstants.ABF) &&
      this.alternateQuote &&
      this.AdjData[CommonConstants.uwAdjustment]['abfRateActionAdjustment']['componentRateAction'] &&
      !this.uwService.showComponentAdjustmentsForAlternates(this.RateData)
    ) {
      delete this.AdjData[CommonConstants.uwAdjustment]['abfRateActionAdjustment']['componentRateAction'];
    }
    this.commonQuoteService
      .submitApplyAdjustment(
        this.AdjData,
        this.metaTransID,
        this.opportunityData.ratingTransID,
        this.removedPlanids.length > 0 ? this.removedPlanids.join(',') : '',
        this.changeSetDetail ? this.changeSetDetail : '',
        action,
        useRouterLogic,
        this.isInitialQuoteUpdate
      )
      .subscribe(
        (response: any) => {
          if (response.status === 200) {
            this.setSuccessFlag();
            this.declineQuoteBool = false;
            setTimeout(() => {
              this.declineQuoteBool = true;
            });
            if (action === 'release') {
              this.processId = response.body.processId;
              if (undefined != this.processId) {
                this.alertData = '';
                this.removeSuccessMsg();
                this.warningMessage = false;
                this.showProgress = true;
                this.progressPercent = 1;
                this.progressStyle = 'progress-bar-warning';
                var source = this.commonService.listenForStream(this.processId);
                this.eventSources.push(source);

                source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener('ISOLATE_UWACTION_STATUS', (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener('SEND_EXHIBIT_TO_UI', (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener('MED_SEND_EXHIBIT_TO_UI', (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener('MERGE_EXHIBITS', (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);
                });

                source.addEventListener('ISOLATE_UWACTION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);
                });

                source.addEventListener('FAILED', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processFailedEvent(message);
                });
              } else {
                // for direct release without PE
                this.processOthersAction(action);
              }
            } else {
              // for scenarios other than release
              this.processOthersAction(action);
            }
          } else {
            this.processErrorResponse(this.getErrorResponse(action));
          }
        },
        (error) => {
          this.processErrorResponse(CommonConstants.system_error);
        }
      );
  }

  processDefaultEvents(event: any) {
    this.progressStyle = '';
    let eventData = JSON.parse(event.data);
    var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
    this.progressPercent = percent;
    this.progressMessage = eventData.message;
  }

  processExhibitDocsEvents(event: any) {
    if (event.data) {
      let data = JSON.parse(event.data);
      if (data.payload && data.payload.exhibits) {
        this.exhibitDocs = this.commonService.deepCopy(data.payload.exhibits);
      }
    }
  }

  processEventComplete(message: any) {
    let eventData = JSON.parse(message.data);
    this.progressStyle = 'progress-bar-success';
    this.progressPercent = 100;
    this.progressMessage = eventData.message;
    let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
    element.click();
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
    this.reloadPage();
  }

  processFailedEvent(message: any) {
    this.progressStyle = 'progress-bar-danger';
    this.progressPercent = 90;
    this.progressMessage = 'Failed to release rates because print exhibit was not available.';
    this.status = 'Pending Review';
    this.hideProgressBar();
    this.removeSuccessMsg();
    this.reloadPage();
  }

  processOthersAction(action: string) {
    this.alertData = this.getSuccessResponse(action);
    this.setSuccessFlag();
    this.reloadPage();
  }

  processErrorResponse(errorResponse: string) {
    this.alertData = errorResponse;
    this.setFailureFlag();
  }

  onSubmitForRequote(action: string) {
    if (this.AdjData[CommonConstants.uwAdjustment]?.assumptionsAndConditions) {
      this.AdjData[CommonConstants.uwAdjustment].assumptionsAndConditions = this.customAssumAndConditionsToAscii(
        this.AdjData[CommonConstants.uwAdjustment].assumptionsAndConditions
      );
    }
    if (
      StringUtils.isEqual(this.RateData.opportunityType, CommonConstants.RENEWAL_LOCAL) &&
      StringUtils.isEqual(this.opportunityData?.fundingType, CommonConstants.ABF) &&
      this.alternateQuote &&
       this.AdjData[CommonConstants.uwAdjustment]?.abfRateActionAdjustment?.componentRateAction &&
      !this.uwService.showComponentAdjustmentsForAlternates(this.RateData)
    ) {
      delete this.AdjData[CommonConstants.uwAdjustment]['abfRateActionAdjustment']['componentRateAction'];
    }
    if (this.RateData.quotingType != CommonConstants.ACA) {
      this.commonQuoteService
        .submitApplyAdjustment(
          this.AdjData,
          this.metaTransID,
          this.opportunityData.ratingTransID,
          this.removedPlanids.length > 0 ? this.removedPlanids.join(',') : '',
          this.changeSetDetail ? this.changeSetDetail : '',
          CommonConstants.save,
          this.commonQuoteService.useRouterLogicToProcess(CommonConstants.save)
        )
        .subscribe(
          (response) => {
            if (response.status === 200) {
              this.alertData = this.getSuccessResponse(CommonConstants.save);
              this.setSuccessFlag();
              this.submitForRequote(action);
            } else {
              this.alertData = this.getErrorResponse(CommonConstants.save);
              this.setFailureFlag();
              this.submitForRequote(action);
            }
          },
          (error) => {
            this.alertData = CommonConstants.system_error;
            this.setFailureFlag();
            this.submitForRequote(action);
          }
        );
    } else {
      this.submitForRequote(action);
    }
  }
  submitForRequote(action: string) {
    this.commonQuoteService.submitRequote(this.AdjData, this.metaTransID, this.opportunityData.ratingTransID, action).subscribe(
      (response) => {
        if (response.status === 200) {
          if (this.RateData.quotingType == CommonConstants.ACA) {
            this.setSuccessFlag();
            this.alertData = this.getSuccessResponse(action);
            setTimeout(() => {
              this.backClicked();
            }, 2000); // 2 seconds delay
          } else {
            this.backClicked();
          }
        } else {
          this.alertData = this.getErrorResponse(action);
          this.setFailureFlag();
        }
      },
      (error) => {
        this.alertData = CommonConstants.system_error;
        this.setFailureFlag();
      }
    );
  }

  viewCalcDetails(selectedPlan: any) {
    this.isOldRiskScoreVersion = this.uwService.isOldRiskScoreVersion(this.RateData['receivedRiskScoreVersion']);
    this.selectedPlan = {
      ...selectedPlan,
      mbu: this.RateData['mbu'],
      participationRate: this.RateData.medical.participationRate,
      contractEffectiveDate: this.RateData['contractEffectiveDate'],
      virginGroup: this.RateData['virginGroup'],
      riskScore: this.RateData['riskScore']
    };
  }

  updatePlanDeleteIndicator(allPlansDeleted: boolean, planType: any) {
    if (planType == 'F') {
      this.allFeaturedPlanDeleted = true;
    } else if (planType == 'P') {
      this.allPortfolioPlanDeleted = true;
    } else {
      this.allErrerdPlanDeleted = true;
    }
  }

  setSuccessFlag() {
    this.successMessage = true;
    this.failureMessage = false;
    this.warningMessage = false;
  }
  setFailureFlag() {
    this.div_visible = false;
    this.failureMessage = true;
    this.successMessage = false;
    this.warningMessage = false;
  }
  setWarningFlag() {
    this.warningMessage = true;
    this.successMessage = false;
    this.failureMessage = false;
  }

  onReQuote(obj) {
    this.reQuoteData = { ...obj };
    this.onApplyAdjustments('requote');
  }

  closeRequoteModal($event) {
    this.showRequoteModal = false;
  }

// Off-Cycle functionality
  @ViewChild(OffCycleModalComponent, { static: false }) offCycleModalComponent!: OffCycleModalComponent;

  private calculateDefaultOffCycleEndDate(): string {
    return DateUtil.calculateOffCycleEndDate(this.RateData.contractEffectiveDate, CommonUtil.isQuoteNeverSold(this.RateData));
  }

  onOffCycleOpen() {
    const modalElements = this.offCycleModalComponent?.getModalElements();
    if (modalElements) {
      this.offCycleModalService.onOffCycleOpen(this.RateData, modalElements);
    }
  }

  onOffCycleReasonChange() {
    this.offCycleModalService.onOffCycleReasonChange();
  }

  setDefaultOffCycleDate() {
    this.offCycleModalService.setDefaultOffCycleDate();
  }

  clickOffCycleDate() {
    this.offCycleModalService.clickOffCycleDate();
  }

  onOffCycleConfirm() {
    const success = this.offCycleModalService.onOffCycleConfirm(this.RateData, 'Medical');
    if (success) {
      this.successMessage = true;
      this.alertData = 'Off-Cycle contract end date has been updated successfully.';
      this.onApplyAdjustments('save');
    }
  }

  initializePlans() {
    let planTabs = ['featured', 'portfolio', 'erred'];
    if (planTabs.includes(this.activeTab) && this.activeTab == CommonConstants.featured) {
      this.activeTab = this.hasFeaturedPlans ? CommonConstants.featured : this.hasPortfolioPlans ? 'portfolio' : 'erred';
    }
  }

  reloadChildComponents() {
    this.RateData = this.commonService.deepCopy(this.RateData);
    this.InitialRateData = this.commonService.deepCopy(this.InitialRateData);
  }
  handleRateInitialResponse(metadata: any, data: any): void {
    console.log('New Quote initial detail loaded');
    this.handleInitialQuoteDetals(metadata, data);
    this.isReadonlyRoleChanges();
    if (data.errors && data.errors.errorList) {
      this.handleQuoteErrors(data.errors.errorList);
    }
    if (this.status == 'Failed') {
      if (data.errors && data.errors.errorList && data.errors.errorList.length == 1 && data.errors.errorList[0].code == 'E1403') {
        this.disableprint = false;
      }
    } else if (this.opportunityData.lob === 'Medical' && this.RateData.quotingType != CommonConstants.MEWA) {
      this.getExperienceSummary(JSON.parse(JSON.stringify(data)));
    }

    if (this.commonService.hasSessionLoginAgain()) {
      this.commonQuoteService.removeHistorySessionStorage();
    }
    this.getABFDefaultValues(
      data.derivedState,
      data.marketSegment,
      this.opportunityData.fundingType,
      data.contractEffectiveDate,
      data.factorEffectiveDate,
      data.opportunityType,
      data.medical.alternateQuote
    );
    this.div_visible = false;
  }

  handleInitialQuoteDetals(metadata: any, data: any) {
    let nonReleasableStatus = ['failed', 'partial success', 'received', 'processing', 'awaiting risk score'];
    let disablePrintStatus = ['failed', 'received', 'processing', 'awaiting risk score'];
    this.mergeRateDataWithAsyncData(JSON.parse(JSON.stringify(data)));
    if (this.RateData && this.RateData.opportunityType == CommonConstants.RENEWAL_LOCAL && this.RateData.quotingType != CommonConstants.ACA) {
      this.planSectionCollpse = true;
    }
    this.RateData[CommonConstants.FUNDING_TYPE] = this.opportunityData.fundingType;
    this.RateData['supportStandardTierRatio'] = data?.supportStandardTierRatio;
    this.InitialRateData[CommonConstants.FUNDING_TYPE] = this.opportunityData.fundingType;
    this.status = data.status;
    this.quoteReason = this.RateData['quoteReason'];
    this.RateData.quoteOrigin = data.quoteOrigin;
    this.opportunityData.quoteOrigin = data.quoteOrigin;
    this.accountName = data.accountName;
    this.metaTransID = metadata.metaTransID;
    this.listenPrintExhibit(data.processID);
    this.disableSoldTab = !(data.soldEnabled == true || data.soldEnabled == 'true');
    let lowerCaseStatus = data.status.toLowerCase();
    this.alternateQuote = data?.medical?.alternateQuote;
    this.disableAutoRunConvert = !(data?.autoRunConvertEligible);
    if (data?.oppOrigin?.['Market Segment']) {
      this.isCrossSelled = true;
    }
    if (
      data?.oppOrigin?.['Fundingtype'] &&
      StringUtils.isEqual(data?.oppOrigin?.Fundingtype, CommonConstants.fundingTypeFiToAbfChanged) &&
      this.RateData.opportunityType == CommonConstants.RENEWAL_LOCAL
    ) {
      this.LGFItoSGAbfCrossSelling = true;
    }
    if (nonReleasableStatus.includes(lowerCaseStatus)) {
      this.disableReleaseTab = true;
      this.disableDeclineTab = true;
    } else {
      this.disableReleaseTab = false;
      this.disableDeclineTab = false;
    }
    this.isPending = this.status == 'Pending Review';
    this.disableprint = disablePrintStatus.includes(lowerCaseStatus);
    if (this.disableprint) {
      if (data.errors && data.errors.errorList && data.errors.errorList.length == 1 && data.errors.errorList[0].code == 'E1403') this.disableprint = false;
    }
    this.declineQuoteBool = false;
    setTimeout(() => {
      this.declineQuoteBool = true;
    });
  }

  mergeRateDataWithAsyncData(data: any) {
    Object.keys(data).forEach((key) => {
      if (this.RateData[key] !== data[key]) {
        this.RateData[key] = this.commonService.deepCopy(data[key]);
      }
      if (this.InitialRateData[key] !== data[key]) {
        this.InitialRateData[key] = this.commonService.deepCopy(data[key]);
      }
    });
    this.reloadChildComponents();
  }

  handleAssumptionsAndConditions(data: any) {
    if (data.assumptionsAndConditions) {
      this.InitialRateData.assumptionsAndConditions = JSON.parse(JSON.stringify(data.assumptionsAndConditions.sort((a, b) => a.dsplyOrder - b.dsplyOrder)));
      this.RateData.assumptionsAndConditions = JSON.parse(JSON.stringify(data.assumptionsAndConditions.sort((a, b) => a.dsplyOrder - b.dsplyOrder)));
    }
    this.reloadChildComponents();
  }

  handleQuoteErrors(errorList: any[]) {
    let errMsgs = [];
    for (let error of errorList) {
      this.quoteErrorCode = error.code;
      if (!errMsgs.includes(error.msg)) {
        errMsgs.push(error.msg);
        if (this.quoteError) {
          this.quoteError = this.quoteError + ' , ' + error.msg;
        } else {
          this.quoteError = error.msg;
        }
      }
    }
  }

  handleUWResponse(data: any) {
    this.uwAdjustmentFetchObject = JSON.parse(JSON.stringify(data));
    this.RateData.uwAdjustment = this.commonService.deepCopy(this.uwAdjustmentFetchObject.uwAdjustment);
    this.InitialRateData.uwAdjustment = this.commonService.deepCopy(this.uwAdjustmentFetchObject.uwAdjustment);

    // Remove currentRiskFactor for MEWA quotes that are NOT Renewal Original from Adjustment History
    if (this.RateData.quotingType === CommonConstants.MEWA && (!StringUtils.isEqual(this.RateData.opportunityType, CommonConstants.RENEWAL_LOCAL) || this.alternateQuote)) {
      if (this.RateData.uwAdjustment?.quoteAdjustments?.currentRiskFactor !== undefined) {
        delete this.RateData.uwAdjustment.quoteAdjustments.currentRiskFactor;
      }
      if (this.InitialRateData.uwAdjustment?.quoteAdjustments?.currentRiskFactor !== undefined) {
        delete this.InitialRateData.uwAdjustment.quoteAdjustments.currentRiskFactor;
      }
    }

    this.factorOrAdjustmentFetched$.next();
    this.tierKey = ((this.RateData.uwAdjustment && this.RateData.uwAdjustment.outputTier) || this.RateData.medicalOutputTier) + '-tier';
    this.reloadChildComponents();
  }

  handleMPCResponse(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    this.RateData.medicalPremiumComparison = this.commonService.deepCopy(dataObj.medicalPremiumComparison);
    this.InitialRateData.medicalPremiumComparison = this.commonService.deepCopy(dataObj.medicalPremiumComparison);
    this.reloadChildComponents();
  }

  handleGRFSKResponse(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    this.RateData.failedGuardRails = this.commonService.deepCopy(dataObj.failedGuardRails);
    this.InitialRateData.failedGuardRails = this.commonService.deepCopy(dataObj.failedGuardRails);
    this.reloadChildComponents();
  }

  handleFactorsAndTierLives(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    if (dataObj.factors) {
      this.RateData.factors = this.commonService.deepCopy(dataObj.factors);
      this.InitialRateData.factors = this.commonService.deepCopy(dataObj.factors);
      this.factorOrAdjustmentFetched$.next();
    }
    if (dataObj.calculatedTierLives) {
      this.RateData.calculatedTierLives = this.commonService.deepCopy(dataObj.calculatedTierLives);
      this.InitialRateData.calculatedTierLives = this.commonService.deepCopy(dataObj.calculatedTierLives);
    }
    if (dataObj.ageSexFactor) {
      this.RateData.ageSexFactor = this.commonService.deepCopy(dataObj.ageSexFactor);
      this.InitialRateData.ageSexFactor = this.commonService.deepCopy(dataObj.ageSexFactor);
    }
    if (dataObj.availableTiers) {
      this.RateData.availableTiers = this.commonService.deepCopy(dataObj.availableTiers);
      this.InitialRateData.availableTiers = this.commonService.deepCopy(dataObj.availableTiers);
    }
    if (dataObj.quoteAcaFactors) {
      this.RateData.quoteAcaFactors = this.commonService.deepCopy(dataObj.quoteAcaFactors);
      this.InitialRateData.quoteAcaFactors = this.commonService.deepCopy(dataObj.quoteAcaFactors);
    }
    if (dataObj?.factors?.lstTblPeSheetSlct) {
      this.buildExhibitSheets(this.commonService.deepCopy(dataObj.factors.lstTblPeSheetSlct));
    }

	this.disableAutoRunConvert = !(dataObj?.autoRunConvertEligible);
    this.reloadChildComponents();
  }

  /**
   * Function to build ExhibitSheets from SSE response
   * @param exhibitSheetsData
   */
  buildExhibitSheets(exhibitSheetsData) {
    this.exhibitSheets = [];
    exhibitSheetsData.forEach((exhibitSheetData) => {
      let exhibitSheet: any = {};
      exhibitSheet.printExhibitTypeCode = exhibitSheetData.sheetCd;
      exhibitSheet.printExhibitSheetName = exhibitSheetData.sheetNm;
      exhibitSheet.sheetStatus = exhibitSheetData.dfltIncl === 'Y' ? 'Include' : 'Exclude';
      this.exhibitSheets.push(exhibitSheet);
    });
  }

  handlePlanData(data: any) {
    let rateData = JSON.parse(JSON.stringify(data));
    if (this.RateData.medical && this.RateData.medical.proposedPlans) {
      let hasRateData = this.RateData.medical.proposedPlans;
      this.RateData.medical.proposedPlans = this.commonService.deepCopy(this.mergeArrays(hasRateData, rateData.medical.proposedPlans));
    } else if (this.RateData.medical) {
      this.RateData.medical.proposedPlans = this.commonService.deepCopy(this.mergeArrays([], rateData.medical.proposedPlans));
      if (rateData.medical.asIsRenewalPlans) {
        this.RateData.medical.asIsRenewalPlans = rateData.medical.asIsRenewalPlans;
      }
    }
    if (this.InitialRateData.medical && this.InitialRateData.medical.proposedPlans) {
      let hasInitialRateData = this.InitialRateData.medical.proposedPlans;
      this.InitialRateData.medical.proposedPlans = this.commonService.deepCopy(this.mergeArrays(hasInitialRateData, rateData.medical.proposedPlans));
    } else if (this.RateData.medical) {
      this.InitialRateData.medical.proposedPlans = this.commonService.deepCopy(this.mergeArrays([], rateData.medical.proposedPlans));
    }
    this.reloadChildComponents();
  }

  mergeArrays(...arrays) {
    let jointArray = [];

    arrays.forEach((array) => {
      jointArray = [...jointArray, ...array];
    });
    return [...new Set([...jointArray])];
  }

  loadFeaturedMedicalPlans() {
    this.featuredPlanCount = 0;
    if (this.RateData['medical'] && this.RateData['medical'].proposedPlans) {
      this.RateData['medical'].proposedPlans.forEach((item) => {
        if (item.planTypeRequested == 'F') {
          this.hasFeaturedPlanFailures = this.hasFeaturedPlanFailures || !!item.failedGuardRails;
          if (!this.RateData['medicalPremiumComparison'] && item.factors && item.factors.calculatedTierLives) {
            item['lives'] = JSON.parse(JSON.stringify(item.factors.calculatedTierLives));
            if (
              this.RateData['uwAdjustment'] &&
              this.RateData['uwAdjustment'].peOverrideData &&
              this.RateData['uwAdjustment'].peOverrideData.planLevelLives &&
              this.RateData['uwAdjustment'].peOverrideData.planLevelLives.find((x) => x.ratingPlanID == item.ratingPlanID)
            ) {
              item['lives'][this.tierKey] = JSON.parse(
                JSON.stringify(this.RateData['uwAdjustment'].peOverrideData.planLevelLives.find((x) => x.ratingPlanID == item.ratingPlanID).lives)
              );
            }
          }
          this.featuredPlanCount++;
          if (!item.asIsRenewalPlan) {
            this.RateData['asIsRenewalPlan'] = item.asIsRenewalPlan;
          }
        }
      });
    }
  }

  loadPortFolioMedicalPlans() {
    this.portfolioPlanCount = 0;
    if (this.RateData['medical'] && this.RateData['medical'].proposedPlans) {
      this.RateData['medical'].proposedPlans.forEach((item) => {
        if (item.planTypeRequested == 'P') {
          this.hasPortfolioPlanFailures = this.hasPortfolioPlanFailures || !!item.failedGuardRails;
          this.portfolioPlanCount++;
        }
      });
    }
  }

  loadErrordMedicalPlans() {
    this.erredPlanCount = 0;
    if (this.RateData['medical'] && this.RateData['medical'].proposedPlans) {
      this.RateData['medical'].proposedPlans.forEach((item) => {
        if ((item.errors && item.errors.metadata) || (!item.status && !item.factors) || (item.status && item.status == 'Failed')) {
          if (!this.erredPlanLoaded) {
            this.erredPlanLoaded = true;
          }
          this.erredPlanCount++;
        }
      });
    }
  }

  initializeMedicalPlans() {
    this.featuredPlanCount = 0;
    this.portfolioPlanCount = 0;
    this.erredPlanCount = 0;
    if (this.RateData['medical'] && this.RateData['medical'].proposedPlans) {
      this.RateData['medical'].proposedPlans.forEach((item) => {
        if ((item.errors && item.errors.metadata) || (!item.status && !item.factors) || (item.status && item.status == 'Failed')) {
          this.erredPlanCount++;
          if (!this.hasErredPlans) {
            this.hasErredPlans = true;
            this.noOfPlans++;
          }
        } else if (item.planTypeRequested == 'F') {
          this.hasFeaturedPlanFailures = this.hasFeaturedPlanFailures || !!item.failedGuardRails;
          if (!this.RateData['medicalPremiumComparison'] && item.factors && item.factors.calculatedTierLives) {
            item['lives'] = JSON.parse(JSON.stringify(item.factors.calculatedTierLives));
            if (
              this.RateData['uwAdjustment'] &&
              this.RateData['uwAdjustment'].peOverrideData &&
              this.RateData['uwAdjustment'].peOverrideData.planLevelLives &&
              this.RateData['uwAdjustment'].peOverrideData.planLevelLives.find((x) => x.ratingPlanID == item.ratingPlanID)
            ) {
              item['lives'][this.tierKey] = JSON.parse(
                JSON.stringify(this.RateData['uwAdjustment'].peOverrideData.planLevelLives.find((x) => x.ratingPlanID == item.ratingPlanID).lives)
              );
            }
          }
          this.featuredPlanCount++;
          if (!this.hasPortfolioPlans) {
            this.hasPortfolioPlans = true;
            this.noOfPlans++;
          }
        } else if (item.planTypeRequested == 'P') {
          this.hasPortfolioPlanFailures = this.hasPortfolioPlanFailures || !!item.failedGuardRails;
          this.portfolioPlanCount++;
          if (!this.hasPortfolioPlans) {
            this.hasPortfolioPlans = true;
            this.noOfPlans++;
          }
        }
      });
    }
    if (this.featuredPlanCount > 0) {
      this.featuredPlanLoaded = true;
      this.noOfPlansLoadComplete++;
      if (this.noOfPlans == this.noOfPlansLoadComplete) {
        this.allPlansLoaded = true;
      }
    }
    if (this.portfolioPlanCount > 0) {
      this.portfolioPlanLoaded = true;
      this.noOfPlansLoadComplete++;
      if (this.noOfPlans == this.noOfPlansLoadComplete) {
        this.allPlansLoaded = true;
      }
    }
    if (this.erredPlanCount > 0) {
      this.erredPlanLoaded = true;
      this.noOfPlansLoadComplete++;
      if (this.noOfPlans == this.noOfPlansLoadComplete) {
        this.allPlansLoaded = true;
      }
    }
  }
  isReadonlyRoleChanges() {
    this.authService.userRoleTextToDisplay.subscribe((data) => {
      if (data.includes('Read Only')) {
        this.isReadOnlyRole = true;
      }
    });
  }
  updateProgressbar(style: string, percent: number, message: string) {
    this.progressPercent = percent;
    this.progressStyle = style;
    this.progressMessage = message;
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  printGenerationStatusUpdate(event: any) {
    let eventData = JSON.parse(event.data);
    var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
    this.updateProgressbar('', percent, eventData.message);
  }

  printGenerationStatusCompletion(message: any) {
    let eventData = JSON.parse(message.data);
    this.updateProgressbar('progress-bar-success', 100, eventData.message);

    let contentData = eventData.payload.contentData;
    let contentName = eventData.payload.contentName;
    if (eventData.payload.contentMetadata) {
      contentName = eventData.payload.contentMetadata[0].value;
    }
    const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
    this.peService.createAndDownloadBlobFile(arrayBuffer, contentName);
    this.disableprint = false;
    this.hideProgressBar();
  }

  printGenerationFailure(message: any) {
    console.error('Received event : ', JSON.stringify(message.data));
    this.updateProgressbar('progress-bar-danger', 90, 'Failed to generate exhibit');
    if (this.quoteErrorCode == 'E1403') this.reloadPage();
    this.removeSuccessMsg();
    this.hideProgressBar();
  }

  onGeneratePrintExhibitSuccess(response: any) {
    if (response.status === 200) {
      this.processId = response.body.processId;
      this.showProgress = true;
      let openPEDropdown = false;
      this.updateProgressbar('progress-bar-warning', 1, '');
      var source = this.commonService.listenForStream(this.processId);
      this.eventSources.push(source);
      source.addEventListener('PE_GENERATION_STATUS', (data) => this.printGenerationStatusUpdate.call(this, data));
      source.addEventListener('SEND_EXHIBIT_TO_UI', (event: any) => {
        if (event.data) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.exhibits) {
            openPEDropdown = true;
            this.exhibitDocs = this.commonService.deepCopy(data.payload.exhibits);
          }
        }
      });
      source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (data) => {
        source.close();
        this.printGenerationStatusCompletion.call(this, data);
        this.commonQuoteService.cleanUpSSEEvents(this.processId);
        if (openPEDropdown) {
          let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
          element.click();
        }
      });
      source.addEventListener('FAILED', (data) => {
        source.close();
        this.printGenerationFailure.call(this, data);
        this.commonQuoteService.cleanUpSSEEvents(this.processId);
      });
    }
  }

  listenPrintExhibit(processId: any) {
    if (processId != null && processId != undefined && processId !== '') {
      var source = this.commonService.listenForStreamTrackAndFail(processId);
      this.eventSources.push(source);
      source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
        this.showProgress = true;
        this.progressStyle = '';
        let eventData = JSON.parse(event.data);
        var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
        this.progressPercent = percent;
        this.progressMessage = eventData.message;
      });
      source.addEventListener('SEND_EXHIBIT_TO_UI', (event: any) => {
        this.showProgress = true;
        if (event.data) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.exhibits) {
            this.exhibitDocs = this.commonService.deepCopy(data.payload.exhibits);
          }
        }
      });
      source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
        this.showProgress = true;
        source.close();
        this.commonQuoteService.cleanUpSSEEvents(processId);
        let eventData = JSON.parse(message.data);
        this.progressStyle = 'progress-bar-success';
        this.progressPercent = 100;
        this.progressMessage = eventData.message;
        let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
        if (typeof element != 'undefined') {
          element.click();
        }
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      });
      source.addEventListener('BATCH_FETCH_EXHIBITS_PROCESS_COMPLETE', (event: any) => {
        source.close();
        this.showProgress = true;
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          if (payload.recentExhibitsFetchStatus && ['Success', 'Partial', 'Failed'].includes(payload.recentExhibitsFetchStatus)) {
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            this.progressMessage = 'Exhibits Link Fetch Process completed successfully.';
          } else {
            console.error('Received Exhibit Status :' + payload.recentExhibitsFetchStatus);
            this.progressPercent = 90;
            this.progressStyle = 'progress-bar-danger';
            this.progressMessage = 'Received Exhibit Status :' + payload.recentExhibitsFetchStatus;
          }
        }
        this.hideProgressBar();
      })
      source.addEventListener('FAILED', (message: any) => {
        this.showProgress = true;
        source.close();
        this.commonQuoteService.cleanUpSSEEvents(processId);
        this.progressStyle = 'progress-bar-danger';
        this.progressPercent = 90;
        this.progressMessage = 'Print exhibit generation or storage to FileNet failed.';
        this.hideProgressBar();
      });
      source.addEventListener('NO_EVENTS', (message: any) => {
        source.close();
      });
    }
  }

  onGeneratePrintExhibitError(error: any) {
    this.disableprint = false;
    alert('Error while generating print exhibit');
  }

  onGeneratePrintExhibit() {
    this.disableprint = true;
    let uwAdjustFormData = { ...this.RateData.uwAdjustment };
    uwAdjustFormData['medical'] = true;
    this.opportunityData.accountName = this.accountName;

    if (uwAdjustFormData.componentAdjustments) {
      uwAdjustFormData.componentAdjustments = this.convertProperFormat(uwAdjustFormData.componentAdjustments, 'C');
    }

    this.AdjData = { opportunity: this.opportunityData, uwAdjustment: uwAdjustFormData };
    this.commonQuoteService.generatePrintExhibit(this.AdjData, this.metaTransID, this.opportunityData.ratingTransID, this.quoteErrorCode).subscribe(
      (response) => {
        this.onGeneratePrintExhibitSuccess.call(this, response);
      },
      (error) => {
        this.onGeneratePrintExhibitError.call(this, error);
      }
    );
  }

  isAutoRun(quoteOrigin: string) {
    return quoteOrigin === RenewalsConstants.AUTO_RUN_BATCH;
  }

  onUserAction(action: string) {
    if (action === 'requote') {
      this.showRequoteModal = true;
    } else if (action === 'print') {
      this.onGeneratePrintExhibit();
    } else if (action === 'convert') {
      this.convertAutoRunToRegularGroup(action);
    } else {
      this.onApplyAdjustments(action);
    }
  }

  convertAutoRunToRegularGroup(action: string) {
    let data = {};
    this.constructAutoRunConvertRequest(data);
    let batchID = this.RateData?.batchID;
    data['batchID'] = batchID ? batchID : '';
    this.renewalsService.autoRunConvertAction(data, batchID).subscribe(
      (response) => {
        if (response && response.body && response.body['msg'] && response.body['msg'].startsWith('Converted Successfully')) {
          this.alertData = this.getSuccessResponse(action);
          this.setSuccessFlag();
          setTimeout(() => {
            this.backClicked();
          }, 3000);
        } else {
          this.alertData = this.getErrorResponse(action);
          this.setFailureFlag();
        }
      },
      (error) => {
        this.alertData = CommonConstants.system_error;
        this.setFailureFlag();
      }
    );
  }

  private constructAutoRunConvertRequest(data: {}) {
    data['rareQuoteKeys'] = [];
    let requestData = {};
    requestData = {
      opportunityID: this.opportunityData.opportunityID ? this.opportunityData.opportunityID : '',
      quoteHeaderID: this.opportunityData.quoteHeaderID ? this.opportunityData.quoteHeaderID : '',
      fundingType: this.opportunityData.fundingType ? this.opportunityData.fundingType : '',
      lob: this.opportunityData.lob ? this.opportunityData.lob : '',
      ratingTransID: this.opportunityData.ratingTransID ? this.opportunityData.ratingTransID : '',
      quoteOrigin: this.opportunityData.quoteOrigin ? this.opportunityData.quoteOrigin : ''
    };
    data['rareQuoteKeys'].push(requestData);
  }

  onPrintError(error) {
    this.alertData = error;
    this.setFailureFlag();
  }

  onUserSelectionChange(data) {
    this.userSelectionChanges = data;
  }

  updatePEOverrideError(isError: boolean) {
    this.hasPEOverrideError = isError;
  }

  getABFDefaultValues(stateCode: string, marketSegment: string, fundingType: string, quoteEffDate: string, factorEffDate: string, opportunityType: string, isAlternate: string) {
    let key = stateCode + marketSegment + fundingType + quoteEffDate + factorEffDate;
    let abfDefaultValues = this.cacheService.getCommissionInfo(key, stateCode, marketSegment, fundingType, quoteEffDate, factorEffDate, opportunityType, isAlternate);

    // Set sslDataLoaded to false to show loader instead of button
    this.sslDataLoaded = false;

    abfDefaultValues.subscribe((response) => {
      this.abfSLDefaultValues = {};
      this.abfSLDefaultValues['SURPLUS_REFUND'] = [];
      this.abfSLDefaultValues['ASL_AGG_ATCH_PT'] = [];
      this.abfSLDefaultValues['SSL_CONTRACT_BASIS'] = [];
      this.abfSLDefaultValues['SSL_DEDUCTIBLE'] = [];
      this.abfSLDefaultValues['ER_FUNDING_LEVEL'] = response && response.EmployerFundingLevel ? response.EmployerFundingLevel[0] : [];
      this.erFundLvlDfltVal = this.abfSLDefaultValues['ER_FUNDING_LEVEL'];
      if (response && Array.isArray(response.StopLossCoverage)) {
        response.StopLossCoverage.forEach((resp) => {
          switch (resp.dataCtgry) {
            case 'SURPLUS_REFUND':
              this.abfSLDefaultValues['SURPLUS_REFUND'].push(resp.dataCtgryValue);
              break;
            case 'ASL_AGG_ATCH_PT':
              this.abfSLDefaultValues['ASL_AGG_ATCH_PT'].push(resp.dataCtgryValue);
              break;
            case 'SSL_CONTRACT_BASIS':
              this.abfSLDefaultValues['SSL_CONTRACT_BASIS'].push(resp.dataCtgryValue);
              break;
            case 'SSL_DEDUCTIBLE':
              this.abfSLDefaultValues['SSL_DEDUCTIBLE'].push(resp.dataCtgryValue);
              break;
          }
        });
      }

        // Only set sslDataLoaded to true if we actually have VALID SSL data
        const hasSSLData = Object.keys(this.abfSLDefaultValues)
          .filter(key => key !== 'ER_FUNDING_LEVEL') // Exclude non-SSL keys
          .every(key => this.abfSLDefaultValues[key]?.[0]);



        // For ABF funding type, wait for ALL SSL data to be loaded
        if (this.opportunityData.fundingType === 'ABF') {

          this.sslDataLoaded = hasSSLData;
        } else {
          this.sslDataLoaded = true; // Non-ABF quotes don't need SSL data
        }
      },
      (error) => {
        // Even if there's an error, show the button so user can proceed
        this.sslDataLoaded = true;
      }
    );
  }
  checkValidRates(validRate: boolean) {
    this.inValidRates = validRate;
  }

  getExperienceSummary(quoteDetails: any) {
    if (
      (quoteDetails.opportunityType === CommonConstants.RENEWAL_LOCAL &&
        quoteDetails['groupExperienceSummary'] &&
        quoteDetails['medical'] &&
        quoteDetails['medical']['experienceClaimsAvailable'] &&
        quoteDetails['medical']['experienceClaimsAvailable'].toLocaleLowerCase() === 'yes') ||
      (quoteDetails.opportunityType === CommonConstants.NEW_BUSINESS_LOCAL && quoteDetails['medical'])
    ) {
      let lob = this.opportunityData.lob || '';
      let fundingType = this.opportunityData.fundingType || '';
      let opportunityID = this.opportunityData.opportunityID || '';
      let quoteHeaderID = this.opportunityData.quoteHeaderID || '';
      let quoteOrigin = this.opportunityData.quoteOrigin || '';
      let ratingTransID = this.opportunityData.ratingTransID || '';

      this.commonQuoteService.getRenewalExperienceSummary(opportunityID, quoteHeaderID, quoteOrigin, fundingType, lob, ratingTransID).subscribe(
        (response) => {
          if (response) {
            this.experienceSumData = response;
            this.experienceSumData[CommonConstants.FUNDING_TYPE] = fundingType;
          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }

  addRenewalClass(type = '') {
    if (this.RateData && this.RateData['opportunityType'] !== CommonConstants.RENEWAL_LOCAL) {
      return '';
    }
    if (type === 'header') {
      return 'renewal-header-bg';
    } else {
      return '';
    }
  }
  getEventReceivedStatus() {
    return (
      this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
      this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
      this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)
    );
  }

  updateCurvRiskScore(event:any) {
    if(event.isSSEEvent){
      this.sseCurvRiskScore = event.initialRiskScoreValue;
    }else {
      this.curvRiskScore = event.initialRiskScoreValue;
    }
  }
  enableCurvFlashing(event: any) {
    if(event.riskScoreFlash){
      this.enableRiskScoreFlash = true;
    } else {
      this.enableRiskScoreFlash = false;
    }
  }

  setMissingCompAdjustmentData() {
    if (this.uwAdjustmentFetchObject.uwAdjustment && this.RateData.factors && this.RateData.factors.experienceFactors && this.RateData.factors.experienceFactors.expRateAction) {
      let expFactorsRateData = structuredClone(this.RateData.factors.experienceFactors.expRateAction)
      delete expFactorsRateData.totalPremium;

      if (this.uwAdjustmentFetchObject.uwAdjustment.abfRateActionAdjustment && !this.uwAdjustmentFetchObject.uwAdjustment.abfRateActionAdjustment.componentRateAction) {
        if (this.uwService.showComponentAdjustmentsForAlternates(this.RateData)) {
          if (this.RateData && this.RateData.uwAdjustment) {
            this.RateData.uwAdjustment.abfRateActionAdjustment['componentRateAction'] = structuredClone(expFactorsRateData);
          }
          if (this.InitialRateData && this.InitialRateData.uwAdjustment) {
            this.InitialRateData.uwAdjustment.abfRateActionAdjustment['componentRateAction'] = structuredClone(expFactorsRateData);
          }
        };
      }
    }
  }

  groupExperienceSubmit(data) {
    this.groupExperienceData = data;

    const abfValues = {}
    if (this.RateData.fundingType !== 'FI') {
      const {
        surplusRefund,
        aggSLCorridor,
        sslContractBasis,
        sslDeductible
      } = this.uwService.setupReQuoteABFInitialValues(this.RateData.fundingType !== 'FI', this.abfSLDefaultValues,
          this.RateData.medical?.stopLossCovg ?? null        );


      abfValues['stopLossCovg'] = {};
      abfValues['stopLossCovg']['sslDeductible'] = sslDeductible.value;
      abfValues['stopLossCovg']['sslContractBasis'] = sslContractBasis.value;
      abfValues['stopLossCovg']['surplusRefund'] = surplusRefund.value;
      abfValues['stopLossCovg']['aggSLCorridor'] = aggSLCorridor.value;
    }

    let errFundingFactor
    if (this.RateData.medical &&
      (this.RateData.medical.employerFundingLevel ||
        this.RateData.medical.employerFundingLevel === 0)) {

      errFundingFactor = parseFloat((this.RateData.medical.employerFundingLevel * 100).toFixed(1));
    } else if (this.abfSLDefaultValues['ER_FUNDING_LEVEL'] &&
      (this.abfSLDefaultValues['ER_FUNDING_LEVEL'].dfltPct ||
        this.abfSLDefaultValues['ER_FUNDING_LEVEL'].dfltPct === 0)) {

      errFundingFactor = parseFloat((this.abfSLDefaultValues['ER_FUNDING_LEVEL'].dfltPct * 100).toFixed(1));
    }

    let selectedCommissionType = null;
    let commissionValue = null;
    if (this.RateData.medical && this.RateData.medical?.proposedPlans?.length) {
        selectedCommissionType = this.RateData.medical.proposedPlans[0]['commissionType'];
        if (selectedCommissionType.toLowerCase() !== 'percent') {
          commissionValue = parseFloat(this.RateData.medical.proposedPlans[0]['commissionValue']).toFixed(2);
        } else {
          commissionValue = this.RateData.medical.proposedPlans[0]['commissionValue'];
        }
      }

    const reQuoteObj = {
      factorEffectiveDate : this.datepipe.transform(this.RateData.factorEffectiveDate, "MM-dd-yyyy"),
      riskScoreVersionOpted : 'NOT REQUESTED',
      riskScoreType : null,
      errFundingFactor : errFundingFactor,
      commissionValue: commissionValue,
      selectedCommissionType: selectedCommissionType,
      ...abfValues
    };

    this.reQuoteData = reQuoteObj;
    this.onApplyAdjustments('grpExpSubmit');

  }
}
