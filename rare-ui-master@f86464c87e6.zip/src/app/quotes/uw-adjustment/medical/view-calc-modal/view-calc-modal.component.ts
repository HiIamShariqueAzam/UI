import { KeyValue } from '@angular/common';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { CommonService, PrintExhibitService } from 'src/app/shared/services';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { UnderwriterAdjustmentService } from '../uw-adjustment.service';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { AfterViewInit, Component, ElementRef, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { CommonUtil } from 'src/app/shared/utils/common-util';

@Component({
  selector: 'app-view-calc-modal',
  templateUrl: './view-calc-modal.component.html',
  styleUrls: ['./view-calc-modal.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class ViewCalcRatesComponent implements OnInit, OnChanges, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  @Input() planData: any;
  @Input() fundingType: any;
  @Input() insertedTimestamp: any;
  @Input() initialRateData: any;
  @Input() rateData: any;
  @Input() metaTransID: any;
  @Input() ratingTransID: any;
  @Input() isOldRiskScoreVersion: boolean;
  @Input() alternateQuote: boolean;
  @Input() LGFItoSGAbfCrossSelling: boolean;
  

  planName: string = '';
  hasRiskScore: boolean = false;
  hasWithoutRiskScoreValues: boolean = false;
  trailLogs: any;
  isViewCalcMedical: boolean = false;
  isViewCalcDrug: boolean = false;
  isViewCalcClaimCost: boolean = false;
  isViewCalcFiEquPremium: boolean = false;
  isViewCalcFiPremium: boolean = false;
  isViewCalcAbfPremium: boolean = false;
  downloadFailed: boolean = false;
  showRiskScore: boolean;
  showABFCompAdj: boolean = false;

  header = {
    header: '',
    pureComponent: 'Pure Components',
    abfComponentForTarget: 'ABF Components for Target',
    adjPureComponent: 'Qte lvl Adj ABF Components',
    adjRblComponent: 'Rbl Components',
    adjAbfComponentForTarget: 'Final Adj Components'
  };

  generalKeys = [
    {
      key: 'contractEffectiveDate',
      description: 'Contract Eff Date '
    },
    {
      key: 'contractCode',
      description: 'Contract Code '
    },
    {
      key: 'mbu',
      description: 'MBU Code '
    },
    {
      key: 'chamberOfCommerce',
      description: 'Chamber of Commerce'
    },
    {
      key: 'participationRate',
      description: 'Participation Rate',
      type: 'Percent'
    },
    {
      key: 'premiumDelay',
      description: 'Premium Delay'
    },
    {
      key: 'riskScore',
      description: 'Risk Score'
    }
  ];

  generalKeys_MEWA = [
    {
      key: 'contractEffectiveDate',
      description: 'Contract Eff Date '
    },
    {
      key: 'contractCode',
      description: 'Contract Code '
    },
    {
      key: 'mbu',
      description: 'MBU Code '
    }
  ];

  claimsCostKeys = [
    {
      key: 'morbidityFactor',
      description: 'Morbidity'
    },
    {
      key: 'networkAdjustmentFactor',
      description: 'Network Adjustment Factor'
    },
    {
      key: 'industryFactor',
      description: 'Industry Factor'
    },
    {
      key: 'groupSizeFactor',
      description: 'Group Size Factor'
    },
    {
      key: 'newBusinessFactor',
      description: 'New Business Factor'
    },
    {
      key: 'virginGrpFactor',
      description: 'Virgin Group Factor'
    },
    {
      key: 'mhsaAmount',
      description: 'MHSA Amount',
      type: 'PMPM'
    },
    {
      key: 'hottClaims',
      description: 'Hott Claims',
      type: 'PMPM'
    },
    {
      key: 'lstMedClmGrpmRateAdjFctr',
      description: '',
      type: ''
    },
    {
      key: 'nonRetentionAssessmentPMPM',
      description: 'Non Retention Assessments - PMPM',
      type: 'PMPM'
    },
    {
      key: 'nonRetentionAssessmentPercent',
      description: 'Non Retention Assessments - Percent',
      type: 'Percent'
    },
    {
      key: 'medClaimCost',
      description: 'Medical Claims Cost',
      type: 'PMPM'
    },
    {
      key: 'rxClaimCost',
      description: 'Rx Claims Cost',
      type: 'PMPM'
    },
    {
      key: 'totalClaimCost',
      description: 'Total Claims Cost',
      type: 'PMPM'
    }
  ];

  lobSpecificKeys_MEWA = [
    {
      key: 'monthlyPremium',
      description: 'Monthly premium',
      type: 'Flat Dollar'
    },
    {
      key: 'yearlyPremium',
      description: 'Annual premium',
      type: 'Flat Dollar'
    },
    {
      key: 'riskFactorAdjusted',
      description: 'Risk Factor Adjusted'
    },
    {
      key: 'uwRiskAdjFactor',
      description: 'UW Risk Adjustment Factor'
    },
    {
      key: 'wholeHealthAdjustmentFactor',
      description: 'Whole health adjustment'
    },
    {
      key: 'netPMPMWithAdjustment',
      description: 'Net PMPM unrounded Adjusted',
      type: 'Flat Dollar'
    },
    {
      key: 'reqPMPYPremiumWithAdjustment',
      description: 'REQ PMPY PREM Adjusted',
      type: 'Flat Dollar'
    },
    {
      key: 'finalRiskFactor',
      description: 'Final Risk Factor'
    },
    {
      key: 'whsReduction',
      description: 'WHS Reduction'
    },
    {
      key: 'monthlyPremiumAdjusted',
      description: 'Monthly premium Adjusted',
      type: 'Flat Dollar'
    },
    {
      key: 'yearlyPremiumAdjusted',
      description: 'Annual premium Adjusted',
      type: 'Flat Dollar'
    }
  ];

  lobSpecificKeys = [
    {
      key: 'startCost',
      description: 'Starting Cost',
      type: 'PMPM'
    },
    {
      key: 'startingCostAdjustment',
      description: 'Starting Cost Adjustment'
    },
    {
      key: 'strngFctr',
      description: 'Relativity'
    },
    {
      key: 'lgsltvAdjustment',
      description: 'Legislative Adjustment'
    },
    {
      key: 'areaFactor',
      description: 'Area Factor'
    },
    {
      key: 'decrementFactor',
      description: 'Area Decrement Factor'
    },
    {
      key: 'ageSexFactor',
      description: 'Age/Sex Factor'
    },
    {
      key: 'trendEffDate',
      description: 'Trend Eff Date'
    },
    {
      key: 'trendMidDate',
      description: 'Trend Eff Date Midpoint'
    },
    {
      key: 'trendFactor',
      description: 'Trend Factor'
    },
    {
      key: 'trendingDays',
      description: 'Days of Trend'
    },
    {
      key: 'adjustedTrendFactor',
      description: 'Adjusted Trend Factor'
    },
    {
      key: 'costOfCareAdjustment',
      description: 'Cost of Care Adjustment'
    },
    {
      key: 'medBnftSlopeFctr',
      description: 'Benefit Slope Factor'
    },
    {
      key: 'dedFndngFctr',
      description: 'Deductible Funding Factor'
    }
  ];

  premiumCostKeys = [
    {
      key: 'premiumDelayChargeFactor',
      description: 'Grace Period / Premium Delay Interest Charge'
    },
    {
      key: 'acaInsurerFeeFactor',
      description: 'ACA Insurer Fee'
    },
    {
      key: 'cerPCORIFee',
      description: 'CER PCORI Fee',
      type: 'PMPM'
    },
    {
      key: 'statePremiumTaxesFactor',
      description: 'State Premium Taxes',
      type: 'Percent'
    },
    {
      key: 'participationAdjustment',
      description: 'Participation Adjustment'
    },
    {
      key: 'specialtyDiscountAdjFactor',
      description: 'Speciality Discount (hits total premium)'
    },
    {
      key: 'retentionAssessmentPMPM',
      description: 'Retention Assessments - PMPM',
      type: 'PMPM'
    },
    {
      key: 'retentionAssessmentPercent',
      description: 'Retention Assessments - Percent',
      type: 'Percent'
    },
    {
      key: 'chamberOfCommerce',
      description: 'Chamber of Commerce'
    },
    {
      key: 'medNbDscntFctr',
      description: 'New Business Discount (hits total Premium)'
    },
    {
      key: 'grossPMPM',
      description: 'PMPM Before Risk Score',
      type: 'PMPM'
    },
    {
      key: 'finalGrossPMPM',
      description: 'Gross PMPM before Adjustment',
      type: 'PMPM'
    },
    {
      key: 'totalMonthlyPremium',
      description: 'Monthly Premium (excls J & K)',
      type: 'PMPM'
    },
    {
      key: 'adjTierFactor',
      description: 'Adjusted Tier Factor'
    },
    {
      key: 'totalAdjustment',
      description: 'Total Adjustments'
    },
    {
      key: 'addOnCost',
      description: 'Add-On PMPM',
      type: 'PMPM'
    },
    {
      key: 'finalGrossPMPMAdjusted',
      description: 'Final Gross PMPM - Adjusted',
      type: 'PMPM'
    },
    {
      key: 'totalMonthlyPremiumAdjusted',
      description: 'Monthly Premium - Adjusted',
      type: 'PMPM'
    }
  ];

  FIRenewalPremiumCostKeys = [
    {
      key: 'premiumDelayChargeFactor',
      description: 'Grace Period / Premium Delay Interest Charge'
    },
    {
      key: 'acaInsurerFeeFactor',
      description: 'ACA Insurer Fee'
    },
    {
      key: 'cerPCORIFee',
      description: 'CER PCORI Fee',
      type: 'PMPM'
    },
    {
      key: 'statePremiumTaxesFactor',
      description: 'State Premium Taxes',
      type: 'Percent'
    },
    {
      key: 'participationAdjustment',
      description: 'Participation Adjustment'
    },
    {
      key: 'specialtyDiscountAdjFactor',
      description: 'Speciality Discount (hits total premium)'
    },
    {
      key: 'retentionAssessmentPMPM',
      description: 'Retention Assessments - PMPM',
      type: 'PMPM'
    },
    {
      key: 'retentionAssessmentPercent',
      description: 'Retention Assessments - Percent',
      type: 'Percent'
    },
    {
      key: 'chamberOfCommerce',
      description: 'Chamber of Commerce'
    },
    {
      key: 'medNbDscntFctr',
      description: 'New Business Discount (hits total Premium)'
    },
    {
      key: 'grossPMPM',
      description: 'PMPM Before Risk Score',
      type: 'PMPM'
    },
    {
      key: 'finalGrossPMPM',
      description: 'Pure Manual Gross PMPM before Adjustment',
      type: 'PMPM'
    },
    {
      key: 'WHSAdj',
      description: 'WHS Adjustment',
    },
    {
      key: 'grossPMPMWithWHSDiscount',
      description: 'Gross PMPM with WHS Adjustment',
      type: 'PMPM'
    },
    {
      key: 'fiExperienceGrossPMPM',
      description: 'Exp Adjusted Gross PMPM',
      type: 'PMPM'
    },
    {
      key: 'fiExperienceMonthlyPremium',
      description: 'Monthly Premium (excls J & K)',
      type: 'PMPM'
    },
    {
      key: 'adjTierFactor',
      description: 'Adjusted Tier Factor'
    },
    {
      key: 'totalAdjustment',
      description: 'Total Adjustments'
    },
    {
      key: 'addOnCost',
      description: 'Add-On PMPM',
      type: 'PMPM'
    },
    {
      key: 'finalFIExperienceAdjustedGrossPMPM',
      description: 'Final Gross PMPM - Adjusted',
      type: 'PMPM'
    },
    {
      key: 'finalFIExperienceAdjustedMonthlyPremium',
      description: 'Monthly Premium - Adjusted',
      type: 'PMPM'
    }
  ];

  abfCalcKeys = [
    {
      key: 'claimsCostWithRiskScore',
      description: 'ABF Claims Cost',
      type: 'PMPM'
    },
    {
      key: 'claimAdjustmentFctr',
      description: 'ABF Claim Modification Adj'
    },
    {
      key: 'adjustedClaimsCost',
      description: 'ABF Adj Claims Cost',
      type: 'PMPM'
    },
    {
      key: 'premTrgtAdjFactor',
      description: 'FI-to-ABF Premium Adjustment'
    },
    {
      key: 'abfGrossPMPM',
      description: 'Target Gross PMPM - ABF',
      type: 'PMPM'
    },
    {
      key: 'claimsAboveSSLPercentage',
      description: 'Claims Above SSL',
      type: 'Percent'
    },
    {
      key: 'claimsBelowSSLPercentage',
      description: 'Claims below SSL',
      type: 'Percent'
    },
    {
      key: 'sslCoverageAdjFctr',
      description: 'SSL Coverage Period Adjustment'
    },
    {
      key: 'sslRetentionFactors',
      description: 'SSL Retention Factors'
    },
    {
      key: 'aslCoverageAdjFctr',
      description: 'ASL Coverage Period Adjustment'
    },
    {
      key: 'aslRetentionFactors',
      description: 'ASL Retention Factors'
    },
    {
      key: 'aslRateFctr',
      description: 'ASL Rate Factor'
    },
    {
      key: 'terminalLiabilityFctr',
      description: 'Terminal Liability Factor'
    },
    {
      key: 'sslClaimsNoLoad',
      description: 'SSL Claims',
      type: 'PMPM'
    },
    {
      key: 'aslClaimsNoLoad',
      description: 'ASL Claims',
      type: 'PMPM'
    },
    {
      key: 'abfComponents',
      description: 'abfComponents'
    },
    {
      key: 'experienceAdjustedClaimCost',
      description: 'Exp Adj ABF Claim Cost',
      type: 'RoundTwoDecimal'
    },
    {
      key: 'experienceAdjustedGrossPMPM',
      description: 'Exp Adj ABF Gross PMPM',
      type: 'RoundTwoDecimal'
    },
    {
      key: 'WHSAdj',
      description: 'WHS Adjustment',
    },
    {
      key: 'grossPMPMWithWHSDiscount',
      description: 'Gross PMPM with WHS Adjustment',
      type: 'PMPM'
    },
    {
      key: 'abfMonthlyPMPM',
      description: 'Monthly Premium',
      type: 'PMPM'
    },
    {
      key: 'totalAdjustment',
      description: 'Total Adjustments'
    },
    {
      key: 'adjAbfComponents',
      description: 'adjAbfComponents'
    },
    {
      key: 'totalMonthlyPremiumAdjusted',
      description: 'Monthly Premium - Adjusted',
      type: 'PMPM'
    },
    {
      key: 'adjTierFactor',
      description: 'Adjusted Tier Factor'
    },
    {
      key: 'complianceLimitPMPM',
      description: 'Compliance Check Limit',
      type: 'PMPM'
    },
    {
      key: 'excessOfLimit',
      description: 'Compliance Difference',
      type: 'PMPM'
    },
    {
      key: 'compliant',
      description: 'In Compliance?'
    }
  ];

  renewalKeys = ['Exp Adj ABF Claim Cost', 'Exp Adj ABF Gross PMPM'];

  abfFipremiumCostKeys = [
    {
      key: 'premiumDelayChargeFactor',
      description: 'Grace Period / Premium Delay Interest Charge'
    },
    {
      key: 'acaInsurerFeeFactor',
      description: 'ACA Insurer Fee'
    },
    {
      key: 'cerPCORIFee',
      description: 'CER PCORI Fee',
      type: 'PMPM'
    },
    {
      key: 'statePremiumTaxesFactor',
      description: 'State Premium Taxes',
      type: 'Percent'
    },
    {
      key: 'participationAdjustment',
      description: 'Participation Adjustment'
    },
    {
      key: 'specialtyDiscountAdjFactor',
      description: 'Speciality Discount (hits total premium)'
    },
    {
      key: 'retentionAssessmentPMPM',
      description: 'Retention Assessments - PMPM',
      type: 'PMPM'
    },
    {
      key: 'retentionAssessmentPercent',
      description: 'Retention Assessments - Percent',
      type: 'Percent'
    },
    {
      key: 'chamberOfCommerce',
      description: 'Chamber of Commerce'
    },
    {
      key: 'medNbDscntFctr',
      description: 'New Business Discount (hits total Premium)'
    },
    {
      key: 'grossPMPM',
      description: 'PMPM Before Risk Score',
      type: 'PMPM'
    },
    {
      key: 'finalGrossPMPM',
      description: 'Gross PMPM before Adjustment',
      type: 'PMPM'
    }
  ];

  abfRetenKeys = [
    {
      key: 'retentionFactors.cmpntType==SSL',
      description: 'SSL Coverage Period Adjustment'
    },
    {
      key: 'retentionFactors.cmpntType==ASL',
      description: 'ASL Coverage Period Adjustment'
    }
  ];

  abfComponentHeader = ['ASO', 'SSL Prem', 'ASL Prem', 'Max Claims', 'Terminal Liab', 'Total'];

  abfComponentKey = ['asoAdminFee', 'sslPremium', 'aslPremium', 'maxPaidClaim', 'terminalLiability', 'totalPremium'];

  adjAbfComponent = ['adjAsoAdminFee', 'adjSslPremium', 'adjAslPremium', 'adjMaxPaidClaim', 'adjTerminalLiability', 'adjABFPremium'];

  adjRblComponent = ['rblAloAsoAdminFee', 'rblAloSslPremium', 'rblAloAslPremium', 'rblAloMaxPaidClaim', 'rblAloTerminalLiability', 'rblAloAdjAbfPMPM'];

  finalAdjAbfComponent = [
    'finalAdjAsoAdminFee',
    'finalAdjSslPremium',
    'finalAdjAslPremium',
    'finalAdjMaxPaidClaim',
    'finalAdjTerminalLiability',
    'finalAdjAbfPMPM'
  ];
  enableCurvChanges: boolean = false;

  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    private commonService: CommonService,
    private peService: PrintExhibitService,
    private commonQuoteService: CommonQuoteService,
    private uwService: UnderwriterAdjustmentService
  ) {
    config.backdrop = 'static';
    config.keyboard = false;
  }


  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  getAbfComponentValue(data) {
    let retObj = [];
    if (this.planData.factors && this.planData.factors.abfFactors && this.planData.factors.abfFactors.abfComponents) {
      if (data === 'pureComponent') {
        this.abfComponentKey.forEach((key) => {
          retObj.push(this.planData.factors.abfFactors.abfComponents.INITIAL[key]);
        });
      } else if (data === 'abfComponentForTarget') {
        this.abfComponentKey.forEach((key) => {
          retObj.push(this.planData.factors.abfFactors.abfComponents.UNADJUSTED[key]);
        });
      } else if (data === 'adjAbfComponent') {
        this.adjAbfComponent.forEach((key) => {
          retObj.push(this.planData.factors.abfFactors[key]);
        });
      } else if (data === 'adjRblComponent') {
        this.adjRblComponent.forEach((key) => {
          retObj.push(this.planData.factors.abfFactors[key]);
        });
      } else if (data === 'finalAdjAbfComponent') {
        this.finalAdjAbfComponent.forEach((key) => {
          retObj.push(this.planData.factors.abfFactors[key]);
        });
      } else if (data === 'adjExpAbfComponent' && this.planData.factors.abfFactors.abfComponents.EXPADJUSTED) {
        this.abfComponentKey.forEach((key) => {
          retObj.push(this.planData.factors.abfFactors.abfComponents.EXPADJUSTED[key]);
        });
      }
    }
    return retObj;
  }

  ngOnChanges(changes: SimpleChanges) {
    let riskScore: any = 'N/A';
    this.enableCurvChanges = false;
    if (this.planData && this.planData.riskScore) {
      if (this.planData.riskScore != -99999 && !isNaN(this.planData.riskScore)) {
        riskScore = parseFloat(this.planData.riskScore);
      }
    }
    if (this.planData && this.planData.factors) {
      this.hasWithoutRiskScoreValues =
        this.planData.factors.medClaimCostWithoutRiskscore && !isNaN(parseFloat(this.planData.factors.medClaimCostWithoutRiskscore));
      this.planData.factors['riskScore'] = riskScore;
    } else {
      this.hasWithoutRiskScoreValues = false;
    }
    this.hasRiskScore = !isNaN(riskScore);
    this.planName = this.planData && this.planData.planBenefits && this.planData.planBenefits.planName;
    this.populateMedicalFIFundingType(riskScore);
    this.isViewCalcMedical =
      this.isViewCalcClaimCost =
      this.isViewCalcDrug =
      this.isViewCalcFiEquPremium =
      this.isViewCalcAbfPremium =
      this.isViewCalcFiPremium =
        false;

    if(this.uwService.showComponentAdjustmentsForAlternates(this.rateData)) {
      this.showABFCompAdj = true;
    }
    if((this.rateData?.riskScoreType == 'CURV' || this.rateData?.riskScoreType == 'NA') && (this.fundingType == 'FI' || this.fundingType == 'ABF')){
        this.enableCurvChanges = true;
    }
  }

  checkRenewalKey(description: string) {
    if (this.renewalKeys.indexOf(description) === -1) {
      return true;
    } else {
      return this.rateData.opportunityType !== 'Renewal Local' ? false : true;
    }
  }

  checkIsRenewal() {
    return this.rateData.opportunityType === 'Renewal Local';
  }

  downloadViewCalcExcelMEWA() {
    let viewCalcDetails = {};
    let viewCalcData = {};

    viewCalcData['planName'] = this.planName;
    viewCalcData['opportunityID'] = this.rateData.opportunityID;
    viewCalcData['quoteHeaderID'] = this.rateData.quoteHeaderID;
    viewCalcData['contractCode'] = this.planData.contractCode;
    viewCalcData['lob'] = this.planData.lob;
    viewCalcData['mbu'] = this.planData.mbu;
    viewCalcData['opportunityType'] = this.rateData.opportunityType;

    Object.keys(this.trailLogs).forEach((key) => {
      let camelKey = this.convertToCamel(key);
      viewCalcData[camelKey] = JSON.parse(JSON.stringify(this.trailLogs[key]));
    });
    viewCalcDetails['data'] = viewCalcData;

    let tierBasedComponents = [];
    let medicareTierBasedComponents=[];
    if (this.rateData && this.rateData.uwAdjustment) {
      let tierRatioCalculationType = null;
      if (this.rateData.uwAdjustment.tierRatioCalculationType) {
        tierRatioCalculationType = this.rateData.uwAdjustment.tierRatioCalculationType;
      } else {
        tierRatioCalculationType = this.planData.factors.tierRatioCalculationType;
      }
      let rates = {};
      let medicareRates={};
      rates['description'] = tierRatioCalculationType + ' Tier Ratio';
      rates['tierValue'] = this.getTierRatios(this.rateData.factors?.mewaFactors?.tierFactor);
      medicareRates['description'] ='Medicare Tier Ratio';
      medicareRates['tierValue'] = this.rateData.factors?.mewaFactors?.medicareTierFactor ? this.getTierRatios(this.rateData.factors.mewaFactors.medicareTierFactor): null;
      tierBasedComponents.push(rates);
      medicareTierBasedComponents.push(medicareRates);
    }

    if (this.planData && this.planData.rateInfo) {
      let rates = {};
      let medicareRates={};
      rates['description'] = 'Rates';
      rates['tierValue'] = this.getRates(this.planData.rateInfo);

      medicareRates['description']='Medicare Rates';
      medicareRates['tierValue'] = this.planData.factors?.mewaFactors?.medicareTieredRates ? this.getRates(this.planData.factors.mewaFactors.medicareTieredRates): null;
      tierBasedComponents.push(rates);
      medicareTierBasedComponents.push(medicareRates);
      
    }
    
    viewCalcData['tierBasedComponents'] = tierBasedComponents;
    viewCalcData['medicareTierBasedComponents']= medicareTierBasedComponents;
    this.downloadViewCalcExcelFile(viewCalcDetails);
  }

  downloadViewCalcExcel() {
    if (this.rateData.quotingType == CommonConstants.MEWA) {
      this.downloadViewCalcExcelMEWA();
      return;
    }
    let viewCalcDetails = {};
    let viewCalcData = {};
    let tierBasedComponents = [];
    viewCalcData['planName'] = this.planName;
    viewCalcData['opportunityID'] = this.rateData.opportunityID;
    viewCalcData['quoteHeaderID'] = this.rateData.quoteHeaderID;
    viewCalcData['contractCode'] = this.planData.contractCode;
    viewCalcData['lob'] = this.planData.lob;
    viewCalcData['acsFactor'] = this.planData.factors.acsFactor;
    viewCalcData['opportunityType'] = this.rateData.opportunityType;
    viewCalcData['quotedSubscribers'] = this.rateData?.factors?.eligibleSubCount;

    Object.keys(this.trailLogs).forEach((key) => {
      let camelKey = this.convertToCamel(key);
      viewCalcData[camelKey] = JSON.parse(JSON.stringify(this.trailLogs[key]));
    });
    viewCalcData['medical']['ageSexFactor']['valueWithoutRiskScore'] = JSON.parse(JSON.stringify(viewCalcData['medical']['ageSexFactor']['value']));
    viewCalcData['medical']['ageSexFactor']['value'] = this.getValueWithRiskScore(viewCalcData['medical']['ageSexFactor']);
    viewCalcData['drug']['ageSexFactor']['valueWithoutRiskScore'] = JSON.parse(JSON.stringify(viewCalcData['drug']['ageSexFactor']['value']));
    viewCalcData['drug']['ageSexFactor']['value'] = this.getValueWithRiskScore(viewCalcData['drug']['ageSexFactor']);
    viewCalcData['claimCost']['industryFactor']['value'] = this.getValueWithRiskScore(viewCalcData['claimCost']['industryFactor']);

    if (viewCalcData['abfPremium'] && viewCalcData['abfPremium']['abfComponents']) {
      if (viewCalcData['abfPremium']['abfComponents']) {
        viewCalcData['abfPremium']['abfComponents']['abfComponentMap'] = viewCalcData['abfPremium']['abfComponents']['value'];
        delete viewCalcData['abfPremium']['abfComponents']['value'];
      }
      if (viewCalcData['abfPremium']['adjAbfComponents']) {
        delete viewCalcData['abfPremium']['adjAbfComponents'];
      }
    }

    if (this.rateData && this.rateData.uwAdjustment) {
      let outputTier = this.rateData.uwAdjustment.outputTier;
      let tierRatioCalculationType = null;
      if (this.rateData.uwAdjustment.tierRatioCalculationType) {
        tierRatioCalculationType = this.rateData.uwAdjustment.tierRatioCalculationType;
      } else {
        tierRatioCalculationType = this.planData.factors.tierRatioCalculationType;
      }
      let rates = {};
      rates['description'] = tierRatioCalculationType + ' Tier Ratio';
      switch (tierRatioCalculationType) {
        case 'Standard':
          rates['tierValue'] = this.getTierRatios(this.rateData.factors?.rateTierFactor[outputTier + '-tier']);
          break;
        case 'Current':
          rates['tierValue'] = this.getTierRatios(this.planData.factors.currentRateTierFactor[outputTier + '-tier']);
          break;
        case 'Custom':
          rates['tierValue'] = this.getTierRatios(
            this.rateData.uwAdjustment.customTierRatio
              ? this.rateData.uwAdjustment.customTierRatio
              : this.planData.factors.customRateTierFactor[outputTier + '-tier']
          );
          break;
      }
      tierBasedComponents.push(rates);
    }

    if (this.planData && this.planData.rateInfo) {
      let rates = {};
      rates['description'] = 'Rates';
      rates['tierValue'] = this.getRates(this.planData.rateInfo);
      tierBasedComponents.push(rates);
    }
    viewCalcData['tierBasedComponents'] = tierBasedComponents;
    this.setAbfComponents(viewCalcData);
    if (
      StringUtils.isEqual(this.rateData?.opportunityType, CommonConstants.RENEWAL_LOCAL) &&
      StringUtils.isEqual(this.fundingType, CommonConstants.ABF) &&
      (!this.showABFCompAdj || this.LGFItoSGAbfCrossSelling) &&
      viewCalcData['abfPremium']['abfComponents']['abfComponentMap']['RECALCULATED']
    ) {
      delete viewCalcData['abfPremium']['abfComponents']['abfComponentMap']['RECALCULATED'];
    }
    viewCalcDetails['data'] = viewCalcData;
    this.downloadViewCalcExcelFile(viewCalcDetails);
  }

  convertToCamel(key) {
    var result = key.replace(/([A-Z])/g, '$1');
    return result.charAt(0).toLowerCase() + result.slice(1);
  }

  getRates(rateInfo) {
    let tierValue = {};
    if (rateInfo.single && rateInfo.single != 0) {
      tierValue['EE'] = rateInfo.single;
    }
    if (rateInfo.eeOne && rateInfo.eeOne != 0) {
      tierValue['E1'] = rateInfo.eeOne;
    }
    if (rateInfo.eeSpouse && rateInfo.eeSpouse != 0) {
      tierValue['ES'] = rateInfo.eeSpouse;
    }
    if (rateInfo.eeChild && rateInfo.eeChild != 0) {
      tierValue['EK'] = rateInfo.eeChild;
    }
    if (rateInfo.eeChildren && rateInfo.eeChildren != 0) {
      tierValue['EC'] = rateInfo.eeChildren;
    }
    if (rateInfo.family && rateInfo.family != 0) {
      tierValue['EF'] = rateInfo.family;
    }
    return tierValue;
  }

  getTierRatios(tierRatios: any) {
    let tierValue = {};
    if (tierRatios) {
      if (tierRatios.eeFactor) {
        tierValue['EE'] = tierRatios.eeFactor;
      }
      if (tierRatios.e1Factor) {
        tierValue['E1'] = tierRatios.e1Factor;
      }
      if (tierRatios.esFactor) {
        tierValue['ES'] = tierRatios.esFactor;
      }
      if (tierRatios.ecFactor) {
        tierValue['EC'] = tierRatios.ecFactor;
      }
      if (tierRatios.ekFactor) {
        tierValue['EK'] = tierRatios.ekFactor;
      }
      if (tierRatios.efFactor) {
        tierValue['EF'] = tierRatios.efFactor;
      }
    }
    return tierValue;
  }

  setAbfComponents(viewCalcDetails) {
    if (this.planData && this.planData.factors && this.planData.factors.abfFactors && this.planData.factors.abfFactors.abfComponents) {
      let abfComponents = this.planData.factors.abfFactors.abfComponents;
      if (abfComponents.INITIAL) {
        viewCalcDetails.abfPremium.abfComponents.abfComponentMap.INITIAL = abfComponents.INITIAL;
      }
      if (abfComponents.UNADJUSTED) {
        viewCalcDetails.abfPremium.abfComponents.abfComponentMap.UNADJUSTED = abfComponents.UNADJUSTED;
      }
      if (abfComponents.EXPADJUSTED) {
        viewCalcDetails.abfPremium.abfComponents.abfComponentMap.EXPADJUSTED = abfComponents.EXPADJUSTED;
      }
      viewCalcDetails.abfPremium.abfComponents.abfComponentMap.UWADJUSTED = this.setAdjAbfComponentValues(this.adjAbfComponent, abfComponents.UNADJUSTED);

      viewCalcDetails.abfPremium.abfComponents.abfComponentMap.RECALCULATED = this.setAdjAbfComponentValues(this.adjRblComponent, abfComponents.UNADJUSTED);

      viewCalcDetails.abfPremium.abfComponents.abfComponentMap.COMPADJUSTED = this.setAdjAbfComponentValues(
        this.finalAdjAbfComponent,
        abfComponents.UNADJUSTED
      );
    }
  }

  setAdjAbfComponentValues(adjComponent, UNADJUSTED) {
    let componentsObj = {};
    let abfFactors = this.planData.factors.abfFactors;
    if (adjComponent && abfFactors) {
      adjComponent.forEach((key) => {
        if (key.includes('adjAsoAdminFee') || key.includes('rblAloAsoAdminFee') || key.includes('finalAdjAsoAdminFee')) {
          componentsObj['asoAdminFee'] = abfFactors[key];
        } else if (key.includes('adjSslPremium') || key.includes('rblAloSslPremium') || key.includes('finalAdjSslPremium')) {
          componentsObj['sslPremium'] = abfFactors[key];
        } else if (key.includes('adjAslPremium') || key.includes('rblAloAslPremium') || key.includes('finalAdjAslPremium')) {
          componentsObj['aslPremium'] = abfFactors[key];
        } else if (key.includes('adjMaxPaidClaim') || key.includes('rblAloMaxPaidClaim') || key.includes('finalAdjMaxPaidClaim')) {
          componentsObj['maxPaidClaim'] = abfFactors[key];
        } else if (key.includes('adjTerminalLiability') || key.includes('rblAloTerminalLiability') || key.includes('finalAdjTerminalLiability')) {
          componentsObj['terminalLiability'] = abfFactors[key];
        } else if (key.includes('adjABFPremium') || key.includes('rblAloAdjAbfPMPM') || key.includes('finalAdjAbfPMPM')) {
          componentsObj['totalPremium'] = abfFactors[key];
        }
      });
    }
    return Object.keys(componentsObj).length != 0 ? componentsObj : UNADJUSTED;
  }

  downloadViewCalcExcelFile(viewCalcDetails) {
    /* ALGR-128683 - Passing curvRiskScoreEnabled flag to backend to identify if CURV risk score is enabled for the quote */
    viewCalcDetails['data']['curvRiskScoreEnabled'] = this.enableCurvChanges;
    this.commonQuoteService.getViewCalcExcel(this.metaTransID, this.ratingTransID, viewCalcDetails).subscribe(
      (response) => {
        this.downloadFailed = false;
        let processId = response.processId;
        var source = this.commonService.listenForStream(processId);
        source.addEventListener('SEND_EXHIBIT_TO_UI', (message: any) => {
          let eventData = JSON.parse(message.data);
          let fileExt = '.xlsx';
          CommonService.exportFilename = eventData.metaData.fileName ? eventData.metaData.fileName : 'sheet' + fileExt;
          let fileName = this.commonService.getExportFilename();
          let contentData = eventData.payload.contentData;
          const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
        });
        source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
          source.close();
          this.commonQuoteService.cleanUpSSEEvents(processId);
        });
        source.addEventListener('FAILED', (message: any) => {
          source.close();
          this.commonQuoteService.cleanUpSSEEvents(processId);
          this.downloadFailedErrMsg();
        });
      },
      (error) => {
        this.downloadFailedErrMsg();
      }
    );
  }

  downloadFailedErrMsg() {
    this.downloadFailed = true;
    var promise = new Promise<any>((resolve) => {
      setTimeout(() => {
        resolve(false);
      }, 10000);
    });
    promise.then((res) => {
      this.downloadFailed = false;
    });
  }

  setDefault() {
    this.downloadFailed = false;
  }
  /*ALGR-127976: Removed With Risk Score and Without Risk Score headers, display only with risk score values and  
   shifted Risk Score label to general section in view calc modal */
  populateMedicalFIFundingType(riskScore: any) {
    this.trailLogs = {};
    this.trailLogs['general'] = this.populateGenericPlanData(riskScore);
    if (!this.isOldRiskScoreVersion) {
      this.premiumCostKeys = [...this.filterKeyWithOldRiskScore(this.premiumCostKeys)];
      this.abfFipremiumCostKeys = [...this.filterKeyWithOldRiskScore(this.abfFipremiumCostKeys)];
    }
    if (this.rateData.quotingType == CommonConstants.MEWA) {
      this.trailLogs['Medical'] = this.populateMEWASpecificData();
    } else if (this.fundingType.toLowerCase() === 'abf') {
      this.trailLogs['Medical'] = this.populateLobSpecificData('medical');
      this.trailLogs['Drug'] = this.populateLobSpecificData('rx');
      this.trailLogs['ClaimCost'] = this.populateClaimsCostData();
      this.trailLogs['FiEquPremium'] = { ...this.populateAdminRetentions(), ...this.populatePremiumData(this.abfFipremiumCostKeys, 'ABF') };
      this.trailLogs['AbfPremium'] = this.populateAbfCalcData();
    } else {
      this.trailLogs['Medical'] = this.populateLobSpecificData('medical');
      this.trailLogs['Drug'] = this.populateLobSpecificData('rx');
      this.trailLogs['ClaimCost'] = this.populateClaimsCostData();
      this.trailLogs['FiPremium'] = { ...this.populateAdminRetentions(), ...this.populatePremiumData(this.premiumCostKeys, 'FI') };
    }
    this.setParticipationAdjustment();
  }

  populateMEWASpecificData() {
    let retObj = {};

    let mfFactors: Array<any> = this.planData?.factors?.mewaFactors?.factors ?? [];

    mfFactors.forEach((mfFactor) => {
      let value = Number(mfFactor.value);
      if (mfFactor.unit && mfFactor.unit === 'Percent') {
        value = value / 100;
      }

      retObj[mfFactor.id] = {
        value: Number(value),
        description: mfFactor.id,
        type: mfFactor.unit ?? undefined
      };
    });

    let key = 'mewaFactors';
    if (this.planData && this.planData.factors && this.planData.factors[key]) {
      this.lobSpecificKeys_MEWA.forEach((lobObj) => {
        if (
          lobObj.key == 'riskFactorAdjusted' &&
          this.rateData.uwAdjustment &&
          this.rateData.uwAdjustment.quoteAdjustments &&
          !this.isEmptyValue(this.rateData.uwAdjustment.quoteAdjustments.riskFactor)
        ) {
          retObj[lobObj.key] = {
            value: Number(this.rateData.uwAdjustment.quoteAdjustments.riskFactor),
            description: this.checkIsRenewal() ? 'Tiered Risk Factor Adjusted' : lobObj.description,
            type: lobObj.type ?? undefined
          };
        } else if (
          lobObj.key == 'uwRiskAdjFactor' &&
          this.rateData.uwAdjustment &&
          this.rateData.uwAdjustment.quoteAdjustments &&
          !this.isEmptyValue(this.rateData.uwAdjustment.quoteAdjustments.uwAdjustmentFactor)
        ) {
          retObj[lobObj.key] = {
            value: Number(this.rateData.uwAdjustment.quoteAdjustments.uwAdjustmentFactor),
            description: lobObj.description,
            type: lobObj.type ?? undefined
          };
        } else if (
          lobObj.key == 'wholeHealthAdjustmentFactor' &&
          this.rateData.uwAdjustment &&
          this.rateData.uwAdjustment.quoteAdjustments &&
          !this.isEmptyValue(this.rateData.uwAdjustment.quoteAdjustments.wholeHealthAdjustmentFactor)
        ) {
          retObj[lobObj.key] = {
            value: Number(this.rateData.uwAdjustment.quoteAdjustments.wholeHealthAdjustmentFactor),
            description: lobObj.description,
            type: lobObj.type ?? undefined
          };
        } else if (!this.isEmptyValue(this.planData.factors[key][lobObj.key])) {
          let displayValue = this.planData.factors[key][lobObj.key];
          if (lobObj.description?.toLowerCase().includes('unrounded') && !this.isEmptyValue(this.planData.factors[key][lobObj.key + 'Unrounded'])) {
            displayValue = this.planData.factors[key][lobObj.key + 'Unrounded'];
          }
          retObj[lobObj.key] = {
            value: displayValue,
            description: lobObj.description,
            type: lobObj.type ?? undefined
          };
        }
      });
    }
    return retObj;
  }

  filterKeyWithOldRiskScore(list) {
    let filterKeyName = ['PMPM Before Risk Score', 'Risk Score'];
    return list.filter((val) => !StringUtils.checkStrExitsInArr(val.description, filterKeyName));
  }

  getHeaderValue(value) {
    if (value === 'FiPremium') return 'FI Premium';
    else if (value === 'AbfPremium') return 'ABF Premium';
    else if (value === 'FiEquPremium') return 'FI Equivalent Premium';
    else return value;
  }

  isEmptyValue(value) {
    return value === null || value === undefined || value === '';
  }

  removeParticipationAdjustment(retObj) {
    if (this.planData && this.planData.factors && this.planData.factors.applyParticipationAdjToClaimsCost && retObj['participationAdjustment']) {
      delete retObj['participationAdjustment'];
    }
  }

  setParticipationAdjustment() {
    if (this.planData && this.planData.factors && this.planData.factors.applyParticipationAdjToClaimsCost) {
      this.setParticipationAdjustmentToNode('Medical');
      this.setParticipationAdjustmentToNode('Drug');
    }
  }

  setParticipationAdjustmentToNode(node) {
    this.trailLogs[node]['participationAdjustment'] = {
      value: this.planData.factors['participationAdjustment'],
      description: 'Participation Adjustment'
    };
  }

  populateAbfCalcData(): any {
    let retObj = {};
    if (this.planData && this.planData.factors && this.planData.factors.abfFactors) {
      this.abfCalcKeys.forEach((abfObj) => {
        if (
          (abfObj.key === 'sslCoverageAdjFctr' || abfObj.key === 'aslCoverageAdjFctr') &&
          !this.isEmptyValue(this.planData.factors.abfFactors[abfObj.key].cvrgPrdAdjFctr)
        ) {
          retObj[abfObj.key] = {
            value: this.planData.factors.abfFactors[abfObj.key].cvrgPrdAdjFctr,
            description: abfObj.description,
            type: abfObj.type
          };
        } else if (this.planData.factors.abfFactors.retentionFactors && (abfObj.key === 'sslRetentionFactors' || abfObj.key === 'aslRetentionFactors')) {
          this.planData.factors.abfFactors.retentionFactors.forEach((retentionFactor) => {
            if (abfObj.key === 'sslRetentionFactors' && retentionFactor.cmpntType === 'SSL' && !this.isEmptyValue(retentionFactor.retntnAmt)) {
              retObj[retentionFactor.cmpntType + retentionFactor.retntnNm.replace(' ', '')] = {
                value: retentionFactor.retntnAmt,
                description: retentionFactor.retntnNm,
                type: retentionFactor.retntnTypeCd
              };
            }
            if (abfObj.key === 'aslRetentionFactors' && retentionFactor.cmpntType === 'ASL' && !this.isEmptyValue(retentionFactor.retntnAmt)) {
              retObj[retentionFactor.cmpntType + retentionFactor.retntnNm.replace(' ', '')] = {
                value: retentionFactor.retntnAmt,
                description: retentionFactor.retntnNm,
                type: retentionFactor.retntnTypeCd
              };
            }
          });
        } else if (
          (!this.isEmptyValue(this.planData.factors.abfFactors[abfObj.key]) || abfObj.key === 'abfComponents' || abfObj.key === 'adjAbfComponents') &&
          this.checkRenewalKey(abfObj.description)
        ) {
          if (this.checkHasComplianceCheck(abfObj.key, this.planData.factors.abfFactors)) {
          } else {
            let val = this.planData.factors.abfFactors[abfObj.key];
            if (this.renewalKeys.indexOf(abfObj.description) !== -1) {
              val = parseFloat(val.toFixed(2));
            }
            retObj[abfObj.key] = {
              value: val,
              description: abfObj.description,
              type: abfObj.type
            };
          }
        }
      });
    }
    if (this.planData?.factors?.abfFactors?.cmplncChk?.cmplncType === 'ANNPREM') {
      retObj['excessOfLimit'].type = 'ANNPREM';
      retObj['complianceLimitPMPM'].type = 'ANNPREM';
    }
    return retObj;
  }

  checkHasComplianceCheck(key, abfFactors) {
    return !abfFactors['hasComplianceCheck'] && (key === 'excessOfLimit' || key === 'complianceLimitPMPM' || key === 'compliant');
  }

  populateAdminRetentions(): any {
    let retObj = {};
    if (this.planData && this.planData.factors) {
      let keys = ['medicalFactors', 'rxFactors'];
      keys.forEach((key) => {
        if (this.planData.factors[key]) {
          if (this.planData.factors[key].retentionFactors && Array.isArray(this.planData.factors[key].retentionFactors)) {
            this.planData.factors[key].retentionFactors.forEach((retention) => {
              retObj[key + retention.retntnNm.replace(' ', '') + retention.retntnTypeCd] = {
                value: retention.retntnAmt,
                description: retention.retntnNm + (key == 'medicalFactors' ? ' - Medical' : ' - Drug'),
                type: retention.retntnTypeCd
              };
            });
          }
          if (
            this.planData.factors[key].adminAdjustment &&
            (this.planData.factors[key].adminAdjustment.retntnAmt || this.planData.factors[key].adminAdjustment.retntnAmt == 0)
          ) {
            let retnName = this.planData.factors[key].adminAdjustment.retntnNm;
            let retnType = this.planData.factors[key].adminAdjustment.retntnTypeCd || 'PMPM';
            if (!retnName) {
              retnName = 'Admin Adjustment';
            }
            retObj[key + retnName.replace(' ', '') + retnType] = {
              value: this.planData.factors[key].adminAdjustment.retntnAmt,
              description: retnName + (key === 'medicalFactors' ? ' - Medical' : ' - Drug'),
              type: retnType
            };
          }
        }
      });
    }
    return retObj;
  }

  populatePremiumData(premiumCostKeys, type): any {
    let retObj = {};
    let generalAgentDesc;
    if (type === 'ABF') {
      generalAgentDesc = 'General Agent Commission - ABF';
    } else {
      generalAgentDesc = 'General Agent Commission - FI';
    }
    if (this.planData && this.planData.factors) {
      if (this.planData.commissionValue || this.planData.commissionValue == 0) {
        if (this.planData.commissionType && this.planData.commissionType.toLowerCase() === 'percent') {
          retObj['generalAgent'] = {
            value: parseFloat(this.planData.commissionValue),
            description: generalAgentDesc,
            type: this.planData.commissionType
          };
        } else {
          retObj['generalAgent'] = {
            value: parseFloat(this.planData.commissionValue),
            description: generalAgentDesc,
            type: this.planData.commissionType
          };
        }
      }
      if (this.fundingType.toLowerCase() === 'fi' && this.rateData.opportunityType == 'Renewal Local') {
        return this.premiumKeyIterator(this.FIRenewalPremiumCostKeys, retObj);
      } else {
        return this.premiumKeyIterator(premiumCostKeys, retObj);
      }
    }
    return retObj;
  }
  premiumKeyIterator(keyArray, retObj) {
    keyArray.forEach((lobObj) => {
      if (
        !this.isEmptyValue(this.planData.factors[lobObj.key]) &&
        ((lobObj.key == 'chamberOfCommerce' && this.planData.chamberOfCommerce) || lobObj.key !== 'chamberOfCommerce')
      ) {
        retObj[lobObj.key] = {
          value: lobObj.key == 'adjTierFactor' ? this.convertToDecimalNumber(this.planData.factors[lobObj.key]) : this.planData.factors[lobObj.key],
          valueWithoutRiskScore:
            this.planData.factors[lobObj.key + 'WithoutRiskscore'] ||
            (lobObj.key == 'adjTierFactor' ? this.convertToDecimalNumber(this.planData.factors[lobObj.key]) : this.planData.factors[lobObj.key]),
          description: lobObj.description,
          type: lobObj.type
        };
      }
    });
    this.removeParticipationAdjustment(retObj);
    return retObj;
  }

  convertToDecimalNumber(value: any) {
    return value != null && value != '' && typeof value !== 'undefined' ? Number(value) : value;
  }

  populateClaimsCostData(): any {
    let retObj = {};
    if (this.planData && this.planData.factors) {
      this.claimsCostKeys.forEach((lobObj) => {
        if (
          !this.isEmptyValue(this.planData.factors[lobObj.key]) &&
          ((lobObj.key == 'virginGrpFactor' && this.planData.virginGroup) || lobObj.key !== 'virginGrpFactor')
        ) {
          if (lobObj.key == 'lstMedClmGrpmRateAdjFctr') {
            this.setMedClmGrpmRateAdjFctr(retObj);
          } else {
            retObj[lobObj.key] = {
              value: this.planData.factors[lobObj.key],
              valueWithoutRiskScore: this.planData.factors[lobObj.key + 'WithoutRiskscore'] || this.planData.factors[lobObj.key],
              description: lobObj.description,
              type: lobObj.type
            };
          }
        }
      });
    }
    return retObj;
  }

  setMedClmGrpmRateAdjFctr(retObj) {
    if (this.planData.factors.lstMedClmGrpmRateAdjFctr && this.planData.factors.lstMedClmGrpmRateAdjFctr.length > 0) {
      this.planData.factors.lstMedClmGrpmRateAdjFctr.forEach((medClmGrpmRateAdjFctr) => {
        if (medClmGrpmRateAdjFctr.applyLvl === 'Claims') {
          let claimsAdj = {
            value: medClmGrpmRateAdjFctr.adjVal,
            valueWithoutRiskScore: medClmGrpmRateAdjFctr.adjVal,
            description: medClmGrpmRateAdjFctr.adjNm,
            type: medClmGrpmRateAdjFctr.adjType
          };
          retObj[claimsAdj.description] = claimsAdj;
        }
      });
    }
  }

  populateGenericPlanData(riskScore:any): any {
    let retObj = {};
    const riskScoreKey = 'riskScore';
    if (this.planData) {
      if (this.rateData.quotingType == CommonConstants.MEWA) {
        this.generalKeys = this.generalKeys_MEWA;
      }

      this.generalKeys.forEach((lobObj) => {
        if (!this.isEmptyValue(this.planData[lobObj.key]) && lobObj.key != 'chamberOfCommerce' && lobObj.key != 'participationRate') {
          retObj[lobObj.key] = {
            value: this.planData[lobObj.key],
            description: lobObj.description,
            type: lobObj.type
          };
        } else if (lobObj.key == 'chamberOfCommerce') {
          retObj[lobObj.key] = {
            value: this.planData[lobObj.key] ? 'Yes' : 'No',
            description: lobObj.description
          };
        } else if (
          lobObj.key == 'participationRate' &&
          this.planData.participationRate &&
          this.planData.participationRate.findIndex((rate) => rate.type == 'WholeCase') != -1
        ) {
          retObj[lobObj.key] = {
            value: this.planData.participationRate.filter((prate) => prate.type == 'WholeCase')[0].value,
            description: lobObj.description,
            type: lobObj.type
          };
        }
        if (StringUtils.isEqual(lobObj.key, riskScoreKey)) {
          retObj[lobObj.key] = {
            value: riskScore,
            description: lobObj.description,
            type: lobObj.type
          };
        }
      });
    }
    return retObj;
  }

  populateLobSpecificData(type: string): any {
    let retObj = {};
    let key = type === 'medical' ? 'medicalFactors' : 'rxFactors';
    if (this.planData && this.planData.factors && this.planData.factors[key]) {
      this.lobSpecificKeys.forEach((lobObj) => {
        if (!this.isEmptyValue(this.planData.factors[key][lobObj.key])) {
          retObj[lobObj.key] = {
            value: this.planData.factors[key][lobObj.key],
            description: lobObj.description,
            type: lobObj.type
          };
        }
      });
    }
    return retObj;
  }

  ngOnInit() {
    this.showRiskScore = this.commonService.getShowViewCalc();
  }

  originalOrder = (a: KeyValue<string, any>, b: KeyValue<string, any>): number => {
    return 0;
  };

  isMonthlyPremium(value: any, type): boolean {
    return value.description.indexOf('Monthly Premium') !== -1 || value.type === 'RoundTwoDecimal';
  }

  isPercent(value: any, type): boolean {
    return value.type === 'Percent' && value.description.indexOf('General Agent Commission') === -1;
  }

  isCommissionPercent(value: any, type): boolean {
    return value.type === 'Percent' && value.description.indexOf('General Agent Commission') !== -1;
  }

  isDollarType(value: any, type): boolean {
    return (
      !this.isMonthlyPremium(value, type) &&
      (value.type === 'PMPM' || value.type === 'PCPM' || value.type === 'ANNPREM' || value.type === 'Flat Dollar') &&
      !isNaN(parseFloat(value.value))
    );
  }

  isDateType(value: any, type): boolean {
    return value.description.indexOf('Date') !== -1;
  }

  isPremuimDelay(value: any, type): boolean {
    return value.description === 'Premium Delay';
  }

  isEligibleSubCount(value: any, type): boolean {
    return value.description === 'Eligible Sub Count';
  }

  isDecimalType(value, type): boolean {
    let processedValue = this.getValue(value, type);
    return (
      !isNaN(processedValue) &&
      !this.isMonthlyPremium(value, type) &&
      !this.isDollarType(value, type) &&
      !this.isPercent(value, type) &&
      !this.isCommissionPercent(value, type) &&
      processedValue % 1 != 0
    );
  }

  isInComplaince(value, type): boolean {
    return value.description === 'In Compliance?';
  }

  getComplainceValue(data, type) {
    return data.value ? 'Yes' : 'No';
  }

  isOtherType(value: any, type): boolean {
    return (
      !this.isMonthlyPremium(value, type) &&
      !this.isPercent(value, type) &&
      !this.isDollarType(value, type) &&
      !this.isDecimalType(value, type) &&
      !this.isDateType(value, type) &&
      !this.isPremuimDelay(value, type) &&
      !this.isCommissionPercent(value, type) &&
      !this.isInComplaince(value, type)
    );
  }

  getValue(value, type) {
    return type == 'R' ? this.getValueWithRiskScore(value) : this.getValueWithoutRiskScore(value);
  }

   getDecimalValue(value, type) {
    const response =  type == 'R' ? this.getValueWithRiskScore(value) : this.getValueWithoutRiskScore(value);
    const numValue = Number(response);  
    
    return isNaN(numValue) ? 0 : numValue;
  }

  getValueWithRiskScore(value) {
    /* ALGR-128683 - Updated the logic to check for CURV risk score enablement while displaying N/A for age/sex factor value */
    return (value.description.includes('Age/Sex') && this.isOldRiskScoreVersion && !this.enableCurvChanges) ||
      (value.description.includes('Industry') && new Date(this.insertedTimestamp) < new Date(this.commonService.getInsertedTimestamp()))
      ? this.hasWithoutRiskScoreValues || this.hasRiskScore
        ? 'N/A'
        : value.value
      : value.value;
  }

  getValueWithoutRiskScore(value) {
    return value.description.includes('Risk Score') && value.description.indexOf('Risk Score') == 0
      ? 'N/A'
      : value['valueWithoutRiskScore']
        ? value['valueWithoutRiskScore']
        : value.value;
  }

  getAbfComponentHeaderValue(type) {
    if (this.planData && this.planData.factors.abfFactors.abfComponents.EXPADJUSTED && !this.header['adjExpAbfComponent']) {
      this.header['adjExpAbfComponent'] = 'Exp Adj ABF Components';
    }
    return this.header[type];
  }
  /* ALGR-96591- As part of this task rounded commision value(graded commssion) */
  roundValueToTwoDecimals(value) {
    return (Math.round(value * 100) / 100).toFixed(2);
  }
}
