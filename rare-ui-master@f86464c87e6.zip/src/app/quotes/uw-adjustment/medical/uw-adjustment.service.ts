import { formatPercent, formatCurrency, getCurrencySymbol } from '@angular/common';
import { inject, Injectable, LOCALE_ID } from '@angular/core';
import { Subject } from 'rxjs';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { StringUtils } from 'src/app/shared/utils/string-utils';

@Injectable({ providedIn: 'root' })
export class UnderwriterAdjustmentService {
  
  PRODUCT_SEPARATOR = '##';
  ROUND_OF_6 = 6;
  changeRateList: any[] = [];
  featutePlanSupressSubject = new Subject<{ plans: any, plan?: any }>();
  MONTHS_IN_A_YEAR = 12;
  HUNDRED = 100;

  readonly locale = inject<string>(LOCALE_ID);

  clearRateList() {
    this.changeRateList = [];
  }
  getAbfAdjustments(plan: any, quoteDetail: any): any {
    let applyAdjustment;
    let componentAdjustment;
    let rblAdjustment;
    let rblPercentAdjustment;
    let abfFactors;
    let factors;
    let acsFactor = 1;
    let initialAbfFactors: any = {};
    let unAdjustedAbfFactors: any = {};
    let adjustedFinalPMPM = 0;
    let adjustedFinalClaimCost = 0;
    let adjustedAbfPMPM = 0;
    let adjustments: any = {};
    let adjDiffToTarget = 0;
    let sslAdj = 0;
    let aslAdj = 0;
    let adjSslAdj = 0;
    let adjAslAdj = 0;

    if (quoteDetail) {
      if (quoteDetail.uwAdjustment) adjustments = quoteDetail.uwAdjustment;
    }

    if (!applyAdjustment) {
      applyAdjustment = adjustments.quoteAdjustments;
    }
    plan.adjustment = applyAdjustment;

    if (adjustments.componentAdjustments) componentAdjustment = adjustments.componentAdjustments;

    if (adjustments.rebalanceAdjustments) {
      rblAdjustment = adjustments.rebalanceAdjustments;
    }

    if (adjustments.percentageComponent) rblPercentAdjustment = adjustments.percentageComponent;

    factors = plan.factors;
    if (factors && factors.acsFactor) {
      acsFactor = factors.acsFactor;
    }
    abfFactors = factors.abfFactors;
    if (abfFactors && abfFactors.abfComponents) {
      initialAbfFactors = abfFactors.abfComponents.INITIAL;
      unAdjustedAbfFactors = abfFactors.abfComponents.UNADJUSTED;
    }
    let adjustmentFactor = this.getAdjustmentFactor(plan.adjustment);
    if (adjustments?.abfRateActionAdjustment) {
      let whSaving = adjustments.abfRateActionAdjustment['renewalWHAPercent'];
      if (!StringUtils.isUndefined(whSaving)) {
        whSaving = whSaving / 100;
        adjustmentFactor *=(1 - whSaving);
        if (whSaving !== 0) {
          abfFactors['WHSAdj'] = 1 - whSaving;
        } else {
          delete abfFactors['WHSAdj'];
        }
      }
    }
    if (abfFactors != undefined) {
      adjustedAbfPMPM += abfFactors.abfGrossPMPM;
      adjustedFinalPMPM += abfFactors.abfMonthlyPMPM;
      adjustedFinalClaimCost += abfFactors.adjustedClaimsCost;
      adjustedAbfPMPM *= adjustmentFactor;
      adjustedFinalPMPM *= adjustmentFactor;
      adjustedFinalClaimCost *= adjustmentFactor;

      ({ adjDiffToTarget, sslAdj, aslAdj, adjSslAdj, adjAslAdj } = this.calculateQtLvlAdjustment(
        abfFactors,
        initialAbfFactors,
        adjustmentFactor,
        adjDiffToTarget,
        adjustedAbfPMPM,
        sslAdj,
        aslAdj,
        adjSslAdj,
        adjAslAdj
      ));

      abfFactors['adjAsoAdminFee'] = this.roundedValue(abfFactors.adjAsoAdminFee);
      abfFactors['adjSslPremium'] = this.roundedValue(abfFactors.adjSslPremium);
      abfFactors['adjAslPremium'] = this.roundedValue(abfFactors.adjAslPremium);
      abfFactors['adjMaxPaidClaim'] = this.roundedValue(abfFactors.adjMaxPaidClaim);
      abfFactors['adjABFPremium'] = this.roundedValue(abfFactors.adjABFPremium);

      abfFactors['adjTerminalLiability'] =
        abfFactors.adjABFPremium - (abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.adjMaxPaidClaim);

      let rblDiff = this.getRblDiffValue(abfFactors, rblAdjustment, abfFactors.adjABFPremium);
      if (rblAdjustment != undefined) {
        abfFactors['rblAloAsoAdminFee'] = this.roundingValueAfterFixingDecimal(
          abfFactors.rblAdjAsoAdminFee + this.applyRblDiff(rblAdjustment.adminFactorAllocation, rblDiff)
        );
        abfFactors['rblAloSslPremium'] = this.roundingValueAfterFixingDecimal(
          abfFactors.rblAdjSslPremium + this.applyRblDiff(rblAdjustment.sslFactorAllocation, rblDiff)
        );
        abfFactors['rblAloAslPremium'] = this.roundingValueAfterFixingDecimal(
          abfFactors.rblAdjAslPremium + this.applyRblDiff(rblAdjustment.aslFactorAllocation, rblDiff)
        );
        abfFactors['rblAloMaxPaidClaim'] = this.roundingValueAfterFixingDecimal(
          abfFactors.rblAdjMaxPaidClaim + this.applyRblDiff(rblAdjustment.mcfFactorAllocation, rblDiff)
        );
        abfFactors['rblAloTerminalLiability'] = this.roundingValueAfterFixingDecimal(
          abfFactors.rblAdjTerminalLiability + this.applyRblDiff(rblAdjustment.tlFactorAllocation, rblDiff)
        );
      }
      if (this.hasRblAdjustment(rblAdjustment) && this.findFinalRblAllocation(rblAdjustment))
        abfFactors[this.findFinalRblAllocation(rblAdjustment)] = this.roundedValue(
          abfFactors['adjABFPremium'] - this.getSumofOtherComponents(abfFactors, this.findFinalRblAllocation(rblAdjustment))
        );

      abfFactors['rblAloAdjAbfPMPM'] =
        abfFactors.rblAloAsoAdminFee +
        abfFactors.rblAloSslPremium +
        abfFactors.rblAloAslPremium +
        abfFactors.rblAloMaxPaidClaim +
        abfFactors.rblAloTerminalLiability;

      if (!this.hasRblAdjustment(rblAdjustment) && this.hasRblPerAdjustment(rblPercentAdjustment)) {
        abfFactors['rblAloAsoAdminFee'] = this.roundingValueAfterFixingDecimal(
          this.applyRblPercent(abfFactors.adjABFPremium, rblPercentAdjustment, 'adminFactor')
        );
        abfFactors['rblAloSslPremium'] = this.roundingValueAfterFixingDecimal(
          this.applyRblPercent(abfFactors.adjABFPremium, rblPercentAdjustment, 'sslFactor')
        );
        abfFactors['rblAloAslPremium'] = this.roundingValueAfterFixingDecimal(
          this.applyRblPercent(abfFactors.adjABFPremium, rblPercentAdjustment, 'aslFactor')
        );
        abfFactors['rblAloMaxPaidClaim'] = this.roundingValueAfterFixingDecimal(
          this.applyRblPercent(abfFactors.adjABFPremium, rblPercentAdjustment, 'mcfFactor')
        );
        abfFactors['rblAloTerminalLiability'] = this.roundingValueAfterFixingDecimal(
          this.applyRblPercent(abfFactors.adjABFPremium, rblPercentAdjustment, 'tlFactor')
        );

        abfFactors['rblAloTerminalLiability'] =
          abfFactors.adjABFPremium - (abfFactors.rblAloAsoAdminFee + abfFactors.rblAloSslPremium + abfFactors.rblAloAslPremium + abfFactors.rblAloMaxPaidClaim);

        abfFactors['rblAloAdjAbfPMPM'] =
          abfFactors.rblAloAsoAdminFee +
          abfFactors.rblAloSslPremium +
          abfFactors.rblAloAslPremium +
          abfFactors.rblAloMaxPaidClaim +
          abfFactors.rblAloTerminalLiability;
      }

      abfFactors['finalAdjAsoAdminFee'] = this.getComponentAdjValue('asoAdmin', componentAdjustment, abfFactors.rblAloAsoAdminFee, rblAdjustment, acsFactor);
      abfFactors['finalAdjSslPremium'] = this.getComponentAdjValue('sslPremium', componentAdjustment, abfFactors.rblAloSslPremium, rblAdjustment, acsFactor);
      abfFactors['finalAdjAslPremium'] = this.getComponentAdjValue('aslPremium', componentAdjustment, abfFactors.rblAloAslPremium, rblAdjustment, acsFactor);
      abfFactors['finalAdjMaxPaidClaim'] = this.getComponentAdjValue('maxClaims', componentAdjustment, abfFactors.rblAloMaxPaidClaim, rblAdjustment, acsFactor);
      abfFactors['finalAdjTerminalLiability'] = this.getComponentAdjValue(
        'terminalLiability',
        componentAdjustment,
        abfFactors.rblAloTerminalLiability,
        rblAdjustment,
        acsFactor
      );
      abfFactors['finalAdjAbfPMPM'] = this.roundedValue(
        abfFactors.finalAdjAsoAdminFee +
          abfFactors.finalAdjSslPremium +
          abfFactors.finalAdjAslPremium +
          abfFactors.finalAdjMaxPaidClaim +
          abfFactors.finalAdjTerminalLiability
      );
      abfFactors['totalAdjustment'] = adjustmentFactor != 1 ? adjustmentFactor : 'N/A';
      let estMembers = this.getValidatedParsedValue(plan.factors.estMembers, 1);
      abfFactors['totalMonthlyPremiumAdjusted'] = this.roundedValue(abfFactors.finalAdjAbfPMPM) * estMembers;
      if (quoteDetail.factors) {
        plan = this.calculateRateInfoForPlan(quoteDetail, adjustments, abfFactors, plan);
      }
      this.validateGuardrails(plan, quoteDetail.factors?.guardRails, adjustments);
      return plan;
    }
  }

  private calculateQtLvlAdjustment(
    abfFactors: any,
    initialAbfFactors: any,
    adjustmentFactor: number,
    adjDiffToTarget: number,
    adjustedAbfPMPM: number,
    sslAdj: number,
    aslAdj: number,
    adjSslAdj: number,
    adjAslAdj: number
  ) {
    abfFactors['reCalcAsoAdminFee'] = initialAbfFactors.asoAdminFee;
    abfFactors['reCalcSslPremium'] = abfFactors.sslClaimsLoadPercentRetentionValue * adjustmentFactor + abfFactors.sslClaimsLoadNonRetentionValue;
    abfFactors['reCalcAslPremium'] = abfFactors.aslClaimsLoadPercentRetentionValue * adjustmentFactor + abfFactors.aslClaimsLoadNonRetentionValue;
    abfFactors['reCalcMaxPaidClaim'] = initialAbfFactors.maxPaidClaim * adjustmentFactor;
    abfFactors['reCalcTerminalLiability'] = initialAbfFactors.terminalLiability * adjustmentFactor;
    abfFactors['reCalcABFPremium'] =
      abfFactors.reCalcAsoAdminFee +
      abfFactors.reCalcSslPremium +
      abfFactors.reCalcAslPremium +
      abfFactors.reCalcMaxPaidClaim +
      abfFactors.reCalcTerminalLiability;
    adjDiffToTarget = adjustedAbfPMPM - abfFactors.reCalcABFPremium;
    sslAdj = abfFactors.reCalcSslPremium / (abfFactors.reCalcSslPremium + abfFactors.reCalcAslPremium);
    aslAdj = 1 - sslAdj;

    adjSslAdj = adjDiffToTarget * sslAdj;
    adjAslAdj = adjDiffToTarget * aslAdj;

    abfFactors['adjAsoAdminFee'] = abfFactors.reCalcAsoAdminFee;
    abfFactors['adjSslPremium'] = abfFactors.reCalcSslPremium + adjSslAdj;
    abfFactors['adjAslPremium'] = abfFactors.reCalcAslPremium + adjAslAdj;
    abfFactors['adjMaxPaidClaim'] = abfFactors.reCalcMaxPaidClaim;
    abfFactors['adjTerminalLiability'] = abfFactors.reCalcTerminalLiability;
    abfFactors['adjABFPremium'] =
      abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.adjMaxPaidClaim + abfFactors.adjTerminalLiability;
    return { adjDiffToTarget, sslAdj, aslAdj, adjSslAdj, adjAslAdj };
  }

  applyRblDiff(rblAdjustment, rblDiff) {
    return (rblAdjustment ? +rblAdjustment : 0) * rblDiff || 0;
  }

  applyRblPercent(rblRates, rblPercentAdjustment, factor) {
    return (rblRates ? +rblRates : 0) * rblPercentAdjustment[factor] || 0;
  }

  getRblDiffValue(abfFactors, rblAdjustment, adjABFPremium) {
    if (rblAdjustment != undefined) {
      abfFactors['rblAdjAsoAdminFee'] = abfFactors.adjAsoAdminFee * (rblAdjustment.adminFactorAdj ? rblAdjustment.adminFactorAdj : 1);
      abfFactors['rblAdjSslPremium'] = abfFactors.adjSslPremium * (rblAdjustment.sslFactorAdj ? rblAdjustment.sslFactorAdj : 1);
      abfFactors['rblAdjAslPremium'] = abfFactors.adjAslPremium * (rblAdjustment.aslFactorAdj ? rblAdjustment.aslFactorAdj : 1);
      abfFactors['rblAdjMaxPaidClaim'] = abfFactors.adjMaxPaidClaim * (rblAdjustment.mcfFactorAdj ? rblAdjustment.mcfFactorAdj : 1);
      abfFactors['rblAdjTerminalLiability'] = abfFactors.adjTerminalLiability * (rblAdjustment.tlFactorAdj ? rblAdjustment.tlFactorAdj : 1);
      abfFactors['rblAdjABFPremium'] =
        abfFactors.rblAdjAsoAdminFee +
        abfFactors.rblAdjSslPremium +
        abfFactors.rblAdjAslPremium +
        abfFactors.rblAdjMaxPaidClaim +
        abfFactors.rblAdjTerminalLiability;
      return adjABFPremium - abfFactors.rblAdjABFPremium;
    }
  }

  getAbfRateInfo(plan, multiplicativeFactor, abfFactors) {
    let rateInfo = plan.rateInfo;
    if (!rateInfo) {
      rateInfo = {};
    }
    // Totals
    if (multiplicativeFactor) {
      rateInfo['single'] = this.roundedValue(abfFactors.finalAdjAbfPMPM * (multiplicativeFactor.eeFactor || 0));
      rateInfo['eeOne'] = this.roundedValue(abfFactors.finalAdjAbfPMPM * (multiplicativeFactor.e1Factor || 0));
      rateInfo['eeChild'] = this.roundedValue(abfFactors.finalAdjAbfPMPM * (multiplicativeFactor.ekFactor || 0));
      rateInfo['eeChildren'] = this.roundedValue(abfFactors.finalAdjAbfPMPM * (multiplicativeFactor.ecFactor || 0));
      rateInfo['eeSpouse'] = this.roundedValue(abfFactors.finalAdjAbfPMPM * (multiplicativeFactor.esFactor || 0));
      rateInfo['family'] = this.roundedValue(abfFactors.finalAdjAbfPMPM * (multiplicativeFactor.efFactor || 0));

      this.getComponentRates('asoFee', rateInfo, multiplicativeFactor, abfFactors.finalAdjAsoAdminFee);
      this.getComponentRates('sslPremium', rateInfo, multiplicativeFactor, abfFactors.finalAdjSslPremium);
      this.getComponentRates('aslPremium', rateInfo, multiplicativeFactor, abfFactors.finalAdjAslPremium);
      this.getComponentRates('maxPaidClaimsFund', rateInfo, multiplicativeFactor, abfFactors.finalAdjMaxPaidClaim);
      //Terminal Liability Calculation
      rateInfo['terminalLiabilityFund']['single'] =
        rateInfo['single'] -
        (rateInfo['asoFee']['single'] + rateInfo['sslPremium']['single'] + rateInfo['aslPremium']['single'] + rateInfo['maxPaidClaimsFund']['single']);
      rateInfo['terminalLiabilityFund']['eeOne'] =
        rateInfo['eeOne'] -
        (rateInfo['asoFee']['eeOne'] + rateInfo['sslPremium']['eeOne'] + rateInfo['aslPremium']['eeOne'] + rateInfo['maxPaidClaimsFund']['eeOne']);
      rateInfo['terminalLiabilityFund']['eeChild'] =
        rateInfo['eeChild'] -
        (rateInfo['asoFee']['eeChild'] + rateInfo['sslPremium']['eeChild'] + rateInfo['aslPremium']['eeChild'] + rateInfo['maxPaidClaimsFund']['eeChild']);
      rateInfo['terminalLiabilityFund']['eeChildren'] =
        rateInfo['eeChildren'] -
        (rateInfo['asoFee']['eeChildren'] +
          rateInfo['sslPremium']['eeChildren'] +
          rateInfo['aslPremium']['eeChildren'] +
          rateInfo['maxPaidClaimsFund']['eeChildren']);
      rateInfo['terminalLiabilityFund']['eeSpouse'] =
        rateInfo['eeSpouse'] -
        (rateInfo['asoFee']['eeSpouse'] + rateInfo['sslPremium']['eeSpouse'] + rateInfo['aslPremium']['eeSpouse'] + rateInfo['maxPaidClaimsFund']['eeSpouse']);
      rateInfo['terminalLiabilityFund']['family'] =
        rateInfo['family'] -
        (rateInfo['asoFee']['family'] + rateInfo['sslPremium']['family'] + rateInfo['aslPremium']['family'] + rateInfo['maxPaidClaimsFund']['family']);
    }
    return rateInfo;
  }

  getRetentionAssessments(plan) {
    if (plan.factors && plan.factors.rtnStateAssessments && Object.keys(plan.factors.rtnStateAssessments).length > 0) {
      let retentionAssessmentPercent = 0;
      retentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['domesticRtntnPercent'], 0);
      retentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['nonDomesticRtntnPercent'], 0);
      retentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['domesticNonRtntnPercent'], 0);
      retentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['nonDomesticNonRtntnPercent'], 0);

      let retentionAssessmentPMPM = 0;
      retentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['domesticRtntnPMPM'], 0);
      retentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['nonDomesticRtntnPMPM'], 0);
      retentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['domesticNonRtntnPMPM'], 0);
      retentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.rtnStateAssessments['nonDomesticNonRtntnPMPM'], 0);

      if (retentionAssessmentPercent) plan.factors['retentionAssessmentPercent'] = retentionAssessmentPercent;

      if (retentionAssessmentPMPM) plan.factors['retentionAssessmentPMPM'] = retentionAssessmentPMPM;
    }
  }

  getNonRetentionAssessments(plan) {
    if (plan.factors && plan.factors.nonRtnStateAssessments && Object.keys(plan.factors.nonRtnStateAssessments).length > 0) {
      let nonRetentionAssessmentPercent = 0;
      nonRetentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['domesticRtntnPercent'], 0);
      nonRetentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['nonDomesticRtntnPercent'], 0);
      nonRetentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['domesticNonRtntnPercent'], 0);
      nonRetentionAssessmentPercent += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['nonDomesticNonRtntnPercent'], 0);

      let nonRetentionAssessmentPMPM = 0;
      nonRetentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['domesticRtntnPMPM'], 0);
      nonRetentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['nonDomesticRtntnPMPM'], 0);
      nonRetentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['domesticNonRtntnPMPM'], 0);
      nonRetentionAssessmentPMPM += this.getValidatedParsedValue(plan.factors.nonRtnStateAssessments['nonDomesticNonRtntnPMPM'], 0);

      if (nonRetentionAssessmentPercent) plan.factors['nonRetentionAssessmentPercent'] = nonRetentionAssessmentPercent;

      if (nonRetentionAssessmentPMPM) plan.factors['nonRetentionAssessmentPMPM'] = nonRetentionAssessmentPMPM;
    }
  }

  getTotalAdjComponentRates(rateInfo, key) {
    return this.roundedValue(
      rateInfo.asoFee[key] + rateInfo.sslPremium[key] + rateInfo.aslPremium[key] + rateInfo.terminalLiabilityFund[key] + rateInfo.maxPaidClaimsFund[key]
    );
  }

  getLengthofDecimals(str: number) {
    if (str.toString().indexOf('.') !== -1) {
      return str.toString().split('.')[1].length || 0;
    }
    return 0;
  }

  multiply(a: number, b: number) {
    let fixedDecLength = this.getLengthofDecimals(a) + this.getLengthofDecimals(b);
    return Number((a * b).toFixed(fixedDecLength));
  }

  getComponentRates(key, rateInfo, multiplicativeFactor, finalAdjFee) {
    rateInfo[key]['single'] = this.roundedValue(this.multiply(finalAdjFee, multiplicativeFactor.eeFactor || 0));
    rateInfo[key]['eeOne'] = this.roundedValue(this.multiply(finalAdjFee, multiplicativeFactor.e1Factor || 0));
    rateInfo[key]['eeChild'] = this.roundedValue(this.multiply(finalAdjFee, multiplicativeFactor.ekFactor || 0));
    rateInfo[key]['eeChildren'] = this.roundedValue(this.multiply(finalAdjFee, multiplicativeFactor.ecFactor || 0));
    rateInfo[key]['eeSpouse'] = this.roundedValue(this.multiply(finalAdjFee, multiplicativeFactor.esFactor || 0));
    rateInfo[key]['family'] = this.roundedValue(this.multiply(finalAdjFee, multiplicativeFactor.efFactor || 0));
  }

  getComponentAdjValue(key, componentAdjustment, valueBeforeAdj, rblAdjustment, acsFactor) {
    let keyType = key + 'Type';
    if (componentAdjustment && componentAdjustment[keyType] === 'PMPM' && componentAdjustment[key])
      return this.roundedValue((valueBeforeAdj += +componentAdjustment[key]));
    else if (componentAdjustment && componentAdjustment[keyType] === 'Percent' && componentAdjustment[key])
      return this.roundingValueAfterFixingDecimal((valueBeforeAdj *= +componentAdjustment[key]));
    else if (componentAdjustment && componentAdjustment[keyType] === 'PCPM' && componentAdjustment[key])
      return this.roundedValue((valueBeforeAdj += +(componentAdjustment[key] / acsFactor)));

    return this.hasRblAdjustment(rblAdjustment) ? valueBeforeAdj : this.roundedValue(valueBeforeAdj);
  }

  hasRblAdjustment(rblAdjustment) {
    let flag = false;
    if (rblAdjustment && Object.keys(rblAdjustment).length)
      Object.keys(rblAdjustment).forEach((Adj) => {
        if (rblAdjustment[Adj] && Adj != 'rebalanceAdjustmentType' && Adj != 'percentageComponent') flag = true;
      });
    return flag;
  }

  hasRblPerAdjustment(rblPercentAdjustment) {
    let flag = false;
    if (rblPercentAdjustment && Object.keys(rblPercentAdjustment).length)
      Object.keys(rblPercentAdjustment).forEach((Adj) => {
        if (rblPercentAdjustment[Adj]) flag = true;
      });
    return flag;
  }

  findFinalRblAllocation(rblAdjustment) {
    let key;
    Object.keys(this.getRblAloKeys()).forEach((Adj) => {
      if (rblAdjustment[Adj]) key = Adj;
    });
    return key ? this.getRblComponentKey(key) : 'rblAloTerminalLiability';
  }

  getRblComponentKey(type) {
    return this.getRblAloKeys()[type];
  }

  getRblAloKeys() {
    return {
      adminFactorAllocation: 'rblAloAsoAdminFee',
      sslFactorAllocation: 'rblAloSslPremium',
      aslFactorAllocation: 'rblAloAslPremium',
      mcfFactorAllocation: 'rblAloMaxPaidClaim',
      tlFactorAllocation: 'rblAloTerminalLiability'
    };
  }

  getSumofOtherComponents(abfFactors, exceptComponent) {
    let sum = 0;
    Object.keys(this.getRblAloKeys()).forEach((component) => {
      if (this.getRblAloKeys()[component] != exceptComponent) sum = sum + abfFactors[this.getRblAloKeys()[component]];
    });
    return sum;
  }

  getPlanLevelAdjustments(plan: any, quoteDetail: any): any {
    let applyAdjustment;
    let riskScore: any = 1;
    let adjustments: any = {};
    if (quoteDetail) {
      if (quoteDetail.uwAdjustment) adjustments = quoteDetail.uwAdjustment;
      if (quoteDetail.riskScore) riskScore = quoteDetail.riskScore;
      if (quoteDetail.fundingType && quoteDetail.fundingType === 'ABF') {
        // TODO: Keeping this until we have the ABF Adjustment implementation, as we don't want to do the FI
        // Calculation for the ABF
        return plan;
      }
    }

    if (adjustments.productAdjustments) {
      adjustments.productAdjustments.forEach((adjustment) => {
        let productCategoryCode: string = '';
        let productCode: string = '';
        let hasPMTIndicator: boolean = false;
        if (plan.planBenefits && plan.planBenefits.productCategoryCode) {
          productCategoryCode = plan.planBenefits.productCategoryCode;
          hasPMTIndicator = true;
        }
        if (!productCategoryCode) {
          productCategoryCode = plan.networkType;
        }
        if (hasPMTIndicator) {
          productCode = plan.planBenefits.productCode ? plan.planBenefits.productCode : '';
        } else {
          if (plan['CDHPIndicator']) {
            productCode = plan['CDHPIndicator'];
          } else if (plan['cdhpindicator']) {
            productCode = plan['cdhpindicator'];
          }
        }
        if (adjustment.networkName == plan.networkName && adjustment.networkType == productCategoryCode && adjustment['CDHPIndicator'] == productCode) {
          applyAdjustment = adjustment;
        }
      });
    }
    if (!applyAdjustment) {
      applyAdjustment = adjustments.quoteAdjustments;
    }
    plan.adjustment = applyAdjustment;

    this.getRetentionAssessments(plan);
    this.getNonRetentionAssessments(plan);

    if (plan && plan.factors) {
      if (riskScore && !isNaN(riskScore) && riskScore != -99999) {
        plan.factors['riskScore'] = parseFloat(riskScore);
      } else {
        plan.factors['riskScore'] = 'Not Available';
      }
    }

    let outputTier = adjustments && adjustments.outputTier ? adjustments.outputTier : quoteDetail.medicalOutputTier;
    let tierRatioCalculationType = adjustments && adjustments.tierRatioCalculationType ? adjustments.tierRatioCalculationType : 'Standard';
    if (quoteDetail.factors) {
      let receivedRiskScoreVersion = quoteDetail['receivedRiskScoreVersion'] ? quoteDetail['receivedRiskScoreVersion'] : '';
      plan.rateInfo = this.calculateTieredRates(plan, quoteDetail.factors, outputTier, tierRatioCalculationType, receivedRiskScoreVersion, quoteDetail?.riskScoreType);
      return plan;
    }
  }
  calculateMedicalDivisor(factors: any): number {
    let value = 1;

    value -= this.getValidatedParsedValue(factors.statePremiumTaxesFactor, 0);
    value -= this.getValidatedParsedValue(factors.acaInsurerFeeFactor, 0);
    value -= this.getValidatedParsedValue(factors.premiumDelayChargeFactor, 0);
    value -= this.getValidatedParsedValue(factors.retentionAssessmentPercent, 0);

    if (
      factors.generalAgentNewBusinessCommission &&
      factors.generalAgentNewBusinessCommission.retntnTypeCd &&
      factors.generalAgentNewBusinessCommission.retntnTypeCd.toUpperCase() == 'PERCENT'
    ) {
      value -= this.getValidatedParsedValue(factors.generalAgentNewBusinessCommission.retntnAmt, 0);
    }

    if (factors.medicalFactors) {
      if (factors.medicalFactors.retentionFactors && Array.isArray(factors.medicalFactors.retentionFactors)) {
        factors.medicalFactors.retentionFactors.forEach((retention) => {
          if (retention.retntnTypeCd.toUpperCase() == 'PERCENT') {
            value -= this.getValidatedParsedValue(retention.retntnAmt, 0);
          }
        });
      }
    }

    return value;
  }

  calculateMedicalMultiplier(factors: any): number {
    let value = 1;
    value *= this.getValidatedParsedValue(factors.specialtyDiscountAdjFactor, 1);
    if (factors && !factors.applyParticipationAdjToClaimsCost) {
      value *= this.getValidatedParsedValue(factors.participationAdjustment, 1);
    }
    value *= this.getValidatedParsedValue(factors.medNbDscntFctr, 1);
    return value;
  }

  calculateAddOnCostAdjustment(factors: any, addOnCost: any): number {
    let adjustedCost = 0;
    if (!isNaN(addOnCost) && addOnCost * 1 != 0) {
      if (
        factors.generalAgentNewBusinessCommission &&
        factors.generalAgentNewBusinessCommission.retntnTypeCd &&
        factors.generalAgentNewBusinessCommission.retntnTypeCd.toUpperCase() == 'PMPM'
      ) {
        addOnCost += this.getValidatedParsedValue(factors.generalAgentNewBusinessCommission.retntnAmt, 0);
      }

      if (factors.medicalFactors) {
        if (factors.medicalFactors.retentionFactors && Array.isArray(factors.medicalFactors.retentionFactors)) {
          factors.medicalFactors.retentionFactors.forEach((retention) => {
            if (retention.retntnTypeCd.toUpperCase() !== 'PERCENT') {
              addOnCost += this.getValidatedParsedValue(retention.retntnAmt, 0);
            }
          });
        }
        if (factors.medicalFactors.adminAdjustment) {
          if (factors.medicalFactors.adminAdjustment.retntnTypeCd.toUpperCase() == 'PMPM') {
            addOnCost += this.getValidatedParsedValue(factors.medicalFactors.adminAdjustment.retntnAmt, 0);
          }
        }
      }
      addOnCost += this.getValidatedParsedValue(factors.retentionAssessmentPMPM, 0);

      let divisor = this.calculateMedicalDivisor(factors);
      let multiplier = this.calculateMedicalMultiplier(factors);
      if (divisor != 0) {
        adjustedCost = (addOnCost / divisor) * multiplier;
      }
    }
    return adjustedCost;
  }

  calculateAdjustedFinalPMPM(factors: any, adjustment: any, receivedRiskScoreVersion: string, riskScoreType?: string): number {
    let estMembers = this.getValidatedParsedValue(factors.estMembers, 1);
    let medicalClaimCost = this.getValidatedParsedValue(factors.medClaimCost, 0);
    let rxPMPM = this.getValidatedParsedValue(factors.rxPMPM, 0);
    let medicalClaimCostWithoutRiskScore = this.getValidatedParsedValue(factors.medClaimCostWithoutRiskscore, 0);
    let rxPMPMWithoutRiskscore = this.getValidatedParsedValue(factors.rxPMPMWithoutRiskscore, 0);
    let adjustedFinalPMPM = 0;
    let adjustedFinalPMPMWithoutRiskScore = 0;
    let adjustmentFactor = this.getAdjustmentFactor(adjustment);
    let adjustmentCostUIValue: any = 'N/A';

    let hottClaims = this.getValidatedParsedValue(this.getMedClmGrpmRateAdjFctr('Hott Claims', factors.lstMedClmGrpmRateAdjFctr), 0);
    let mhsaAmount = this.getValidatedParsedValue(this.getMedClmGrpmRateAdjFctr('MHSA Amount', factors.lstMedClmGrpmRateAdjFctr), 0);
    let embeddedVision = this.getValidatedParsedValue(this.getMedClmGrpmRateAdjFctr('Embedded Vision', factors.lstMedClmGrpmRateAdjFctr), 0);

    medicalClaimCost += hottClaims;
    medicalClaimCost += mhsaAmount;
    medicalClaimCost += embeddedVision;

    medicalClaimCostWithoutRiskScore += hottClaims;
    medicalClaimCostWithoutRiskScore += mhsaAmount;
    medicalClaimCostWithoutRiskScore += embeddedVision;

    if (adjustment && this.getValidatedParsedValue(adjustment.addOnCost, 0)) {
      adjustmentCostUIValue = parseFloat(adjustment.addOnCost);
      medicalClaimCost += adjustmentCostUIValue;
      medicalClaimCostWithoutRiskScore += adjustmentCostUIValue;
      medicalClaimCost = this.calculateAddOnCostAdjustment(factors, medicalClaimCost);
      medicalClaimCostWithoutRiskScore = this.calculateAddOnCostAdjustment(factors, medicalClaimCostWithoutRiskScore);
    } else {
      medicalClaimCost = this.getValidatedParsedValue(factors.medPMPM, 0);
      medicalClaimCostWithoutRiskScore = this.getValidatedParsedValue(factors.medPMPMWithoutRiskscore, 0);
    }
    adjustedFinalPMPM = medicalClaimCost + rxPMPM;
    adjustedFinalPMPMWithoutRiskScore = medicalClaimCostWithoutRiskScore + rxPMPMWithoutRiskscore;

    if (factors.chamberOfCommerce) {
      adjustedFinalPMPM *= factors.chamberOfCommerce;
      adjustedFinalPMPMWithoutRiskScore *= factors.chamberOfCommerce;
    }

    if (!StringUtils.isEmpty(riskScoreType) && StringUtils.isNotEqualIgnoreCase(riskScoreType,CommonConstants.CURV) && factors.riskScore && factors.riskScore != 'Not Available' && factors.riskScore != -99999 && this.isOldRiskScoreVersion(receivedRiskScoreVersion)) {
      adjustedFinalPMPM *= factors.riskScore;
    }

    adjustedFinalPMPM *= adjustmentFactor;
    adjustedFinalPMPMWithoutRiskScore *= adjustmentFactor;

    factors['totalAdjustment'] = adjustmentFactor != 1 ? adjustmentFactor : 'N/A';
    factors['addOnCost'] = adjustmentCostUIValue;
    factors['finalGrossPMPMAdjusted'] = adjustedFinalPMPM;
    factors['finalGrossPMPMAdjustedWithoutRiskscore'] = adjustedFinalPMPMWithoutRiskScore;
    factors['totalMonthlyPremiumAdjusted'] = this.roundedValue(adjustedFinalPMPM) * estMembers;
    factors['totalMonthlyPremiumAdjustedWithoutRiskscore'] = this.roundedValue(adjustedFinalPMPMWithoutRiskScore) * estMembers;

    return adjustedFinalPMPM;
  }

  getMedClmGrpmRateAdjFctr(adjNm: any, lstMedClmGrpmRateAdjFctr: any) {
    if (lstMedClmGrpmRateAdjFctr) {
      var medClmGrpmRateAdjFctr = lstMedClmGrpmRateAdjFctr.filter(
        (medClmGrpmRateAdjFctr) => medClmGrpmRateAdjFctr.adjNm === adjNm && medClmGrpmRateAdjFctr.applyLvl == 'Claims'
      );
      if (medClmGrpmRateAdjFctr.length > 0) {
        return medClmGrpmRateAdjFctr[0].adjVal;
      }
    }
  }

  calculateTieredRates(plan: any, factors: any, reqTier: number, tierRatioType: string, receivedRiskScoreVersion: string, riskScoreType?: string): any {
    let rateInfo = plan.rateInfo;
    if (plan && plan.factors && plan.factors.grossPMPM) {
      let adjustedFinalPMPM = this.roundedValue(this.calculateAdjustedFinalPMPM(plan.factors, plan.adjustment, receivedRiskScoreVersion, riskScoreType));
      let tierFactors = this.getTierMultiplier(factors, reqTier, tierRatioType);
      let multiplicativeFactor = tierFactors.tierFactor;
      plan.factors['adjTierFactor'] = tierFactors.adjTierFactor;
      if (!rateInfo) {
        rateInfo = {};
      }
      if (multiplicativeFactor) {
        rateInfo['single'] = this.roundedValue(adjustedFinalPMPM * (multiplicativeFactor.eeFactor || 0));
        rateInfo['eeOne'] = this.roundedValue(adjustedFinalPMPM * (multiplicativeFactor.e1Factor || 0));
        rateInfo['eeChild'] = this.roundedValue(adjustedFinalPMPM * (multiplicativeFactor.ekFactor || 0));
        rateInfo['eeChildren'] = this.roundedValue(adjustedFinalPMPM * (multiplicativeFactor.ecFactor || 0));
        rateInfo['eeSpouse'] = this.roundedValue(adjustedFinalPMPM * (multiplicativeFactor.esFactor || 0));
        rateInfo['family'] = this.roundedValue(adjustedFinalPMPM * (multiplicativeFactor.efFactor || 0));
      }
    }
    return rateInfo;
  }

  roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }

  roundingValueAfterFixingDecimal(value: number): number {
    return Math.round(+value.toFixed(10) * 100) / 100;
  }

  roundHalfUpTwoDecimals(num){
    // Multiply by 100 to shift the decimal point two places to the right
    let scaledNum = num * 100;
    // Check if the fractional part is exactly 0.5
    if (this.roundValueToFourDecimals(Math.abs(scaledNum % 1)) >= 0.5) {
      // If it's half and more, round up using Math.ceil
      return Math.ceil(scaledNum) / 100;
    } else {
      // Otherwise, use standard Math.round
      return Math.round(scaledNum) / 100;
    }
}

  roundHalfDownTwoDecimals(num: number): number {
    // Multiply by 100 to shift the decimal point two places to the right
    let scaledNum = num * 100;
    // Check if the fractional part is exactly 0.5
    if (this.roundValueToFourDecimals(Math.abs(scaledNum % 1)) == 0.50) {
      // If it's half, round down using Math.floor
      return Math.floor(scaledNum) / 100;
    } else {
      // Otherwise, use standard Math.round
      return Math.round(scaledNum) / 100;
    }
  }

  getTierMultiplier(factors: any, reqTier: number, tierRatioType: string) {
    if (tierRatioType == 'Current' && factors.currentRateOutputTierFactor && factors.currentRateOutputTierFactor[reqTier + '-tier']) {
      return {
        tierFactor: factors.currentRateOutputTierFactor[reqTier + '-tier'],
        adjTierFactor: factors.currentRateTierFactorMultiplier[reqTier + '-tier']
      };
    } else if (tierRatioType == 'Custom' && factors.customRateOutputTierFactor && factors.customRateOutputTierFactor[reqTier + '-tier']) {
      return {
        tierFactor: factors.customRateOutputTierFactor[reqTier + '-tier'],
        adjTierFactor: factors.customRateTierFactorMultiplier[reqTier + '-tier']
      };
    }
    return {
      tierFactor: factors?.outputTierFactor?.[reqTier + '-tier'] ?? null,
      adjTierFactor: factors?.tierFactorMultiplier?.[reqTier + '-tier'] ?? null
    };
  }
  callRateActionForBulk(rateActionPercent, currentPlanTotalRates, expAdjTotalRates, expAdjFactor, medicalAlternateTier, fundingType, mpc) {
    let tierMonthlyPremium = expAdjTotalRates?.tierWiseManualMonthlyTotals?.[medicalAlternateTier + '-tier']?.tierTotals?.monthlyPremium;
    let calulatedExpAdj;
    if (StringUtils.isEqual(fundingType, CommonConstants.ABF)) {
      calulatedExpAdj = this.calculateRateActionFactor(
        rateActionPercent,
        currentPlanTotalRates,
        mpc && mpc?.quoteMonthlyGrandTotal ? mpc?.quoteMonthlyGrandTotal : expAdjTotalRates['experienceFactors']['expComponentTotal']['totalPremium'],
        expAdjFactor
      );
    } else {
      if (!StringUtils.isEmpty(tierMonthlyPremium)) {
        calulatedExpAdj = this.calculateRateActionFactor(rateActionPercent, currentPlanTotalRates, tierMonthlyPremium, 1);
      } else {
        calulatedExpAdj = this.calculateRateActionFactor(
          rateActionPercent,
          currentPlanTotalRates,
          expAdjTotalRates['experienceFactors']['expComponentTotal']['totalPremium'],
          expAdjFactor
        );
      }
    }
    return calulatedExpAdj;
  }
  getAdjustmentFactor(adjustment: any) {
    let value = 1;
    if (adjustment != undefined) {
      value *= this.getValidatedParsedValue(adjustment.uwAdjustmentFactor, 1);
      value *= this.getValidatedParsedValue(adjustment.employerRiskFactor, 1);
      value *= this.getValidatedParsedValue(adjustment.salesAdjustmentFactor, 1);
      value *= this.getValidatedParsedValue(adjustment.wholeHealthAdjustmentFactor, 1);
    }
    return value;
  }

  getValidatedParsedValue(value, defaultValue) {
    return value && !isNaN(value) ? parseFloat(value) : defaultValue;
  }

  getValidatedParsedValueAllowZero(value, defaultValue) {
    return (value !== null && value !== undefined && value !== '' && !isNaN(value)) ? parseFloat(value) : defaultValue;
  }

  hasDifferentCustomTierRatio(updatedCustomTierRatio: any, initialCustomTierRatio): boolean {
    let objKeys: string[] = [];
    if (updatedCustomTierRatio && !initialCustomTierRatio) {
      return true;
    }
    objKeys = updatedCustomTierRatio ? objKeys.concat(Object.keys(updatedCustomTierRatio)) : objKeys;
    objKeys = initialCustomTierRatio ? objKeys.concat(Object.keys(initialCustomTierRatio)) : objKeys;

    let uniqueKeys = [...new Set(objKeys)];
    let returnValue = false;
    uniqueKeys.forEach((key) => {
      returnValue = returnValue || (updatedCustomTierRatio && updatedCustomTierRatio[key]) != (initialCustomTierRatio && initialCustomTierRatio[key]);
    });
    return returnValue;
  }

  calculateCustomTierRatioFactor(customTierRatio: any, tierLives: any, acsFactor: any): any {
    let weightedAverage: number = this.calculateWeightedAverage(customTierRatio, tierLives);
    let factorMultiplier: number = parseFloat((acsFactor / weightedAverage).toFixed(this.ROUND_OF_6));
    let tierFactor: any = this.calculateTierMultiplier(customTierRatio, factorMultiplier);

    return { tierFactor, factorMultiplier };
  }

  calculateWeightedAverage(tierRatio: any, lives: any): number {
    let runningSum: number = 0;
    let totalLives: number = 0;

    Object.keys(tierRatio).forEach((key) => {
      let keyPrefix = key.substr(0, 2);
      let fctrPrefix = keyPrefix + 'Factor';
      let censusPrefix = keyPrefix + 'Count';
      runningSum += tierRatio[fctrPrefix] ? tierRatio[fctrPrefix] * (lives[censusPrefix] ? lives[censusPrefix] : 0) : 0;
      totalLives += lives[censusPrefix] ? lives[censusPrefix] * 1 : 0;
    });

    return parseFloat((runningSum / (totalLives ? totalLives : 1)).toFixed(this.ROUND_OF_6));
  }

  calculateTierMultiplier(tierRatio: any, factorMultiplier: number): any {
    let rateFactor = {};
    Object.keys(tierRatio).forEach((key) => {
      rateFactor[key] = tierRatio[key] * 1 * factorMultiplier;
    });
    return rateFactor;
  }

  roundOffValue(value) {
    return Math.round(+value.toFixed(2) * 100) / 100;
  }

  validateCompliance(plan: any, guardrail, failedGuardRails, adjustment: any) {
    let abfFactors = plan.factors.abfFactors;
    if (abfFactors && abfFactors.cmplncChk) {
      let maxPaidClaim = abfFactors['finalAdjMaxPaidClaim'];
      let terminalLiability = abfFactors['finalAdjTerminalLiability'];
      let cmplncLimit = abfFactors.cmplncChk.cmplncLimit;
      if (abfFactors.cmplncChk.cmplncType == 'PEPY') {
        cmplncLimit = this.roundOffValue(cmplncLimit / plan.factors.acsFactor);
      }
      let value: number;
      if (abfFactors.cmplncChk.cmplncType == 'PEPY' || abfFactors.cmplncChk.cmplncType == 'PMPY') {
        cmplncLimit = this.roundOffValue(cmplncLimit / 12);
        let claimsPlusLiability = maxPaidClaim + terminalLiability;
        value = claimsPlusLiability - cmplncLimit;
      }
      if (abfFactors.cmplncChk.cmplncType == 'ANNPREM') {
        let mcfPlusTLSingle = plan.rateInfo.terminalLiabilityFund.single + plan.rateInfo.maxPaidClaimsFund.single;
        let mcfPlusTLSpouse = plan.rateInfo.terminalLiabilityFund.eeSpouse + plan.rateInfo.maxPaidClaimsFund.eeSpouse;
        let mcfPlusTLOne = plan.rateInfo.terminalLiabilityFund.eeOne + plan.rateInfo.maxPaidClaimsFund.eeOne;
        let mcfPlusTLChild = plan.rateInfo.terminalLiabilityFund.eeChild + plan.rateInfo.maxPaidClaimsFund.eeChild;
        let mcfPlusTLChildren = plan.rateInfo.terminalLiabilityFund.eeChildren + plan.rateInfo.maxPaidClaimsFund.eeChildren;
        let mcfPlusTLFamily = plan.rateInfo.terminalLiabilityFund.family + plan.rateInfo.maxPaidClaimsFund.family;
        let tierLives = plan.factors?.calculatedTierLives?.[adjustment?.outputTier + '-tier'] ?? null;
        let total =
          (mcfPlusTLSingle * (tierLives?.eeCount || 0) +
            mcfPlusTLSpouse * (tierLives?.esCount || 0) +
            mcfPlusTLOne * (tierLives?.e1Count || 0) +
            mcfPlusTLChild * (tierLives?.ekCount || 0) +
            mcfPlusTLChildren * (tierLives?.ecCount || 0) +
            mcfPlusTLFamily * (tierLives?.efCount || 0)) *
          12;
        value = total - cmplncLimit;
      }
      abfFactors['excessOfLimit'] = value;
      if (value < guardrail.minVal || value > guardrail.maxVal) {
        if (!failedGuardRails.includes(guardrail.attrbNm)) {
          failedGuardRails.push(guardrail.attrbNm);
        }
        if (!StringUtils.isUndefined(plan.toggled)) {
          if (!plan.includeInPrintExhibitOverride && !plan.toggled && plan.includeInPrintExhibit) {
            plan.includeInPrintExhibit = false;
            this.guardrailToggle(plan);
          }
        }
        abfFactors['compliant'] = false;
      } else {
        if (failedGuardRails.includes(guardrail.attrbNm)) {
          failedGuardRails.splice(failedGuardRails.indexOf(guardrail.attrbNm), 1);
        }
        if (!StringUtils.isUndefined(plan.toggled)) {
          if (!plan.includeInPrintExhibitOverride && !plan.toggled && !plan.includeInPrintExhibit) {
            plan.includeInPrintExhibit = true;
            this.guardrailToggle(plan);
          }
        }
        abfFactors['compliant'] = true;
      }
    }
  }

  guardrailToggle(plan: any) {
    if (plan.guardrailToggled) {
      plan.guardrailToggled = !plan.guardrailToggled;
    } else {
      plan.guardrailToggled = true;
    }
  }
  validateGuardrails(plan: any, guardRails, adjustment: any): void {
    var guardrails = guardRails || [];
    var failedGuardRails = plan.failedGuardRails || [];
    var nagativeGuardRails = [
      'response.proposedPlans.rateInfo.TIERED.ASO.ACTIVE.EE.rate',
      'response.proposedPlans.rateInfo.TIERED.MAX_CLAIMS_FUND.ACTIVE.EE.rate',
      'response.proposedPlans.rateInfo.TIERED.SSL.ACTIVE.EE.rate',
      'response.proposedPlans.rateInfo.TIERED.TERMINAL_LIABILITY.ACTIVE.EE.rate',
      'response.proposedPlans.rateInfo.TIERED.ASL.ACTIVE.EE.rate'
    ];

    guardrails.forEach((guardrail) => {
      if (guardrail.guardName == 'ABF Compliance Check') {
        this.validateCompliance(plan, guardrail, failedGuardRails, adjustment);
      }
    });

    if (!plan.includeInPrintExhibitOverride && plan.includeInPrintExhibit && failedGuardRails) {
      failedGuardRails.forEach((guardRails) => {
        if (nagativeGuardRails.includes(guardRails)) {
          plan.includeInPrintExhibit = false;
        }
      });
    }

    plan.failedGuardRails = failedGuardRails.length > 0 ? failedGuardRails : null;
  }

  getNormalizedRiskFactor(riskFactor, minVal, maxVal) {
    if (riskFactor < minVal) {
      return minVal;
    } else if (riskFactor > maxVal) {
      return maxVal;
    }
    return riskFactor;
  }

  getMEWAAdjusments(plan: any, quoteDetail: any) {

    let adjustments: any = {};
    if (quoteDetail) {
      if (quoteDetail.uwAdjustment) adjustments = quoteDetail.uwAdjustment;
    }

    let mewaFactors = structuredClone(plan.factors.mewaFactors);
    let riskFactorGuardRail;
    if (quoteDetail.factors && quoteDetail.factors?.guardRails
      && quoteDetail.factors?.guardRails.find(gr => gr.attrbNm == 'request.medical.riskFactor')) {
      riskFactorGuardRail = quoteDetail.factors.guardRails.find(gr => gr.attrbNm == 'request.medical.riskFactor');
    }

    let riskFactorOriginal = quoteDetail.medical.riskFactor;
    let normalizedRiskFactor = Number(riskFactorOriginal);
    let riskFactorAdjusted, riskFactorWithAdj;

    const riskFactorInAdjustment = this.getValidatedParsedValue(quoteDetail.uwAdjustment.quoteAdjustments?.riskFactor, null);
    const uwAdjustmentFactor = this.getValidatedParsedValue(quoteDetail.uwAdjustment.quoteAdjustments?.uwAdjustmentFactor, null);
    const wholeHealthAdjustmentFactorInAdjustment = this.getValidatedParsedValue(quoteDetail.uwAdjustment.quoteAdjustments?.wholeHealthAdjustmentFactor, null);
    const wholeHealthAdjustmentFactor = wholeHealthAdjustmentFactorInAdjustment
      ? (StringUtils.isEqual(quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL)
        ? 1 - (wholeHealthAdjustmentFactorInAdjustment / this.HUNDRED)
        : wholeHealthAdjustmentFactorInAdjustment)
      : null;
    const currentRiskFactorInAdjustment = this.getValidatedParsedValueAllowZero(quoteDetail.uwAdjustment.quoteAdjustments?.currentRiskFactor, null);
    
    if ((currentRiskFactorInAdjustment === null || currentRiskFactorInAdjustment === undefined) && StringUtils.isEqual(quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL) && !quoteDetail.medical?.alternateQuote) {
      if(!quoteDetail.uwAdjustment.quoteAdjustments) {
        quoteDetail.uwAdjustment.quoteAdjustments = {};
      }
      quoteDetail.uwAdjustment.quoteAdjustments.currentRiskFactor = riskFactorOriginal;
    }

    if (riskFactorInAdjustment || uwAdjustmentFactor || wholeHealthAdjustmentFactor) {
      riskFactorAdjusted = riskFactorInAdjustment && !isNaN(riskFactorInAdjustment) ? riskFactorInAdjustment : riskFactorOriginal;
      riskFactorWithAdj = uwAdjustmentFactor && !isNaN(uwAdjustmentFactor) ? (riskFactorAdjusted * uwAdjustmentFactor) : riskFactorAdjusted;

      if (riskFactorGuardRail) {
        normalizedRiskFactor = this.getNormalizedRiskFactor(riskFactorWithAdj, riskFactorGuardRail.minVal, riskFactorGuardRail.maxVal);
      } else {
        normalizedRiskFactor = riskFactorWithAdj;
      }
    }

    let netPMPMUnrounded = mewaFactors.netPMPM;
    let ageGenderFactor = mewaFactors.ageGenderFctr ?? 1;
    let retentionFctr = mewaFactors.retentionFctr;

    let netPMPMWithoutRiskFactor = UnderwriterAdjustmentService.rounfOffToEightDecimals(netPMPMUnrounded / riskFactorOriginal);
    let netPMPMWithAdjustmentUnrounded = netPMPMWithoutRiskFactor * normalizedRiskFactor;
    let netPMPMWithAdjustment = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(netPMPMWithAdjustmentUnrounded));
    let claimsPMPMWithAdjustment = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(ageGenderFactor * netPMPMWithAdjustment));
    let claimsPMPYWithAdjustment = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(claimsPMPMWithAdjustment * this.MONTHS_IN_A_YEAR));
    let totalPercentOfPremiumItems = this.roundValueToFourDecimals(retentionFctr / this.HUNDRED);
    let reqPMPYPremiumWithoutWHAdj = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(claimsPMPYWithAdjustment / (1 - (totalPercentOfPremiumItems))));

    let finalReqPMPYPremium, finalRiskFactor, whsReduction, reqPMPYPremiumWithAdjustment, riskFactorWithWHS = null;

    if (wholeHealthAdjustmentFactor && !isNaN(wholeHealthAdjustmentFactor)) {
      reqPMPYPremiumWithAdjustment = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(reqPMPYPremiumWithoutWHAdj * wholeHealthAdjustmentFactor));
      riskFactorWithWHS = this.roundValueToFourDecimals(UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumWithAdjustment / reqPMPYPremiumWithoutWHAdj) * (normalizedRiskFactor));
      finalRiskFactor = riskFactorGuardRail ? this.getNormalizedRiskFactor(riskFactorWithWHS, riskFactorGuardRail.minVal, riskFactorGuardRail.maxVal) : riskFactorWithWHS;
      finalReqPMPYPremium = this.roundHalfUpTwoDecimals(UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumWithAdjustment / riskFactorWithWHS) * finalRiskFactor);

      whsReduction = this.roundValueToFourDecimals((finalReqPMPYPremium / reqPMPYPremiumWithoutWHAdj) - 1);
    } else {
      finalReqPMPYPremium = reqPMPYPremiumWithoutWHAdj;
      finalRiskFactor = this.roundValueToFourDecimals(normalizedRiskFactor);
    }

    mewaFactors.pureClaimCostWithAdjustment;
    mewaFactors.postClaimPMPMItemsWithAdjustment;
    mewaFactors.totalPercentOfPremiumItems = totalPercentOfPremiumItems;
    mewaFactors.reqPMPYPremiumWithoutWHAdj = reqPMPYPremiumWithoutWHAdj;

    mewaFactors.netPMPMWithAdjustment = netPMPMWithAdjustment;
    mewaFactors.netPMPMWithAdjustmentUnrounded = netPMPMWithAdjustmentUnrounded;
    mewaFactors.claimsPMPMWithAdjustment = claimsPMPMWithAdjustment;
    mewaFactors.claimsPMPYWithAdjustment = claimsPMPYWithAdjustment;
    mewaFactors.reqPMPYPremiumWithAdjustment = finalReqPMPYPremium;
    mewaFactors.finalRiskFactor = finalRiskFactor;
    mewaFactors.riskFactorWithWHS = riskFactorWithWHS;
    mewaFactors.whsReduction = whsReduction;

    plan.factors.mewaFactors = structuredClone(mewaFactors);

    if (quoteDetail.factors) {
      plan.rateInfo = this.getMEWARateInfo(plan);
      plan.factors.mewaFactors.medicareTieredRates = plan?.factors?.mewaFactors?.medicareTieredRates ? this.getMewaMedicareTieredRate(plan): null;

    }

    return plan;
  }


  getMEWARateInfo(plan) {

    let tierFactor = plan.factors.mewaFactors.tierFactor;
    let reqPMPYPremiumWithAdjustment = plan.factors.mewaFactors.reqPMPYPremiumWithAdjustment;
    let actualMemberCount = plan.factors.mewaFactors.actualMemberCount;
    let weightedTieringFactor = plan.factors.mewaFactors.weightedTieringFactor;

    let reqPMPYPremiumXestMembers = UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumWithAdjustment * actualMemberCount);
    let reqPMPYPremiumXestMembersDIV12 = UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumXestMembers / this.MONTHS_IN_A_YEAR);
    let adjustedFinalReqPMPYPremium = UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumXestMembersDIV12 / weightedTieringFactor);
    let pcpmEmpRate = this.roundHalfDownTwoDecimals(adjustedFinalReqPMPYPremium);

    let rateInfo = plan.rateInfo ? plan.rateInfo : {};
    rateInfo['single'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * tierFactor.eeFactor));
    rateInfo['eeSpouse'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * tierFactor.esFactor));
    rateInfo['eeChildren'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * tierFactor.ecFactor));
    rateInfo['family'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * tierFactor.efFactor));

    let subscriberCount = plan.factors.mewaFactors.subscriberCount;
    let monthlyPremiumAdjusted = this.roundedValue(
      (rateInfo['single'] * subscriberCount?.eeCount)
      + (rateInfo['eeSpouse'] * subscriberCount?.esCount)
      + (rateInfo['eeChildren'] * subscriberCount?.ecCount)
      + (rateInfo['family'] * subscriberCount?.efCount));
    let yearlyPremiumAdjusted = this.roundedValue(monthlyPremiumAdjusted * this.MONTHS_IN_A_YEAR);

    plan.factors.mewaFactors.monthlyPremiumAdjusted = monthlyPremiumAdjusted;
    plan.factors.mewaFactors.yearlyPremiumAdjusted = yearlyPremiumAdjusted;

    return rateInfo;
  }

  getMewaMedicareTieredRate(plan){

    let medicareTierFactor=plan.factors.mewaFactors.medicareTierFactor;

    let reqPMPYPremiumWithAdjustment = plan.factors.mewaFactors.reqPMPYPremiumWithAdjustment;
    let actualMemberCount = plan.factors.mewaFactors.actualMemberCount;
    let weightedTieringFactor = plan.factors.mewaFactors.weightedTieringFactor;

    let reqPMPYPremiumXestMembers = UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumWithAdjustment * actualMemberCount);
    let reqPMPYPremiumXestMembersDIV12 = UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumXestMembers / this.MONTHS_IN_A_YEAR);
    let adjustedFinalReqPMPYPremium = UnderwriterAdjustmentService.rounfOffToEightDecimals(reqPMPYPremiumXestMembersDIV12 / weightedTieringFactor);
    let pcpmEmpRate = this.roundHalfDownTwoDecimals(adjustedFinalReqPMPYPremium);


    let medicareTieredRates= plan.factors.mewaFactors.medicareTieredRates ? plan.factors.mewaFactors.medicareTieredRates : {};

    medicareTieredRates['single'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * medicareTierFactor.eeFactor ));
    medicareTieredRates['eeSpouse'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * medicareTierFactor.esFactor));
    medicareTieredRates['eeChildren'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * medicareTierFactor.ecFactor));
    medicareTieredRates['family'] = this.roundHalfUpTwoDecimals(this.roundValueToSixDecimals(pcpmEmpRate * medicareTierFactor.efFactor));


    return medicareTieredRates;
  }


  getFiAdjusments(plan: any, quoteDetail: any, currentPlanArray?: any) {
    let adjustedFiPMPM = 0;
    let adjustments: any = {};
    let currentPlan;
    let abfRateActionAdjustment: any = {};
    if (quoteDetail) {
      if (quoteDetail.uwAdjustment) adjustments = quoteDetail.uwAdjustment;
    }
    if (!StringUtils.isUndefined(currentPlanArray)) {
      currentPlanArray.forEach((currentPlanObj) => {
        currentPlan = currentPlanObj;
      });
    }
    if (adjustments.abfRateActionAdjustment) {
      abfRateActionAdjustment = adjustments.abfRateActionAdjustment;
    }
    let adjustmentFactor = abfRateActionAdjustment['totalQlAdj'] || abfRateActionAdjustment['expAdj'];
    let whSaving = undefined;
    if (abfRateActionAdjustment && abfRateActionAdjustment.hasOwnProperty('renewalWHAPercent')) {
      whSaving = abfRateActionAdjustment['renewalWHAPercent'];
    }
    if (!StringUtils.isUndefined(whSaving)) {
      whSaving = whSaving / 100;
      adjustmentFactor *=(1 - whSaving);
      if (whSaving !== 0) {
        plan.factors['WHSAdj'] = 1 - whSaving;
      } else {
        delete plan.factors['WHSAdj'];
      }
    }
    adjustedFiPMPM += plan.factors.grossPMPMWithoutRiskscore;
    plan.factors['totalAdjustment'] = adjustmentFactor != 1 ? adjustmentFactor : 'N/A';
    plan.factors['grossPMPMWithWHSDiscount'] = whSaving ? plan.factors.grossPMPMWithoutRiskscore * (1 - whSaving) : 'N/A' ;
    adjustedFiPMPM *= adjustmentFactor;
    if (quoteDetail?.factors) {
      return this.calculateRateInfoForFiPlan(quoteDetail, adjustments, adjustedFiPMPM.toFixed(2), plan, currentPlan);
    }
  }
  private calculateRateInfoForFiPlan(quoteDetail: any, adjustments: any, adjustedFiPMPM: any, plan: any, currentPlan?: any) {
    let tierFactors = this.getTierMultiplier(quoteDetail.factors, adjustments.outputTier, adjustments.tierRatioCalculationType);
    let multiplicativeFactor = tierFactors.tierFactor;
    plan.factors['adjTierFactor'] = tierFactors.adjTierFactor;
    this.getRetentionAssessments(plan);
    this.getNonRetentionAssessments(plan);
    plan.rateInfo = this.getFiRateInfo(quoteDetail, plan, multiplicativeFactor, adjustedFiPMPM, adjustments, currentPlan);
    return plan;
  }

  getFiRateInfo(quoteDetail, plan, multiplicativeFactor, adjustedFiPMPM, adjustments, currentPlan?: any) {
    let rateInfo = plan.rateInfo || {};
    const outputTier = adjustments?.outputTier || quoteDetail?.medicalOutputTier;

    if (adjustments?.abfRateActionAdjustment?.isFlatRateApplied && !StringUtils.isUndefined(currentPlan)) {

      let rateActPercent = Number(adjustments.abfRateActionAdjustment.adjustedRateActionPercent) / 100;
      rateActPercent = 1 + (rateActPercent || 0);

      let whSaving = adjustments.abfRateActionAdjustment['renewalWHAPercent'];
      if (!StringUtils.isUndefined(whSaving)) {
        rateActPercent = rateActPercent * (1 - Number(whSaving) / 100);
      }
      if (outputTier == 1) {
        rateInfo['single'] = this.roundedValue(Number(currentPlan['currRatesT1']) * rateActPercent);
      }
      if (outputTier == 2) {
        rateInfo['single'] = this.roundedValue(Number(currentPlan['currRatesT1']) * rateActPercent);
        rateInfo['family'] = this.roundedValue(Number(currentPlan['currRatesT2']) * rateActPercent);
      }
      if (outputTier == 3) {
        rateInfo['single'] = this.roundedValue(Number(currentPlan['currRatesT1']) * rateActPercent);
        rateInfo['eeOne'] = this.roundedValue(Number(currentPlan['currRatesT2']) * rateActPercent);
        rateInfo['family'] = this.roundedValue(Number(currentPlan['currRatesT3']) * rateActPercent);
      }
      if (outputTier == 4) {
        rateInfo['single'] = this.roundedValue(Number(currentPlan['currRatesT1']) * rateActPercent);
        rateInfo['eeSpouse'] = this.roundedValue(Number(currentPlan['currRatesT2']) * rateActPercent);
        rateInfo['eeChildren'] = this.roundedValue(Number(currentPlan['currRatesT3']) * rateActPercent);
        rateInfo['family'] = this.roundedValue(Number(currentPlan['currRatesT4']) * rateActPercent);
      }
      if (outputTier == 5) {
        rateInfo['single'] = this.roundedValue(Number(currentPlan['currRatesT1']) * rateActPercent);
        rateInfo['eeSpouse'] = this.roundedValue(Number(currentPlan['currRatesT2']) * rateActPercent);
        rateInfo['eeChild'] = this.roundedValue(Number(currentPlan['currRatesT3']) * rateActPercent);
        rateInfo['eeChildren'] = this.roundedValue(Number(currentPlan['currRatesT4']) * rateActPercent);
        rateInfo['family'] = this.roundedValue(Number(currentPlan['currRatesT5']) * rateActPercent);
      }
    } else {
      // Totals
      if (multiplicativeFactor) {
        rateInfo['single'] = this.roundedValue(adjustedFiPMPM * (multiplicativeFactor.eeFactor || 0));
        rateInfo['eeOne'] = this.roundedValue(adjustedFiPMPM * (multiplicativeFactor.e1Factor || 0));
        rateInfo['eeChild'] = this.roundedValue(adjustedFiPMPM * (multiplicativeFactor.ekFactor || 0));
        rateInfo['eeChildren'] = this.roundedValue(adjustedFiPMPM * (multiplicativeFactor.ecFactor || 0));
        rateInfo['eeSpouse'] = this.roundedValue(adjustedFiPMPM * (multiplicativeFactor.esFactor || 0));
        rateInfo['family'] = this.roundedValue(adjustedFiPMPM * (multiplicativeFactor.efFactor || 0));
      }
    }
    return rateInfo;
  }

  getAbfExperienceAdjusments(plan: any, quoteDetail: any, componentLevelRates: any, isTierAdjusted: boolean = false): any {
    let abfFactors;
    let factors;
    let acsFactor = 1;
    let initialAbfFactors: any = {};
    let adjustedFinalPMPM = 0;
    let adjustedFinalClaimCost = 0;
    let adjustedAbfPMPM = 0;
    let adjustments: any = {};
    let adjDiffToTarget = 0;
    let sslAdj = 0;
    let aslAdj = 0;
    let adjSslAdj = 0;
    let adjAslAdj = 0;
    let abfRateActionAdjustment: any = {};
    if (quoteDetail) {
      if (quoteDetail.uwAdjustment) adjustments = quoteDetail.uwAdjustment;
    }

    if (adjustments.abfRateActionAdjustment) abfRateActionAdjustment = adjustments.abfRateActionAdjustment;

    factors = plan.factors;
    if (factors && factors.acsFactor) {
      acsFactor = factors.acsFactor;
    }
    abfFactors = factors.abfFactors;
    if (abfFactors && abfFactors.abfComponents) {
      initialAbfFactors = abfFactors.abfComponents.INITIAL;
    }

    let adjustmentFactor = isTierAdjusted ? abfRateActionAdjustment['expAdj'] : (abfRateActionAdjustment['totalQlAdj'] || abfRateActionAdjustment['expAdj']);
    let whSaving = adjustments?.abfRateActionAdjustment ? adjustments.abfRateActionAdjustment['renewalWHAPercent'] : undefined;
    if (!StringUtils.isUndefined(whSaving) && !isTierAdjusted) {
      whSaving = whSaving / 100;
      adjustmentFactor *=(1 - whSaving);
      if (whSaving !== 0) {
        abfFactors['WHSAdj'] = 1 - whSaving;
      } else {
        delete abfFactors['WHSAdj'];
      }
    }
    if (abfFactors != undefined && componentLevelRates != undefined) {
      adjustedAbfPMPM += abfFactors.abfGrossPMPM;
      adjustedFinalPMPM += abfFactors.abfMonthlyPMPM;
      adjustedFinalClaimCost += abfFactors.adjustedClaimsCost;
      adjustedAbfPMPM *= adjustmentFactor;
      adjustedFinalPMPM *= adjustmentFactor;
      adjustedFinalClaimCost *= adjustmentFactor;
      ({ adjDiffToTarget, sslAdj, aslAdj, adjSslAdj, adjAslAdj } = this.calculateQtLvlAdjustment(
        abfFactors,
        initialAbfFactors,
        adjustmentFactor,
        adjDiffToTarget,
        adjustedAbfPMPM,
        sslAdj,
        aslAdj,
        adjSslAdj,
        adjAslAdj
      ));
      abfFactors['adjAsoAdminFee'] = this.roundedValue(abfFactors.adjAsoAdminFee);
      abfFactors['adjSslPremium'] = this.roundedValue(abfFactors.adjSslPremium);
      abfFactors['adjAslPremium'] = this.roundedValue(abfFactors.adjAslPremium);
      abfFactors['adjMaxPaidClaim'] = this.roundedValue(abfFactors['adjMaxPaidClaim']);
      abfFactors['adjABFPremium'] = this.roundedValue(abfFactors.adjABFPremium);
      abfFactors['adjTerminalLiability'] = this.roundedValue(
        abfFactors.adjABFPremium - (abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.adjMaxPaidClaim)
      );
      abfFactors['adjABFPremium'] = this.roundedValue(
        abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.adjMaxPaidClaim + abfFactors.adjTerminalLiability
      );
      abfFactors['rblAloAsoAdminFee'] = this.roundingValueAfterFixingDecimal(abfFactors['adjAsoAdminFee'] * componentLevelRates['asoAdminFactor']);
      abfFactors['rblAloSslPremium'] = this.roundingValueAfterFixingDecimal(abfFactors['adjSslPremium'] * componentLevelRates['sslPremiumFactor']);
      abfFactors['rblAloAslPremium'] = this.roundingValueAfterFixingDecimal(abfFactors['adjAslPremium'] * componentLevelRates['aslPremiumFactor']);
      abfFactors['rblAloTerminalLiability'] = this.roundingValueAfterFixingDecimal(
        abfFactors['adjTerminalLiability'] * componentLevelRates['terminalLiabilityFactor']
      );

      abfFactors['rblAloMaxPaidClaim'] =
        abfFactors['adjABFPremium'] -
        (abfFactors.rblAloAsoAdminFee + abfFactors.rblAloSslPremium + abfFactors.rblAloAslPremium + abfFactors.rblAloTerminalLiability);
      abfFactors['rblAloAdjAbfPMPM'] =
        abfFactors.rblAloAsoAdminFee +
        abfFactors.rblAloSslPremium +
        abfFactors.rblAloAslPremium +
        abfFactors.rblAloMaxPaidClaim +
        abfFactors.rblAloTerminalLiability;

      abfFactors['finalAdjAsoAdminFee'] = abfFactors['rblAloAsoAdminFee'];
      abfFactors['finalAdjSslPremium'] = abfFactors['rblAloSslPremium'];
      abfFactors['finalAdjAslPremium'] = abfFactors['rblAloAslPremium'];
      abfFactors['finalAdjMaxPaidClaim'] = abfFactors['rblAloMaxPaidClaim'];
      abfFactors['finalAdjTerminalLiability'] = abfFactors['rblAloTerminalLiability'];
      abfFactors['finalAdjAbfPMPM'] = this.roundedValue(
        abfFactors.finalAdjAsoAdminFee +
          abfFactors.finalAdjSslPremium +
          abfFactors.finalAdjAslPremium +
          abfFactors.finalAdjMaxPaidClaim +
          abfFactors.finalAdjTerminalLiability
      );

      abfFactors['totalAdjustment'] = adjustmentFactor != 1 ? adjustmentFactor : 'N/A';
      abfFactors['grossPMPMWithWHSDiscount'] = whSaving && !isTierAdjusted  ? abfFactors.abfGrossPMPM * (1 - whSaving) : 'N/A';
      let estMembers = this.getValidatedParsedValue(plan.factors.estMembers, 1);
      abfFactors['totalMonthlyPremiumAdjusted'] = this.roundedValue(abfFactors.finalAdjAbfPMPM) * estMembers;
      if (quoteDetail.factors) {
        plan = this.calculateRateInfoForPlan(quoteDetail, adjustments, abfFactors, plan);
      }
      this.validateGuardrails(plan, quoteDetail.factors?.guardRails, adjustments);
      return plan;
    }
  }

  getAbfAltExperienceAdjusments(plan: any, quoteDetail: any, componentLevelRates: any, isTierAdjusted: boolean = false): any {
    let abfFactors;
    let factors;
    let acsFactor = 1;
    let initialAbfFactors: any = {};
    let adjustedFinalPMPM = 0;
    let adjustedFinalClaimCost = 0;
    let adjustedAbfPMPM = 0;
    let adjustments: any = {};
    let adjDiffToTarget = 0;
    let sslAdj = 0;
    let aslAdj = 0;
    let adjSslAdj = 0;
    let adjAslAdj = 0;
    let abfRateActionAdjustment: any = {};
    if (quoteDetail) {
      if (quoteDetail.uwAdjustment) adjustments = quoteDetail.uwAdjustment;
    }

    if (adjustments.abfRateActionAdjustment) abfRateActionAdjustment = adjustments.abfRateActionAdjustment;

    factors = plan.factors;
    if (factors && factors.acsFactor) {
      acsFactor = factors.acsFactor;
    }
    abfFactors = factors.abfFactors;
    if (abfFactors && abfFactors.abfComponents) {
      initialAbfFactors = abfFactors.abfComponents.INITIAL;
    }

    let adjustmentFactor =  isTierAdjusted ? abfRateActionAdjustment['expAdj'] : (abfRateActionAdjustment['totalQlAdj'] || abfRateActionAdjustment['expAdj']);
    let whSaving =  adjustments?.abfRateActionAdjustment ? adjustments.abfRateActionAdjustment['renewalWHAPercent'] : undefined;
    if (!StringUtils.isUndefined(whSaving) && !isTierAdjusted) {
      whSaving = whSaving / 100;
      adjustmentFactor *=(1 - whSaving);
      if (whSaving !== 0) {
        abfFactors['WHSAdj'] = 1 - whSaving;
      } else {
        delete abfFactors['WHSAdj'];
      }
    }
    if (abfFactors != undefined && componentLevelRates != undefined) {
      adjustedAbfPMPM += abfFactors.abfGrossPMPM;
      adjustedFinalPMPM += abfFactors.abfMonthlyPMPM;
      adjustedFinalClaimCost += abfFactors.adjustedClaimsCost;
      adjustedAbfPMPM *= adjustmentFactor;
      adjustedFinalPMPM *= adjustmentFactor;
      adjustedFinalClaimCost *= adjustmentFactor;
      ({ adjDiffToTarget, sslAdj, aslAdj, adjSslAdj, adjAslAdj } = this.calculateQtLvlAdjustment(
        abfFactors,
        initialAbfFactors,
        adjustmentFactor,
        adjDiffToTarget,
        adjustedAbfPMPM,
        sslAdj,
        aslAdj,
        adjSslAdj,
        adjAslAdj
      ));
      abfFactors['adjAsoAdminFee'] = this.roundedValue(abfFactors.adjAsoAdminFee);
      abfFactors['adjSslPremium'] = this.roundedValue(abfFactors.adjSslPremium);
      abfFactors['adjAslPremium'] = this.roundedValue(abfFactors.adjAslPremium);
      abfFactors['adjMaxPaidClaim'] = this.roundedValue(abfFactors['adjMaxPaidClaim']);
      abfFactors['adjABFPremium'] = this.roundedValue(abfFactors.adjABFPremium);
      abfFactors['adjTerminalLiability'] = this.roundedValue(
        abfFactors.adjABFPremium - (abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.adjMaxPaidClaim)
      );
      abfFactors['adjABFPremium'] = this.roundedValue(
        abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.adjMaxPaidClaim + abfFactors.adjTerminalLiability
      );
      abfFactors['rblAloMaxPaidClaim'] =
        abfFactors['adjABFPremium'] - (abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.adjTerminalLiability);
      abfFactors['rblAloAdjAbfPMPM'] =
        abfFactors.adjAsoAdminFee + abfFactors.adjSslPremium + abfFactors.adjAslPremium + abfFactors.rblAloMaxPaidClaim + abfFactors.adjTerminalLiability;

      abfFactors['finalAdjAsoAdminFee'] = abfFactors['adjAsoAdminFee'];
      abfFactors['finalAdjSslPremium'] = abfFactors['adjSslPremium'];
      abfFactors['finalAdjAslPremium'] = abfFactors['adjAslPremium'];
      abfFactors['finalAdjMaxPaidClaim'] = abfFactors['rblAloMaxPaidClaim'];
      abfFactors['finalAdjTerminalLiability'] = abfFactors['adjTerminalLiability'];
      abfFactors['finalAdjAbfPMPM'] = this.roundedValue(
        abfFactors.finalAdjAsoAdminFee +
          abfFactors.finalAdjSslPremium +
          abfFactors.finalAdjAslPremium +
          abfFactors.finalAdjMaxPaidClaim +
          abfFactors.finalAdjTerminalLiability
      );

      abfFactors['totalAdjustment'] = adjustmentFactor != 1 ? adjustmentFactor : 'N/A';
      abfFactors['grossPMPMWithWHSDiscount'] = whSaving && !isTierAdjusted ? abfFactors.abfGrossPMPM * (1 - whSaving) : 'N/A';
      let estMembers = this.getValidatedParsedValue(plan.factors.estMembers, 1);
      abfFactors['totalMonthlyPremiumAdjusted'] = this.roundedValue(abfFactors.finalAdjAbfPMPM) * estMembers;
      if (quoteDetail.factors) {
        plan = this.calculateRateInfoForPlan(quoteDetail, adjustments, abfFactors, plan);
      }
      this.validateGuardrails(plan, quoteDetail.factors?.guardRails, adjustments);
      return plan;
    }
  }

  private calculateRateInfoForPlan(quoteDetail: any, adjustments: any, abfFactors: any, plan: any) {
    let tierFactors = this.getTierMultiplier(quoteDetail.factors, adjustments.outputTier, adjustments.tierRatioCalculationType);
    let multiplicativeFactor = tierFactors.tierFactor;
    abfFactors['adjTierFactor'] = tierFactors.adjTierFactor;
    this.getRetentionAssessments(plan);
    this.getNonRetentionAssessments(plan);
    plan.rateInfo = this.getAbfRateInfo(plan, multiplicativeFactor, abfFactors);
    return plan;
  }

  //Method to calculate divisor for component rate action factor calc
  calculateQtLvlAdjAndComponentRates(featuredPlans: any, quoteDetail, abfRateActionAdjustmentFactor?: any, isTierAdjusted: boolean = false): any {
    let totalRatesComp = { adjAsoAdminFee: 0, adjSslPremium: 0, adjAslPremium: 0, adjMaxPaidClaim: 0, adjTerminalLiability: 0 };
    let outputTier = quoteDetail.medicalOutputTier ? quoteDetail.medicalOutputTier : quoteDetail.uwAdjustment.outputTier;
    let tierFactorData = this.getTierMultiplier(quoteDetail.factors, outputTier, quoteDetail.uwAdjustment.tierRatioCalculationType);
    let multiplicativeFactor = tierFactorData.tierFactor;
    featuredPlans.forEach((plan) => {
      let adjAbfPMPM = 0;
      let calcAbfFactors;
      let adjDiffToTarget;
      let sslAdj;
      let aslAdj;
      let adjSslAdj;
      let adjAslAdj;
      let factors = plan.factors;
      let adjustmentFactor = quoteDetail.uwAdjustment.abfRateActionAdjustment['totalQlAdj'] || quoteDetail.uwAdjustment.abfRateActionAdjustment['expAdj'];
      let whSaving = quoteDetail.uwAdjustment.abfRateActionAdjustment['renewalWHAPercent'];
      if (!StringUtils.isUndefined(whSaving) && !isTierAdjusted) {
        whSaving = whSaving / 100;
        adjustmentFactor *=(1 - whSaving);
        if (whSaving !== 0) {
          factors['WHSAdj'] = 1 - whSaving;
        } else {
          delete factors['WHSAdj'];
        }
      }
      calcAbfFactors = JSON.parse(JSON.stringify(factors.abfFactors));
      adjAbfPMPM += calcAbfFactors.abfGrossPMPM;
      adjAbfPMPM *= adjustmentFactor;
      ({ adjDiffToTarget, sslAdj, aslAdj, adjSslAdj, adjAslAdj } = this.calculateQtLvlAdjustment(
        calcAbfFactors,
        factors.abfFactors.abfComponents.INITIAL,
        adjustmentFactor,
        adjDiffToTarget,
        adjAbfPMPM,
        sslAdj,
        aslAdj,
        adjSslAdj,
        adjAslAdj
      ));
      calcAbfFactors['adjAsoAdminFee'] = this.roundedValue(calcAbfFactors.adjAsoAdminFee);
      calcAbfFactors['adjSslPremium'] = this.roundedValue(calcAbfFactors.adjSslPremium);
      calcAbfFactors['adjAslPremium'] = this.roundedValue(calcAbfFactors.adjAslPremium);
      calcAbfFactors['adjMaxPaidClaim'] = this.roundedValue(calcAbfFactors.adjMaxPaidClaim);
      calcAbfFactors['adjABFPremium'] = this.roundedValue(calcAbfFactors.adjABFPremium);
      calcAbfFactors['adjTerminalLiability'] = this.roundedValue(
        calcAbfFactors.adjABFPremium -
          (calcAbfFactors.adjAsoAdminFee + calcAbfFactors.adjSslPremium + calcAbfFactors.adjAslPremium + calcAbfFactors.adjMaxPaidClaim)
      );
      calcAbfFactors['adjABFPremium'] = this.roundedValue(
        calcAbfFactors.adjAsoAdminFee +
          calcAbfFactors.adjSslPremium +
          calcAbfFactors.adjAslPremium +
          calcAbfFactors.adjMaxPaidClaim +
          calcAbfFactors.adjTerminalLiability
      );

      if (abfRateActionAdjustmentFactor) {
        calcAbfFactors['adjAsoAdminFee'] = this.roundingValueAfterFixingDecimal(
          calcAbfFactors['adjAsoAdminFee'] * abfRateActionAdjustmentFactor['asoAdminFactor']
        );
        calcAbfFactors['adjSslPremium'] = this.roundingValueAfterFixingDecimal(
          calcAbfFactors['adjSslPremium'] * abfRateActionAdjustmentFactor['sslPremiumFactor']
        );
        calcAbfFactors['adjAslPremium'] = this.roundingValueAfterFixingDecimal(
          calcAbfFactors['adjAslPremium'] * abfRateActionAdjustmentFactor['aslPremiumFactor']
        );
        calcAbfFactors['adjTerminalLiability'] = this.roundingValueAfterFixingDecimal(
          calcAbfFactors['adjTerminalLiability'] * abfRateActionAdjustmentFactor['terminalLiabilityFactor']
        );
        calcAbfFactors['adjMaxPaidClaim'] =
          calcAbfFactors.adjABFPremium -
          (calcAbfFactors.adjAsoAdminFee + calcAbfFactors.adjSslPremium + calcAbfFactors.adjAslPremium + calcAbfFactors.adjTerminalLiability);
        calcAbfFactors['adjABFPremium'] =
          calcAbfFactors.adjAsoAdminFee +
          calcAbfFactors.adjSslPremium +
          calcAbfFactors.adjAslPremium +
          calcAbfFactors.adjMaxPaidClaim +
          calcAbfFactors.adjTerminalLiability;
      }
      let rateInfo = JSON.parse(JSON.stringify(plan.rateInfo));
      plan['calRateInfo'] = {};
      plan['calRateInfo']['single'] = this.roundedValue(calcAbfFactors['adjABFPremium'] * (multiplicativeFactor.eeFactor || 0));
      plan['calRateInfo']['eeOne'] = this.roundedValue(calcAbfFactors['adjABFPremium'] * (multiplicativeFactor.e1Factor || 0));
      plan['calRateInfo']['eeChild'] = this.roundedValue(calcAbfFactors['adjABFPremium'] * (multiplicativeFactor.ekFactor || 0));
      plan['calRateInfo']['eeChildren'] = this.roundedValue(calcAbfFactors['adjABFPremium'] * (multiplicativeFactor.ecFactor || 0));
      plan['calRateInfo']['eeSpouse'] = this.roundedValue(calcAbfFactors['adjABFPremium'] * (multiplicativeFactor.esFactor || 0));
      plan['calRateInfo']['family'] = this.roundedValue(calcAbfFactors['adjABFPremium'] * (multiplicativeFactor.efFactor || 0));

      Object.keys(totalRatesComp).forEach((key) => {
        rateInfo[key] = {};
        if (key != 'adjTerminalLiability') this.getComponentRates(key, rateInfo, multiplicativeFactor, calcAbfFactors[key]);
      });
      rateInfo['adjTerminalLiability']['single'] =
        plan['calRateInfo']['single'] -
        ((rateInfo['adjAsoAdminFee']['single'] || 0) +
          (rateInfo['adjSslPremium']['single'] || 0) +
          (rateInfo['adjAslPremium']['single'] || 0) +
          (rateInfo['adjMaxPaidClaim']['single'] || 0));
      rateInfo['adjTerminalLiability']['eeOne'] =
        plan['calRateInfo']['eeOne'] -
        ((rateInfo['adjAsoAdminFee']['eeOne'] || 0) +
          (rateInfo['adjSslPremium']['eeOne'] || 0) +
          (rateInfo['adjAslPremium']['eeOne'] || 0) +
          (rateInfo['adjMaxPaidClaim']['eeOne'] || 0));
      rateInfo['adjTerminalLiability']['eeChild'] =
        plan['calRateInfo']['eeChild'] -
        ((rateInfo['adjAsoAdminFee']['eeChild'] || 0) +
          (rateInfo['adjSslPremium']['eeChild'] || 0) +
          (rateInfo['adjAslPremium']['eeChild'] || 0) +
          (rateInfo['adjMaxPaidClaim']['eeChild'] || 0));
      rateInfo['adjTerminalLiability']['eeChildren'] =
        plan['calRateInfo']['eeChildren'] -
        ((rateInfo['adjAsoAdminFee']['eeChildren'] || 0) +
          (rateInfo['adjSslPremium']['eeChildren'] || 0) +
          (rateInfo['adjAslPremium']['eeChildren'] || 0) +
          (rateInfo['adjMaxPaidClaim']['eeChildren'] || 0));
      rateInfo['adjTerminalLiability']['eeSpouse'] =
        plan['calRateInfo']['eeSpouse'] -
        ((rateInfo['adjAsoAdminFee']['eeSpouse'] || 0) +
          (rateInfo['adjSslPremium']['eeSpouse'] || 0) +
          (rateInfo['adjAslPremium']['eeSpouse'] || 0) +
          (rateInfo['adjMaxPaidClaim']['eeSpouse'] || 0));
      rateInfo['adjTerminalLiability']['family'] =
        plan['calRateInfo']['family'] -
        ((rateInfo['adjAsoAdminFee']['family'] || 0) +
          (rateInfo['adjSslPremium']['family'] || 0) +
          (rateInfo['adjAslPremium']['family'] || 0) +
          (rateInfo['adjMaxPaidClaim']['family'] || 0));

      let subscriberCounts: any = UnderwriterAdjustmentService.fetchSubsciberCount(quoteDetail.medical.currentPlans, plan);
      Object.keys(totalRatesComp).forEach((key) => {
        rateInfo[key]['single'] = (rateInfo[key]['single'] || 0) * (subscriberCounts ? subscriberCounts.eeCount : 0);
        rateInfo[key]['eeOne'] = (rateInfo[key]['eeOne'] || 0) * (subscriberCounts ? subscriberCounts.e1Count : 0);
        rateInfo[key]['eeChild'] = (rateInfo[key]['eeChild'] || 0) * (subscriberCounts ? subscriberCounts.ekCount : 0);
        rateInfo[key]['eeChildren'] = (rateInfo[key]['eeChildren'] || 0) * (subscriberCounts ? subscriberCounts.ecCount : 0);
        rateInfo[key]['eeSpouse'] = (rateInfo[key]['eeSpouse'] || 0) * (subscriberCounts ? subscriberCounts.esCount : 0);
        rateInfo[key]['family'] = (rateInfo[key]['family'] || 0) * (subscriberCounts ? subscriberCounts.efCount : 0);
        totalRatesComp[key] +=
          rateInfo[key]['single'] +
          rateInfo[key]['eeOne'] +
          rateInfo[key]['eeChild'] +
          rateInfo[key]['eeChildren'] +
          rateInfo[key]['eeSpouse'] +
          rateInfo[key]['family'];
      });
      Object.keys(totalRatesComp).forEach((key) => {
        totalRatesComp[key] = this.roundedValue(totalRatesComp[key]);
      });
    });
    return isTierAdjusted ? featuredPlans : totalRatesComp;
  }

  private static fetchSubsciberCount(currentPlans: any[], plan: any) {
    let subscriberCount = {
      e1Count: 0,
      ecCount: 0,
      eeCount: 0,
      efCount: 0,
      ekCount: 0,
      esCount: 0
    };
    plan.currPlanId.forEach((currid) => {
      let currentPlan = currentPlans.filter((cPlan) => cPlan.id == currid)[0];
      if (currentPlan.enrolledSubscriber) {
        subscriberCount.e1Count = subscriberCount.e1Count + currentPlan.enrolledSubscriber.e1Count;
        subscriberCount.ecCount = subscriberCount.ecCount + currentPlan.enrolledSubscriber.ecCount;
        subscriberCount.eeCount = subscriberCount.eeCount + currentPlan.enrolledSubscriber.eeCount;
        subscriberCount.efCount = subscriberCount.efCount + currentPlan.enrolledSubscriber.efCount;
        subscriberCount.ekCount = subscriberCount.ekCount + currentPlan.enrolledSubscriber.ekCount;
        subscriberCount.esCount = subscriberCount.esCount + currentPlan.enrolledSubscriber.esCount;
      }
    });
    return subscriberCount;
  }

  convertPercentToDecimal(value): number {
    return isNaN(value) ? 1 : 1 + Number.parseFloat(value) / 100;
  }

  calculateRateActionFactor(adjustedPercent, currentPlanTotalRates, expAdjTotalRates, expAdjFactor) {
    let percentToDecimal = isNaN(adjustedPercent) ? 0 : 1 + adjustedPercent / 100;
    return this.roundValueToSixDecimals((Math.round(((percentToDecimal * currentPlanTotalRates) / expAdjTotalRates) * 100000) / 100000) * expAdjFactor);
  }
  //Method to calculate component adj percent
  calculateComponentPercentage(currentComponentTotal: any, calculatedTotalRates: any) {
    calculatedTotalRates['asoAdminCompPercent'] = this.roundValueToSixDecimals(
      +((calculatedTotalRates['adjAsoAdminFee'] - currentComponentTotal['asoAdminFee']) / currentComponentTotal['asoAdminFee']).toFixed(6) * 100
    );
    calculatedTotalRates['sslPremCompPercent'] = this.roundValueToSixDecimals(
      +((calculatedTotalRates['adjSslPremium'] - currentComponentTotal['sslPremium']) / currentComponentTotal['sslPremium']).toFixed(6) * 100
    );
    calculatedTotalRates['aslPremCompPercent'] = this.roundValueToSixDecimals(
      +((calculatedTotalRates['adjAslPremium'] - currentComponentTotal['aslPremium']) / currentComponentTotal['aslPremium']).toFixed(6) * 100
    );
    calculatedTotalRates['maxPaidClaimCompPercent'] = this.roundValueToSixDecimals(
      +((calculatedTotalRates['adjMaxPaidClaim'] - currentComponentTotal['maxPaidClaim']) / currentComponentTotal['maxPaidClaim']).toFixed(6) * 100
    );
    calculatedTotalRates['terminalLiabilityCompPercent'] = this.roundValueToSixDecimals(
      +((calculatedTotalRates['adjTerminalLiability'] - currentComponentTotal['terminalLiability']) / currentComponentTotal['terminalLiability']).toFixed(6) *
        100
    );
  }

  calculateRateActionFactorNewCalc(adjustedPercent, currentPlanTotalRates, expAdjTotalRates) {
    let percentToDecimal = isNaN(adjustedPercent) ? 0 : 1 + adjustedPercent / 100;
    return this.roundValueToSixDecimals(Math.round(((percentToDecimal * currentPlanTotalRates) / expAdjTotalRates) * 1000000) / 1000000);
  }
  calculateComponentAdjFactors(factors: any, componentLevelRates: any, oldCompLvlRates: any, abfRateActionAdjustment: any): void {
    componentLevelRates['asoAdminFactor'] = this.calculateRateActionFactor(
      abfRateActionAdjustment['asoAdminFee'],
      factors.experienceFactors.currentComponentTotal.asoAdminFee,
      oldCompLvlRates['adjAsoAdminFee'],
      1
    );

    componentLevelRates['sslPremiumFactor'] = this.calculateRateActionFactor(
      abfRateActionAdjustment['sslPremium'],
      factors.experienceFactors.currentComponentTotal.sslPremium,
      oldCompLvlRates['adjSslPremium'],
      1
    );

    componentLevelRates['aslPremiumFactor'] = this.calculateRateActionFactor(
      abfRateActionAdjustment['aslPremium'],
      factors.experienceFactors.currentComponentTotal.aslPremium,
      oldCompLvlRates['adjAslPremium'],
      1
    );

    componentLevelRates['terminalLiabilityFactor'] = this.calculateRateActionFactor(
      abfRateActionAdjustment['terminalLiability'],
      factors.experienceFactors.currentComponentTotal.terminalLiability,
      oldCompLvlRates['adjTerminalLiability'],
      1
    );
    componentLevelRates['maxClaimFactor'] = this.calculateRateActionFactor(
      abfRateActionAdjustment['maxPaidClaim'],
      factors.experienceFactors.currentComponentTotal.maxPaidClaim,
      oldCompLvlRates['adjMaxPaidClaim'],
      1
    );
  }

  roundValueToSixDecimals(value) {
    return Math.round(+Number(value).toFixed(6) * 1000000) / 1000000;
  }

  roundValueToFourDecimals(value) {
    return Math.round(+Number(value).toFixed(4) * 10000) / 10000;
  }

  calculateRateActionRatesOnIntialLoad(featuredPlans: any, quoteDetail, abfRateActionAdj: any, initialExpRates: any, isInitial: boolean) {
    this.calculateComponentAdjFactors(quoteDetail.factors, initialExpRates, initialExpRates, abfRateActionAdj);
    let finalExpRates = this.calculateQtLvlAdjAndComponentRates(featuredPlans, quoteDetail, initialExpRates);
    if (isInitial) this.calculateComponentPercentage(quoteDetail.factors.experienceFactors.currentComponentTotal, finalExpRates);
    this.calculateComponentAdjFactors(quoteDetail.factors, finalExpRates, initialExpRates, abfRateActionAdj);
    return finalExpRates;
  }

  getKey(key, factor: boolean) {
    if (key == 'asoAdminFee') {
      return factor ? 'asoAdminFactor' : 'adjAsoAdminFee';
    } else if (key == 'sslPremium') {
      return factor ? 'sslPremiumFactor' : 'adjSslPremium';
    } else if (key == 'aslPremium') {
      return factor ? 'aslPremiumFactor' : 'adjAslPremium';
    } else if (key == 'maxPaidClaim') {
      return factor ? 'maxClaimFactor' : 'adjMaxPaidClaim';
    } else if (key == 'terminalLiability') {
      return factor ? 'terminalLiabilityFactor' : 'adjTerminalLiability';
    }
  }
  static rounfOffToEightDecimals(value: Number) {
    return Math.round(+Number(value).toFixed(8) * 100000000) / 100000000;
  }

  public static summingPlanTotprem(groups: any) {
    let currentPlanTotPrem = 0;
    let renewalPlanTotprem = 0;
    let adjustedRenewalPlanTotPrem = 0;
    for (let grp of groups) {
      if (grp['curntPlanintialGrandTotal']) {
        currentPlanTotPrem = currentPlanTotPrem + grp['curntPlanintialGrandTotal'];
      }
      if (grp['renewalPlanintialGrandTotal']) {
        renewalPlanTotprem = renewalPlanTotprem + grp['renewalPlanintialGrandTotal'];
      }
      if (grp['adjustedRenewalPlanGrandTotal']) {
        adjustedRenewalPlanTotPrem = adjustedRenewalPlanTotPrem + grp['adjustedRenewalPlanGrandTotal'];
      }
    }
    return { currentPlanTotPrem: currentPlanTotPrem, renewalPlanTotPrem: renewalPlanTotprem, adjustedRenewalPlanTotPrem: adjustedRenewalPlanTotPrem };
  }

  public totalRateActionCalc(curr: any, other: any): number {
    if (other == 0 || curr == 0) return 0;
    return this.roundedValue((other / curr - 1) * 100);
  }

  public static calculateUWGrandTotal(group: any, groups) {
    let adjGrandTotal = 0;
    group.data.proposedPlans.forEach((plan) => {
      let subscriberCount = UnderwriterAdjustmentService.fetchSubsciberCount(group['quoteDetail']['medical']['currentPlans'], plan);
      if (subscriberCount) {
        adjGrandTotal =
          adjGrandTotal +
          (plan.rateInfo['single'] || 0) * (subscriberCount['eeCount'] || 0) +
          (plan.rateInfo['eeOne'] || 0) * (subscriberCount['e1Count'] || 0) +
          (plan.rateInfo['eeChild'] || 0) * (subscriberCount['ekCount'] || 0) +
          (plan.rateInfo['eeChildren'] || 0) * (subscriberCount['ecCount'] || 0) +
          (plan.rateInfo['eeSpouse'] || 0) * (subscriberCount['esCount'] || 0) +
          (plan.rateInfo['family'] || 0) * (subscriberCount['efCount'] || 0);
      }
    });
    group['adjustedRenewalPlanGrandTotal'] = adjGrandTotal;
    return groups.reduce((accumulator, grp) => {
      return accumulator + (grp['adjustedRenewalPlanGrandTotal'] || 0);
    }, 0);
  }

  public static filterFeaturedPlans(proposedPlans: any[]): any[] {
    return proposedPlans.filter((plan) => plan.status && plan.status != 'Failed' && plan['planTypeRequested'] == 'F');
  }

  isOldRiskScoreVersion(receivedRiskScoreVersion: string): boolean {
    if (receivedRiskScoreVersion && !isNaN(parseFloat(receivedRiskScoreVersion))) {
      let riskScoreVersion = parseFloat(receivedRiskScoreVersion).toFixed(1);
      return StringUtils.checkStrExitsInArr(riskScoreVersion, ['1.0', '3.0', '1', '3']);
    } else {
      return true;
    }
  }

  showComponentAdjustmentsForAlternates(data): boolean {
    if (Object.keys(data).length === 0) {
      return false;
    }
    if(data?.medical?.alternateQuote && StringUtils.isEqual(data.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
      if(StringUtils.isEqual(data.fundingType, data.medical.currentPlans?.[0]?.fundingType)) {
        return true;
      }

      return false;
    }
    return true;
  }

  setupReQuoteABFInitialValues(showABFSLValues, defaultValues, stopLossCvgArr) {
    const initValues = {
      surplusRefundList: [],
      aggSLCorridorList: [],
      sslContractBasisList: [],
      sslDeductibleList: [],
      surplusRefund: null,
      aggSLCorridor: null,
      sslContractBasis: null,
      sslDeductible: null
    };
    
    let stopLossCvg: any = {};

    if (showABFSLValues && defaultValues) {
      if (Array.isArray(defaultValues['SURPLUS_REFUND']) && defaultValues['SURPLUS_REFUND'].length > 0) {
        defaultValues['SURPLUS_REFUND'].forEach(val => {
          initValues.surplusRefundList.push({ "label": formatPercent(parseFloat(val), this.locale, "1.0-0"), "value": parseFloat(val) });
        });
        initValues.surplusRefund = {
          "label": formatPercent(parseFloat(defaultValues['SURPLUS_REFUND'][0]), this.locale, "1.0-0"),
          "value": parseFloat(defaultValues['SURPLUS_REFUND'][0])
        };
      }

      if (Array.isArray(defaultValues['ASL_AGG_ATCH_PT']) && defaultValues['ASL_AGG_ATCH_PT'].length > 0) {
        defaultValues['ASL_AGG_ATCH_PT'].forEach(val => {
          initValues.aggSLCorridorList.push({ "label": formatPercent(parseFloat(val), this.locale, "1.0-0"), "value": parseFloat(val) });
        });
        initValues.aggSLCorridor = {
          "label": formatPercent(parseFloat(defaultValues['ASL_AGG_ATCH_PT'][0]), this.locale, "1.0-0"),
          "value": parseFloat(defaultValues['ASL_AGG_ATCH_PT'][0])
        };
      }

      if (Array.isArray(defaultValues['SSL_CONTRACT_BASIS']) && defaultValues['SSL_CONTRACT_BASIS'].length > 0) {
        defaultValues['SSL_CONTRACT_BASIS'].forEach(val => {
          initValues.sslContractBasisList.push({ "label": val, "value": val });
        });
        initValues.sslContractBasis = {
          "label": defaultValues['SSL_CONTRACT_BASIS'][0],
          "value": defaultValues['SSL_CONTRACT_BASIS'][0]
        };
      }

      if (Array.isArray(defaultValues['SSL_DEDUCTIBLE']) && defaultValues['SSL_DEDUCTIBLE'].length > 0) {
        defaultValues['SSL_DEDUCTIBLE'].forEach(val => {
          initValues.sslDeductibleList.push({
            "label": formatCurrency(parseFloat(val), this.locale,
              getCurrencySymbol("USD", "wide"), undefined, "1.0-0"), "value": parseFloat(val)
          });
        });
        initValues.sslDeductible = {
          "label": formatCurrency(parseFloat(defaultValues['SSL_DEDUCTIBLE'][0]),
            this.locale, getCurrencySymbol("USD", "wide"), undefined, "1.0-0"),
          "value": parseFloat(defaultValues['SSL_DEDUCTIBLE'][0])
        };
      }
    }

    if (initValues.surplusRefundList.length > 0) {
      initValues.surplusRefundList.sort((a, b) => (parseFloat(a.value) > parseFloat(b.value)) ? 1 : -1);
    }

    if (initValues.sslDeductibleList.length > 0) {
      initValues.sslDeductibleList.sort((a, b) => (parseFloat(a.value) > parseFloat(b.value)) ? 1 : -1);
    }

    if (initValues.aggSLCorridorList.length > 0) {
      initValues.aggSLCorridorList.sort((a, b) => (parseFloat(a.value) > parseFloat(b.value)) ? 1 : -1);
    }

    if (initValues.sslContractBasisList.length > 0) {
      initValues.sslContractBasisList.sort((a, b) => (a.value > b.value) ? 1 : -1);
    }

    if (Array.isArray(stopLossCvgArr)) {
      stopLossCvg = stopLossCvgArr[0];
    }

    if (stopLossCvg && Object.keys(stopLossCvg).length > 0) {
      if (stopLossCvg['surplusRefund'])
        initValues.surplusRefund = {
          "label": formatPercent(parseFloat(stopLossCvg['surplusRefund']), this.locale, "1.0-0"),
          "value": parseFloat(stopLossCvg['surplusRefund'])
        };
      if (stopLossCvg['aggSLCorridor'])
        initValues.aggSLCorridor = {
          "label": formatPercent(parseFloat(stopLossCvg['aggSLCorridor']), this.locale, "1.0-0"),
          "value": parseFloat(stopLossCvg['aggSLCorridor'])
        };
      if (stopLossCvg['sslContractBasis'])
        initValues.sslContractBasis = { "label": stopLossCvg['sslContractBasis'], "value": stopLossCvg['sslContractBasis'] };
      if (stopLossCvg['sslDeductible'])
        initValues.sslDeductible = {
          "label": formatCurrency(parseFloat(stopLossCvg['sslDeductible']), this.locale,
            getCurrencySymbol("USD", "wide"), undefined, "1.0-0"),
          "value": parseFloat(stopLossCvg['sslDeductible'])
        };
    }

    if ((initValues.sslDeductibleList.length > 0 && initValues.sslDeductibleList.filter(ele => ele.value == initValues.sslDeductible.value).length < 1) || (initValues.sslDeductibleList.length < 1)) {
      initValues.sslDeductible = {};
    }

    if ((initValues.surplusRefundList.length > 0 && initValues.surplusRefundList.filter(ele => ele.value == initValues.surplusRefund.value).length < 1) || (initValues.surplusRefundList.length < 1)) {
      initValues.surplusRefund = {};
    }

    if ((initValues.aggSLCorridorList.length > 0 && initValues.aggSLCorridorList.filter(ele => ele.value == initValues.aggSLCorridor.value).length < 1) || (initValues.aggSLCorridorList.length < 1)) {
      initValues.aggSLCorridor = {};
    }

    if ((initValues.sslContractBasisList.length > 0 && initValues.sslContractBasisList.filter(ele => ele.value == initValues.sslContractBasis.value).length < 1) || (initValues.sslContractBasisList.length < 1)) {
      initValues.sslContractBasis = {};
    }

    return initValues;
  }

  
}
