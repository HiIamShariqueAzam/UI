import { Component, OnInit, Input, SimpleChanges, OnChanges, Inject, LOCALE_ID, Output, EventEmitter, OnDestroy, HostListener } from "@angular/core";
import { formatCurrency, getCurrencySymbol, formatPercent, ViewportScroller } from '@angular/common';
import { UnderwriterAdjustmentService } from '../uw-adjustment.service';
import { Enrollments, MedicalPremiumComparison, PlanComparison, PlanRates } from "src/app/shared/models";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { CommonConstants } from "src/app/shared/constants/common.constants";

@Component({
  selector: "app-medical-premium-comparison",
  templateUrl: "./medical-premium-comparison.component.html",
  styleUrls: ["./medical-premium-comparison.component.css"],
  standalone: false,
})
export class MedicalPremiumComparisonComponent implements OnInit, OnChanges, OnDestroy {
  @Input() quoteDetail: any;
  @Input() InitalQuoteDetail: any;
  @Input() disableAll: boolean;
  @Input() mpcStatusChange: boolean;
  @Output() checkValidPremiumRates = new EventEmitter<boolean>();


  initialTier: number;
  requestedTier: number;
  calculatedLives: any;
  mpcGuardrailErrorMessage: string;
  enableIIPcheckbox: boolean;
  includeInProposal: boolean;
  mpc: MedicalPremiumComparison;
  mpcInitialObj: MedicalPremiumComparison;
  tierDescription: any;
  isVirginGroup: boolean;
  tempMpcOnchange: boolean = false;
  defaultTierNames = {
    EE: "EE",
    EF: "EF",
    EK: "EK",
    EC: "EC",
    ES: "ES",
    E1: "E1"
  };
  defaultAbfCompTierNames = {
    EE: "single",
    EF: "family",
    EK: "eeChild",
    EC: "eeChildren",
    ES: "eeSpouse",
    E1: "eeOne"
  };
  changeRateList: any[] = [];
  isRenewal: boolean = false;
  abfComponentKeys = ['asoAdminFee', 'sslPremium', 'aslPremium', 'terminalLiability', 'maxPaidClaim'];
  abfComponentDisplayKey = [{ key: 'asoAdminFee', value: 'Admin' }, { key: 'sslPremium', value: 'SSL Prem' },
  { key: 'aslPremium', value: 'ASL Prem' }, { key: 'terminalLiability', value: 'TL Fund' },
  { key: 'maxPaidClaim', value: 'Max CL Fund' }];
  showCompRateActionPrcnt: boolean = false;
  featurePlansSubject: any;
  componentPercentages: any = {};
  timeOut: any;
  mpcTimeOut: any;
  showMedicalPremiumComparison: boolean = false;
  monthlyTotal: number = 0;
  yearlyTotal: number = 0;
  private userHasInteracted: boolean = false;
  private hasScrolledToMPC: boolean = false;
  private interactionListener: () => void;
  constructor(@Inject(LOCALE_ID) private locale: string, private uwService: UnderwriterAdjustmentService, private scroller: ViewportScroller) { }
  ngOnDestroy(): void {
    this.featurePlansSubject.unsubscribe();
    if (this.interactionListener) {
      this.manageInteractionListeners(false);
    }
  }
  ngOnInit() {
    this.featurePlansSubject = this.uwService.featutePlanSupressSubject.subscribe(data => {
      this.enableOrDisableEnrollmentEdit(data.plans, data?.plan);
    })
    
    this.interactionListener = () => {
      this.userHasInteracted = true;
      this.manageInteractionListeners(false);
    };
    
    this.manageInteractionListeners(true);
    
    this.initializeComponentVariables();
  }

  private manageInteractionListeners(add: boolean): void {
    const action = add ? 'addEventListener' : 'removeEventListener';
    document[action]('mousedown', this.interactionListener, true);
    document[action]('keydown', this.interactionListener, true);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.quoteDetail && !changes.quoteDetail.firstChange) {
      this.tempMpcOnchange = true;
      this.initializeComponentVariables();

    }
    if (changes.mpcStatusChange && changes.mpcStatusChange.currentValue) {
      this.requestedTier = (this.quoteDetail && this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.outputTier)
        || (this.quoteDetail && this.quoteDetail.medicalOutputTier) || 1;

      this.calculateQuoteRates();
    }
  }

  initializeComponentVariables() {
    if (this.quoteDetail) {

      this.isRenewal = (this.quoteDetail && this.quoteDetail.opportunityType == 'Renewal Local');
      this.tierDescription = (this.quoteDetail["factors"] && this.quoteDetail["factors"].tierDescription) || {};
      this.calculatedLives = (this.quoteDetail["factors"] && this.quoteDetail["factors"].calculatedTierLives) || {};
      this.isVirginGroup = (this.quoteDetail["virginGroup"]) || false;
      this.enableIIPcheckbox = (this.quoteDetail["showMedicalPremiumComparison"]) || false;
      this.mpc = (this.quoteDetail["medicalPremiumComparison"]) || {};
      this.showMedicalPremiumComparison = Object.keys(this.mpc).length != 0 && this.mpc?.planComparison && this.mpc?.planComparison?.length > 0 ? true : false;

      if (this.isRenewal && this.mpc && this.mpc.planComparison && this.mpc.planComparison.length > 0 && !this.userHasInteracted && !this.hasScrolledToMPC) {
        setTimeout(() => {
          if (!this.userHasInteracted) {
            this.scroller.scrollToAnchor("targetToScroll");
            this.hasScrolledToMPC = true;
          }
        }, 100);
      }
      this.createTempQuoteRatingPlanID(this.mpc);
      this.requestedTier = (this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.outputTier)
        || (this.quoteDetail.medicalOutputTier) || 1;
      this.showCompRateActionPrcnt = false;
    }
    if (this.InitalQuoteDetail) {
      this.mpcInitialObj = (this.InitalQuoteDetail["medicalPremiumComparison"]) || {};
      this.createTempQuoteRatingPlanID(this.mpcInitialObj);
      this.initialTier = (this.InitalQuoteDetail.uwAdjustment && this.InitalQuoteDetail.uwAdjustment.outputTier)
        || (this.InitalQuoteDetail.medicalOutputTier) || 1;
    }

    if (this.quoteDetail && this.InitalQuoteDetail) {
      this.buildGuardRailErrorMessage();
      if (this.enableIIPcheckbox) {
        if (this.mpc.hasOwnProperty("includeInProposal") && this.mpc["includeInProposal"] != null) {
          this.includeInProposal = this.mpc["includeInProposal"];
        } else {
          this.includeInProposal = (this.mpcGuardrailErrorMessage == "");
        }
      } else {
        this.includeInProposal = false;
      }
    }
    if (this.isRenewal && this.quoteDetail && this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans && this.mpc && this.mpc.planComparison) {
      let featuredPlans = this.quoteDetail.medical.proposedPlans.filter(plan => plan.planTypeRequested == 'F' && plan.status && plan.status != 'Failed');
      let enableOther = this.checkSuprsdPlnToEnbl(featuredPlans);
      clearTimeout(this.mpcTimeOut);

      this.mpcTimeOut = setTimeout(() => {
        for (let plan of this.mpc.planComparison) {
          if (plan['disableEdit']) {
            delete plan['disableEdit'];
          }
          let proposedPlan = featuredPlans.find(p => p.contractCode == plan.quoteContractCode);
          if (proposedPlan && proposedPlan.includeInPrintExhibit != undefined && !proposedPlan.includeInPrintExhibit) {
            plan['disableEdit'] = true;
          } else {
            plan['disableEdit'] = !enableOther;
          }
          if (proposedPlan && proposedPlan['rateInfo']) {
            this.setValuesToProposedPlanTierRates(proposedPlan['rateInfo'], plan['proposedPlanTieredRates']);
          }
        }
        this.calculateComponentPercent(this.mpc.planComparison);
      });
    }
  }

  setValuesToProposedPlanTierRates(updatedRateInfo, proposedPlanTieredRates) {
    proposedPlanTieredRates['asoAdminFee'] = updatedRateInfo['asoFee'];
    proposedPlanTieredRates['sslPremium'] = updatedRateInfo['sslPremium'];
    proposedPlanTieredRates['aslPremium'] = updatedRateInfo['aslPremium'];
    proposedPlanTieredRates['terminalLiability'] = updatedRateInfo['terminalLiabilityFund'];
    proposedPlanTieredRates['maxPaidClaim'] = updatedRateInfo['maxPaidClaimsFund'];
  }

  createTempQuoteRatingPlanID(mpc: MedicalPremiumComparison) {
    if (mpc && mpc.planComparison) {
      mpc.planComparison.forEach(x => {
        if (!x.tempQuoteRatingPlanID && this.tempMpcOnchange && x.quoteRatingPlanID) {
          x.tempQuoteRatingPlanID = x.quoteRatingPlanID;
          x.quoteRatingPlanID = x.quoteRatingPlanID + "_" + x.currPlanId;
        }
      });
    }
  }

  buildGuardRailErrorMessage() {
    this.mpcGuardrailErrorMessage = "";
    let counter = 1;
    if (this.mpcInitialObj && this.quoteDetail && !this.quoteDetail["mpcGuardrailOverride"] && this.mpcInitialObj["guardRailStatus"]) {
      Object.keys(this.mpcInitialObj["guardRailStatus"]).map(item => {
        if (this.mpcInitialObj["guardRailStatus"][item].status === "Failed") {
          this.mpcGuardrailErrorMessage += counter + ") " + this.mpcInitialObj["guardRailStatus"][item].value + "\n";
          counter++;
        }
      });
    }
  }

  hasRenewalRates(plan): boolean {
    return plan && plan.hasRenewalRates;
  }

  getPlanInfo(type: string, plan): string {
    if (type == "C") {
      return ("Current Plan - " + plan.currentplanName + " (" + plan.currPlanId + ") " + " (" + plan.currentCarrierName + ")" + " - " + plan.currentFundingType);
    } else {
      return ("Featured Plan - " + plan.quoteContractCode + " - " + plan.quotePlanName + " (" + plan.quoteLegalEntity + ")");
    }
  }

  getColSpan(type: string, plan): number {
    if (type == "H") {
      return this.hasRenewalRates(plan) ? 2 : 1;
    } else if (type == "GHC") {
      return this.hasRenewalRates(plan) ? 4 : this.showCompRateActionPrcnt ? 8 : 3;
    } else if (type == "GHQ") {
      return this.isRenewal && this.showCompRateActionPrcnt ? 8 : 3;
    } else if (type == "GHD") {
      return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "R") && this.hasMonthlyTotal(plan, "C") ? 2 : 1;
    } else {
      if (this.hasRenewalRates(plan)) {
        if (!this.hasMonthlyTotal(plan, "C")) {
          return 7;
        } else {
          return this.getAbsoluteValue(this.getDifferencePecentage(plan, "C"), '') ? 7 : 8;
        }
      } else {
        return this.isRenewal && this.showCompRateActionPrcnt ? 16 : 6;
      }
    }
  }

  getColSpanGrand(showCompRateActionPrcnt): number {
    if (this.mpc.hasRenewalRates) {
      if (this.getrenewalIncreasePercentage("R")) {
        if (!this.hasMonthlyGrandTotal("C")) {
          return 3;
        } else {
          return 3;
        }
      } else {
        return 7;
      }
    } else {
      if (this.isRenewal) {
        return showCompRateActionPrcnt ? 10 : 5
      } else {
        return 6;
      }
    }
  }

  isTierApplicable(plan, tier: number, type: string): boolean {
    return type === 'Q' ? plan.quoteTier >= tier : plan.currentTier >= tier;
  }

  getMaxTier(plan): number {
    if (plan.quoteTier && plan.currentTier) {
      return (plan.currentTier > plan.quoteTier) ? plan.currentTier : plan.quoteTier;
    }
    return plan.currentTier || plan.quoteTier;
  }

  getEnrollmentTotal(plan, forType: string): number {
    if (forType == "C") {
      if (this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT' && plan.currentEnrollments2Comp && plan.currentEnrollments2Comp.totalEnroll) {
        return plan.currentEnrollments2Comp.totalEnroll;
      }
      if (this.quoteDetail?.oppOrigin?.originalRatingMethod !== '2COMPOSIT' && plan.currentEnrollments && plan.currentEnrollments.totalEnroll) {
        return plan.currentEnrollments.totalEnroll;
      }
    } else {
      if (plan.quoteEnrollments && plan.quoteEnrollments.totalEnroll) {
        return plan.quoteEnrollments.totalEnroll;
      }
    }
    return 0;
  }

  getMonthlyRate(plan, forType: string): number {
    if (forType == "C") {
      if (plan.currentRates && plan.currentRates.monthlyTotal) {
        return plan.currentRates.monthlyTotal;
      }
    } else if (forType == "R") {
      if (plan.renewalRates && plan.renewalRates.monthlyTotal) {
        return plan.renewalRates.monthlyTotal;
      }
    } else {
      if (plan.quoteRates && plan.quoteRates.monthlyTotal) {
        return plan.quoteRates.monthlyTotal;
      }
    }
    return 0;
  }

  hasMonthlyTotal(plan, forType: string): boolean {
    let total = this.getMonthlyRate(plan, forType);
    return this.isRenewal ? true : total && total !== 0;
  }

  hasMonthlyGrandTotal(forType: string): boolean {
    let total = this.getMonthlyTotalRate(forType);
    return this.isRenewal ? true : total && total !== 0;
  }

  getAnnualRate(plan, forType: string): number {
    if (forType == "C") {
      if (plan.currentRates && plan.currentRates.yearlyTotal) {
        return plan.currentRates.yearlyTotal;
      }
    } else if (forType == "R") {
      if (plan.renewalRates && plan.renewalRates.yearlyTotal) {
        return plan.renewalRates.yearlyTotal;
      }
    } else {
      if (plan.quoteRates && plan.quoteRates.yearlyTotal) {
        return plan.quoteRates.yearlyTotal;
      }
    }
    return 0;
  }

  getMonthlyRateDifference(plan, forType: string): number {
    if (forType == "C") {
      return plan.diffToCurrentMonthlyRate || 0;
    } else {
      return plan.diffToRenewalMonthlyRate || 0;
    }
  }

  getAnnualRateDifference(plan, forType: string): number {
    if (forType == "C") {
      return plan.diffToCurrentYearlyRate || 0;
    } else {
      return plan.diffToRenewalYearlyRate || 0;
    }
  }

  getDifferencePecentage(plan, forType: string): number {
    if (forType == "C") {
      return plan.diffToCurrentRatePercentage || 0;
    } else {
      return plan.diffToRenewalRatePercentage || 0;
    }
  }

  getMonthlyTotalRate(forType: string): number {
    if (forType == "C") {
      return (this.mpc.currentMonthlyGrandTotal || 0);
    } else if (forType == "R") {
      return (this.mpc.renewalMonthlyGrandTotal || 0);
    } else {
      return (this.mpc.quoteMonthlyGrandTotal || 0);
    }
  }

  getAnnualTotalRate(forType: string): number {
    if (forType == "C") {
      return (this.mpc.currentYearlyGrandTotal || 0);
    } else if (forType == "R") {
      return (this.mpc.renewalYearlyGrandTotal || 0);
    } else {
      return (this.mpc.quoteYearlyGrandTotal || 0);
    }
  }

  getMonthlyTotalRateDifference(forType: string): number {
    if (forType == "C") {
      return (this.mpc.diffToCurrentMonthlyTotal || 0);
    } else {
      return (this.mpc.diffToRenewalMonthlyTotal || 0);
    }
  }

  getAnnualTotalRateDifference(forType: string): number {
    if (forType == "C") {
      return (this.mpc.diffToCurrentYearlyTotal || 0);
    } else {
      return (this.mpc.diffToRenewalYearlyTotal || 0);
    }
  }

  getTotalDifferencePecentage(forType: string): number {
    if (forType == "C") {
      return this.mpc.diffToCurrentRatePercentage || 0;
    } else {
      return this.mpc.diffToRenewalRatePercentage || 0;
    }
  }

  getrenewalIncreasePercentage(forType: string): number {
    if (forType == "R") {
      return this.mpc.renewalIncreasePercentage || 0;
    }
  }

   getPlanEnrollment(plan, tierValue: number, forType: string): string | number {
    if (forType == "C") {
      // For 2COMPOSIT, return empty string for Tier 2 and Tier 4 to hide those cells
      if (this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT' && 
          (tierValue === 2 || tierValue === 4)) {
        return '';
      }
      if (
        this.quoteDetail?.oppOrigin?.originalRatingMethod !== '2COMPOSIT' &&
        plan.currentEnrollments &&
        (plan.currentEnrollments["enrollT" + tierValue] ||
          plan.currentEnrollments["enrollT" + tierValue] == 0)
      ) {
        return plan.currentEnrollments["enrollT" + tierValue];
      }
      if (
        this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT' &&
        plan.currentEnrollments2Comp &&
        (plan.currentEnrollments2Comp["enrollT" + tierValue] ||
          plan.currentEnrollments2Comp["enrollT" + tierValue] == 0)
      ) {
        return plan.currentEnrollments2Comp["enrollT" + tierValue];
      }
    } else {
      if (
        plan.quoteEnrollments &&
        (plan.quoteEnrollments["enrollT" + tierValue] ||
          plan.quoteEnrollments["enrollT" + tierValue] == 0)
      ) {
        return plan.quoteEnrollments["enrollT" + tierValue];
      }
    }
    return 0;
  }

  getPlanRate(plan, tierValue: number, forType: string, id?: string): string | number {
    let retValue;
    if (forType == "C") {
      if(this.quoteDetail?.oppOrigin?.originalRatingMethod === 'MEMBER'){
        return '';
      }
      // For 2COMPOSIT, return empty string for Tier 2 and Tier 4 to hide those cells
      if (this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT' && 
          (tierValue === 2 || tierValue === 4)) {
        return '';
      }
      if (plan.currentRates && (plan.currentRates["ratesT" + tierValue] || plan.currentRates["ratesT" + tierValue] == 0 && this.uwService.changeRateList.find(e => e.id == id) == undefined)) {
        retValue = plan.currentRates["ratesT" + tierValue];
      }
    } else if (forType == "R") {
      if(this.quoteDetail?.oppOrigin?.originalRatingMethod === 'MEMBER'){
        return '';
      }
      // For 2COMPOSIT, return empty string for Tier 2 and Tier 4 to hide those cells
      if (this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT' && 
          (tierValue === 2 || tierValue === 4)) {
        return '';
      }
      if (plan.renewalRates && (plan.renewalRates["ratesT" + tierValue] || (plan.renewalRates["ratesT" + tierValue] == 0 && this.uwService.changeRateList.find(e => e.id == id) == undefined))) {
        retValue = plan.renewalRates["ratesT" + tierValue];
      }
    } else {
      if (plan.quoteRates && (plan.quoteRates["ratesT" + tierValue] || (plan.quoteRates["ratesT" + tierValue] == 0 && this.uwService.changeRateList.find(e => e.id == id) == undefined))) {
        retValue = plan.quoteRates["ratesT" + tierValue];
      }
    }
    if (isNaN(retValue)) {
      return retValue;
    }
    if (retValue == 0 && ((this.quoteDetail?.oppOrigin && this.quoteDetail?.oppOrigin?.ratingMethod === CommonConstants.MEMBER_RATED) || (plan.currentFundingType === CommonConstants.ACA && (plan.quoteFundingType === CommonConstants.ABF || plan.quoteFundingType === CommonConstants.FI))
    )) {
      return "";
    }
    return formatCurrency(retValue, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
  }

   getTierName(plan, tierValue: number, forType: string): string {
    if (forType == "C" || forType == "R") {
      if (tierValue <= plan.currentTier) {
        return this.getTierEmpDesc(tierValue, plan.currentTier, forType);
      }
    } else {
      if (tierValue <= plan.quoteTier) {
        return this.getTierEmpDesc(tierValue, plan.quoteTier, forType);
      }
    }
    return "";
  }

  getTierEmpDesc(tierNumber: number, availableTiers: number, forType?: string): string {
    // For 2COMPOSIT in Current section: Adult = Tier 1, Child = Tier 3
    // Return empty string for Tier 2 and Tier 4 to hide those rows
    if (this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT' && 
        (forType === 'C')) {
      if (tierNumber == 1) {
        return 'Adult';
      } else if (tierNumber == 3) {
        return 'Child';
      } else if (tierNumber == 2 || tierNumber == 4) {
        return ''; // Hide Tier 2 (ES) and Tier 4 (EF) rows
      }
    }
    let tieredValue = this.isRenewal ? this.defaultTierNames : this.tierDescription[availableTiers + "-Tier"];
    if (!tieredValue) {
      tieredValue = this.defaultTierNames;
    }
    switch (availableTiers) {
      case 1:
        if (tierNumber == 1) {
          return tieredValue.EE;
        }
        break;
      case 2:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.EF;
        }
        break;
      case 3:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.E1;
        } else if (tierNumber == 3) {
          return tieredValue.EF;
        }
        break;
      case 4:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EC;
        } else if (tierNumber == 4) {
          return tieredValue.EF;
        }
        break;
      case 5:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EK;
        } else if (tierNumber == 4) {
          return tieredValue.EC;
        } else if (tierNumber == 5) {
          return tieredValue.EF;
        }
        break;
    }
    return "";
  }

  calculateQuoteEnrollments(en, qt) {
    en.totalEnroll = 0;
    switch (qt * 1) {
      case 1:
        if (!en.enrollT1) en.enrollT1 = 0;
        en.enrollT2 = null;
        en.enrollT3 = null;
        en.enrollT4 = null;
        en.enrollT5 = null;
        break;
      case 2:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        en.enrollT3 = null;
        en.enrollT4 = null;
        en.enrollT5 = null;
        break;
      case 3:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        if (!en.enrollT3) en.enrollT3 = 0;
        en.enrollT4 = null;
        en.enrollT5 = null;
        break;
      case 4:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        if (!en.enrollT3) en.enrollT3 = 0;
        if (!en.enrollT4) en.enrollT4 = 0;
        en.enrollT5 = null;
        break;
      case 5:
        if (!en.enrollT1) en.enrollT1 = 0;
        if (!en.enrollT2) en.enrollT2 = 0;
        if (!en.enrollT3) en.enrollT3 = 0;
        if (!en.enrollT4) en.enrollT4 = 0;
        if (!en.enrollT5) en.enrollT5 = 0;
        break;
    }
    for (let i = 1; i <= 5; i++) {
      en.totalEnroll += this.getCalculatedEnrollments(en, i);
    }
    return en;
  }
  calculateQuoteRates() {
    if (this.mpc && Object.keys(this.mpc).length > 0) {
      this.mpc.planComparison.forEach((pc: PlanComparison) => {
        pc = this.setEnrollmentsOnTierChange(pc);
      });
      this.calculateGrandTotal();
    }
  }

  private setEnrollmentsOnTierChange(pc: PlanComparison) {
    if (pc.quoteRates && pc.tempQuoteRatingPlanID) {
      let filteredPlan = this.getPlan(pc.tempQuoteRatingPlanID);
      pc.quoteTier = this.requestedTier * 1;
      if (filteredPlan) {
        pc.quoteRates = this.calculateRates(filteredPlan);
        if (this.isRenewal && this.quoteDetail && this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans) {
          let plan = this.quoteDetail.medical.proposedPlans.find(p => p.contractCode == pc.quoteContractCode);
          if (plan && plan.includeInPrintExhibit != undefined && !plan.includeInPrintExhibit) {
            this.updateEnrolmentCounts(pc.quoteEnrollments, (this.requestedTier * 1));
            return pc;
          }
        }
        if (pc.quoteTier === this.initialTier) {
          if (this.mpc.userModified && !pc['calWholeCase']) {
            pc.quoteEnrollments = this.calculateQuoteEnrollments(
              this.getMPCinitialPlan(pc.quoteRatingPlanID).quoteEnrollments,
              this.requestedTier
            );
          }
          else if (pc.quoteTier === pc.currentTier && !this.isVirginGroup) {
            let cEnrollment = Object.assign({}, this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT' ? pc.quoteEnrollments : pc.currentEnrollments);
            pc.quoteEnrollments = this.calculateQuoteEnrollments(cEnrollment, this.requestedTier);
          }
          else {
            pc.quoteEnrollments = this.calculateEnrollments(filteredPlan,null,pc.currPlanId);
          }
        }
        else {
          if (pc.quoteTier === pc.currentTier && !this.isVirginGroup) {
            let cEnrollment = Object.assign({}, pc.currentEnrollments);
            pc.quoteEnrollments = this.calculateQuoteEnrollments(cEnrollment, this.requestedTier);
          }
          else {
            pc.quoteEnrollments = this.calculateEnrollments(filteredPlan,null,pc.currPlanId);
          }
        }
        pc.quoteRates = this.calculateQuoteTotal(pc.quoteRates, pc.quoteEnrollments);
      }
      pc = this.calculateQuoteDifferences(pc);
    }
    return pc;
  }

  getPlan(ratingPlanID: string) {
    let plan = this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans ? this.quoteDetail.medical.proposedPlans.filter(pl => pl.ratingPlanID == ratingPlanID) : [];
    if (plan.length > 0) {
      return plan[0];
    }
    return null;
  }

  calculateRates(plan): PlanRates {
    let pr: PlanRates = new PlanRates();
    if (plan && plan.rateInfo) {
      pr.ratesT1 = plan.rateInfo.single || 0;
      switch (this.requestedTier * 1) {
        case 2:
          pr.ratesT2 = plan.rateInfo.family || 0;
          break;
        case 3:
          pr.ratesT2 = plan.rateInfo.eeOne || 0;
          pr.ratesT3 = plan.rateInfo.family || 0;
          break;
        case 4:
          pr.ratesT2 = plan.rateInfo.eeSpouse || 0;
          pr.ratesT3 = plan.rateInfo.eeChildren || 0;
          pr.ratesT4 = plan.rateInfo.family || 0;
          break;
        case 5:
          pr.ratesT2 = plan.rateInfo.eeSpouse || 0;
          pr.ratesT3 = plan.rateInfo.eeChild || 0;
          pr.ratesT4 = plan.rateInfo.eeChildren || 0;
          pr.ratesT5 = plan.rateInfo.family || 0;
          break;
      }
    }
    return pr;
  }

  calculateEnrollments(plan, tier?: any, currentPlanIDFromPC?:any): Enrollments {
    let en = new Enrollments();
    let index = tier ? (tier + '-tier') : (this.requestedTier + '-tier');
    let lives = this.calculatedLives ? this.calculatedLives[index] : {};
    if (!tier && this.requestedTier && this.isRenewal) {
      //this means that the underwriter has done a tierChange selection on the Renewal quoteDetailPage
      //in such cases as per ALGR-90969 use the actual census instead of wholecase
      let currentPlanID;
      if (StringUtils.isEmpty(currentPlanIDFromPC)) {
        if (typeof (plan.currPlanId) == 'string') {
          currentPlanID = plan.currPlanId;
        }
        else {
          currentPlanID = plan.currPlanId[0];
        }
      }
      else {
        currentPlanID = currentPlanIDFromPC;
      }
      var matchingPlanComparison;
      if (this.quoteDetail.medicalPremiumComparison && this.quoteDetail.medicalPremiumComparison.planComparison) {
        for (const element of this.quoteDetail.medicalPremiumComparison.planComparison) {
          if (element.currPlanId === currentPlanID) {
            matchingPlanComparison = element;
            break;
          }
        }
        if (matchingPlanComparison && matchingPlanComparison.tierAdjustedLivesMap && matchingPlanComparison.tierAdjustedLivesMap[index]) {
          lives = matchingPlanComparison.tierAdjustedLivesMap[index];
        }
      }
    }

    if (lives) {
      en.enrollT1 = lives.eeCount * 1;
      en.totalEnroll = 0;
      switch (tier ? (tier * 1) : (this.requestedTier * 1)) {
        case 2:
          en.enrollT2 = (lives.efCount || 0) * 1;
          break;
        case 3:
          en.enrollT2 = (lives.e1Count || 0) * 1;
          en.enrollT3 = (lives.efCount || 0) * 1;
          break;
        case 4:
          en.enrollT2 = (lives.esCount || 0) * 1;
          en.enrollT3 = (lives.ecCount || 0) * 1;
          en.enrollT4 = (lives.efCount || 0) * 1;
          break;
        case 5:
          en.enrollT2 = (lives.esCount || 0) * 1;
          en.enrollT3 = (lives.ekCount || 0) * 1;
          en.enrollT4 = (lives.ecCount || 0) * 1;
          en.enrollT5 = (lives.efCount || 0) * 1;
          break;
      }
      for (let i = 1; i <= 5; i++) {
        en.totalEnroll += this.getCalculatedEnrollments(en, i);
      }
    }
    return en;
  }

  calculateFourAndTwoCompositeEnrollments(): Enrollments{
    let en = new Enrollments();
    let tier = this.requestedTier;    
    let index = this.requestedTier + '-tier';
    let lives = this.calculatedLives ? this.calculatedLives[index] : {};
    if (lives) {
      en.enrollT1 = lives.eeCount * 1;
      en.totalEnroll = 0;
      switch (tier ? (tier * 1) : (this.requestedTier * 1)) {
        case 2:
          en.enrollT2 = (lives.efCount || 0) * 1;
          break;
        case 3:
          en.enrollT2 = (lives.e1Count || 0) * 1;
          en.enrollT3 = (lives.efCount || 0) * 1;
          break;
        case 4:
          en.enrollT2 = (lives.esCount || 0) * 1;
          en.enrollT3 = (lives.ecCount || 0) * 1;
          en.enrollT4 = (lives.efCount || 0) * 1;
          break;
        case 5:
          en.enrollT2 = (lives.esCount || 0) * 1;
          en.enrollT3 = (lives.ekCount || 0) * 1;
          en.enrollT4 = (lives.ecCount || 0) * 1;
          en.enrollT5 = (lives.efCount || 0) * 1;
          break;
      }
      for (let i = 1; i <= 5; i++) {
        en.totalEnroll += this.getCalculatedEnrollments(en, i);
      }
    }
    return en;
  }

  roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }

  calculateQuoteTotal(pr: PlanRates, en: Enrollments): PlanRates {
    pr.monthlyTotal = 0;
    for (let i = 1; i <= 5; i++) {
      pr.monthlyTotal += this.getCalculatedRates(en, pr, i);
    }
    pr.yearlyTotal = this.roundedValue(pr.monthlyTotal * 12);
    return pr;
  }

  calculateQuoteDifferences(pc: PlanComparison): PlanComparison {
    pc.diffToCurrentMonthlyRate = pc.quoteRates.monthlyTotal - pc.currentRates.monthlyTotal;
    pc.diffToCurrentYearlyRate = pc.quoteRates.yearlyTotal - pc.currentRates.yearlyTotal;
    if (pc.currentRates.monthlyTotal)
      pc.diffToCurrentRatePercentage = pc.diffToCurrentMonthlyRate / pc.currentRates.monthlyTotal;
    else pc.diffToCurrentRatePercentage = 0;
    if (pc.hasRenewalRates) {
      pc.diffToRenewalMonthlyRate = pc.quoteRates.monthlyTotal - pc.renewalRates.monthlyTotal;
      pc.diffToRenewalYearlyRate = pc.quoteRates.yearlyTotal - pc.renewalRates.yearlyTotal;
      pc.diffToRenewalRatePercentage = pc.diffToRenewalMonthlyRate / pc.renewalRates.monthlyTotal;
    }
    return pc;
  }

  calculateGrandTotal() {
    this.mpc.currentMonthlyGrandTotal = 0;
    this.mpc.currentYearlyGrandTotal = 0;
    this.mpc.quoteMonthlyGrandTotal = 0;
    this.mpc.quoteYearlyGrandTotal = 0;
    this.mpc.renewalMonthlyGrandTotal = 0;
    this.mpc.renewalYearlyGrandTotal = 0;
    let hasRenewalRates: boolean = false;
    this.mpc.planComparison.forEach((pc: PlanComparison) => {
      if (pc.quoteRates && pc.quoteRatingPlanID) {
        if (pc.currentRates.monthlyTotal && pc.currentRates.yearlyTotal != undefined) {
          this.mpc.currentMonthlyGrandTotal += pc.currentRates.monthlyTotal;
          this.mpc.currentYearlyGrandTotal += pc.currentRates.yearlyTotal;
        }
        if (pc.quoteRates.monthlyTotal && pc.quoteRates.yearlyTotal != undefined) {
          this.mpc.quoteMonthlyGrandTotal += pc.quoteRates.monthlyTotal;
          this.mpc.quoteYearlyGrandTotal += pc.quoteRates.yearlyTotal;
        }
        if (pc.hasRenewalRates) {
          this.mpc.renewalMonthlyGrandTotal += pc.renewalRates.monthlyTotal;
          this.mpc.renewalYearlyGrandTotal += pc.renewalRates.yearlyTotal;
          hasRenewalRates = true;
        }
      }
    });

    this.mpc.diffToCurrentMonthlyTotal = this.mpc.quoteMonthlyGrandTotal - this.mpc.currentMonthlyGrandTotal;
    this.mpc.diffToCurrentYearlyTotal = this.mpc.quoteYearlyGrandTotal - this.mpc.currentYearlyGrandTotal;
    if (this.mpc.currentMonthlyGrandTotal)
      this.mpc.diffToCurrentRatePercentage = this.mpc.diffToCurrentMonthlyTotal / this.mpc.currentMonthlyGrandTotal;
    else this.mpc.diffToCurrentRatePercentage = 0;

    if (hasRenewalRates) {
      this.mpc.diffToRenewalMonthlyTotal =
        this.mpc.quoteMonthlyGrandTotal - this.mpc.renewalMonthlyGrandTotal;
      this.mpc.diffToRenewalYearlyTotal =
        this.mpc.quoteYearlyGrandTotal - this.mpc.renewalYearlyGrandTotal;
      if (this.mpc.renewalMonthlyGrandTotal) {
        this.mpc.diffToRenewalRatePercentage = this.mpc.diffToRenewalMonthlyTotal / this.mpc.renewalMonthlyGrandTotal;
        this.mpc.differenceToCurrentRenewalYearlyTotal = this.mpc.renewalYearlyGrandTotal - this.mpc.currentYearlyGrandTotal;
        this.mpc.renewalIncreasePercentage = this.mpc.differenceToCurrentRenewalYearlyTotal / this.mpc.currentYearlyGrandTotal;
      } else {
        this.mpc.diffToRenewalRatePercentage = 0;
        this.mpc.renewalIncreasePercentage = 0;
      }
    }
  }

  classHighlighter(value): string {
    return value * 1 > 0 ? "higher" : "lesser";
  }
  getPercentValue(value: number) {
    if (value && value != Infinity) {
      return formatPercent(value, this.locale, '1.2-4');
    }
    else {
      return 0;
    }
  }
  getAbsoluteValue(value: number, type?: string): number | string {
    if (value && value != Infinity) {
      if (type == 'percent') {
        return formatPercent(Math.abs(value), this.locale, '1.2-2');
      }
      return formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.0-0');
    }
    return 0;
  }

  getMPCplan(planID) {
    return this.mpc.planComparison.find(x => x.quoteRatingPlanID === planID);
  }

  getMPCinitialPlan(planID) {
    let plan = this.mpcInitialObj.planComparison.find(
      x => x.quoteRatingPlanID === planID
    );
    return JSON.parse(JSON.stringify(plan));
  }

  getCalculatedEnrollments(enrollment: Enrollments, index: number): number {
    let tierEnroll = enrollment["enrollT" + index];
    return tierEnroll && !isNaN(tierEnroll) ? tierEnroll * 1 : 0;
  }

  getCalculatedRates(enrollment: Enrollments, rate: PlanRates, index: number): number {
    let tierRate: string = '' + rate["ratesT" + index];
    if (tierRate) {
      tierRate = tierRate.replace("$", "").replace(/,/g, "");
    }
    return tierRate && !isNaN(parseFloat(tierRate)) ? parseFloat(tierRate) * this.getCalculatedEnrollments(enrollment, index) * 1 : 0;
  }

  getTotalEnrollment(plan, forType: string) {
    let total = 0;
    if (forType === "C") {
      for (let i = 1; i <= 5; i++) {
        total += this.getCalculatedEnrollments(this.quoteDetail?.oppOrigin?.originalRatingMethod === '2COMPOSIT' ? plan.currentEnrollments2Comp : plan.currentEnrollments, i);
      }
    } else if (forType === "Q") {
      for (let i = 1; i <= 5; i++) {
        total += this.getCalculatedEnrollments(plan.quoteEnrollments, i);
      }
    }
    return total;
  }

  getMonthlyTotal(plan, forType: string) {

    let monthTotal = 0;
    if (forType === "C") {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.currentEnrollments, plan.currentRates, i);
      }
    } else if (forType === "R") {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.currentEnrollments, plan.renewalRates, i);
      }
    } else if (forType === "Q") {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.quoteEnrollments, plan.quoteRates, i);
      }
    }
    return monthTotal;
  }

  getAnnualTotal(plan, forType: string) {
    let yearTotal = 0;
    if (forType === "C" || forType === "R" || forType === "Q") {
      yearTotal = this.getMonthlyTotal(plan, forType) * 12;
    }
    return this.roundedValue(yearTotal);
  }

  getAnnualTotalNotRecalcutaleMonthlyTotal(monthlyTotal) {
    let yearTotal = 0;
    if (monthlyTotal) {
      yearTotal = monthlyTotal * 12;
    }
    return this.roundedValue(yearTotal);
  }

  updateMPC($event, plan, tierValue: number, forType: string) {
    let mpcPlan = this.getMPCplan(plan.quoteRatingPlanID);
    if (forType == "CE") {
      this.checkAndSetInvalidRates($event, $event.target.value);
      mpcPlan.currentEnrollments["enrollT" + tierValue] = $event.target.value;


      mpcPlan.currentEnrollments.totalEnroll = this.getTotalEnrollment(mpcPlan, "C");
      mpcPlan.currentRates.monthlyTotal = this.getMonthlyTotal(mpcPlan, "C");
      mpcPlan.currentRates.yearlyTotal = this.getAnnualTotal(mpcPlan, "C");
      mpcPlan.renewalRates.monthlyTotal = this.getMonthlyTotal(mpcPlan, "R");
      mpcPlan.renewalRates.yearlyTotal = this.getAnnualTotal(mpcPlan, "R");
      this.calculateQuoteRatesForUpdate();
    } else if (forType == "QE") {
      this.checkAndSetInvalidRates($event, $event.target.value);
      mpcPlan.quoteEnrollments["enrollT" + tierValue] = $event.target.value;
      mpcPlan.quoteEnrollments.totalEnroll = this.getTotalEnrollment(mpcPlan, "Q");
      mpcPlan.quoteRates.monthlyTotal = this.getMonthlyTotal(mpcPlan, "Q");
      mpcPlan.quoteRates.yearlyTotal = this.getAnnualTotal(mpcPlan, "Q");
      this.calculateQuoteRatesForUpdate();
    } else if (forType == "CR") {
      let value = $event.target.value;
      value = value.replace("$", "").replace(/,/g, "");
      if (isNaN(value)) {
        mpcPlan.currentRates["ratesT" + tierValue] = $event.target.value;
      } else {
        mpcPlan.currentRates["ratesT" + tierValue] = (+value).toFixed(2);
      }
      if (value == '') {
        mpcPlan.currentRates["ratesT" + tierValue] = '';
      }
      this.checkAndSetInvalidRates($event, value);
      mpcPlan.currentRates.monthlyTotal = this.getMonthlyTotal(mpcPlan, "C");
      mpcPlan.currentRates.yearlyTotal = this.getAnnualTotal(mpcPlan, "C");
      this.calculateQuoteRatesForUpdate();
    } else if (forType == "RR") {
      let value = $event.target.value;
      value = value.replace("$", "").replace(/,/g, "");

      if (isNaN(value)) {
        mpcPlan.renewalRates["ratesT" + tierValue] = $event.target.value;
      } else {
        mpcPlan.renewalRates["ratesT" + tierValue] = (+value).toFixed(2);
      }
      if (value == '') {
        mpcPlan.renewalRates["ratesT" + tierValue] = '';
      }
      this.checkAndSetInvalidRates($event, value);

      mpcPlan.renewalRates.monthlyTotal = this.getMonthlyTotal(mpcPlan, "R");
      mpcPlan.renewalRates.yearlyTotal = this.getAnnualTotal(mpcPlan, "R");
      this.calculateQuoteRatesForUpdate();
    }
    var inValidRate = this.verifyEnteredRates();
    this.checkValidPremiumRates.emit(inValidRate);
  }

  verifyEnteredRates() {
    return this.uwService.changeRateList.find(e => e.valid == false) != undefined;
  }

  private checkAndSetInvalidRates($event, value): void {
    const index = this.uwService.changeRateList.findIndex(e => e.id == $event.target.id);
    if (index != -1) {
      this.uwService.changeRateList[index].valid = value == '' ? false : !isNaN(value);
    } else {
      this.uwService.changeRateList.push({ id: $event.target.id, valid: (value != '' && !isNaN(value)) });
    }
  }

  calculateQuoteRatesForUpdate() {
    this.mpc.planComparison.forEach((pc: PlanComparison) => {
      if (pc.quoteRates && pc.tempQuoteRatingPlanID) {
        let filteredPlan = this.getPlan(pc.tempQuoteRatingPlanID);
        pc.quoteTier = this.requestedTier * 1;
        if (filteredPlan) {
          pc = this.calculateQuoteDifferences(pc);
        }
      }
    });
    this.calculateGrandTotal();
  }

  checkIsValid(event, type: string, id) {
    if (this.isRenewal && this.showCompRateActionPrcnt) {
      return "renewalWidth";
    }
    if (type == "currency") {
      event = ("" + event).replace("$", "").replace(/,/g, "");
    }

    var foundChange = this.uwService.changeRateList.find(e => e.id == id);

    if (foundChange && !foundChange.valid) {
      return 'redContent';
    }
    if (event == undefined || event == 'undefined') {
      return '';
    }
    if (!isNaN(event)) {
      return "";
    } else {
      return "redContent";
    }
  }

  isNumber(event) {
    return !(event.charCode > 31 && (event.charCode < 48 || event.charCode > 57));
  }

  isCurency(evt) {
    var el = evt.target;
    var charCode = evt.charCode;
    var number = el.value.split(".");
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (number.length > 1 && charCode == 46) {
      return false;
    }
    var caratPos = this.getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && number[1].length > 1) {
      return false;
    }
    return true;
  }

  getSelectionStart(o) {
    return o.selectionStart;
  }

  isDisabled(plan, tierValue: number, forType: string): string {
    if (!plan.quoteRatingPlanID) {
      return "";
    } else {
      if (forType == "C" || forType == "R") {
        if (tierValue <= plan.currentTier) {
          return this.getTierEmpDesc(tierValue, plan.currentTier);
        }
      } else {
        if (tierValue <= plan.quoteTier) {
          return this.getTierEmpDesc(tierValue, plan.quoteTier);
        }
      }
    }
    return "";
  }

  checkIsDisabled(plan, tierValue: number, forType: string) {
    let value = this.isDisabled(plan, tierValue, forType);
    if (value && !this.isRenewal) return "";
    else return "mpcGray";
  }

  userUpdatatedIIPValue() {
    this.mpc["includeInProposalOverride"] = true;
    this.mpc["includeInProposal"] = this.includeInProposal;
  }


  getAbfCompDisplayLabel(key: string): string {
    return this.abfComponentDisplayKey.find(data => data.key == key).value;
  }

  showAbfRates() {
    this.showCompRateActionPrcnt = !this.showCompRateActionPrcnt;
  }

  getAbfComponentRates(plan: any, type: string, compName: string, tierValue: number) {
    if (type == "C") {
      if (tierValue <= plan.currentTier) {
        let abfRates = this.getTierAbfCompRates(plan, tierValue, compName, plan.currentTier, type);
        return formatCurrency(abfRates, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      }
    } else {
      if (tierValue <= plan.quoteTier) {
        let abfRates = this.getTierAbfCompRates(plan, tierValue, compName, plan.quoteTier, type);
        return formatCurrency(abfRates, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
      }
    }
  }
  getTierAbfCompRates(plan, tierNumber: number, compName: string, availableTiers: number, type: string): number {
    let planType;
    if (type == 'C') {
      if (plan && plan.currentPlanTieredRates && plan.currentPlanTieredRates[compName]) {
        planType = plan.currentPlanTieredRates[compName];
      }
    } else if (type == 'P') {
      if (plan && plan.proposedPlanTieredRates && plan.proposedPlanTieredRates[compName]) {
        planType = plan.proposedPlanTieredRates[compName];
      }
    }
    if (planType != undefined) {
      switch (availableTiers) {
        case 1:
          if (tierNumber == 1) {
            return planType[this.defaultAbfCompTierNames.EE];
          }
          break;
        case 2:
          if (tierNumber == 1) {
            return planType[this.defaultAbfCompTierNames.EE];
          } else if (tierNumber == 2) {
            return planType[this.defaultAbfCompTierNames.EF];
          }
          break;
        case 3:
          if (tierNumber == 1) {
            return planType[this.defaultAbfCompTierNames.EE];
          } else if (tierNumber == 2) {
            return planType[this.defaultAbfCompTierNames.E1];
          } else if (tierNumber == 3) {
            return planType[this.defaultAbfCompTierNames.EF];
          }
          break;
        case 4:
          if (tierNumber == 1) {
            return planType[this.defaultAbfCompTierNames.EE];
          } else if (tierNumber == 2) {
            return planType[this.defaultAbfCompTierNames.ES];
          } else if (tierNumber == 3) {
            return planType[this.defaultAbfCompTierNames.EC];
          } else if (tierNumber == 4) {
            return planType[this.defaultAbfCompTierNames.EF];
          }
          break;
        case 5:
          if (tierNumber == 1) {
            return planType[this.defaultAbfCompTierNames.EE];
          } else if (tierNumber == 2) {
            return planType[this.defaultAbfCompTierNames.ES];
          } else if (tierNumber == 3) {
            return planType[this.defaultAbfCompTierNames.EK];
          } else if (tierNumber == 4) {
            return planType[this.defaultAbfCompTierNames.EC];
          } else if (tierNumber == 5) {
            return planType[this.defaultAbfCompTierNames.EF];
          }
          break;
      }
    }
    return 0;
  }

  private checkSuprsdPlnToEnbl(plans: any[]) {
    return plans.find(plan => plan.includeInPrintExhibit != undefined && !plan.includeInPrintExhibit) != undefined;
  }

  /**
   * Function to enable or disable edit for enrollment details in current plans.
   * @param featuredPlans
   */
  enableOrDisableEnrollmentEdit(featuredPlans: any[], selectedPlan?: any) {
    clearTimeout(this.timeOut);
    this.timeOut = setTimeout(() => {
      if (featuredPlans && featuredPlans.length > 0) {
        let enableOther = this.checkSuprsdPlnToEnbl(featuredPlans);
        this.mpc.planComparison.forEach(currentPlan => {
          if (currentPlan['disableEdit']) {
            delete currentPlan['disableEdit'];
          }
          let featuredPlan = featuredPlans.find(featuredPlan => StringUtils.isEqual(featuredPlan.contractCode, currentPlan.quoteContractCode));
          if (featuredPlan && featuredPlan.includeInPrintExhibit != undefined && !featuredPlan.includeInPrintExhibit) {
            currentPlan['suppressed'] = true;
            this.setOrUnsetEnrollments(currentPlan, true, true, false);
          } else {
            currentPlan['suppressed'] = false;
            if(selectedPlan && StringUtils.isEqual(selectedPlan.contractCode, currentPlan.quoteContractCode)) {
              this.setOrUnsetEnrollments(currentPlan, false, !enableOther, true);
            }
            else {
              this.setOrUnsetEnrollments(currentPlan, false, !enableOther, false);
            }
          }
        })
        this.calculateGrandTotal();
        this.calculateComponentPercent(this.mpc.planComparison);
      }
    }, 500)

  }

  private setOrUnsetEnrollments(plan: any, update: boolean, enableOther: boolean, skipModifiedEnroll: boolean) {
    let currTier = plan.currentTier;
    let quoteTier = plan.quoteTier;
    if(this.quoteDetail?.oppOrigin?.ratingMethod === CommonConstants.MEMBER_RATED && plan.currentRates.monthlyTotal !== 0 && plan.currentRates.yearlyTotal !== 0) {
     this.monthlyTotal = plan.currentRates.monthlyTotal;
     this.yearlyTotal = plan.currentRates.yearlyTotal;
    }
    if (update) {
      this.updateEnrolmentCounts(plan.quoteEnrollments, quoteTier);
      this.updateEnrolmentCounts(this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT' ? plan.currentEnrollments2Comp : plan.currentEnrollments, currTier);
      const enrollments = this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT'
        ? plan.currentEnrollments2Comp
        : plan.currentEnrollments;
      enrollments.totalEnroll = 0;
      plan.currentRates.monthlyTotal = 0;
      plan.currentRates.yearlyTotal = 0;
      plan.renewalRates.monthlyTotal = 0;
      plan.renewalRates.yearlyTotal = 0;
      plan.quoteEnrollments.totalEnroll = 0;
      plan.quoteRates.monthlyTotal = 0;
      plan.quoteRates.yearlyTotal = 0;
    } else {
      if (!(enableOther)) {
        let currEnroll = this.calculateEnrollments(plan, currTier);
        if (currTier != quoteTier) {
          let quoteEnroll = this.calculateEnrollments(plan);
          this.updateEnrlmntsToOriginal(plan.quoteEnrollments, quoteTier, quoteEnroll);

        } else if(this.isRenewal && this.isEnrollemntsUpdated(plan,currEnroll) && !skipModifiedEnroll){
          //this means that the user has done a enrollment update on the Renewal quoteDetailPage after supress the plan
          //in such cases as per ALGR-98944 use the MedicalPremium node to update enrollments instead of wholecase(caluclatedTierLives)
          this.updateEnrollmentFromMPC(plan);
        } 
        else {
          this.updateEnrlmntsToOriginal(this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT' ? plan.currentEnrollments2Comp : plan.currentEnrollments,
            currTier,
            this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT'
              ? plan.initialCurrentEnrollments2Comp
              : currEnroll);
          this.updateEnrlmntsToOriginal(plan.quoteEnrollments, quoteTier, currEnroll);
        }

      } else {
        if (currTier != quoteTier) {
          let quoteEnroll = this.calculateEnrollments(plan);
          this.updateEnrlmntsToOriginal(plan.quoteEnrollments, currTier, quoteEnroll);
        } else {
            this.updateEnrlmntsToOriginal(
              plan.quoteEnrollments,
              quoteTier,
              this.quoteDetail?.oppOrigin?.originalRatingMethod == '4COMPOSIT' || this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT'
                ? this.calculateFourAndTwoCompositeEnrollments()
                : plan.initialCurrentEnrollments
            );
        }
          this.updateEnrlmntsToOriginal(
            this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT' ? plan.currentEnrollments2Comp : plan.currentEnrollments,
            currTier,
            this.quoteDetail?.oppOrigin?.originalRatingMethod == '4COMPOSIT'
              ? this.calculateFourAndTwoCompositeEnrollments()
              : this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT'
                ? plan.initialCurrentEnrollments2Comp
                : plan.initialCurrentEnrollments
          );
        if (this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT') {
          this.updateEnrlmntsToOriginal(
            plan.currentEnrollments,
            currTier,
            plan.initialCurrentEnrollments
          );
        }
      }
      const enrollments = this.quoteDetail?.oppOrigin?.originalRatingMethod == '2COMPOSIT'
        ? plan.currentEnrollments2Comp
        : plan.currentEnrollments;
      enrollments.totalEnroll = this.getTotalEnrollment(plan, "C");
      // for member rated quotes, current rates should not be recalculated
      if (!this.quoteDetail?.oppOrigin || this.quoteDetail?.oppOrigin?.ratingMethod !== CommonConstants.MEMBER_RATED || this.quoteDetail?.oppOrigin?.originalRatingMethod) {
        plan.currentRates.monthlyTotal = this.quoteDetail?.oppOrigin?.originalRatingMethod ? (plan.initialCurrentMonthlyTotal ?? 0) : this.getMonthlyTotal(plan, "C");
        plan.currentRates.yearlyTotal = this.quoteDetail?.oppOrigin?.originalRatingMethod ? this.getAnnualTotalNotRecalcutaleMonthlyTotal(plan.currentRates.monthlyTotal) : this.getAnnualTotal(plan, "C");
      }
      if (this.quoteDetail?.oppOrigin?.ratingMethod === CommonConstants.MEMBER_RATED && !this.quoteDetail?.oppOrigin?.originalRatingMethod && plan.currentRates.monthlyTotal === 0 && plan.currentRates.yearlyTotal === 0) {
        plan.currentRates.monthlyTotal = this.monthlyTotal;
        plan.currentRates.yearlyTotal = this.yearlyTotal;
      }
      if (this.hasRenewalRates(plan)) {
        plan.renewalRates.monthlyTotal = this.quoteDetail?.oppOrigin?.originalRatingMethod ? (plan.initialRenewalMonthlyTotal ?? 0) : this.getMonthlyTotal(plan, "R");;
        plan.renewalRates.yearlyTotal = this.quoteDetail?.oppOrigin?.originalRatingMethod ? this.getAnnualTotalNotRecalcutaleMonthlyTotal(plan.renewalRates.monthlyTotal) : this.getAnnualTotal(plan, "R");
      }
      plan.quoteEnrollments.totalEnroll = this.getTotalEnrollment(plan, "Q");
      plan.quoteRates.monthlyTotal = this.getMonthlyTotal(plan, "Q");
      plan.quoteRates.yearlyTotal = this.getAnnualTotal(plan, "Q");
    }
    plan['disableEdit'] = enableOther;
    this.calculateQuoteDifferences(plan);
  }


  updateEnrolmentCounts(enrolmentObj: any, tierLimit) {
    for (let tierVal = tierLimit; tierVal >= 1; tierVal--) {
      enrolmentObj['enrollT' + tierVal] = 0;
    }
  }
  updateEnrlmntsToOriginal(enrolmentObj: any, tierLimit, originalObj: any) {
    if (originalObj && enrolmentObj) {
      for (let tierVal = tierLimit; tierVal >= 1; tierVal--) {
        enrolmentObj['enrollT' + tierVal] = originalObj['enrollT' + tierVal]
      }
    }
  }

  calculateComponentPercent(mpc: PlanComparison[]) {
    let mpcPlans = this.mpc.planComparison;
    if (mpcPlans) {
      let currTot = 0;
      let quoteTot = 0;
      for (let compName of this.abfComponentKeys) {
        for (let plan of mpcPlans) {
          if (plan['proposedPlanTieredRates']) {
            let currTier = plan.currentTier;

            for (let i = currTier; i > 0; i--) {
              let currEnroll = plan.currentEnrollments['enrollT' + i] || 0;
              currTot = currTot + (currEnroll * this.getTierAbfCompRates(plan, i, compName, currTier, 'C'));
            }
            let quoteTier = currTier != plan.quoteTier ? this.requestedTier : plan.quoteTier;
            for (let i = quoteTier; i > 0; i--) {
              let quotEnroll = plan.quoteEnrollments['enrollT' + i] || 0;
              quoteTot = quoteTot + (quotEnroll * this.getTierAbfCompRates(plan, i, compName, quoteTier, 'P'));
            }
          }
        }
        this.componentPercentages[compName] = ((quoteTot - currTot) / currTot);
        currTot = 0;
        quoteTot = 0;
      }

    }
  }
  isEnrollemntsUpdated(plan, currEnroll) {
    let isEnrollmentChanged = false;
    if (StringUtils.isEqual(plan.quoteEnrollments?.totalEnroll, plan.initialCurrentEnrollments?.totalEnroll) &&
      StringUtils.isEqual(plan.currentEnrollments?.totalEnroll, plan.initialCurrentEnrollments?.totalEnroll) && !plan.suppressed) {
      return isEnrollmentChanged;
    } else {
      if (plan && plan.quoteEnrollments && currEnroll) {
        isEnrollmentChanged = this.verifyEnrollmentCategories(plan.quoteEnrollments, currEnroll)
      } if (plan && plan.currentEnrollments && currEnroll) {
        isEnrollmentChanged = isEnrollmentChanged ? isEnrollmentChanged : this.verifyEnrollmentCategories(plan.currentEnrollments, currEnroll)
      }
    }
    return isEnrollmentChanged;
  }
  verifyEnrollmentCategories(plan, currEnroll) {
    let isChanged = false;
    if(currEnroll && !StringUtils.isObjectEmpty(currEnroll)){
    for (let i = 1; i <= Object.keys(currEnroll)?.length; i++) {
     if (!StringUtils.isUndefined(plan['enrollT' + i]) && !StringUtils.isUndefined(currEnroll['enrollT' + i]) &&
      plan['enrollT' + i] != currEnroll['enrollT' + i]) {
        isChanged  = true;
      }
    }
  }
    return isChanged;
  }
  updateEnrollmentFromMPC(plan) {
    if (this.mpc?.planComparison && plan) {
      const matchingPlanComparison = this.mpc.planComparison.find(element => StringUtils.isEqual(element.currPlanId,plan.currPlanId));
      if (matchingPlanComparison && !StringUtils.isObjectEmpty(matchingPlanComparison)) {
        if (matchingPlanComparison.quoteEnrollments) {
          this.updateEnrlmntsToOriginal(plan.quoteEnrollments, plan.quoteTier, matchingPlanComparison.quoteEnrollments);
        } if (matchingPlanComparison.currentEnrollments) {
          this.updateEnrlmntsToOriginal(plan.currentEnrollments, plan.currentTier, matchingPlanComparison.currentEnrollments);
        }
      }
    }
  }
}
