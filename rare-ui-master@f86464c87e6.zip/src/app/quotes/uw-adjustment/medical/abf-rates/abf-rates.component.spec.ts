import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { AbfRatesComponent } from './abf-rates.component';

describe('AbfRatesComponent', () => {
  let component: AbfRatesComponent;
  let fixture: ComponentFixture<AbfRatesComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AbfRatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AbfRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
