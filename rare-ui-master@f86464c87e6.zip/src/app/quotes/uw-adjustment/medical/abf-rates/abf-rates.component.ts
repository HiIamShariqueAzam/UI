import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: '[app-abf-rates]',
  templateUrl: './abf-rates.component.html',
  styleUrls: ['./abf-rates.component.css'],
  standalone: false
})
export class AbfRatesComponent implements OnInit {
  @Input() rate: any;
  @Input() abfKey: string;
  @Input() colSpanForABF: any;
  @Input() requestedTier: any;

  constructor() { }

  ngOnInit() {
  }


  getRatesLabelForABF(key) {
    return {
      'asoFee': 'Admin',
      'sslPremium': 'SSL Prem',
      'aslPremium': 'ASL Prem',
      'terminalLiabilityFund': 'TL Fund',
      'maxPaidClaimsFund': 'Max CI Fund'
    }[key.value];
  }

}
