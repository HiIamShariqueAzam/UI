import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services';
import { provideAnimations } from '@angular/platform-browser/animations';
import { Router, ActivatedRoute } from '@angular/router';
import { OidcSecurityService, AuthModule } from 'angular-auth-oidc-client';
import { By, DomSanitizer } from '@angular/platform-browser';
import { of } from 'rxjs/internal/observable/of';
import { MedicalComponent } from './medical.component';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { RadioButtonModule } from 'primeng/radiobutton';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe, Location } from '@angular/common';
import { rateInfoResponse, printExhibitResponse, applyAdjRequest, applyAdjResponse, getFileResponse } from './uw-adjustment.mock';

describe('MedicalComponent', () => {
  let component: MedicalComponent;
  let fixture: ComponentFixture<MedicalComponent>;
  let commonService: CommonService;
  var adjButton;


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [MedicalComponent],
      imports: [ReactiveFormsModule, FlexLayoutModule, TableModule, ButtonModule, CalendarModule, RadioButtonModule,
        AuthModule.forRoot()],
      providers: [provideAnimations(), provideHttpClient(), FormBuilder, {
        provide: Router,
        useClass: class { navigate = jasmine.createSpy("navigate"); },
        OidcSecurityService
      }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalComponent);
    component = fixture.componentInstance;
    adjButton = fixture.debugElement.query(By.css('#adjButton'));
    TestBed.configureTestingModule({
      providers: [CommonService]
    });
    commonService = TestBed.get(CommonService);
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture=null;
    component=null;
    commonService=null;
    adjButton = null;

});

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a defined component', () => {
    expect(component).toBeDefined();
});

it('should be created', () => {
  expect(commonService).toBeTruthy();
});

it("should call the constructor", () => {
  let fb: FormBuilder;
  let router: Router;
  let activatedRoute: ActivatedRoute;
  let location: Location;
  let ngbModal: NgbModal;
  let config: NgbModalConfig;
  let datePipe: DatePipe;
    component = new UwAdjustmentComponent(fb,commonService,router,activatedRoute,location,config,ngbModal,datePipe);
});

it("should have plans header values", () => {

  var columns = [
    { header: 'Employee' },
     { header: 'Employee + Spouse' },
    { header: 'Employee + Child(ren)' },
   { header: 'Employee + Family' },
   ];

  expect(columns).toEqual(component.columns);
});

it("should have input field name values", () => {

  var cols = [
    { header: 'UW Adjustment Factor' },
    { header: 'Employer Risk Factor' },
    { header: 'Sales Adjustment Factor' },
    { header: 'Whole Health Adjustment Factor' },
  ];

  expect(cols).toEqual(component.cols);
});

it("should have tier list values", () => {

  var tierList = [
    { tier: '2' },
    { tier: '3' },
    { tier: '4' }
  ];

  expect(tierList).toEqual(component.tierList);
});

it("should have action values", () => {

  var actionList = [
    { action: 'Quote' },
    { action: 'Decline to Quote' }
  ];

  expect(actionList).toEqual(component.actionList);
});

it("should have isCollapsed values", () => {

  var collapsed = false;
  expect(collapsed).toEqual(component.isCollapsed);
});



it("should call #ngOnInit", () => {

  spyOn(component, 'loadRateInfo');
  component.ngOnInit();
  expect(component.loadRateInfo).toHaveBeenCalled();

  expect(component.selectedQuoteAction).toEqual({ action: 'Quote' });
  expect(component.userSelectedTier).toEqual('');
});

it("should call #backClicked", () => {

  expect(component.backClicked).toHaveBeenCalled();
  });


it('should return a Rate Info response', () => {

  let response;
  spyOn(commonService, 'getRateInfo').and.returnValue(of(rateInfoResponse));

  commonService.getRateInfo('123').subscribe(res => {
    response = res;
  });

  expect(response).toEqual(rateInfoResponse);
});


it('should return a Print Exhibit response', () => {

  let response;
  spyOn(commonService, 'getPrintExhibitInfo').and.returnValue(of(printExhibitResponse));

  commonService.getPrintExhibitInfo('123').subscribe(res => {
    response = res;
  });

  expect(response).toEqual(printExhibitResponse);
});


it('should return a Apply Adjustment response', () => {

  let response;
  spyOn(commonService, 'submitApplyAdjustment').and.returnValue(of(applyAdjResponse));

  commonService.submitApplyAdjustment(applyAdjRequest,'123').subscribe(res => {
    response = res;
  });

  expect(response).toEqual(applyAdjResponse);
});


it('should return a get file from filenet response', () => {

  let response;
  spyOn(commonService, 'getFileFromFilenet').and.returnValue(of(getFileResponse));

  commonService.getFileFromFilenet("123").subscribe(res => {
    response = res;
  });

  expect(response).toEqual(getFileResponse);
});


});
