import { Component, OnInit, Input, SimpleChanges, OnChanges, ElementRef, ViewChildren, QueryList, ViewChild } from "@angular/core";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: "app-assumptions-conditions-grid",
  templateUrl: "./medical-assumptions-conditions-component.html",
  styleUrls: ["./medical-assumptions-conditions-component.css"],
  standalone: false,
})
export class assumptionsAndConditionsGridComponent implements OnInit, OnChanges {
  @ViewChildren('AandCText') rows:  QueryList< ElementRef>;
  @ViewChild('AssumptionsGrid') assumptionsGrid: ElementRef;
  @Input() quoteDetail;
  @Input() disableAll: boolean;

  btnDisabled: boolean = false ;
  emptyRowOrder: any = {};
  allChecked: boolean;
  nextDisplayOrder: number = 1;
  unSelectableAssumptionsOtherThanDepthOne: any[] = [];
  parentChildAssumptions: any = {};
  exhibitList= [
    { "label": "A&C", "value": "AC" },
    { "label": "RenSum", "value": "R" }
   ];
   fiExhibitList= [
    { "label": "A&C", "value": "AC" }
   ];
  isRenewal = false;

  ngOnChanges(changes: SimpleChanges) {
    if (changes.quoteDetail && !changes.quoteDetail.firstChange) {
      this.initializeComponentVariables();
    }
  }

  ngOnInit() {
    this.initializeComponentVariables();
  }

  customAssumAndConditionsToChar(adjData){
    if(adjData.length){
      adjData.forEach(element => {
        if(element?.asmptnCndtnText)
          element.asmptnCndtnText = CommonUtil.asciiToCharacter(element.asmptnCndtnText);
      });
    }
    return adjData;
  }

  initializeComponentVariables() {
    if (this.quoteDetail && this.quoteDetail.assumptionsAndConditions) {
      this.quoteDetail.assumptionsAndConditions = this.customAssumAndConditionsToChar(this.quoteDetail.assumptionsAndConditions);
      this.nextDisplayOrder = this.quoteDetail.assumptionsAndConditions[this.quoteDetail.assumptionsAndConditions.length - 1]
        .dsplyOrder + 1;
    this.isRenewal = this.quoteDetail.opportunityType === 'Renewal Local';
    }
    if (this.isRenewal && this.quoteDetail.fundingType == 'FI') {
      this.exhibitList = this.fiExhibitList
    }
    this.checkAllAssumptions();
    this.populateUnselectableAssumptions();
  }

  addnewTableRow() {
    let sheetCd = this.quoteDetail.opportunityType === 'Renewal Local' ? '' : 'AC';
    this.quoteDetail.assumptionsAndConditions.push(
      { asmptnCndtnType: "C", asmptnCndtnText: "", dsplyOrder: this.nextDisplayOrder++, depth: 1, includeInPE: false, sheetCd }
    )
    this.emptyRowOrder[this.quoteDetail.assumptionsAndConditions.length - 1] = true;
    this.processEnableButton();
    this.checkAllAssumptions()
    setTimeout(()=>{
      this.assumptionsGrid.nativeElement.scrollTop = this.assumptionsGrid.nativeElement.scrollHeight;
      this.rows.last.nativeElement.focus();
    });
  }

  showAssumSheetCdDropdown(assumption) {
   return (this.quoteDetail.opportunityType === 'Renewal Local') ? assumption && assumption.asmptnCndtnType === 'C' : false;
  }

  getReadOnlyExhibitType(val) {
    if(val == 'AC') {
      return 'A&C';
    } else if(val == 'R') {
      return 'RenSum';
    } else {
      return 'A&C';
    }

  }

  updatedAssumptionsText($event, rowIndex) {
    let assumptionText = $event.target.value.replace(/(\r\n|\n|\r)/gm, "").replace(/\s{2,}/g, ' ');
    this.quoteDetail.assumptionsAndConditions[rowIndex].asmptnCndtnText = assumptionText;
    this.checkEmptyRowOrder(rowIndex);
    this.checkAllAssumptions();
  }

  checkEmptyRowOrder(rowIndex) {
    let assumptionsAndConditions= this.quoteDetail.assumptionsAndConditions[rowIndex];
    if (assumptionsAndConditions.asmptnCndtnText && assumptionsAndConditions.sheetCd) {
      delete this.emptyRowOrder[rowIndex];
    } else if (!(assumptionsAndConditions.asmptnCndtnText && assumptionsAndConditions.sheetCd)) {
      this.emptyRowOrder[rowIndex] = true;
    }
    this.processEnableButton();
  }

  selectAllAssumptions($event) {
    this.quoteDetail.assumptionsAndConditions.forEach(assumption => assumption.asmptnCndtnText.length > 0 ?
      assumption.includeInPE = this.allChecked :
      assumption.includeInPE = false );
    this.checkAllAssumptions();
    if(this.allChecked) {
      this.unSelectableAssumptionsOtherThanDepthOne = [];
    }else {
     var indices =  this.quoteDetail.assumptionsAndConditions.flatMap((assumption ,index) => (!assumption.includeInPE && assumption.depth > 1) ? [index] : []);
     this.unSelectableAssumptionsOtherThanDepthOne.push(...indices);
  }
   // control.checked = this.allChecked; just commented to check this works or not as locally not able to produce
  }

  checkAllAssumptions() {
    this.allChecked = this.quoteDetail.assumptionsAndConditions.filter((assumption) => !assumption.includeInPE).length === 0 &&
      this.quoteDetail.assumptionsAndConditions.length > 0;
  }

  processEnableButton() {
    this.btnDisabled = Object.keys(this.emptyRowOrder).length > 0;
  }

  selectAssumption($event, index) {
    this.quoteDetail.assumptionsAndConditions[index].includeInPE = $event;
    if (this.quoteDetail.assumptionsAndConditions[index] && this.quoteDetail.assumptionsAndConditions[index]['depth'] === 1) {
      if (this.parentChildAssumptions[index] && Array.isArray(this.parentChildAssumptions[index])) {
        this.parentChildAssumptions[index].forEach(idx => {
          if ($event) {
            let itemIndex = this.unSelectableAssumptionsOtherThanDepthOne.indexOf(idx);
            if (itemIndex !== -1) {
              this.unSelectableAssumptionsOtherThanDepthOne.splice(itemIndex, 1);
            }
          } else {
            this.quoteDetail.assumptionsAndConditions[idx].includeInPE = false ;
            this.unSelectableAssumptionsOtherThanDepthOne.push(idx);
          }
        });
      }
    }
    this.quoteDetail.assumptionsAndConditions.forEach(assumptions => {
      if(assumptions.asmptnCndtnText === this.quoteDetail.assumptionsAndConditions[index].asmptnCndtnText){
        (assumptions['includeInPE'] as boolean)= $event.checked as boolean;
      }
    });
    this.checkAllAssumptions();
  }

  populateUnselectableAssumptions() {
    let parentIndex = 0;
    let prevDepth = 1;
    this.quoteDetail.assumptionsAndConditions.forEach((assumption, idx) => {
      if (assumption.depth && assumption.depth > 1) {
        if (prevDepth == 1) {
          parentIndex = idx - 1;
        }
        if (!this.parentChildAssumptions[parentIndex]) {
          this.parentChildAssumptions[parentIndex] = [];
        }
        this.parentChildAssumptions[parentIndex].push(idx);
        if (!this.quoteDetail.assumptionsAndConditions[parentIndex].includeInPE) {
          this.unSelectableAssumptionsOtherThanDepthOne.push(idx);
        }
      }
      prevDepth = assumption.depth;
    })
  }

  shouldDisable(idx): boolean {
    return this.disableAll ||
      this.unSelectableAssumptionsOtherThanDepthOne.indexOf(idx) !== -1 ||
      this.quoteDetail.assumptionsAndConditions[idx].asmptnCndtnText.trim().length == 0;
  }
}
