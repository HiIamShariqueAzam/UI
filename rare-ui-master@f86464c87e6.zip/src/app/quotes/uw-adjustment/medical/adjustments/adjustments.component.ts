import { AfterViewInit, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { RareConstants } from 'src/app/shared/models/rareConstants';
import { CommonService, ProcessQuoteDetailsService } from 'src/app/shared/services';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { UnderwriterAdjustmentService } from '../uw-adjustment.service';
import { Enrollments, MedicalPremiumComparison, PlanComparison, PlanRates } from 'src/app/shared/models';
import { ExpGrandTotalCalcService } from '../exp-grand-total-calc.service';

@Component({
  selector: 'app-adjustments',
  templateUrl: './adjustments.component.html',
  styleUrls: ['./adjustments.component.css'],
  standalone: false,
})
export class AdjustmentsComponent implements OnChanges, OnInit, AfterViewInit {
  @Input() quoteDetail: any;
  @Input() opportunityData: any;
  @Input() disableAll: boolean;
  @Input() allPlansLoaded: boolean;
  @Input() quoteAdjustments: boolean;
  @Input() fundingType: any;
  @Input() planActiveTab: any;
  @Input() showAdjustmentHistory: boolean = true;
  @Output() adjustmentsUpdated = new EventEmitter<any>();
  @Output() riskScoreFlashingEvent = new EventEmitter<any>();
  @Input() declineResaonsFromUWAdjs: any;
  @Output() declineReaonsToBeChecked = new EventEmitter<any>();
  @Input() uwAdjustmentFetchObject;
  @Input() isReadOnlyRole;
  @Input() LGFItoSGAbfCrossSelling;
  @Input() curvRiskScore;
  @Input() sseCurvRiskScore;
  @Input() isSetRateAdjFormLoaded: boolean;

  calculatedLives: any;
  tierRatioGuardrailFailure: boolean;
  hasQuoteDetailsPopulated: boolean = false;
  hasformulaTieredRateActionPercent: boolean =false;
  hasuwTieredRateActionPercent: boolean =false;
  uwAdjustment: any;
  userSelectedTier: any;
  adjustment_form: FormGroup;
  MedPlans: any;
  status: any;
  adjHistory: any;
  isCurrentTierRatioEligible: boolean;
  selectedTierRatioCalculationType: string;
  tierList = [{ tier: '2' }, { tier: '3' }, { tier: '4' }];
  tierListArray = [];
  requestedTier: number;
  initialTier: number;
  isCollapsed: boolean = false;
  isCustomTierSelected = false;
  loadAdjustment = true;
  activeTab: string = 'Q';
  rblActiveTab: string = 'RC';
  PRODUCT_SEPARATOR = '##';
  premTrgtAdjFactor: any;
  adjustmentKeys: string[] = ['currentRiskFactor', 'riskFactor', 'uwAdjustmentFactor', 'employerRiskFactor', 'salesAdjustmentFactor', 'wholeHealthAdjustmentFactor', 'addOnCost'];
  componentKeys: string[] = ['asoAdmin', 'sslPremium', 'aslPremium', 'terminalLiability', 'maxClaims'];
  rblKeys: string[] = [
    'adminFactorAdj',
    'sslFactorAdj',
    'aslFactorAdj',
    'tlFactorAdj',
    'mcfFactorAdj',
    'adminFactorAllocation',
    'sslFactorAllocation',
    'aslFactorAllocation',
    'tlFactorAllocation',
    'mcfFactorAllocation'
  ];
  percentKeys: string[] = ['adminFactor', 'sslFactor', 'aslFactor', 'tlFactor', 'mcfFactor'];
  userModifiedProductAdjustments: any = {};
  readonly RENEWAL_LOCAL = CommonConstants.RENEWAL_LOCAL;
  factorKeys: string[] = ['eeFactor', 'e1Factor', 'esFactor', 'ecFactor', 'ekFactor', 'efFactor'];

  tierBasedFactorKeys: any = {
    '1-tier': ['eeFactor'],
    '2-tier': ['eeFactor', 'efFactor'],
    '3-tier': ['eeFactor', 'e1Factor', 'efFactor'],
    '4-tier': ['eeFactor', 'esFactor', 'ecFactor', 'efFactor'],
    '5-tier': ['eeFactor', 'esFactor', 'ecFactor', 'ekFactor', 'efFactor']
  };

  adjType: any = [
    { label: 'PMPM', value: 'PMPM' },
    { label: 'Percent', value: 'Percent' },
    { label: 'PCPM', value: 'PCPM' }
  ];
  //fieldNames should be same as  in response , have to update once i get to know
  rateActionValueKeys: string[] = [
    'adjustedRateActionPercent',
    'asoAdminFee',
    'sslPremium',
    'aslPremium',
    'maxPaidClaim',
    'terminalLiability',
    'renewalWHAPercent'
  ];
  FiRateActionValueKeys: string[] = ['adjustedRateActionPercent', 'renewalWHAPercent', 'isFlatRateApplied'];
  rateActionDisabledKeys = [
    'expAdj',
    'totalQlAdj',
    'fiToAbfTarget',
    'calcRebalAsoAdminAdj',
    'calcRebalSslPremAdj',
    'calcRebalAslPremAdj',
    'calcRebalMaxClmAdj',
    'calcRebalTrmnlLbltyAdj',
    'maxPaidClaim',
    'calcFrmlRtAsoAdmin',
    'calcFrmlRtSslPrem',
    'calcFrmlRtAslPrem',
    'calcFrmlRtMaxClmAdj',
    'calcFrmlRtTrmnlLblty',
    'frmlRtActionPercent',
    'formulaTieredRateActionPercent',
    'uwTieredRateActionPercent'
  ];

  isCustomTierSelectable: boolean = false;
  erredFactors: any = {};
  customRateTierFactor: any;
  initialCustomRateTierFactor: any;
  standardRateTierFactor: any;
  currentRateTierFactor: any;

  customTierRatio: any = {};
  currentTierRatio: any = {};
  standardTierRatio: any = {};

  includedPlanTypes: string[] = ['F', 'P'];
  productAdjustmentCategories: any[] = [];
  loadQuoteAdjustments: boolean = false;
  adminFactorCB: boolean = false;
  sslFactorCB: boolean = false;
  aslFactorCB: boolean = false;
  tlFactorCB: boolean = false;
  mcfFactorCB: boolean = false;
  showRateActionAdj: boolean = false;
  componentTierTotalRates: any;
  initialComponentTierRates: any;
  isInitialLoad: boolean = false;
  isRateAdjChangeLoaded: boolean = false;
  actualDeclineReason: any;
  userTypedDeclineReasons: any;
  predefinedDeclineReasons: any[] = [];
  planListForRtAtnCalc = [];
  featuredpLanList = [];
  isTierAdjDisabled: boolean = false;
  isTierAdjDisabledForABF: boolean = false;
  isFlatRateEnabledForMultiplePlan: boolean = true;
  isAllFeaturePlanMappingExist: boolean = false;
  tierSelectionFromUI: string = '';
  whAdjustmentsDetails: any;
  adjustmentRiskFactor: any;
  isPlusIcon: boolean = true;
  enableCurvChanges: boolean = false;
  isRiskScoreAvailable: boolean = true;
  showAdjustmentForAlts: boolean = true;
  mpc: MedicalPremiumComparison;
  proposedPlansCopy: any; 
  customTierRatioTypeRateActionFixEnabled: boolean = this.commonService.getCustomTierRatioTypeRateActionFixEnabled(); 

  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private uwService: UnderwriterAdjustmentService,
    private processQuoteService: ProcessQuoteDetailsService,
    private commonQuoteService: CommonQuoteService,
    private expGrandTotalCalcService: ExpGrandTotalCalcService
  ) {}

  ngOnChanges(changes: SimpleChanges) {
    if (
      (changes.quoteDetail && !changes.quoteDetail.firstChange) ||
      (changes.allPlansLoaded && !changes.allPlansLoaded.firstChange) ||
      (changes.quoteAdjustments && !changes.quoteAdjustments.firstChange) ||
      (changes.componentAdjustments && !changes.componentAdjustments.firstChange) ||
      (changes.isSetRateAdjFormLoaded && ! changes.isSetRateAdjFormLoaded.firstChange)
    ) {
      if (!this.adjHistory || (this.adjHistory && this.adjHistory.length == 0)) {
        this.loadAdjustment = true;
      }
      this.initializeComponentVariables();
    }

    if(changes.quoteDetail) {
      this.showAdjustmentForAlts = this.showRateAdjustmentSection();
    }

    if (changes.declineResaonsFromUWAdjs) {
      this.setDeclineReasonsToUWNotes(null, false);
    }
    this.processQuoteService.declineOptionsValues.subscribe((value) => {
      if (value != null) {
        this.processQuoteService.setDeclineOptionsChecked(value);
        this.setDeclineReasonsToUWNotes(value, true);
      }
    });
    if (this.adjustment_form != undefined) {
      this.adjustment_form.get('uwNotesToSales').valueChanges.subscribe((val) => {
        this.adjustment_form.get('uwNotesToSales').setValue(val, { emitEvent: false });
      });
    }
    if (this.sseCurvRiskScore && this.sseCurvRiskScore !== this.curvRiskScore) {
      this.curvRiskScore = this.sseCurvRiskScore;
      this.isPlusIcon = true;
    }

    if (this.sseCurvRiskScore) {
      this.isRiskScoreAvailable = true;
    }
  }

  ngOnInit() {
    this.getAdjustHitory();
    this.uwAdjustment = {};
    this.MedPlans = [];
    this.calculatedLives = {};
    this.predefinedDeclineReasons = [];
    this.quoteDetail['contractStartDate'] = this.quoteDetail.contractEffectiveDate;
    if (this.quoteDetail.productsQuoted != undefined) {
      this.quoteDetail['lob1'] = this.quoteDetail.productsQuoted[0];
    }
    if (this.curvRiskScore === undefined) {
      this.isRiskScoreAvailable = false;
    }
    if (this.predefinedDeclineReasons.length == 0) {
      this.predefinedDeclineReasons = this.processQuoteService.declineOptionsFromBackend;
    }
    this.showRateActionAdj = this.quoteDetail && this.quoteDetail.opportunityType == 'Renewal Local';
    if (this.showRateActionAdj) this.activeTab = 'RTA';
    if (this.quoteDetail.quotingType == 'MEWA') this.setActiveTab('Q');
    this.initializeComponentVariables();
    let uWNotesSplit: any[] = [];
    if (this.uwAdjustment.uwNotesToSales.includes(';')) {
      uWNotesSplit = this.uwAdjustment.uwNotesToSales.split(';');
    } else {
      uWNotesSplit.push(this.uwAdjustment.uwNotesToSales);
    }
    if (uWNotesSplit != null && this.uwAdjustment.uwNotesToSales != '') {
      var declineChecboxes = this.predefinedDeclineReasons.filter((x) => {
        return uWNotesSplit.findIndex((t) => t === x) != -1;
      });
      if (typeof declineChecboxes != 'undefined' && declineChecboxes != null) {
        this.declineReaonsToBeChecked.emit(declineChecboxes);
      }
    }
    if (this.adjustment_form
      .get('quoteAdjustments')
      ?.get('uwAdjustmentFactor')?.value != ''){
        this.isPlusIcon = false;
      }
  }

  ngAfterViewInit() {
    this.setFormValue();
  }

  callDeclineOptionsBackend() {
    let isMedicalAca = this.commonService.isMedicalAca(this.quoteDetail);
    if (!isMedicalAca) {
      this.commonQuoteService.getDeclineOptions(this.quoteDetail, this.opportunityData.ratingTransID).subscribe((response) => {
        if (typeof response != 'undefined' && response != null && typeof response.data != 'undefined' && response.data != null) {
          response.data.forEach((element) => {
            this.predefinedDeclineReasons.push(element);
          });
          this.setUWNotesWithDclnToQtRsn();
          this.emitDeclineCheckboxOptions();
        }
      });
    }
  }
  initializeComponentVariables() {
    if (this.quoteDetail) {
      this.hasQuoteDetailsPopulated = true;
      if (this.quoteDetail.medical && this.quoteDetail.quotingType == 'ACA') {
        this.hasQuoteDetailsPopulated = false;
      }
      this.tierRatioGuardrailFailure =
        this.quoteDetail.failedGuardRails &&
        Array.isArray(this.quoteDetail.failedGuardRails) &&
        this.quoteDetail.failedGuardRails.includes('Current Carrier Tier Ratios');
      if (this.quoteDetail.availableTiers) {
        this.tierList = this.quoteDetail.availableTiers;
        this.tierList.sort((a, b) => (a.tier > b.tier ? 1 : b.tier > a.tier ? -1 : 0));
      }

      if (!this.quoteDetail.uwAdjustment) {
        this.quoteDetail.uwAdjustment = {};
        this.quoteDetail.uwAdjustment.outputTier = this.quoteDetail.medicalOutputTier;
      }
      if (this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.tierRatioCalculationType) {
        this.quoteDetail.uwAdjustment.tierRatioCalculationType = '';
      }
      this.uwAdjustment = this.quoteDetail.uwAdjustment;
      this.requestedTier = this.uwAdjustment.outputTier;
      this.initialTier = this.requestedTier;
      this.calculatedLives = (this.quoteDetail['factors'] && this.quoteDetail['factors'].calculatedTierLives) || {};
      if (this.calculatedLives) {
        Object.keys(this.calculatedLives).forEach((tierValue) => {
          this.tierListArray.push({ tier: tierValue.substring(0, 1) });
        });
        this.tierListArray.sort((tier1, tier2) => (tier1.tier > tier2.tier ? 1 : tier2.tier > tier1.tier ? -1 : 0));
        this.tierListArray = this.tierListArray.filter((tierList, index) => {
          return index === this.tierListArray.findIndex((tierIndex) => StringUtils.isEqual(tierList.tier, tierIndex.tier));
        });
      }
      this.initializeTierFactors();
      this.loadQuoteAdjustments = this.quoteAdjustments;
      let currentPlanIDs = [];
      if (this.quoteDetail.medical && this.quoteDetail.medical.currentPlans) {
        currentPlanIDs = this.quoteDetail.medical.currentPlans.map((currentPlan) => currentPlan.id);
      }
      if (this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans) {
        this.MedPlans = this.quoteDetail.medical.proposedPlans.filter(
          (plan) => this.includedPlanTypes.includes(plan.planTypeRequested) && plan.status != 'Failed'
        );
        this.MedPlans.forEach((plan) => {
          if (plan?.factors?.abfFactors) {
            this.premTrgtAdjFactor = plan.factors.abfFactors.premTrgtAdjFactor;
          }
        });
        let featuredpLanList = UnderwriterAdjustmentService.filterFeaturedPlans(this.quoteDetail.medical.proposedPlans);
        this.isFlatRateEnabledForMultiplePlan = featuredpLanList.every((plan) => plan?.currPlanId?.length == 1);
        this.isAllFeaturePlanMappingExist = featuredpLanList.every(
          (plan) => plan?.currPlanId?.length >= 1 && !StringUtils.isEmpty(plan?.currPlanId?.[0]) && currentPlanIDs.includes(plan?.currPlanId?.[0])
        );
      }
      if (!this.showRateActionAdj && this.allPlansLoaded && this.fundingType == 'FI') {
        this.setupProductAdjustmentKeys();
      }

      this.initializeAdjustmentForm();
      this.setFormValue();
      this.onFormValueChanges();
            
      if (this.quoteDetail.opportunityType == 'Renewal Local' && this.fundingType == 'ABF') {
        this.isTierAdjDisabledForABF = true;
      } else {
        this.isTierAdjDisabledForABF = false;
      }
      this.getDisabledField();
      if (this.disableAll) {
        this.adjustment_form.disable();
      } else {
        this.adjustment_form.enable();
      }
      if (StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL) && StringUtils.isEqual(this.fundingType, CommonConstants.FI)) {
        this.getFlatEnabled();
      }
      if (this.showRateActionAdj) {
        if (this.fundingType == 'ABF') {
          this.rateActionValueKeys.forEach((key) => {
            this.adjustment_form
              .get('abfRateActionAdjustment')
              .get(key)
              .valueChanges.subscribe((val) => {
                this.onRateActionValueChanges(key, val);
              });
          });
        } else if (this.fundingType == 'FI')  {
          this.FiRateActionValueKeys.forEach((key) => {
            this.adjustment_form
              .get('fiRateActionAdjustment')
              .get(key)
              .valueChanges.subscribe((val) => {
                this.onFiRateActionValueChanges(key, val);
              });
          });
        }
      }
      if((this.quoteDetail.riskScoreType == 'CURV' || this.quoteDetail.riskScoreType == 'NA') && (this.fundingType == 'FI' || this.fundingType == 'ABF')){
        this.enableCurvChanges = true;
      }
    }
  }

  populateRiskAdjustmentFactor(): void {
    if (this.isPlusIcon) {
      // Set the value when the icon is plus
      if (this.curvRiskScore) {
        this.adjustment_form
          .get('quoteAdjustments')
          ?.get('uwAdjustmentFactor')
          ?.setValue(this.curvRiskScore);
          this.riskScoreFlashingEvent.emit({riskScoreFlash : false});
      } else {
        console.warn('curvRiskScore is not available.');
      }
    } else {
      // Reset the value when the icon is minus
      this.adjustment_form
        .get('quoteAdjustments')
        ?.get('uwAdjustmentFactor')
        ?.setValue('');
      this.riskScoreFlashingEvent.emit({riskScoreFlash : true});
    }

    // Toggle the icon state
    this.isPlusIcon = !this.isPlusIcon;
  }
  getDisabledField() {
    // if (StringUtils.isEqual(this.quoteDetail.opportunityType, 'Renewal Local') && StringUtils.isEqual(this.fundingType, 'ABF')) {
    //   return this.isTierAdjDisabledForABF;
    // } else {
      return this.isTierAdjDisabled;
    // }
  }
  getFlatEnabled() {
    if (this.quoteDetail.medicalInputTier == this.requestedTier) {
      if (this.isFlatRateEnabledForMultiplePlan) {
        this.adjustment_form.get('fiRateActionAdjustment')?.get('isFlatRateApplied')?.enable();
      } else {
        this.adjustment_form.get('fiRateActionAdjustment')?.get('isFlatRateApplied')?.disable();
      }
    } else {
      this.adjustment_form.get('fiRateActionAdjustment')?.get('isFlatRateApplied')?.disable();
    }
  }
  initializeTierFactors() {
    let tierKey = this.requestedTier + '-tier';
    this.isCurrentTierRatioEligible = (this.quoteDetail.factors && this.quoteDetail.factors.isCurrentTierRatioEligible) || false;
    this.selectedTierRatioCalculationType =
      (this.quoteDetail.factors && (this.quoteDetail.factors.tierRatioCalculationType || this.quoteDetail.factors.tierRatioType)) || 'Standard';

    this.standardRateTierFactor = (this.quoteDetail.factors && this.quoteDetail.factors.rateTierFactor) || {};
    this.currentRateTierFactor = (this.quoteDetail.factors && this.quoteDetail.factors.currentRateTierFactor) || {};
    this.customRateTierFactor = (this.quoteDetail.factors && this.quoteDetail.factors.customRateTierFactor) || {};
    this.initialCustomRateTierFactor = JSON.parse(JSON.stringify((this.quoteDetail.factors && this.quoteDetail.factors.customRateTierFactor) || {}));

    Object.keys(this.standardRateTierFactor).forEach((key) => {
      if (!this.customRateTierFactor[key]) {
        this.customRateTierFactor[key] = this.standardRateTierFactor[key];
      }
    });

    if (this.uwAdjustment.tierRatioCalculationType === 'Custom') {
      this.customRateTierFactor[tierKey] = this.uwAdjustment.customTierRatio;
      this.selectedTierRatioCalculationType = 'Custom';
    }

    this.customTierRatio = this.customRateTierFactor[tierKey] || {};
    this.currentTierRatio = (this.currentRateTierFactor && this.currentRateTierFactor[tierKey]) || {};
    this.standardTierRatio = this.standardRateTierFactor[tierKey] || {};
  }

  setupProductAdjustmentKeys() {
    this.MedPlans &&
      this.MedPlans.forEach((plan) => {
        let productCategoryCode: string = '';
        let productCode: string = '';
        let hasPMTIndicator: boolean = false;
        if (plan.planBenefits && plan.planBenefits.productCategoryCode) {
          productCategoryCode = plan.planBenefits.productCategoryCode;
          hasPMTIndicator = true;
        }
        if (!productCategoryCode) {
          productCategoryCode = plan.networkType;
        }
        if (hasPMTIndicator) {
          productCode = plan.planBenefits.productCode ? plan.planBenefits.productCode : '';
        } else {
          if (plan['CDHPIndicator']) {
            productCode = plan['CDHPIndicator'];
          } else if (plan['cdhpindicator']) {
            productCode = plan['cdhpindicator'];
          }
        }
        let derivedCode = plan.networkName + this.PRODUCT_SEPARATOR + productCategoryCode + this.PRODUCT_SEPARATOR + productCode;
        if (!this.productAdjustmentCategories.includes(derivedCode)) {
          this.productAdjustmentCategories.push(derivedCode);
        }
      });
    this.productAdjustmentCategories = this.productAdjustmentCategories.sort();
  }

  initializeAdjustmentForm() {
    if (this.showRateActionAdj) {
      if (this.fundingType == 'ABF') {
        this.adjustment_form = this.constructRenewalForms();
      }
      if (this.fundingType == 'FI') {
        this.adjustment_form = this.constructFiRenewalForms();
      }
      if (this.quoteDetail.quotingType == CommonConstants.MEWA) {
        this.adjustment_form = this.constructNBmewaForms();
      }
    } else if (!this.showRateActionAdj && this.fundingType) {
      if (this.fundingType == 'ABF') {
        this.adjustment_form = this.constructNBabfForms();
        this.adjustment_form
          .get('componentAdjustments')
          .get('asoAdminType')
          .valueChanges.subscribe((componentAdj) => {
            this.onComponentAdjChanges('asoAdmin', componentAdj);
          });
        this.adjustment_form
          .get('componentAdjustments')
          .get('sslPremiumType')
          .valueChanges.subscribe((componentAdj) => {
            this.onComponentAdjChanges('sslPremium', componentAdj);
          });
        this.adjustment_form
          .get('componentAdjustments')
          .get('aslPremiumType')
          .valueChanges.subscribe((componentAdj) => {
            this.onComponentAdjChanges('aslPremium', componentAdj);
          });
        this.adjustment_form
          .get('componentAdjustments')
          .get('terminalLiabilityType')
          .valueChanges.subscribe((componentAdj) => {
            this.onComponentAdjChanges('terminalLiability', componentAdj);
          });
        this.adjustment_form
          .get('componentAdjustments')
          .get('maxClaimsType')
          .valueChanges.subscribe((componentAdj) => {
            this.onComponentAdjChanges('maxClaims', componentAdj);
          });

        this.percentKeys.forEach((adjKey) => {
          this.adjustment_form
            .get('percentageComponent')
            .get(adjKey)
            .valueChanges.subscribe((val) => {
              this.setRblPercentValueChanges(adjKey, val);
            });
        });

        this.componentKeys.forEach((adjKey) => {
          this.adjustment_form
            .get('componentAdjustments')
            .get(adjKey)
            .valueChanges.subscribe((val) => {
              this.setComponentlevelValueChanges(adjKey, val);
            });
        });

        this.rblKeys.forEach((adjKey) => {
          this.adjustment_form
            .get('rebalanceAdjustments')
            .get(adjKey)
            .valueChanges.subscribe((val) => {
              this.setRblValueChanges(adjKey, val);
            });
        });
      } else if (this.fundingType == 'FI') {
        this.adjustment_form = this.constructNBfiForms();
        if (this.allPlansLoaded) {
          this.addProductAdjustments();
        }
      } else if (this.quoteDetail.quotingType == CommonConstants.MEWA) {
        this.adjustment_form = this.constructNBmewaForms();
      }
    }
  }

  private constructRenewalForms(): FormGroup {
    return this.fb.group({
      uwNotesToSales: [''],
      uwComments: [''],
      exhibitName: [''],
      customTierRatio: this.constructTierRatioForm(),
      abfRateActionAdjustment: (this.quoteDetail?.medical?.alternateQuote || this.LGFItoSGAbfCrossSelling) ? this.constructAltAbfRateAdjGroup() : this.constructRateAdjGroup()
    });
  }
  private constructFiRenewalForms(): FormGroup {
    return this.fb.group({
      uwNotesToSales: [''],
      uwComments: [''],
      exhibitName: [''],
      customTierRatio: this.constructTierRatioForm(),
      fiRateActionAdjustment: this.constructFiRateAdjGroup()
    });
  }

  private constructNBfiForms(): FormGroup {
    return this.fb.group({
      uwNotesToSales: [''],
      uwComments: [''],
      exhibitName: [''],
      quoteAdjustments: this.fb.group({
      currentRiskFactor: [''],
        riskFactor: ['', [ValidationService.decimalValidator]],
        uwAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        employerRiskFactor: ['', [ValidationService.decimalValidator]],
        salesAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        wholeHealthAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        addOnCost: ['', [ValidationService.addonPMPMValidator]],
        fiToAbfTarget: ['']
      }),
      customTierRatio: this.constructTierRatioForm(),
      productAdjustments: this.fb.array([])
    });
  }

  private constructNBmewaForms(): FormGroup {
    return this.fb.group({
      uwNotesToSales: [''],
      uwComments: [''],
      exhibitName: [''],
      quoteAdjustments: this.fb.group({
        currentRiskFactor: [''],
        riskFactor: ['', [ValidationService.decimalValidator]],
        uwAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        employerRiskFactor: ['', [ValidationService.decimalValidator]],
        salesAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        wholeHealthAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        addOnCost: ['', [ValidationService.addonPMPMValidator]],
        fiToAbfTarget: ['']
      }),
      customTierRatio: this.constructTierRatioForm(),
      productAdjustments: this.fb.array([])
    });
  }

  private constructNBabfForms(): FormGroup {
    return this.fb.group({
      uwNotesToSales: [''],
      uwComments: [''],
      exhibitName: [''],
      quoteAdjustments: this.fb.group({
        currentRiskFactor: [''],
        riskFactor: ['', [ValidationService.decimalValidator]],
        uwAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        employerRiskFactor: ['', [ValidationService.decimalValidator]],
        salesAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        wholeHealthAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        addOnCost: ['', [ValidationService.addonPMPMValidator]],
        fiToAbfTarget: ['']
      }),
      rebalanceAdjustments: this.fb.group({
        adminFactorAdj: ['', [ValidationService.decimalValidator, ValidationService.emptyAndGreaterThanZeroValidator]],
        adminFactorAllocation: ['', [ValidationService.decimalValidator]],
        sslFactorAdj: ['', [ValidationService.decimalValidator, ValidationService.emptyAndGreaterThanZeroValidator]],
        sslFactorAllocation: ['', [ValidationService.decimalValidator]],
        aslFactorAdj: ['', [ValidationService.decimalValidator, ValidationService.emptyAndGreaterThanZeroValidator]],
        aslFactorAllocation: ['', [ValidationService.decimalValidator]],
        tlFactorAdj: ['', [ValidationService.decimalValidator, ValidationService.emptyAndGreaterThanZeroValidator]],
        tlFactorAllocation: ['', [ValidationService.decimalValidator]],
        mcfFactorAdj: ['', [ValidationService.decimalValidator, ValidationService.emptyAndGreaterThanZeroValidator]],
        mcfFactorAllocation: ['', [ValidationService.decimalValidator]]
      }),
      percentageComponent: this.fb.group({
        adminFactor: ['', [ValidationService.decimalValidator]],
        sslFactor: ['', [ValidationService.decimalValidator]],
        aslFactor: ['', [ValidationService.decimalValidator]],
        tlFactor: ['', [ValidationService.decimalValidator]],
        mcfFactor: ['', [ValidationService.decimalValidator]]
      }),
      componentAdjustments: this.fb.group({
        asoAdminType: [''],
        asoAdmin: [''],
        sslPremium: [''],
        sslPremiumType: [''],
        aslPremiumType: [''],
        aslPremium: [''],
        terminalLiabilityType: [''],
        terminalLiability: [''],
        maxClaimsType: [''],
        maxClaims: ['']
      }),
      customTierRatio: this.constructTierRatioForm()
    });
  }

  // Methos to construct ABF ALT rate action adj form group
  private constructAltAbfRateAdjGroup(): FormGroup {
    return this.fb.group({
      adjustedRateActionPercent: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      totalQlAdj: ['', [ValidationService.validateDecimalNumbers]],
      expAdj: ['', [ValidationService.validateDecimalNumbers]],
      fiToAbfTarget: ['', [ValidationService.validateDecimalNumbers]],
      asoAdminFee: [''],
      calcRebalAsoAdminAdj: [''],
      sslPremium: [''],
      calcRebalSslPremAdj: [''],
      aslPremium: [''],
      calcRebalAslPremAdj: [''],
      maxPaidClaim: [''],
      calcRebalMaxClmAdj: [''],
      terminalLiability: [''],
      calcRebalTrmnlLbltyAdj: [''],
      calcFrmlRtAsoAdmin: [''],
      calcFrmlRtSslPrem: [''],
      calcFrmlRtAslPrem: [''],
      calcFrmlRtMaxClmAdj: [''],
      calcFrmlRtTrmnlLblty: [''],
      frmlRtActionPercent: [''],
      renewalWHAPercent: ['']
    });
  }

  // Methos to construct rate action adj form group
  private constructRateAdjGroup(): FormGroup {
    return this.fb.group({
      adjustedRateActionPercent: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      totalQlAdj: ['', [ValidationService.validateDecimalNumbers]],
      expAdj: ['', [ValidationService.validateDecimalNumbers]],
      fiToAbfTarget: ['', [ValidationService.validateDecimalNumbers]],
      asoAdminFee: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      calcRebalAsoAdminAdj: [''],
      sslPremium: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      calcRebalSslPremAdj: [''],
      aslPremium: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      calcRebalAslPremAdj: [''],
      maxPaidClaim: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      calcRebalMaxClmAdj: [''],
      terminalLiability: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      calcRebalTrmnlLbltyAdj: [''],
      calcFrmlRtAsoAdmin: [''],
      calcFrmlRtSslPrem: [''],
      calcFrmlRtAslPrem: [''],
      calcFrmlRtMaxClmAdj: [''],
      calcFrmlRtTrmnlLblty: [''],
      frmlRtActionPercent: [''],
      renewalWHAPercent: ['']
    });
  }
  private constructFiRateAdjGroup(): FormGroup {
    return this.fb.group({
      adjustedRateActionPercent: ['', [Validators.required, ValidationService.validateDecimalNumbers]],
      totalQlAdj: ['', []],
      expAdj: ['', [ValidationService.validateDecimalNumbers]],
      frmlRtActionPercent: [''],
      formulaTieredRateActionPercent:[''],
      uwTieredRateActionPercent: [''],
      renewalWHAPercent: [''],
      isFlatRateApplied: [false]
    });
  }
  private constructTierRatioForm(): FormGroup {
    return this.fb.group({
      eeFactor: ['', [Validators.required, ValidationService.decimalValidator, ValidationService.greaterThanZeroValidator]],
      esFactor: ['', [Validators.required, ValidationService.decimalValidator, ValidationService.greaterThanZeroValidator]],
      e1Factor: ['', [Validators.required, ValidationService.decimalValidator, ValidationService.greaterThanZeroValidator]],
      ekFactor: ['', [Validators.required, ValidationService.decimalValidator, ValidationService.greaterThanZeroValidator]],
      ecFactor: ['', [Validators.required, ValidationService.decimalValidator, ValidationService.greaterThanZeroValidator]],
      efFactor: ['', [Validators.required, ValidationService.decimalValidator, ValidationService.greaterThanZeroValidator]]
    });
  }

  callRateAction(rateActionPercent, fundingType?: any) {
    let tierMonthlyPremium = this.quoteDetail?.factors?.tierWiseManualMonthlyTotals?.[this.requestedTier + '-tier']?.tierTotals?.monthlyPremium;
    let calulatedExpAdj;
    if (this.quoteDetail.opportunityType == 'Renewal Local' && StringUtils.isEqual(this.opportunityData?.fundingType, CommonConstants.ABF) && this.customTierRatioTypeRateActionFixEnabled && this.quoteDetail?.medical?.proposedPlans) {
      this.proposedPlansCopy = JSON.parse(JSON.stringify(this.quoteDetail?.medical?.proposedPlans.filter(x => x?.planTypeRequested == 'F')));
      if (this.proposedPlansCopy) {
        this.proposedPlansCopy.forEach((plan: any) => {
          if (this.uwService.showComponentAdjustmentsForAlternates(this.quoteDetail) && !this.LGFItoSGAbfCrossSelling) {
            plan = this.uwService.getAbfExperienceAdjusments(plan, this.quoteDetail, this.quoteDetail.uwAdjustment['componentTierTotalRates'], true);
          } else {
            plan = this.uwService.getAbfAltExperienceAdjusments(plan, this.quoteDetail, this.quoteDetail.uwAdjustment['componentTierTotalRates'], true);
          }
        });
      }
      this.mpc = JSON.parse(JSON.stringify(this.quoteDetail["medicalPremiumComparison"])) || {};
      this.mpc = this.expGrandTotalCalcService.calculateQuoteRates(this.mpc, this.proposedPlansCopy, this.quoteDetail, this.requestedTier, this.initialTier);
      // this.calculateQuoteRates();
    }
    if (
      StringUtils.isEqual(fundingType, RareConstants.ABF) ||
      (this.quoteDetail.medicalInputTier == this.requestedTier &&
        this.uwService.roundValueToSixDecimals(rateActionPercent) == this.uwAdjustment.abfRateActionAdjustment['frmlRtActionPercent'])
    ) {
      calulatedExpAdj = this.uwService.calculateRateActionFactor(
        rateActionPercent,
        this.quoteDetail.factors.experienceFactors.currentComponentTotal.totalPremium,
        this.mpc?.quoteMonthlyGrandTotal ? this.mpc?.quoteMonthlyGrandTotal : this.quoteDetail.factors.experienceFactors.expComponentTotal.totalPremium,
        this.quoteDetail.factors.experienceFactors.experienceAdjustmentFactor
      );
    } else {
      if (null != tierMonthlyPremium && undefined != tierMonthlyPremium) {
        calulatedExpAdj = this.uwService.calculateRateActionFactorNewCalc(
          rateActionPercent,
          this.quoteDetail.factors.experienceFactors.currentComponentTotal.totalPremium,
          tierMonthlyPremium
        );
      } else {
        calulatedExpAdj = this.uwService.calculateRateActionFactor(
          rateActionPercent,
          this.quoteDetail.factors.experienceFactors.currentComponentTotal.totalPremium,
          this.mpc?.quoteMonthlyGrandTotal ? this.mpc?.quoteMonthlyGrandTotal : this.quoteDetail.factors.experienceFactors.expComponentTotal.totalPremium,
          this.quoteDetail.factors.experienceFactors.experienceAdjustmentFactor
        );
      }
    }
    return calulatedExpAdj;
  }

  showFlatRateTooltip: boolean = false;
  private setFiRateActionAdjValues() {
    if (
      this.quoteDetail.factors &&
      this.quoteDetail.factors.experienceFactors &&
      this.quoteDetail.factors.experienceFactors.expRateAction &&
      this.quoteDetail.factors.experienceFactors.experienceAdjustmentFactor
    ) {
      if (
        this.uwAdjustment &&
        (this.uwAdjustment.abfRateActionAdjustment == undefined ||
          Object.values(JSON.stringify(this.uwAdjustment.abfRateActionAdjustment)).every((val) => val == ''))
      ) {
        let expRateAction = this.quoteDetail.factors.experienceFactors.expRateAction;
        this.uwAdjustment.abfRateActionAdjustment = {};
        this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = expRateAction['totalPremium'] * 100;
        this.isInitialLoad = true;
      } else if (this.uwAdjustment && this.uwAdjustment.abfRateActionAdjustment && this.uwAdjustment.abfRateActionAdjustment.componentRateAction) {
        this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = this.uwAdjustment.abfRateActionAdjustment.adjustedRateActionPercent;
        this.uwAdjustment.abfRateActionAdjustment['renewalWHAPercent'] = this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent;
        Object.keys(this.uwAdjustment.abfRateActionAdjustment.componentRateAction).forEach((key) => {
          this.uwAdjustment.abfRateActionAdjustment[key] = this.uwAdjustment.abfRateActionAdjustment.componentRateAction[key];
        });
        this.isInitialLoad = false;
      }
      this.uwAdjustment.abfRateActionAdjustment['isFlatRateApplied'] = this.showFlatRateTooltip = StringUtils.isUndefined(
        this.uwAdjustment?.abfRateActionAdjustment?.isFlatRateApplied
      )
        ? false
        : this.uwAdjustment?.abfRateActionAdjustment?.isFlatRateApplied;
      if (this.showFlatRateTooltip) {
        this.isTierAdjDisabled = true;
      } else {
        this.isTierAdjDisabled = false;
      }
      this.uwAdjustment.abfRateActionAdjustment['expAdj'] = this.quoteDetail.factors.experienceFactors.experienceAdjustmentFactor;
      this.formulaRateActionPercentForFI();
      let renewalWHAPercent = this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent ? this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent : 0;
      let rateActionPercent = this.uwAdjustment.abfRateActionAdjustment.adjustedRateActionPercent;
      let calulatedExpAdj = this.callRateAction(rateActionPercent);
      this.uwAdjustment.abfRateActionAdjustment['totalQlAdj'] = calulatedExpAdj != this.uwAdjustment.abfRateActionAdjustment['expAdj'] ? calulatedExpAdj : '';
      this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = this.uwService.roundValueToSixDecimals(
        this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent']
      );

      if (this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans) {
        this.featuredpLanList = UnderwriterAdjustmentService.filterFeaturedPlans(this.quoteDetail.medical.proposedPlans);
        if (this.quoteDetail.medical.asIsRenewalPlans) {
          this.planListForRtAtnCalc = this.quoteDetail.medical.asIsRenewalPlans;
        }
      }

      let currentAdjustment = JSON.parse(JSON.stringify(this.uwAdjustment.abfRateActionAdjustment));
      this.adjustment_form.get('fiRateActionAdjustment').patchValue(currentAdjustment, { emitEvent: false });
      this.uwAdjustment.abfRateActionAdjustment = currentAdjustment;
      this.propogateAdjustmentChanges(true);
      this.disableRateActionAdjFields();
      this.isRateAdjChangeLoaded = true;
    }
  }

  private setRateActionAdjValues() {
    if (
      this.quoteDetail.factors &&
      this.quoteDetail.factors.experienceFactors &&
      this.quoteDetail.factors.experienceFactors.expRateAction &&
      !StringUtils.isEmpty(this.quoteDetail.factors.experienceFactors.experienceAdjustmentFactor)
    ) {
      if (
        this.uwAdjustment &&
        (this.uwAdjustment.abfRateActionAdjustment == undefined || Object.values(this.uwAdjustment.abfRateActionAdjustment).every((val) => val === ''))
      ) {
        let expRateAction = this.quoteDetail.factors.experienceFactors.expRateAction;
        this.uwAdjustment.abfRateActionAdjustment = {};
        this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = expRateAction['totalPremium'] * 100;
        this.uwAdjustment.abfRateActionAdjustment['asoAdminFee'] = this.convertRateActionPercent(expRateAction['asoAdminFee']);
        this.uwAdjustment.abfRateActionAdjustment['sslPremium'] = this.convertRateActionPercent(expRateAction['sslPremium']);
        this.uwAdjustment.abfRateActionAdjustment['aslPremium'] = this.convertRateActionPercent(expRateAction['aslPremium']);
        this.uwAdjustment.abfRateActionAdjustment['maxPaidClaim'] = this.convertRateActionPercent(expRateAction['maxPaidClaim']);
        this.uwAdjustment.abfRateActionAdjustment['terminalLiability'] = this.convertRateActionPercent(expRateAction['terminalLiability']);
        this.isInitialLoad = true;
      } else if (this.uwAdjustment && this.uwAdjustment.abfRateActionAdjustment && this.uwAdjustment.abfRateActionAdjustment.componentRateAction) {
        this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = this.uwAdjustment.abfRateActionAdjustment.adjustedRateActionPercent;
        this.uwAdjustment.abfRateActionAdjustment['renewalWHAPercent'] = this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent;
        Object.keys(this.uwAdjustment.abfRateActionAdjustment.componentRateAction).forEach((key) => {
          this.uwAdjustment.abfRateActionAdjustment[key] = this.uwAdjustment.abfRateActionAdjustment.componentRateAction[key];
        });
        this.isInitialLoad = false;
      }
      this.uwAdjustment.abfRateActionAdjustment['expAdj'] = this.quoteDetail.factors.experienceFactors.experienceAdjustmentFactor;
      this.formulaRateActionPercent();
      let renewalWHAPercent = this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent ? this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent : 0;
      let rateActionPercent = this.uwAdjustment.abfRateActionAdjustment.adjustedRateActionPercent;
      let calulatedExpAdj = this.callRateAction(rateActionPercent, RareConstants.ABF);
      this.uwAdjustment.abfRateActionAdjustment['totalQlAdj'] = calulatedExpAdj != this.uwAdjustment.abfRateActionAdjustment['expAdj'] ? calulatedExpAdj : '';

      if (this.quoteDetail.medical && this.quoteDetail.medical.proposedPlans) {
        this.featuredpLanList = UnderwriterAdjustmentService.filterFeaturedPlans(this.quoteDetail.medical.proposedPlans);
        if (this.quoteDetail.medical.asIsRenewalPlans) {
          this.planListForRtAtnCalc = this.quoteDetail.medical.asIsRenewalPlans;
        }
        this.initialComponentTierRates = this.uwService.calculateQtLvlAdjAndComponentRates(this.planListForRtAtnCalc, this.quoteDetail);
        this.componentTierTotalRates = this.uwService.calculateRateActionRatesOnIntialLoad(
          this.planListForRtAtnCalc,
          this.quoteDetail,
          this.uwAdjustment.abfRateActionAdjustment,
          this.initialComponentTierRates,
          this.isInitialLoad
        );
        if (this.componentTierTotalRates) {
          this.setCalculatedRateActionFactors();

          if (this.isInitialLoad) {
            this.uwAdjustment.abfRateActionAdjustment['asoAdminFee'] = this.componentTierTotalRates['asoAdminCompPercent'];
            this.uwAdjustment.abfRateActionAdjustment['sslPremium'] = this.componentTierTotalRates['sslPremCompPercent'];
            this.uwAdjustment.abfRateActionAdjustment['aslPremium'] = this.componentTierTotalRates['aslPremCompPercent'];
            this.uwAdjustment.abfRateActionAdjustment['maxPaidClaim'] = this.componentTierTotalRates['maxPaidClaimCompPercent'];
            this.uwAdjustment.abfRateActionAdjustment['terminalLiability'] = this.componentTierTotalRates['terminalLiabilityCompPercent'];
          }
          this.uwAdjustment['componentTierTotalRates'] = this.componentTierTotalRates;
          this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = this.uwService.roundValueToSixDecimals(
            this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent']
          );
          let currentAdjustment = JSON.parse(JSON.stringify(this.uwAdjustment.abfRateActionAdjustment));
          this.adjustment_form.get('abfRateActionAdjustment').patchValue(currentAdjustment, { emitEvent: false });
          this.uwAdjustment.abfRateActionAdjustment = currentAdjustment;
          this.propogateAdjustmentChanges(true);
          this.isRateAdjChangeLoaded = true;
        }
      }
    }
    this.adjustment_form.get('abfRateActionAdjustment').get('fiToAbfTarget').patchValue(this.premTrgtAdjFactor, { emitEvent: false });
    this.disableRateActionAdjFields();
  }

  formulaRateActionPercentForFI() {
    let expRateAction = this.quoteDetail.factors.experienceFactors.expRateAction;
    this.uwAdjustment.abfRateActionAdjustment['frmlRtActionPercent'] = this.uwService.roundValueToSixDecimals(expRateAction['totalPremium'] * 100);
    if(this.uwAdjustment?.abfRateActionAdjustment['formulaTieredRateActionPercent'] != null){
        this.uwAdjustment.abfRateActionAdjustment['formulaTieredRateActionPercent'] = this.uwService.roundValueToSixDecimals(this.uwAdjustment.abfRateActionAdjustment['formulaTieredRateActionPercent']);
       this.hasformulaTieredRateActionPercent =true
    }
    if(this.uwAdjustment?.abfRateActionAdjustment['uwTieredRateActionPercent'] != null){
        this.uwAdjustment.abfRateActionAdjustment['uwTieredRateActionPercent'] = this.uwService.roundValueToSixDecimals(this.uwAdjustment.abfRateActionAdjustment['uwTieredRateActionPercent']);
       this.hasuwTieredRateActionPercent =true
    }
  }
  formulaRateActionPercent() {
    let expRateAction = this.quoteDetail.factors.experienceFactors.expRateAction;
    this.uwAdjustment.abfRateActionAdjustment['frmlRtActionPercent'] = this.uwService.roundValueToSixDecimals(expRateAction['totalPremium'] * 100);
    this.uwAdjustment.abfRateActionAdjustment['calcFrmlRtAsoAdmin'] = this.uwService.roundValueToSixDecimals(
      this.convertRateActionPercent(expRateAction['asoAdminFee'])
    );
    this.uwAdjustment.abfRateActionAdjustment['calcFrmlRtSslPrem'] = this.uwService.roundValueToSixDecimals(
      this.convertRateActionPercent(expRateAction['sslPremium'])
    );
    this.uwAdjustment.abfRateActionAdjustment['calcFrmlRtAslPrem'] = this.uwService.roundValueToSixDecimals(
      this.convertRateActionPercent(expRateAction['aslPremium'])
    );
    this.uwAdjustment.abfRateActionAdjustment['calcFrmlRtMaxClmAdj'] = this.uwService.roundValueToSixDecimals(
      this.convertRateActionPercent(expRateAction['maxPaidClaim'])
    );
    this.uwAdjustment.abfRateActionAdjustment['calcFrmlRtTrmnlLblty'] = this.uwService.roundValueToSixDecimals(
      this.convertRateActionPercent(expRateAction['terminalLiability'])
    );
  }

  private convertRateActionPercent(value: number) {
    return value * 100;
  }

  OnComponentRateActionChages(key, formValue) {
    if (this.componentTierTotalRates) {
      let valueKey = this.uwService.getKey(key, false);
      let value = this.uwService.calculateRateActionFactor(
        formValue,
        this.quoteDetail.factors.experienceFactors.currentComponentTotal[key],
        this.initialComponentTierRates[valueKey],
        1
      );
      this.componentTierTotalRates[this.uwService.getKey(key, true)] = value;
      this.componentTierTotalRates = this.calculateComponentRateActionPercent(this.quoteDetail, this.componentTierTotalRates);
      this.uwService.calculateComponentPercentage(this.quoteDetail.factors.experienceFactors.currentComponentTotal, this.componentTierTotalRates);
      this.uwAdjustment.abfRateActionAdjustment[key] = formValue;
      this.uwAdjustment.abfRateActionAdjustment['maxPaidClaim'] = this.componentTierTotalRates['maxPaidClaimCompPercent'];
      this.uwService.calculateComponentAdjFactors(
        this.quoteDetail.factors,
        this.componentTierTotalRates,
        this.initialComponentTierRates,
        this.uwAdjustment.abfRateActionAdjustment
      );
      this.uwAdjustment['componentTierTotalRates'] = this.componentTierTotalRates;
      this.adjustment_form
        .get('abfRateActionAdjustment')
        .get('maxPaidClaim')
        .patchValue(this.componentTierTotalRates['maxPaidClaimCompPercent'], { emitEvent: false });
      this.setCalculatedRateActionFactors();
      let currentAdjustment = JSON.parse(JSON.stringify(this.uwAdjustment.abfRateActionAdjustment));
      this.adjustment_form.get('abfRateActionAdjustment').patchValue(currentAdjustment, { emitEvent: false });
      this.uwAdjustment.abfRateActionAdjustment = currentAdjustment;
      this.updateMpcOnRateActionChange();
    }
  }

  private calculateUWadj(value, renewalWHAPercent): void {
    if (
      this.quoteDetail.factors &&
      this.quoteDetail.factors.experienceFactors &&
      this.quoteDetail.factors.experienceFactors.experienceAdjustmentFactor &&
      this.quoteDetail.factors.experienceFactors.currentComponentTotal &&
      this.quoteDetail.factors.experienceFactors.expComponentTotal.totalPremium
    ) {
      let adjFactor;
      let adjustedPercent
      if (this.quoteDetail.opportunityType == 'Renewal Local') {
        adjustedPercent = value;
      } else {
        adjustedPercent = renewalWHAPercent ? value - renewalWHAPercent : value;
      }
      adjFactor = this.callRateAction(adjustedPercent, this.quoteDetail.fundingType);
      this.uwAdjustment.abfRateActionAdjustment['totalQlAdj'] = adjFactor != this.uwAdjustment.abfRateActionAdjustment['expAdj'] ? adjFactor : '';
      this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = Number.parseFloat(value);
      this.uwAdjustment.abfRateActionAdjustment['renewalWHAPercent'] = renewalWHAPercent;
      if (this.quoteDetail.fundingType == 'ABF') {
        this.componentTierTotalRates = this.calculateComponentRateActionPercent(this.quoteDetail);
        if (this.componentTierTotalRates) {
          this.uwService.calculateComponentPercentage(this.quoteDetail.factors.experienceFactors.currentComponentTotal, this.componentTierTotalRates);
          this.uwAdjustment.abfRateActionAdjustment['asoAdminFee'] = this.componentTierTotalRates['asoAdminCompPercent'];
          this.uwAdjustment.abfRateActionAdjustment['sslPremium'] = this.componentTierTotalRates['sslPremCompPercent'];
          this.uwAdjustment.abfRateActionAdjustment['aslPremium'] = this.componentTierTotalRates['aslPremCompPercent'];
          this.uwAdjustment.abfRateActionAdjustment['maxPaidClaim'] = this.componentTierTotalRates['maxPaidClaimCompPercent'];
          this.uwAdjustment.abfRateActionAdjustment['terminalLiability'] = this.componentTierTotalRates['terminalLiabilityCompPercent'];
          this.uwService.calculateComponentAdjFactors(
            this.quoteDetail.factors,
            this.componentTierTotalRates,
            this.componentTierTotalRates,
            this.uwAdjustment.abfRateActionAdjustment
          );
          this.uwAdjustment['componentTierTotalRates'] = this.componentTierTotalRates;

          this.setCalculatedRateActionFactors();
          this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = value;
          this.initialComponentTierRates = JSON.parse(JSON.stringify(this.componentTierTotalRates));
        }
        let currentAdjustment = JSON.parse(JSON.stringify(this.uwAdjustment.abfRateActionAdjustment));
        this.adjustment_form.get('abfRateActionAdjustment').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment.abfRateActionAdjustment = currentAdjustment;
      } else {
        this.uwAdjustment.abfRateActionAdjustment['adjustedRateActionPercent'] = value;
        this.uwAdjustment.abfRateActionAdjustment['isFlatRateApplied'] = this.adjustment_form.get('fiRateActionAdjustment').get('isFlatRateApplied').value;
        let currentAdjustment = JSON.parse(JSON.stringify(this.uwAdjustment.abfRateActionAdjustment));
        this.adjustment_form.get('fiRateActionAdjustment').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment.abfRateActionAdjustment = currentAdjustment;
      }
      this.updateMpcOnRateActionChange();
    }
  }

  private setCalculatedRateActionFactors() {
    this.uwAdjustment.abfRateActionAdjustment['calcRebalAsoAdminAdj'] = this.verifyRateActionFactor(
      this.componentTierTotalRates['asoAdminFactor'],
      'asoAdminFee'
    );
    this.uwAdjustment.abfRateActionAdjustment['calcRebalSslPremAdj'] = this.verifyRateActionFactor(
      this.componentTierTotalRates['sslPremiumFactor'],
      'sslPremium'
    );
    this.uwAdjustment.abfRateActionAdjustment['calcRebalAslPremAdj'] = this.verifyRateActionFactor(
      this.componentTierTotalRates['aslPremiumFactor'],
      'aslPremium'
    );
    this.uwAdjustment.abfRateActionAdjustment['calcRebalMaxClmAdj'] = this.verifyRateActionFactor(
      this.componentTierTotalRates['maxClaimFactor'],
      'maxPaidClaim'
    );
    this.uwAdjustment.abfRateActionAdjustment['calcRebalTrmnlLbltyAdj'] = this.verifyRateActionFactor(
      this.componentTierTotalRates['terminalLiabilityFactor'],
      'terminalLiability'
    );
  }

  private verifyRateActionFactor(rateFactor: any, componentName: any) {
    return rateFactor == '1' ? '' : rateFactor;
  }

  private calculateComponentRateActionPercent(quoteDetail: any, rateActionFactr?: any): any {
    return this.uwService.calculateQtLvlAdjAndComponentRates(this.planListForRtAtnCalc, quoteDetail, rateActionFactr);
  }

  private disableRateActionAdjFields(): void {
    setTimeout(() => {
      this.rateActionDisabledKeys.forEach((key) => {
        this.adjustment_form.get('abfRateActionAdjustment')?.get(key)?.disable();
        this.adjustment_form.get('fiRateActionAdjustment')?.get(key)?.disable();
      });
    });
  }

  onComponentAdjChanges(key, componentAdj) {
    this.adjustment_form.get('componentAdjustments').get(key).enable();
    if (componentAdj.value === 'PMPM' || componentAdj.value === 'PCPM') {
      this.adjustment_form.get('componentAdjustments').get(key).setValidators([ValidationService.addonPMPMValidator]);
    } else if (componentAdj.value === 'Percent') {
      this.adjustment_form.get('componentAdjustments').get(key).setValidators([ValidationService.decimalValidator]);
    } else {
      setTimeout(() => {
        this.adjustment_form.get('componentAdjustments').get(key).disable();
      });
    }
    this.adjustment_form.get('componentAdjustments').get(key).updateValueAndValidity();
  }

  onRequestedTierChange($event) {
    this.quoteDetail.supportStandardTierRatio = true;
    let tierKey = $event.value.tier + '-tier';
    this.uwAdjustment['outputTier'] = $event.value.tier;
    this.requestedTier = $event.value.tier;
    if (this.quoteDetail.opportunityType == 'Renewal Local' && this.fundingType == 'FI') {
      this.getFlatEnabled();
    }
    this.customTierRatio = this.customRateTierFactor[tierKey] || {};
    this.currentTierRatio = (this.currentRateTierFactor && this.currentRateTierFactor[tierKey]) || {};
    this.standardTierRatio = this.standardRateTierFactor[tierKey] || {};
    this.selectedTierRatioCalculationType =
      this.requestedTier != this.initialTier && this.selectedTierRatioCalculationType == 'Current' ? 'Standard' : this.selectedTierRatioCalculationType;
    this.setPlanCompToHaveWhlCseEnrlmnt();
    let existedTier = this.checkTierAvailableOrNot();
    if (StringUtils.isUndefined(existedTier)) {
      if (this.hasCurrentTierFactor()) this.selectedTierRatioCalculationType = CommonConstants.CURRENT_TIER;
      else this.selectedTierRatioCalculationType = CommonConstants.CUSTOM_TIER;
    }
    this.setCustomTierRatio();
    this.setSelectTierType(tierKey);
    this.recalculateCustomTierFactorMultiplier();
    if (this.quoteDetail.opportunityType == 'Renewal Local') {
      let renewalWHAPercent = this.uwAdjustment?.abfRateActionAdjustment?.renewalWHAPercent ? this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent : 0;
      let rateActionPercent = this.uwAdjustment?.abfRateActionAdjustment?.adjustedRateActionPercent;
      let calulatedExpAdj = this.callRateAction(rateActionPercent, this.fundingType);
      this.uwAdjustment.abfRateActionAdjustment['totalQlAdj'] =
        calulatedExpAdj != this.uwAdjustment?.abfRateActionAdjustment?.['expAdj'] ? calulatedExpAdj : '';
      if (this.fundingType == 'FI') {
        this.adjustment_form?.get('fiRateActionAdjustment')?.get('totalQlAdj')?.setValue(this.uwAdjustment?.abfRateActionAdjustment?.['totalQlAdj']);
      } else {
        this.adjustment_form?.get('abfRateActionAdjustment')?.get('totalQlAdj')?.setValue(this.uwAdjustment?.abfRateActionAdjustment?.['totalQlAdj']);
      }
      this.calculateUWadj(this.uwAdjustment?.abfRateActionAdjustment?.adjustedRateActionPercent, renewalWHAPercent);
    }
    this.propogateAdjustmentChanges(true);
    if (this.planActiveTab != 'exhibitOR' && this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.peOverrideData) {
      if (this.quoteDetail.uwAdjustment.peOverrideData.lives) {
        this.quoteDetail.uwAdjustment.peOverrideData.lives = null;
        if (this.quoteDetail.uwAdjustment.userUpdatedLives) {
          this.quoteDetail.uwAdjustment.userUpdatedLives = JSON.parse(JSON.stringify(this.quoteDetail.factors.calculatedTierLives));
        }
      }
    }
  }
  setSelectTierType(tierKey) {
    let selectedTierRatioCalculationTypeFromResponse =
      this.quoteDetail.factors && (this.quoteDetail.factors.tierRatioCalculationType || this.quoteDetail.factors.tierRatioType);
    if (this.tierSelectionFromUI) {
      if (this.hasStandardTierFactor() && StringUtils.isEqual(this.tierSelectionFromUI, CommonConstants.STANDARD_TIER)) {
        this.selectedTierRatioCalculationType = CommonConstants.STANDARD_TIER;
      }
      if (this.hasCurrentTierFactor() && StringUtils.isEqual(this.tierSelectionFromUI, CommonConstants.CURRENT_TIER)) {
        this.selectedTierRatioCalculationType = CommonConstants.CURRENT_TIER;
      }
      if (StringUtils.isEqual(this.tierSelectionFromUI, CommonConstants.CUSTOM_TIER)) {
        this.selectedTierRatioCalculationType = CommonConstants.CUSTOM_TIER;
      }
    } else {
      if (
        Object.keys(this.currentRateTierFactor).find((tierFactorKey) => StringUtils.isEqual(tierFactorKey, tierKey)) &&
        this.requestedTier == this.initialTier &&
        StringUtils.isEqual(selectedTierRatioCalculationTypeFromResponse, CommonConstants.CURRENT_TIER)
      ) {
        this.selectedTierRatioCalculationType = CommonConstants.CURRENT_TIER;
      } else if (Object.keys(this.standardRateTierFactor).find((tierFactorKey) => StringUtils.isEqual(tierFactorKey, tierKey))) {
        this.selectedTierRatioCalculationType = CommonConstants.STANDARD_TIER;
      } else if (Object.keys(this.customRateTierFactor).find((tierFactorKey) => StringUtils.isEqual(tierFactorKey, tierKey))) {
        this.selectedTierRatioCalculationType = CommonConstants.CUSTOM_TIER;
      }
    }
  }
  private setPlanCompToHaveWhlCseEnrlmnt(): void {
    if (
      this.showRateActionAdj &&
      this.quoteDetail &&
      this.quoteDetail['medicalPremiumComparison'] &&
      this.quoteDetail['medicalPremiumComparison']['planComparison']
    ) {
      let pcList = this.quoteDetail['medicalPremiumComparison']['planComparison'];
      if (pcList.length > 0) {
        for (let plan of pcList) {
          if (plan['disableEdit'] != undefined && !plan['disableEdit']) {
            plan['calWholeCase'] = true;
          }
        }
      }
    }
  }

  getProductName(idx: number, type: string): string {
    let productAdjustments = this.adjustment_form.controls.productAdjustments as FormArray;
    let productString: string = productAdjustments.controls[idx].get('product').value;
    let productValues = productString.split(this.PRODUCT_SEPARATOR);
    if (type == 'network') {
      return productValues[0];
    } else if (type == 'product') {
      return productValues[1];
    } else {
      return productValues[2];
    }
  }

  addProductAdjustments(): void {
    let productAdjustments = this.adjustment_form.controls.productAdjustments as FormArray;
    productAdjustments.clear();
    this.productAdjustmentCategories.forEach((product) => {
      let productAdjustment: FormGroup = this.fb.group({
        product: product,
        currentRiskFactor: [''],
        riskFactor: ['', [ValidationService.decimalValidator]],
        uwAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        employerRiskFactor: ['', [ValidationService.decimalValidator]],
        salesAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        wholeHealthAdjustmentFactor: ['', [ValidationService.decimalValidator]],
        addOnCost: ['', [ValidationService.addonPMPMValidator]]
      });

      productAdjustment.valueChanges.subscribe((val) => {
        this.onProductLevelAdjustment(val);
      });
      productAdjustments.push(productAdjustment);
    });
  }

  private setUWNotesWithDclnToQtRsn(): void {
    let declineReasons;
    let statusReasons;
    if (
      typeof this.uwAdjustment.statusReasons != 'undefined' &&
      this.uwAdjustment.statusReasons != null &&
      this.uwAdjustment.statusReasons.length > 0 &&
      StringUtils.isEqual(this.quoteDetail.status, CommonConstants.declinedStatus)
    ) {
      declineReasons = this.uwAdjustment.statusReasons;
      this.uwAdjustment.statusReasons.forEach((element) => {
        if (element != 'undefined') {
          if (statusReasons == null) {
            statusReasons = element;
          } else {
            if (!statusReasons.includes(element)) {
              statusReasons = statusReasons != '' && !element.includes(statusReasons) ? statusReasons + ';' + element : element;
            }
          }
        }
      });
      localStorage.setItem(
        'statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType,
        statusReasons
      );
    }
    this.setDeclineReasonsToUWNotes(declineReasons, false);
    if (this.processQuoteService.uwNotesToSales != '' && typeof this.actualDeclineReason != 'undefined' && this.actualDeclineReason != null) {
      this.uwAdjustment.uwNotesToSales = this.processQuoteService.uwNotesToSales;
    }
    if (typeof this.uwAdjustment.uwNotesToSales != 'undefined' && this.uwAdjustment.uwNotesToSales != null && this.uwAdjustment.uwNotesToSales != '') {
      this.adjustment_form.get('uwNotesToSales').setValue(this.uwAdjustment.uwNotesToSales || '', { emitEvent: false });
      this.userTypedDeclineReasons = this.uwAdjustment.uwNotesToSales;
      this.processQuoteService.setUwNotesToSales(this.uwAdjustment.uwNotesToSales);
      this.emitDeclineCheckboxOptions();
    }
    this.adjustment_form.get('uwNotesToSales').setValue(this.uwAdjustment.uwNotesToSales || '', { emitEvent: false });
  }

  setFormValue() {
    this.setUWNotesWithDclnToQtRsn();
    this.adjustment_form.get('uwComments').setValue(this.uwAdjustment.uwComments || '', { emitEvent: false });
    this.adjustment_form.get('exhibitName').setValue(this.uwAdjustment.exhibitName || '', { emitEvent: false });
    this.userSelectedTier = { tier: '' + this.requestedTier };
    if (!this.showRateActionAdj) {
      this.setQuoteLevelAdjustments();
      if (this.allPlansLoaded && this.fundingType == 'FI') {
        this.setProductLevelAdjustments(this.uwAdjustment.quoteAdjustments || {});
      }
    }
    this.setCustomTierRatio();
    if (!this.showRateActionAdj && this.fundingType == 'ABF') {
      this.setComponentAdjustments();
      this.setRblAdjustments();
    }
    if (this.showRateActionAdj) {
      if (this.fundingType == 'ABF') this.setRateActionAdjValues();
      if (this.fundingType == 'FI') this.setFiRateActionAdjValues();
      if(this.quoteDetail.quotingType == CommonConstants.MEWA) this.setQuoteLevelAdjustments();
    }
  }

  setDeclineReasonsToUWNotes(reasons, formChanges) {
    let userTypedDeclineReasonsSplit: any[] = [];
    let userSelectedDeclineReasons: any[] = [];
    if (
      this.uwAdjustment != null &&
      typeof this.uwAdjustment != 'undefined' &&
      typeof this.uwAdjustment.uwNotesToSales != 'undefined' &&
      this.uwAdjustment.uwNotesToSales != null &&
      this.uwAdjustment.uwNotesToSales != ''
    ) {
      this.adjustment_form.get('uwNotesToSales').setValue(this.uwAdjustment.uwNotesToSales || '', { emitEvent: false });
      this.userTypedDeclineReasons = this.uwAdjustment.uwNotesToSales;
    } else if (typeof this.adjustment_form != 'undefined') {
      this.userTypedDeclineReasons = this.adjustment_form.get('uwNotesToSales').value;
    }

    if (reasons != null && this.declineResaonsFromUWAdjs != null && reasons.length === this.declineResaonsFromUWAdjs.length) {
      userSelectedDeclineReasons = this.declineResaonsFromUWAdjs;
    } else if (
      this.uwAdjustment != null &&
      typeof this.uwAdjustment != 'undefined' &&
      this.uwAdjustment.uwNotesToSales != null &&
      this.uwAdjustment.uwNotesToSales != '' &&
      formChanges
    ) {
      userSelectedDeclineReasons = this.uwAdjustment.uwNotesToSales;
    } else {
      if (reasons == null || reasons.length == 0) {
        if (
          typeof localStorage.getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType) !=
            'undefined' &&
          localStorage.getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType) != null
        ) {
          let declineOptionArray = localStorage
            .getItem('statusReasons' + '_' + this.opportunityData.quoteHeaderID + '_' + 'Medical' + '_' + this.opportunityData.fundingType)
            .split(';');
          reasons = declineOptionArray;
        }
      }
      userSelectedDeclineReasons = reasons;
    }
    if (this.actualDeclineReason == 'undefined' || this.actualDeclineReason == null) {
      if (this.userTypedDeclineReasons != null && userSelectedDeclineReasons != null && this.userTypedDeclineReasons.includes(';')) {
        let uWNotesSplitTrim: any[] = [];
        userTypedDeclineReasonsSplit = this.userTypedDeclineReasons.split(';');
        if (userTypedDeclineReasonsSplit.length > 0) {
          userTypedDeclineReasonsSplit.forEach((element) => {
            if (element != 'undefined') {
              let newElement = element.trim();
              uWNotesSplitTrim.push(newElement);
            }
          });
        }
        if (this.predefinedDeclineReasons.length === 0) {
          this.predefinedDeclineReasons = this.processQuoteService.declineOptionsFromBackend;
        }
        if (
          uWNotesSplitTrim &&
          typeof this.predefinedDeclineReasons != 'undefined' &&
          this.predefinedDeclineReasons != null &&
          this.predefinedDeclineReasons.length
        ) {
          this.actualDeclineReason = uWNotesSplitTrim.filter((x) => {
            return this.predefinedDeclineReasons.indexOf(x) == -1;
          });
        }
      } else {
        this.actualDeclineReason = this.userTypedDeclineReasons;
      }
    } else {
      this.actualDeclineReason = '';
      let uWNotesSplitTrim: any[] = [];
      if (this.userTypedDeclineReasons != null) {
        if (this.userTypedDeclineReasons.includes(';')) {
          userTypedDeclineReasonsSplit = this.userTypedDeclineReasons.split(';');
        } else {
          userTypedDeclineReasonsSplit.push(this.userTypedDeclineReasons);
        }
        if (userTypedDeclineReasonsSplit.length > 0) {
          userTypedDeclineReasonsSplit.forEach((element) => {
            if (element != 'undefined') {
              let newElement = element.trim();
              uWNotesSplitTrim.push(newElement);
            }
          });
        }
        var finalArray = uWNotesSplitTrim.filter((x) => {
          return this.predefinedDeclineReasons.findIndex((t) => t === x) === -1;
        });
        if (finalArray.length > 0) {
          finalArray.forEach((elementsArr) => {
            if (this.actualDeclineReason === '') {
              this.actualDeclineReason = elementsArr;
            } else {
              this.actualDeclineReason = this.actualDeclineReason + ';' + elementsArr;
            }
          });
        }
      } else {
        this.actualDeclineReason = this.userTypedDeclineReasons;
      }
    }

    let finalUWNote;
    if (this.actualDeclineReason != null && this.actualDeclineReason.length > 0 && this.actualDeclineReason.constructor === Array) {
      let actualDeclineReason;
      this.actualDeclineReason.forEach((element) => {
        if (actualDeclineReason == null) {
          actualDeclineReason = element;
        } else if (!actualDeclineReason.includes(element)) {
          actualDeclineReason = actualDeclineReason + ';' + element;
        }
      });
      this.actualDeclineReason = actualDeclineReason;
    }
    if (userSelectedDeclineReasons != null && userSelectedDeclineReasons.length > 0) {
      if (userSelectedDeclineReasons.constructor === Array) {
        userSelectedDeclineReasons.forEach((element) => {
          if (finalUWNote == null) {
            finalUWNote = this.actualDeclineReason != '' && !element.includes(this.actualDeclineReason) ? this.actualDeclineReason + ';' + element : element;
            this.processQuoteService.setUwNotesToSales(finalUWNote);
          } else if (!finalUWNote?.includes(element)) {
            if (finalUWNote === undefined) {
              finalUWNote = element;
            } else {
              finalUWNote = finalUWNote + ';' + element;
            }
            this.processQuoteService.setUwNotesToSales(finalUWNote);
          }
        });
        if (finalUWNote != null && finalUWNote.includes(';')) {
          finalUWNote = CommonUtil.htmlEntitiesToString(finalUWNote);
          if (finalUWNote.includes('; ')) {
            finalUWNote = finalUWNote.split('; ').join(';');
          }
          finalUWNote = finalUWNote.split(';').join('; ');
          finalUWNote = CommonUtil.convertSpecialCharToASCII(finalUWNote);
        }
        this.processQuoteService.setUwNotesToSales(finalUWNote);
      }
    } else {
      finalUWNote = this.actualDeclineReason;
      if (finalUWNote != null && finalUWNote.includes(';')) {
        finalUWNote = CommonUtil.htmlEntitiesToString(finalUWNote);
        if (finalUWNote.includes('; ')) {
          finalUWNote = finalUWNote.split('; ').join(';');
        }
        finalUWNote = finalUWNote.split(';').join('; ');
        finalUWNote = CommonUtil.convertSpecialCharToASCII(finalUWNote);
      }
      this.processQuoteService.setUwNotesToSales(finalUWNote);
    }
  }

  emitDeclineCheckboxOptions() {
    let uWNotesSplit: any[] = [];
    let uWNotesSplitTrim: any[] = [];

    if (typeof this.uwAdjustment.uwNotesToSales != 'undefined' && this.uwAdjustment.uwNotesToSales != null && this.uwAdjustment.uwNotesToSales.includes(';')) {
      uWNotesSplit = this.uwAdjustment.uwNotesToSales.split(';');
    } else {
      if (this.uwAdjustment.uwNotesToSales != null) {
        uWNotesSplit.push(this.uwAdjustment.uwNotesToSales);
      }
    }
    if (typeof uWNotesSplit != 'undefined' && uWNotesSplit.length > 0) {
      uWNotesSplit.forEach((element) => {
        let newElement = element.trim();
        uWNotesSplitTrim.push(newElement);
      });
    }
    if (this.predefinedDeclineReasons.length == 0) {
      this.predefinedDeclineReasons = this.processQuoteService.declineOptionsFromBackend;
    }
    if (uWNotesSplit != null && this.uwAdjustment.uwNotesToSales != '') {
      var declineChecboxes = this.predefinedDeclineReasons.filter((x) => {
        return uWNotesSplitTrim.findIndex((t) => t === x) != -1;
      });
      if (typeof declineChecboxes != 'undefined' && declineChecboxes != null) {
        const uniqueDeclineChecboxes = [...new Set(declineChecboxes)];
        this.declineReaonsToBeChecked.emit(uniqueDeclineChecboxes);
      }
    } else {
      this.declineReaonsToBeChecked.emit([]);
    }
  }

  initializeFactorValues(adjustments: any) {
    this.adjustmentKeys.forEach((adjKey) => {
      adjustments[adjKey] = '';
    });
  }

  setCalculatedFactorValues(adjustments: any, adjustmentFactors: any) {
    this.adjustmentKeys.forEach((adjKey) => {
      if (adjKey == 'currentRiskFactor') {
        adjustments[adjKey] = this.calculatedCurrentRiskFactorValue(adjustmentFactors[adjKey]);
      } else {
        adjustments[adjKey] =
          (adjKey == 'addOnCost' || adjKey == 'riskFactor') ? this.calculatedAddOnValue(adjustmentFactors[adjKey]) : this.calculatedFactorValue(adjustmentFactors[adjKey]);
      }
    });
  }

  setModifiedProdAdjustments(adjustments: any) {
    this.adjustmentKeys.forEach((adjKey) => {
      if (adjustments[adjKey]) {
        this.addModifiedProdAdjustmentsKey(adjustments['product'], adjKey);
      }
    });
  }

  resetModifiedProdAdjustments(product: string) {
    this.userModifiedProductAdjustments[product] = [];
  }

  hasModifiedProdAdjustmentsKey(product: string, key: string): boolean {
    return this.userModifiedProductAdjustments[product] && this.userModifiedProductAdjustments[product].indexOf(key) !== -1;
  }

  removeModifiedProdAdjustmentsKey(product: string, key: string) {
    if (this.userModifiedProductAdjustments && this.userModifiedProductAdjustments[product]) {
      let idx = this.userModifiedProductAdjustments[product].indexOf(key);
      if (idx != -1) {
        this.userModifiedProductAdjustments[product].splice(idx, 1);
      }
    }
  }

  addModifiedProdAdjustmentsKey(product: string, key: string) {
    if (!this.userModifiedProductAdjustments[product]) {
      this.userModifiedProductAdjustments[product] = [];
    }
    this.userModifiedProductAdjustments[product].push(key);
  }

  setQuoteLevelAdjustments(): any {
    let currentAdjustment = {};
    this.initializeFactorValues(currentAdjustment);
    if (this.uwAdjustment && this.uwAdjustment.quoteAdjustments) {
      let adjFactor = this.uwAdjustment.quoteAdjustments;
      this.setCalculatedFactorValues(currentAdjustment, adjFactor);
    }
    this.adjustment_form.get('quoteAdjustments').get('fiToAbfTarget').patchValue(this.premTrgtAdjFactor, { emitEvent: false });
    this.adjustment_form.get('quoteAdjustments').patchValue(currentAdjustment, { emitEvent: false });
    this.uwAdjustment['quoteAdjustments'] = currentAdjustment;
  }

  getTypeForAbfComponent(key) {
    return {
      'ASO Admin': 'asoAdmin',
      'SSL Premium': 'sslPremium',
      'ASL Premium': 'aslPremium',
      'Terminal Liability': 'terminalLiability',
      'Max Claims': 'maxClaims'
    }[key];
  }

  previousComponentAdjustment: any;
  previousRblAdjustment: any;
  setComponentAdjustments(): any {
    let currentAdjustment = {};
    if (this.uwAdjustment && this.uwAdjustment.componentAdjustments) {
      this.previousComponentAdjustment = JSON.parse(JSON.stringify(this.uwAdjustment.componentAdjustments));
      if (Array.isArray(this.previousComponentAdjustment)) {
        this.setCalculatedComponentsValues(currentAdjustment, this.previousComponentAdjustment);
        this.adjustment_form.get('componentAdjustments').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment['componentAdjustments'] = currentAdjustment;
      } else if (Object.keys(this.previousComponentAdjustment).length) {
        this.setComponentsDropdownValues(currentAdjustment, this.previousComponentAdjustment);
        this.adjustment_form.get('componentAdjustments').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment['componentAdjustments'] = currentAdjustment;
      }
    }
  }

  setRblAdjustments(): any {
    let currentAdjustment = {};
    if (this.uwAdjustment && this.uwAdjustment.rebalanceAdjustments) {
      this.previousRblAdjustment = JSON.parse(JSON.stringify(this.uwAdjustment.rebalanceAdjustments));
      if (this.previousRblAdjustment.fromComponent && this.previousRblAdjustment.toComponent) {
        this.setRblValues();
        this.setCalculatedRblValues(currentAdjustment, this.previousRblAdjustment.fromComponent, this.previousRblAdjustment.toComponent);
        this.adjustment_form.get('rebalanceAdjustments').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment['rebalanceAdjustments'] = currentAdjustment;
      } else if (this.previousRblAdjustment.percentageComponent) {
        this.disableRebalanaceAdjustments();
        currentAdjustment = this.previousRblAdjustment.percentageComponent;
        this.adjustment_form.get('percentageComponent').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment.rebalanceAdjustments['percentageComponent'] = currentAdjustment;
      } else if (this.previousRblAdjustment.adminFactor) {
        this.disableRebalanaceAdjustments();
        currentAdjustment = this.previousRblAdjustment;
        this.adjustment_form.get('percentageComponent').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment.rebalanceAdjustments['percentageComponent'] = currentAdjustment;
      } else if (Object.keys(this.previousRblAdjustment).length) {
        this.setRblValues();
        this.setRblCheckboxValues(currentAdjustment, this.previousRblAdjustment);
        this.adjustment_form.get('rebalanceAdjustments').patchValue(currentAdjustment, { emitEvent: false });
        this.uwAdjustment['rebalanceAdjustments'] = currentAdjustment;
      }
    }
  }

  setCalculatedRblValues(currentAdjustment, fromComponent, toComponent) {
    Object.keys(fromComponent).forEach((key) => {
      currentAdjustment[key + 'Adj'] = fromComponent[key];
      if (currentAdjustment[key + 'Adj']) {
        this[key + 'CB'] = true;
        this.adjustment_form
          .get('rebalanceAdjustments')
          .get(key + 'Adj')
          .enable();
        this.adjustment_form
          .get('rebalanceAdjustments')
          .get(key + 'Allocation')
          .disable();
        this.adjustment_form
          .get('rebalanceAdjustments')
          .get(key + 'Allocation')
          .setValue('');
        this.adjustment_form
          .get('rebalanceAdjustments')
          .get(key + 'Adj')
          .setValue('');
      }
    });
    Object.keys(toComponent).forEach((key) => {
      currentAdjustment[key + 'Allocation'] = toComponent[key];
    });
  }

  setRblCheckboxValues(currentAdjustment, adjFactor) {
    Object.keys(adjFactor).forEach((key) => {
      currentAdjustment[key] = adjFactor[key];
      if (currentAdjustment[key] && key.includes('Adj')) {
        this[key + 'CB'] = true;
        this.adjustment_form.get('rebalanceAdjustments').get(key).enable();
        this.adjustment_form
          .get('rebalanceAdjustments')
          .get(key.replace('Adj', '') + 'Allocation')
          .disable();
        this.adjustment_form
          .get('rebalanceAdjustments')
          .get(key.replace('Adj', '') + 'Allocation')
          .setValue('');
        this.adjustment_form.get('rebalanceAdjustments').get(key).setValue('');
      }
    });
  }

  setRblValues() {
    if (!this.adminFactorCB && !this.sslFactorCB && !this.aslFactorCB && !this.tlFactorCB && !this.mcfFactorCB) this.disableRebalanaceAdjustments();
    else {
      setTimeout(() => {
        this.rblKeys.forEach((key) => {
          if (key.includes('Adj') && this[key.replace('Adj', '') + 'CB']) {
            this.adjustment_form
              .get('rebalanceAdjustments')
              .get(key.replace('Adj', '') + 'Allocation')
              .disable();
            this.adjustment_form
              .get('rebalanceAdjustments')
              .get(key.replace('Adj', '') + 'Allocation')
              .setValue('');
            this.adjustment_form.get('rebalanceAdjustments').get(key).enable();
          } else if (key.includes('Adj')) {
            this.adjustment_form.get('rebalanceAdjustments').get(key).disable();
          }
        });
        this.rblKeys.forEach((key) => {
          if (key.includes('Adj') && !this[key.replace('Adj', '') + 'CB']) {
            this.adjustment_form
              .get('rebalanceAdjustments')
              .get(key.replace('Adj', '') + 'Allocation')
              .enable();
          }
        });
      });
    }
  }

  setComponentsDropdownValues(currentAdjustment, adjFactor) {
    Object.keys(adjFactor).forEach((key) => {
      if (adjFactor[key] === 'PMPM' || adjFactor[key] === 'Percent' || adjFactor[key] === 'PCPM') {
        currentAdjustment[key] = { label: adjFactor[key], value: adjFactor[key] };
      } else {
        currentAdjustment[key] = adjFactor[key];
      }
    });
  }

  setCalculatedComponentsValues(currentAdjustment, adjFactor) {
    adjFactor.forEach((adjObj) => {
      let key = this.getTypeForAbfComponent(adjObj.adjustmentType);
      currentAdjustment[key] = adjObj.adjustmentFactor;
      currentAdjustment[key + 'Type'] = { label: adjObj.adjustmentFactorType, value: adjObj.adjustmentFactorType };
    });
  }

  isSameProductadjustment_form(element: any, product: string): boolean {
    let prodCode = product.split(this.PRODUCT_SEPARATOR);
    let cdhpindicator = '';
    if (element['CDHPIndicator']) {
      cdhpindicator = element['CDHPIndicator'];
    } else if (element['cdhpindicator']) {
      cdhpindicator = element['cdhpindicator'];
    }
    if (element.networkName) {
      return element.networkName == prodCode[0] && element.networkType == prodCode[1] && cdhpindicator == prodCode[2];
    }
    return product == element.product;
  }

  getFilteredProductAdjustment(productAdjustments: any, product: string): any[] {
    return productAdjustments && Array.isArray(productAdjustments)
      ? productAdjustments.filter((element) => this.isSameProductadjustment_form(element, product))
      : undefined;
  }

  getProductAdjustmentIndex(product: string): number {
    return this.uwAdjustment.productAdjustments && Array.isArray(this.uwAdjustment.productAdjustments)
      ? this.uwAdjustment.productAdjustments.findIndex((element) => this.isSameProductadjustment_form(element, product))
      : -1;
  }

  setProductLevelAdjustments(quoteAdjustments: any) {
    let updatedProdAdjustments = [];
    let productAdjustments = this.adjustment_form.controls.productAdjustments as FormArray;
    for (let c of productAdjustments.controls) {
      let prodKey = c.get('product').value;
      let prodAdjustment = this.getFilteredProductAdjustment(this.uwAdjustment.productAdjustments || [], prodKey);
      let currentAdjustment = {};
      currentAdjustment['product'] = prodKey;
      if (prodAdjustment && Array.isArray(prodAdjustment) && prodAdjustment.length === 1) {
        this.setCalculatedFactorValues(currentAdjustment, prodAdjustment[0]);
        this.setModifiedProdAdjustments(currentAdjustment);
        this.uwAdjustment.productAdjustments.push(currentAdjustment);
      } else {
        this.setCalculatedFactorValues(currentAdjustment, quoteAdjustments);
        this.resetModifiedProdAdjustments(prodKey);
      }
      updatedProdAdjustments.push(currentAdjustment);
    }

    this.adjustment_form.get('productAdjustments').setValue(updatedProdAdjustments, { emitEvent: false });
  }

  calculatedFloatValue(factor: any): any {
    let floatValue = parseFloat(factor);
    if (isNaN(floatValue) || factor == '') {
      return '';
    } else {
      return floatValue !== 0 ? floatValue : '';
    }
  }

  calculatedFactorValue(factor: any): any {
    let floatValue = this.calculatedFloatValue(factor);
    return floatValue !== 1 && floatValue ? floatValue : '';
  }

  calculatedAddOnValue(addOn: any): any {
    return this.calculatedFloatValue(addOn);
  }

  calculatedCurrentRiskFactorValue(factor: any): any {
    let floatValue = parseFloat(factor);
    if (isNaN(floatValue) || factor === '' || factor === null || factor === undefined) {
      return '';
    } else {
      return floatValue;  
    }
  }

  forceQuoteLevelAdjustments() {
    this.uwAdjustment['productAdjustments'] = [];
    this.copyQuoteAdjustmentsToProductLevel(this.uwAdjustment['quoteAdjustments']);
    this.propogateAdjustmentChanges(true);
  }

  getProdAdjustmentValueBasedOnKey(idx: number, key: string): string {
    return (
      this.uwAdjustment && this.uwAdjustment.productAdjustments && this.uwAdjustment.productAdjustments[idx] && this.uwAdjustment.productAdjustments[idx][key]
    );
  }

  setProdAdjustmentValueBasedOnKey(idx: number, key: string, value: string) {
    if (!this.uwAdjustment.productAdjustments) {
      this.uwAdjustment.productAdjustments = [];
    }
    if (!this.uwAdjustment.productAdjustments[idx]) {
      this.uwAdjustment.productAdjustments[idx] = {};
    }
    this.uwAdjustment.productAdjustments[idx][key] = value;
  }

  setControlValues(c: AbstractControl, adjustment: any, key?: string) {
    let productKey = c.get('product').value;
    if (key) {
      if (key == 'currentRiskFactor') {
        if (typeof c.get(key) != 'undefined' && c.get(key) != null) {
          c.get(key).setValue(this.calculatedCurrentRiskFactorValue(adjustment[key]), { emitEvent: false });
        }
      } else if (key == 'addOnCost') {
        if (typeof c.get(key) == 'undefined' || c.get(key) == null) {
          c.get(key).setValue(this.calculatedAddOnValue(adjustment[key]), { emitEvent: false });
        }
      } else {
        if (typeof c.get(key) == 'undefined' || c.get(key) == null) {
          c.get(key).setValue(this.calculatedFactorValue(adjustment[key]), { emitEvent: false });
        }
      }
      let idx: number = this.getProductAdjustmentIndex(productKey);
      if (idx !== -1) {
        this.setProdAdjustmentValueBasedOnKey(idx, key, adjustment[key]);
        this.removeModifiedProdAdjustmentsKey(productKey, key);
      }
    } else {
      this.adjustmentKeys.forEach((adjKey) => {
        let calculatedValue;
        if (adjKey == 'currentRiskFactor') {
          calculatedValue = this.calculatedCurrentRiskFactorValue((adjustment && adjustment[adjKey]) || '');
        } else if (adjKey == 'addOnCost') {
          calculatedValue = this.calculatedAddOnValue((adjustment && adjustment[adjKey]) || '');
        } else {
          calculatedValue = this.calculatedFactorValue((adjustment && adjustment[adjKey]) || '');
        }
        c.get(adjKey).setValue(calculatedValue, { emitEvent: false });
      });
    }
  }

  copyQuoteAdjustmentsToProductLevel(adjustment: any) {
    let productAdjustments = this.adjustment_form.controls.productAdjustments as FormArray;
    for (let c of productAdjustments.controls) {
      this.setControlValues(c, adjustment);
    }
  }

  updateQuoteAdjustmentsToProductLevel(key: string, adjustment: any, prevValue: any) {
    let productAdjustments = this.adjustment_form.controls.productAdjustments as FormArray;
    for (let c of productAdjustments.controls) {
      let productKey = c.get('product').value;
      let prodAdjustIdx: number = this.getProductAdjustmentIndex(productKey);
      let value = this.getProdAdjustmentValueBasedOnKey(prodAdjustIdx, key);
      if (prodAdjustIdx === -1 || (prodAdjustIdx !== -1 && (!this.hasModifiedProdAdjustmentsKey(productKey, key) || value == prevValue))) {
        this.setControlValues(c, adjustment, key);
      }
    }
  }

  setQuotelevelValueChanges(key: string, value: string) {
    let newAdjFactors: any;
    if (this.uwAdjustment['quoteAdjustments']) {
      newAdjFactors = { ...this.uwAdjustment['quoteAdjustments'] };
    } else {
      newAdjFactors = {};
    }
    let prevValue = newAdjFactors[key];
    newAdjFactors[key] = value;
    this.uwAdjustment['quoteAdjustments'] = newAdjFactors;
    if (this.fundingType == 'FI') this.updateQuoteAdjustmentsToProductLevel(key, newAdjFactors, prevValue);
    this.propogateAdjustmentChanges(true);
  }

  setComponentlevelValueChanges(key: string, value: string) {
    let keyType = key + 'Type';
    if (this.adjustment_form.get('componentAdjustments').get(keyType).value && !this.adjustment_form.get('componentAdjustments').get(key).errors) {
      let componentValues: any;
      if (this.uwAdjustment['componentAdjustments']) {
        componentValues = { ...this.uwAdjustment['componentAdjustments'] };
      } else {
        componentValues = {};
      }
      componentValues[key] = value;
      componentValues[keyType] = this.adjustment_form.get('componentAdjustments').get(keyType).value.label;
      this.uwAdjustment['componentAdjustments'] = componentValues;
    }
    this.propogateAdjustmentChanges(true);
  }
  setRblValueChanges(key: string, value: string) {
    if (!this.adjustment_form.get('rebalanceAdjustments').get(key).errors) {
      let rblValues: any;
      if (this.uwAdjustment['rebalanceAdjustments']) {
        rblValues = { ...this.uwAdjustment['rebalanceAdjustments'] };
      } else {
        rblValues = {};
      }
      rblValues[key] = value;
      this.uwAdjustment['rebalanceAdjustments'] = rblValues;
    }
    this.propogateAdjustmentChanges(true);
  }

  setRblPercentValueChanges(key: string, value: string) {
    if (!this.adjustment_form.get('percentageComponent').get(key).errors) {
      let rblValues: any;
      if (this.uwAdjustment['percentageComponent']) {
        rblValues = { ...this.uwAdjustment['percentageComponent'] };
      } else {
        rblValues = {};
      }
      rblValues[key] = value;
      this.uwAdjustment['percentageComponent'] = rblValues;
    }
    this.propogateAdjustmentChanges(true);
  }

  onRateActionValueChanges(key: string, value: any) {
    let newAdjFactors: any;
    if (!this.adjustment_form.get('abfRateActionAdjustment').get(key).errors) {
      if (key == 'adjustedRateActionPercent' && value) {
        let renewalWHAPercent = this.adjustment_form.get('abfRateActionAdjustment').get('renewalWHAPercent').value;
        this.calculateUWadj(value, renewalWHAPercent);
      } else if (key == 'renewalWHAPercent') {
        let rateActionPercent = this.adjustment_form.get('abfRateActionAdjustment').get('adjustedRateActionPercent').value;
        this.calculateUWadj(rateActionPercent, value);
      } else if (value && key != 'maxPaidClaim') {
        this.OnComponentRateActionChages(key, value);
      }
      if (this.uwAdjustment['abfRateActionAdjustment']) {
        newAdjFactors = { ...this.uwAdjustment['abfRateActionAdjustment'] };
      } else {
        newAdjFactors = {};
      }
      newAdjFactors[key] = value;
      this.uwAdjustment['abfRateActionAdjustment'] = newAdjFactors;
    }
    this.propogateAdjustmentChanges(true);
  }

  onFiRateActionValueChanges(key: string, value: any) {
    let newAdjFactors: any;
    if (!this.adjustment_form.get('fiRateActionAdjustment').get(key).errors) {
      if (key == 'adjustedRateActionPercent' && value) {
        let renewalWHAPercent = this.adjustment_form.get('fiRateActionAdjustment').get('renewalWHAPercent').value;
        this.calculateUWadj(value, renewalWHAPercent);
      } else if (key == 'renewalWHAPercent') {
        let rateActionPercent = this.adjustment_form.get('fiRateActionAdjustment').get('adjustedRateActionPercent').value;
        this.calculateUWadj(rateActionPercent, value);
      } else if (key == 'isFlatRateApplied') {
        if (this.adjustment_form.get('fiRateActionAdjustment').get('isFlatRateApplied').value) {
          this.isTierAdjDisabled = true;
        } else {
          this.isTierAdjDisabled = false;
        }
        let renewalWHAPercent = this.adjustment_form.get('fiRateActionAdjustment').get('renewalWHAPercent').value;
        let rateActionPercent = this.adjustment_form.get('fiRateActionAdjustment').get('adjustedRateActionPercent').value;
        this.calculateUWadj(rateActionPercent, renewalWHAPercent);
      } else if (value && key != 'maxPaidClaim') {
        this.OnComponentRateActionChages(key, value);
      }
      if (this.uwAdjustment['fiRateActionAdjustment']) {
        newAdjFactors = { ...this.uwAdjustment['fiRateActionAdjustment'] };
      } else {
        newAdjFactors = {};
      }
      newAdjFactors[key] = value;
      this.uwAdjustment['fiRateActionAdjustment'] = newAdjFactors;
    }
    this.propogateAdjustmentChanges(true);
  }

  updateMpcOnRateActionChange() {
    this.uwService.featutePlanSupressSubject.next({ plans: this.featuredpLanList });
  }

  setNonAdjustmentFields(key: string, val: any) {
    this.uwAdjustment[key] = val;
    this.userTypedDeclineReasons = val;
    this.processQuoteService.setUwNotesToSales(val);
  }

  onFormValueChanges() {
    this.adjustment_form.get('uwNotesToSales').valueChanges.subscribe((val) => {
      this.setNonAdjustmentFields('uwNotesToSales', val);
      this.processQuoteService.declineOptionsValues.subscribe((value) => {
        if (value != null) {
          this.setDeclineReasonsToUWNotes(value, true);
        }
      });
    });
    this.adjustment_form.get('uwComments').valueChanges.subscribe((val) => {
      this.setNonAdjustmentFields('uwComments', val);
    });
    this.adjustment_form.get('exhibitName').valueChanges.subscribe((val) => {
      this.setNonAdjustmentFields('exhibitName', val);
    });

    if (!this.showRateActionAdj || this.quoteDetail.quotingType == CommonConstants.MEWA) {
      this.adjustmentKeys.forEach((adjKey) => {
        this.adjustment_form
          .get('quoteAdjustments')
          .get(adjKey)
          .valueChanges.subscribe((val) => {
            this.setQuotelevelValueChanges(adjKey, val);
          });
      });
    }
    this.factorKeys.forEach((adjKey) => {
      this.adjustment_form
        .get('customTierRatio')
        .get(adjKey)
        .valueChanges.subscribe((val) => {
          this.setCustomTierRatioChanges(adjKey, val);
        });
    });
  }

  onProductLevelAdjustment(data?: any) {
    if (!(this.uwAdjustment.productAdjustments && Array.isArray(this.uwAdjustment.productAdjustments))) {
      this.uwAdjustment.productAdjustments = [];
    }
    let prodAdjustIdx: number = this.getProductAdjustmentIndex(data.product);
    let quoteAdjustments = this.uwAdjustment.quoteAdjustments ? this.uwAdjustment.quoteAdjustments : {};
    let processedAdjustment = { ...data };
    let prodKeys = data.product.split(this.PRODUCT_SEPARATOR);
    processedAdjustment['networkName'] = prodKeys[0];
    processedAdjustment['networkType'] = prodKeys[1];
    processedAdjustment['CDHPIndicator'] = prodKeys[2];

    this.adjustmentKeys.forEach((adjKey) => {
      if (!this.hasSameValue(data[adjKey], quoteAdjustments[adjKey])) {
        this.addModifiedProdAdjustmentsKey(data.product, adjKey);
      }
    });

    if (prodAdjustIdx === -1) {
      this.uwAdjustment.productAdjustments.push(processedAdjustment);
    } else {
      this.uwAdjustment.productAdjustments[prodAdjustIdx] = processedAdjustment;
    }
    this.propogateAdjustmentChanges(true);
  }

  isNumber(evt) {
    var el = evt.target;
    var charCode = evt.charCode;
    var number = el.value.split('.');
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (number.length > 1 && charCode == 46) {
      return false;
    }
    var caratPos = this.getSelectionStart(el);
    var dotPos = el.value.indexOf('.');
    if (caratPos > dotPos && dotPos > -1 && number[1].length > 10) {
      return false;
    }
    return true;
  }

  getSelectionStart(o) {
    return o.selectionStart;
  }

  setActiveTab(type: string) {
    this.activeTab = type;
  }

  setRblActiveTab(type: string) {
    this.rblActiveTab = type;
  }

  trackByFn(index: any, item: any) {
    return index;
  }

  hasSameValue(prodFactor: string, quoteFactor: string): boolean {
    if (prodFactor && quoteFactor) {
      let floatProdFactor = parseFloat(prodFactor);
      let floatQuoteFactor = parseFloat(quoteFactor);
      if (isNaN(floatProdFactor) && isNaN(floatQuoteFactor)) {
        return true;
      } else if (!isNaN(floatProdFactor) && !isNaN(floatQuoteFactor)) {
        return floatProdFactor == floatQuoteFactor;
      }
    } else if (!prodFactor && !quoteFactor) {
      return true;
    }
    return false;
  }

  setCustomTierRatio(): void {
    let tierKey = this.requestedTier + '-tier';
    this.customTierRatio = this.customRateTierFactor[tierKey] || {};
    if (Object.keys(this.customTierRatio).length == 0) {
      this.customTierRatio = this.currentRateTierFactor[tierKey] || {};
    }
    this.factorKeys.forEach((key) => {
      this.customTierRatio[key] = this.getTierFactorValue('custom', key);
    });
    this.adjustment_form.get('customTierRatio').setValue(this.customTierRatio, { emitEvent: false });
    this.uwAdjustment['customTierRatio'] = this.customTierRatio;
    this.uwAdjustment['tierRatioCalculationType'] = this.selectedTierRatioCalculationType;
    this.isCustomTierSelected = this.selectedTierRatioCalculationType == 'Custom';
  }

  getTierFactorValue(type: string, factor: string): number | string {
    let floatValue = 0;
    switch (type) {
      case 'standard':
        floatValue = this.calculatedFloatValue(this.standardTierRatio[factor]);
        break;
      case 'current':
        floatValue = this.calculatedFloatValue(this.currentTierRatio[factor]);
        break;
      case 'custom':
        floatValue = this.calculatedFloatValue(this.customTierRatio[factor]);
        break;
    }
    return floatValue ? floatValue.toFixed(3) : '';
  }

  hasAllCustomTierFactor(tierRatio: any): void {
    let factorKeys = ['eeFactor'];
    switch (this.requestedTier * 1) {
      case 5:
        factorKeys.push('ekFactor');
      case 4:
        factorKeys.push('esFactor');
        factorKeys.push('ecFactor');
      case 3:
        if (this.requestedTier * 1 == 3) {
          factorKeys.push('e1Factor');
        }
      case 2:
        factorKeys.push('efFactor');
    }

    let errValue = false;
    this.erredFactors = {};
    factorKeys.forEach((key) => {
      this.erredFactors[key] = !this.calculatedFloatValue(tierRatio[key]);
      errValue = errValue || this.erredFactors[key];
    });
    this.isCustomTierSelectable = !errValue;

    this.propogateAdjustmentChanges(true);
  }

  onTierSelect(type: string) {
    this.tierSelectionFromUI = type;
    this.selectedTierRatioCalculationType = type;
    this.isCustomTierSelected = type == 'Custom';
    this.propogateAdjustmentChanges(true, true);
  }

  setCustomTierRatioChanges(key: string, value: string) {
    let tierKey = this.requestedTier + '-tier';
    this.customTierRatio[key] = value;
    this.customRateTierFactor[tierKey] = this.customTierRatio;
    this.hasAllCustomTierFactor(this.customTierRatio);
    this.recalculateCustomTierFactorMultiplier();
    this.propogateAdjustmentChanges(true, true);
  }

  hasCurrentTierFactor(): boolean {
    return Object.keys(this.currentTierRatio).length > 0 && this.checkIsCurrentTierRatioEligible();
  }
  checkIsCurrentTierRatioEligible() {
    if (this.requestedTier == this.quoteDetail.medicalInputTier && this.isAllFeaturePlanMappingExist) {
      return true;
    } else {
      return false;
    }
  }
  hasStandardTierFactor(): boolean {
    let existedTier = this.checkTierAvailableOrNot();
    if (StringUtils.isUndefined(existedTier)) {
      return false;
    } else {
      return true;
    }
  }
  checkTierAvailableOrNot() {
    let availableTiers = this.quoteDetail.availableTiers;
    return availableTiers.find((availableTiers) => availableTiers.tier == this.requestedTier);
  }
  cleanupAdjustmentValues(shouldCheckValue: boolean, adjustments?: any): any {
    let newAdjustment = {};
    let hadAdjustmentValue = false;
    if (adjustments) {
      let addOnCost = adjustments.addOnCost ? parseFloat(adjustments.addOnCost) : 0;
      if (!isNaN(addOnCost) && ((shouldCheckValue && addOnCost !== 0) || !shouldCheckValue)) {
        newAdjustment['addOnCost'] = addOnCost;
        hadAdjustmentValue = true;
      }
      let currentRiskFactor = (adjustments.currentRiskFactor !== '' && adjustments.currentRiskFactor !== null && adjustments.currentRiskFactor !== undefined) 
        ? parseFloat(adjustments.currentRiskFactor) : null;
      if (currentRiskFactor !== null && !isNaN(currentRiskFactor)) {
        newAdjustment['currentRiskFactor'] = currentRiskFactor;
        hadAdjustmentValue = true;
      }
      let riskFactor = adjustments.riskFactor ? parseFloat(adjustments.riskFactor) : 0;
      if (!isNaN(riskFactor) && ((shouldCheckValue && riskFactor > 0) || !shouldCheckValue)) {
        newAdjustment['riskFactor'] = riskFactor !== 0 ? riskFactor : 1;
        hadAdjustmentValue = true;
      }
      let uwAdjustmentFactor = adjustments.uwAdjustmentFactor ? parseFloat(adjustments.uwAdjustmentFactor) : 0;
      if (!isNaN(uwAdjustmentFactor) && ((shouldCheckValue && uwAdjustmentFactor > 0 && uwAdjustmentFactor !== 1) || !shouldCheckValue)) {
        newAdjustment['uwAdjustmentFactor'] = uwAdjustmentFactor !== 0 ? uwAdjustmentFactor : 1;
        hadAdjustmentValue = true;
      }
      let employerRiskFactor = adjustments.employerRiskFactor ? parseFloat(adjustments.employerRiskFactor) : 0;
      if (!isNaN(employerRiskFactor) && ((shouldCheckValue && employerRiskFactor > 0 && employerRiskFactor !== 1) || !shouldCheckValue)) {
        newAdjustment['employerRiskFactor'] = employerRiskFactor !== 0 ? employerRiskFactor : 1;
        hadAdjustmentValue = true;
      }
      let salesAdjustmentFactor = adjustments.salesAdjustmentFactor ? parseFloat(adjustments.salesAdjustmentFactor) : 0;
      if (!isNaN(salesAdjustmentFactor) && ((shouldCheckValue && salesAdjustmentFactor > 0 && salesAdjustmentFactor !== 1) || !shouldCheckValue)) {
        newAdjustment['salesAdjustmentFactor'] = salesAdjustmentFactor !== 0 ? salesAdjustmentFactor : 1;
        hadAdjustmentValue = true;
      }
      let wholeHealthAdjustmentFactor = adjustments.wholeHealthAdjustmentFactor ? parseFloat(adjustments.wholeHealthAdjustmentFactor) : 0;
      if (
        !isNaN(wholeHealthAdjustmentFactor) &&
        ((shouldCheckValue && wholeHealthAdjustmentFactor > 0 && wholeHealthAdjustmentFactor !== 1) || !shouldCheckValue)
      ) {
        newAdjustment['wholeHealthAdjustmentFactor'] = wholeHealthAdjustmentFactor !== 0 ? wholeHealthAdjustmentFactor : 1;
        hadAdjustmentValue = true;
      }
    }

    return hadAdjustmentValue ? newAdjustment : undefined;
  }

  cleanupProductLevelAdjustments(adjustments?: any[]): any {
    let productAdjustments = [];
    let hadAdjustmentValue = false;
    if (adjustments && Array.isArray(adjustments) && adjustments.length > 0) {
      adjustments.forEach((adj) => {
        let cleanedupValue = this.cleanupAdjustmentValues(false, adj);
        if (cleanedupValue) {
          cleanedupValue.networkName = adj.networkName;
          cleanedupValue.networkType = adj.networkType;
          cleanedupValue.CDHPIndicator = adj.CDHPIndicator;
          if (cleanedupValue.addOnCost === 0) {
            cleanedupValue.addOnCost = '';
          }
          if (cleanedupValue.uwAdjustmentFactor === 1) {
            cleanedupValue.uwAdjustmentFactor = '';
          }
          if (cleanedupValue.employerRiskFactor === 1) {
            cleanedupValue.employerRiskFactor = '';
          }
          if (cleanedupValue.salesAdjustmentFactor === 1) {
            cleanedupValue.salesAdjustmentFactor = '';
          }
          if (cleanedupValue.wholeHealthAdjustmentFactor === 1) {
            cleanedupValue.wholeHealthAdjustmentFactor = '';
          }
          productAdjustments.push(cleanedupValue);
          hadAdjustmentValue = true;
        }
      });
    }
    return hadAdjustmentValue ? productAdjustments : undefined;
  }

  cleanupCustomTierFactors(tierFactors: any): any {
    let retValue;
    if (tierFactors && Object.keys(tierFactors).length) {
      retValue = {};
      this.factorKeys.forEach((key) => {
        if (tierFactors[key]) {
          retValue[key] = tierFactors[key];
        }
      });
    }
    return retValue;
  }

  validateQuoteAdjustmentControls(quoteAdjustments: AbstractControl): boolean {
    let retValue = true;
    this.adjustmentKeys.forEach((adjKey) => {
      retValue = retValue && quoteAdjustments.get(adjKey).valid;
    });
    return retValue;
  }

  validateComponentAdjustmentControls(componentAdjustments: AbstractControl): boolean {
    let retValue = true;
    this.componentKeys.forEach((adjKey) => {
      if (componentAdjustments.get(adjKey).status != 'DISABLED') {
        retValue = retValue && componentAdjustments.get(adjKey).valid;
      }
    });
    return retValue;
  }

  validatePercentAdjustmentControls(percentAdjustments: AbstractControl): boolean {
    let retValue = true;
    this.percentKeys.forEach((adjKey) => {
      retValue = retValue && percentAdjustments.get(adjKey).valid;
    });
    if (this.hasInValidAllocationByPercent()) retValue = false;
    return retValue;
  }

  validateRblAdjustmentControls(rblAdjustments: AbstractControl): boolean {
    let retValue = true;
    this.rblKeys.forEach((adjKey) => {
      if (rblAdjustments.get(adjKey).status != 'DISABLED') retValue = retValue && rblAdjustments.get(adjKey).valid;
    });

    if (this.hasInValidAllocation()) retValue = false;
    return retValue;
  }

  validateProductAdjustmentControls(productAdjustments: FormArray): boolean {
    let retValue = true;
    for (let c of productAdjustments.controls) {
      this.adjustmentKeys.forEach((adjKey) => {
        retValue = retValue && c.get(adjKey).valid;
      });
    }
    return retValue;
  }

  validateRateActionAdjControls(rateActionAdjControl: AbstractControl): boolean {
    for (let key of this.rateActionValueKeys) {
      if (rateActionAdjControl.get(key).invalid) {
        return false;
      }
    }
    return true;
  }

  validateFiRateActionAdjControls(rateActionAdjControl: AbstractControl): boolean {
    for (let key of this.FiRateActionValueKeys) {
      if (rateActionAdjControl.get(key).invalid) {
        return false;
      }
    }
    return true;
  }

  validateCustomTierControls(customRatio: AbstractControl): boolean {
    let retValue = true;
    // If the form is not valid and the user selected Custom option
    if (this.selectedTierRatioCalculationType === 'Custom') {
      let tierFactorKeys = this.tierBasedFactorKeys[this.requestedTier * 1 + '-tier'];
      tierFactorKeys.forEach((element) => {
        retValue = retValue && customRatio.get(element).valid;
      });
    }
    return retValue;
  }

  propogateAdjustmentChanges(shouldRecalculate: boolean, isTierChange: boolean = false) {
    if (this.showRateActionAdj) {
      this.setCustomTierData();
      if (this.quoteDetail.opportunityType == 'Renewal Local' && this.fundingType == 'ABF' && this.quoteDetail?.factors?.experienceFactors && this.customTierRatioTypeRateActionFixEnabled) {
        let renewalWHAPercent = this.uwAdjustment?.abfRateActionAdjustment?.renewalWHAPercent ? this.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent : 0;
        let rateActionPercent = this.uwAdjustment?.abfRateActionAdjustment?.adjustedRateActionPercent;
        let calulatedExpAdj = this.callRateAction(rateActionPercent, this.fundingType);
        this.uwAdjustment.abfRateActionAdjustment['totalQlAdj'] =
          calulatedExpAdj != this.uwAdjustment?.abfRateActionAdjustment?.['expAdj'] ? calulatedExpAdj : '';
        if (this.fundingType == 'FI') {
          this.adjustment_form?.get('fiRateActionAdjustment')?.get('totalQlAdj')?.setValue(this.uwAdjustment?.abfRateActionAdjustment?.['totalQlAdj']);
        } else {
          this.adjustment_form?.get('abfRateActionAdjustment')?.get('totalQlAdj')?.setValue(this.uwAdjustment?.abfRateActionAdjustment?.['totalQlAdj']);
        }
        if (isTierChange) {
          this.calculateUWadj(this.uwAdjustment?.abfRateActionAdjustment?.adjustedRateActionPercent, renewalWHAPercent);
        }
      }
      if (shouldRecalculate) {
        if (this.fundingType == 'FI') {
          this.adjustmentsUpdated.emit({
            customTierRatio: this.validateCustomTierControls(this.adjustment_form.controls.customTierRatio),
            fiRateActionAdjustment: this.validateFiRateActionAdjControls(this.adjustment_form.controls.fiRateActionAdjustment),
            whAdjustmentsDetails: this.whAdjustmentsDetails
          });
        }
        if (this.fundingType == 'ABF') {
          if (this.quoteDetail && this.quoteDetail.medical && this.planListForRtAtnCalc.length) {
            this.initialComponentTierRates = this.uwService.calculateQtLvlAdjAndComponentRates(this.planListForRtAtnCalc, this.quoteDetail);
            this.uwAdjustment['componentTierTotalRates'] = this.uwService.calculateRateActionRatesOnIntialLoad(
              this.planListForRtAtnCalc,
              this.quoteDetail,
              this.uwAdjustment.abfRateActionAdjustment,
              this.initialComponentTierRates,
              false
            );
          }
          this.adjustmentsUpdated.emit({
            customTierRatio: this.validateCustomTierControls(this.adjustment_form.controls.customTierRatio),
            abfRateActionAdjustment: this.validateRateActionAdjControls(this.adjustment_form.controls.abfRateActionAdjustment),
            whAdjustmentsDetails: this.whAdjustmentsDetails
          });
        }
        if (this.quoteDetail.quotingType == CommonConstants.MEWA) {
          this.adjustmentsUpdated.emit({
            quoteAdjustments: this.validateQuoteAdjustmentControls(this.adjustment_form.controls.quoteAdjustments),
            whAdjustmentsDetails: this.whAdjustmentsDetails
          });
        }
      }
    } else {
      if (this.fundingType == 'FI' && this.allPlansLoaded) {
        this.uwAdjustment.productAdjustments = this.cleanupProductLevelAdjustments(this.cleanupAdjustments());
      }
      this.uwAdjustment.quoteAdjustments = this.cleanupAdjustmentValues(true, this.uwAdjustment.quoteAdjustments);
      this.setCustomTierData();
      if (shouldRecalculate) {
        if (this.fundingType == 'FI') {
          this.adjustmentsUpdated.emit({
            quoteAdjustments: this.validateQuoteAdjustmentControls(this.adjustment_form.controls.quoteAdjustments),
            productAdjustments: this.validateProductAdjustmentControls(this.adjustment_form.controls.productAdjustments as FormArray),
            customTierRatio: this.validateCustomTierControls(this.adjustment_form.controls.customTierRatio),
            whAdjustmentsDetails: this.whAdjustmentsDetails
          });
        } else if (this.fundingType == 'ABF') {
          this.adjustmentsUpdated.emit({
            quoteAdjustments: this.validateQuoteAdjustmentControls(this.adjustment_form.controls.quoteAdjustments),
            componentAdjustments: this.validateComponentAdjustmentControls(this.adjustment_form.controls.componentAdjustments),
            rebalanceAdjustments: this.validateRblAdjustmentControls(this.adjustment_form.controls.rebalanceAdjustments),
            percentageComponent: this.validatePercentAdjustmentControls(this.adjustment_form.controls.percentageComponent),
            customTierRatio: this.validateCustomTierControls(this.adjustment_form.controls.customTierRatio),
            whAdjustmentsDetails: this.whAdjustmentsDetails
          });
        }
        else if (this.quoteDetail.quotingType == CommonConstants.MEWA) {
          this.adjustmentsUpdated.emit({
            quoteAdjustments: this.validateQuoteAdjustmentControls(this.adjustment_form.controls.quoteAdjustments),
            whAdjustmentsDetails: this.whAdjustmentsDetails
          });
        }
      }
    }
  }
  // this method will callonchanging whole health popup specialities changes
  whAdjustmentsUpdates(event) {
    this.whAdjustmentsDetails = event;
    let whSavingValue = 0;
    if (this.whAdjustmentsDetails?.isInitialUpdate) {
      if (StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL)
      && !StringUtils.isEqual(this.quoteDetail.quotingType, CommonConstants.MEWA)) {
        whSavingValue = this.uwAdjustment.abfRateActionAdjustment?.renewalWHAPercent;
      } else {
        whSavingValue = this.uwAdjustment.quoteAdjustments?.wholeHealthAdjustmentFactor;
      }
      this.setFormValuesFromWholeHealth(whSavingValue);
    } else {
      if (this.whAdjustmentsDetails?.whSavingsAdjustment?.controls) {
        Object.keys(this.whAdjustmentsDetails.whSavingsAdjustment.controls).forEach((speciality) => {
          whSavingValue = whSavingValue + Number(this.whAdjustmentsDetails.whSavingsAdjustment.get(speciality).value);
        });
      }

      if (whSavingValue != 0 && !StringUtils.isUndefined(whSavingValue)) {
        if (StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
          whSavingValue = 100 * whSavingValue;
          whSavingValue = this.uwService.roundValueToFourDecimals(whSavingValue);
        } else {
          whSavingValue = 1 - whSavingValue;
          whSavingValue = this.uwService.roundValueToSixDecimals(whSavingValue);
        }
      }
      this.setFormValuesFromWholeHealth(whSavingValue);
    }
    if (whSavingValue == 0) this.setFormValuesFromWholeHealth('');
  }
  setFormValuesFromWholeHealth(whSavingValue) {
    const shouldSuppressEvents = this.whAdjustmentsDetails?.isInitialUpdate;
    if (!StringUtils.isUndefined(whSavingValue)) {
      if (StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL) && StringUtils.isEqual(this.fundingType, CommonConstants.ABF)) {
        this.setRateActionAndWHValues(whSavingValue);
      } else if (
        StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL) &&
        StringUtils.isEqual(this.fundingType, CommonConstants.FI)
      ) {
        this.adjustment_form?.get('fiRateActionAdjustment')?.get('renewalWHAPercent')?.setValue(whSavingValue);
      } else if (StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.NEW_BUSINESS_LOCAL)
        || (
          StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL) &&
          StringUtils.isEqual(this.quoteDetail.quotingType, CommonConstants.MEWA))) {
        this.adjustment_form?.get('quoteAdjustments')?.get('wholeHealthAdjustmentFactor')?.setValue(whSavingValue);
      }
    } else {
      if (StringUtils.isEqual(this.quoteDetail.opportunityType, CommonConstants.RENEWAL_LOCAL) && StringUtils.isEqual(this.fundingType, CommonConstants.ABF)) {
        this.setRateActionAndWHValues(whSavingValue);
      }
    }
  }
  setRateActionAndWHValues(whSavingValue) {
    const shouldSuppressEvents = this.whAdjustmentsDetails?.isInitialUpdate;
    this.adjustment_form
      ?.get('abfRateActionAdjustment')
      ?.get('adjustedRateActionPercent')
      ?.setValue(this.uwAdjustment.abfRateActionAdjustment?.adjustedRateActionPercent);
    this.adjustment_form?.get('abfRateActionAdjustment')?.get('renewalWHAPercent')?.setValue(whSavingValue);
  }
  private setCustomTierData() {
    this.uwAdjustment.customTierRatio = this.selectedTierRatioCalculationType === 'Custom' ? this.cleanupCustomTierFactors(this.customTierRatio) : null;
    this.uwAdjustment.tierRatioCalculationType = this.selectedTierRatioCalculationType;
    this.uwAdjustment.outputTier = this.requestedTier * 1;
  }

  cleanupAdjustments(): any {
    let processedProdAdjustments = [];
    if (this.uwAdjustment.productAdjustments && Array.isArray(this.uwAdjustment.productAdjustments)) {
      this.uwAdjustment.productAdjustments.forEach((prodAdjustment) => {
        let derivedCode =
          prodAdjustment['networkName'] + this.PRODUCT_SEPARATOR + prodAdjustment['networkType'] + this.PRODUCT_SEPARATOR + prodAdjustment['CDHPIndicator'];
        if (
          this.userModifiedProductAdjustments[derivedCode] &&
          Array.isArray(this.userModifiedProductAdjustments[derivedCode]) &&
          this.userModifiedProductAdjustments[derivedCode].length > 0
        ) {
          processedProdAdjustments.push(prodAdjustment);
        }
      });
    }
    return processedProdAdjustments;
  }

  onSubmit() {}

  recalculateCustomTierFactorMultiplier() {
    let tierKey = this.uwAdjustment.outputTier + '-tier';
    if (this.uwAdjustment.customTierRatio && this.uwAdjustment.tierRatioCalculationType == 'Custom') {
      let acsFactor = this.quoteDetail['factors'] && this.quoteDetail['factors'].acsFactor;
      let retValue = this.uwService.calculateCustomTierRatioFactor(this.uwAdjustment.customTierRatio, this.calculatedLives[tierKey], acsFactor);
      this.quoteDetail['factors'].customRateOutputTierFactor[tierKey] = retValue['tierFactor'];
      this.quoteDetail['factors'].customRateTierFactorMultiplier[tierKey] = retValue['factorMultiplier'];
    }
  }

  checkAllAllocationsDisabled() {
    let flag = true;
    this.rblKeys.forEach((adjKey) => {
      if (adjKey.includes('Allocation') && this.adjustment_form.get('rebalanceAdjustments').get(adjKey).status != 'DISABLED') flag = false;
    });
    return flag;
  }

  disableRebalanaceAdjustments() {
    setTimeout(() => {
      this.rblKeys.forEach((key) => {
        this.adjustment_form.get('rebalanceAdjustments').get(key).disable();
      });
    });
  }

  setAndRemoveRblValidator(setValidation, removeValidation, AdjContolName) {
    let rblInputField = this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName);
    if (rblInputField.hasValidator(ValidationService[removeValidation])) {
      rblInputField.removeValidators(ValidationService[removeValidation]);
      rblInputField.setValidators(ValidationService[setValidation]);
    }
  }

  rblCheckboxChange(event, AdjContolName, AloControlName) {
    if (!this.adminFactorCB && !this.sslFactorCB && !this.aslFactorCB && !this.tlFactorCB && !this.mcfFactorCB) {
      this.setAndRemoveRblValidator('greaterThanZeroValidator', 'emptyAndGreaterThanZeroValidator', AdjContolName);
      this.rblKeys.forEach((key) => {
        this.adjustment_form.get('rebalanceAdjustments').get(key).setValue('');
        this.adjustment_form.get('rebalanceAdjustments').get(key).disable();
      });
    } else if (this.checkAllAllocationsDisabled()) {
      if (event.target.checked) {
        this.setAndRemoveRblValidator('greaterThanZeroValidator', 'emptyAndGreaterThanZeroValidator', AdjContolName);
        this.rblKeys.forEach((key) => {
          if (key.includes('Allocation')) {
            this.adjustment_form.get('rebalanceAdjustments').get(key).setValue('');
            this.adjustment_form.get('rebalanceAdjustments').get(key).enable();
          }
        });
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).enable();
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).disable();
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).setValue('');
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).setValue('');
      } else {
        this.setAndRemoveRblValidator('emptyAndGreaterThanZeroValidator', 'greaterThanZeroValidator', AdjContolName);
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).disable();
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).enable();
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).setValue('');
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).setValue('');
      }
    } else {
      if (event.target.checked) {
        this.setAndRemoveRblValidator('greaterThanZeroValidator', 'emptyAndGreaterThanZeroValidator', AdjContolName);
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).enable();
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).disable();
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).setValue('');
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).setValue('');
      } else {
        this.setAndRemoveRblValidator('emptyAndGreaterThanZeroValidator', 'greaterThanZeroValidator', AdjContolName);
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).disable();
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).enable();
        this.adjustment_form.get('rebalanceAdjustments').get(AdjContolName).setValue('');
        this.adjustment_form.get('rebalanceAdjustments').get(AloControlName).setValue('');
      }
    }
  }

  getTotalAllocation() {
    let rblValue = this.adjustment_form.get('rebalanceAdjustments');
    let totalAllocation = 0;
    if (this.adminFactorCB || this.sslFactorCB || this.aslFactorCB || this.tlFactorCB || this.mcfFactorCB) {
      this.rblKeys.forEach((key) => {
        if (key.includes('Allocation') && !isNaN(rblValue.get(key).value)) {
          totalAllocation = totalAllocation + +rblValue.get(key).value;
        }
      });
    }
    return this.roundingValueAfterFixingDecimal(totalAllocation * 100);
  }

  hasInValidAllocation() {
    return (this.adminFactorCB || this.sslFactorCB || this.aslFactorCB || this.tlFactorCB || this.mcfFactorCB) && this.getTotalAllocation() != 100;
  }

  getTotalAllocationByPercent() {
    let rblValue = this.adjustment_form.get('percentageComponent');
    let totalAllocation = 0;
    this.rblKeys.forEach((key) => {
      if (key.includes('Allocation') && !isNaN(rblValue.get(key.replace('Allocation', '')).value)) {
        totalAllocation = totalAllocation + +rblValue.get(key.replace('Allocation', '')).value;
      }
    });
    return this.roundingValueAfterFixingDecimal(totalAllocation * 100);
  }

  hasInValidAllocationByPercent() {
    return this.getTotalAllocationByPercent() > 0 && this.getTotalAllocationByPercent() != 100;
  }

  roundingValueAfterFixingDecimal(value: number): number {
    return Math.round(+value.toFixed(10) * 100) / 100;
  }

  onUwNoteToSalesEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.adjustment_form.get('uwNotesToSales').setValue(ASCII, { emitEvent: true });
    } else {
      this.adjustment_form.get('uwNotesToSales').setValue('', { emitEvent: true });
    }
  }

  onUwNoteToSelfEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.adjustment_form.get('uwComments').setValue(ASCII, { emitEvent: true });
    } else {
      this.adjustment_form.get('uwComments').setValue('', { emitEvent: true });
    }
  }
  isFlatRateEnabled() {
    return this.commonService.hasFlatRateRole();
  }
  getwidth() {
    if (this.isFlatRateEnabled()) {
      return '44% !important';
    } else {
      return '55% !important';
    }
  }

  getRiskFactorGuardRailToolTipValue() {
    let guardRailDesc = '';
    if (this.whAdjustmentsDetails?.uwAdjustment?.quoteAdjustments?.riskFactor
      && this.quoteDetail.quotingType === CommonConstants.MEWA) {
      if (this.quoteDetail &&
        this.quoteDetail.factors &&
        this.quoteDetail.factors?.guardRails) {
        let riskFactorGuardRail = this.quoteDetail.factors?.guardRails.find(gr => gr.attrbNm == "request.medical.riskFactor");
        if (riskFactorGuardRail) {
          let riskFactorAdjusted: number = Number(this.whAdjustmentsDetails?.uwAdjustment?.quoteAdjustments?.riskFactor);
          if (riskFactorAdjusted < Number(riskFactorGuardRail.minVal) || riskFactorAdjusted > Number(riskFactorGuardRail.maxVal)) {
            const label = this.quoteDetail.opportunityType === this.RENEWAL_LOCAL ? 'MEWA tiered risk factor' : 'MEWA risk factor';
            guardRailDesc = `${label} is out of range : ${riskFactorGuardRail.minVal} - ${riskFactorGuardRail.maxVal}`;
          }
        }
      }
    }
    return guardRailDesc;
  }

  getUWAdjFactorGuardRailToolTipValue() {
    let guardRailDesc = '';
    if ((this.quoteDetail.riskScoreType == 'CURV' || this.quoteDetail.riskScoreType == 'NA') && (this.quoteDetail.fundingType === 'FI' || this.quoteDetail.fundingType === 'ABF')) {
      if (this.quoteDetail.factors &&
        this.quoteDetail.factors?.guardRails) {
          let curvRiskFactorGuardRail = this.quoteDetail.factors?.guardRails.find(gr => gr.attrbNm == "request.riskScore");
          if (curvRiskFactorGuardRail) {
            let curvRiskFactorAdjusted: number = Number(this.uwAdjustment?.quoteAdjustments?.uwAdjustmentFactor);
            if (curvRiskFactorAdjusted < Number(curvRiskFactorGuardRail.minVal) || curvRiskFactorAdjusted > Number(curvRiskFactorGuardRail.maxVal)) {
              guardRailDesc = `Risk factor is out of range : ${curvRiskFactorGuardRail.minVal} - ${curvRiskFactorGuardRail.maxVal}`;
            }
          }
        }

    }
    return guardRailDesc;
  }

  getToolTipValue() {
    let whSavingsSpecialty = '';
    if (this.whAdjustmentsDetails) {
      Object.keys(this.whAdjustmentsDetails?.whSavingsAdjustment.value).forEach((key, value) => {
        if (this.whAdjustmentsDetails?.whSavingsAdjustment.value[key]) {
          whSavingsSpecialty +=
            [key] + ' : ' + this.uwService.roundValueToFourDecimals(this.whAdjustmentsDetails.whSavingsAdjustment.value[key] * 100) + '%' + '\n';
        }
      });
    }
    return whSavingsSpecialty;
  }

  getMewaFactorValue(key) {
    if (this.quoteDetail.medical &&
      this.quoteDetail?.medical.proposedPlans &&
      this.quoteDetail?.medical.proposedPlans[0].factors &&
      this.quoteDetail?.medical.proposedPlans[0].factors.mewaFactors &&
      this.quoteDetail?.medical.proposedPlans[0].factors?.mewaFactors[key]) {
      return this.quoteDetail.medical.proposedPlans[0].factors.mewaFactors[key] ?? '';
    }
  }

  getAdjustHitory() {
    this.commonQuoteService
      .getAdjustmentHistory(
        this.opportunityData.ratingTransID,
        this.opportunityData.opportunityID,
        this.opportunityData.quoteHeaderID,
        this.quoteDetail.quoteOrigin,
        this.opportunityData.lob,
        this.opportunityData.fundingType
      )
      .subscribe((response) => {
        if (response) {
          this.adjHistory = response;
          this.adjHistory = this.adjHistory.map((adjData, index) => {
            adjData['AdjNo'] = this.adjHistory.length - index;
            return adjData;
          });
        }
      });
  }

  showRateAdjustmentSection(): boolean {
    return this.uwService.showComponentAdjustmentsForAlternates(this.quoteDetail);
  }
}
