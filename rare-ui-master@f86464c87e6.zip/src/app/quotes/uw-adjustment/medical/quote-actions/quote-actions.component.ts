import { Component, OnChanges, Input, Output, EventEmitter, SimpleChanges, OnInit, ViewChild, ElementRef } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { MultiSelect } from "primeng/multiselect";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { DeclineOptions } from "src/app/shared/models/declineOptions";
import { RenewalsConstants } from 'src/app/renewals/renewals-constants';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { CommonService, PrintExhibitService, ProcessQuoteDetailsService, AuthenticationService } from "src/app/shared/services";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { DateUtil } from "src/app/shared/utils/date-util";

@Component({
  selector: "app-quote-actions",
  templateUrl: "./quote-actions.component.html",
  styleUrls: ["./quote-actions.component.css"],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class QuoteActionsComponent implements OnChanges, OnInit {
  @Input() disableAll: boolean;
  @Input() disableDeclineTab: boolean;
  @Input() disableReleaseTab: boolean;
  @Input() disableprint: boolean;
  @Input() refreshPrintExhibits: any;
  @Input() opportunityData: any;
  @Input() exhibitDocs: any;
  @Input() quotingType: any;
  @Input() declineCheckboxes: any;
  @Input() quoteDetailsObj: any;
  @Input() ratingTransID: any;
  @Input() statusReasonsObj: any;
  @Input() uwAdjustmentFetchObject;
  @Input() isQuoteOriginAutoRunBatch: boolean;
  @Input() disableAutoRunConvert: boolean;
  @Input() sslDataLoaded: boolean = false;

  @Output() userAction = new EventEmitter<any>();
  @Output() errorAction = new EventEmitter<any>();
  @Output() declineReasons = new EventEmitter<any>();
  @Output() releaseType = new EventEmitter<any>();
  @Output() offCycleAction = new EventEmitter<any>();

  @ViewChild(MultiSelect) multiSelect: MultiSelect;

  documents: any[] = [];
  declineOptions: any[] = [];
  releaseOptions: any[] = [];
  backendDeclineOptions: any[] = [];
  decline_form: FormGroup<DeclineOptions>;
  selectedDeclineCheckbox: any;
  isRenewal = false;
  isMedicalAca = false;
  disablePrintForACA = false;
  disableQuoteActions = false;
  selectedReleaseOption = [];
  isAdminUser: boolean = false;
  enableMEWAOriginalQuoteRelease = this.commonService.getMEWAOriginalQuoteReleaseEnabled() ?? true;

  constructor(
    private commonService: CommonService,
    private peService: PrintExhibitService,
    private authenticationService: AuthenticationService,
    private elRef: ElementRef, private commonQuoteService: CommonQuoteService
  ) { }

  ngOnChanges(changes: SimpleChanges) {
    if (this.quoteDetailsObj.productsQuoted != undefined) {
      this.quoteDetailsObj['contractStartDate'] = this.quoteDetailsObj.contractEffectiveDate;
      this.quoteDetailsObj['lob1'] = this.quoteDetailsObj.productsQuoted[0];
    }
    this.disablePrintForACA = this.getDisablePrintForACA();
    let changeKeys = Object.keys(changes);
    if (changes && changeKeys.includes("refreshPrintExhibits") && !changes.refreshPrintExhibits.firstChange) {
      this.loadPrintExhibitsInfo();
    }
    if (changes.exhibitDocs && !changes.exhibitDocs.firstChange) {
      this.updateExhibitDocs();
    }
    if (changes.declineCheckboxes) {
      this.updateDeclineCheckboxes();
    }
    if ((changes.statusReasonsObj && !changes.statusReasonsObj.firstChange) ||
      (changes.uwAdjustmentFetchObject && !changes.uwAdjustmentFetchObject.firstChange)
    ) {
      this.setReleaseOptions();
    }
  }

  ngOnInit() {
    this.setReleaseOptions();
    this.isMedicalAca = this.commonService.isMedicalAca(this.quoteDetailsObj);
    this.disableQuoteActions = this.disableAutorunQuoteActions(this.quotingType);
    let userRole = this.authenticationService.userRole['_value'];
    this.isAdminUser = CommonUtil.userHasAdminRole(userRole);
    this.disablePrintForACA = this.getDisablePrintForACA();
    if (this.opportunityData) {
      this.loadPrintExhibitsInfo();
    }
    this.isRenewal = (this.quoteDetailsObj && this.quoteDetailsObj.opportunityType && this.quoteDetailsObj.opportunityType == 'Renewal Local' && this.quoteDetailsObj['lob1'] == 'Medical');
    const myDropdown = this.elRef.nativeElement.querySelector("releaseMouseHover");
    if (myDropdown) {
      myDropdown.click();
    }
  }

  disableAutorunQuoteActions(quotingType) {
    if (quotingType === CommonConstants.ACA) {
      return this.isQuoteOriginAutoRunBatch && !this.commonService.getAutoRunACAQuoteActionsEnabled();
    }

    return this.isQuoteOriginAutoRunBatch;
  }

  getDisablePrintForACA() {
    return !this.commonService.getMedSGAcaRareRouteEnabled() && this.isMedicalAca;
  }

  setReleaseOptions() {
    this.selectedReleaseOption = [];
    const releaseReasonsArray = this.uwAdjustmentFetchObject?.uwAdjustment?.statusReasons || [];
    if (this.statusReasonsObj?.Released?.length > 0) {
      this.releaseOptions = this.statusReasonsObj.Released.map(value => ({ label: value, value }));
    }
    if (this.uwAdjustmentFetchObject && StringUtils.isEqual(this.quoteDetailsObj?.status, CommonConstants.releasedStatus) && releaseReasonsArray) {
      releaseReasonsArray.forEach(reason => {
        this.selectedReleaseOption.push(reason);
      })
    }
  }

  getRenDropdownClass() {
    if (this.quoteDetailsObj['opportunityType'] === 'Renewal Local' && !this.quoteDetailsObj?.medical?.alternateQuote) {
      return 'renewal-bg';
    } else if (this.quoteDetailsObj?.medical?.alternateQuote) {
      return 'color-alt color-alt-checkbox';
    } else {
      return '';
    }
  }
  onMouseFocus(event) {
    this.multiSelect.show();
    event.stopPropagation();
  }
  onClick(action: string) {
     if (StringUtils.isEqual(action, 'offCycle')) {
          this.offCycleAction.emit();
        } else {
          this.userAction.emit(action);
        }
  }

  onDecline(event) {
    if (event != null) {
      this.declineReasons.emit(event);
    }
  }
  onRelease(event) {
    if (event != null) {
      this.releaseType.emit(this.selectedReleaseOption);
    }
  }

  loadPrintExhibitsInfo() {
    this.commonQuoteService
      .getPrintExhibitInfo(this.opportunityData.ratingTransID, this.opportunityData.lob)
      .subscribe(response => {
        if (response != null) {
          this.documents = this.peService.prepareUniquePrintExhibitList(response.exhibits);
        }
      });
  }

  updateExhibitDocs() {
    this.documents = this.peService.prepareUniquePrintExhibitList(this.exhibitDocs);
  }

  updateDeclineCheckboxes() {
    let declineChecboxes: any;
    if (this.declineCheckboxes != null) {
      this.declineCheckboxes.forEach(element => {
        if (declineChecboxes == null) {
          declineChecboxes = element;
        } else {
          declineChecboxes = declineChecboxes + ',' + element;
        }
      });
      const declineList = this.declineCheckboxes.map(id => this.backendDeclineOptions.find(decOps => decOps === id));
      if (typeof (this.decline_form) != 'undefined') {
        this.decline_form.patchValue({
          declineOptionsForm: declineList
        });
      }
    }
  }

  onError($event) {
    this.errorAction.emit($event)
  }

  checkRenewalBg(): boolean {
    return (this.quoteDetailsObj && this.quoteDetailsObj.opportunityType && this.quoteDetailsObj.opportunityType == 'Renewal Local');
  }

  checkConvertBg(): boolean {
    return (this.quoteDetailsObj && this.quoteDetailsObj.opportunityType && this.quoteDetailsObj.opportunityType == 'Renewal Local' && !this.disableAutoRunConvert);
  }

isSold(): boolean {
    if (!this.quoteDetailsObj || !this.quoteDetailsObj.status) {
      return false;
    }
    const status = this.quoteDetailsObj.status;
    return StringUtils.isEqual(status, 'Sold');
  }

  isContractStarted(): boolean {
    if (!this.quoteDetailsObj || !this.quoteDetailsObj.contractEffectiveDate) {
      return false;
    }

    return DateUtil.isDateInPast(this.quoteDetailsObj.contractEffectiveDate);
  }

  shouldShowOffCycleButton(): boolean {
    // Show off-cycle button only when contract has started AND status is Sold
    return this.isContractStarted() && this.isSold();
  }
}
