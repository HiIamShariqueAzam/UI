import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Inject,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { MultiSelect } from 'primeng/multiselect';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { RenewalsConstants } from 'src/app/renewals/renewals-constants';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
import { AuthenticationService, CommonService, ProcessQuoteDetailsService } from 'src/app/shared/services';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { OpportunitiesHistoryComponent } from '../opportunities-history/opportunities-history.component';
import { UnderwriterAdjustmentService } from '../uw-adjustment.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-quote-details',
  templateUrl: './quote-details.component.html',
  styleUrls: ['./quote-details.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class QuoteDetailsComponent implements OnInit, OnChanges, OnDestroy {
  @Input() disableAll: boolean;
  @Input() enableQuoteHistory: boolean;
  @Input() quoteDetail;
  @Input() opportunityData: any = {};
  @Input() experienceSumData: any = {};
  @Input() defaultValue: any = {};
  @Input() statusReasons: string = '';
  @Input() statusReasonsObj: any;
  @Input() uwAdjustmentFetchObject: any;
  @Input() enableRiskScoreFlash: boolean;
  @Input() estimatedClaimsObj: any;

  @Output() userSelectionChanges = new EventEmitter<any>();
  @Output() curvRiskScoreChange = new EventEmitter<any>();
  @Output() groupExperienceSubmit = new EventEmitter<any>();

  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  @ViewChild('opportunityHistory') opportunityHistory: OpportunitiesHistoryComponent;

  private eventSources: EventSource[] = [];

  fundingType: string = 'FI';
  lob: string = 'Medical';
  supportingDocLinks: any;
  accountName: string = 'Loading...';
  opportunityID: string;
  quoteHeaderID: string;
  quoteOrigin: string;
  opportunityType: string;
  status: any;
  selectedStatus: any;
  selectedName: any;
  statusList: any[] = [];
  underwriterList: any;
  processedQuoteDetails: any[];
  userRole: any;
  isCollapsed: boolean;
  isUnifiedPayloadSubmission: boolean = false;
  userSelectedStatus: any;
  userSelectedUWName: any;
  userSelectedReason: any;
  noData: string = 'Not Available';
  assignedUWName: string;
  oldQuotesData: any;
  siteMatchData: any;
  quotelevelFailData: any;
  censusID: any;
  ratingTransID: string;
  isSentToOpportunity: boolean = false;
  displayModal: boolean = false;
  experienceSummaryID: any;
  statusOptions: any[] = [];
  isInitialLoad = true;
  statusResponse: any;
  selectedStatusReasons: any;
  isQuoteOriginAutoRunBatch: boolean = false;
  autoRunQuotesInHistory: boolean = false;
  quotingTypeFromTab: string;
  createOpportunityURL: string = '/opportunity/create-opportunity-new';
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  quoteHistory: boolean = false;
  autoRunhasQuoteHistory: boolean = false;
  LGFItoSGAbfCrossSelling: boolean = false;
  showABFCompAdj: boolean = false;
  hideRollingLossRatio: boolean = false;
  alternateQuote: boolean;
  isABFtoABFAlternateRenewal: boolean = false;
  mbuChanged: boolean = false;
  isCrossSelled: boolean = false;
  isSGMarketSegment: boolean = false;
  readonly quoteOriginConstants = QUOTE_ORIGIN;
  restrictArrowCall: boolean = true;
  arrowCallRestrictionMap = this.commonService.getArrowCallRestrictionMap();
  curvRiskScore: any = null;
  isRiskMeterClicked: boolean = false;
  isBlinking: boolean = false;
  riskScoreSSEvent: boolean = false;
  initialRiskScoreValue: any = null;
  emitRiskScoreToAdj: any = null;
  riskScoreStatus: string = null;
  hitRate: any = null;
  curvToolTip: string = null;
  initialCurvToolTip: string = null;
  showAutoRunHistoryLink: boolean = false;
  isNewBusiness: boolean = false;
  uploadGroupExpDrawerVisible = false;
  groupExpTableModalVisible = false;
  groupExperienceData = null;
  isAdmin = false;
  showUploadExpError = false;
  uploadExpErrorMessage = '';
  uploadExpErrorTimeout: any;
  hideGroupExpUploadIcon: boolean = true;

  constructor(
    private commonService: CommonService,
    private authService: AuthenticationService,
    private processDetailsService: ProcessQuoteDetailsService,
    private commonQuoteService: CommonQuoteService,
    private router: Router,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private actRoute: ActivatedRoute,
    private uwService: UnderwriterAdjustmentService,
    private confirmationService: ConfirmationService,
    private cdr: ChangeDetectorRef
  ) {

    this.isAdmin = this.authService.isUserRoleAdmin(this.authService.userRole.value);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (
      (changes.quoteDetail && !changes.quoteDetail.firstChange) ||
      (changes.statusReasonsObj && !changes.statusReasonsObj.firstChange) ||
      (changes.uwAdjustmentFetchObject && !changes.uwAdjustmentFetchObject.firstChange)
    ) {
      this.initializeComponentVariables();
    }
    if (this.enableRiskScoreFlash) {
      this.isBlinking = true;
    } else {
      this.isBlinking = false;
    }
    if (this.riskScoreStatus === 'PENDING') {
      this.isRiskMeterClicked = true;
      this.isBlinking = false;
    }

    if(this.uwService.showComponentAdjustmentsForAlternates(this.quoteDetail)) {
      this.showABFCompAdj = true;
    }
  }

  ngOnInit() {
    this.initializeComponentVariables();
    this.isQuoteOriginAutoRunBatch = this.quoteDetail.quoteOrigin === RenewalsConstants.AUTO_RUN_BATCH;
    //if quote origin is not 'autoRunBatch' then checking if it has any autoRunBatch history.
    if (!this.isQuoteOriginAutoRunBatch) {
      this.fetchQuoteHistory(RenewalsConstants.AUTO_RUN_BATCH);
      this.autoRunQuotesInHistory = this.oldQuotesData && this.oldQuotesData.length > 0;
    }
    if (!StringUtils.isEmpty(this.quoteDetail.curvEventId)) {
      var eventSource = this.commonService.listenForStream(this.quoteDetail.curvEventId);
      this.eventSources.push(eventSource);
      this.listenToRiskScoreEvents(eventSource);
    }

    this.alternateQuote = this.quoteDetail?.medical?.alternateQuote;
    this.isSentToOpportunity = this.quoteDetail?.isSentToOpportunity;
    this.isNewBusiness =  StringUtils.isEqual(this.opportunityType, CommonConstants.NEW_BUSINESS_LOCAL)
    if (this.isSentToOpportunity) {
      this.isUnifiedPayloadSubmission = true;
    }
    if (this.quoteDetail?.oppOrigin?.['Market Segment']) {
      this.isCrossSelled = true;
    }
    if (this.quoteDetail?.marketSegment === 'SG') {
      this.isSGMarketSegment = true;
    }
    if (this.quoteDetail?.oppOrigin?.['MBU']) {
      this.mbuChanged = true;
    }
    if (
      this.quoteDetail?.oppOrigin?.['Fundingtype'] &&
      StringUtils.isEqual(this.quoteDetail?.oppOrigin?.Fundingtype, CommonConstants.fundingTypeFiToAbfChanged)
    ) {
      this.LGFItoSGAbfCrossSelling = true;
    }
    if ((this.isCrossSelled && this.quoteDetail?.oppOrigin?.Fundingtype) || this.alternateQuote) {
      this.hideRollingLossRatio = true;
    }

    // Check if ABF to ABF alternate for renewals (matching Java logic)
    if (this.alternateQuote
        && StringUtils.isEqual(this.fundingType, CommonConstants.ABF)
        && StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)
        && !StringUtils.isEqual(this.quoteDetail?.quotingType, CommonConstants.MEWA)
        && StringUtils.isEqual(this.quoteDetail?.medical?.currentPlans?.[0]?.fundingType, CommonConstants.ABF)) {
      this.isABFtoABFAlternateRenewal = true;
    }

    this.commonQuoteService.getOpportunitesByOppID(this.opportunityID, this.lob).subscribe((response) => {
      if (response != null) {
        for (var opp of response.opportunities) {
          if (opp && opp.opportunityID === this.opportunityID) {
            if (!this.isSentToOpportunity) {
              this.isSentToOpportunity = opp.isSentToOpportunity ?? false;
            }
          }
        }
      }
    });

    this.riskScoreStatus = this.quoteDetail.RISK_SCORE_STATUS;
    if (this.quoteDetail.RISK_SCORE_STATUS === 'PENDING') {
      this.isRiskMeterClicked = true;
    }


    this.getGroupExperienceData();
  }

  sendToOppClicked() {
    this.showProgress = false;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';

    let quoteSelectorDetails = {
      quoteHeaderID: this.quoteHeaderID,
      lob: this.lob,
      fundingType: this.fundingType
    }

    if(!this.alternateQuote) {
      quoteSelectorDetails = null
    }

    this.commonQuoteService.sendToOpportunitiesQuote(this.opportunityID, this.lob, this.fundingType, this.ratingTransID, quoteSelectorDetails).subscribe(
      (apiResponse) => {
        this.showProgress = true;
        this.progressPercent = 1;
        this.progressStyle = 'progress-bar-warning';
        const apiStatus = apiResponse.data.status;
        if (apiStatus.code == '200') {
          this.progressStyle = 'progress-bar-success';
          this.progressPercent = 100;
          this.progressMessage = apiStatus.msg;

          // Set isSentToOpportunity to true and persist it
          this.isSentToOpportunity = true;
          localStorage.setItem(`isSentToOpportunity_${this.opportunityID}`, JSON.stringify(this.isSentToOpportunity));
        }
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
        this.isUnifiedPayloadSubmission = true;
      },
      (error) => {
        this.progressPercent = 90;
        this.progressStyle = 'progress-bar-danger';
        this.progressMessage = 'Error in getting response from Send To Opportunities';
        console.error('Error calling sendToOpportunities API:', error);
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      }
    );
  }

  openOpp() {
    const url = this.createOpportunityURL;
    if (url) {
      const pathToNavigate = this.createOpportunityURL;
      const url = this.router.serializeUrl(
        this.router.createUrlTree([pathToNavigate], {
          queryParams: {
            opportunityID: this.opportunityID
          }
        })
      );
      localStorage.setItem('quoteHeaderID', this.quoteHeaderID);
      localStorage.setItem('opportunityID', this.opportunityID);
      localStorage.setItem('isLoginAgain', 'true');
      localStorage.setItem('assignedUserRoles', this.authService.getUserRole());
      localStorage.setItem('assignedUserRolesTextToDisplay', this.authService.getUserRoleTextToDisplay());
      localStorage.setItem('sendToOpp', 'true');
      localStorage.setItem('assignedUserLobs', this.authService.getUserLob());
      localStorage.setItem('assignedUserStates', this.authService.getUserState());
      localStorage.setItem('disableAll', 'false');
      window.open(url, '_blank');
    } else {
      alert("Opportunity Details doesn't exist");
    }
  }

  displayMultiSelection(event) {
    const selectedStatus = this.userSelectedStatus?.value;
    if (this.statusReasonsObj[selectedStatus]?.length > 0 && this.multiSelect) {
      this.multiSelect.show();
    }
    event.stopPropagation();
  }
  checkUserRole() {
    if (this.userRole.includes('ADMIN') || this.userRole.includes('READONLY')) {
      return true;
    } else if (this.userRole.includes('ADMIN') && !this.userRole.includes('READONLY')) {
      return false;
    }
  }

  checkReadonlyRole() {
    if (this.userRole.includes('READONLY')) {
      return true;
    }

    return false;
  }

  dashboardIcon() {
    const batchID = localStorage.getItem('batchID');
    this.commonQuoteService.dashboardIcon(batchID);
  }

  icondisplay() {
    const dashboardSubmissionStatus = localStorage.getItem('dashboardSubmissionStatus');
    if (dashboardSubmissionStatus == 'SUCCESS') {
      return false;
    } else if (dashboardSubmissionStatus == 'FAILED') {
      return true;
    }
    return true;
  }

  initializeComponentVariables() {
    this.statusList = [];
    this.oldQuotesData = [];
    if (this.statusReasonsObj) {
      for (const key in this.statusReasonsObj) {
        if (!StringUtils.isEqual(key, CommonConstants.releasedStatus)) {
          this.statusList.push({ label: key, value: key });
        }
      }
    }
    this.lob = this.opportunityData.lob || '';
    this.fundingType = this.opportunityData.fundingType || '';
    this.opportunityID = this.opportunityData.opportunityID || '';
    this.quoteHeaderID = this.opportunityData.quoteHeaderID || '';
    this.ratingTransID = this.opportunityData.ratingTransID || '';
    this.quotingTypeFromTab = this.quoteDetail.quotingType;
    this.quoteOrigin = this.quoteDetail.quoteOrigin || '';
    if (this.quoteDetail) {
      this.accountName = this.quoteDetail.accountName;
      this.status = this.quoteDetail.status;
      this.supportingDocLinks = this.quoteDetail.supportingDocLinks;
      this.userRole = this.authService.userRole['_value'];
      this.censusID = this.quoteDetail.censusRefId;
      this.opportunityType = this.quoteDetail.opportunityType || '';
      this.assignedUWName = '';
      this.setQuoteDetails();
    }
    if (
      typeof localStorage.getItem('statusReasons' + '_' + this.quoteDetail.quoteHeaderID + '_' + 'Medical' + '_' + this.quoteDetail.fundingType) !=
        'undefined' &&
      localStorage.getItem('statusReasons' + '_' + this.quoteDetail.quoteHeaderID + '_' + 'Medical' + '_' + this.quoteDetail.fundingType) != null
    ) {
      let statusReasons: any;
      if (localStorage.getItem('statusReasons' + '_' + this.quoteDetail.quoteHeaderID + '_' + 'Medical' + '_' + this.quoteDetail.fundingType).includes(';')) {
        if (
          localStorage.getItem('statusReasons' + '_' + this.quoteDetail.quoteHeaderID + '_' + 'Medical' + '_' + this.quoteDetail.fundingType).includes('; ')
        ) {
          statusReasons = localStorage
            .getItem('statusReasons' + '_' + this.quoteDetail.quoteHeaderID + '_' + 'Medical' + '_' + this.quoteDetail.fundingType)
            .split('; ')
            .join(';');
        }
        statusReasons = localStorage
          .getItem('statusReasons' + '_' + this.quoteDetail.quoteHeaderID + '_' + 'Medical' + '_' + this.quoteDetail.fundingType)
          .split(';')
          .join('; ');
      } else {
        statusReasons = localStorage.getItem('statusReasons' + '_' + this.quoteDetail.quoteHeaderID + '_' + 'Medical' + '_' + this.quoteDetail.fundingType);
      }
      this.statusReasons = 'Decline Reasons: ' + statusReasons;
    }
  }

  medicalInputTier: number;
  setQuoteDetails() {
    this.updateAssignedUWName();
    this.setUnderwriterList(this.quoteDetail.state);
    if (!this.underwriterList.find((uwDetails) => uwDetails.value === this.assignedUWName)) {
      this.underwriterList.push({ label: this.assignedUWName, value: this.assignedUWName });
    }
    this.sortObjectArr(this.underwriterList);
    if (this.assignedUWName) {
      this.userSelectedUWName = { label: this.assignedUWName, value: this.assignedUWName };
    } else {
      this.userSelectedUWName = { label: '-', value: this.assignedUWName };
    }
    if (this.status) {
      this.userSelectedStatus = { label: this.status, value: this.status };
    }
    this.userSelectedReason = this.quoteDetail.quoteReason && this.quoteDetail.quoteReason !== 'REAL';
    if (this.quoteDetail && this.quoteDetail.factors && this.quoteDetail.factors.medNetworkFactor) {
      this.siteMatchData = this.quoteDetail.factors.medNetworkFactor;
    }
    this.quotelevelFailData = {};
    if (this.quoteDetail && this.quoteDetail.failedGuardRails) this.quotelevelFailData = this.fetchQuotelevelFailRes(this.quoteDetail.failedGuardRails) || null;

    this.actRoute.queryParams.subscribe((params) => {
      // TODO: This code needs to be removed
      if (params['quotingTypeFromTab'] && params['quotingTypeFromTab'] == 'MEWA') this.quoteDetail.quotingType = 'MEWA';
    });

    this.setRistirictArrowCall();
    this.processedQuoteDetails = this.processDetailsService.process(
      this.quoteDetail,
      this.lob.toLocaleLowerCase(),
      this.fundingType,
      this.defaultValue,
      this.restrictArrowCall,
      this.quotelevelFailData
    );
    this.initialRiskScoreValue = this.quoteDetail?.riskScore;
    this.hitRate = this.quoteDetail?.hitRate?.toFixed(2);
    this.initialCurvToolTip = 'Risk Score: ' + this.initialRiskScoreValue + (this.hitRate ? ', Hit Rate: ' + this.hitRate + '%' : '');

    this.isBlinking = true;
    if ((this.quoteDetail, this.quoteDetail.riskScore != -99999)) {
      this.curvRiskScoreChange.emit({ initialRiskScoreValue: this.initialRiskScoreValue, isSSEEvent: false });
    }
    this.onUserSelection();
    if (this.quoteDetail.groupExperienceSummary && this.quoteDetail.groupExperienceSummary.summaryReferenceID) {
      this.experienceSummaryID = this.quoteDetail.groupExperienceSummary.summaryReferenceID;
    }
    this.medicalInputTier = this.quoteDetail['medicalInputTier'];
  }

  setRistirictArrowCall() {
    if (this.quoteDetail && this.quoteDetail.opportunityType === 'New Business Local') {
      const fundingType = this.quoteDetail.fundingType;
      const lobRestrictions = this.arrowCallRestrictionMap['New Business Local']?.[fundingType];
      const isEnabled = lobRestrictions?.includes('ALL') || lobRestrictions?.includes(this.quoteDetail.derivedState);
      this.restrictArrowCall = !isEnabled;
    }
  }

  updateAssignedUWName() {
    if (this.quoteDetail.underwriterName) {
      this.assignedUWName = this.quoteDetail.underwriterName;
    } else if (this.quoteDetail && this.quoteDetail['uwAdjustment']) {
      this.assignedUWName = this.quoteDetail['uwAdjustment'].assignedUWName || this.assignedUWName;
    }
  }

  isTestQuoteDisabled() {
    if (this.userRole.includes('READONLY') && (this.quoteDetail.quoteReason == 'TEST' || this.quoteDetail.quoteReason == 'REAL')) {
      return true;
    } else {
      return false;
    }
  }

  notSpecialType(detail: any) {
    let dropDowns = ['status', 'underwriter'];
    let specialIndexes = ['quotedSubscribers', 'quoteHeaderID'];
    return (
      !specialIndexes.includes(detail.key) &&
      (!dropDowns.includes(detail.key) || (dropDowns.includes(detail.key) && (this.disableAll || this.status.toLowerCase() === 'failed')))
    );
  }

  getColumnClass(column: number) {
    switch (column) {
      case 0:
        return 'col-md-4 pr-0 mr-0';
      case 1:
        return 'col-md-3 pl-0 ml-0';
      case 2:
        return 'col-md-2';
      case 3:
        return 'col-md-3 pl-0';
    }
  }

  getColumnAddlClass(detail: any) {
    let classes = [];
    if (!!detail.labelToolTip) {
      classes.push('sicDiv');
    }
    if (detail.label === CommonConstants.fundingTypeMarketSegmentLabel && (this.isCrossSelled || this.mbuChanged)) {
      classes.push('crossSelling-color');
    }
    return classes.join(' ');
  }

  getCOM2url(): any {
    let supportingDocLinksKeywords = this.commonService.getSupportingDocLinksKeywords();
    return CommonUtil.getCOM2url(this.supportingDocLinks, supportingDocLinksKeywords);
  }

  onUserSelection() {
    this.isInitialLoad = true;
    this.statusOptions = [];
    let allStatusReasons = [];
    if (this.statusReasonsObj && typeof this.statusReasonsObj === 'object') {
      Object.keys(this.statusReasonsObj).forEach((key) => {
        if (this.statusReasonsObj[key] && this.statusReasonsObj[key].length > 0) {
          allStatusReasons = allStatusReasons.concat(this.statusReasonsObj[key]);
        }
      });
    }

   // Check if status changed to Termed or Transfer and off-cycle date is not set
        const newStatus = this.userSelectedStatus?.value;
        const previousStatus = this.status; // Original status from loaded quote
            const statusChanged = previousStatus !== newStatus;

            // Off-cycle data is now handled automatically in the save payload
            // No modal needed for Termed or Transfer status

    if (
      this.uwAdjustmentFetchObject &&
      StringUtils.isEqual(this.status, this.userSelectedStatus?.value) &&
      !StringUtils.isEqual(this.status, CommonConstants.releasedStatus) &&
      this.uwAdjustmentFetchObject?.uwAdjustment?.statusReasons?.length > 0 &&
      this.uwAdjustmentFetchObject?.uwAdjustment?.statusReasons.some((value) => allStatusReasons.includes(value))
    ) {
      this.selectedStatusReasons = this.uwAdjustmentFetchObject?.uwAdjustment?.statusReasons;
      this.isInitialLoad = false;
    } else if (
      !StringUtils.isEqual(this.status, this.userSelectedStatus?.value) &&
      this.statusReasonsObj &&
      this.statusReasonsObj[this.userSelectedStatus?.value]?.length > 0
    ) {
      this.isInitialLoad = false;
      this.selectedStatusReasons = undefined;
    } else {
      this.isInitialLoad = true;
      this.selectedStatusReasons = undefined;
    }
    if (this.statusReasonsObj) {
      const selectedStatusReasons = this.statusReasonsObj[this.userSelectedStatus?.value];
      if (selectedStatusReasons?.length > 0) {
        this.statusOptions = selectedStatusReasons.map((reasonOptions) => ({ label: reasonOptions, value: reasonOptions }));
      } else {
        this.isInitialLoad = true;
      }
    }
    this.emitUserSelectionChanges();
  }

  onUserSelectionReason() {
    this.emitUserSelectionChanges();
  }

  private emitUserSelectionChanges() {
    this.userSelectionChanges.emit({
      quoteReason: this.userSelectedReason ? 'TEST' : 'REAL',
      assignedUWName: this.userSelectedUWName.value,
      status: this.userSelectedStatus.value,
      selectedStatusReasons: this.selectedStatusReasons,
      statusReasonMap: this.statusReasonsObj
    });
  }

  setUnderwriterList(state) {
    this.underwriterList = this.commonQuoteService.underwriterList[state];
    if (this.underwriterList === undefined || this.underwriterList.length <= 0) {
      this.underwriterList = [];
    } else {
      this.underwriterList = this.underwriterList.slice(0);
    }
    this.underwriterList.push({ label: '-', value: '' });
  }

  sortObjectArr(objectArr) {
    objectArr.sort((a, b) => 0 - (a.label > b.label ? -1 : 1));
  }

  experienceSummaryClicked() {
    this.displayModal = true;
    if (StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
      this.getExperienceSummaryData();
    }
    this.experienceSumData['outputTier'] = this.quoteDetail && this.quoteDetail['uwAdjustment'] && this.quoteDetail['uwAdjustment']['outputTier'];
  }

  disableDisplayModal(e: boolean) {
    this.displayModal = e;
  }

  quoteHistoryClicked() {
    this.fetchQuoteHistory(this.quoteOrigin, true);
  }

  quoteAutoRunHistoryClicked() {
    this.quoteHistory = false;
    this.fetchQuoteHistory(RenewalsConstants.AUTO_RUN_BATCH);
    if (this.autoRunhasQuoteHistory || this.oldQuotesData.length > 0) {
      this.opportunityHistory.open(this.quoteHistory);
    }
  }

  private fetchQuoteHistory(quoteOrigin: string = '', isQuoteHistoryClicked?: boolean) {
    var alternateQuote = this.alternateQuote ? this.alternateQuote : this.quoteDetail.alternateQuote;
    this.commonQuoteService
      .getOldQuotes(this.opportunityID, this.lob, this.quoteHeaderID, this.fundingType, quoteOrigin, alternateQuote, this.quoteDetail.quotingType, this.opportunityType)
      .subscribe(
        (response) => {
          let updatedQuotesData = [];
          if (response.opportunities && response.opportunities.length) {
            this.oldQuotesData = response.opportunities;
            updatedQuotesData = this.oldQuotesData.map((quotesData, index) => {
              quotesData['Version'] = this.oldQuotesData.length - index;
              return quotesData;
            });
            this.oldQuotesData = updatedQuotesData;
            if (quoteOrigin == RenewalsConstants.AUTO_RUN_BATCH && this.oldQuotesData.length > 0) {
              this.autoRunhasQuoteHistory = true;
              this.shouldShowAutoRunHistory();
            }
            if (isQuoteHistoryClicked) {
              if (!this.isQuoteOriginAutoRunBatch) {
                this.quoteHistory = true;
              }
              this.opportunityHistory.open(this.quoteHistory);
            }
          }
        },
        (error) => {
          console.error(error);
        }
      );
  }

  fetchQuotelevelFailRes(array) {
    let filteredEleList = {};
    array.map((ele) => {
      let guardrailRepRes = ele.split('.');
      if (guardrailRepRes.length === 1) {
        filteredEleList[guardrailRepRes[0]] = 1;
      } else {
        filteredEleList[guardrailRepRes[guardrailRepRes.length - 1]] = 1;
      }
    });
    return filteredEleList;
  }

  getColumnLabelClass(column: number) {
    switch (column) {
      case 0:
        return 'col-md-5';
      case 1:
        return 'col-md-7';
      case 2:
        return 'col-md-9';
      case 3:
        return 'col-md-5';
    }
  }

  getColumnValueClass(column: number) {
    switch (column) {
      case 0:
        return 'col-md-7';
      case 1:
        return 'col-md-5';
      case 2:
        return 'col-md-3';
      case 3:
        return 'col-md-7';
    }
  }

  getTooltipClass(data: any) {
    return !!data.valueToolTip ? 'sicDiv' : '';
  }

  downLoadCensus() {
    this.commonQuoteService.downLoadCensus(this.censusID, this.lob, this.quoteHeaderID, this.opportunityType, this.quoteDetail?.groupNbr);
  }

  disableCensusDownload() {
    // Check census privilege only for renewals - if no privilege, disable download
    if (this.isRenewal()) {
      const hasCensusPrivilege = this.authService.isCensusPrivilegedUser(this.commonService.getAssignedUserGroup());
      if (!hasCensusPrivilege) {
        return true;
      }
    }
    
    // Add any other existing business logic here if needed
    return false;
  }

  getToolTipDiv(data: any) {
    return data.guardRailFailureForAcs || data.guardRailFailedForEsm ? 'toolTipDiv' : '';
  }

  navigateToCreateOppScreen() {
    let multiSortMeta = [
      { field: 'state', order: 1 },
      { field: 'marketSegment', order: 1 }
    ];
    this.storage.set('oppMultiSortMeta', multiSortMeta);
    this.router.navigate([this.commonService.getNewCreateOpportunityFlow() && this.createOpportunityURL], {
      queryParams: {
        opportunityID: this.opportunityID
      }
    });
  }

  isAutoRunBatchEnabled() {
    return this.commonService.isAutoRunBatchEnabled;
  }

  shouldShowAutoRunHistory(): boolean {
    this.autoRunQuotesInHistory = this.oldQuotesData && this.oldQuotesData.length > 0 && this.autoRunhasQuoteHistory;
    const disableAll = this.disableAll ?? false;
    const isQuoteOriginAutoRunBatch = this.isQuoteOriginAutoRunBatch ?? false;
    const autoRunQuotesInHistory = this.autoRunQuotesInHistory ?? false;
    const isAutoRunBatchEnabled = this.isAutoRunBatchEnabled() ?? false;
    this.showAutoRunHistoryLink = !disableAll && !isQuoteOriginAutoRunBatch && autoRunQuotesInHistory && isAutoRunBatchEnabled && this.isRenewal();
    return this.showAutoRunHistoryLink;
  }

  isRenewal(): boolean {
    return StringUtils.isEqualIgnoreCase(this.opportunityType, 'Renewal Local');
  }

  getExperienceSummaryData() {
    if (Object.keys(this.experienceSumData).length === 0) {
      let lob = this.opportunityData.lob || '';
      let fundingType = this.opportunityData.fundingType || '';
      let opportunityID = this.opportunityData.opportunityID || '';
      let quoteHeaderID = this.opportunityData.quoteHeaderID || '';
      let quoteOrigin = this.opportunityData.quoteOrigin || '';
      let ratingTransID = this.opportunityData.ratingTransID || '';

      this.commonQuoteService.getRenewalExperienceSummary(opportunityID, quoteHeaderID, quoteOrigin, fundingType, lob, ratingTransID).subscribe((response) => {
        if (response) {
          this.experienceSumData = response;
          this.experienceSumData[CommonConstants.FUNDING_TYPE] = fundingType;
        }
      });
    }
  }
  getRiskMeterTooltip(): string {
    const riskMeterSrc = this.getRiskMeter();
    if(this.disableAll) {
      return '';
    }
    if (riskMeterSrc.includes('Risk_Meter_Greyed.png')) {
      return 'Awaiting Risk Score';
    } else if (riskMeterSrc.includes('Risk_Meter_Clear.png')) {
      return 'Request Risk Score';
    }
    return 'Risk Meter status unknown.';
  }
  getRiskMeter() {
    if (this.isRiskMeterClicked || this.disableAll) {
      return './assets/Risk_Meter_Greyed.png';
    } else {
      return './assets/Risk_Meter_Clear.png';
    }
  }

  riskMeterClicked(event: MouseEvent) {
    if (this.isRiskMeterClicked || this.disableAll) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    this.isRiskMeterClicked = true;
    this.getRiskMeter();
    this.isBlinking = false;
    this.getRiskScoreDetails();
  }

  getRiskScoreDetails() {
    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';
    const ratingTransID = this.opportunityData.ratingTransID || '';
    this.commonQuoteService.getRiskScoreDetails(ratingTransID).subscribe(
      (response) => {
        if (response) {
          if (response.result == 'Successfully submitted order.' && !StringUtils.isEmpty(response.orderGroupGuid)) {
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            this.progressMessage = 'Risk Score request submitted Successfully';
            var eventSource = this.commonService.listenForStream(response.orderGroupGuid);
            this.eventSources.push(eventSource);
            this.listenToRiskScoreEvents(eventSource);
          } else {
            this.progressStyle = 'progress-bar-danger';
            this.progressPercent = 100;
            this.progressMessage = 'Failed to Submit Risk Score request - Please contact RARE Support Team';
            this.isRiskMeterClicked = false;
          }
        }
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      },
      (error) => {
        this.progressPercent = 90;
        this.progressStyle = 'progress-bar-danger';
        this.progressMessage = 'Error in getting response for Risk Score';
        this.isRiskMeterClicked = false;
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      }
    );
  }

  listenToRiskScoreEvents(eventSource: any): void {
    eventSource.addEventListener('CURV_RISK_SCORE_POLLING', (event: any) => {
      this.processRiskScoreEvents(event);
      this.isRiskMeterClicked = true;
      setTimeout(() => {}, 3000);
    });

    eventSource.addEventListener('RISK_SCORE_COMPLETED', (event: any) => {
      eventSource.close();
      if (event && event.data) {
        var eventData = JSON.parse(event.data);
        var payload = eventData.payload;
        if (payload.status == 'COMPLETED') {
          this.riskScoreSSEvent = true;
          this.emitRiskScoreToAdj = payload.score;
          this.hitRate = payload?.hitRate?.toFixed(2);
          this.curvToolTip = 'Risk Score: ' + this.emitRiskScoreToAdj + (this.hitRate ? ', Hit Rate: ' + this.hitRate + '%' : '');
          if(this.emitRiskScoreToAdj.toString().length != 1) {
          this.curvRiskScore = this.emitRiskScoreToAdj ? parseFloat(this.emitRiskScoreToAdj).toString().split('.')[0] + '.' + (parseFloat(this.emitRiskScoreToAdj).toString().split('.')[1]?.substring(0, 2) || '') : '';
          } else {
            this.curvRiskScore = this.emitRiskScoreToAdj;
          }
          this.isBlinking = true;
          this.isRiskMeterClicked = false;
          this.riskScoreStatus = 'COMPLETED';
          this.curvRiskScoreChange.emit({ initialRiskScoreValue: this.emitRiskScoreToAdj, isSSEEvent: true });
          if (this.quoteDetail?.factors !== undefined) {
            this.quoteDetail.riskScore = this.emitRiskScoreToAdj;
            this.processedQuoteDetails = this.processDetailsService.process(
              this.quoteDetail,
              this.lob.toLocaleLowerCase(),
              this.fundingType,
              this.defaultValue,
              this.restrictArrowCall,
              this.quotelevelFailData
            );
          }
        } else if (payload.status == 'FAILED') {
          this.isRiskMeterClicked = false;
        } else {
          this.riskScoreSSEvent = false;
        }
      }
    });
  }

  isDummyEvent(payload: any) {
    return payload && payload.dummyEvent && payload.dummyEvent == 'true';
  }

  processRiskScoreEvents(event: any) {
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      let payload = eventData['payload'];
      if (this.isDummyEvent(payload)) {
        return;
      }
    }
  }

  uploadExperienceClicked() {
    if (this.groupExperienceData) {
      this.groupExpTableModalVisible = true;
    } else {
      this.uploadGroupExpDrawerVisible = true;
    }

  }

  getGroupExperienceData() {
    const ratingTransID = this.opportunityData?.ratingTransID || this.ratingTransID;
    const marketSegment = this.quoteDetail?.marketSegment || '';
    const isUploadEnabled = this.isNewBusinessUploadEnabled(this.lob, marketSegment, this.fundingType);

    this.commonQuoteService.fetchGroupExperienceForNewBusiness(ratingTransID, this.lob).subscribe(
      (response) => {
        if (response) {
          this.groupExperienceData = response;
          this.hideGroupExpUploadIcon = !isUploadEnabled;
        } else {
          this.groupExperienceData = null;
          if(!this.checkReadonlyRole() && isUploadEnabled) {
            this.hideGroupExpUploadIcon = false;
          }
        }

        this.cdr.markForCheck();
      },
      (error) => {
        this.showUploadExpError = true;
        this.uploadExpErrorMessage = 'Failed to fetch group experience data. Please try again later.';
        this.uploadExpErrorTimeout = setTimeout(() => this.removeUploadExpErrorMsg(), 5000);
      }
    );
  }

  uploadGroupExperienceComplete(newData) {
    this.uploadGroupExpDrawerVisible = false;
    this.groupExperienceData = newData.groupExperience;
    this.groupExpTableModalVisible = true;
  }

  uploadExpDrawerClosed(event) {
    this.uploadGroupExpDrawerVisible = false;
  }

  groupExperienceChanged(data) {
    this.groupExperienceData = data;
  }

  closeGroupExpTableModal() {
    this.groupExpTableModalVisible = false;
  }

   submitGroupExperience() {
    this.closeGroupExpTableModal();
   
    // Show confirmation dialog after drawer is closed
    setTimeout(() => {
      this.confirmationService.confirm({
        message: 'Are you sure you want to submit?',
        header: 'Confirmation',
        key: 'groupExpSubmit',
        acceptButtonStyleClass: 'dialog-button',
        rejectButtonStyleClass: 'dialog-button',
        accept: () => {
          this.groupExperienceSubmit.emit(this.groupExperienceData);
        },
        reject: () => {
          // Reopen the drawer if user cancels
          this.groupExpTableModalVisible = true;
        }
      });
    }, 100);
  }

  removeUploadExpErrorMsg() {
    this.showUploadExpError = false;
    this.uploadExpErrorMessage = '';
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }

  isNewBusinessUploadEnabled(lob: string, marketSegment: string, fundingType: string): boolean {
    const config = this.commonService.getNewBusinessUploadEnabledConfig();


    if (!config[lob]) {
      return false;
    }

    if (!config[lob][marketSegment]) {
      return false;
    }

    const allowedFundingTypes = config[lob][marketSegment];
    if (Array.isArray(allowedFundingTypes)) {
      return allowedFundingTypes.includes(fundingType);
    }

    return false;
  }

}
