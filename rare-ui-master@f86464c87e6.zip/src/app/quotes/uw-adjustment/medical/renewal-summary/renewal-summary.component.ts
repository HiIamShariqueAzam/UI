import { Component, OnInit, Input, Inject, LOCALE_ID, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { formatCurrency, getCurrencySymbol, formatNumber, formatPercent } from '@angular/common';

@Component({
  selector: 'app-renewal-summary',
  templateUrl: './renewal-summary.component.html',
  styleUrls: ['./renewal-summary.component.css'],
  standalone: false
})
export class RenewalSummaryComponent implements OnInit, AfterViewChecked {

  @Input() experienceSumData: any = {};
  maxClaimAccountStatus:string = '';

  constructor(private cdRef : ChangeDetectorRef ,@Inject(LOCALE_ID) private locale: string) { }

  ngOnInit(){ }

  ngAfterViewChecked() {
    if (this.maxClaimAccountStatus) {
      this.cdRef.detectChanges();
    }
  }

  getRoundedValue(val, formatType = 'string'): any {
    let numExp = /^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/;
    // check is Number
    if (numExp.test(val) && formatType !== 'string') {
      val = parseFloat(val);
      if (formatType === 'flat-dollar') {
        return formatCurrency(val, this.locale, getCurrencySymbol('USD', 'wide'),
          undefined, '1.2-2');
      } else if (formatType === 'percent') {
        return formatPercent(val, this.locale, '1.0-2');
      } else {
        return formatNumber(val, this.locale, '1.0-2');
      }
    } else {
      return (val) ? val : '';
    }
  }

  getTableData(keyName: string) {
    let contractPeriodSummaryMap = this.experienceSumData['contractPeriodSummaryMap'] || {};
    if(contractPeriodSummaryMap && contractPeriodSummaryMap[1]) {
      let summary = contractPeriodSummaryMap[1];
      let value: any = 0;
      let formatType = 'string';
      let claimSummaryArr = ['incurredClaimsTotal', 'nonSpecificClaimsTotal', 'totalLargeClaimantsOverSSL'];

      if(claimSummaryArr.includes(keyName)) {
        value = summary?.claimSummary[keyName] || 0;
        formatType = 'flat-dollar';
      } else if(keyName === 'totalExpectedClaims') {
        value = summary?.revenueSummary?.expectedClaims || 0;
        formatType = 'flat-dollar';
      } else if(keyName === 'maxClaimsAccountStatus') {
        this.maxClaimAccountStatus = summary?.revenueSummary?.maxClaimAccountStatus || '';
        let claimsPercentDiff = summary?.revenueSummary?.claimsPercentDiff || 0;
        value = `${this.maxClaimAccountStatus} (${this.getRoundedValue(claimsPercentDiff, 'percent')})`;
      }
      return this.getRoundedValue(value, formatType);
    }
    return '-';
  }

  getMaxClaimsStatusClass() : string {
   return (this.maxClaimAccountStatus == 'Running Hot') ?  'bg-runningHot' :
    (this.maxClaimAccountStatus == 'Running Normal') ? 'bg-runningNormal' :
    (this.maxClaimAccountStatus == 'Running Well') ? 'bg-runningWell' : ''
  }
}
