import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges,
  ElementRef,
  ViewChild,
  AfterViewInit
} from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CommonService } from "src/app/shared/services";
import { Router } from "@angular/router";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: "app-sitematch-modal",
  templateUrl: "./sitematch-modal.component.html",
  styleUrls: ["./sitematch-modal.component.css"],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class SitematchModalComponent implements OnInit, OnChanges, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  @Input() siteMatchData: any;
  siteMatchInfo: any[] = [];
  columns = [
    {
      header: "S.No",
      field: "sNo"
    },
    {
      header: "Network Name",
      field: "networkName"
    },
    {
      header: "Sitematch Applicable",
      field: "siteMatchInd"
    },
    {
      header: "Required %",
      field: "siteMatchReqPercentage"
    },
    {
      header: "Actual %",
      field: "siteMatchPercentage"
    },
    {
      header: "Company Zip Included",
      field: "siteMatchGrpZipInd"
    },
    {
      header: "Company Zip Status",
      field: "siteMatchGrpStatus"
    },
    {
      header: "Group Qualified",
      field: "groupQualified"
    }
  ];

  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    private commonService: CommonService,
    private router: Router
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  ngOnChanges(changes: SimpleChanges) {
    var arr = [];
    if (this.siteMatchData) {
      let keys = Object.keys(this.siteMatchData);
      for (var i = 0, n = keys.length; i < n; i++) {
        var key = keys[i];
        this.siteMatchData[key].sNo = i + 1;
        arr.push(this.siteMatchData[key]);
      }
      this.siteMatchInfo = arr;
    }
  }

  getSiteMatchValue(siteMatchInfo, field) {
    if (
      field === "siteMatchReqPercentage" ||
      field === "siteMatchPercentage"
    ) {
      if (siteMatchInfo[field] || siteMatchInfo[field] === 0)
        return parseFloat((siteMatchInfo[field] * 100).toFixed(2));
      else return "NA";
    } else if (field === "siteMatchInd" || field === "siteMatchGrpZipInd") {
      if (siteMatchInfo[field] === "Y") return "Yes";
      if (siteMatchInfo[field] === "N") return "No";
      else return "";
    }
  }

  ngOnInit() {
  }
  stringConversion(value)
  {
    return StringUtils.convertToString(value);
  }
}
