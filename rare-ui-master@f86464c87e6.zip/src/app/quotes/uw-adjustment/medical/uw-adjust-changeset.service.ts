import { Injectable } from "@angular/core";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { Enrollments, PlanComparison } from "src/app/shared/models";
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CalculatorUtils } from "../../../shared/utils/calculator-utils";
@Injectable({ providedIn: "root" })
export class UWAdjustmentChangeSetService {
  PRODUCT_SEPARATOR = "##";
  bulkCompRateActionKeys = ['asoAdminFee','sslPremium','aslPremium','terminalLiability','maxPaidClaim'];
  getProcessedProdAdjustmentData(prodAdjustments: any, adjustmentKeys: string[], productSeparator: string): any {
    let adjustment = {};
    prodAdjustments.forEach(plan => {
      let productCategoryCode: string = plan.networkType;
      let productCode: string = "";
      if (plan["CDHPIndicator"]) {
        productCode = plan["CDHPIndicator"];
      } else if (plan["cdhpindicator"]) {
        productCode = plan["cdhpindicator"];
      }
      let derivedCode =
        plan.networkName +
        productSeparator +
        productCategoryCode +
        productSeparator +
        productCode;
      adjustment[derivedCode] = { ...plan };
      if (adjustmentKeys.indexOf(derivedCode) == -1) {
        adjustmentKeys.push(derivedCode);
      }
    });
    return adjustment;
  }

  getProductAdjustmentChangesetDetails(updatedProdAdjust, initialProdAdjust, quoteAdjustments, productSeparator: string): any[] {
    let updatedProdAdjustment = {};
    let initialProdAdjustment = {};
    let adjustmentKeys: string[] = [];
    let updatedChanges = [];
    if (initialProdAdjust) {
      initialProdAdjustment = this.getProcessedProdAdjustmentData(initialProdAdjust, adjustmentKeys, productSeparator);
    }
    if (updatedProdAdjust) {
      updatedProdAdjustment = this.getProcessedProdAdjustmentData(updatedProdAdjust, adjustmentKeys, productSeparator);
    }
    if (adjustmentKeys.length > 0) {
      let prodAdjChanges;
      adjustmentKeys.forEach(key => {
        if (initialProdAdjustment[key] && updatedProdAdjustment[key]) {
          prodAdjChanges = this.getObjectChangeset(updatedProdAdjustment[key], initialProdAdjustment[key]);
          const {networkName, networkType, CDHPIndicator, ...rest } = updatedProdAdjustment[key];
          if (prodAdjChanges) {
            if (quoteAdjustments) {
              let keysWithDifferentValues: string[] = [];
              Object.keys(rest).forEach(diffKey => {
                if (rest[diffKey] && initialProdAdjustment[key][diffKey]) {
                  if (parseFloat(rest[diffKey]) !== parseFloat(initialProdAdjustment[key][diffKey])) {
                    keysWithDifferentValues.push(diffKey);
                  }
                } else {
                  keysWithDifferentValues.push(diffKey);
                }
              });

              prodAdjChanges = {};
              keysWithDifferentValues.forEach(diffKey => {
                if (rest[diffKey] && !quoteAdjustments[diffKey]) {
                  prodAdjChanges[diffKey] = rest[diffKey];
                } else if (!rest[diffKey] && quoteAdjustments[diffKey]) {
                  prodAdjChanges[diffKey] = rest[diffKey];
                } else if (rest[diffKey] && quoteAdjustments[diffKey] &&
                  parseFloat(rest[diffKey]) !== parseFloat(quoteAdjustments[diffKey])) {
                  prodAdjChanges[diffKey] = rest[diffKey];
                }
              });
            }
          }
          if (prodAdjChanges && this.hasFactorKeys(prodAdjChanges)) {
            prodAdjChanges["networkName"] = networkName;
            prodAdjChanges["networkType"] = networkType;
            prodAdjChanges["CDHPIndicator"] = CDHPIndicator;
          } else {
            prodAdjChanges = null;
          }
        } else if (updatedProdAdjustment[key]) {
          prodAdjChanges = { ...updatedProdAdjustment[key] };
        }
        if (prodAdjChanges && this.hasFactorKeys(prodAdjChanges)) {
          updatedChanges.push(prodAdjChanges);
        }
      });
    }
    return updatedChanges.length ? updatedChanges : null;
  }

  hasFactorKeys(adjustmemtObject: any): boolean {
    const {networkName, networkType, CDHPIndicator, ...rest} = adjustmemtObject;
    let hasSomeFactorValue: boolean = false ;
    if (rest) {
      Object.keys(rest).forEach(key => {hasSomeFactorValue = hasSomeFactorValue || rest[key] != null;});
    }
    return hasSomeFactorValue;
  }

  getAandCDifferences(updatedAssumptionList: any[], existingAssumptionList: any[]): any[] {
    let changedValues = [];
    if (updatedAssumptionList && existingAssumptionList) {
      for (let i = 0; i < updatedAssumptionList.length; i++) {
        if (!existingAssumptionList[i]) {
          changedValues.push(updatedAssumptionList[i]);
        } else if (this.getObjectChangeset(updatedAssumptionList[i], existingAssumptionList[i])) {
          changedValues.push(updatedAssumptionList[i]);
        }
      }
    }
    return changedValues;
  }

  getObjectChangeset(updated, initial): any {
    let changeSet = {};
    for (let key in updated) {
      if (initial && updated[key] !== initial[key]) {
        if (initial && updated && StringUtils.isEqual(key, CommonConstants.DISCOUNT_SPLITS) && updated[key] !== initial[key]) {
          const result = this.comparisonForArrayOfObj(updated[key], initial[key])
          if (!StringUtils.isUndefined(result) && result.length > 0)
            changeSet[key] = result;
        }
        else if (typeof initial[key] === "object" && typeof updated[key] === "object") {
          changeSet[key] = this.getObjectChangeset(updated[key], initial[key]);
        } else if (updated[key]) {
          changeSet[key] = updated[key];
        } else if(initial[key] && updated[key] == ""){
          changeSet[key] = updated[key];
        }
      } else if (!initial && updated && updated[key]) {
        changeSet[key] = updated[key];
      }
      if (changeSet[key])
        changeSet['ratingPlanID'] = updated.ratingPlanID;
    }
    return Object.keys(changeSet).length ? changeSet : null;
  }


  getAssumptionsChangeSetDetails(updatedAssumptionsList: any[], initialAssumpList: any[]): any {
    let returnChangeset = {};
    let newChanges: any[] = this.getAandCDifferences(updatedAssumptionsList, initialAssumpList);
    let existingChanges: any[] = this.getAandCDifferences(initialAssumpList, updatedAssumptionsList);
    if (newChanges && newChanges.length > 0) {
      returnChangeset["newValue"] = newChanges;
    }
    if (existingChanges && existingChanges.length > 0) {
      returnChangeset["oldValue"] = existingChanges;
    }
    return Object.keys(returnChangeset).length > 0 ? returnChangeset : null;
  }

  isPlanComparisonInvalid(mpcData): boolean {
    if (mpcData && mpcData.planComparison) {
      for (const pc of mpcData.planComparison) {
        if (this.checkInvalid(pc.currentEnrollments, 'enroll') || this.checkInvalid(pc.quoteEnrollments, 'enroll')
          || this.checkInvalid(pc.currentRates, 'rates') || this.checkInvalid(pc.renewalRates, 'rates')) {
          return true;
        }

      }
    }
  }

  checkInvalid(mpcData, type): boolean {
    if (mpcData) {
      for (let i = 1; i <= 5; i++) {
        let data = type + 'T' + i;
        let val = mpcData[data];
        if(val && type=='rates') {
          val = ('' + val).replace("$", "").replace(/,/g, "");
        }
        if (val && isNaN(val))
          return true;
      }
    }
    return false ;
  }

  getMappedEnrollments(tierValue: number, tierEnrollments: any): Enrollments {
    let en = new Enrollments();
    en.enrollT1 = tierEnrollments.eeCount * 1;
    switch (tierValue * 1) {
      case 2:
        en.enrollT2 = (tierEnrollments.efCount || 0) * 1;
        break;
      case 3:
        en.enrollT2 = (tierEnrollments.e1Count || 0) * 1;
        en.enrollT3 = (tierEnrollments.efCount || 0) * 1;
        break;
      case 4:
        en.enrollT2 = (tierEnrollments.esCount || 0) * 1;
        en.enrollT3 = (tierEnrollments.ecCount || 0) * 1;
        en.enrollT4 = (tierEnrollments.efCount || 0) * 1;
        break;
      case 5:
        en.enrollT2 = (tierEnrollments.esCount || 0) * 1;
        en.enrollT3 = (tierEnrollments.ekCount || 0) * 1;
        en.enrollT4 = (tierEnrollments.ecCount || 0) * 1;
        en.enrollT5 = (tierEnrollments.efCount || 0) * 1;
        break;
    }
    en.totalEnroll = 0;
    for (let i = 1; i <= 5; i++) {
      en.totalEnroll += ((en["enrollT" + i] || 0) * 1);
    }
    return en;
  }

  cleanupRateFormatting(rates: any): any {
    let retValue = {};
    if(rates && Object.keys(rates).length > 0) {
      Object.keys(rates).forEach(key => {
        retValue[key] = ('' + rates[key]).replace("$", "").replace(/,/g, "");
      })
    }
    return retValue;
  }

  getMPCPlanLevelChangeSet(plan1: any, plan2: any, tieredLives: any, currentTierValue: number, initialTierValue: number): any {
    let changeSet = {};
    let quoteEnrollments = null;
    var {totalEnroll, ...updatedCurrentEnrollments} = plan1.currentEnrollments;
    var {totalEnroll, ...updatedCurrentEnrollments2Comp} = plan1.currentEnrollments2Comp || {};
    var { totalEnroll, ...updatedQuotedEnrollments } = plan1.quoteEnrollments;
    var {monthlyTotal, yearlyTotal, ...updatedCurrentRates} = plan1.currentRates;
    var {monthlyTotal, yearlyTotal, ...updatedRenewalRates} = plan1.renewalRates;

    var {totalEnroll, ...previousCurrentEnrollments} = plan2.currentEnrollments;
    var {totalEnroll, ...previousCurrentEnrollments2Comp} = plan2.currentEnrollments2Comp || {};
    var { totalEnroll, ...previousQuotedEnrollments } = plan2.quoteEnrollments;
    var {monthlyTotal, yearlyTotal, ...previousCurrentRates} = plan2.currentRates;
    var {monthlyTotal, yearlyTotal, ...previousRenewalRates} = plan2.renewalRates;

    var currentEnrollments = this.getObjectChangeset(updatedCurrentEnrollments, previousCurrentEnrollments);
    var currentEnrollments2Comp = this.getObjectChangeset(updatedCurrentEnrollments2Comp, previousCurrentEnrollments2Comp);
    
    // Doing this to check when the tiers got changed, check against the acutal calculated tier value
    // instead of relying on the previous updated value
    if (currentTierValue == initialTierValue) {
      quoteEnrollments = this.getObjectChangeset(updatedQuotedEnrollments, previousQuotedEnrollments);
    } else {
      let planEnrollments;
      if (plan1.currentTier !== plan1.quoteTier && plan1.quoteEnrollments) {
        planEnrollments = this.getMappedEnrollments(initialTierValue, tieredLives);
      } else {
        planEnrollments = previousQuotedEnrollments;
      }
      quoteEnrollments = this.getObjectChangeset(updatedQuotedEnrollments, planEnrollments);
    }
    var currentRates = this.getObjectChangeset(this.cleanupRateFormatting(updatedCurrentRates), this.cleanupRateFormatting(previousCurrentRates));
    var renewalRates = this.getObjectChangeset(this.cleanupRateFormatting(updatedRenewalRates), this.cleanupRateFormatting(previousRenewalRates));

    if (currentEnrollments) {
      changeSet["currentEnrollments"] = currentEnrollments;
    }
    if (currentEnrollments2Comp) {
      changeSet["currentEnrollments2Comp"] = currentEnrollments2Comp;
    }
    if (quoteEnrollments) {
      changeSet["quoteEnrollments"] = quoteEnrollments;
    }
    if (currentRates) {
      changeSet["currentRates"] = currentRates;
    }
    if (renewalRates) {
      changeSet["renewalRates"] = renewalRates;
    }
    return changeSet;
  }

  getPremiumComparisonChangeSet(quoteDetails: any, oldQuoteDetails: any): any {
    let mpcData: any = (quoteDetails && quoteDetails.medicalPremiumComparison) || {};
    let mpcInitialData: any = (oldQuoteDetails && oldQuoteDetails.medicalPremiumComparison) || {};
    let modifiedTier: number = (quoteDetails.uwAdjustment && quoteDetails.uwAdjustment.outputTier &&
      quoteDetails.uwAdjustment.outputTier) || quoteDetails.medicalOutputTier;
    let existingTier: number = (oldQuoteDetails.uwAdjustment && oldQuoteDetails.uwAdjustment.outputTier &&
      oldQuoteDetails.uwAdjustment.outputTier) || oldQuoteDetails.medicalOutputTier;
    let tieredLives: any = (quoteDetails && quoteDetails.factors && quoteDetails.factors.calculatedTierLives &&
        quoteDetails.factors.calculatedTierLives[modifiedTier + '-tier']) || {};

    let mpcNewValue = [];
    let mpcOldValue = [];
    let mpcDataChangeSetDetails = {};
    if (mpcData && mpcData.planComparison) {
      mpcData.planComparison.forEach((pc: PlanComparison) => {
        let updatedMPC: PlanComparison;
        let initialMPC: PlanComparison;
        if (pc.quoteRatingPlanID && pc.quoteRates) {
          updatedMPC = this.getMPCplan(mpcData, pc.quoteRatingPlanID, "quoteRatingPlanID");
          initialMPC = this.getMPCplan(mpcInitialData, pc.quoteRatingPlanID, "quoteRatingPlanID");
          let newValue = this.getMPCPlanLevelChangeSet(updatedMPC, initialMPC, { ...tieredLives }, modifiedTier, existingTier);
          let oldValue = this.getMPCPlanLevelChangeSet(initialMPC, updatedMPC, { ...tieredLives }, existingTier, modifiedTier);
          if (Object.keys(newValue).length) {
            newValue["currPlanId"] = updatedMPC.currPlanId;
            newValue["quoteRatingPlanID"] = updatedMPC.tempQuoteRatingPlanID;
            newValue["quoteContractCode"] = updatedMPC.quoteContractCode;
            mpcNewValue.push(newValue);
          }
          if (Object.keys(oldValue).length) {
            oldValue["currPlanId"] = initialMPC.currPlanId;
            oldValue["quoteRatingPlanID"] = initialMPC.tempQuoteRatingPlanID;
            oldValue["quoteContractCode"] = initialMPC.quoteContractCode;
            mpcOldValue.push(oldValue);
          }
        }
      });
    }
    if (mpcNewValue && Object.keys(mpcNewValue).length) {
      mpcDataChangeSetDetails["newValue"] = {planComparison: [...mpcNewValue]};
    }
    if (mpcOldValue && Object.keys(mpcOldValue).length) {
      mpcDataChangeSetDetails["oldValue"] = {planComparison: [...mpcOldValue]};
    }
    return Object.keys(mpcDataChangeSetDetails).length ? mpcDataChangeSetDetails : null;
  }

  getComponentObj(componentAdjustments, type, value) {

    return componentAdjustments.find(item => item[type] === value);

  }

  getComponentAdjustmentChangesetDetails(updated, initial): any {
    let changeSet = [];
    for (let obj in updated) {
      let initialObj;
      if(initial){
      initialObj = this.getComponentObj(initial, "adjustmentType", updated[obj]["adjustmentType"]);
      }
      if (initial && updated[obj]["adjustmentType"] && initialObj && updated[obj]["adjustmentType"] === initialObj["adjustmentType"] &&
      (updated[obj]["adjustmentFactorType"] != initialObj["adjustmentFactorType"] || updated[obj]["adjustmentFactor"] != initialObj["adjustmentFactor"])) {
          changeSet.push(updated[obj]);
      }
      else if(!initialObj && updated && updated[obj]){
          changeSet.push(updated[obj]);
      }
    }
    return changeSet.length ? changeSet : null;
  }

  rblKeys: string[] = [
    "adminFactor",
    "sslFactor",
    "aslFactor",
    "tlFactor",
    "mcfFactor",
  ];

  getRblAdjustmentChangesetDetails(updated, initial): any {
    let changeSet = {};
    if(updated && updated.fromComponent && Object.keys(updated.fromComponent).length && !updated.rebalanceAdjustmentType)
      updated['rebalanceAdjustmentType'] = 'COMPONENT';
    if(initial && initial.fromComponent && Object.keys(initial.fromComponent).length && !initial.rebalanceAdjustmentType)
      updated['rebalanceAdjustmentType'] = 'COMPONENT';

    if(updated && updated.percentageComponent && Object.keys(updated.percentageComponent).length && !updated.rebalanceAdjustmentType)
      updated['rebalanceAdjustmentType'] = 'PERCENTAGE';
    if(initial && initial.percentageComponent && Object.keys(initial.percentageComponent).length && !initial.rebalanceAdjustmentType)
      updated['rebalanceAdjustmentType'] = 'PERCENTAGE';

    if((!initial || (initial && initial.rebalanceAdjustmentType === 'COMPONENT')) &&
     (!updated || (updated && updated.rebalanceAdjustmentType === 'COMPONENT'))){
    if(initial && updated && initial.fromComponent && updated.fromComponent){
      changeSet['fromComponent'] = {};
      Object.keys(initial.fromComponent).forEach(key => {
        if((initial.fromComponent[key] || updated.fromComponent[key]) && initial.fromComponent[key] != updated.fromComponent[key]){
        changeSet['fromComponent'][key] = initial.fromComponent[key];
        }
      });
    }
    else if ((initial && initial.fromComponent) || (updated && updated.fromComponent)){
      if (initial && initial.fromComponent){
      changeSet['fromComponent'] = {...initial.fromComponent};
      }
    }
    if(initial && updated && initial.toComponent && updated.toComponent){
      changeSet['toComponent'] = {};
      Object.keys(initial.toComponent).forEach(key => {
        if((initial.toComponent[key] || updated.toComponent[key]) && initial.toComponent[key] != updated.toComponent[key]){
        changeSet['toComponent'][key] = initial.toComponent[key];
        }
      });
    }
    else if ((initial && initial.toComponent) || (updated && updated.toComponent)){
      if (initial && initial.toComponent){
      changeSet['toComponent'] = {...initial.toComponent};
      }
    }
    if((changeSet['fromComponent'] && !Object.keys(changeSet['fromComponent']).length))
      delete changeSet['fromComponent'];
    if((changeSet['toComponent'] && !Object.keys(changeSet['toComponent']).length))
      delete changeSet['toComponent'];
    return changeSet && ((changeSet['fromComponent'] && Object.keys(changeSet['fromComponent']).length) ||
    (changeSet['toComponent'] && Object.keys(changeSet['toComponent']).length)) ? this.getChangeSetWithType(changeSet, 'COMPONENT') : null;
    }
    else if ((!initial || (initial && initial.rebalanceAdjustmentType === 'PERCENTAGE')) &&
    (!updated || (updated && updated.rebalanceAdjustmentType === 'PERCENTAGE'))){
      if(initial && updated && initial.percentageComponent && updated.percentageComponent){
        changeSet['percentageComponent'] = {};
        Object.keys(initial.percentageComponent).forEach(key => {
          if((initial.percentageComponent[key] || updated.percentageComponent[key]) && initial.percentageComponent[key] != updated.percentageComponent[key]){
          changeSet['percentageComponent'][key] = initial.percentageComponent[key];
          }
        });
      }
      else if ((initial && initial.percentageComponent) || (updated && updated.percentageComponent)){
        if (initial && initial.percentageComponent)
        changeSet['percentageComponent'] = {...initial.percentageComponent};
      }
    return changeSet && ((changeSet['percentageComponent'] && Object.keys(changeSet['percentageComponent']).length))
     ? this.getChangeSetWithType(changeSet, 'PERCENTAGE') : null;
    }
    else if (initial && initial.rebalanceAdjustmentType === 'COMPONENT' && updated && updated.rebalanceAdjustmentType === 'PERCENTAGE'){
      changeSet['fromComponent'] = {...initial.fromComponent};
      changeSet['toComponent'] = {...initial.toComponent};
      changeSet['rebalanceAdjustmentType'] = initial.rebalanceAdjustmentType;
    return changeSet && ((changeSet['fromComponent'] && Object.keys(changeSet['fromComponent']).length))
      ? changeSet : null;
    }
    else if (updated && updated.rebalanceAdjustmentType === 'COMPONENT' && initial && initial.rebalanceAdjustmentType === 'PERCENTAGE'){
      changeSet['percentageComponent'] = {...initial.percentageComponent};
      changeSet['rebalanceAdjustmentType'] = initial.rebalanceAdjustmentType;
    return changeSet && ((changeSet['percentageComponent'] && Object.keys(changeSet['percentageComponent']).length))
      ? changeSet : null;
    }
  return null;
  }

  getChangeSetWithType(changeSet, type){
    changeSet['rebalanceAdjustmentType'] = type;
    return changeSet;
  }

  getAbfRatectionAdjChangeSet(updated, initial): any {
    let changeSet = {};
    for (let key in updated) {
      if (initial && updated && StringUtils.isEqual(key, CommonConstants.DISCOUNT_SPLITS) && updated[key] !== initial[key]) {
        const result = this.comparisonForArrayOfObj(updated[key], initial[key])
        if (!StringUtils.isUndefined(result) && result.length > 0)
          changeSet[key] = result;
      }
      else if (initial && updated && typeof initial[key] === "object" && typeof updated[key] === "object") {
        var value = this.getObjectChangeset(updated[key], initial[key]);
        if (value != null)
          changeSet[key] = value;
      } else if (initial && updated && key in initial && key in updated && updated[key] !== initial[key]) {
        changeSet[key] = updated[key];
      } else if(initial && updated && key == 'renewalWHAPercent' && updated[key] !== initial[key]){
        changeSet[key] = updated[key];
      }
    }
    return Object.keys(changeSet).length ? changeSet : null;
  }

  getAdjustmentChangeSetDetails(adjustmentData, oldQuoteDetail, productSeparator: string ,fundingType? ) {
    let adjustmentKeys = [
      "quoteAdjustments",
      "productAdjustments",
      "componentAdjustments",
      "rebalanceAdjustments",
      "contractEndDate",
      "exhibitName",
      "assignedUWName",
      "outputTier",
      "uwComments",
      "uwNotesToSales",
      'abfRateActionAdjustment',
      'statusReasons'
    ];
    let newChangeDetails = {};
    let oldChangeDetails = {};
    let newChanges;
    let oldChanges;
    let uwAdjustment =  (oldQuoteDetail && oldQuoteDetail['uwAdjustment']) || {};
    let initialTier = (uwAdjustment.outputTier  || oldQuoteDetail.medicalOutputTier);
    adjustmentKeys.forEach(adjustment => {
      if (adjustment === "quoteAdjustments") {
        newChanges = this.getObjectChangeset(adjustmentData[adjustment], uwAdjustment[adjustment]);
        oldChanges = this.getObjectChangeset(uwAdjustment[adjustment], adjustmentData[adjustment]);
      } else if (adjustment === "assignedUWName") {
        newChanges = adjustmentData[adjustment] != uwAdjustment[adjustment] ? adjustmentData[adjustment] : null;
        oldChanges = adjustmentData[adjustment] != uwAdjustment[adjustment] ? uwAdjustment[adjustment] : null;
      } else if (adjustment === "outputTier") {
        newChanges = adjustmentData[adjustment] != initialTier ? adjustmentData[adjustment] : null;
        oldChanges = adjustmentData[adjustment] != initialTier ? initialTier : null;
      } else if (adjustment === "productAdjustments") {
        newChanges = this.getProductAdjustmentChangesetDetails(
          adjustmentData[adjustment],
          uwAdjustment[adjustment],
          adjustmentData["quoteAdjustments"],
          productSeparator
        );
        oldChanges = this.getProductAdjustmentChangesetDetails(
          uwAdjustment[adjustment],
          adjustmentData[adjustment],
          uwAdjustment["quoteAdjustments"],
          productSeparator
        );
      } else if (adjustment === "componentAdjustments") {
        newChanges = this.getComponentAdjustmentChangesetDetails(
          adjustmentData[adjustment],
          uwAdjustment[adjustment]
        );
        oldChanges = this.getComponentAdjustmentChangesetDetails(
          uwAdjustment[adjustment],
          adjustmentData[adjustment]
        );
      } else if (adjustment === "rebalanceAdjustments") {
        newChanges = this.getRblAdjustmentChangesetDetails(
          uwAdjustment[adjustment],
          adjustmentData[adjustment]
        );
        oldChanges = this.getRblAdjustmentChangesetDetails(
          adjustmentData[adjustment],
          uwAdjustment[adjustment]
        );
      } else if(adjustment === 'abfRateActionAdjustment') {
        if(!uwAdjustment[adjustment] && oldQuoteDetail && oldQuoteDetail.factors && oldQuoteDetail.factors.experienceFactors &&
          oldQuoteDetail.factors.experienceFactors.expRateAction) {
           let expRateAction =  oldQuoteDetail.factors.experienceFactors.expRateAction;
           this.createOldQuoteabfRateActionAdj(uwAdjustment, adjustment, expRateAction, fundingType);
        }
        else if(uwAdjustment[adjustment]) {
          if (fundingType && StringUtils.isEqual(fundingType, 'FI') && !uwAdjustment[adjustment]['isFlatRateApplied']) {
            uwAdjustment[adjustment]['isFlatRateApplied'] = false;
          }
        }
        newChanges = this.getAbfRatectionAdjChangeSet(adjustmentData[adjustment], uwAdjustment[adjustment]);
        oldChanges = this.getAbfRatectionAdjChangeSet(uwAdjustment[adjustment], adjustmentData[adjustment]);
      }
      else if (StringUtils.isEqual(adjustment, CommonConstants.STATUS_REASONS)) {
        if (!this.arraysAreEqual(adjustmentData[adjustment], uwAdjustment[adjustment])) {
          newChanges = adjustmentData[adjustment] && adjustmentData[adjustment].length > 0 ? adjustmentData[adjustment] : null;
          oldChanges = uwAdjustment[adjustment] && uwAdjustment[adjustment].length > 0 ? uwAdjustment[adjustment] : null;
        }
        else {
          newChanges = null;
          oldChanges = null;
        }
      }
      else if (adjustmentData[adjustment] !== uwAdjustment[adjustment]) {
        newChanges = adjustmentData[adjustment];
        oldChanges = uwAdjustment[adjustment];
      } else {
        newChanges = null;
        oldChanges = null;
      }
      if (newChanges != null) {
        newChangeDetails[adjustment] = newChanges;
      }
      if (oldChanges != null) {
        oldChangeDetails[adjustment] = oldChanges;
      }
    });
    let adjustmentChangeDetails = {};
    if (Object.keys(newChangeDetails).length) {
      adjustmentChangeDetails["newValue"] = { ...newChangeDetails };
    }
    if (Object.keys(oldChangeDetails).length) {
      adjustmentChangeDetails["oldValue"] = { ...oldChangeDetails };
    }

    return Object.keys(adjustmentChangeDetails).length ? adjustmentChangeDetails : null;

    
  }
  arraysAreEqual(array1, array2) {
    if (StringUtils.isUndefined(array2) || (array1?.length !== array2?.length)) {
      return false;
    }
    return array1.every((value, index) => value === array2[index]);
  }

  comparisonForArrayOfObj(updateWhObj, initialWhObj) {
    const isUpdated = (updateWhObj, initialWhObj) => updateWhObj.value == initialWhObj.value && updateWhObj.id == initialWhObj.id;
    if (StringUtils.isUndefined(initialWhObj)) {
      return updateWhObj;
    }
    const getUniqueArray = (compareWhObj1, compareWhObj2, compareFunction) =>
    compareWhObj2?.filter(updatedObj =>
        !compareWhObj1?.some(initialObj =>
          compareFunction(updatedObj, initialObj)));
    const onlyInInitial = getUniqueArray(updateWhObj, initialWhObj, isUpdated);
    const onlyInUpdated = getUniqueArray(initialWhObj, updateWhObj, isUpdated);
    return onlyInUpdated;
  }
    createOldQuoteabfRateActionAdj(uwAdjustment: any, adjustment: string, expRateAction: any ,fundingType? : string) {
      
    uwAdjustment[adjustment] = {};
    uwAdjustment[adjustment]['componentRateAction'] = {};
    uwAdjustment[adjustment]['adjustedRateActionPercent'] = Math.round(+(expRateAction['totalPremium'] * 100).toFixed(6) * 1000000) / 1000000;
    uwAdjustment[adjustment]['componentRateAction']['asoAdminFee'] = Math.round(+(expRateAction['asoAdminFee'] * 100).toFixed(6) * 1000000) / 1000000;
    uwAdjustment[adjustment]['componentRateAction']['sslPremium'] = Math.round( +(expRateAction['sslPremium'] * 100).toFixed(6) * 1000000) / 1000000;
    uwAdjustment[adjustment]['componentRateAction']['aslPremium'] = Math.round(+(expRateAction['aslPremium'] * 100).toFixed(6) * 1000000) / 1000000;
    uwAdjustment[adjustment]['componentRateAction']['maxPaidClaim'] = Math.round( +(expRateAction['maxPaidClaim'] * 100).toFixed(6) * 1000000) / 1000000;
    uwAdjustment[adjustment]['componentRateAction']['terminalLiability'] = Math.round( +(expRateAction['terminalLiability'] * 100).toFixed(6) * 1000000) / 1000000;
      if (StringUtils.isEqual(fundingType, 'FI')) {
        uwAdjustment[adjustment]['isFlatRateApplied'] = false;
      }
  }

  getJSONStringifiedValue(obj: any): string {
    return JSON.stringify(obj, (key, value) => (value == null ? 0 : value));
  }

  cleanupNullNodes(obj: any): any {
    if ((obj && Object.keys((obj)).length > 0)) {
      Object.keys(obj).forEach(eleKey => {
        if (obj[eleKey] === null || obj[eleKey] === undefined) {
          delete obj[eleKey];
        }
      });
    }
    return obj;
  }

  isPlanComparisonChanged(quoteDetails, oldQuoteDetails): boolean {
    let mpcData = quoteDetails.medicalPremiumComparison || {};
    let mpcInitialData = oldQuoteDetails.medicalPremiumComparison || {};
    let requestedTier = (quoteDetails.uwAdjustment && quoteDetails.uwAdjustment.outputTier && quoteDetails.uwAdjustment.outputTier) ||
        quoteDetails.medicalOutputTier;
    let initialTier = (oldQuoteDetails.uwAdjustment && oldQuoteDetails.uwAdjustment.outputTier && oldQuoteDetails.uwAdjustment.outputTier)
        || oldQuoteDetails.medicalOutputTier;
    let cumulativeTierLives = (quoteDetails.factors && quoteDetails.factors.calculatedTierLives) || {};

    if (mpcData && mpcData.planComparison) {

        if(quoteDetails && quoteDetails.medical && quoteDetails.medical.proposedPlans){
             let fPlan= quoteDetails.medical.proposedPlans.find(plan => plan.planTypeRequested == 'F' && plan.status && plan.status && plan.includeInPrintExhibit == false);
             if(fPlan){
              mpcData.hasSuppressedPlans = true;
             }else {
              mpcData.hasSuppressedPlans = false;
             }
          }
      for (const pc of mpcData.planComparison) {
        let updatedMPC: PlanComparison;
        let initialMPC: PlanComparison;
        if (pc.quoteRatingPlanID && pc.quoteRates) {
          updatedMPC = this.getMPCplan(mpcData, pc.quoteRatingPlanID, "quoteRatingPlanID");
          initialMPC = this.getMPCplan(mpcInitialData, pc.quoteRatingPlanID, "quoteRatingPlanID");
        } else {
          updatedMPC = this.getMPCplan(mpcData, pc.currPlanId, "currPlanId");
          initialMPC = this.getMPCplan(mpcInitialData, pc.currPlanId, "currPlanId");
        }

        if(quoteDetails && quoteDetails.opportunityType == 'Renewal Local'){
          if (pc['disableEdit']) {
            delete pc['disableEdit'];
          }
          if (pc['calWholeCase']) {
            delete pc['calWholeCase'];
          }
          let featuredPlan ;
          if(quoteDetails && quoteDetails.medical && quoteDetails.medical.proposedPlans){
            featuredPlan = quoteDetails.medical.proposedPlans.find(plan => plan.contractCode == pc.quoteContractCode);
          }

          if( featuredPlan && featuredPlan.includeInPrintExhibit == true && this.getObjectChangeset(updatedMPC.currentEnrollments, initialMPC.initialCurrentEnrollments)){

            return true;
          }
          if (requestedTier == initialTier) {
              if (featuredPlan && featuredPlan.includeInPrintExhibit == true && this.getObjectChangeset(updatedMPC.quoteEnrollments, initialMPC.initialCurrentEnrollments)) {
                return true;
              }
            } else {
              let enrollment;
              if (updatedMPC.currentTier !== updatedMPC.quoteTier && updatedMPC.quoteEnrollments) {
                enrollment = this.getMappedEnrollments(updatedMPC.quoteTier, cumulativeTierLives[updatedMPC.quoteTier + '-tier']);
              } else {
                enrollment = {...initialMPC.quoteEnrollments};
              }
              if (featuredPlan && featuredPlan.includeInPrintExhibit == true && this.getObjectChangeset(updatedMPC.quoteEnrollments, enrollment)) {
                return true;
              }
            }

        }else {
          if (this.getObjectChangeset(updatedMPC.currentEnrollments, initialMPC.currentEnrollments)) {
            return true;
          }
          if (this.getObjectChangeset(this.cleanupRateFormatting(updatedMPC.currentRates), this.cleanupRateFormatting(initialMPC.currentRates))) {
            return true;
          }
          if (this.getObjectChangeset(this.cleanupRateFormatting(updatedMPC.renewalRates), this.cleanupRateFormatting(initialMPC.renewalRates))) {
            return true;
          }

          if (requestedTier == initialTier) {
          // There is no output tier cahnge, so validate the quote enrollments directly
            if (this.getObjectChangeset(updatedMPC.quoteEnrollments, initialMPC.quoteEnrollments)) {
              return true;
            }
          } else {
          // There is output tier cahnge, so need to decide whether to use the enrollments or calculated tier lives
            let enrollment;
            if (updatedMPC.currentTier !== updatedMPC.quoteTier && updatedMPC.quoteEnrollments) {
              // Since the tiers are different, then user changed the tier, and we loaded the whole case enrollemnt
              enrollment = this.getMappedEnrollments(updatedMPC.quoteTier, cumulativeTierLives[updatedMPC.quoteTier + '-tier']);
            } else {
              enrollment = {...initialMPC.quoteEnrollments};
            }
            if (this.getObjectChangeset(updatedMPC.quoteEnrollments, enrollment)) {
              return true;
            }
          }
        }
      }
      return mpcData['includeInProposal'] != mpcInitialData['includeInProposal'];
    }
    return false ;
  }

  getMPCplan(mpcData: any, id: string, idType: string): any {
    return mpcData.planComparison.find(x => x[idType] === id);
  }

  getCustomTierRatioChangeSetDetails(quoteDetail: any, oldQuoteDetail: any): any {
    let customTierChangeDetails = {};

    let initialData = (oldQuoteDetail && oldQuoteDetail.uwAdjustment && oldQuoteDetail.uwAdjustment.customTierRatio) || {};
    let updatedData = (quoteDetail && quoteDetail.uwAdjustment && quoteDetail.uwAdjustment.customTierRatio) || {};

    let newChanges = this.getObjectChangeset(updatedData, initialData);
    let oldChanges = this.getObjectChangeset(initialData, updatedData);

    if (newChanges && Object.keys(newChanges).length) {
      customTierChangeDetails["newValue"] = { ...newChanges };
    }
    if (oldChanges && Object.keys(oldChanges).length) {
      customTierChangeDetails["oldValue"] = { ...oldChanges };
    }
    return Object.keys(customTierChangeDetails).length ? customTierChangeDetails : null;
  }

  getRemovedPlanIdsList(quoteDetails: any): any[] {
    let retValue = [];
    if (quoteDetails && quoteDetails['medical'] && quoteDetails['medical']['proposedPlans']) {
      quoteDetails['medical']['proposedPlans'].forEach(plan => {
        if (plan.planTypeRequested === 'R' && !!plan.markedForDelete) {
          retValue.push({"ratingPlanID": plan.ratingPlanID, "contractCode": plan.contractCode});
        }
      });
    }
    return retValue;
  }

  retrieveIEPlanList(quoteDetails: any): any[] {
    let retValue = [];
    if(quoteDetails && quoteDetails['medical'] && quoteDetails['medical']['proposedPlans']) {
      quoteDetails['medical']['proposedPlans'].filter(plan => (plan.toggled || plan.guardrailToggled)).forEach(pPlan => {
        let retObj = {"ratingPlanID": pPlan.ratingPlanID, "contractCode": pPlan.contractCode, 'includeInPrintExhibit':pPlan.includeInPrintExhibit, 'planTypeRequested':pPlan.planTypeRequested};
        if(pPlan.toggled){
          retObj["includeInPrintExhibitOverride"] = true;
        }
        retValue.push(retObj);
        delete pPlan.toggled;
        delete pPlan.guardrailToggled;
      })
    }

   return retValue;
  }

  getPlanLevelLivesChangeset(quoteDetails: any, oldQuoteDetails: any, requestedTier: number) {
    let tierKey = requestedTier + '-tier';
    let changeSetDetail = null;
    let uwAdjustedPlanLevelLives = null;
    let planLives = [];
    let hasDifferences = false ;
    let oldValues = [];
    let newValues = [];
    // If the Adjustment has PlanLives then it means the user already override the lives at feature plan level
    if (oldQuoteDetails && oldQuoteDetails.uwAdjustment && oldQuoteDetails.uwAdjustment.peOverrideData &&
      oldQuoteDetails.uwAdjustment.peOverrideData.planLevelLives && oldQuoteDetails.uwAdjustment.peOverrideData.planLevelLives.length != 0) {
      uwAdjustedPlanLevelLives = JSON.parse(JSON.stringify(oldQuoteDetails.uwAdjustment.peOverrideData.planLevelLives));
      if (Array.isArray(uwAdjustedPlanLevelLives)) {
        let updatedValues = {};
        uwAdjustedPlanLevelLives.forEach(plan => {
          updatedValues[plan.ratingPlanID] = { ...plan.lives };
        });
        uwAdjustedPlanLevelLives = updatedValues;
      }
    }

    if (quoteDetails && quoteDetails['medical'] && quoteDetails['medical']['proposedPlans']) {
      // get the filtered feature plans
      let featurePlans = quoteDetails['medical']['proposedPlans'].filter(plan =>
          plan.planTypeRequested === 'F' && plan.status !== "Failed" && plan.lives);
      // if it has atleast more than one success full feature plan and have lives mapped
      if (featurePlans.length > 0) {
        // get the cumulative lives to cross check any change happened
        let cumulativeTierLives = featurePlans[0].factors.calculatedTierLives[tierKey];
        featurePlans.forEach(plan => {
          if ((this.getObjectChangeset(plan.lives[tierKey], cumulativeTierLives) != null)) {
            // changing the approach to store only the changed plan lives
            planLives.push({ "ratingPlanID": plan.ratingPlanID, "lives": { ...plan.lives[tierKey] } });
            hasDifferences = true;
          }
        });

        // if there is a difference in lives or the adjustment node has planlevelLives
        if (hasDifferences || uwAdjustedPlanLevelLives) {
          hasDifferences = true;
          planLives.forEach(plan => {
            let oldValue = null;
            let newValue = null;
            if (uwAdjustedPlanLevelLives && uwAdjustedPlanLevelLives[plan.ratingPlanID]) {
              newValue = this.getObjectChangeset(plan.lives, uwAdjustedPlanLevelLives[plan.ratingPlanID])
              oldValue = this.getObjectChangeset(uwAdjustedPlanLevelLives[plan.ratingPlanID], plan.lives)
            } else {
              newValue = this.getObjectChangeset(plan.lives, cumulativeTierLives)
              oldValue = this.getObjectChangeset(cumulativeTierLives, plan.lives)
            }
            if (oldValue) {
              oldValues.push({ "ratingPlanID": plan.ratingPlanID, "lives": { ...oldValue } });
            }
            if (newValue) {
              newValues.push({ "ratingPlanID": plan.ratingPlanID, "lives": { ...newValue } });
            }
          });
        }

        if (oldValues.length > 0 || newValues.length > 0) {
          changeSetDetail = { oldValues, newValues }
        }

        if (hasDifferences) {
          return {
            planLives,
            changeSetDetail
          };
        }
      }
    }
    return null;
  }

  private setToggledPlan(toggledPlanList): any {
    let oldList = [];
    toggledPlanList.forEach(element => {
      oldList.push({ ratingPlanId: element.ratingPlanID, contractCode: element.contractCode, includeInPrintExhibit: !element.includeInPrintExhibit, planTypeRequested: element.planTypeRequested });
    });
    return oldList;
  }

  getPEOverrideDataChangeSetDetails(quoteDetails, oldQuoteDetails, exhibitSheets): any {
    let changesetDetail = {};
    let peOverrideValue = {};
    let requestedTier = (quoteDetails.uwAdjustment && quoteDetails.uwAdjustment.outputTier && quoteDetails.uwAdjustment.outputTier) ||
        quoteDetails.medicalOutputTier;
    let tierKey = requestedTier + '-tier';

    if(quoteDetails.uwAdjustment && quoteDetails.uwAdjustment.peOverrideData && quoteDetails.uwAdjustment.peOverrideData.sheetCodes){
      this.updateIncludeExcludeSheets(quoteDetails.uwAdjustment.peOverrideData.sheetCodes, exhibitSheets, quoteDetails);
    }

    let peOverrideData = JSON.parse(JSON.stringify(quoteDetails.uwAdjustment && quoteDetails.uwAdjustment.peOverrideData) || "{}");
    let existingPeeOverrideData = JSON.parse(JSON.stringify(oldQuoteDetails && oldQuoteDetails.uwAdjustment &&
        oldQuoteDetails.uwAdjustment.peOverrideData) || "{}");
    let existingExhibitSheets;
    if(existingPeeOverrideData && existingPeeOverrideData.printExhibitEligibility){
      existingExhibitSheets = JSON.parse(JSON.stringify(existingPeeOverrideData.printExhibitEligibility));
    }
    let { lives, ...existingData } = existingPeeOverrideData;
    let newData = { ...peOverrideData };
    let newAdjustedLives = { ...newData.lives };
    let newExhibitOverride;
    let newIEInPE;
    if(peOverrideData && peOverrideData.printExhibitEligibility){
      newExhibitOverride = JSON.parse(JSON.stringify(peOverrideData.printExhibitEligibility));
    }

    let includeExcludeInPEList = this.retrieveIEPlanList(quoteDetails);
    let existingIEInPE;
    if(includeExcludeInPEList.length > 0) {
      peOverrideData.inculdeExcludeInPE  = includeExcludeInPEList;
      newIEInPE = includeExcludeInPEList;
      if(existingPeeOverrideData && existingPeeOverrideData.includeExcludeInPE &&  existingPeeOverrideData.includeExcludeInPE.length > 0){
        existingIEInPE = this.setToggledPlan(newIEInPE);
      }
    }


    delete newData.lives;
    delete newData.planLives;
    delete newData.planLevelLives;
    delete existingData.planLevelLives;
    delete existingData.printExhibitEligibility;
    delete newData.printExhibitEligibility;
    delete newData.includeExcludeInPE;

    let hasAdjustedValues = (newAdjustedLives && Object.keys(newAdjustedLives).length > 0) || (newData && Object.keys(newData).length > 0);

    if ((!lives || Object.keys(lives).length == 0) && hasAdjustedValues) {
      if (oldQuoteDetails && oldQuoteDetails['medical'] && oldQuoteDetails.quotingType !== 'MEWA' && oldQuoteDetails['medical']['proposedPlans']) { // ToDo - To be Check and remove
        let successfulPlan = oldQuoteDetails['medical']['proposedPlans'].find(plan =>
          (plan.planTypeRequested === 'F' || plan.planTypeRequested === 'P') && plan.status !== "Failed");
        if (successfulPlan) {
          lives = successfulPlan.factors.calculatedTierLives[tierKey];
        }
      }
    }

    if ((!existingData || Object.keys(existingData).length == 0) && hasAdjustedValues)  {
      existingData = {};
      let totalMedEmp = 0;
      let waivers = 0;
      let eligibleEmp = 0;
      if (oldQuoteDetails.censusCalc && oldQuoteDetails.censusCalc.censusSubscriber &&
          oldQuoteDetails.censusCalc.censusSubscriber.medEligibilityLivesMap) {
        totalMedEmp = oldQuoteDetails.censusCalc.censusSubscriber.medEligibilityLivesMap.QuotedCount || 0;
        eligibleEmp = oldQuoteDetails.censusCalc.censusSubscriber.medEligibilityLivesMap.EligibleCount || 0;
        waivers = oldQuoteDetails.censusCalc.censusSubscriber.medEligibilityLivesMap.WaiverCount || 0;
      }
      existingData['contractEffectiveDate'] = oldQuoteDetails.contractEffectiveDate;
      existingData['contractEndDate'] = oldQuoteDetails.contractEndDate;
      existingData['rateGuaranteeEffectiveDate'] = oldQuoteDetails.suppHealth?.guaranteeEffectiveDate;
      existingData['rateGuaranteeEndDate'] = oldQuoteDetails.suppHealth?.guaranteeEndDate;
      existingData['quotedCount'] = totalMedEmp;
      existingData['eligibleCount'] = eligibleEmp;
      existingData['waiverCount'] = waivers;
    }

    let newLivesValue = this.getObjectChangeset(newAdjustedLives, lives);
    let newOtherOverridesValue = this.getObjectChangeset(newData, existingData);
    let oldLivesValue = this.getObjectChangeset(lives, newAdjustedLives);
    let oldOtherOverridesValue = this.getObjectChangeset(existingData, newData);

    if (newOtherOverridesValue) {
      peOverrideValue = { ...newData };
    }
    if (newLivesValue) {
      peOverrideValue['lives'] = { ...newAdjustedLives };
    }

    if (newOtherOverridesValue) {
      changesetDetail["newValue"] = { ...newOtherOverridesValue };
    }

    if (oldOtherOverridesValue) {
      changesetDetail["oldValue"] = { ...oldOtherOverridesValue };
    }

    if (newLivesValue) {
      if (!changesetDetail["newValue"]) {
        changesetDetail["newValue"] = {};
      }
      changesetDetail["newValue"]["lives"] = { ...newLivesValue };
    }

    if (oldLivesValue) {
      if (!changesetDetail["oldValue"]) {
        changesetDetail["oldValue"] = {};
      }
      changesetDetail["oldValue"]["lives"] = { ...oldLivesValue };
    }


    let planLevelLives = this.getPlanLevelLivesChangeset(quoteDetails, oldQuoteDetails, requestedTier);
    if (planLevelLives && planLevelLives.planLives) {
      peOverrideValue['planLevelLives'] = [...planLevelLives.planLives];
    }

    if (planLevelLives && planLevelLives.changeSetDetail && planLevelLives.changeSetDetail.newValues) {
      if (!changesetDetail["newValue"]) {
        changesetDetail["newValue"] = {};
      }
      changesetDetail["newValue"]["planLevelLives"] = [...planLevelLives.changeSetDetail.newValues];
    }

    if (planLevelLives && planLevelLives.changeSetDetail && planLevelLives.changeSetDetail.oldValues) {
      if (!changesetDetail["oldValue"]) {
        changesetDetail["oldValue"] = {};
      }
      changesetDetail["oldValue"]["planLevelLives"] = [...planLevelLives.changeSetDetail.oldValues];
    }
    if(newIEInPE) {
      if (!changesetDetail["newValue"]) {
        changesetDetail["newValue"] = {};
      }
      changesetDetail['newValue']['includeExcludeInPE'] = newIEInPE;
      if(existingIEInPE){
      changesetDetail['oldValue']['includeExcludeInPE'] = existingIEInPE;
      }
    }else {
      if(Object.keys(changesetDetail).length > 0) {
      if(changesetDetail['oldValue'] && changesetDetail['oldValue']['includeExcludeInPE'])
      delete changesetDetail['oldValue']['includeExcludeInPE'];
      if(changesetDetail['newValue'] && changesetDetail['newValue']['includeExcludeInPE'])
      delete changesetDetail['newValue']['includeExcludeInPE'];
      }
     }

    if(newExhibitOverride){
      let incomingExhibitSheets = [];
      if(existingExhibitSheets){
          incomingExhibitSheets = existingExhibitSheets;
      }else{
        incomingExhibitSheets = exhibitSheets;
      }
      let oldSheets = incomingExhibitSheets.filter(({ sheetStatus: status1, printExhibitSheetName: name1 }) =>
      !newExhibitOverride.some(({ sheetStatus: status2, printExhibitSheetName: name2 }) =>
      (name1 === name2 && status1 === status2)));

      let newSheets = newExhibitOverride.filter(({ sheetStatus: status1, printExhibitSheetName: name1 }) =>
      !incomingExhibitSheets.some(({ sheetStatus: status2, printExhibitSheetName: name2 }) =>
      (name1 === name2 && status1 === status2)));
      if (newSheets && newSheets.length>0) {
        if(!changesetDetail["newValue"]){
          changesetDetail["newValue"] = {};
        }
        changesetDetail["newValue"]["printExhibitEligibility"] = newSheets;
        peOverrideValue["printExhibitEligibility"] = newExhibitOverride;
      }else if(changesetDetail["newValue"] && changesetDetail["newValue"].printExhibitEligibility){
        delete changesetDetail["newValue"].printExhibitEligibility;
      }
      if (oldSheets && oldSheets.length>0) {
        if(!changesetDetail["oldValue"]){
          changesetDetail["oldValue"] = {};
        }
        changesetDetail["oldValue"]["printExhibitEligibility"] = oldSheets;
      }else if(changesetDetail["oldValue"] && changesetDetail["oldValue"].printExhibitEligibility){
        delete changesetDetail["oldValue"].printExhibitEligibility;
      }
    }
    if(changesetDetail && changesetDetail["newValue"] && !changesetDetail["newValue"].printExhibitEligibility &&
    existingExhibitSheets && existingExhibitSheets.length>0){
      peOverrideValue["printExhibitEligibility"] = existingExhibitSheets;
    }
    if(changesetDetail && changesetDetail["newValue"] &&  changesetDetail['newValue']['includeExcludeInPE']) {
      peOverrideValue['includeExcludeInPE'] = newIEInPE;
    }
    if (Object.keys(peOverrideValue).length) {
      if(peOverrideValue["sheetCodes"]){
        delete peOverrideValue["sheetCodes"];
      }
      if(changesetDetail["newValue"] && changesetDetail["newValue"]["sheetCodes"]){
        delete changesetDetail["newValue"]["sheetCodes"];
      }

      if (changesetDetail && changesetDetail["newValue"] && !changesetDetail["newValue"].printExhibitEligibility && changesetDetail['newValue']['includeExcludeInPE']) {
        if(existingIEInPE == undefined) {
          delete changesetDetail["oldValue"];
        }else {
          delete changesetDetail["newValue"]['ratingPlanID'];
        }
      }

      if(changesetDetail && changesetDetail["oldValue"] && !changesetDetail["oldValue"].printExhibitEligibility && changesetDetail['oldValue']['includeExcludeInPE']) {
        delete changesetDetail['oldValue']['ratingPlanID'];
        delete changesetDetail['oldValue']['lives'];
      }
      return {
        peOverrideValue,
        changesetDetail
      };
    }

    return null;
  }

  updateIncludeExcludeSheets(sheetCodes : any, exhibitSheets : any, quoteDetails : any){
    let exhibitSheetChanges;
    let previousExhibitSheets;
    if(quoteDetails.uwAdjustment.peOverrideData.printExhibitEligibility){
      exhibitSheetChanges = JSON.parse(JSON.stringify(quoteDetails.uwAdjustment.peOverrideData.printExhibitEligibility));
      previousExhibitSheets = quoteDetails.uwAdjustment.peOverrideData.printExhibitEligibility;
    }else{
      exhibitSheetChanges = JSON.parse(JSON.stringify(exhibitSheets));
      previousExhibitSheets = exhibitSheets;
    }
    let changed : boolean;
    if(sheetCodes.length === 0){
      changed = true;
    }
    sheetCodes.forEach((code) => {
      exhibitSheetChanges?.forEach((obj) => {
        if (obj.printExhibitTypeCode === code && obj.sheetStatus === "Exclude") {
          obj.sheetStatus = "Include";
          changed = true;
        }
      });
    });
    exhibitSheetChanges.forEach((obj) => {
      if (!sheetCodes.includes(obj.printExhibitTypeCode)) {
        obj.sheetStatus = "Exclude";
        changed = true;
      }
    })
    
    if(changed){
      let difference = previousExhibitSheets.filter(({ sheetStatus: status1, printExhibitSheetName: name1 }) =>
       !exhibitSheetChanges.some(({ sheetStatus: status2, printExhibitSheetName: name2 }) =>
        (name1 === name2 && status1 === status2)));

      if(difference && difference.length>0){
        quoteDetails.uwAdjustment.peOverrideData.printExhibitEligibility = exhibitSheetChanges;
      }else{
        delete quoteDetails.uwAdjustment.peOverrideData['printExhibitEligibility'];
      }
    }else{
      delete quoteDetails.uwAdjustment.peOverrideData['printExhibitEligibility'];
    }
    if(quoteDetails.uwAdjustment.peOverrideData.sheetCodes){
      delete quoteDetails.uwAdjustment.peOverrideData.sheetCodes;
    }
  }

  getTierRatioSelectionChangeSetDetails(quoteDetails, oldQuoteDetails): any {
    let currentSelection = quoteDetails && quoteDetails.uwAdjustment && quoteDetails.uwAdjustment.tierRatioCalculationType ||
      quoteDetails && quoteDetails.factors && quoteDetails.factors.tierRatioCalculationType;
    let prevSelection = oldQuoteDetails && oldQuoteDetails.uwAdjustment && oldQuoteDetails.uwAdjustment.tierRatioCalculationType ||
      oldQuoteDetails && oldQuoteDetails.factors && oldQuoteDetails.factors.tierRatioCalculationType;
    if (currentSelection != prevSelection) {
      return { "newValue": currentSelection, "oldValue": prevSelection };
    }
    return null;
  }

constructBulkChangeSet(intial , updated, quotingType?: string) {
  let changeSet = {};
  const isMEWA = quotingType === CommonConstants.MEWA;
  
  if (intial && updated) {
    // Always initialize the structure
    if (!changeSet['changeSetDetail']) changeSet['changeSetDetail'] = {};
    if (!changeSet['changeSetDetail']['adjustmentData']) changeSet['changeSetDetail']['adjustmentData'] = {};
    if (!changeSet['changeSetDetail']['adjustmentData']['newValue']) changeSet['changeSetDetail']['adjustmentData']['newValue'] = {};
    if (!changeSet['changeSetDetail']['adjustmentData']['oldValue']) changeSet['changeSetDetail']['adjustmentData']['oldValue'] = {};

    // Accumulate all changes
    if (updated['uwNotesToSales'] && (intial['uwNotesToSales'] != updated['uwNotesToSales'])) {
      changeSet['changeSetDetail']['adjustmentData']['newValue']['uwNotesToSales'] = updated['uwNotesToSales'];
      changeSet['changeSetDetail']['adjustmentData']['oldValue']['uwNotesToSales'] = intial['uwNotesToSales'];
    }

    if (intial['uwComments'] != updated['uwComments']) {
      changeSet['changeSetDetail']['adjustmentData']['newValue']['uwComments'] = updated['uwComments'];
      changeSet['changeSetDetail']['adjustmentData']['oldValue']['uwComments'] = intial['uwComments'];
    }

    // Only include visionProductAdjustments if there is a change
    if (updated.visionProductAdjustments && Array.isArray(updated.visionProductAdjustments) && updated.visionProductAdjustments.length > 0) {
      const initialVision = intial.visionProductAdjustments && Array.isArray(intial.visionProductAdjustments) ? intial.visionProductAdjustments : [];
      const updatedVision = updated.visionProductAdjustments;
      const visionChanged =
        initialVision.length !== updatedVision.length ||
        updatedVision.some((adj, idx) => {
          const initAdj = initialVision[idx];
          if (!initAdj) return true;
          return adj.proposedRateActionAdjustment !== initAdj.proposedRateActionAdjustment ||
                 adj.suggestedRateActionAdjustment !== initAdj.suggestedRateActionAdjustment ||
                 adj.planName !== initAdj.planName ||
                 adj.ratingPlanID !== initAdj.ratingPlanID;
        });
      if (visionChanged) {
        changeSet['changeSetDetail']['adjustmentData']['newValue']['visionProductAdjustments'] = updatedVision.map(adj => ({
          proposedRateActionAdjustment: adj.proposedRateActionAdjustment,
          suggestedRateActionAdjustment: (adj.suggestedRateActionAdjustment === null || adj.suggestedRateActionAdjustment === undefined) ? 1 : adj.suggestedRateActionAdjustment,
          planName: adj.planName,
          ratingPlanID: adj.ratingPlanID
        }));
        changeSet['changeSetDetail']['adjustmentData']['oldValue']['visionProductAdjustments'] = initialVision.map(adj => ({
          proposedRateActionAdjustment: adj.proposedRateActionAdjustment,
          suggestedRateActionAdjustment: adj.suggestedRateActionAdjustment,
          planName: adj.planName,
          ratingPlanID: adj.ratingPlanID
        }));
      }
    }

    // Only include dentalProductAdjustments if there is a change
    const hasAdjPlan = Object.keys(updated).some(key => key.startsWith('adjPlan'));
    if (hasAdjPlan && updated.dentalProductAdjustments && Array.isArray(updated.dentalProductAdjustments) && updated.dentalProductAdjustments.length > 0) {
      const initialDental = intial.dentalProductAdjustments && Array.isArray(intial.dentalProductAdjustments) ? intial.dentalProductAdjustments : [];
      const updatedDental = updated.dentalProductAdjustments;
      const dentalChanged =
        initialDental.length !== updatedDental.length ||
        updatedDental.some((adj, idx) => {
          const initAdj = initialDental[idx];
          if (!initAdj) return true;
          return adj.proposedRateActionAdjustment !== initAdj.proposedRateActionAdjustment ||
            adj.suggestedRateActionAdjustment !== initAdj.suggestedRateActionAdjustment ||
            adj.planName !== initAdj.planName ||
            adj.ratingPlanID !== initAdj.ratingPlanID;
        });
      if (dentalChanged) {
        changeSet['changeSetDetail']['adjustmentData']['newValue']['dentalProductAdjustments'] = updatedDental.map(adj => ({
          proposedRateActionAdjustment: adj.proposedRateActionAdjustment,
          suggestedRateActionAdjustment: (adj.suggestedRateActionAdjustment === null || adj.suggestedRateActionAdjustment === undefined) ? 1 : adj.suggestedRateActionAdjustment,
          planName: adj.planName,
          ratingPlanID: adj.ratingPlanID
        }));
        changeSet['changeSetDetail']['adjustmentData']['oldValue']['dentalProductAdjustments'] = initialDental.map(adj => ({
          proposedRateActionAdjustment: adj.proposedRateActionAdjustment,
          suggestedRateActionAdjustment: adj.suggestedRateActionAdjustment,
          planName: adj.planName,
          ratingPlanID: adj.ratingPlanID
        }));
      }
    }

    // Only include overallProposedIncrease if it actually changed
    const newOverall = CalculatorUtils.convertPercentageToFactor(Number(updated['overallProposedIncrease']));
    const oldOverall = CalculatorUtils.convertPercentageToFactor(Number(intial['overallProposedIncrease']));
    if (newOverall !== oldOverall) {
      changeSet['changeSetDetail']['adjustmentData']['newValue']['overallProposedIncrease'] = newOverall;
      changeSet['changeSetDetail']['adjustmentData']['oldValue']['overallProposedIncrease'] = oldOverall;
    }

    this.constructChngSetTotRatAct('adjustedRateActionPercent', updated, intial, changeSet);
    if(!isMEWA){
      this.constructChngSetTotRatAct('renewalWHAPercent', updated, intial, changeSet);
      this.constructChngSetToWHDetails(updated, intial, changeSet);
    } else {
      this.constructChngSetMewaQuoteAdj('currentRiskFactor', updated, intial, changeSet);
      this.constructChngSetMewaQuoteAdj('riskFactor', updated, intial, changeSet);
      this.constructChngSetMewaQuoteAdj('uwAdjustmentFactor', updated, intial, changeSet);
      this.constructChngSetMewaQuoteAdj('wholeHealthAdjustmentFactor', updated, intial, changeSet);
      this.constructChngSetToMewaWHDetails(updated, intial, changeSet);
    }

    this.bulkCompRateActionKeys.forEach(key => {
      if (updated[key] && (intial[key] != updated[key])) {
        if (!changeSet['changeSetDetail']['adjustmentData']['newValue']['abfRateActionAdjustment']) {
          changeSet['changeSetDetail']['adjustmentData']['newValue']['abfRateActionAdjustment'] = {};
        }
        if (!changeSet['changeSetDetail']['adjustmentData']['oldValue']['abfRateActionAdjustment']) {
          changeSet['changeSetDetail']['adjustmentData']['oldValue']['abfRateActionAdjustment'] = {};
        }
        if (!changeSet['changeSetDetail']['adjustmentData']['newValue']['abfRateActionAdjustment']['componentRateAction']) {
          changeSet['changeSetDetail']['adjustmentData']['newValue']['abfRateActionAdjustment']['componentRateAction'] = {};
        }
        if (!changeSet['changeSetDetail']['adjustmentData']['oldValue']['abfRateActionAdjustment']['componentRateAction']) {
          changeSet['changeSetDetail']['adjustmentData']['oldValue']['abfRateActionAdjustment']['componentRateAction'] = {};
        }
        changeSet['changeSetDetail']['adjustmentData']['newValue']['abfRateActionAdjustment']['componentRateAction'][key] = updated[key];
        changeSet['changeSetDetail']['adjustmentData']['oldValue']['abfRateActionAdjustment']['componentRateAction'][key] = intial[key];
      }
    });
  }
  // Only return if there is at least one change
  return (changeSet['changeSetDetail'] && changeSet['changeSetDetail']['adjustmentData'] &&
    (Object.keys(changeSet['changeSetDetail']['adjustmentData']['newValue']).length > 0 ||
     Object.keys(changeSet['changeSetDetail']['adjustmentData']['oldValue']).length > 0)) ? changeSet : null;
}
  constructChngSetToWHDetails(updated, initial, changeSet) {
    if (Object.keys(changeSet).length > 0) {
      const changesetNewValue = this.comparisonForArrayOfObj(updated?.discountSplits, initial?.discountSplits);
      const changesetOldValue = this.comparisonForArrayOfObj(initial?.discountSplits, updated?.discountSplits);
      if (!StringUtils.isUndefined(changesetNewValue) && !StringUtils.isUndefined(changeSet.changeSetDetail.adjustmentData['newValue']['abfRateActionAdjustment']))
        changeSet.changeSetDetail.adjustmentData['newValue']['abfRateActionAdjustment'][CommonConstants.DISCOUNT_SPLITS] = changesetNewValue
      if (!StringUtils.isUndefined(changesetOldValue) && !StringUtils.isUndefined(changeSet.changeSetDetail.adjustmentData['oldValue']['abfRateActionAdjustment']))
        changeSet.changeSetDetail.adjustmentData['oldValue']['abfRateActionAdjustment'][CommonConstants.DISCOUNT_SPLITS] = changesetOldValue
    }
  }
  constructChngSetTotRatAct(key, updated, intial, changeSet) {
    // for whsaving we are deleting the splits and renewalWHAPercent can be undefined.so removing undefined check here to create changeset.
    let checkEmptyString = key === 'renewalWHAPercent' ? true : (updated[key] !== undefined && updated[key] !== null && updated[key] !== '');
    if(checkEmptyString && intial[key] != updated[key]) {
      if(!changeSet['changeSetDetail'])
       changeSet['changeSetDetail'] = {};

      if(!changeSet['changeSetDetail']['adjustmentData'])
       changeSet['changeSetDetail']['adjustmentData'] = {};

      if(!changeSet['changeSetDetail']['adjustmentData']['newValue'])
       changeSet['changeSetDetail']['adjustmentData']['newValue'] = {};


       if(!changeSet['changeSetDetail']['adjustmentData']['oldValue']){
       changeSet['changeSetDetail']['adjustmentData']['oldValue'] = {};
       }

      if(!changeSet['changeSetDetail']['adjustmentData']['newValue']['abfRateActionAdjustment']) {
        changeSet['changeSetDetail']['adjustmentData']['newValue']={ 'abfRateActionAdjustment':{[key]: updated[key] }};
      } else {
        changeSet['changeSetDetail']['adjustmentData']['newValue']['abfRateActionAdjustment'] = {[key]: updated[key] }
      }

      if(!changeSet['changeSetDetail']['adjustmentData']['oldValue']['abfRateActionAdjustment']) {
        changeSet['changeSetDetail']['adjustmentData']['oldValue']={ 'abfRateActionAdjustment':{[key]: intial[key] }};
      } else {
        changeSet['changeSetDetail']['adjustmentData']['oldValue']['abfRateActionAdjustment'] = {[key]: intial[key] };
      }
    }
  }

  constructChngSetMewaQuoteAdj(key, updated, intial, changeSet) {
    // for whsaving we are deleting the splits and wholeHealthAdjustmentFactor can be undefined.so removing undefined check here to create changeset.
    // riskFactor and uwAdjustmentFactor will be undefined as well when deleted
    let checkEmptyString = (key === 'wholeHealthAdjustmentFactor' || key === 'currentRiskFactor' || key === 'riskFactor' || key === 'uwAdjustmentFactor') ? true : (updated[key] !== undefined && updated[key] !== null && updated[key] !== '');
    const normalizedInitial = (intial[key] === undefined || intial[key] === null) ? '' : intial[key];
    const normalizedUpdated = (updated[key] === undefined || updated[key] === null) ? '' : updated[key];
    if(checkEmptyString && normalizedInitial != normalizedUpdated) {
      if(!changeSet['changeSetDetail'])
       changeSet['changeSetDetail'] = {};

      if(!changeSet['changeSetDetail']['adjustmentData'])
       changeSet['changeSetDetail']['adjustmentData'] = {};

      if(!changeSet['changeSetDetail']['adjustmentData']['newValue'])
       changeSet['changeSetDetail']['adjustmentData']['newValue'] = {};


       if(!changeSet['changeSetDetail']['adjustmentData']['oldValue']){
       changeSet['changeSetDetail']['adjustmentData']['oldValue'] = {};
       }

      if(!changeSet['changeSetDetail']['adjustmentData']['newValue']['quoteAdjustments']) {
        changeSet['changeSetDetail']['adjustmentData']['newValue']['quoteAdjustments'] = {};
      }
      changeSet['changeSetDetail']['adjustmentData']['newValue']['quoteAdjustments'][key] = updated[key];

      if(!changeSet['changeSetDetail']['adjustmentData']['oldValue']['quoteAdjustments']) {
        changeSet['changeSetDetail']['adjustmentData']['oldValue']['quoteAdjustments'] = {};
      }
      changeSet['changeSetDetail']['adjustmentData']['oldValue']['quoteAdjustments'][key] = intial[key];
    }
  }
 
  constructChngSetToMewaWHDetails(updated, initial, changeSet) {
    if (Object.keys(changeSet).length > 0) {
      const changesetNewValue = this.comparisonForArrayOfObj(updated?.discountSplits, initial?.discountSplits);
      const changesetOldValue = this.comparisonForArrayOfObj(initial?.discountSplits, updated?.discountSplits);
      if (!StringUtils.isUndefined(changesetNewValue) && changesetNewValue.length > 0 && !StringUtils.isUndefined(changeSet.changeSetDetail.adjustmentData['newValue']['quoteAdjustments']))
        changeSet.changeSetDetail.adjustmentData['newValue']['quoteAdjustments'][CommonConstants.DISCOUNT_SPLITS] = changesetNewValue;
      if (!StringUtils.isUndefined(changesetOldValue) && changesetOldValue.length > 0 && !StringUtils.isUndefined(changeSet.changeSetDetail.adjustmentData['oldValue']['quoteAdjustments']))
        changeSet.changeSetDetail.adjustmentData['oldValue']['quoteAdjustments'][CommonConstants.DISCOUNT_SPLITS] = changesetOldValue;
    }
  }

}
