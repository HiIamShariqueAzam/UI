import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicareRatesComponent } from './medicare-rates.component';

describe('MedicareRatesComponent', () => {
  let component: MedicareRatesComponent;
  let fixture: ComponentFixture<MedicareRatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MedicareRatesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MedicareRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
