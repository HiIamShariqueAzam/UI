import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: '[app-medicare-rates]',
  templateUrl: './medicare-rates.component.html',
  styleUrls: ['./medicare-rates.component.css'],
  standalone: false
})
export class MedicareRatesComponent implements OnInit {
  @Input() rate: any;
  @Input() mewaKey: string;
  @Input() colSpanForMEWA: any;
  @Input() requestedTier: any;

  constructor() { }

  ngOnInit() {
  }



  getRatesLabelForMewa(key){
    return{
      'medicareTieredRates':'Medicare'
    }[key.value];
  }
}
