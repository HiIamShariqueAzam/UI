import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ValidationService } from 'src/app/shared/services/validation.service';
import moment from 'moment';
import { Lives, PeOverrideData, PeSheets } from 'src/app/shared/models/exhibitOverrides';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-exhibit-overrides',
  templateUrl: './exhibit-overrides.component.html',
  styleUrls: ['./exhibit-overrides.component.css'],
  standalone: false,
})
export class ExhibitOverridesComponent implements OnInit, OnChanges {

  @Input() quoteDetail: any;
  @Input() disableAll: boolean;
  @Input() tierChange: any;
  @Input() exhibitSheets: any;
  @Output() onError = new EventEmitter< any>();
  

  overridenData: any;
  peOverrideData: FormGroup<PeOverrideData>;
  lives: FormGroup<Lives>;
  peSheets : FormGroup<PeSheets>;
  requestedTier: number;
  contractStartDateIncurred: any;
  contractStartDate: any;
  contractEndDate: any;
  minDate: any;
  totalEligible: any;
  waivers: any;
  totalQuoted: any;
  livesData: any;
  availableSheets : any[];
  selectedproposalSheets : any;
  incomingSelectedSheets : any;
  multiselectEle: any;
  incomingExhibitSheets : any[];
  modifiedExhibitSheets : any[];
  isRenewal = false;

  constructor(private fb: FormBuilder, public datepipe: DatePipe, private confirmationService : ConfirmationService) {}

  ngOnInit() {
    this.peOverrideData = this.fb.group({
      quotedCount: ['', [Validators.required, ValidationService.numberValidator]],
      eligibleCount: ['', [Validators.required, ValidationService.numberValidator]],
      waiverCount: ['', [Validators.required, ValidationService.numberValidator]],
      contractEndDate: ['', [ValidationService.dateVaidator]],
      contractEffectiveDate: ['', [ValidationService.dateVaidator]],
      contractEffectiveDateIncurred: [''],
    }
    );
    this.lives = this.fb.group({
      eeCount: ['', [Validators.required, ValidationService.numberValidator]],
      esCount: ['', [Validators.required, ValidationService.numberValidator]],
      e1Count: ['', [Validators.required, ValidationService.numberValidator]],
      ecCount: ['', [Validators.required, ValidationService.numberValidator]],
      ekCount: ['', [Validators.required, ValidationService.numberValidator]],
      efCount: ['', [Validators.required, ValidationService.numberValidator]],
    });

    if (this.quoteDetail.quotingType === 'MEWA' || this.quoteDetail.quotingType === 'ACA') {
      this.lives.controls['eeCount'].removeValidators(Validators.required);
      this.lives.controls['esCount'].removeValidators(Validators.required);
      this.lives.controls['e1Count'].removeValidators(Validators.required);
      this.lives.controls['ecCount'].removeValidators(Validators.required);
      this.lives.controls['ekCount'].removeValidators(Validators.required);
      this.lives.controls['efCount'].removeValidators(Validators.required);
    }

    if (this.quoteDetail.quotingType === 'ACA') {
      this.peOverrideData.controls['quotedCount'].removeValidators(Validators.required);
      this.peOverrideData.controls['eligibleCount'].removeValidators(Validators.required);
      this.peOverrideData.controls['waiverCount'].removeValidators(Validators.required);
    }

    this.peSheets = this.fb.group({
      proposalSheets: ['',[Validators.required]]
    });

    this.setPeSheets();

    if (this.disableAll) {
      this.peOverrideData.disable();
      this.lives.disable();
      this.peSheets.disable();
    } else {
      this.peOverrideData.enable();
      this.lives.enable();
      this.peSheets.enable();
    }
    if (this.quoteDetail) {
      this.isRenewal = this.quoteDetail.opportunityType == 'Renewal Local';
      this.setPEoverrideControlValues();
    }

    this.peSheets.get("proposalSheets").valueChanges.subscribe(sheetCodes=> {​​​​​​​​
      this.quoteDetail.uwAdjustment.peOverrideData.sheetCodes = sheetCodes;
      this.onError.emit(this.peOverrideData.status === 'INVALID' || this.lives.status === 'INVALID' || this.peSheets.controls.proposalSheets.errors)
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.quoteDetail) {
      this.requestedTier = (this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.outputTier) || 1;
      this.initializePEOverrideValues();
      if (this.quoteDetail.uwAdjustment.peOverrideData) {
        this.quoteDetail.uwAdjustment.peOverrideData.lives = this.quoteDetail.uwAdjustment.userUpdatedLives[this.requestedTier + '-tier'];
        this.overridenData = (this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.peOverrideData) || {};
        if (this.peOverrideData) {
          this.setPEoverrideControlValues();
        }
      }
    }
  }


  initializePEOverrideValues() {
    if (this.quoteDetail) {
      if (!this.quoteDetail.uwAdjustment) {
        this.quoteDetail.uwAdjustment = {};
        this.quoteDetail.uwAdjustment.outputTier = this.quoteDetail.medicalOutputTier;
      }
      this.requestedTier = this.quoteDetail.uwAdjustment.outputTier;
      let tierKey = this.requestedTier + '-tier';

      if (!this.quoteDetail.uwAdjustment.peOverrideData ||
          !Object.keys(this.quoteDetail.uwAdjustment.peOverrideData).includes("contractEffectiveDate")) {
        let totalMedEmp = 0;
        let waivers = 0;
        let eligibleEmp = 0;
        if (this.quoteDetail.censusCalc &&
          this.quoteDetail.censusCalc.censusSubscriber &&
          this.quoteDetail.censusCalc.censusSubscriber.medEligibilityLivesMap) {
          totalMedEmp = this.quoteDetail.censusCalc.censusSubscriber.medEligibilityLivesMap.QuotedCount || 0;
          eligibleEmp = this.quoteDetail.censusCalc.censusSubscriber.medEligibilityLivesMap.EligibleCount || 0;
          waivers = this.quoteDetail.censusCalc.censusSubscriber.medEligibilityLivesMap.WaiverCount || 0;
        }
        if(!this.quoteDetail.uwAdjustment.peOverrideData || (this.quoteDetail.uwAdjustment.peOverrideData
          && !this.quoteDetail.uwAdjustment.peOverrideData.lives && !this.quoteDetail.uwAdjustment.peOverrideData.printExhibitEligibility)){
        this.quoteDetail.uwAdjustment.peOverrideData = {};
          }
        this.quoteDetail.uwAdjustment.peOverrideData['contractEffectiveDate'] = this.quoteDetail.contractEffectiveDate;
        this.quoteDetail.uwAdjustment.peOverrideData['contractEndDate'] = this.quoteDetail.contractEndDate;
        this.quoteDetail.uwAdjustment.peOverrideData['contractEffectiveDateIncurred'] = this.quoteDetail.contractEffectiveDateIncurred;
        this.quoteDetail.uwAdjustment.peOverrideData['quotedCount'] = totalMedEmp;
        this.quoteDetail.uwAdjustment.peOverrideData['eligibleCount'] = eligibleEmp;
        this.quoteDetail.uwAdjustment.peOverrideData['waiverCount'] = waivers;
      }

      if (!this.quoteDetail.uwAdjustment.userUpdatedLives) {
        this.quoteDetail.uwAdjustment.userUpdatedLives = JSON.parse(JSON.stringify(this.quoteDetail.factors.calculatedTierLives ?? {}));
        if (this.quoteDetail.uwAdjustment.peOverrideData.lives) {
          this.quoteDetail.uwAdjustment.userUpdatedLives[tierKey] = this.quoteDetail.uwAdjustment.peOverrideData.lives;
        }
      }
    }
  }

  clickedConEffDate() {
    let element: HTMLElement = document.querySelectorAll(".conEffectivedates .p-inputtext")[0] as HTMLElement;
    element.click();
  }

  clickedConEffDateIncurred() {
    let element: HTMLElement = document.querySelectorAll(".conEffectivedate .p-inputtext")[0] as HTMLElement;
    element.click();
  }

  clickedConEndDate() {
    let element: HTMLElement = document.querySelectorAll(".clickedConEndDate .p-inputtext")[0] as HTMLElement;
    element.click();
  }

  setPEoverrideControlValues() {
    if (this.overridenData) {
      if (this.overridenData.contractEffectiveDateIncurred) {
        let EffDateIncurred = new Date(this.overridenData.contractEffectiveDateIncurred);
        this.contractStartDateIncurred = new Date(EffDateIncurred.getUTCFullYear(), EffDateIncurred.getUTCMonth(), EffDateIncurred.getUTCDate());
      }
      if (this.overridenData.contractEffectiveDate) {
        let startDate = new Date(this.overridenData.contractEffectiveDate);
        this.contractStartDate = new Date(startDate.getUTCFullYear(), startDate.getUTCMonth(), startDate.getUTCDate());
      }
      if (this.overridenData.contractEndDate) {
        let endDate = new Date(this.overridenData.contractEndDate);
        this.contractEndDate = new Date(endDate.getUTCFullYear(), endDate.getUTCMonth(), endDate.getUTCDate());
      }
      this.totalQuoted = this.overridenData.quotedCount;
      this.totalEligible = this.overridenData.eligibleCount;
      this.waivers = this.overridenData.waiverCount;
      this.minDate = this.contractStartDate;
    }
    this.setControlValues();
    this.setLiveCounts();
  }

  setControlValues() {
    this.peOverrideData.controls.quotedCount.setValue(this.totalQuoted);
    this.peOverrideData.controls.eligibleCount.setValue(this.totalEligible);
    this.peOverrideData.controls.waiverCount.setValue(this.waivers);
    if (this.contractStartDateIncurred)
      this.peOverrideData.controls.contractEffectiveDateIncurred.setValue(this.transformDate(this.contractStartDateIncurred));
    if (this.contractStartDate)
      this.peOverrideData.controls.contractEffectiveDate.setValue(this.transformDate(this.contractStartDate));
    if (this.contractEndDate)
      this.peOverrideData.controls.contractEndDate.setValue(this.transformDate(this.contractEndDate));
  }

  setLiveCounts() {
    if (this.overridenData) {
      let livesData = { ...this.overridenData.lives };
      if (livesData) {
        if (livesData.eeCount || livesData.eeCount == 0)
          this.lives.controls.eeCount.setValue(livesData.eeCount);
        if (livesData.efCount || livesData.efCount == 0)
          this.lives.controls.efCount.setValue(livesData.efCount);
        if (livesData.e1Count || livesData.e1Count == 0)
          this.lives.controls.e1Count.setValue(livesData.e1Count);
        if (livesData.esCount || livesData.esCount == 0)
          this.lives.controls.esCount.setValue(livesData.esCount);
        if (livesData.ecCount || livesData.ecCount == 0)
          this.lives.controls.ecCount.setValue(livesData.ecCount);
        if (livesData.ekCount || livesData.ekCount == 0)
          this.lives.controls.ekCount.setValue(livesData.ekCount);

      }
    }
  }

  setPeSheets(){
    if(this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.peOverrideData &&
      this.quoteDetail.uwAdjustment.peOverrideData.printExhibitEligibility){
        this.setIncludeExcludeSheets(this.quoteDetail.uwAdjustment.peOverrideData.printExhibitEligibility);
    }else if(this.exhibitSheets){
      this.setIncludeExcludeSheets(this.exhibitSheets);
    }
  }

  setIncludeExcludeSheets(peSheets : any){
    let includeSheets = [];
    let allSheets = [];
    if (this.quoteDetail.opportunityType == CommonConstants.RENEWAL_LOCAL && (this.quoteDetail?.oppOrigin?.['Market Segment'] || this.quoteDetail?.oppOrigin?.['Fundingtype'])) {
      peSheets = peSheets.filter((sheet) => sheet.printExhibitSheetName !== 'Renewal Rate' && sheet.printExhibitSheetName !== 'Renewal Summary')
    }

    peSheets.forEach((val) => {
      allSheets.push({"label": val.printExhibitSheetName, "value": val.printExhibitTypeCode});
      if(val.sheetStatus === "Include"){
        includeSheets.push(val.printExhibitTypeCode);
      }
    });
    this.incomingExhibitSheets = JSON.parse(JSON.stringify(peSheets));
    this.modifiedExhibitSheets = JSON.parse(JSON.stringify(peSheets));
    this.selectedproposalSheets = includeSheets;
    this.incomingSelectedSheets = includeSheets;
    this.availableSheets = allSheets;
    if(this.quoteDetail.uwAdjustment.peOverrideData.sheetCodes){
      this.selectedproposalSheets = this.quoteDetail.uwAdjustment.peOverrideData.sheetCodes;
    }
  }

  isNumber(event) {
    return !(event.charCode > 31 && (event.charCode < 48 || event.charCode > 57));
  }

  transformDate(dateValue) {
    return this.datepipe.transform(dateValue, "yyyy-MM-dd");
  }

  updateContractEffDateIncurred(e) {
    this.contractStartDateIncurred = new Date(e);
    const formattedDate = this.transformDate(this.contractStartDateIncurred);
    this.peOverrideData.controls.contractEffectiveDateIncurred.setValue(formattedDate);
    // Update backend data object so it is saved
    if (this.quoteDetail && this.quoteDetail.uwAdjustment && this.quoteDetail.uwAdjustment.peOverrideData) {
      this.quoteDetail.uwAdjustment.peOverrideData.contractEffectiveDateIncurred = formattedDate;
    }
    this.reflectChanges();
  }

  updateContractEndDate(e) {
    this.contractEndDate = new Date(e);
    this.peOverrideData.controls.contractEndDate.setValue(this.transformDate(this.contractEndDate));
    this.reflectChanges();
  }

  async updateContractEffDate(newValue, prevValue) {
    const originalYear = moment(this.quoteDetail.contractEffectiveDate).year();
    const newYear = moment(newValue).year();
    let showModal = false;
    let confirmed = true;
    if (newYear > originalYear) {
      showModal = true;
    }
    if (showModal) {
      confirmed = await new Promise((resolve) => {
        this.confirmationService.confirm({
          message: `Selected date range falls in next benefit year. The plans and benefits from the quote are for current benefit year only.
            Do you still want to continue ?`,
          header: 'Warning!',
          acceptButtonStyleClass: 'dialog-button-icon',
          rejectButtonStyleClass: 'dialog-button-icon',
          accept: () => {
            resolve(true);
          },
          reject: () => {
            resolve(false);
          }
        });
      });
    }

    if(!confirmed) {
      this.contractStartDate = new Date(prevValue);
      return;
    }
    
    this.contractStartDate = new Date(newValue);
    this.peOverrideData.controls.contractEffectiveDate.setValue(this.transformDate(this.contractStartDate));
    var endDate: any;
    var year = this.contractStartDate.getFullYear();
    var month = this.contractStartDate.getMonth();
    var date = this.contractStartDate.getDate();
    endDate = new Date(year + 1, month, date - 1);
    this.contractEndDate = endDate;
    this.peOverrideData.controls.contractEndDate.setValue(this.transformDate(this.contractEndDate));
    this.minDate = this.contractStartDate;
    this.reflectChanges();
  }

  editContractEffDateIncurred(e) {
    if (moment(e.target.value, 'MM-DD-YYYY', true).isValid())
      this.peOverrideData.controls.contractEffectiveDateIncurred.setValue(this.transformDate(e.target.value));
    else {
      this.peOverrideData.controls.contractEffectiveDateIncurred.setValue(null);
      this.contractStartDateIncurred = null;
    }
  }

  editContractEffDate(e) {
    if (moment(e.target.value, 'MM-DD-YYYY', true).isValid())
      this.peOverrideData.controls.contractEffectiveDate.setValue(this.transformDate(e.target.value));
    else {
      this.peOverrideData.controls.contractEffectiveDate.setValue(null);
      this.contractStartDate = null;
    }
  }

  editContractEndDate(e) {
    if (moment(e.target.value, 'MM-DD-YYYY', true).isValid())
      this.peOverrideData.controls.contractEndDate.setValue(this.transformDate(e.target.value));
    else {
      this.peOverrideData.controls.contractEndDate.setValue(null);
      this.contractEndDate = null
    }
  }

  updateCount($event, forType: string) {
    let value = ($event.target.value || $event.target.value === "0") ? $event.target.value : "";
    if (forType === 'TQS')
      this.peOverrideData.controls.quotedCount.setValue(value);
    else if (forType === 'TEE')
      this.peOverrideData.controls.eligibleCount.setValue(value);
    else if (forType === 'W')
      this.peOverrideData.controls.waiverCount.setValue(value);
    else if (forType === 'EE')
      this.lives.controls.eeCount.setValue(value);
    else if (forType === 'EF')
      this.lives.controls.efCount.setValue(value);
    else if (forType === 'ES')
      this.lives.controls.esCount.setValue(value);
    else if (forType === 'EK')
      this.lives.controls.ekCount.setValue(value);
    else if (forType === 'EC')
      this.lives.controls.ecCount.setValue(value);
    else if (forType === 'E1')
      this.lives.controls.e1Count.setValue(value);
    this.reflectChanges();
  }

  reflectChanges() {
    if (this.overridenData) {
      let tierKey = this.requestedTier + '-tier';
      let peValues = this.peOverrideData.value;
      let livesValues = this.lives.value;
      Object.keys(peValues).forEach(key => {
        this.overridenData[key] = peValues[key];
      });
      Object.keys(livesValues).forEach(key => {
        this.overridenData.lives[key] = livesValues[key];
      });
      Object.keys(this.overridenData).forEach(key => {
        this.quoteDetail.uwAdjustment.peOverrideData[key] = this.overridenData[key];
      });
      this.quoteDetail.uwAdjustment.userUpdatedLives[tierKey] = this.overridenData.lives;
    }
    this.onError.emit(this.peOverrideData.status === 'INVALID' || this.lives.status === 'INVALID' || this.peSheets.controls.proposalSheets.errors)
  }

}
