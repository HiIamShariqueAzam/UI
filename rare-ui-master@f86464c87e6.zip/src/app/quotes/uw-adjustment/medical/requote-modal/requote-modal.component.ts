import { DatePipe, formatCurrency, formatPercent, getCurrencySymbol } from '@angular/common';
import { AfterViewInit, Component, ElementRef, EventEmitter, Inject, Input, LOCALE_ID, OnInit, Output, SimpleChanges, ViewChild } from "@angular/core";
import { NgbModal, NgbModalConfig } from "@ng-bootstrap/ng-bootstrap";
import moment from 'moment';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { CommonService } from 'src/app/shared/services';
import { CommonUtil } from "src/app/shared/utils/common-util";
import { UnderwriterAdjustmentService } from '../uw-adjustment.service';

enum riskScoreTypeVal {
  SIMILAR = "Similar",
  NEW = "New"
}
@Component({
  selector: "app-requote-modal",
  templateUrl: "./requote-modal.component.html",
  styleUrls: ["./requote-modal.component.css"],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class RequoteModalComponent implements OnInit, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() quoteDetail: any;
  @Input() defaultValues: any;
  @Output() requote = new EventEmitter<any>();
  @Output() close = new EventEmitter<any>();

  factorEffectiveDate: any;
  censusRefId: String;
  errFundingFactor: any;
  hasErrFundingFactor: boolean = false;
  isDemographicOpted: boolean = false;
  isClaimDataOpted: boolean = false;
  riskScoreVersionOpted: String;
  isERfundValid: boolean = true;
  showABFSLValues: boolean = false;
  oldQuoteDetail: any = {};

  sslDeductibleList: any[];
  sslContractBasisList: any[];
  aggSLCorridorList: any[];
  surplusRefundList: any[];

  sslDeductible: any = {};
  sslContractBasis: any = {};
  aggSLCorridor: any = {};
  surplusRefund: any = {};
  isRenewal: boolean = false;
  ristirictArrowCall: boolean = true;
  commissionValue: any;
  existingCommissionType: String;
  selectedCommissionType: String;
  isCommValValid: boolean = true;
  acaOrMewaQuote: boolean = false;

  commissionTypesList: any[] = [];
  riskScoreTypeList: any[] = [];
  selectedRiskScoreType: string = riskScoreTypeVal.SIMILAR;
  arrowCallRestrictionMap = this.commonService.getArrowCallRestrictionMap();

  constructor(config: NgbModalConfig,
    private modalService: NgbModal,
    public datepipe: DatePipe,
    @Inject(LOCALE_ID) private locale: string, 
    private commonService: CommonService,
    private uwAdjService: UnderwriterAdjustmentService
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  ngOnChanges(changes: SimpleChanges) {
    if ((changes.quoteDetail && !changes.quoteDetail.firstChange)) {
      this.ngOnInit();
      this.setupABFInitialValues();
    }
    else if(changes.defaultValues && !changes.defaultValues.firstChange) {
      this.setupABFInitialValues();
    }
  }
  ngOnInit() {
    if (this.quoteDetail) {
      this.showABFSLValues = this.quoteDetail.fundingType != 'FI';
      this.setupABFInitialValues();
      this.setIsRenewal();
      this.setRistirictArrowCall();
      this.factorEffectiveDate = this.datepipe.transform(this.quoteDetail.factorEffectiveDate, "MM-dd-yyyy");
      this.censusRefId = this.quoteDetail.censusRefId;
      this.acaOrMewaQuote = this.quoteDetail.medical && [CommonConstants.MEWA, CommonConstants.ACA].includes(this.quoteDetail.quotingType) ? true : false;
      if (this.quoteDetail.medical && (this.quoteDetail.medical.employerFundingLevel || this.quoteDetail.medical.employerFundingLevel === 0)) {
        this.hasErrFundingFactor = true;
        this.errFundingFactor = parseFloat((this.quoteDetail.medical.employerFundingLevel * 100).toFixed(1));
      } else if (this.defaultValues['ER_FUNDING_LEVEL'] && (this.defaultValues['ER_FUNDING_LEVEL'].dfltPct || this.defaultValues['ER_FUNDING_LEVEL'].dfltPct === 0)) {
        this.hasErrFundingFactor = true;
        this.errFundingFactor = parseFloat((this.defaultValues['ER_FUNDING_LEVEL'].dfltPct * 100).toFixed(1));
      }
      if (this.quoteDetail.medical && this.quoteDetail.medical?.proposedPlans?.length) {
        this.existingCommissionType = this.quoteDetail.medical.proposedPlans[0]['commissionType'];
        if (this.existingCommissionType.toLowerCase() !== 'percent') {
          this.commissionValue = parseFloat(this.quoteDetail.medical.proposedPlans[0]['commissionValue']).toFixed(2);
        } else {
          this.commissionValue = this.quoteDetail.medical.proposedPlans[0]['commissionValue'];
        }
      }
    }

    this.commissionTypesList = [
      { label: 'Percent', value: 'Percent' },
      { label: 'PCPM', value: 'PCPM' },
      { label: 'PMPM', value: 'PMPM' },
      { label: 'Flat Dollar', value: 'Flat Dollar' }
    ];
    this.riskScoreTypeList = [
      { label: 'Similar Score', value: riskScoreTypeVal.SIMILAR },
      { label: 'New Score', value: riskScoreTypeVal.NEW },
    ]
  }

  setIsRenewal() {
    this.isRenewal = (this.quoteDetail.medical && this.quoteDetail.medical.experienceClaimsAvailable === "Yes"
      && this.quoteDetail.opportunityType === "Renewal Local");
  }

  setRistirictArrowCall() {
    if(this.quoteDetail && this.quoteDetail.opportunityType === "New Business Local") {
      const fundingType = this.quoteDetail.fundingType;
      const lobRestrictions = this.arrowCallRestrictionMap["New Business Local"]?.[fundingType];
      const isEnabled = lobRestrictions?.includes("ALL") || lobRestrictions?.includes(this.quoteDetail.derivedState);
      this.ristirictArrowCall = !isEnabled;
    }
  }

  setupABFInitialValues() {
    ({
      surplusRefundList : this.surplusRefundList ,
      aggSLCorridorList: this.aggSLCorridorList,
      sslContractBasisList: this.sslContractBasisList,
      sslDeductibleList: this.sslDeductibleList,
      surplusRefund: this.surplusRefund,
      aggSLCorridor: this.aggSLCorridor,
      sslContractBasis: this.sslContractBasis,
      sslDeductible: this.sslDeductible
    }
     = this.uwAdjService.setupReQuoteABFInitialValues(this.showABFSLValues, this.defaultValues , 
      this.quoteDetail.medical?.stopLossCovg ?? null
     ));
  }

  onchangeCommValue(event) {
    if (this.selectedCommissionType && this.selectedCommissionType.toLowerCase() === 'percent') {
      this.isCommValValid = !(this.commissionValue < 0 || this.commissionValue > 100 || this.commissionValue === '');
    } else {
      let pattern = /^[0-9]+(\.[0-9]{1,2})?$/g;
      this.isCommValValid = (this.commissionValue.match(pattern) !== null);
    }
  }

  commissionValMsg() {
    if (!this.isCommValValid) {
      if (this.commissionValue.split('.').length > 1) {
        return this.commissionValue.split('.')[1].length > 0 ? 'Value should be upto 2 decimal place' : 'Invalid value';
      } else {
        return 'Please enter comm value';
      }
    } else {
      return '';
    }
  }

  onchangeErr(event) {
    this.errFundingFactor = event.target.value;
    this.isERfundValid = !(this.errFundingFactor < 0 || this.errFundingFactor > 100 || this.errFundingFactor === '');
  }

  clickedEffDate() {
    let element: HTMLElement = document.querySelectorAll(".effectivedate .p-inputtext")[0] as HTMLElement;
    element.click();
  }

  updateFactorAsOfDate(e: any) {
    this.factorEffectiveDate = new Date(e);
  }

  validateFactorsDate(value: any) {
    if (moment(value.target.value, 'MM-DD-YYYY', true).isValid()) {
      this.factorEffectiveDate = new Date(value.target.value);
    } else {
      this.factorEffectiveDate = undefined;
    }
  }

  isNumber(event) {
    return !(event.charCode > 31 && (event.charCode < 48 || event.charCode > 57));
  }

  isNumberOrDecimal(event) {
    if (event.target.value.split('.').length > 1 && event.charCode === 46) {
      return false;
    }
    return !(event.charCode > 31 && ((event.charCode < 48 && event.charCode !== 46) || event.charCode > 57));
  }

  isValidCommissionValue(event) {
    //Only allow a number with max 2 decimal places for commissionValue
    return CommonUtil.isNumberWithGivenDecimalPlaces(event, 2);
  }

  onReQuote() {
    let abfValues = {};
    if (this.showABFSLValues) {
      abfValues['stopLossCovg'] = {};
      abfValues['stopLossCovg']['sslDeductible'] = this.sslDeductible.value;
      abfValues['stopLossCovg']['sslContractBasis'] = this.sslContractBasis.value;
      abfValues['stopLossCovg']['surplusRefund'] = this.surplusRefund.value;
      abfValues['stopLossCovg']['aggSLCorridor'] = this.aggSLCorridor.value;
    }

    let riskScoreVersionOpted = (this.isDemographicOpted || this.isClaimDataOpted) ? (this.isDemographicOpted ? "1" : "3") : "NOT REQUESTED"

    let riskScoreType = riskScoreVersionOpted === "3" ? this.selectedRiskScoreType : (riskScoreVersionOpted === "1" ? riskScoreTypeVal.NEW : null);
    this.requote.emit({
      factorEffectiveDate: this.factorEffectiveDate,
      riskScoreVersionOpted,
      riskScoreType,
      errFundingFactor: this.errFundingFactor,
      commissionValue: this.commissionValue,
      selectedCommissionType: this.selectedCommissionType ? this.selectedCommissionType : this.existingCommissionType,
      ...abfValues
    });
    this.close.emit();
  }

  onClose() {
    this.close.emit();
  }

  validateRequoteFields(valid: boolean) {
    if (this.showABFSLValues)
      return valid ? ((this.isERfundValid && this.isCommValValid && (Object.keys(this.sslDeductible).length > 0) &&
        (Object.keys(this.sslContractBasis).length > 0) && (Object.keys(this.aggSLCorridor).length > 0) &&
        (Object.keys(this.surplusRefund).length > 0) && this.factorEffectiveDate != undefined)) :
        ((!this.isERfundValid || !this.isCommValValid || (Object.keys(this.sslDeductible).length < 1) || (Object.keys(this.sslContractBasis).length < 1) || (Object.keys(this.aggSLCorridor).length < 1) || (Object.keys(this.surplusRefund).length < 1) || this.factorEffectiveDate == undefined));
    else
      return valid ? ((this.isERfundValid && this.isCommValValid && this.factorEffectiveDate != undefined)) :
        ((!this.isERfundValid || !this.isCommValValid || this.factorEffectiveDate == undefined));
  }

  getColumnClass() {
    if (this.hasErrFundingFactor && this.censusRefId !== null && !this.isRenewal && this.existingCommissionType) {
      return 'col-3';
    } else {
      return 'col-3'
    }
  }

  get3xRiskScoreTooltipTxt() {
    return (!this.quoteDetail?.riskScore3XEnabled) ? '3.x risk score not allowed by ARROW' : '';
  }

  getRiskScor3xColClass() {
    return (this.hasErrFundingFactor && this.quoteDetail?.riskScore3XEnabled && this.censusRefId !== null && !this.isRenewal) ? 'col-3' : this.getColumnClass();
  }
}
