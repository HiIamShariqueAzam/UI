import { Component, Input, Output, EventEmitter } from "@angular/core";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonService, PrintExhibitService } from "src/app/shared/services";

@Component({
  selector: "app-print-exhibits",
  templateUrl: "./print-exhibits.component.html",
  styleUrls: ["./print-exhibits.component.css"],
  standalone: false,
})
export class PrintExhibitsComponent {
  @Input() documents: any[];
  @Input() isRenewal: boolean = false;
  @Input() alternateQuote: boolean;
  @Input() isMEWARenOGQuote: boolean = false;
  @Output() errorAction = new EventEmitter<any>();

  constructor(
    private commonService: CommonService,
    private peService: PrintExhibitService, private commonQuoteService: CommonQuoteService
  ) {}

  isReleased(status){
    if (status===true) {
      return "releaseStyle";
    } else { return false; }
  }

  downloadPrintExhibitsFile(contentKey) {
    if (contentKey != null && contentKey != "") {
      contentKey = contentKey.replace("{", "%7B");
      contentKey = contentKey.replace("}", "%7D");
    }
    this.commonQuoteService.getFileFromFilenet(contentKey).subscribe(
      response => {
        if (response && response.contentData && response.contentName) {
          let contentData = response.contentData;
          let contentName = response.contentName;
          sessionStorage.setItem("printExhibitExcelName", contentName);
          const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, contentName);
        } else {
          this.errorAction.emit("Error while downloading print exhibit");
        }
      },
      error => {
        this.errorAction.emit("Error while downloading print exhibit");
      }
    );
  }
}
