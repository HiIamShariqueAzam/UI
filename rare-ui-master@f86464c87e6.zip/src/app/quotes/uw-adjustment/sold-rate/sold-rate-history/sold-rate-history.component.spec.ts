import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { SoldRateHistoryComponent } from './sold-rate-history.component';

describe('SoldRateHistoryComponent', () => {
  let component: SoldRateHistoryComponent;
  let fixture: ComponentFixture<SoldRateHistoryComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SoldRateHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoldRateHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
