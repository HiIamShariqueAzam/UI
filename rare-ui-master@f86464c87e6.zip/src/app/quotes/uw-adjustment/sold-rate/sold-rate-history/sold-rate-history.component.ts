import { StringUtils } from 'src/app/shared/utils/string-utils';
import { Component, OnInit, Input, OnChanges, Inject, LOCALE_ID } from "@angular/core";
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: 'app-sold-rate-history',
  templateUrl: './sold-rate-history.component.html',
  standalone: false,
})
export class SoldRateHistoryComponent implements OnInit {

  @Input() historyData: any;
  @Input() responseDataHistory: any;
  @Input() cols: any;
  checked;
  selectedRate: any;

  constructor(@Inject(LOCALE_ID) private locale: string) { }

  ngOnInit() {
  }

  onRowSelect(event) {
  }

  getFactor(lob, category, index) {
    if (lob.toLowerCase() === 'medical' && this.responseDataHistory[index].employmentCategoryMedical) {
      for (let medFactor of this.responseDataHistory[index].employmentCategoryMedical) {
        if (medFactor.emplymntCtgryCd.toLowerCase() === category.toLowerCase())
          return medFactor.emplymntCtgryFctr;
      }
    }
    if (lob.toLowerCase() === 'vision' && this.responseDataHistory[index].employmentCategoryVision) {
      for (let visFactor of this.responseDataHistory[index].employmentCategoryVision) {
        if (visFactor.emplymntCtgryCd.toLowerCase() === category.toLowerCase())
          return visFactor.emplymntCtgryFctr;
      }
    }
    if (lob.toLowerCase() === 'dental' && this.responseDataHistory[index].employmentCategoryDental) {
      for (let denFactor of this.responseDataHistory[index].employmentCategoryDental) {
        if (denFactor.emplymntCtgryCd.toLowerCase() === category.toLowerCase())
          return denFactor.emplymntCtgryFctr;
      }
    }
    
  }

  stringConversion(value) {
    return StringUtils.convertToString(value);
  }
  getEnrollments(rowdata, field, empCat) {
    if (StringUtils.isEqual(field ,'eeRateEnrollment'))
      return empCat?.enrollments?.ee ? empCat.enrollments.ee : 0;
    if (StringUtils.isEqual(field ,'ekRateEnrollment'))
      return empCat?.enrollments?.ek ? empCat.enrollments.ek : 0;
    if (StringUtils.isEqual(field ,'efRateEnrollment'))
      return empCat?.enrollments?.ef ? empCat.enrollments.ef : 0;
    if (StringUtils.isEqual(field , 'ecRateEnrollment'))
      return empCat?.enrollments?.ec ? empCat.enrollments.ec : 0;
    if (StringUtils.isEqual(field ,'esRateEnrollment'))
      return empCat?.enrollments?.es ? empCat.enrollments.es : 0;
  }

  rateSplitsExpand(historyData) {
    historyData.expanded = !historyData.expanded;
  }

  isRateSplitsAvailable(historyData, index) {
    if (historyData.lob === 'Medical' && historyData?.employmentCategory?.[index]?.rateSplits?.length) {
      return true
    }
    else {
      return false
    }
  }
  getIncludedRatesText(ratesIncluded, fundingType) {
    if (StringUtils.isEqualIgnoreCase(fundingType, 'ABF') && (StringUtils.isEqualIgnoreCase(ratesIncluded.toString(), "yes") || ratesIncluded === true)) {
      return CommonConstants.ADDITIONAL_PROGRAM_ADDED_TO_ADMIN;
    }
    if (StringUtils.isEqualIgnoreCase(fundingType, 'FI') && (StringUtils.isEqualIgnoreCase(ratesIncluded.toString(), "yes") || ratesIncluded === true)) {
      return CommonConstants.ADDITIONAL_PROGRAM_ADDED_TO_TOTAL;
    }
    return CommonConstants.ADDITIONAL_PROGRAM_EMBEDDED;
  }

  getSoldRateColumnClass(column){
    return `header-${column}`
  }
}
