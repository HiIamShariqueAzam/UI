import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthenticationService, CommonService, PrintExhibitService } from 'src/app/shared/services';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe, DecimalPipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SoldRatesForm } from 'src/app/shared/models/soldRate';
import { RareConstants } from 'src/app/shared/models/rareConstants';
import { SoldRateService } from './services/sold-rate.service';
import { CommonQuoteService } from '../../services/common-quote.service';
import { ReportsService } from 'src/app/report-generate-management/services/reports.service';
import { MultiSelect } from 'primeng/multiselect';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { DateFormatPipe } from 'src/app/shared/pipes/date-format-pipe';
import { NumberUtils } from 'src/app/shared/utils/number-utils';
import { SoldConstants } from './sold-constants';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

export class RateInfo {
  'eeRate': number;
  'esRate': number;
  'efRate': number;
  'ecRate': number;
  'ekRate': number;
}
@Component({
  selector: 'app-sold-rate',
  templateUrl: './sold-rate.component.html',
  styleUrls: ['./sold-rate.component.css'],
  standalone: false
})
export class SoldRateComponent implements OnInit {
  quotes: any;
  cols: any[];
  rowData: any[];
  rowDataHistory: any[];
  selectedRate: any;
  categoryList: any[] = [];
  flagCategoryChanged;
  soldRateFullResponse;
  map;
  ratingTransID;
  opportunityID;
  quoteHeaderID;
  lob;
  groupName;
  contractEffDate: any;
  responseData;
  checked;
  responseDataHistory;
  displayDialog: boolean;
  empCategory: any[] = [];
  empCategoryHistory: any[] = [];
  nonEmpCategory: any[] = [];
  planName: any[] = [];
  planTypes: any[] = [];
  fundingTypes: any[] = [];
  contractCodes: any[] = [];
  currentContractCodes: any[] = [];
  lobValues: string[] = [];
  formData;
  fundingType;
  empCategoryData;
  empCategoryFactor;
  planNamesBackup;
  contractCodeBackup;
  CCValue: any = "";
  CCCValue: any = "";
  errorValue;
  additionalProgramErrorValue;
  successMessage: any;
  failureMessage: any;
  alertData: any;
  lob_FT: any[];
  isLoading: boolean = true;
  div_visible: boolean = false;
  enablePrintOnSold: boolean = false;
  showSaveAlert: boolean = false;
  showSubmitAlert: boolean = false;
  showErrorAlert: boolean = false;
  disableSubmit: boolean = true;
  onSubmitFlag = false;
  onChangeLob: boolean = true;
  quoteOrigin: string;

  empCatValue;
  lobValue;
  soldRates_form: FormGroup<SoldRatesForm>;
  historyData: any[] = [];
  selectedRatingPlanID: string;
  selectedRatingPlanIDs: string[];
  selectedPlan;
  selectedProducts: any[];
  selectedContractCodes: any[];
  selectedContractCode;
  selectedCurrentContractCode;
  selectedLOB: string = '';
  classCode;
  caseNumber;
  caseNumberUpdate;
  selectedPlanType: string = '';
  selectedFundingType: string = '';
  employmentCategory: any[] = [];
  selectedEmpCategory;
  planValue: any = "";
  selectedRowsToRemove: any[] = [];
  dubEmpCats: string = '';
  selectedSoldRatePlan: any = [];
  action: any = 'save';
  contractCodeRemove: any;
  isReadOnlyRole: boolean = false;
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  isRenewalLocal: boolean = false;
  submitOptions = [];
  selectedSubmitValue: string[] = [];
  lobAdded = new Map<string, string>();
  medActiveRemoved = new Map<string, boolean>();
  visActiveRemoved = new Map<string, boolean>();
  denActiveRemoved = new Map<string, boolean>();
  shpActiveRemoved = new Map<string, boolean>();
  mapOfContractCodeAndAdditionalProgram = new Map<String, Object[]>();
  programValues: string[] = [];
  PMPM: number;
  Desc: string;
  selectedRateType: string;
  rateTypesAdditional: any[] = [];
  isEdit: boolean = false;
  addRateInfo: any
  planTypesAdditional: any[] = [];
  selectedProgramType: string = '';
  descriptionReason: string = '';
  selectedPlanTypeAdditional;
  isIncludeInRates: boolean = false;
  includeInRates: string;
  state: string = "";
  factorEffectiveDate: string
  quoteEffectiveDate: string
  displayProgramDialog: boolean = false;
  rateInfo: { key: string, value: string }[] = [
    { key: 'Employee', value: 'eeRate' },
    { key: 'Employee+Spouse', value: 'esRate' },
    { key: 'Employee+Child', value: 'ekRate' },
    { key: 'Employee+Children', value: 'ecRate' },
    { key: 'Employee+Family', value: 'efRate' }
  ]
  soldRateFullResponseModified;
  showAdditionalProgramsPopUp: boolean = false;
  selectedAdditionalProgramEmpCategory: any[] = [];
  additionalProgramEmpCategoryList: any[] = [];
  mapOfContractCodeAndSelectedEmpCategories = new Map<String, String[]>();
  isCurrentPlanMapped: boolean = false;
  selectedRatingPlanIdUpdate: string;
  isCaseNoSaved: boolean = false;
  savedCaseNumber = '' ;
  isEnrollmentMismatch :boolean = false;
  currentPlansArray = [];

  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  constructor(
    private dateFormatPipe: DateFormatPipe,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private _decimalPipe: DecimalPipe,
    public datepipe: DatePipe,
    private authService: AuthenticationService,
    private soldRateService: SoldRateService,
    private commonService: CommonService,
    private peService: PrintExhibitService,
    private commonQuoteService: CommonQuoteService,
    private reportsService: ReportsService) {
  }

  onNavigateTab(data: string) {
    let tabData = data.split("-");
    if (tabData[0] === RareConstants.medical) {
      this.lob = tabData[0];
      this.fundingType = this.commonService.getFundingTypeforTab(tabData[0], tabData[1]);
      this.backToMedical(tabData);
    }
    if (tabData[0] === RareConstants.vision) {
      this.lob = tabData[0];
      this.fundingType = tabData[1];
      this.backToVision();
    }
    if (tabData[0] === RareConstants.dental) {
      this.lob = tabData[0];
      this.fundingType = tabData[1];
      this.backToDental();
    }
    if (StringUtils.isEqualIgnoreCase(tabData[0], CommonConstants.SuppHealth)) {
      this.lob = tabData[0];
      this.fundingType = tabData[1];
      this.backToSuppHealth();
    }
  }
  backToMedical(tabData) {
    this.router.navigate(['quote/uw-rate'], {
      queryParams: {
        ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]), opportunityID: this.opportunityID,quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1])
        ,quoteHeaderID: this.quoteHeaderID, lob: this.lob, groupName: this.groupName, fundingType: this.fundingType, availableTabs: this.lob_FT
      }
    });
  }
  backToVision() {
    if (this.commonService.isVisionEnabled == 'true') {
      this.router.navigate(['quote/uw-rate-vision'], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(this.lob, this.fundingType), opportunityID: this.opportunityID,quoteOrigin: this.quoteOrigin,
          quoteHeaderID: this.quoteHeaderID, lob: this.lob, groupName: this.groupName, fundingType: this.fundingType, availableTabs: this.lob_FT
        }
      });
    }
  }
  backToDental() {
    this.router.navigate(['quote/uw-rate-dental'], {
      queryParams: {
        ratingTransID: this.commonService.getTransIDforTab(this.lob, this.fundingType), opportunityID: this.opportunityID,quoteOrigin: this.quoteOrigin,
        quoteHeaderID: this.quoteHeaderID, lob: this.lob, groupName: this.groupName, fundingType: this.fundingType, availableTabs: this.lob_FT
      }
    });
  }
  backToSuppHealth() {
    this.router.navigate(['quote/uw-rate-supplemental-health'], {
      queryParams: {
        ratingTransID: this.commonService.getTransIDforTab(this.lob, this.fundingType), opportunityID: this.opportunityID,quoteOrigin: this.quoteOrigin,
        quoteHeaderID: this.quoteHeaderID, lob: this.lob, groupName: this.groupName, fundingType: this.fundingType, availableTabs: this.lob_FT
      }
    });
  }
  ngOnInit() {
    this.authService.userRoleTextToDisplay.subscribe(data => {
      if (data.includes('Read Only')) {
        this.isReadOnlyRole = true;
      }
    })
    this.route.queryParams
      .subscribe(params => {
        this.ratingTransID = params['ratingTransID'];
        this.opportunityID = params['opportunityID'];
        this.quoteHeaderID = params['quoteHeaderID'];
        this.lob = params['lob'];
        this.groupName = params['groupName'];
        this.fundingType = params['fundingType'];
        this.lob_FT = params['availableTabs'];
        this.state = params['state'];
        this.quoteOrigin = params['quoteOrigin'];
        this.factorEffectiveDate = params['factorEffectiveDate'];
      });

    this.soldRates_form = this.fb.group({
      caseNumber: ['', [Validators.required]],
      caseNumberUpdate: ['', [Validators.required]],
      classValue: ['', [Validators.required]],
      ccCodeOverride: ['', [Validators.required]],
      classValueUpdate: ['', [Validators.required]],
      ccCodeOverrideUpdate: ['', [Validators.required]],
      ccValue: ['', [Validators.required]],
      cccValue: ['', [Validators.required]],
      includeInRates: ['']
    });
    this.enablePrintOnSold = false;
    this.loadSoldRates();
    this.flagCategoryChanged = 0;
    this.commonService.setOpportunityId(this.opportunityID);
    this.commonService.setquoteHeaderId(this.quoteHeaderID);
    this.commonService.setRatingTransID(this.ratingTransID);

    sessionStorage.setItem("addedAdditionalPrograms", "");
  }

  isTabDisabled(tabName: string) {
    return this.commonQuoteService.shouldDisableTab(tabName);
  }

  loadSoldRates() {
    this.soldRateFullResponse = [];
    this.selectedSoldRatePlan = [];
    this.responseData = [];
    this.responseDataHistory = [];
    this.historyData = [];
    this.empCategory = [];
    this.showAdditionalProgramsPopUp = false;
    this.selectedAdditionalProgramEmpCategory = [];
    this.additionalProgramEmpCategoryList = [];
    if (this.ratingTransID) {

      this.soldRateService.getSoldRatesHistoryGrid(this.opportunityID, this.quoteHeaderID).subscribe(responseHistory => {
        if (responseHistory && responseHistory.length > 0) {
          this.isCaseNoSaved = true;
          this.savedCaseNumber = responseHistory[0].caseNumber;
          this.responseDataHistory = responseHistory;
          this.enablePrintOnSold = !this.soldHistoryHasOnlySuppHealthPlans();
          for (let resp of responseHistory) {
            if (resp.submittedTimestamp && resp.submittedTimestamp != null) {
              resp.submittedTimestamp = this.dateFormatPipe.transform(resp.submittedTimestamp, "MM/dd/yyyy hh:mm a");
            }
            resp.plan.forEach(plan => {
              if (StringUtils.isEqual(plan.lob, RareConstants.suppHealth) && plan.ageBandTierRates) {
                plan.employmentCategory.forEach((ageBandsEmploymentCategory, index) => {
                  const rateInfo = {
                    eeRate: plan.ageBandTierRates[index].eeRate,
                    esRate: plan.ageBandTierRates[index].esRate,
                    efRate: plan.ageBandTierRates[index].efRate,
                    ecRate: plan.ageBandTierRates[index].ecRate,
                    ekRate: plan.ageBandTierRates[index].ekRate
                  }
                  ageBandsEmploymentCategory.rateInfo = rateInfo;
                  ageBandsEmploymentCategory.ageBand =`${plan.ageBandTierRates[index].ageBandStart}-${plan.ageBandTierRates[index].ageBandEnd}`;
                })
              }
            })
            this.historyData.push(resp.plan);
          }
        }
      });

      this.soldRateFullResponse = this.soldRateService.getSoldRatesGrid(this.opportunityID, this.quoteHeaderID, this.fundingType).subscribe(response => {
        this.isLoading = false;
        this.soldRateFullResponse = response;
        this.isRenewalLocal = response['sfOpportunityType'] == 'Renewal Local';
        if (this.isRenewalLocal) {
          this.cols = SoldConstants.RENEWAL_COLS;
          if (this.currentContractCodes.length == 0 && this.soldRateFullResponse?.currentPlans && this.soldRateFullResponse?.currentPlans?.length > 0) {
            this.soldRateFullResponse.currentPlans.forEach(fullResponseCurrentPlans => {
              this.currentPlansArray.push(fullResponseCurrentPlans.id)
              this.currentContractCodes.push({
                "label": fullResponseCurrentPlans.planName,
                "value": fullResponseCurrentPlans.contractCode
              })
            })
          }

        }
        else {
          this.cols = SoldConstants.NEWBUSINESS_COLS;
        }

        this.responseData = response.plan;
        if (this.isRenewalLocal) {
          this.responseData.forEach(plan => {
            if (!StringUtils.isEqual(plan.status,'Pre-Sold') && StringUtils.isUndefined(plan?.currentContractCode)) {
              delete plan?.currentContractCode;
            }
          })
          let initialEnrollments;
          let mappedCurrentPlansArray = [];
          let portfolioSoldNotifcationPlans = this.responseData.filter(responseDataPlans => this.checkSoldConditions(responseDataPlans, CommonConstants.PORTFOLIO_PLAN_TYPE))
          for (let plan of this.responseData) {
            if (this.checkSoldConditions(plan, CommonConstants.FEATURE_PLAN_TYPE)) {
              if (plan.currPlanId.length == 1) {
                mappedCurrentPlansArray.push(plan.currPlanId[0]);
                this.soldRateFullResponse.currentPlans.forEach(fullResponseCurrentPlans => {
                  if (StringUtils.isEqual(plan.currPlanId[0], fullResponseCurrentPlans.id)) {
                    plan.currentContractCode = fullResponseCurrentPlans.contractCode;
                    initialEnrollments = this.soldRateFullResponse.mappedMedTierLivesMap[fullResponseCurrentPlans.contractCode];
                  }
                })
                this.assignEnrollments(plan, initialEnrollments);
              }
            }
          }
          if (portfolioSoldNotifcationPlans.length == 1) {
            let uniqueCurrentPlan = this.currentPlansArray.filter(currentPlansArrayList => !mappedCurrentPlansArray.includes(currentPlansArrayList));
            if (uniqueCurrentPlan.length == 1) {
              for (let plan of this.responseData) {
                if (this.checkSoldConditions(plan, CommonConstants.PORTFOLIO_PLAN_TYPE)) {
                  plan.currentContractCode = this.soldRateFullResponse.currentPlans.filter(currentPlan => StringUtils.isEqual(currentPlan.id, uniqueCurrentPlan.toString()))[0].contractCode;
                  initialEnrollments = this.soldRateFullResponse.mappedMedTierLivesMap[plan.currentContractCode];
                  this.assignEnrollments(plan, initialEnrollments);
                }
              }
            }
          }
        }
        if (this.responseData) {
          this.responseData = this.responseData.sort(function (plan1, plan2) {
            return plan1.quotedContractCode > plan2.quotedContractCode ? 1 : plan1.quotedContractCode < plan2.quotedContractCode ? -1 : 0
          });
        }
        //The tierRate at this time is the quotedTierRates from QLI and this will change
        //whenever there are additionalProgram additions/inclusions
        //quotedTierRate is created as new attribute to store these original/quoted values
        //and will be used when the plan is added again.
        for (let plan of this.responseData) {
          plan['quotedTierRates'] = plan.tierRate
        }

        let ctrctDate = new Date(response.effectiveDate);
        this.contractEffDate = new Date(ctrctDate.getUTCFullYear(), ctrctDate.getUTCMonth(), ctrctDate.getUTCDate());
        if (response.caseNumber) {
          this.soldRates_form.controls.caseNumber.setValue(response.caseNumber);
          this.caseNumber = response.caseNumber;
        }
        this.submitOptions = [];
        this.lobAdded = new Map<string, string>();
        this.planTypesAdditional = [];
        for (let plan of this.responseData) {
          if (plan.status === "Pre-Sold" && plan.employmentCategory) {
            for (let { } of plan.employmentCategory) {
              this.lobAdded.set(plan.contractCode, plan.lob);
            }
            if (!(this.submitOptions.find(x => x === plan.lob))) {
              this.submitOptions.push(plan.lob);
            }
            plan.employmentCategory = plan.employmentCategory.sort(function (a, b) {
              return a.emplymntCtgryCd > b.emplymntCtgryCd ? 1 : a.emplymntCtgryCd < b.emplymntCtgryCd ? -1 : 0
            });
            this.isCaseNoSaved = true
            this.savedCaseNumber = plan.caseNumber;
            this.empCategory.push(plan);
            if (StringUtils.isEqualIgnoreCase(plan.lob,RareConstants.medical)) {
              this.showAdditionalProgramsPopUp = true;
              this.getIncludeInRates(plan.fundingType);
              this.planTypesAdditional.push({
                'label': plan.contractCodePlanName,
                'value': plan.contractCodePlanName
              })
            } else {
              let index = 0;
              const planAgeBands = plan.ageBandTierRates?.sort((a, b) => a.ageBandStart - b.ageBandStart) ?? [];

              // Adding this for sold notification for Supp Health
              if(plan.ageBandTierRates && plan['employmentCategory'] && plan['employmentCategory'].length==1){
                let count=0;
                plan.ageBandTierRates.forEach(ageBand => {
                  let empCatJson = JSON.parse(JSON.stringify(plan['employmentCategory'][0]));
                  const tierRates = {
                    eeRate:  ageBand.eeRate,
                    esRate:  ageBand.esRate,
                    efRate:  ageBand.efRate,
                    ecRate:  ageBand.ecRate,
                    ekRate:  ageBand.ekRate
                  };
                  empCatJson.tierRate = tierRates;
                  if(count>0){
                    plan['employmentCategory'].push(empCatJson);
                  }
                  count++;
                })
              }

              for (var employmentCategory of plan['employmentCategory']) {
                var employmentCategoryFactor = this.getFactor(plan.lob, employmentCategory.emplymntCtgryCd);
                employmentCategory['tierRate'] = {};
                if (plan.tierRate) {
                  employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(plan.tierRate.eeRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(plan.tierRate.esRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(plan.tierRate.efRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(plan.tierRate.ecRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(plan.tierRate.ekRate) * Number(employmentCategoryFactor));
                  index = 0;
                } else {
                  const ageBandTierRates = planAgeBands[index];
                  employmentCategory.ageBand =`${ageBandTierRates.ageBandStart}-${ageBandTierRates.ageBandEnd}`;
                  employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.eeRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.esRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.efRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.ecRate) * Number(employmentCategoryFactor));
                  employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(ageBandTierRates.ekRate) * Number(employmentCategoryFactor));
                  index = index + 1;
                }

              }
            }
          } else {
            this.nonEmpCategory.push(plan);
            if (StringUtils.isEqualIgnoreCase(plan.lob,RareConstants.medical)) {
              this.mapOfContractCodeAndSelectedEmpCategories = new Map<String, String[]>();
            }
            if (plan.contractCode)
              plan.contractCode = plan.quotedContractCode;
          }

        }
        this.rowData = this.empCategory;
        this.rowDataHistory = this.empCategoryHistory;
        this.disableSubmitButton();
        if (this.showSaveAlert || this.showSubmitAlert) {
          this.div_visible = false;
          this.successMessage = true;
          this.alertData = this.showSaveAlert ? "Sold updates saved" : "Click print to generate sold rate sheet";
          if (this.showSubmitAlert) this.generateReport();
          this.showSubmitAlert = false;
        }
        if (this.onSubmitFlag) {
          this.callSubmitAfterSave();
        }
        this.quoteEffectiveDate = this.soldRateFullResponse.contractEffectiveDate;
        this.programValues = [];
        this.rateTypesAdditional = [];
        this.soldRateService.getSoldRatesAdditionalPrograms(this.state, this.factorEffectiveDate, this.quoteEffectiveDate).subscribe(res => {
          if (Array.isArray(res)) {
            for (let element of res) {
              if (element.dataCtgry === 'ADDNTL_PRG_TYPE') {
                this.programValues.push(element.dataCtgryValue)
              } else if (element.dataCtgry === 'ADDNTL_PRG_RT_TYPE') {
                this.rateTypesAdditional.push({
                  'label': element.dataCtgryValue,
                  'value': element.dataCtgryValue
                })
              }
            }
          }
        })

        this.addRatesFromIncludedAdditionalPrograms();

      });
    }

  }

  //As part of ALGR-92136 the rateInfo in the QLI always has the original
  //rates i.e. rates without AdditionalPrograms. However, whenever we need
  //to display the rates in UI we will always show them with the additionalProgram rates
  //which are available in the rateSplit nodes of the plan object for the UI response (its not same as QLI)
  //in QLI the rateSplit will be under soldRequest node of QLI
  addRatesFromIncludedAdditionalPrograms() {
    var soldPlans = this.soldRateFullResponse['plan'];
    if (soldPlans) {
      for (var soldPlan of soldPlans) {
        if (StringUtils.isEqual(soldPlan.lob, 'Medical') && soldPlan['employmentCategory']) {
          for (var employmentCategory of soldPlan['employmentCategory']) {
            var employmentCategoryFactor=this.getFactor("Medical",employmentCategory.emplymntCtgryCd);

            if(!employmentCategoryFactor){
              employmentCategoryFactor=1
            }

            if(!this.mapOfContractCodeAndSelectedEmpCategories.get(soldPlan.contractCode)){
              this.mapOfContractCodeAndSelectedEmpCategories.set(soldPlan.contractCode,[]);
            }
            this.mapOfContractCodeAndSelectedEmpCategories.get(soldPlan.contractCode).push(employmentCategory.emplymntCtgryCd);

            employmentCategory['tierRate']={};
            employmentCategory.tierRate.eeRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.eeRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.esRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.esRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.efRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.efRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.ecRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.ecRate) * Number(employmentCategoryFactor));
            employmentCategory.tierRate.ekRate = this.roundValueToTwoDecimals(Number(soldPlan.tierRate.ekRate) * Number(employmentCategoryFactor));
            if(employmentCategory['rateSplits']){
              for (var rateSplit of employmentCategory['rateSplits']) {
                if (StringUtils.isEqualIgnoreCase(rateSplit.splitIncluded, "yes")) {
                  var rateArray = rateSplit['rates'];
                  employmentCategory.tierRate.eeRate = employmentCategory.tierRate.eeRate  + this.getRequiredRatesFromRateArray(rateArray, 'ee');
                  employmentCategory.tierRate.esRate = employmentCategory.tierRate.esRate  + this.getRequiredRatesFromRateArray(rateArray, 'es');
                  employmentCategory.tierRate.efRate = employmentCategory.tierRate.efRate  + this.getRequiredRatesFromRateArray(rateArray, 'ef');
                  employmentCategory.tierRate.ecRate = employmentCategory.tierRate.ecRate  + this.getRequiredRatesFromRateArray(rateArray, 'ec');
                  employmentCategory.tierRate.ekRate = employmentCategory.tierRate.ekRate  + this.getRequiredRatesFromRateArray(rateArray, 'ek');
                }
              }
            }
          }
        }
      }
    }

  }

  roundValueToTwoDecimals(value) {
    return Math.round(+(Number(value)).toFixed(2) * 100) / 100
  }


  //rates is an array which has the rates for all tiers
  //we need to iterate and get the rate for the requiredTier
  //and get the rates. If no match is found, return ZERO
  getRequiredRatesFromRateArray(rateArray, tierForWhichRateIsRequired) {
    for (const rate of rateArray) {
      if (StringUtils.isEqualIgnoreCase(rate.tier, tierForWhichRateIsRequired)) {
        return rate.rate;
      }
    }
    return 0;
  }

  callSubmitAfterSave() {
    this.onSubmitFlag = false;
    let _SoldRatePlansWithCat = Object.assign({}, this.soldRateFullResponse);

    _SoldRatePlansWithCat.plan = [];
    for (var i = 0; i < this.responseData.length; i++) {
      if (this.responseData[i].employmentCategory && this.responseData[i].employmentCategory.length > 0
        && this.selectedSubmitValue.includes(this.responseData[i].lob)) {
        _SoldRatePlansWithCat.plan.push(this.responseData[i]);
        const index = this.submitOptions.indexOf(this.responseData[i].lob);
        if (index !== -1) {
          this.submitOptions.splice(index, 1);
        }
      }
    }

    let contractEndDateFormatted = this.datepipe.transform(
      this.contractEffDate,
      "yyyy-MM-dd"
    );
    _SoldRatePlansWithCat.effectiveDate = contractEndDateFormatted;
    const rateinfoJson = { "data": this.buildSubmitJson(_SoldRatePlansWithCat) };
    if (rateinfoJson.data['plan'].length > 0) {
      this.div_visible = true;
      this.soldRateService.submitSoldRates(rateinfoJson).subscribe(() => {
        this.showSubmitAlert = true;
        this.showSaveAlert = false;
        this.loadSoldRates();
        this.removeSubmittedLobs(rateinfoJson);
      },
        () => {
          this.showErrorAlert = true;
          this.div_visible = false;
          this.alertData = "Error Encountered, Please contact dl-RARE-IT";
          this.failureMessage = true;
        });
    }
  }

  //if LOB is submitted successfully then remove that from the submit dropDown
  //and use the submit dropDown values to determine whether to
  //keep submit enabled or disabled
  removeSubmittedLobs(rateinfoJson) {
    for (let plan of rateinfoJson.data['plan']) {
      var lob = plan.lob;
      this.selectedSubmitValue = Array.from(this.selectedSubmitValue);
      const index = this.selectedSubmitValue.indexOf(lob);
      if (index !== -1) {
        this.selectedSubmitValue.splice(index, 1);
      }
    }
  }

  getFactor(lob, category) {
    if (lob.toLowerCase() === RareConstants.medicalLC && this.soldRateFullResponse.employmentCategoryMedical) {
      for (let medFactor of this.soldRateFullResponse.employmentCategoryMedical) {
        if (medFactor.emplymntCtgryCd.toLowerCase() === category.toLowerCase())
          return medFactor.emplymntCtgryFctr;
      }
    }
    if (lob.toLowerCase() === RareConstants.visionLC && this.soldRateFullResponse.employmentCategoryVision) {
      for (let visFactor of this.soldRateFullResponse.employmentCategoryVision) {
        if (visFactor.emplymntCtgryCd.toLowerCase() === category.toLowerCase())
          return visFactor.emplymntCtgryFctr;
      }
    }
    if (lob.toLowerCase() === RareConstants.dentalLC && this.soldRateFullResponse.employmentCategoryDental) {
      for (let denFactor of this.soldRateFullResponse.employmentCategoryDental) {
        if (denFactor.emplymntCtgryCd.toLowerCase() === category.toLowerCase())
          return denFactor.emplymntCtgryFctr;
      }
    }
    if (StringUtils.isEqualIgnoreCase(lob, RareConstants.suppHealth) && this.soldRateFullResponse.employmentCategorySuppHealth) {
      for (let suppHealthFactor of this.soldRateFullResponse.employmentCategorySuppHealth) {
        if (suppHealthFactor.emplymntCtgryCd && StringUtils.isEqualIgnoreCase(suppHealthFactor.emplymntCtgryCd, category))
          return suppHealthFactor.emplymntCtgryFctr;
      }
    }
  }

  removeSuccessMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.alertData = " ";
    this.showSaveAlert = false;
    this.showErrorAlert = false;
    this.showSubmitAlert = false;
    this.isCurrentPlanMapped = false;
    this.isEnrollmentMismatch = false
  }

  getPlanNameAndCC(lob, fundType, planType) {
    this.planName = [];
    this.contractCodes = [];
    for (let resp of this.responseData) {
      if (resp.lob === lob && resp.fundingType === fundType && resp.planTypeRequested === planType) {
        this.planName.push({
          "quotedContractCode": resp.quotedContractCode,
          "contractCode": resp.contractCode ? resp.contractCode : resp.quotedContractCode,
          "productName": resp.productName || "",
          "ratingPlanID": resp.ratingPlanID
        });
        if (!(this.contractCodes.find(x => x.value === resp.quotedContractCode))) {
          this.contractCodes.push({
            "label": resp.quotedContractCode,
            "value": resp.quotedContractCode
          });
        }
      }
    }
    if (this.planName.length === 1 && !StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)) {
      this.getRatesByCC(this.contractCodes[0].label);
      this.getRates(this.planName[0].ratingPlanID);
    }
  }

  refreshPlanDropdown() {
    this.planName = [];
    this.contractCodes = [];
    this.planNamesBackup = this.planName;
    for (let resp of this.responseData) {
      this.planName.push({
        "quotedContractCode": resp.quotedContractCode,
        "contractCode": resp.contractCode,
        "productName": resp.productName || ""
      });
      if (!(this.contractCodes.find(x => x.value === resp.quotedContractCode))) {
        this.contractCodes.push({
          "label": resp.quotedContractCode,
          "value": resp.quotedContractCode
        });
      }
      if (!(this.lobValues.find(x => x === resp.lob))) {
        this.lobValues.push(resp.lob);
      }
    }
    this.planNamesBackup = this.planName;
    this.contractCodeBackup = this.contractCodes;

    this.disableSubmitButton();
  }


  refreshData() {
    for (let resp of this.responseData) {
      if (!(this.contractCodes.find(x => x.value === resp.quotedContractCode))) {
        this.contractCodes.push({
          "label": resp.quotedContractCode,
          "value": resp.quotedContractCode
        });
      }
    }
    this.contractCodeBackup = this.contractCodes;
    this.empCategory = [];
    for (let soldPlans of this.responseData) {
      if (soldPlans.employmentCategory) {
        soldPlans.employmentCategory = soldPlans.employmentCategory.sort(function (a, b) {
          return a.emplymntCtgryCd > b.emplymntCtgryCd ? 1 : a.emplymntCtgryCd < b.emplymntCtgryCd ? -1 : 0
        });
        if (this.isRenewalLocal && soldPlans.lob == 'Medical') {
          if (!StringUtils.isUndefined(soldPlans.currentContractCode))
          soldPlans.currentContractCode = soldPlans.currentContractCode ? soldPlans.currentContractCode : this.selectedCurrentContractCode
        }
        this.empCategory.push(soldPlans);
      }
      else {
        this.nonEmpCategory.push(soldPlans);
      }

    }
    this.empCategory = this.empCategory.sort(function (a, b) {
      return a.quotedContractCode > b.quotedContractCode ? 1 : a.quotedContractCode < b.quotedContractCode ? -1 : 0
    });
    this.rowData = this.empCategory;
    this.disableSubmitButton();
  }

  disableSubmitButton() {
    if (this.rowData.length > 0)
      this.disableSubmit = false;
    else
      this.disableSubmit = true;
  }

  showDialogToAdd() {
    //when the add button is clicked - clear out all existing fields
    this.resetForm();
    this.formData = null;
    this.displayDialog = true;
    this.soldCCvalue = '';
    this.errorFlag = false;
    this.errorValue = "";
    for (let resp of this.responseData) {
      if (resp.lob === 'Medical') {
        this.showAdditionalProgramsPopUp == true;
        if (resp.planIsRemoved) {
          resp.planIsRemoved = false;
        }
      }
      if (!(this.lobValues.find(x => x === resp.lob))) {
        this.lobValues.push(resp.lob);
      }
    }
    this.soldRates_form.controls.ccCodeOverride.setValue('');
  }

  getLOB(value) {
    this.onChangeLob = false;
    setTimeout(() => {
      this.onChangeLob = true;
    });
    this.selectedLOB = value;
    this.errorFlag = false;
    this.planTypes = [];
    this.fundingTypes = [];
    this.selectedPlanType = "";
    this.selectedFundingType = "";
    this.planValue = "";
    this.CCValue = "";
    this.CCCValue = "";
    this.empCatValue = "";
    this.selectedPlan = "";
    this.selectedRatingPlanID = "";
    this.formData = null;
    this.selectedProducts = null;
    this.selectedContractCodes = null;
    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && !(this.fundingTypes.find(x => x.value === resp.fundingType))) {
        if (resp.fundingType === "FI" && (this.checkSoldTableHasFundingType() === 'FI' || !this.checkSoldTableHasFundingType())) {
          this.fundingTypes.push({
            "label": "FI",
            "value": "FI",
          });
        }
        else if (resp.fundingType === "ABF" && (this.checkSoldTableHasFundingType() === 'ABF' || !this.checkSoldTableHasFundingType())) {
          this.fundingTypes.push({
            "label": "ABF",
            "value": "ABF",
          });
        }
      }
    }
    if (this.fundingTypes.length === 1)
      this.getFundingType(this.fundingTypes[0].value);
    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)) {
      this.selectAllProductsForSuppHealth();
    }
  }

  selectAllProductsForSuppHealth() {
    let selectedProducts = [];
    let selectedQuotedContractCodes = [];
    let selectedRatingPlanIDs = [];
    this.responseData.forEach(product => {
      if (StringUtils.isEqualIgnoreCase(product.lob, RareConstants.suppHealth)) {
        selectedProducts.push({
          "quotedContractCode": product.quotedContractCode,
          "contractCode": product.contractCode,
          "productName": product.productName,
          "ratingPlanID": product.ratingPlanID
        })
        selectedRatingPlanIDs.push(product.ratingPlanID);
        const quotedContractCode = product.quotedContractCode;

        let isContractCodeSelected = selectedQuotedContractCodes.some((selectedContractCode) => {
          return selectedContractCode.value === quotedContractCode;
        });

        if (!isContractCodeSelected){
          selectedQuotedContractCodes.push({
            "label": product.quotedContractCode,
            "value": product.quotedContractCode
          })
        }
      }
    })
    this.selectedProducts = selectedProducts;
    this.selectedContractCodes = selectedQuotedContractCodes;
    this.selectedRatingPlanIDs = selectedRatingPlanIDs;

    const soldContractCodes: string[] = selectedQuotedContractCodes.map(soldContractCode => soldContractCode.value);
    const contractCodes = soldContractCodes.join(", ")
    this.soldRates_form.controls.ccCodeOverride.setValue(contractCodes);

    this.categoryList = [];
    this.categoryList = this.getCategoryList(this.selectedLOB, 'A');
  }

  checkSoldTableHasFundingType() {
    let fundType;
    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && resp.employmentCategory && resp.employmentCategory.length > 0) {
        fundType = resp.fundingType;
      }
    }
    return fundType;
  }

  getFundingType(value) {
    this.selectedFundingType = value;
    this.errorFlag = false;
    this.planTypes = [];
    this.selectedPlanType = "";
    this.planValue = "";
    this.CCValue = "";
    this.CCCValue = "";
    this.empCatValue = "";
    this.selectedPlan = "";
    this.selectedRatingPlanID = "";
    this.formData = null;
    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && this.selectedFundingType === resp.fundingType && !(this.planTypes.find(x => x.value === resp.planTypeRequested))) {
        if (resp.planTypeRequested === "F") {
          this.planTypes.push({
            "label": "Featured Plan",
            "value": "F",
          });
        }
        else {
          this.planTypes.push({
            "label": "Portfolio Plan",
            "value": "P",
          });
        }
      }
    }

    if (this.planTypes.length === 1)
      this.getPlanType(this.planTypes[0].value);

    for (let resp of this.responseData) {
      if (this.selectedLOB === resp.lob && this.selectedFundingType === resp.fundingType && resp.caseNumber) {
        this.soldRates_form.controls.caseNumber.setValue(resp.caseNumber);
        this.caseNumber = resp.caseNumber;
      }
    }

  }
  getPlanType(value) {
    this.onChangeLob = false;
    setTimeout(() => {
      this.onChangeLob = true;
    });
    this.selectedPlanType = value;
    this.planValue = "";
    this.CCValue = "";
    this.CCCValue = "";
    this.empCatValue = "";
    this.selectedPlan = "";
    this.selectedRatingPlanID = "";
    this.selectedContractCode = "";
    this.selectedCurrentContractCode = "";
    this.errorFlag = false;
    this.formData = null;
    this.getPlanNameAndCC(this.selectedLOB, this.selectedFundingType, this.selectedPlanType);
  }
  getPlanDataForProduct(map, value): any {
    let objFound = map.find(x => x.ratingPlanID === value);
    return objFound || {};
  }

  getPlanNameForProduct(map, value): string {
    let objFound = this.getPlanDataForProduct(map, value);
    return objFound.productName || "";
  }
  getCurrentPlan(value) {
    let contractData;
    let currentContractCodes = [];
    contractData = this.responseData.find(responseData => responseData.ratingPlanID === value);
    if (StringUtils.isEqualIgnoreCase(this.selectedPlanType, 'F')) {
      contractData.currPlanId.forEach(currentData => {
        this.soldRateFullResponse.currentPlans.forEach(fullResponseCurrentPlans => {
          if (currentData == fullResponseCurrentPlans.id) {
            currentContractCodes.push({
              "label": fullResponseCurrentPlans.planName,
              "value": fullResponseCurrentPlans.contractCode
            })
          }
        })
      })
    }
    if (currentContractCodes.length == 1) {
      this.CCCValue = {
        "label": currentContractCodes[0].label,
        "value": currentContractCodes[0].value
      }
      this.selectedCurrentContractCode = currentContractCodes[0].value;
    }
  }
  getRates(value) {
    this.selectedPlan = this.getPlanNameForProduct(this.planName, value);
    this.selectedRatingPlanID = value;
    this.additionalProgramErrorFlag = false;
    this.dataReset();
    this.formData = null;
    this.selectedEmpCategory = null;
    this.empCatValue = "";
    this.lobValue = "";
    let contractData;
    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth) && value) {
      const selectedProducts = value ?? [];
      let soldContractCodes = selectedProducts.map(selectedProduct => selectedProduct.quotedContractCode);
      soldContractCodes = soldContractCodes.join(", ")
      let selectedQuotedContractCodes = [];
      let selectedRatingPlanIDs = [];
      selectedProducts.forEach(selectedProduct => {
        let isContractCodeSelected = selectedQuotedContractCodes.some((selectedContractCode) => {
          return selectedContractCode.value === selectedProduct.quotedContractCode;
        });
        selectedRatingPlanIDs.push(selectedProduct['ratingPlanID']);
        if (!isContractCodeSelected){
          selectedQuotedContractCodes.push({
            "label": selectedProduct.quotedContractCode,
            "value": selectedProduct.quotedContractCode
          })
        }
      })
      this.selectedContractCodes = selectedQuotedContractCodes;
      this.selectedRatingPlanIDs = selectedRatingPlanIDs;
      this.soldRates_form.controls.ccCodeOverride.setValue(soldContractCodes);
    } else {
      contractData = this.responseData.find(x => x.ratingPlanID === value);
      this.CCValue = {
        "label": contractData.quotedContractCode,
        "value": contractData.quotedContractCode
      };
      this.selectedContractCode = contractData.quotedContractCode;
      this.soldRates_form.controls.ccCodeOverride.setValue(contractData.contractCode);
    }
    if (this.isRenewalLocal && StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.medical))
      this.getCurrentPlan(value);
    this.categoryList = [];
    this.categoryList = CommonUtil.getSortedList(this.getCategoryList(this.selectedLOB, 'A'));
  }
  getRatesByCCC(selectedCurrentPlan) {
    this.selectedCurrentContractCode = selectedCurrentPlan.value;
  }
  buildSubmitJson(_SoldRatePlansWithCat): any {
    let _rateInfo = Object.assign({}, _SoldRatePlansWithCat);
    _rateInfo['plan'].forEach((plan, index) => {
      const tierRate = plan['tierRate'];
      const asoFeeRate = plan['asoFee'];
      const sslPremiumRate = plan['sslPremium'];
      const aslPremiumRate = plan['aslPremium'];
      const terminalLiabilityRate = plan['terminalLiabilityFund'];
      const maxPaidClaimsRate = plan['maxPaidClaimsFund'];
      const empCategoryInfo = plan['employmentCategory']
      let empCategoryArray = [] as Array<any>;
      if (empCategoryInfo) {
        empCategoryInfo.forEach((element) => {
          let factor = this.getFactor(plan['lob'], element['emplymntCtgryCd']);
          var rateInfo: RateInfo = this.calculateRate(factor, tierRate);
          var asoFee: RateInfo = this.calculateRate(factor, asoFeeRate);
          var sslPremium: RateInfo = this.calculateRate(factor, sslPremiumRate);
          var aslPremium: RateInfo = this.calculateRate(factor, aslPremiumRate);
          var terminalLiability: RateInfo = this.calculateRate(factor, terminalLiabilityRate);
          var maxPaidClaimsFund: RateInfo = this.calculateRate(factor, maxPaidClaimsRate);
          empCategoryArray.push({
            'emplymntCtgryCd': element['emplymntCtgryCd'],
            'employmentClassCode': element['employmentClassCode'],
            'wgsSubGroupNumber': element['wgsSubGroupNumber'],
            'rateInfo': rateInfo,
            'asoFee': asoFee,
            'sslPremium': sslPremium,
            'aslPremium': aslPremium,
            'terminalLiabilityFund': terminalLiability,
            'maxPaidClaimsFund': maxPaidClaimsFund,
            'enrollments': element['enrollments'],
            'rateSplits': element['rateSplits']
          });
        });
        _rateInfo['plan'][index]['employmentCategory'] = empCategoryArray;
      }
      empCategoryArray = null;
    })
    return _rateInfo;
  }
  calculateRate(factor, tierRate): any {
    if (tierRate) {
      var rateInfo: RateInfo = new RateInfo();
      rateInfo.eeRate = parseFloat(this.buildRateInfo(factor, tierRate.eeRate));
      rateInfo.esRate = parseFloat(this.buildRateInfo(factor, tierRate.esRate));
      rateInfo.efRate = parseFloat(this.buildRateInfo(factor, tierRate.efRate));
      rateInfo.ecRate = parseFloat(this.buildRateInfo(factor, tierRate.ecRate));
      rateInfo.ekRate = parseFloat(this.buildRateInfo(factor, tierRate.ekRate));
      return rateInfo;
    } else {
      return null;
    }
  }

  convertToDecimal(tierRate): any {
    return this._decimalPipe.transform(tierRate, "1.2-2");
  }

  buildRateInfo(factor, tierRate): any {
    return isNaN(factor) ? this.convertToDecimal(tierRate).replace(/[^\d\.\-]/g, "")
      : this.convertToDecimal(factor * tierRate).replace(/[^\d\.\-]/g, "");
  }

  submitSoldRates($event) {
    if ($event.target.name === 'Manual Submit') {
      this.action = $event.target.name;

    }

    this.saveSoldRates();
    this.onSubmitFlag = true;
    if ((this.isCurrentPlanMapped && StringUtils.isEqual(this.alertData, SoldConstants.CURRENT_PLAN_MAP_MSG)) || (this.isEnrollmentMismatch && StringUtils.isEqual(this.alertData, SoldConstants.ENROLLMENT_MISMATCH_MSG)))
    this.onSubmitFlag = false;
    //clear out sessiondata for additionalPrograms when SUBMIT is done
    sessionStorage.setItem("addedAdditionalPrograms", "");
  }


  updateAction(action) {
    this.action = action;
  }
  saveSoldRates() {
    this.isEnrollmentMismatch = false;
    if (this.selectedSoldRatePlan.length == 0) {
      this.updatedSoldRatePlan({}, '', '');
    }
    for (let i = 0; i < this.selectedSoldRatePlan.length; i++) {
      this.selectedSoldRatePlan[i]['ActionPerformed'] = this.action;
    }
    this.removeSuccessMsg();
    let _SoldRatePlansWithCat = Object.assign({}, this.soldRateFullResponse);
    _SoldRatePlansWithCat.plan = this.responseData;
    let contractEndDateFormatted = this.datepipe.transform(
      this.contractEffDate,
      "yyyy-MM-dd"
    );
    _SoldRatePlansWithCat.effectiveDate = contractEndDateFormatted;
    this.div_visible = true;
    if (this.isRenewalLocal) {
      let medicalPlans = this.responseData.filter(medPlans => StringUtils.isEqualIgnoreCase(medPlans.lob, RareConstants.medical) && StringUtils.isEqualIgnoreCase(medPlans.status, "Pre-Sold") && medPlans?.employmentCategory?.length != 0);
      this.isCurrentPlanMapped = medicalPlans.some(medPlans => StringUtils.isUndefined(medPlans.currentContractCode))
    }
    if (this.isCurrentPlanMapped) {
      this.showErrorAlert = true;
      this.div_visible = false;
      this.alertData = SoldConstants.CURRENT_PLAN_MAP_MSG;
      return;
    }
    let enrollments = this.checkEnrollmentCount(_SoldRatePlansWithCat);
    if (!StringUtils.isUndefined(_SoldRatePlansWithCat?.quotedSubscribers) && this.isRenewalLocal) {
      if (enrollments != _SoldRatePlansWithCat.quotedSubscribers && (this.selectedSubmitValue?.includes(RareConstants.medical) || (this.submitOptions?.includes(RareConstants.medical) && StringUtils.isEqual(this.action, CommonConstants.save)))) {
        this.isEnrollmentMismatch = true;
        this.showErrorAlert = true;
        this.div_visible = false;
        this.alertData = SoldConstants.ENROLLMENT_MISMATCH_MSG;
        return;
      }
    }
    this.soldRateService.saveSoldRates(_SoldRatePlansWithCat, this.opportunityID, this.selectedSoldRatePlan, this.action).subscribe(response => {
      if (this.onSubmitFlag) {
        this.loadSoldRates();
      } else if (response.code === 'success') {
        this.showSaveAlert = true;
        this.selectedSoldRatePlan = [];
        this.selectedRowsToRemove = [];
        this.loadSoldRates();
      }
    },
      error => {
        console.error(error);
        this.showErrorAlert = true;
        this.div_visible = false;
        this.alertData = "Error Encountered, Please contact dl-RARE-IT";
        this.failureMessage = true;
      });

    //clear out sessiondata for additionalPrograms when save is done
    sessionStorage.setItem("addedAdditionalPrograms", "");
    this.mapOfContractCodeAndAdditionalProgram = new Map<String, Object[]>();
  }

  createFileName(): string {
    let visFlag = false;
    let medFlag = false;
    let denFlag = false;
    let _SoldRatePlansWithCat = Object.assign({}, this.soldRateFullResponse);
    const planList = _SoldRatePlansWithCat['plan'];
    planList.forEach(plan => {
      if (plan['lob'] === RareConstants.medical && plan['status'] === 'Sold') {
        medFlag = true;
      } else if (plan['lob'] === RareConstants.vision && plan['status'] === 'Sold') {
        visFlag = true;
      } else if (plan['lob'] === RareConstants.dental && plan['status'] === 'Sold') {
        denFlag = true;
      }
    });
    let contractEndDateFormatted = this.datepipe.transform(
      _SoldRatePlansWithCat['effectiveDate'],
      "yyyyMMdd"
    );
    let submittedTimeStamp = this.datepipe.transform(
      new Date(),
      "yyyyMMdd-hhmmss"
    );
    const lobName = medFlag && visFlag ? 'MED' : !medFlag && visFlag ? 'VIS' : !medFlag && denFlag ? 'DEN' : 'MED';
    const returnValue = _SoldRatePlansWithCat['caseName'] + '-' + contractEndDateFormatted + '-' + _SoldRatePlansWithCat['quoteHeaderID'] + '-' + submittedTimeStamp + '-' +
      lobName + '-RARE-FINALRATES';
    return returnValue;
  }
  generateReport() {
    this.reportsService.getGeneratedReport(null, null, null, null, this.opportunityID,
      this.quoteHeaderID, this.fundingType, this.createFileName()).subscribe(response => {
        this.div_visible = false;
        if (response.status === 200) {
          this.processId = response.body.processId;
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = "progress-bar-warning";
          var source = this.commonService.listenForStream(this.processId);
          source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
            this.progressStyle = "";
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
          });
          source.addEventListener("SEND_EXHIBIT_TO_UI", (message: any) => {
            let eventData = JSON.parse(message.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
            let fileExt = '.xlsx';
            CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet" + fileExt);
            let fileName = this.commonService.getExportFilename();
            let contentData = eventData?.payload?.contentData;
            if (contentData) {
              const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            }
          });
          source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
            source.close();
            let eventData = JSON.parse(message.data);
            this.progressStyle = "progress-bar-success";
            this.progressPercent = 100;
            this.progressMessage = eventData.message;
            setTimeout(() => {
              this.showProgress = false;
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener('FAILED', (message: any) => {
            source.close();
            console.error("Received event : ", JSON.stringify(message.data));
            this.progressPercent = 90;
            this.progressStyle = "progress-bar-danger";
            this.progressMessage = "Error in getting response for Export";
          });
        }
      }, error => {
        this.div_visible = false;
        alert("Error in getting response for Export: " + error);
      });
  }

  downloadFile(blob: any, filename: string) {

    var binaryData = [];
    binaryData.push(blob);

    /*Workaround for IE11 download issue*/
    // IE doesn't allow using a blob object directly as link href
    // instead it is necessary to use msSaveOrOpenBlob
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(new Blob(binaryData, { type: "" }), filename);
      return;
    }
    else {
      // create hidden dom element (so it works in all browsers)
      const url = window.URL.createObjectURL(new Blob(binaryData, { type: "" })); // <-- work with blob directly
      const a = document.createElement('a');
      a.setAttribute('style', 'display:none;');
      document.body.appendChild(a);

      // create file, attach to hidden element and open hidden element
      a.href = url;
      a.download = filename;
      a.click();
    }
  }

  getPlanData(map, value): any {
    let objFound = map.find(x => x.quotedContractCode === value);
    return objFound || {};
  }

  getPlanName(map, value): string {
    let objFound = this.getPlanData(map, value);
    return objFound.productName || "";
  }

  getPlanNameObj(map, value): string {
    let objFound = map.find(x => x.quotedContractCode === value && x.fundingType === this.selectedFundingType);
    return objFound || "";
  }

  getProductsByContractCode(products, quotedContractCode): any[] {
    return products.filter(product => product.quotedContractCode === quotedContractCode);
  }

  getRatesByCC(value) {
    this.selectedContractCode = value;
    this.dataReset();
    this.formData = null;
    this.selectedEmpCategory = null;
    this.empCatValue = "";
    this.lobValue = "";
    this.selectedPlan = this.getPlanName(this.responseData, value);

    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, CommonConstants.SuppHealth) && value) {
      const selectedQuotedContractCodes = value ?? [];
      let soldContractCodes = selectedQuotedContractCodes.map(selectedQuotedContractCode => selectedQuotedContractCode.value);
      soldContractCodes = soldContractCodes.join(", ")

      let selectedProducts = [];
      let selectedRatingPlanIDs = [];
      selectedQuotedContractCodes.forEach(selectedQuotedContractCode => {
        const products = this.getProductsByContractCode(this.responseData, selectedQuotedContractCode.value);
        products?.forEach(product => {
          selectedProducts.push({
            "quotedContractCode": selectedQuotedContractCode.value,
            "contractCode": product['contractCode'],
            "productName": product['productName'],
            "ratingPlanID": product['ratingPlanID']
          })
          selectedRatingPlanIDs.push(product['ratingPlanID']);
        })
      })
      this.selectedProducts = selectedProducts;
      this.selectedRatingPlanIDs = selectedRatingPlanIDs;
      this.soldRates_form.controls.ccCodeOverride.setValue(soldContractCodes);
    } else {
      this.planValue =
          {
            "quotedContractCode": this.selectedContractCode,
            "contractCode": this.getPlanNameObj(this.responseData, value)['contractCode'],
            "productName": this.selectedPlan,
            "ratingPlanID": this.getPlanNameObj(this.responseData, value)['ratingPlanID']
          };
      this.selectedRatingPlanID = this.getPlanNameObj(this.responseData, value)['ratingPlanID'];
      this.soldRates_form.controls.ccCodeOverride.setValue(this.planValue.contractCode);
    }
    if (this.isRenewalLocal && this.selectedLOB == 'Medical')
      this.getCurrentPlan(this.selectedRatingPlanID);
    this.categoryList = [];
    this.categoryList = this.getCategoryList(this.selectedLOB, 'A');
  }

  getSoldContractCode(value) {
    this.soldCCvalue = value;
  }

  getCategoryList(lob, forType) {
    let categoryListArray = [];
    let defaultCategoryList = [];
    if (StringUtils.isEqualIgnoreCase(lob, RareConstants.medical)) {
      for (let cat of this.soldRateFullResponse.employmentCategoryMedical) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    }
    else if (StringUtils.isEqualIgnoreCase(lob, RareConstants.vision)) {
      for (let cat of this.soldRateFullResponse.employmentCategoryVision) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    }
    else if (StringUtils.isEqualIgnoreCase(lob, RareConstants.dental)) {
      for (let cat of this.soldRateFullResponse.employmentCategoryDental) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    }
    else if (StringUtils.isEqualIgnoreCase(lob, RareConstants.suppHealth)) {
      for (let cat of this.soldRateFullResponse.employmentCategorySuppHealth) {
        this.setCategoryList(forType, categoryListArray, cat, defaultCategoryList);
      }
    }

    if (defaultCategoryList.length) {
      defaultCategoryList.sort();
      this.empCatValue = defaultCategoryList;
      this.getCategory(defaultCategoryList);
    }

    categoryListArray.sort(function (a, b) {
      if (a && b) {
        if (a.label && b.label) {
          return a.label.localeCompare(b.label);
        } else {
          return a.localeCompare(b);
        }
      }
    });
    return categoryListArray;
  }

  setCategoryList(forType, categoryListArray: any[], cat: any, defaultCategoryList: any[]) {
    if (StringUtils.isEqualIgnoreCase(forType, 'A')) {
      categoryListArray.push({
        "label": cat.emplymntCtgryCd,
        "value": cat.emplymntCtgryCd
      });
      if (StringUtils.isEqualIgnoreCase(cat.dfltInd, 'Y')) {
        defaultCategoryList.push(cat.emplymntCtgryCd);
      }
    } else {
      categoryListArray.push(cat.emplymntCtgryCd);
    }
  }

//This is invoked when AddPlan popup is reset
  resetForm() {
    this.revertReplacingOfTierRatesWithQuotedRates();
    this.formReset();
  }

  getEmpCategoryFactor(value,lob?) {
    if(StringUtils.isEmpty(lob))
      lob=this.selectedLOB;

    this.empCategoryData = null
    if ((lob.toLowerCase() === RareConstants.medicalLC && this.soldRateFullResponse.employmentCategoryMedical) || this.selectedProgramType) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategoryMedical.find(x => x.emplymntCtgryCd === value);
    }

    if (lob.toLowerCase() === RareConstants.visionLC && this.soldRateFullResponse.employmentCategoryVision) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategoryVision.find(x => x.emplymntCtgryCd === value);
    }

    if (lob.toLowerCase() === RareConstants.dentalLC && this.soldRateFullResponse.employmentCategoryDental) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategoryDental.find(x => x.emplymntCtgryCd === value);
    }

    if (StringUtils.isEqualIgnoreCase(lob, RareConstants.suppHealth) && this.soldRateFullResponse.employmentCategorySuppHealth) {
      this.empCategoryData = this.soldRateFullResponse.employmentCategorySuppHealth.find(x => x.emplymntCtgryCd === value);
    }

    return this.empCategoryData.emplymntCtgryFctr;
  }

  checkActiveExistCommon(ratingPlanID: string) {
    let empCat;
    empCat = this.responseData.find(x => x.ratingPlanID === ratingPlanID);
    let classCodeExists = false;
    if (empCat && empCat.employmentCategory) {
      empCat.employmentCategory.find(x => {
        if (x.employmentClassCode === this.classCode)
          classCodeExists = true;
      });
    }
    const isActive = this.selectedEmpCategory && this.selectedEmpCategory.find(e => e === 'Active');
    if ((!empCat || !empCat.employmentCategory || !empCat.employmentCategory.length) && isActive) {
      return true;
    } else if ((!empCat || !empCat.employmentCategory || !empCat.employmentCategory.length) && !isActive) {
      return false;
    } else if (empCat && empCat.employmentCategory && empCat.employmentCategory.length) {
      if ((classCodeExists && !empCat.employmentCategory.find(e => e.emplymntCtgryCd === 'Active' && e.employmentClassCode === this.classCode))
        || (!classCodeExists && !isActive)) {
        return false;
      } else if (!classCodeExists && isActive) {
        return true;
      }
    }
    return true;
  }

  checkActiveExist() {
    return this.checkActiveExistCommon(this.selectedRatingPlanID);
  }

  checkActiveExistSuppHealth() {
    return this.selectedRatingPlanIDs.some(ratingPlanID => this.checkActiveExistCommon(ratingPlanID));
  }

  updateEnrollment(rowData, empCat, enterdValue, key) {
    rowData.employmentCategory.forEach(rowDataEmpCat => {
      if (rowDataEmpCat.emplymntCtgryCd == empCat.emplymntCtgryCd && rowDataEmpCat.employmentClassCode == empCat.employmentClassCode) {
            rowDataEmpCat.enrollments[key] = Number(enterdValue);
      }
    })
  }
  onEnrollmentChange(key, rowData, empCat, event) {
    let enterdValue = event.replace("%", "").replace(",", "");
    if (StringUtils.isEqualIgnoreCase(key, 'eeRateEnrollment'))
      this.updateEnrollment(rowData, empCat, enterdValue, 'ee');
    if (StringUtils.isEqualIgnoreCase(key, 'ekRateEnrollment'))
      this.updateEnrollment(rowData, empCat, enterdValue, 'ek');
    if (StringUtils.isEqualIgnoreCase(key, 'efRateEnrollment'))
      this.updateEnrollment(rowData, empCat, enterdValue, 'ef');
    if (StringUtils.isEqualIgnoreCase(key, 'ecRateEnrollment'))
      this.updateEnrollment(rowData, empCat, enterdValue, 'ec');
    if (StringUtils.isEqualIgnoreCase(key, 'esRateEnrollment'))
      this.updateEnrollment(rowData, empCat, enterdValue, 'es');
  }

  prepareEmpCatObj(empCat, forType, classCode, lob?) {
    let obj = {
      "emplymntCtgryCd": '',
      "employmentClassCode": '',
      "wgsSubGroupNumber": '',
    }
    if (this.isRenewalLocal && StringUtils.isEqualIgnoreCase(lob, RareConstants.medical)) {
      if (empCat == 'Active') {
        let planListResponseData = this.responseData;
        planListResponseData = planListResponseData.filter(planListResponseData => !StringUtils.isEqualIgnoreCase(planListResponseData.ratingPlanID, this.selectedRatingPlanIdUpdate))
        let existContractMapping = planListResponseData.find(responseData => responseData.currentContractCode == this.selectedCurrentContractCode && responseData?.employmentCategory && responseData?.employmentCategory?.length > 0);
        if (existContractMapping) {
          obj['enrollments'] = { ee: 0, ef: 0, ek: 0, es: 0, ec: 0 };
        }
        else {
          let initialEnrollments = this.soldRateFullResponse.mappedMedTierLivesMap[this.selectedCurrentContractCode];
          obj['enrollments'] = {
            ee: initialEnrollments?.EE, ef: initialEnrollments?.EF, ek: initialEnrollments?.EK,
            es: initialEnrollments?.ES, ec: initialEnrollments?.EC
          };
        }
      }
      else {
        obj['enrollments'] = { ee: 0, ef: 0, ek: 0, es: 0, ec: 0 };
      }
    }
    if (forType === "C") {
      obj['emplymntCtgryCd'] = empCat;
      obj['employmentClassCode'] = classCode;
      obj['wgsSubGroupNumber'] = "";
      return obj;
    }
    else {
      obj['emplymntCtgryCd'] = empCat;
      obj['employmentClassCode'] = "";
      obj['wgsSubGroupNumber'] = "";
      return obj;
    }
  }

  checkEmpCatExist(obj) {
    return this.checkEmpCatExistCommon(obj, [this.selectedRatingPlanID]);
  }

  checkEmpCatExistSuppHealth(obj) {
    return this.checkEmpCatExistCommon(obj, this.selectedRatingPlanIDs);
  }

  /**
   * Common method for checking existing empCat
   * This common function is a refactor of the previous checkEmpCatExist that takes an array of strings
   * @param obj
   * @param selectedRatingPlanIDs
   */
  checkEmpCatExistCommon(obj, selectedRatingPlanIDs) {
    return selectedRatingPlanIDs.some(selectedRatingPlanID => {
      let planEmpCat = this.responseData.find(x => x.ratingPlanID === selectedRatingPlanID).employmentCategory;
      if (planEmpCat?.length > 0) {
        for (let i = 0; i < planEmpCat.length; i++) {
          if (planEmpCat[i].employmentClassCode == null) {
            planEmpCat[i].employmentClassCode = '';
          }
        }
      }
      let isplanEmpCatExists = planEmpCat?.find(x => x.emplymntCtgryCd === obj.emplymntCtgryCd && x.employmentClassCode.toLowerCase() === obj.employmentClassCode.toLowerCase());
      if (isplanEmpCatExists)
        return true;
      else
        return false;
    })
  }

  checkDubEmpCatExist() {
    this.dubEmpCats = '';
    if (this.formData.employmentCategory) {
      for (let empCat of this.selectedEmpCategory) {
        let obj;
        if (this.soldRates_form.controls.classValue.value) {
          obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value);
        }
        else {
          obj = this.prepareEmpCatObj(empCat, 'WC', '');
        }
        if (this.checkEmpCatExist(obj)) {
          this.dubEmpCats = this.dubEmpCats + empCat + ', ';
        }
      }
    }
    if (this.dubEmpCats)
      return true;
    else
      return false;
  }

  checkDubEmpCatExistSuppHealth() {
    this.dubEmpCats = '';
    return this.formData.some(selectedProduct => {
      if (selectedProduct.employmentCategory) {
        for (let empCat of this.selectedEmpCategory) {
          let obj;
          if (this.soldRates_form.controls.classValue.value) {
            obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value);
          }
          else {
            obj = this.prepareEmpCatObj(empCat, 'WC', '');
          }
          if (this.checkEmpCatExistSuppHealth(obj)) {
            this.dubEmpCats = this.dubEmpCats + empCat + ', ';
          }
        }
      }
      if (this.dubEmpCats)
        return true;
      else
        return false;
    })
  }

  saveQLI() {
    if (StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)) {
      this.saveQLISuppHealth();
      return;
    }
    if (this.selectedContractCode && this.selectedLOB && this.selectedFundingType && this.soldRates_form.controls.caseNumber.value &&
      this.soldRates_form.controls.ccCodeOverride.value && this.selectedEmpCategory && this.selectedEmpCategory.length > 0 && this.checkActiveExist()) {
      this.isCaseNoSaved = true;
      this.savedCaseNumber = this.soldRates_form.controls.caseNumber.value;
      if (this.selectedLOB === 'Medical') {
        if (this.mapOfContractCodeAndSelectedEmpCategories && this.mapOfContractCodeAndSelectedEmpCategories.has(this.selectedContractCode)) {
          let employmentCategoryList = this.mapOfContractCodeAndSelectedEmpCategories.get(this.selectedContractCode);
          for (let addedEmpCategory of this.selectedEmpCategory) {
            if (!(employmentCategoryList.find(x => x === addedEmpCategory))) {
              employmentCategoryList.push(addedEmpCategory);
            }
          }
          this.mapOfContractCodeAndSelectedEmpCategories.delete(this.selectedContractCode);
          this.mapOfContractCodeAndSelectedEmpCategories.set(JSON.parse(JSON.stringify(this.selectedContractCode)), JSON.parse(JSON.stringify(employmentCategoryList)));
        } else {
          this.mapOfContractCodeAndSelectedEmpCategories.set(JSON.parse(JSON.stringify(this.selectedContractCode)), JSON.parse(JSON.stringify(this.selectedEmpCategory)));

        }
      }
      if (this.isRenewalLocal && StringUtils.isEmpty(this.selectedCurrentContractCode) && this.selectedLOB == 'Medical') {
        this.errorFlag = true;
        this.errorValue = SoldConstants.CURRENT_PLAN_SELECT_MSG;
      }else if(!this.planRetireeValidation(false)){
        this.errorFlag = true;
        this.errorValue = SoldConstants.RETIREE_VALIDATION_MSG;
      }
      else {
        for (let i = 0; i < this.selectedEmpCategory.length; i++) {
          this.isRateSplitsAvailable(this.formData, i);
        }
        if (this.selectedLOB === 'Medical') {
          this.showAdditionalProgramsPopUp = true;
        }
        if (!this.checkDubEmpCatExist()) {
          for (let empCat of this.selectedEmpCategory) {
            this.errorFlag = false;
            if (this.formData.employmentCategory) {
              let obj;
              if (this.soldRates_form.controls.classValue.value) {
                obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB);
              }
              else {
                obj = this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB);
              }
              this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value;
              this.updatedSoldRatePlan(obj, 'add', this.selectedRatingPlanID);
              this.soldCCvalueUpdated = this.soldCCvalue;
              obj['tierRate']={};
              obj.tierRate.eeRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat));
              obj.tierRate.esRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat));
              obj.tierRate.efRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat));
              obj.tierRate.ecRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat));
              obj.tierRate.ekRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat));

              this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).employmentCategory.push(obj);

            } else {
              let obj1;
              if (this.soldRates_form.controls.classValue.value) {
                obj1 = [this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB)];
              }
              else {
                obj1 = [this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB)];
              }
              this.selectedRatingPlanIdUpdate = '';
              this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value;
              this.updatedSoldRatePlan(obj1[0], 'add', this.selectedRatingPlanID);

              obj1.forEach(emplyCat => {
                emplyCat['tierRate']={};
                emplyCat.tierRate.eeRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat));
                emplyCat.tierRate.esRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat));
                emplyCat.tierRate.efRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat));
                emplyCat.tierRate.ecRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat));
                emplyCat.tierRate.ekRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat));
              });

              this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).employmentCategory = obj1;
            }
            this.lobAdded.set(this.selectedContractCode, this.selectedLOB);
          }
          if (!this.errorFlag) {

            this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value ? this.soldRates_form.controls.ccCodeOverride.value : this.selectedContractCode;
            this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID).currentContractCode = this.selectedCurrentContractCode;
            this.updateCaseNumberByLobAndFT(this.selectedLOB, this.selectedFundingType, 'C');

            this.refreshData();
            this.displayDialog = false;
            this.formReset();
          }
        } else {
          this.errorFlag = true;
          this.errorValue = "Entered Class already exists for the Category Code '" + this.dubEmpCats + "'";
        }
      }
    }
    else {
      if (!this.checkActiveExist())
        this.errorValue = "Please Select Employment Category Code Active to proceed";

      if (!this.selectedPlan)
        this.errorValue = "Please Select Plan";

      if (!this.soldRates_form.controls.ccCodeOverride.value)
        this.errorValue = "Please Enter Sold Contract Code to proceed";

      this.validateFormSaveCommon();

      this.errorFlag = true;
    }
    this.updateAdditionalProgramsAppliesTo();
    this.updateSubmitOptions();

  }

  validateFormSaveCommon() {
    if (!this.soldRates_form.controls.caseNumber.value)
      this.errorValue = "Please Enter Case Number to proceed";

    if (!this.selectedEmpCategory)
      this.errorValue = "Please Select Employment Category Code";

    if (!this.selectedPlanType)
      this.errorValue = "Please Select Plan Type";

    if (!this.selectedFundingType)
      this.errorValue = "Please Select Sold Funding Type";

    if (!this.selectedLOB)
      this.errorValue = "Please Select LOB";

    else if (!this.errorValue && !this.planRetireeValidation(false))
      this.errorValue = SoldConstants.RETIREE_VALIDATION_MSG;
  }

  saveQLISuppHealth(){
    if (this.selectedContractCodes
      && this.selectedLOB && this.selectedFundingType
      && this.soldRates_form.controls.caseNumber.value
      && this.soldRates_form.controls.ccCodeOverride.value
      && this.selectedEmpCategory && this.selectedEmpCategory.length > 0
      && this.checkActiveExistSuppHealth()) {
      this.errorFlag = false;
      this.isCaseNoSaved = true;
      this.savedCaseNumber = this.soldRates_form.controls.caseNumber.value;
      if (!this.checkDubEmpCatExistSuppHealth()) {
        for (let empCat of this.selectedEmpCategory) {
          this.errorFlag = false;
          if (this.formData && this.formData.length > 0) {
            this.formData.forEach((selectedProduct, index) => {
              if (selectedProduct.employmentCategory) {
                let obj;
                if (this.soldRates_form.controls.classValue.value) {
                  obj = this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB);
                } else {
                  obj = this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB);
                }
                this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value.split(", ")[index];
                this.updatedSoldRatePlan(obj, 'add', selectedProduct.ratingPlanID);
                this.soldCCvalueUpdated = this.soldCCvalue;

                if (selectedProduct.ageBandTierRates) {
                  let employmentCategoryCodeAgeBands = [];
                  const ageBandTierRates = selectedProduct.ageBandTierRates.sort((a, b) => a.ageBandStart - b.ageBandStart);
                  ageBandTierRates.forEach(ageBand => {
                    let ageBands = JSON.parse(JSON.stringify(obj));
                    ageBands.ageBand = `${ageBand.ageBandStart}-${ageBand.ageBandEnd}`;
                    const tierRates = {
                      eeRate:  this.roundValueToTwoDecimals(ageBand.eeRate * this.getEmpCategoryFactor(empCat)),
                      esRate:  this.roundValueToTwoDecimals(ageBand.esRate *  this.getEmpCategoryFactor(empCat)),
                      efRate:  this.roundValueToTwoDecimals(ageBand.efRate *  this.getEmpCategoryFactor(empCat)),
                      ecRate:  this.roundValueToTwoDecimals(ageBand.ecRate *  this.getEmpCategoryFactor(empCat)),
                      ekRate:  this.roundValueToTwoDecimals(ageBand.ekRate *  this.getEmpCategoryFactor(empCat))
                    };
                    ageBands.tierRate = tierRates;
                    employmentCategoryCodeAgeBands.push(ageBands);
                  })
                  this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).employmentCategory.push(...employmentCategoryCodeAgeBands);
                } else {
                  obj['tierRate']={};
                  obj.tierRate.eeRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat));
                  obj.tierRate.esRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat));
                  obj.tierRate.efRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat));
                  obj.tierRate.ecRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat));
                  obj.tierRate.ekRate = this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat));
                  this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).employmentCategory.push(obj);
                }
              } else {
                let obj1;
                if (this.soldRates_form.controls.classValue.value) {
                  obj1 = [this.prepareEmpCatObj(empCat, 'C', this.soldRates_form.controls.classValue.value, this.selectedLOB)];
                } else {
                  obj1 = [this.prepareEmpCatObj(empCat, 'WC', '', this.selectedLOB)];
                }
                this.selectedRatingPlanIdUpdate = '';
                this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).contractCode = this.soldRates_form.controls.ccCodeOverride.value.split(", ")[index];
                this.updatedSoldRatePlan(obj1[0], 'add', selectedProduct.ratingPlanID);
                obj1.forEach(emplyCat => {
                  emplyCat['tierRate'] = {};
                  if (selectedProduct.ageBandTierRates) {
                    const ageBands = selectedProduct.ageBandTierRates.sort((a, b) => a.ageBandStart - b.ageBandStart);
                    ageBands.forEach((ageBand, index) => {
                      const ageBandRange = `${ageBand.ageBandStart}-${ageBand.ageBandEnd}`;
                      const tierRates = {
                        eeRate: this.roundValueToTwoDecimals(ageBand.eeRate * this.getEmpCategoryFactor(empCat)),
                        esRate: this.roundValueToTwoDecimals(ageBand.esRate * this.getEmpCategoryFactor(empCat)),
                        efRate: this.roundValueToTwoDecimals(ageBand.efRate * this.getEmpCategoryFactor(empCat)),
                        ecRate: this.roundValueToTwoDecimals(ageBand.ecRate * this.getEmpCategoryFactor(empCat)),
                        ekRate: this.roundValueToTwoDecimals(ageBand.ekRate * this.getEmpCategoryFactor(empCat))
                      }
                      if (index === 0) {
                        emplyCat.ageBand = ageBandRange;
                        emplyCat.tierRate = tierRates;
                      } else {
                        let ageBandRow = JSON.parse(JSON.stringify(emplyCat));
                        ageBandRow.ageBand = ageBandRange;
                        ageBandRow.tierRate = tierRates;
                        obj1.push(ageBandRow);
                      }
                    })
                  } else {
                    emplyCat.tierRate.eeRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.eeRate * this.getEmpCategoryFactor(empCat));
                    emplyCat.tierRate.esRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.esRate * this.getEmpCategoryFactor(empCat));
                    emplyCat.tierRate.efRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.efRate * this.getEmpCategoryFactor(empCat));
                    emplyCat.tierRate.ecRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ecRate * this.getEmpCategoryFactor(empCat));
                    emplyCat.tierRate.ekRate =  this.roundValueToTwoDecimals(this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).tierRate.ekRate * this.getEmpCategoryFactor(empCat));
                  }
                });

                this.responseData.find(x => x.ratingPlanID === selectedProduct.ratingPlanID).employmentCategory = obj1;
              }
              this.lobAdded.set(selectedProduct.quotedContractCode, this.selectedLOB);
            })
          }
        }
        if (!this.errorFlag) {
          this.selectedRatingPlanIDs.forEach((selectedRatingPlanID, index) => {
            this.responseData.find(plan => plan.ratingPlanID === selectedRatingPlanID).contractCode
              = this.soldRates_form.controls.ccCodeOverride.value ? this.soldRates_form.controls.ccCodeOverride.value.split(", ")[index] :
              this.findContractCodeByRatingPlanID(this.selectedProducts, selectedRatingPlanID).contractCode;
          })

          this.selectedRatingPlanIDs.forEach(selectedRatingPlanID => {
            this.responseData.find(plan => plan.ratingPlanID === selectedRatingPlanID).currentContractCode
              = this.findContractCodeByRatingPlanID(this.selectedProducts, selectedRatingPlanID).contractCode;
          })
          this.updateCaseNumberByLobAndFT(this.selectedLOB, this.selectedFundingType, 'C');

          this.refreshData();
          this.displayDialog = false;
          this.formReset();
        }
      } else {
        this.errorFlag = true;
        this.errorValue = "Entered Class already exists for the Category Code '" + this.dubEmpCats + "'";
      }
    } else {
      if (!this.checkActiveExistSuppHealth())
        this.errorValue = "Please Select Employment Category Code Active to proceed";
      if (this.selectedProducts && this.selectedProducts.length === 0)
        this.errorValue = "Please Select Products";
      if (!this.soldRates_form.controls.ccCodeOverride.value)
        this.errorValue = "Please Enter Sold Contract Code to proceed";
      this.validateFormSaveCommon();

      this.errorFlag = true;
    }
    this.updateAdditionalProgramsAppliesTo();
    this.updateSubmitOptions();
  }

  findContractCodeByRatingPlanID(selectedProducts: any[], ratingPlanID: string){
    return selectedProducts.find((selectedProduct) => selectedProduct.ratingPlanID === ratingPlanID);
  }
  omit_special_char(event) {
    var k;
    k = event.charCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
  }

  onPaste(event: ClipboardEvent) {
    event.preventDefault(); 
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    let trimmedText = pastedText.replace(/[^a-zA-Z0-9]/g, '');
    let inputElement = <HTMLInputElement>document.getElementById('caseNumber');
    inputElement.value = trimmedText;
    this.caseNumber = trimmedText;
  }

  updateCaseNumberByLobAndFT(lob, FT, type) {
    for (let resp of this.responseData) {
      if (lob === resp.lob && FT === resp.fundingType) {
        if (type === 'C')
          resp['caseNumber'] = this.soldRates_form.controls.caseNumber.value;
        else if (type === 'U') {
          resp['caseNumber'] = this.soldRates_form.controls.caseNumberUpdate.value;
          this.soldRateFullResponse.caseNumber = this.soldRates_form.controls.caseNumberUpdate.value;
        }
      }
    }
  }

  prepareRemoveObj(selectedRow, selectedEmpCat) {
    var rowObj = {
      "quotedContractCode": selectedRow.quotedContractCode,
      "contractCode": selectedRow.contractCode,
      "lob": selectedRow.lob,
      "fundingType": selectedRow.fundingType,
      "emplymntCtgryCd": selectedEmpCat.emplymntCtgryCd,
      "employmentClassCode": selectedEmpCat.employmentClassCode
    };

    this.contractCodeRemove = selectedRow.quotedContractCode;
    return rowObj;
  }

  addRowToRemove(selectedRow, selectedEmpCat, event) {
    if (event.target.checked) {
      var rowObj = this.prepareRemoveObj(selectedRow, selectedEmpCat);
      this.selectedRowsToRemove.push(rowObj);
      if (selectedEmpCat.emplymntCtgryCd === 'Active') {
        if (selectedRow.lob === 'Medical')
          this.medActiveRemoved.set(selectedRow.contractCode, true);
        if (selectedRow.lob === 'Vision')
          this.visActiveRemoved.set(selectedRow.contractCode, true);
        if (selectedRow.lob === 'Dental')
          this.denActiveRemoved.set(selectedRow.contractCode, true);
        if (selectedRow.lob === RareConstants.suppHealth)
          this.shpActiveRemoved.set(selectedRow.contractCode, true);

      }

    }
    else {
      var removeRowObj = this.prepareRemoveObj(selectedRow, selectedEmpCat);
      if (selectedEmpCat.emplymntCtgryCd === 'Active') {
        if (selectedRow.lob === 'Medical')
          this.medActiveRemoved.set(selectedRow.contractCode, false);
        if (selectedRow.lob === 'Vision')
          this.visActiveRemoved.set(selectedRow.contractCode, false);
        if (selectedRow.lob === 'Dental')
          this.denActiveRemoved.set(selectedRow.contractCode, false);
        if (selectedRow.lob === RareConstants.suppHealth)
          this.shpActiveRemoved.set(selectedRow.contractCode, false);

      }

      for (var i = 0; i < this.selectedRowsToRemove.length; i++) {
        if (this.selectedRowsToRemove[i].quotedContractCode == removeRowObj.quotedContractCode &&
          this.selectedRowsToRemove[i].fundingType == removeRowObj.fundingType &&
          this.selectedRowsToRemove[i].employmentClassCode == removeRowObj.employmentClassCode) {
          this.selectedRowsToRemove.splice(i, 1);
        }
      }
    }
  }

  removeRows() {
    this.planTypesAdditional = [];
    for (var j = 0; j < this.selectedRowsToRemove.length; j++) {
      for (var i = 0; i < this.responseData.length; i++) {
        if (this.responseData[i] && this.selectedRowsToRemove[j]) {
          if (StringUtils.isEqualIgnoreCase(this.selectedRowsToRemove[j].quotedContractCode, this.responseData[i].quotedContractCode) &&
            StringUtils.isEqualIgnoreCase(this.selectedRowsToRemove[j].fundingType, this.responseData[i].fundingType)) {
            if (this.isRenewalLocal && StringUtils.isEqualIgnoreCase(this.responseData[i].lob, RareConstants.medical) && StringUtils.isEqualIgnoreCase(this.selectedRowsToRemove[j].emplymntCtgryCd.toLowerCase(), SoldConstants.ACTIVE)) {
              delete this.responseData[i].currentContractCode;
            }
            if (StringUtils.isEqualIgnoreCase(this.selectedRowsToRemove[j].emplymntCtgryCd.toLowerCase(), "active") &&
              StringUtils.isEqualIgnoreCase(this.selectedRowsToRemove[j].lob, this.responseData[i].lob) &&
              StringUtils.isEqualIgnoreCase(this.selectedRowsToRemove[j].fundingType, this.responseData[i].fundingType)) {
              this.responseData[i].contractCode = this.responseData[i].quotedContractCode;
              this.responseData[i].planIsRemoved = true;
              this.responseData[i].additionalPrograms = null;
              let selectedItemsForRemoval = [];
              let updatedPlansList = []
              for (let k = 0; k < this.responseData[i].employmentCategory.length; k++) {
                if (StringUtils.isEqualIgnoreCase(this.responseData[i].lob, RareConstants.medical)) {
                  let key = this.responseData[i].contractCodePlanName + '|' + this.responseData[i].employmentCategory[k].emplymntCtgryCd;
                  if (this.mapOfContractCodeAndAdditionalProgram && this.mapOfContractCodeAndAdditionalProgram.has(key)) {
                    this.mapOfContractCodeAndAdditionalProgram.delete(key);
                  }
                }
                // on click remove button rateSplits and additionalPrograms
                if (StringUtils.isEqualIgnoreCase(this.responseData[i].lob , RareConstants.medical) && this.responseData[i].rateSplits !== null) {
                  this.responseData[i].rateSplits = null;
                  this.responseData[i].additionalPrograms = null;
                }
                if (this.selectedRowsToRemove[j].wgsSubGroupNumber == this.responseData[i].wgsSubGroupNumber
                  && this.selectedRowsToRemove[j].employmentClassCode == this.responseData[i].employmentCategory[k].employmentClassCode) {
                  selectedItemsForRemoval.push(this.responseData[i].employmentCategory[k]);
                  this.lob = this.selectedRowsToRemove[j].lob;
                  for (let index = 0; index <= selectedItemsForRemoval.length - 1; index++) {
                    selectedItemsForRemoval[index].quotedContractCode = this.selectedRowsToRemove[j].quotedContractCode;
                    selectedItemsForRemoval[index].contractCode = this.selectedRowsToRemove[j].contractCode;
                    selectedItemsForRemoval[index].ratingPlanId = this.responseData[i].ratingPlanID;
                  }

                } else {
                  updatedPlansList.push(this.responseData[i].employmentCategory[k]);
                  if (StringUtils.isEqualIgnoreCase(this.responseData[i].lob , RareConstants.medical)) {
                    this.getIncludeInRates(this.responseData[i].fundingType);
                    this.planTypesAdditional.push({
                      'label': this.responseData[i].employmentCategory[k].contractCodePlanName,
                      'value': this.responseData[i].employmentCategory[k].contractCodePlanName
                    })
                  }
                }
              }

              this.responseData[i].employmentCategory = updatedPlansList;
              this.updatedSoldRatePlan(selectedItemsForRemoval, 'Remove', '');
            } else {
              if (this.responseData[i] && this.responseData[i].employmentCategory) {
                for (let k = 0; k < this.responseData[i].employmentCategory.length; k++) {
                  if (this.selectedRowsToRemove[j] &&
                    this.responseData[i].employmentCategory[k] &&
                    this.selectedRowsToRemove[j].emplymntCtgryCd == this.responseData[i].employmentCategory[k].emplymntCtgryCd &&
                    this.selectedRowsToRemove[j].employmentClassCode == this.responseData[i].employmentCategory[k].employmentClassCode) {
                    let deletedRow = this.responseData[i].employmentCategory.splice(k, 1);
                    deletedRow[0].contractCode = this.selectedRowsToRemove[j].contractCode;
                    this.lob = this.selectedRowsToRemove[j].lob;
                    if (StringUtils.isEqualIgnoreCase(this.lob, RareConstants.medical)) {
                      let key = this.responseData[i].contractCodePlanName + '|' + this.selectedRowsToRemove[j].emplymntCtgryCd;
                      if (this.mapOfContractCodeAndAdditionalProgram && this.mapOfContractCodeAndAdditionalProgram.has(key)) {
                        this.mapOfContractCodeAndAdditionalProgram.delete(key);
                      }
                    if (this.mapOfContractCodeAndSelectedEmpCategories && this.mapOfContractCodeAndSelectedEmpCategories.has(this.selectedRowsToRemove[j].contractCode)) {
                      let employmentCategoryList = this.mapOfContractCodeAndSelectedEmpCategories.get(this.selectedRowsToRemove[j].contractCode);
                      let index = employmentCategoryList.indexOf(this.empCatValueUpdateX);
                      employmentCategoryList.splice(index, 1);
                      this.mapOfContractCodeAndSelectedEmpCategories.delete(this.selectedRowsToRemove[j].contractCode);
                      this.mapOfContractCodeAndSelectedEmpCategories.set(JSON.parse(JSON.stringify(this.selectedRowsToRemove[j].contractCode)), JSON.parse(JSON.stringify(employmentCategoryList)))
                    }
                  }
                    this.updatedSoldRatePlan(deletedRow, 'Remove', '');
                  }
                }
              }
            }
          }
        }
      }

    }

    this.updateAdditionalProgramsAppliesTo();
    this.updateSubmitOptions();
    this.formReset();
    this.selectedRowsToRemove = [];

  }

  updateAdditionalProgramsAppliesTo() {
    this.planTypesAdditional = [];
    for (let p of this.rowData) {
      if (p.employmentCategory.length > 0 && StringUtils.isEqualIgnoreCase(p.lob ,RareConstants.medical)) {
        this.getIncludeInRates(p.fundingType);
        this.planTypesAdditional.push({
          'label': p.contractCodePlanName,
          'value': p.contractCodePlanName
        })
      }
    }
  }

  // update
  displayDialogUpdate: boolean = false;
  disableUpdate: boolean = false;
  errorFlagUpdate: boolean = false;
  categoryListUpdate: any[] = [];
  planValueUpdate;
  planValueUpdateX;
  lobUpdate;
  CCValueUpdate;
  CCCValueUpdate;
  soldCCvalueUpdated;
  soldCCvalue;
  staticContractcode;
  empCatValueUpdate;
  empCatValueUpdateX;
  errorValueUpdate;
  formDataUpdate;
  empCategoryDataUpdate;
  empCategoryFactorUpdate;
  employmentClassCodeX;
  selectCCValueUpdate;
  fundingTypeUpdate;
  ratingPlanIdUpdate;
  selectCCCValueUpdate;
  findRatingPlanID(contractCode, planName, lob, fundType) {
    return this.responseData.find(x => x.quotedContractCode === contractCode && x.productName === planName && x.lob === lob && x.fundingType === fundType).ratingPlanID;
  }
  getRatesByCCCUpdate(contract) {
    this.selectedCurrentContractCode = contract.value;
    this.selectCCCValueUpdate = contract.value
  }
  showDialogToUpdate(SelectedRow, SelectedEmpCat) {
    this.formReset();
    this.refreshPlanDropdown();
    this.errorFlagUpdate = false;
    this.errorValueUpdate = null;
    this.displayDialogUpdate = true;
    this.selectPlanValueUpdate = SelectedRow.productName;
    this.soldCCvalueUpdated = SelectedRow.contractCode ? SelectedRow.contractCode : SelectedRow.quotedContractCode;
    this.planValueUpdate = {
      "quotedContractCode": SelectedRow.quotedContractCode,
      "productName": this.selectPlanValueUpdate,
      "contractCode": this.soldCCvalueUpdated,
    };
    this.selectedRatingPlanIdUpdate = this.ratingPlanIdUpdate = this.findRatingPlanID(SelectedRow.quotedContractCode, SelectedRow.productName, SelectedRow.lob, SelectedRow.fundingType);
    this.planValueUpdateX = SelectedRow.quotedContractCode;
    this.lobUpdate = SelectedRow.lob;
    this.fundingTypeUpdate = SelectedRow.fundingType;
    this.CCValueUpdate = {
      "label": SelectedRow.quotedContractCode,
      "value": SelectedRow.quotedContractCode
    };
    if (this.isRenewalLocal && StringUtils.isEqualIgnoreCase(this.lobUpdate ,RareConstants.medical)) {
      if (StringUtils.isEmpty(SelectedRow.currentContractCode)) {
        this.CCCValueUpdate = "";
        this.selectedCurrentContractCode = ""
      }
      else{
      this.soldRateFullResponse.currentPlans.forEach(soldRateFullResponseCurrentPlans => {
        if (soldRateFullResponseCurrentPlans.contractCode == SelectedRow.currentContractCode) {
          this.CCCValueUpdate = {
            "label": soldRateFullResponseCurrentPlans.planName,
            "value": SelectedRow.currentContractCode
          }
        }
      })
      this.selectedCurrentContractCode = this.CCCValueUpdate?.value
    }
      this.selectCCCValueUpdate = SelectedRow?.currentContractCode
    }
    this.selectCCValueUpdate = SelectedRow.quotedContractCode;
    this.empCatValueUpdate = SelectedEmpCat.emplymntCtgryCd;
    this.empCatValueUpdateX = SelectedEmpCat.emplymntCtgryCd;
    this.employmentClassCodeX = SelectedEmpCat.employmentClassCode;
    this.soldRates_form.controls.caseNumberUpdate.setValue(SelectedRow.caseNumber);
    this.caseNumberUpdate = SelectedRow.caseNumber;
    if (SelectedEmpCat.employmentClassCode)
      this.soldRates_form.controls.classValueUpdate.setValue(SelectedEmpCat.employmentClassCode);
    else
      this.soldRates_form.controls.classValueUpdate.setValue('');

    if (this.empCatValueUpdate.toLowerCase() === 'active') {
      this.disableUpdate = true;
    }
    else {
      this.disableUpdate = false;
    }

    this.categoryListUpdate = [];
    this.categoryListUpdate = this.getCategoryList(this.lobUpdate, 'U');

    this.getCategoryUpdate(this.empCatValueUpdate);
  }
  selectPlanValueUpdate;
  getRatesUpdate(value) {
    this.selectPlanValueUpdate = this.getPlanName(this.planName, value);
    let contractData = this.getPlanData(this.responseData, value);
    this.lobUpdate = contractData.lob;
    this.CCValueUpdate = {
      'label': contractData.quotedContractCode,
      'value': contractData.quotedContractCode
    };
    this.soldCCvalueUpdated = contractData.quotedContractCode;
    this.selectCCValueUpdate = this.CCValueUpdate.value;
    this.empCatValueUpdate = "";

    let empCat = this.getPlanData(this.responseData, this.selectCCValueUpdate);
    if (!empCat.employmentCategory || empCat.employmentCategory.length === 0) {
      this.categoryListUpdate = [];
      this.categoryListUpdate.push("Active");
    }
    else {
      this.categoryListUpdate = [];
      this.categoryListUpdate = this.getCategoryList(this.lobUpdate, 'U');
    }
  }
  getRatesByCCUpdate(value) {
    this.CCValueUpdate = value;
    this.soldCCvalueUpdated = value;
    this.selectCCValueUpdate = this.CCValueUpdate.value;
    let planData = this.getPlanData(this.responseData, this.selectCCValueUpdate);
    this.lobUpdate = planData.lob;
    this.selectPlanValueUpdate = planData.productName || "";
    this.planValueUpdate = {
      "quotedContractCode": this.CCValueUpdate.value,
      "contractCode": this.soldCCvalueUpdated,
      "productName": this.selectPlanValueUpdate
    };
    this.empCatValueUpdate = "";

  }
  getCategoryUpdate(value) {
    this.empCatValueUpdate = value;
    this.errorFlagUpdate = false;
    this.formDataUpdate = this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate);
    if (this.lobUpdate.toLowerCase() === RareConstants.medicalLC && this.soldRateFullResponse.employmentCategoryMedical) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategoryMedical.find(x => x.emplymntCtgryCd === value);
    }

    if (this.lobUpdate.toLowerCase() === RareConstants.visionLC && this.soldRateFullResponse.employmentCategoryVision) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategoryVision.find(x => x.emplymntCtgryCd === value);
    }

    if (this.lobUpdate.toLowerCase() === RareConstants.dentalLC && this.soldRateFullResponse.employmentCategoryDental) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategoryDental.find(x => x.emplymntCtgryCd === value);
    }

    if (StringUtils.isEqualIgnoreCase(this.lobUpdate, RareConstants.suppHealth) && this.soldRateFullResponse.employmentCategorySuppHealth) {
      this.empCategoryDataUpdate = this.soldRateFullResponse.employmentCategorySuppHealth.find(x => x.emplymntCtgryCd === value);
    }

    this.empCategoryFactorUpdate = this.empCategoryDataUpdate.emplymntCtgryFctr;


  }

  isplanEmpCatExists(planEmpCat) {
    return planEmpCat.find(x => x.emplymntCtgryCd === this.empCatValueUpdate && x.employmentClassCode.toLowerCase() === this.soldRates_form.controls.classValueUpdate.value.toLowerCase());
  }

  updateQLI() {
    this.errorFlagUpdate = false;
    this.errorValueUpdate = null;
    if (this.CCValueUpdate && this.lobUpdate && this.empCatValueUpdate && this.caseNumberUpdate && this.soldCCvalueUpdated) {
      this.isCaseNoSaved = true;
      this.savedCaseNumber = this.caseNumberUpdate;
      if (this.isRenewalLocal && StringUtils.isEqualIgnoreCase(this.lobUpdate ,RareConstants.medical) && StringUtils.isEmpty(this.CCCValueUpdate)) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = SoldConstants.CURRENT_PLAN_SELECT_MSG;
        return;
      }
      let obj;
      let obj1;
      if (this.soldRates_form.controls.classValueUpdate.value) {
        obj = this.prepareEmpCatObj(this.empCatValueUpdate, 'C', this.soldRates_form.controls.classValueUpdate.value, this.lobUpdate);
        obj1 = [this.prepareEmpCatObj(this.empCatValueUpdate, 'C', this.soldRates_form.controls.classValueUpdate.value, this.lobUpdate)];
      }
      else {
        obj = this.prepareEmpCatObj(this.empCatValueUpdate, 'WC', '', this.lobUpdate);
        obj1 = [this.prepareEmpCatObj(this.empCatValueUpdate, 'WC', '', this.lobUpdate)];
      }
      this.selectedRatingPlanIdUpdate = '';
      let isplanEmpCatClassCodeExists = [];
      let planEmpCat = this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory;
      if (!this.errorFlagUpdate && !this.planRetireeValidation(true)) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = SoldConstants.RETIREE_VALIDATION_MSG;
        return;
      }

      if (planEmpCat) {
        obj['tierRate']={};
        const product = this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate);

        if (product.tierRate){
          obj['tierRate'].eeRate =  this.roundValueToTwoDecimals(product.tierRate.eeRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
          obj['tierRate'].esRate =  this.roundValueToTwoDecimals(product.tierRate.esRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
          obj['tierRate'].efRate =  this.roundValueToTwoDecimals(product.tierRate.efRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
          obj['tierRate'].ecRate =  this.roundValueToTwoDecimals(product.tierRate.ecRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
          obj['tierRate'].ekRate =  this.roundValueToTwoDecimals(product.tierRate.ekRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
        }

        obj1.forEach(ele => {
            if(ele.emplymntCtgryCd===this.empCatValueUpdate){
                ele['tierRate']={};
                const productUpdate = this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate);
                if (productUpdate.tierRate) {
                  ele['tierRate'].eeRate =  this.roundValueToTwoDecimals(productUpdate.tierRate.eeRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
                  ele['tierRate'].esRate =  this.roundValueToTwoDecimals(productUpdate.tierRate.esRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
                  ele['tierRate'].efRate =  this.roundValueToTwoDecimals(productUpdate.tierRate.efRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
                  ele['tierRate'].ecRate =  this.roundValueToTwoDecimals(productUpdate.tierRate.ecRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
                  ele['tierRate'].ekRate =  this.roundValueToTwoDecimals(productUpdate.tierRate.ekRate * this.getEmpCategoryFactor(this.empCatValueUpdate,this.lobUpdate));
                }
            }
        });

        this.updatedSoldRatePlan(obj, 'update', this.ratingPlanIdUpdate);
        isplanEmpCatClassCodeExists = planEmpCat.filter(x => x.emplymntCtgryCd === obj.emplymntCtgryCd && x.employmentClassCode === obj.employmentClassCode);
        let isExistingClassCode = planEmpCat.find(x => x.employmentClassCode === obj.employmentClassCode);
        if (isplanEmpCatClassCodeExists.length && this.employmentClassCodeX !== this.soldRates_form.controls.classValueUpdate.value) {
          this.errorFlagUpdate = true;
          this.errorValueUpdate = 'Given Employment Category Code with given classcode already exists';
          return;
        }
        else {
          if (!isExistingClassCode && obj.emplymntCtgryCd === "Active") {
            if (planEmpCat.find(x => x.employmentClassCode === this.employmentClassCodeX && x.emplymntCtgryCd === obj.emplymntCtgryCd)) {
              for (let num = 0; num < planEmpCat.length; num++) {
                if (planEmpCat[num].employmentClassCode === this.employmentClassCodeX) {
                  planEmpCat[num].employmentClassCode = this.soldRates_form.controls.classValueUpdate.value;
                }
              }
            }
          } else if (!isExistingClassCode && obj.emplymntCtgryCd !== "Active") {
            if (planEmpCat.find(x => x.employmentClassCode === this.employmentClassCodeX && x.emplymntCtgryCd === obj.emplymntCtgryCd)) {
              for (let num = 0; num < planEmpCat.length; num++) {
                if (planEmpCat[num].employmentClassCode === this.employmentClassCodeX) {
                  planEmpCat[num].employmentClassCode = this.soldRates_form.controls.classValueUpdate.value;
                }
              }
            }
            else {
              this.errorFlagUpdate = true;
              this.errorValueUpdate = 'Please Select Employment Category Code Active to proceed';
              return;
            }
          }
          else {
            for (let num = 0; num < planEmpCat.length; num++) {
              if (planEmpCat[num].employmentClassCode === this.employmentClassCodeX && planEmpCat[num].emplymntCtgryCd === obj.emplymntCtgryCd) {
                planEmpCat[num].employmentClassCode = this.soldRates_form.controls.classValueUpdate.value;
              }
            }
            if (this.isRenewalLocal && this.lobUpdate == 'Medical' && planEmpCat.find(planEmpCat => planEmpCat.emplymntCtgryCd === obj.emplymntCtgryCd))
              planEmpCat.find(planEmpCat => planEmpCat.emplymntCtgryCd === obj.emplymntCtgryCd).enrollments = obj?.enrollments;
          }
        }
      }

      //Handle Scenario - If plan is removed and without save and then same plan is added
      this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).planIsRemoved = false;

      if (this.isplanEmpCatExists(planEmpCat)) {
        if (this.soldCCvalueUpdated && this.soldRates_form.controls.ccCodeOverrideUpdate.value && this.soldCCvalueUpdated === this.soldRates_form.controls.ccCodeOverrideUpdate.value) {
          this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).contractCode = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
          if (this.isRenewalLocal && StringUtils.isEqualIgnoreCase(this.lobUpdate ,RareConstants.medical))
            this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).currentContractCode = this.CCCValueUpdate?.value;
          this.updateCaseNumberByLobAndFT(this.lobUpdate, this.fundingTypeUpdate, 'U');
          this.displayDialogUpdate = false;
          this.refreshData();
          this.refreshPlanDropdown();
        } else if (!this.soldRates_form.controls.ccCodeOverrideUpdate.value) {
          this.responseData.find(x => x.contractCode !== this.soldCCvalueUpdated).contractCode = null;
          this.updateCaseNumberByLobAndFT(this.lobUpdate, this.fundingTypeUpdate, 'U');
          this.displayDialogUpdate = false;
          this.refreshData();
          this.refreshPlanDropdown();
        }
        else {
          this.errorFlagUpdate = true;
          this.errorValueUpdate = 'Given Employment Category Code is already exists';
          this.displayDialogUpdate = true;
        }
      }
      else {
        if (this.soldRates_form.controls.ccCodeOverrideUpdate.value && this.soldCCvalueUpdated !== this.soldRates_form.controls.ccCodeOverrideUpdate.value) {
          this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).contractCode = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
          this.selectCCValueUpdate = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
          this.planValueUpdateX = this.soldRates_form.controls.ccCodeOverrideUpdate.value;
        }
        if (planEmpCat) {
          this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory.push(obj);
        } else {
          this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory = obj1;
        }
        let planEmpCatX = this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory;
        let isplanEmpCatExistsX = planEmpCatX.find(x => x.emplymntCtgryCd === this.empCatValueUpdateX && x.employmentClassCode === this.employmentClassCodeX);

        if (isplanEmpCatExistsX) {
          for (var i = 0; i < planEmpCatX.length; i++) {
            if (planEmpCatX[i].emplymntCtgryCd == this.empCatValueUpdateX &&
              planEmpCatX[i].employmentClassCode == this.employmentClassCodeX) {
              this.responseData.find(x => x.ratingPlanID === this.ratingPlanIdUpdate).employmentCategory.splice(i, 1);
            }
          }
        }
        if (this.mapOfContractCodeAndSelectedEmpCategories && this.mapOfContractCodeAndSelectedEmpCategories.has(this.soldRates_form.controls.ccCodeOverrideUpdate.value) &&
          this.lobUpdate === 'Medical') {
          let employmentCategoryList = this.mapOfContractCodeAndSelectedEmpCategories.get(this.soldRates_form.controls.ccCodeOverrideUpdate.value);
          let index = employmentCategoryList.indexOf(this.empCatValueUpdateX);
          employmentCategoryList.splice(index, 1);
          employmentCategoryList.push(this.empCatValueUpdate);
          this.mapOfContractCodeAndSelectedEmpCategories.delete(this.soldRates_form.controls.ccCodeOverrideUpdate.value);
          this.mapOfContractCodeAndSelectedEmpCategories.set(JSON.parse(JSON.stringify(this.soldRates_form.controls.ccCodeOverrideUpdate.value)), JSON.parse(JSON.stringify(employmentCategoryList)))

        }
        this.updateCaseNumberByLobAndFT(this.lobUpdate, this.fundingTypeUpdate, 'U');
        this.refreshData();
        this.refreshPlanDropdown();
        this.displayDialogUpdate = false;
      }
    }
    else {
      if (!this.caseNumberUpdate) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = 'Please Enter Case Number';
      }
      if (!this.soldCCvalueUpdated) {
        this.errorFlagUpdate = true;
        this.errorValueUpdate = 'Please Enter Contract Code';
      }
    }
  }
  // update


  errorFlag: boolean = false;
  additionalProgramErrorFlag: boolean = false;
  dataReset() {
    this.formData = null;
    this.empCategoryData = null;
    this.empCategoryFactor = 1;
    this.selectedEmpCategory = null;
  }
  formReset() {
    this.contractCodes = this.contractCodeBackup;
    this.planName = this.planNamesBackup;
    this.selectedPlan = null;
    this.selectedLOB = "";
    this.selectedPlanType = "";
    this.selectedRatingPlanID = "";
    this.selectedFundingType = "";
    this.selectedContractCode = null;
    this.formData = null;
    this.empCategoryData = null;
    this.empCategoryFactor = 1;
    this.selectedEmpCategory = null;
    this.planValue = "";
    this.CCValue = "";
    this.CCCValue = "";
    this.errorFlag = false;
    this.soldRates_form.controls.classValue.setValue('');
    this.soldRates_form.controls.ccCodeOverride.setValue('');
    this.soldRates_form.controls.caseNumber.setValue('');
    this.caseNumber = "";
    this.selectedRatingPlanIdUpdate = '';
    this.selectedProducts = null;
    this.selectedContractCodes = null;
    this.selectedRatingPlanIDs = null;
  }

  preparePlanData(selectedPlan, planType, currentDate, selectedRatingPlanId) {
    let quotedContractCode; let contractCode, currentContractCode;
    if (planType !== 'Remove') {
      if (this.CCValue.value) quotedContractCode = this.CCValue.value;
      else if (this.CCValueUpdate) quotedContractCode = this.CCValueUpdate.value;
      else quotedContractCode = this.contractCodeRemove;
      if (this.soldRates_form.controls.ccCodeOverride.value) contractCode = this.soldRates_form.controls.ccCodeOverride.value;
      else if (this.soldCCvalueUpdated) contractCode = this.soldCCvalueUpdated;
      else contractCode = quotedContractCode;
      if (this.CCCValue.value) currentContractCode = this.CCCValue.value;
      else if (this.CCCValueUpdate) currentContractCode = this.CCCValueUpdate.value;
      else currentContractCode = this.contractCodeRemove;
    }
    else {
      quotedContractCode = selectedPlan.quotedContractCode;
      contractCode = selectedPlan.contractCode;
      currentContractCode = selectedPlan?.currentContractCode;
    }
    return {
      performedTime: currentDate,
      currentContractCode: currentContractCode ? currentContractCode : '',
      quotedContractCode: quotedContractCode ? quotedContractCode : '',
      empcategorycode: selectedPlan.emplymntCtgryCd ? selectedPlan.emplymntCtgryCd : '',
      empClass: selectedPlan.employmentClassCode ? selectedPlan.employmentClassCode : '',
      LOB: this.selectedLOB ? this.selectedLOB : this.lobUpdate ? this.lobUpdate : this.lob,
      action: planType,
      contractCode: contractCode ? contractCode : quotedContractCode,
      caseNumber: this.caseNumber ? this.caseNumber : this.caseNumberUpdate ? this.caseNumberUpdate : '',
      ratingPlanId: selectedRatingPlanId
    }
  }

  updatedSoldRatePlan(selectedPlan, planType, ratingPlanID) {
    let today = new Date();
    const getDate = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    let currentDate = getDate + ' ' + time;
    if (planType == 'add') {
      this.selectedSoldRatePlan.push(this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID));
    }
    else if (planType == 'update') {
      if (this.selectedSoldRatePlan.length !== 0) {
        let findIndex = this.selectedSoldRatePlan.findIndex(x => x.empcategorycode == this.empCatValueUpdateX && x.empClass === selectedPlan.employmentClassCode);
        if (findIndex !== -1) this.selectedSoldRatePlan[findIndex] = this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID);
        else this.selectedSoldRatePlan.push(this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID));
      } else {
        this.selectedSoldRatePlan = new Array(this.preparePlanData(selectedPlan, planType, currentDate, ratingPlanID));
      }
    }
    else if (planType == 'Remove') {

      for (let i = 0; i < selectedPlan.length; i++) {
        let findIndex = this.selectedSoldRatePlan.findIndex(x => x.empcategorycode === selectedPlan[i].emplymntCtgryCd
          && x.empClass === selectedPlan[i].employmentClassCode && this.lob === x.LOB && x.quotedContractCode === selectedPlan[i].quotedContractCode);
        if (findIndex == -1) {
          this.selectedSoldRatePlan.push(this.preparePlanData(selectedPlan[i], planType, currentDate, selectedPlan[i].ratingPlanId));

        } else {
          this.selectedSoldRatePlan.splice(findIndex, 1);
        }
      }

    }
    else {
      this.selectedSoldRatePlan.push(this.preparePlanData({}, '', currentDate, ratingPlanID));
    }


  }

  backClicked() {
    this.router.navigate(['/quote']);
  }


  clickedFromDate() {
    let element: HTMLElement = document.querySelectorAll('.overridedate .p-inputtext')[0] as HTMLElement;
    if (typeof (element) != 'undefined') {
      element.click();
    }
  }
  onRowSelect() {

  }

  disableManualSubmitBtn(): boolean {
    if (!this.selectedSubmitValue || this.selectedSubmitValue.length === 0) {
      return true;
    }
    return this.isReadOnlyRole || this.disableSubmit;
  }
  onlobSelect() {
    if (this.selectedSubmitValue?.length) {
      this.disableSubmit = false;
    }
    else {
      this.disableSubmit = true;
    }
  }
  onMouseFocus(event) {
    this.multiSelect.show();
    event.stopPropagation();
  }
  updateSubmitOptions() {
    this.submitOptions = [];

    if (this.medActiveRemoved.size > 0) {
      let medActiveRemoved = this.getByValue(this.medActiveRemoved, true);
      for (var i = 0; i < medActiveRemoved.length; ++i) {
        this.lobAdded.delete(medActiveRemoved[i]);
        this.setSelectedSubmitedValues(CommonConstants.Medical)
      }
    }
    if (this.visActiveRemoved.size > 0) {
      let visActiveRemoved = this.getByValue(this.visActiveRemoved, true);
      for (var i = 0; i < visActiveRemoved.length; ++i) {
        this.lobAdded.delete(visActiveRemoved[i]);
        this.setSelectedSubmitedValues(CommonConstants.Vision)
      }
    }
    if (this.denActiveRemoved.size > 0) {
      let denActiveRemoved = this.getByValue(this.denActiveRemoved, true);
      for (var i = 0; i < denActiveRemoved.length; ++i) {
        this.lobAdded.delete(denActiveRemoved[i]);
        this.setSelectedSubmitedValues(CommonConstants.Dental);
      }
    }
    if (this.shpActiveRemoved.size > 0) {
      let shpActiveRemoved = this.getByValue(this.shpActiveRemoved, true);
      for (var i = 0; i < shpActiveRemoved.length; ++i) {
        this.lobAdded.delete(shpActiveRemoved[i]);
        this.setSelectedSubmitedValues(RareConstants.suppHealth);
      }
    }

    let addedLobList = Array.from(this.lobAdded.values());
    for (let addedLob of addedLobList) {
      if (!(this.submitOptions.find(x => x === addedLob))) {
        this.submitOptions.push(addedLob);
      }
    }
    if (!this.submitOptions.includes("Medical")) {
      this.showAdditionalProgramsPopUp = false;
    }
    this.medActiveRemoved = new Map<string, boolean>();
    this.visActiveRemoved = new Map<string, boolean>();
    this.denActiveRemoved = new Map<string, boolean>();
    this.shpActiveRemoved = new Map<string, boolean>();

  }

  setSelectedSubmitedValues(lob) {
    const index = this.selectedSubmitValue.indexOf(lob);
    if (index !== -1) {
      this.selectedSubmitValue.splice(index, 1);
    }
  }

  getByValue(map, searchValue) {
    let keys = [];
    for (let [key, value] of map.entries()) {
      if (value === searchValue)
        keys.push(key);
    }
    return keys;
  }

  saveAdditionalProgram() {
    this.additionalProgramErrorFlag = false;
    if (!this.descriptionReason || this.descriptionReason.length === 0) {
      this.additionalProgramErrorFlag = true;
      this.additionalProgramErrorValue = "Please Enter Desc/Reason Value";
    }
    if (!this.additionalProgramErrorFlag) {
      this.selectedPlanTypeAdditional.forEach(selectedPlan => {
        const contractCode = selectedPlan.split("-", 1)[0];
        if (this.mapOfContractCodeAndSelectedEmpCategories.get(contractCode)) {
          const countOfRequiredEmploymentCategories = this.mapOfContractCodeAndSelectedEmpCategories.get(contractCode).length;
          if (countOfRequiredEmploymentCategories != this.selectedAdditionalProgramEmpCategory.length) {
            this.additionalProgramErrorFlag = true;
            this.additionalProgramErrorValue = CommonConstants.EMPLOYMENT_CATEGORIES_FOR_SELECTED_PLANS_DO_NOT_MATCH;
          } else {
            const sortedListOfSelectedEmpCategories = CommonUtil.getSortedList(this.selectedAdditionalProgramEmpCategory);
            const sortedListOfExpectedCategories = CommonUtil.getSortedList(this.mapOfContractCodeAndSelectedEmpCategories.get(contractCode));
            if (JSON.stringify(sortedListOfSelectedEmpCategories) != JSON.stringify(sortedListOfExpectedCategories)) {
              this.additionalProgramErrorFlag = true;
              this.additionalProgramErrorValue = CommonConstants.EMPLOYMENT_CATEGORIES_FOR_SELECTED_PLANS_DO_NOT_MATCH;
            }
          }
        }
      });
    }
    if (!this.additionalProgramErrorFlag) {
      if (this.addRateInfo['Active'].eeRate &&
        this.addRateInfo['Active'].esRate &&
        this.addRateInfo['Active'].efRate &&
        this.addRateInfo['Active'].ecRate &&
        this.addRateInfo['Active'].ekRate) {
        //do nothing as this means all rates are present and valid
      } else {
        this.additionalProgramErrorFlag = true;
        this.additionalProgramErrorValue = CommonConstants.ADDITIONAL_PROGRAM_RATES_NOT_VALID;
      }
    }
    if (!this.additionalProgramErrorFlag) {
      this.additionalProgramErrorValue = "";
      this.addRatesFromAdditionalPrograms();
      this.alertData = "Additional Programs Saved Successfully";
      this.showSaveAlert = true;
      this.displayProgramDialog = false;
      this.successMessage = true;
      this.formResetProgram();
    }
  }

  addRatesFromAdditionalPrograms() {
    var additionalProgram = {
      "rateType": this.selectedRateType,
      "contractCodePlanName": this.selectedPlanTypeAdditional,
      "programType": this.selectedProgramType,
      "rateInfo": this.addRateInfo,
      "empCatValue": this.empCatValue,
      "isIncludeInRates": this.isIncludeInRates,
      "descriptionReason": this.descriptionReason
    };

    //Start - Ensure that only uniqueAdditionalPrograms are added
    //We should not consider any additionalProgram if its being added again
    //We use the combination of selectedPlanContractCode+selectedProgramType+descriptionReason+selectedRateType+EERate as uniqueKey
    //to determine if or not that additionalProgram was already added
    let listOfAlreadyAddedAdditionalProgramIds = [];
    if (sessionStorage.getItem("addedAdditionalPrograms")) {
      let commaSeparatedValues = sessionStorage.getItem("addedAdditionalPrograms");
      listOfAlreadyAddedAdditionalProgramIds = commaSeparatedValues.split(',');
    }

    let listOfUniqueIDOfAdditionalProgram = [];
    this.selectedPlanTypeAdditional.forEach(selectedPlan => {
      //the data and its order in this key separated by | should NOT be changed as it is used in getAdditionalProgramDetails function
      listOfUniqueIDOfAdditionalProgram.push(selectedPlan + '|' + this.selectedProgramType + '|' + this.descriptionReason + '|' + this.selectedRateType + '|' + this.addRateInfo['Active'].eeRate);
    });

    let mapWithIsUniqueFlag = new Map();
    listOfUniqueIDOfAdditionalProgram.forEach(uniqueAdditionalProgramID => {
      if (listOfAlreadyAddedAdditionalProgramIds.includes(uniqueAdditionalProgramID)) {
        mapWithIsUniqueFlag.set(uniqueAdditionalProgramID, false)
      } else {
        mapWithIsUniqueFlag.set(uniqueAdditionalProgramID, true)
        listOfAlreadyAddedAdditionalProgramIds.push(uniqueAdditionalProgramID);
        sessionStorage.setItem("addedAdditionalPrograms", listOfAlreadyAddedAdditionalProgramIds.join(','));
      }
     })
    //End - Ensure that only uniqueAdditionalPrograms are added

    //iterate through all the existing soldPlans
    this.rowData.forEach(soldPlan => {
      let isAdditionalProgramsAddedToThisPlan = false;
      soldPlan.employmentCategory
        .forEach(empPlan => {
          if (StringUtils.isEqualIgnoreCase(soldPlan.lob, RareConstants.medical)) {

            const currentSoldPlanNameWithContractCodePrefix = soldPlan.quotedContractCode + "-" + soldPlan.productName;
            const uniqueIDForThisSoldPlan = currentSoldPlanNameWithContractCodePrefix + '|' + this.selectedProgramType + '|' + this.descriptionReason + '|' + this.selectedRateType + '|' + this.addRateInfo['Active'].eeRate;
            if (this.selectedPlanTypeAdditional.includes(currentSoldPlanNameWithContractCodePrefix) && mapWithIsUniqueFlag.get(uniqueIDForThisSoldPlan) == true) {
              isAdditionalProgramsAddedToThisPlan = true;
              if (this.isIncludeInRates) {
                empPlan.tierRate.eeRate = empPlan.tierRate.eeRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].eeRate);
                empPlan.tierRate.esRate = empPlan.tierRate.esRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].esRate);
                empPlan.tierRate.efRate = empPlan.tierRate.efRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].efRate);
                empPlan.tierRate.ecRate = empPlan.tierRate.ecRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].ecRate);
                empPlan.tierRate.ekRate = empPlan.tierRate.ekRate + parseFloat(this.addRateInfo[empPlan.emplymntCtgryCd].ekRate);
              }
            }
          }
        })
      if (isAdditionalProgramsAddedToThisPlan) {
        if (soldPlan['additionalPrograms']) {
          soldPlan['additionalPrograms'].push(additionalProgram);
        } else {
          soldPlan['additionalPrograms'] = [additionalProgram];
        }
      }
    })

    this.rowData.forEach(soldPlan => {
      if (soldPlan.additionalPrograms && soldPlan.additionalPrograms.length > 0) {
        soldPlan.additionalPrograms.forEach(additionalProgram => {
          additionalProgram.empCatValue.forEach(empCat => {
            let rateInfoForEmploymentCategory = additionalProgram.rateInfo[empCat];
            let text = this.getIncludedRatesText(additionalProgram.isIncludeInRates, soldPlan.fundingType);
            let soldPlanAdditionalProgram = {
              "contractCodePlanName": soldPlan.contractCodePlanName,
              "rateInfo": rateInfoForEmploymentCategory,
              "planName": soldPlan.productName,
              "programType": additionalProgram.programType,
              "isIncludeInRates": additionalProgram.isIncludeInRates,
              "contractCode": soldPlan.contractCode,
              "employmentCategoryCode": empCat,
              "ratesText": text,
              "description": additionalProgram.descriptionReason,
              "rateType": additionalProgram.rateType
            };

            var uniqueMapKey = soldPlan.contractCodePlanName + "|" + empCat;

            if (!this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey)) {
              this.mapOfContractCodeAndAdditionalProgram.set(uniqueMapKey, []);
              if (soldPlan.additionalPrograms[0].contractCodePlanName.includes(soldPlan.contractCodePlanName)) {
                this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey).push(soldPlanAdditionalProgram);
              }
            } else {
              var isAdditionalProgramAdded = false;

              // checking unique key to avoid duplicate additionalProgram getting added
              this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey).forEach(additionalProgramInNestedLoop => {
                if (additionalProgramInNestedLoop['programType'] == additionalProgram.programType
                  && additionalProgramInNestedLoop['description'] == additionalProgram.descriptionReason
                  && additionalProgramInNestedLoop['programType'] == additionalProgram.programType
                  && additionalProgramInNestedLoop['rateInfo'].eeRate == rateInfoForEmploymentCategory.eeRate
                  && additionalProgramInNestedLoop['employmentCategoryCode'] == empCat
                  && additionalProgramInNestedLoop['rateType'] == additionalProgram.rateType) {
                  isAdditionalProgramAdded = true;
                }
              });
              if (!isAdditionalProgramAdded) {
                if (soldPlan.additionalPrograms[0].contractCodePlanName.includes(soldPlan.contractCodePlanName)) {
                  this.mapOfContractCodeAndAdditionalProgram.get(uniqueMapKey).push(soldPlanAdditionalProgram);
                }
              }
            }
          });
        });
      }
    });

    for (let [key, value] of this.mapOfContractCodeAndAdditionalProgram) {
      if (value && value.length == 0) {
        this.mapOfContractCodeAndAdditionalProgram.delete(key);
      }
    }
  }

  getIncludedRatesText(ratesIncluded, fundingType) {
    if (StringUtils.isEqualIgnoreCase(fundingType, 'ABF') && (StringUtils.isEqualIgnoreCase(ratesIncluded.toString(), "yes") || ratesIncluded === true)) {
      return CommonConstants.ADDITIONAL_PROGRAM_ADDED_TO_ADMIN;
    }
    if (StringUtils.isEqualIgnoreCase(fundingType, 'FI') && (StringUtils.isEqualIgnoreCase(ratesIncluded.toString(), "yes") || ratesIncluded === true)) {
      return CommonConstants.ADDITIONAL_PROGRAM_ADDED_TO_TOTAL;
    }
    return CommonConstants.ADDITIONAL_PROGRAM_EMBEDDED;
  }

  openAdditionalProgramsPopUp() {
    //when the add additionalPrograms button is clicked - clear out all existing fields
    this.formResetProgram();
    this.removeSuccessMsg();
    this.formData = null;
    this.displayProgramDialog = true;
    this.soldRates_form.controls.ccCodeOverride.setValue('');
  }

  formResetProgram() {
    this.selectedProgramType = "";
    this.descriptionReason = "";
    this.PMPM = null;
    this.selectedPlanType = "";
    this.selectedEmpCategory = "";
    this.selectedFundingType = "";
    this.additionalProgramErrorFlag = false;
  }

  getProgramType(value) {
    this.selectedProgramType = value;
    this.additionalProgramErrorFlag = false;
    this.descriptionReason = "";
    this.selectedRateType = "";
    this.selectedPlanTypeAdditional = [];
    this.PMPM = null;

    this.planTypesAdditional.forEach(element => {
      this.selectedPlanTypeAdditional.push(element.value)
    })

    this.selectedRateType = this.rateTypesAdditional[0].value

    this.selectedPlan = "";
    this.selectedRatingPlanID = "";
    this.formData = null;
    this.categoryList = [];
    for (let resp of this.responseData) {
      if (StringUtils.isEqualIgnoreCase(resp.lob, RareConstants.medical)) {
        this.selectedRatingPlanID = resp.ratingPlanID;
        break;
      }
    }
    this.categoryList = this.getCategoryList(RareConstants.medical, 'A');

    this.categoryList.sort((a, b) => {
      return a.label.localeCompare(b.label);
    })
    this.getCategory(this.empCatValue)
    this.addRateInfo = {
      'Active': new RateInfo(),
      'Cobra': new RateInfo(),
      'Over 65 Retiree': new RateInfo(),
      'Retiree All': new RateInfo(),
      'Under 65 Retiree': new RateInfo()
    }
  }

  editAdditionalEmpRates(empCatCode, empRate) {
    let outputTier = this.formData.outputTier + '-tier';
    if (empRate == 'Employee') {
      this.addRateInfo[empCatCode].esRate = Number((this.formData.rateTierFactor[outputTier].esFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2))
      this.addRateInfo[empCatCode].efRate = Number((this.formData.rateTierFactor[outputTier].efFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2))
      this.addRateInfo[empCatCode].ecRate = Number((this.formData.rateTierFactor[outputTier].ecFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2))
      this.addRateInfo[empCatCode].ekRate = Number((this.formData.rateTierFactor[outputTier].ekFactor * this.addRateInfo[empCatCode].eeRate).toFixed(2))
    }
    if (empCatCode == 'Active') {
      this.categoryList.forEach(element => {
        var empCategoryFctr = this.soldRateFullResponse.employmentCategoryMedical.find(x => x.emplymntCtgryCd === element.value);
        this.addRateInfo[element.value].esRate = Number((this.addRateInfo['Active'].esRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
        this.addRateInfo[element.value].eeRate = Number((this.addRateInfo['Active'].eeRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
        this.addRateInfo[element.value].ekRate = Number((this.addRateInfo['Active'].ekRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
        this.addRateInfo[element.value].efRate = Number((this.addRateInfo['Active'].efRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
        this.addRateInfo[element.value].ecRate = Number((this.addRateInfo['Active'].ecRate * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
      })
    }
  }

  onChangeOfESActiveTierDuplicate() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].esRate = parseFloat(this.addRateInfo['Active'].esRate);
    }
  }

  onChangeOfEKActiveTierDuplicate() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].ekRate = parseFloat(this.addRateInfo['Active'].ekRate);
    }
  }

  onChangeOfEFActiveTierDuplicateOthers() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].efRate = parseFloat(this.addRateInfo['Active'].efRate);
    }
  }

  onChangeOfECActiveTierDuplicateOthers() {
    for (const category of this.categoryList) {
      this.addRateInfo[category.value].ecRate = parseFloat(this.addRateInfo['Active'].ecRate);
    }
  }

  editPMPMAdditionalEmpRates() {
    let outputTier = this.formData.outputTier + '-tier';
    this.categoryList.forEach(element => {
      var empCategoryFctr = this.soldRateFullResponse.employmentCategoryMedical.find(x => x.emplymntCtgryCd === element.value);
      this.addRateInfo[element.value].esRate = Number((this.formData.tierFactorMultiplier[outputTier] * this.PMPM * this.formData.rateTierFactor[outputTier].esFactor * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
      this.addRateInfo[element.value].efRate = Number((this.formData.tierFactorMultiplier[outputTier] * this.PMPM * this.formData.rateTierFactor[outputTier].efFactor * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
      this.addRateInfo[element.value].eeRate = Number((this.formData.tierFactorMultiplier[outputTier] * this.PMPM * this.formData.rateTierFactor[outputTier].eeFactor * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
      this.addRateInfo[element.value].ecRate = Number((this.formData.tierFactorMultiplier[outputTier] * this.PMPM * this.formData.rateTierFactor[outputTier].ecFactor * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
      this.addRateInfo[element.value].ekRate = Number((this.formData.tierFactorMultiplier[outputTier] * this.PMPM * this.formData.rateTierFactor[outputTier].ekFactor * empCategoryFctr.emplymntCtgryFctr).toFixed(2))
    })
  }


  getRateType(value) {
    this.selectedRateType = value;
    if (value !== 'PMPM') {
      this.PMPM = null
    }
    this.addRateInfo = {
      'Active': new RateInfo(),
      'Cobra': new RateInfo(),
      'Under 65 Retiree': new RateInfo(),
      'Over 65 Retiree': new RateInfo(),
      'Retiree All': new RateInfo()
    }
  }
  valueChanged() {
    this.isEdit = !this.isEdit;
    this.soldRateFullResponse = this.soldRateFullResponseModified;
  }
  getCategoryAddtional(value) {
    this.additionalProgramErrorFlag = false;
    this.selectedEmpCategory = CommonUtil.getSortedList(value);
    this.selectedAdditionalProgramEmpCategory = this.selectedEmpCategory;
    this.formData = this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID);
    this.soldRateFullResponseModified = this.soldRateFullResponse;
  }

  getCategory(value) {
    if (this.selectedProgramType) {
      this.getCategoryAddtional(value);
      this.modifyTier();
    }
    else {
      this.errorFlag = false;
      this.selectedEmpCategory = value;
      if(StringUtils.isEqualIgnoreCase(this.selectedLOB, RareConstants.suppHealth)){
        let formData = [];
        this.selectedRatingPlanIDs.forEach(selectedRatingPlanID => {
          let data = this.responseData.find(x => x.ratingPlanID === selectedRatingPlanID);
          if (data) {
            formData.push(data);
          }
        })
        this.formData = formData;
      } else {
        this.formData = this.responseData.find(x => x.ratingPlanID === this.selectedRatingPlanID);
      }
      this.replaceCurrentTierRatesWithOriginalQuotedRatesWhenAddingNewPlanInAddProgram();
    }
  }

  //When Add product popUp is opened - the rates that are displayed should be "QuotedRates"
  //i.e. they should not have any additionalPrograms "added"
  //This flow is triggered whenever Quoted Contract Code or Product Name dropDown is changed
  replaceCurrentTierRatesWithOriginalQuotedRatesWhenAddingNewPlanInAddProgram() {
    if (this.formData && this.formData['quotedTierRates']) {
      if (this.formData['additionalPrograms'] && !this.formData['tierRatesWithAdditionalPrograms']) {
        this.formData['tierRatesWithAdditionalPrograms'] = JSON.parse(JSON.stringify(this.formData.tierRate));
      }
      this.formData.tierRate = JSON.parse(JSON.stringify(this.formData.quotedTierRates));
    }
  }

  onAddPlanPopUpClose() {
    this.revertReplacingOfTierRatesWithQuotedRates;
  }

  revertReplacingOfTierRatesWithQuotedRates() {
    if (this.rowData) {
      for (var soldPlan of this.rowData) {
        if (soldPlan && soldPlan['tierRatesWithAdditionalPrograms']) {
          soldPlan.tierRate = JSON.parse(JSON.stringify(soldPlan['tierRatesWithAdditionalPrograms']));
        }
      }
    }
  }

  //This function has to be replaced as we have logic already existing and can be reused.
  modifyTier() {
    let outputTier = this.formData.outputTier + '-tier';
    //do tier Modification only if its not already a 5 tier one
    if (outputTier !== '5-tier') {
      if (outputTier === '4-tier') {
        this.formData.rateTierFactor['4-tier'].ekFactor = this.formData.rateTierFactor['4-tier'].ecFactor;
        this.formData.outputTierFactor['4-tier'].ekFactor = this.formData.outputTierFactor['4-tier'].ecFactor;
      }
      else if (outputTier === '3-tier') {
        this.formData.rateTierFactor['3-tier'].esFactor = this.formData.rateTierFactor['3-tier'].e1Factor;
        this.formData.rateTierFactor['3-tier'].ekFactor = this.formData.rateTierFactor['3-tier'].e1Factor;
        this.formData.rateTierFactor['3-tier'].ecFactor = this.formData.rateTierFactor['3-tier'].efFactor;

        this.formData.outputTierFactor['3-tier'].esFactor = this.formData.outputTierFactor['3-tier'].e1Factor;
        this.formData.outputTierFactor['3-tier'].ekFactor = this.formData.outputTierFactor['3-tier'].e1Factor;
        this.formData.outputTierFactor['3-tier'].ecFactor = this.formData.outputTierFactor['3-tier'].efFactor;
      }
      else if (outputTier === '2-tier') {
        this.formData.rateTierFactor['2-tier'].esFactor = this.formData.rateTierFactor['2-tier'].efFactor;
        this.formData.rateTierFactor['2-tier'].ekFactor = this.formData.rateTierFactor['2-tier'].efFactor;
        this.formData.rateTierFactor['2-tier'].ecFactor = this.formData.rateTierFactor['2-tier'].efFactor;

        this.formData.outputTierFactor['2-tier'].esFactor = this.formData.outputTierFactor['2-tier'].efFactor;
        this.formData.outputTierFactor['2-tier'].ekFactor = this.formData.outputTierFactor['2-tier'].efFactor;
        this.formData.outputTierFactor['2-tier'].ecFactor = this.formData.outputTierFactor['2-tier'].efFactor;
      }
      else {
        this.formData.rateTierFactor['1-tier'].esFactor = this.formData.rateTierFactor['1-tier'].eeFactor;
        this.formData.rateTierFactor['1-tier'].ekFactor = this.formData.rateTierFactor['1-tier'].eeFactor;
        this.formData.rateTierFactor['1-tier'].ecFactor = this.formData.rateTierFactor['1-tier'].eeFactor;
        this.formData.rateTierFactor['1-tier'].efFactor = this.formData.rateTierFactor['1-tier'].eeFactor;

        this.formData.outputTierFactor['1-tier'].esFactor = this.formData.outputTierFactor['1-tier'].eeFactor;
        this.formData.outputTierFactor['1-tier'].ekFactor = this.formData.outputTierFactor['1-tier'].eeFactor;
        this.formData.outputTierFactor['1-tier'].ecFactor = this.formData.outputTierFactor['1-tier'].eeFactor;
        this.formData.outputTierFactor['1-tier'].efFactor = this.formData.outputTierFactor['1-tier'].eeFactor;

      }
    }
  }

  getIncludeInRates(fundingType) {
    if (fundingType == 'FI') {
      this.includeInRates = 'Total';
    }
    if (fundingType == 'ABF') {
      this.includeInRates = 'Admin';
    }
  }

  isNumber(event) {
    return NumberUtils.isKeyPressForAValidNumber(event, 2);
  }

  getSelectionStart(o) {
    return o.selectionStart;
  }

  isPMPMNumber(event) {
    return NumberUtils.isKeyPressForAValidNumber(event, 6);
  }

  getEnrollments(field, empCat) {
    if (StringUtils.isEqualIgnoreCase(field, 'eeRateEnrollment'))
      return empCat?.enrollments?.ee ? empCat.enrollments.ee : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'ekRateEnrollment'))
      return empCat?.enrollments?.ek ? empCat.enrollments.ek : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'efRateEnrollment'))
      return empCat?.enrollments?.ef ? empCat.enrollments.ef : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'ecRateEnrollment'))
      return empCat?.enrollments?.ec ? empCat.enrollments.ec : 0;
    if (StringUtils.isEqualIgnoreCase(field, 'esRateEnrollment'))
      return empCat?.enrollments?.es ? empCat.enrollments.es : 0;
  }

  rateSplitsExpand(rowData) {
    rowData.expanded = !rowData.expanded;
  }

  isRateSplitsAvailable(planData, index) {
    if (StringUtils.isEqualIgnoreCase(planData.lob, 'Medical') && planData?.employmentCategory?.[index]?.rateSplits?.length) {
      return true
    }
    if (StringUtils.isEqualIgnoreCase(planData.lob, 'Medical') && planData?.additionalPrograms && !planData.planIsRemoved) {
      return true
    }
    return false
  }

  /* Display alert message to prevent multiple Retiree's added to sold plan */
  planRetireeValidation(isUpdate) {
    let isValid = true;
    const lob = "Supp Health";
    const retireAll = "Retiree All";
    const retire = "Retiree";
    let isRetireeAll = this.empCatValue?.some((emp) => StringUtils.isEqualIgnoreCase(emp, retireAll));
    if (isUpdate && this.empCatValueUpdate) {
      isRetireeAll = StringUtils.isEqualIgnoreCase(this.empCatValueUpdate, retireAll);
    }
    if (!this.empCategory?.length && this.empCatValue?.length && !isUpdate && !StringUtils.isEqualIgnoreCase(this.selectedLOB, lob)) {
      isValid = this.RetireecommonValidation(isValid, retire, isRetireeAll);
    } else if (!this.historyRetireeValidation(isUpdate, retire, isRetireeAll, retireAll) && !StringUtils.isEqualIgnoreCase(this.selectedLOB, lob)) {
      isValid = false;
    }
    return isValid;
  }

  historyRetireeValidation(isUpdate, retire, isRetireeAll, retireAll) {
    let isValid = true;
    const classObj = {classValueUpdate: "classValueUpdate",classValue:"classValue"}
    let categoryDropdown = isUpdate ? (this.empCatValueUpdate?.split(',')) : this.empCatValue;
    let selectedContractcode = isUpdate ? this.soldRates_form.get('ccCodeOverrideUpdate')?.value : this.soldRates_form.get('ccCodeOverride')?.value;
    let selectedClassValue = isUpdate ? this.soldRates_form.get(classObj.classValueUpdate)?.value : this.soldRates_form.get(classObj.classValue)?.value;
    selectedClassValue = selectedClassValue?selectedClassValue:"";
    if (this.empCategory && this.empCategory?.length) {
      const selectedRetireeLength = categoryDropdown?.filter((emp) => emp.includes(retire))?.length;
      const retireeOptionsLength = categoryDropdown?.filter((emp) => SoldConstants.RETIREE_OPTIONS.indexOf(emp) != -1)?.length;
      this.empCategory.forEach((emp) => {
        if (StringUtils.isEqualIgnoreCase(emp.contractCode,selectedContractcode) && emp.employmentCategory?.length) {
          const historyEmpCategory = emp.employmentCategory.map((emp) =>{return {category:emp.emplymntCtgryCd,class:emp.employmentClassCode}});
          const retireeAllLength = historyEmpCategory.filter((emp) => StringUtils.isEqualIgnoreCase(emp.category, retireAll) && emp.class == selectedClassValue)?.length;
          const retireeLength = historyEmpCategory.filter((emp) => SoldConstants.RETIREE_OPTIONS.indexOf(emp.category) != -1 && emp.class == selectedClassValue)?.length;
          if (retireeLength && selectedRetireeLength > 1) {
              isValid = false;
            } else if (isRetireeAll && retireeLength) {
              isValid = false;
            } else if (retireeAllLength && retireeOptionsLength) {
              isValid = false;
            } else if (!isUpdate) {
              isValid = this.RetireecommonValidation(isValid, retire, isRetireeAll);
            }
        } else if (!isUpdate) {
          isValid = this.RetireecommonValidation(isValid, retire, isRetireeAll);
        }
      })
    }
    return isValid;
  }
  RetireecommonValidation(isValid, retire, isRetireeAll) {
    if (this.empCatValue?.filter((emp) => emp.includes(retire))?.length > 2) {
      isValid = false
    } else if (isRetireeAll && this.empCatValue?.filter((emp) => SoldConstants.RETIREE_OPTIONS.indexOf(emp) != -1)?.length == 1) {
      isValid = false;
    }
    return isValid;
  }

  getSoldRateColumnClass(column){
    return `header-${column}`
  }

  /**
   * This returns a warning message String in case Sold Rates include at least one Supp Health
   */
  getTooltipWarningMessage(){
    if (this.responseDataHistory.length > 0 && this.soldHistoryHasSuppHealthPlans()) {
      return CommonConstants.PRINT_TOOLTIP_SUPP_HEALTH_WARNING;
    }

    return CommonConstants.EMPTY_STRING;
  }

  /**
   * This checks if there is at least one Supp Health Sold Rate
   */
  soldHistoryHasSuppHealthPlans(){
    return this.responseDataHistory.some(history =>
      history.plan.some(plan =>
        StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.suppHealth)));
  }

  /**
   * This checks if all Sold Rates are Supp Health ones
   */
  soldHistoryHasOnlySuppHealthPlans(){
    return this.responseDataHistory.every(history =>
        history.plan.length === history.plan.filter(plan =>
          StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.suppHealth)
        ).length
    );
  }

  /**
   * This checks the enrollment count matches with quoted subscribers or not
   */
  checkEnrollmentCount(_SoldRatePlansWithCat) {
    let enrollments = 0;
    if (_SoldRatePlansWithCat?.plan) {
      _SoldRatePlansWithCat.plan.forEach(plan => {
        if (StringUtils.isEqualIgnoreCase(plan.lob, RareConstants.medical) && !StringUtils.isUndefined(plan?.employmentCategory) && plan?.employmentCategory?.length > 0) {
          plan?.employmentCategory?.forEach(empCat => {
            if (!StringUtils.isUndefined(empCat?.enrollments)) {
              Object.keys(empCat.enrollments).forEach(enrollmentKey => {
                if (!StringUtils.isUndefined(empCat.enrollments[enrollmentKey]))
                  enrollments = enrollments + empCat.enrollments[enrollmentKey];
              })
            }
          })
        }
      })
      return enrollments;
    }
  }
  /**
  * This snippet assign the enrollment count for plan
  */
  private assignEnrollments(plan: any, initialEnrollments: any) {
    plan.employmentCategory.forEach(empCat => {
      if (StringUtils.isUndefined(empCat.enrollments)) {
        if (StringUtils.isEqual(empCat.emplymntCtgryCd, CommonConstants.ACTIVE)) {
          empCat[CommonConstants.ENROLLMENTS] = {
            ee: initialEnrollments?.EE, ef: initialEnrollments?.EF, ek: initialEnrollments?.EK,
            es: initialEnrollments?.ES, ec: initialEnrollments?.EC
          };
        }
      }
    });
  }
  private checkSoldConditions(plan: any, planTypeRequested) {
    return StringUtils.isEqual(plan.planTypeRequested, planTypeRequested) && StringUtils.isEqual(plan.status, CommonConstants.PRE_SOLD) && StringUtils.isEqual(plan.lob, CommonConstants.Medical) && plan.employmentCategory && StringUtils.isUndefined(plan.currentContractCode);
  }
}
