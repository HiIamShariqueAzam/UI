import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { SoldRateComponent } from './sold-rate.component';

describe('SoldRateComponent', () => {
  let component: SoldRateComponent;
  let fixture: ComponentFixture<SoldRateComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SoldRateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoldRateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
