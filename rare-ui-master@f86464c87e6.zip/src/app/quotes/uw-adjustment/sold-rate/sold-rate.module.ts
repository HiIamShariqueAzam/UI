import { NgModule } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { SoldRateComponent } from './sold-rate.component';
import { RouterModule } from '@angular/router';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePickerModule } from 'primeng/datepicker';
import { CheckboxModule } from 'primeng/checkbox';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import { DialogModule } from 'primeng/dialog';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { SoldRateHistoryComponent } from './sold-rate-history/sold-rate-history.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { TooltipModule } from "primeng/tooltip";
@NgModule({
    declarations: [
        SoldRateComponent,
        SoldRateHistoryComponent
    ],
    imports: [
        CommonModule, TableModule, ButtonModule, MultiSelectModule, FormsModule, SelectModule, DatePickerModule, CheckboxModule, DialogModule, ReactiveFormsModule, RouterModule.forChild([
            {path: '', component: SoldRateComponent, pathMatch: 'full'}
        ]), ProgressSpinnerModule, ConfirmDialogModule, TooltipModule
    ],
    exports: [
        SoldRateComponent,
        SoldRateHistoryComponent
    ],
    providers: [
        RouterModule, DecimalPipe, DatePipe, ConfirmationService
    ]
})
export class SoldRateModule { }
