import { Injectable } from '@angular/core';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class SoldRateService {

  constructor(
    private authenticationService: AuthenticationService,
    private http: HttpClient,
    private commonService: CommonService) { }

  getSoldRatesGrid(opportunityID, quoteHeaderID, fundType) {
    let headers = this.commonService.setRequestHeadersSoldRate();
    return this.http.get<any>(this.commonService.getRareUiUrl() + "/soldRates?opportunityID=" + opportunityID + "&quoteHeaderID=" + quoteHeaderID + "&fundingType=" + fundType, { headers: headers });
  }

  getSoldRatesGridColumnHeaders() {
    return this.http.get<any>('assets/mock-jsons/sold-rate-grid.json');
  }

  getSoldRatesHistoryGrid(opportunityID, quoteHeaderID) {
    let headers = this.commonService.setRequestHeadersSoldRate();
    return this.http.get<any>(this.commonService.getRareUiUrl() + "/soldRates/history?opportunityID=" + opportunityID + "&quoteHeaderID=" + quoteHeaderID, { headers: headers });
  }

  submitSoldRates(soldRates) {
    let plan = soldRates['data']['plan'];
    let headers = this.commonService.setSubmitHeadersSoldRate(soldRates['data']['metaData']['metaTransID'], plan[0]['ratingTransID']);
    let request = {
      "soldRates": soldRates,
    }
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/ui/soldRates", rareUiRequest, { headers: headers });
  }

  saveSoldRates(soldRates, opportunityID, soldAuditTrail, action) {
    let headers = this.commonService.setRequestHeadersSoldRate();
    let request = {
      soldRates,
      action: action,
      soldAuditTrail: soldAuditTrail
    }
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    return this.http.put<any>(this.commonService.getRareUiUrl() + "/soldRates/save?opportunityID=" + opportunityID, rareUiRequest, { headers: headers });
  }
  getSoldRatesAdditionalPrograms(state, factorEffDate, quoteEffDate) {
    let headers = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + "/ui/manager/additional-programs?state=" + state + '&factorEffectiveDate=' + factorEffDate + '&quoteEffDate=' + quoteEffDate,
      { headers: headers })
  }
  saveAdditionalProgram(fundingType, request) {

    let headers = this.commonService.setRequestHeadersSoldRate();
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/additionalPrograms/save?fundingType=" +
      fundingType, rareUiRequest, { headers: headers });


  }
}
