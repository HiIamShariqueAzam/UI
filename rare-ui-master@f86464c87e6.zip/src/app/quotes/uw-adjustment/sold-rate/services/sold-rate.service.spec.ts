import { TestBed } from '@angular/core/testing';

import { SoldRateService } from './sold-rate.service';

describe('SoldRateService', () => {
  let service: SoldRateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SoldRateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
