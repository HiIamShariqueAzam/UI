import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormBuilder, FormGroup, FormGroupDirective } from "@angular/forms";
import { ActivatedRoute } from '@angular/router';
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { ProcessQuoteDetailsService } from 'src/app/shared/services';
import { CommonService } from "src/app/shared/services/common.service";
import { CommonUtil } from "src/app/shared/utils/common-util";
import { DentalConstants } from "../dental.constants";


@Component({
  selector: "app-adjustments",
  templateUrl: "./adjustments-dental.component.html",
  styleUrls: ["./adjustments-dental.component.css"],
  standalone: false
})
export class AdjustmentsDentalComponent implements OnInit {

  @Input() RateData;
  @Input() dentalAdjustmentNode;
  @Input() adjustedPlans;
  @Input() featuredPlans;
  @Input() dentalPremiumComparison;
  @Input() initialRates;
  @Input() reqTier
  @Input() isReadOnlyRole;
  @Input() disableAll;
  @Input() status;
  @Output() onFactorAdj = new EventEmitter<any>();

  constructor(private fb: FormBuilder, private rootFormGroup: FormGroupDirective,
    private route:ActivatedRoute,private commonService:CommonService, private processQuoteService: ProcessQuoteDetailsService) {

  }

  uwAdjustment = {};
  proposedPlans = [];
  isCollapsed: boolean = false ;
  form: FormGroup;
  activeTab: string = "Q";
  fundingType = 'FI';
  oppID:any;
  lob1:any;
  transID:any;
  quoteHeaderID:any;
  isAdjError: boolean = false;
  errorMessage:any;
  isFactorAdjusted: boolean;
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.oppID = params[CommonConstants.OPPORTUNITY_ID];
      this.transID = params[CommonConstants.RATINGTRANS_ID];
      this.lob1 = params[CommonConstants.LOB];
      this.fundingType = params[CommonConstants.FUNDING_TYPE];
      this.quoteHeaderID = params[CommonConstants.QUOTEHEADER_ID];
    });
    this.form = this.rootFormGroup.control;
    this.setFormValue();
  }

  // Setting form values
  setFormValue() {
    if (this.RateData && this.RateData.uwAdjustment) {
      this.form.get(DentalConstants.uwNotesToSales).setValue(this.RateData.uwAdjustment.uwNotesToSales || '');
      this.form.get(DentalConstants.uwComments).setValue(this.RateData.uwAdjustment.uwComments || '');
    }
    this.form.get(DentalConstants.salesNotetoUW).setValue(this.RateData["dental"][DentalConstants.salesNotetoUW] || '', { emitEvent: false });
    this.form.get(DentalConstants.salesNotetoUW)?.disable();
  }
  isNumber(evt) {
    return CommonUtil.isNumber(evt);
  }

  checkIfNull(plan){
    if(plan['uwAdjustment'] == null || plan['uwAdjustment'] == undefined ){
     return null;
    }
    else {
      if ((String(plan['uwAdjustment']).match(/^(\d?(\.\d{1,10})?)?$/g))) {
        if (String(plan['uwAdjustment']) !== '0' && String(plan['uwAdjustment']) !== '' && plan['uwAdjustment'] !== undefined) {
          this.isAdjError = false;
          return null;
        } else {
          this.isAdjError = true;
          this.errorMessage = DentalConstants.invalidValue;
          return true;
        }
      } else {
        this.isAdjError = true;
        this.errorMessage = DentalConstants.invalidValue;
        return true;
      }
    }
  }

  // Fetch the UW factor from the API and return
  getUWAdjustment(plan,index) {
    let ratingPlansIDS = [];
    if (!this.isFactorAdjusted && this.dentalAdjustmentNode.length) {
      for (let i = 0; i < this.dentalAdjustmentNode.length; i++) {
        ratingPlansIDS.push(this.dentalAdjustmentNode[i].ratingPlanID);
        if (ratingPlansIDS.includes(plan.ratingPlanID)) {
          if (plan.ratingPlanID == this.dentalAdjustmentNode[i].ratingPlanID && plan.planName == this.dentalAdjustmentNode[i].planName) {
            return this.dentalAdjustmentNode[i].uwAdjustment;
          }

        }
      }
    } else {
        this.adjustedPlans.forEach((item, i) => {
          if (item['ratingPlanID'] == plan.ratingPlanID && item['planName'] == plan.planName) {
            plan['uwAdjustment'] = item.uwAdjustment;
          }
        });
      return plan['uwAdjustment'];
    }
  }
  // On changing the adjustment factor
  onAdjChange(value, plan, index, featuredPlans) {
    this.isFactorAdjusted = true;
    this.onFactorAdj.emit(this.isFactorAdjusted)
    if (value == null || value == "") {
      this.commonService.isMatchClicked = false;
      const index1 = this.adjustedPlans.findIndex(item => item.ratingPlanID == plan.ratingPlanID);
      this.adjustedPlans[index1].uwAdjustment = null;
      this.calculateRates(index, 1);
    } else {
      this.calculateRates(index, Number(value));
      this.commonService.isMatchClicked = false;
      this.commonService.onMatchClick = false;
      this.commonService.onResetClick = false;
      this.commonService.adjustedRatingPlanID = plan.ratingPlanID;
      featuredPlans.forEach((item, ind) => {
        let isRatingPlanID: boolean
        if (item.ratingPlanID == plan.ratingPlanID) {
          isRatingPlanID = true
        }
        let cccRate = {
          "single": featuredPlans[ind]['rateInfo'].EEpremiumWithACAFee,
          "eeSpouse": featuredPlans[ind]['rateInfo'].ESpremiumWithACAFee,
          "eeOne": featuredPlans[ind]['rateInfo'].E1premiumWithACAFee,
          "eeChild": featuredPlans[ind]['rateInfo'].EKpremiumWithACAFee,
          "eeChildren": featuredPlans[ind]['rateInfo'].ECpremiumWithACAFee,
          "family": featuredPlans[ind]['rateInfo'].EFpremiumWithACAFee,
          "monthlyPremium": 0,
          "yearlyPremium": 0
        }
        let ccrRate = {
          "single": featuredPlans[ind]['rateInfo'].EEpremiumWithACAFee,
          "eeSpouse": featuredPlans[ind]['rateInfo'].ESpremiumWithACAFee,
          "eeOne": featuredPlans[ind]['rateInfo'].E1premiumWithACAFee,
          "eeChild": featuredPlans[ind]['rateInfo'].EKpremiumWithACAFee,
          "eeChildren": featuredPlans[ind]['rateInfo'].ECpremiumWithACAFee,
          "family": featuredPlans[ind]['rateInfo'].EFpremiumWithACAFee,
          "monthlyPremium": 0,
          "yearlyPremium": 0
        }
        let planObj = {
          "planName": item.planName,
          "ratingPlanID": item.ratingPlanID,
          "uwAdjustment": isRatingPlanID ? value : plan.uwAdjustment,
          "matchCurrent": false,
          "matchRenewal": false,
          "reset": false,
          "cccRate": cccRate,
          'ccrRate': ccrRate,
        }


        if (this.dentalAdjustmentNode.length) {
          planObj.uwAdjustment = isRatingPlanID ? value : this.dentalAdjustmentNode[ind].uwAdjustment
        } else {
          planObj.uwAdjustment = isRatingPlanID ? value : plan.uwAdjustment
        }

        if (value !== null || value !== 0) {
          const index = this.adjustedPlans.findIndex(item => item.ratingPlanID == planObj.ratingPlanID);

          if (index !== -1 && isRatingPlanID) {
            this.adjustedPlans[index].uwAdjustment = value;
          }
          else if (this.adjustedPlans.length !== featuredPlans.length) {
            this.adjustedPlans.push(planObj);
            const findIndex = this.adjustedPlans.findIndex(planObj => planObj.ratingPlanID === plan['ratingPlanID']);
            this.adjustedPlans[findIndex].rateInfo = plan.rateInfo;
            this.adjustedPlans[findIndex].ageBandRateInfo = plan.ageBandRateInfo;
            this.updatePremiumComparison(plan, value, false);
          }
        }
      });
      this.dentalPremiumComparison.planComparison.forEach((item, i) => {
        if (item.quoteRatingPlanID == plan.ratingPlanID) {
          this.dentalPremiumComparison.planComparison[i]['matchCurrent'] = true;
          this.dentalPremiumComparison.planComparison[i]['matchRenewal'] = true;
          this.dentalPremiumComparison.planComparison[i]['reset'] = true;
        }
      });
      this.adjustedPlans.forEach((item, i) => {
        if (item.ratingPlanID == plan.ratingPlanID) {
          this.adjustedPlans[i].matchCurrent = false;
          this.adjustedPlans[i].matchRenewal = false;
          this.adjustedPlans[i].reset = false;
        }
      });

    }
    this.assignRateInfoRatesToQuotedRatesAfterAdjustment(plan);
  }
  // Assigning featured plans (rateInfo) rates to quoted rates in premium comparison
  assignRateInfoRatesToQuotedRatesAfterAdjustment(denPlan) {
    if (this.dentalPremiumComparison) {
      const comparisonIndex = this.dentalPremiumComparison.planComparison.findIndex(obj => obj.quoteRatingPlanID === denPlan.ratingPlanID);
      const featuredPlanIndex = this.featuredPlans.findIndex(obj => obj.ratingPlanID === denPlan.ratingPlanID && obj.planName === denPlan.planName);
      
      if (comparisonIndex !== -1 && featuredPlanIndex !== -1) {
        this.dentalPremiumComparison.planComparison.forEach(element => {
          if (denPlan.ratingPlanID == element.quoteRatingPlanID) {
            switch (Number(this.reqTier)) {
              case 1:
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT1 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EEpremiumWithACAFee;
                break;
              case 2:
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT1 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EEpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT2 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EFpremiumWithACAFee;
                break;
              case 3:
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT1 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EEpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT2 = this.featuredPlans[featuredPlanIndex]['rateInfo'].E1premiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT3 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EFpremiumWithACAFee;
                break;
              case 4:
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT1 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EEpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT2 = this.featuredPlans[featuredPlanIndex]['rateInfo'].ESpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT3 = this.featuredPlans[featuredPlanIndex]['rateInfo'].ECpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT4 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EFpremiumWithACAFee;
                break;
              case 5:
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT1 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EEpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT2 = this.featuredPlans[featuredPlanIndex]['rateInfo'].ESpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT3 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EKpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT4 = this.featuredPlans[featuredPlanIndex]['rateInfo'].ECpremiumWithACAFee;
                this.dentalPremiumComparison.planComparison[comparisonIndex].quoteRates.ratesT5 = this.featuredPlans[featuredPlanIndex]['rateInfo'].EFpremiumWithACAFee;
                break;
              default: console.log('default')
            }
          }
        });
      }
    }
  }
  // Calculate each tier rates with UW factor
  calculateRates(index, value) {
    if (value > 0) {
      this.featuredPlans[index]['rateInfo'].EEpremiumWithACAFee = this.initialRates[index]['initialRates'].EEpremiumWithACAFee * value;
      this.featuredPlans[index]['rateInfo'].single = this.featuredPlans[index]['rateInfo'].EEpremiumWithACAFee;
      switch (this.reqTier * 1) {
        case 5:
          this.featuredPlans[index]['rateInfo'].EKpremiumWithACAFee = this.initialRates[index]['initialRates'].EKpremiumWithACAFee * value;
          this.featuredPlans[index]['rateInfo'].eeChild = this.featuredPlans[index]['rateInfo'].EKpremiumWithACAFee;
        case 4:
          this.featuredPlans[index]['rateInfo'].ESpremiumWithACAFee = this.initialRates[index]['initialRates'].ESpremiumWithACAFee * value;
          this.featuredPlans[index]['rateInfo'].eeSpouse = this.featuredPlans[index]['rateInfo'].ESpremiumWithACAFee;
          this.featuredPlans[index]['rateInfo'].ECpremiumWithACAFee = this.initialRates[index]['initialRates'].ECpremiumWithACAFee * value;
          this.featuredPlans[index]['rateInfo'].eeChildren = this.featuredPlans[index]['rateInfo'].ECpremiumWithACAFee;
        case 3:
          if (this.reqTier * 1 == 3) {
            this.featuredPlans[index]['rateInfo'].E1premiumWithACAFee = this.initialRates[index]['initialRates'].E1premiumWithACAFee * value;
            this.featuredPlans[index]['rateInfo'].eeOne = this.featuredPlans[index]['rateInfo'].E1premiumWithACAFee;
          }
        case 2:
          this.featuredPlans[index]['rateInfo'].EFpremiumWithACAFee = this.initialRates[index]['initialRates'].EFpremiumWithACAFee * value;
          this.featuredPlans[index]['rateInfo'].family = this.featuredPlans[index]['rateInfo'].EFpremiumWithACAFee;
      }
    }
  }

  onUwNoteToSalesEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.form.get(DentalConstants.uwNotesToSales).setValue(ASCII || '');
    }
    else{
      this.form.get(DentalConstants.uwNotesToSales).setValue("");
    }
  }

  onUwNoteToSelfEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.form.get(DentalConstants.uwComments).setValue(ASCII || '');
    }
    else{
      this.form.get(DentalConstants.uwComments).setValue("");
    }
  }

  updatePremiumComparison(plan, adjustmentFactor, isCurrentRateEdit = false) {
    this.RateData.dentalPremiumComparison.planComparison.forEach(planComp => {
      if (adjustmentFactor && planComp.quoteRatingPlanID === plan.ratingPlanID) {
        planComp.isProposedPlanRatesEdited = CommonConstants.NO_CHAR;
        plan = this.recalculateQuotedRates(planComp, adjustmentFactor);
      }
    })
  }


  recalculateQuotedRates(planComparison, adjustmentFactor) {
    this.calculateQuotedTierRates(planComparison.currentRates, planComparison.quoteRates, planComparison.quoteEnrollments, planComparison.quoteTier, adjustmentFactor)
    let enr = planComparison.quoteEnrollments['enrollT1'] ? planComparison.quoteEnrollments['enrollT1'] : 0;
    planComparison.quoteRates['monthlyTotal'] = (Math.round((planComparison.quoteRates['ratesT1'] + Number.EPSILON) * 100) / 100 * enr);
    return planComparison;
  }

  calculateQuotedTierRates(currentRates, quotedRates, enrollments, quoteTier, adjustmentFactor) {
    let monthlyRate = 0;
    for (let i = 1; i <= quoteTier; i++) {
      quotedRates['ratesT' + i] = this.roundedValue(currentRates['ratesT' + i] * (adjustmentFactor || 0));
    }
  }

  roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }
}
