import { Component, OnInit, Input, OnChanges, SimpleChanges, AfterViewInit, ElementRef, ViewChild } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { EventEmitter, Output } from "@angular/core";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: 'app-view-benefit-modal-dental',
  templateUrl: './view-benefit-modal.component.html',
  styleUrls: ['./view-benefit-modal.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class ViewBenefitModalComponent implements OnInit, OnChanges, AfterViewInit {


  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  objectKeys = Object.keys;
  @Input() dentalBenefits;
  @Input() isSGRen: any;
  @Input() isAutoQuote: any;
  @Input() alternateQuote;
  @Input() isCustomizeEnable: boolean;
  @Input() isReadOnlyRole;
  @Output() customizePlanEvent = new EventEmitter<void>();
  deductibles = [];
  coinsuranceList = [];
  othersList = [];
  maximumsList = [];
  constructor(
    config: NgbModalConfig,
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }
  
  ngOnChanges(changes: SimpleChanges) {
    if(!this.isSGRen && !this.isAutoQuote){
    this.constructJSON()} 
  }

  ngOnInit() {
    if(!this.isSGRen && !this.isAutoQuote){
    this.constructJSON()}
  }

  constructJSON() {
    this.deductibles = []
    this.coinsuranceList = [];
    this.othersList = [];
    this.maximumsList = [];
  
    if (this.dentalBenefits) {
      if (this.dentalBenefits.indDeductible) {
        let obj = {
          'key': 'Annual Deductible',
          'inn': this.dentalBenefits.indDeductible.inn,
          'oon': this.dentalBenefits.indDeductible.oon
        }
        this.deductibles.push(obj);
      }
      if (this.dentalBenefits.familyDeductible) {
        let obj = {
          'key': 'Family Deductible Multiple',
          'inn': this.dentalBenefits.familyDeductible.inn,
          'oon': this.dentalBenefits.familyDeductible.oon
        }
        this.deductibles.push(obj);
      }
      if (this.dentalBenefits.indLifetimeDed) {
        let obj = {
          'key': 'Individual Lifetime Deductible',
          'inn': this.dentalBenefits.indLifetimeDed.inn,
          'oon': this.dentalBenefits.indLifetimeDed.oon
        }
        this.deductibles.push(obj);
      }
      if (this.dentalBenefits.dpDeductibleWaived) {
        let obj = {
          'key': 'Deductible Waived - D&P',
          'inn': this.dentalBenefits.dpDeductibleWaived.inn,
          'oon': this.dentalBenefits.dpDeductibleWaived.oon
        }
        this.deductibles.push(obj);
      }
      if (this.dentalBenefits.annualMax) {
        this.maximumsList.push({
          key: 'Annual Maximum',
          inn: this.dentalBenefits.annualMax.inn,
          oon: this.dentalBenefits.annualMax.oon
        })
      }
      if (this.dentalBenefits.outOfPocketMax) {
        let obj = {
          key: 'Out of Pocket Maximum Individual/Family',
          inn: this.dentalBenefits.outOfPocketMax['individual'].inn + '/' + this.dentalBenefits.outOfPocketMax['family'].inn,
          oon: this.dentalBenefits.outOfPocketMax['individual'].oon + '/' + this.dentalBenefits.outOfPocketMax['family'].oon
        }
        this.maximumsList.push(obj);
      }

      if (this.dentalBenefits.orthoLifeTimeMax) {
        this.maximumsList.push({
          key: 'Lifetime Orthodontic Maximum',
          inn: this.dentalBenefits.orthoLifeTimeMax.inn,
          oon: this.dentalBenefits.orthoLifeTimeMax.oon
        })
      }
      for (var item in this.dentalBenefits.benefitAdjustmentMap) {
        this.dentalBenefits.benefitAdjustmentMap[item].forEach((element) => {
          if (element) {
            let obj = {
              'key': element.benefitAdjustmentName,
              'value': element.benefitOption
            }
            this.othersList.push(obj)
          }
        })
      }
      for (var item in this.dentalBenefits.coinsuranceMap) {
        let obj1 = {
          title: item,
          inn: this.dentalBenefits.coinsuranceMap[item].inn,
          oon: this.dentalBenefits.coinsuranceMap[item].oon,
        }
        this.coinsuranceList.push(obj1);
      }
    }
  }

  customizePlanModal() {
    // Open the modal using Bootstrap's modal API
    const modal = document.getElementById('customizeModal');
    if (modal) {
      // For Bootstrap 5
      // @ts-ignore
      const bsModal = new window.bootstrap.Modal(modal);
      bsModal.show();
    }
  }

  customizePlan() {
    // Emit the event
    this.customizePlanEvent.emit();

    // Close myModal1 using Bootstrap's modal API
    const mainModal = document.getElementById('myModal1');
    if (mainModal) {
      // For Bootstrap 5
      // @ts-ignore
      const bsMainModal = window.bootstrap.Modal.getInstance(mainModal);
      if (bsMainModal) {
        bsMainModal.hide();
      }
    }
  }
}
