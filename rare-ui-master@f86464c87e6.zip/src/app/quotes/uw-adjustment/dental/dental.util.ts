import { StringUtils } from "src/app/shared/utils/string-utils";
import { DentalConstants } from "./dental.constants";

export class DentalUtil {

    public static tierDescription: any = {
        "1-Tier": {
            "EE": DentalConstants.employee
        },
        "3-Tier": {
            "EE": DentalConstants.employee,
            "EF": DentalConstants.employee + ' + ' + DentalConstants.Family,
            "E1": DentalConstants.employee + ' + ' + DentalConstants.one
        },
        "4-Tier": {
            "EE": DentalConstants.employee,
            "EF": DentalConstants.employee + ' + ' + DentalConstants.Family,
            "ES": DentalConstants.employee + ' + ' + DentalConstants.spouse,
            "EC": DentalConstants.employee + ' + ' + DentalConstants.children
        },
        "5-Tier": {
            "EE": DentalConstants.employee,
            "EF": DentalConstants.employee + ' + ' + DentalConstants.Family,
            "EK": DentalConstants.employee + ' + ' + DentalConstants.child,
            "ES": DentalConstants.employee + ' + ' + DentalConstants.spouse,
            "EC": DentalConstants.employee + ' + ' + DentalConstants.children
        },
        "2-Tier": {
            "EE": DentalConstants.employee,
            "EF": DentalConstants.employee + ' + ' + DentalConstants.Family
        }
    };
    public static defaultTierNames = {
        "EE": DentalConstants.Family,
        "EF": DentalConstants.employee + ' + ' + DentalConstants.Family,
        "EK": DentalConstants.employee + ' + ' + DentalConstants.child,
        "EC": DentalConstants.employee + ' + ' + DentalConstants.children,
        "ES": DentalConstants.employee + ' + ' + DentalConstants.spouse,
        "E1": DentalConstants.employee + ' + ' + DentalConstants.one
    };

    public static calculateRateGuaranteeMonths(date1: Date, date2: Date) {
        // Calculate the difference in months regardless of the day
        let months = (date2.getFullYear() - date1.getFullYear()) * 12 + (date2.getMonth() - date1.getMonth());
        // If the end date's day is greater than or equal to the start date's day, count as a full month
        if (date2.getDate() >= date1.getDate()) {
            months += 1;
        }
        // Always return at least 0
        return months <= 0 ? 0 : months;
    }

    public static isNumber(evt) {
        var el = evt.target;
        var charCode = evt.charCode;
        var number = el.value.split(".");
        if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        if (number.length > 1 && charCode == 46) {
            return false;
        }
        var caratPos = this.getSelectionStart(el);
        var dotPos = el.value.indexOf(".");
        if (caratPos > dotPos && dotPos > -1 && number[1].length > 10) {
            return false;
        }
        return true;
    }

    public static getSelectionStart(o) {
        return o.selectionStart;
    }
    
}