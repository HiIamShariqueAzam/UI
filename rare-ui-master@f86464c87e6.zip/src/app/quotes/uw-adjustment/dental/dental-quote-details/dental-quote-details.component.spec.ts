import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DentalQuoteDetailsComponent } from './dental-quote-details.component';

describe('DentalQuoteDetailsComponent', () => {
  let component: DentalQuoteDetailsComponent;
  let fixture: ComponentFixture<DentalQuoteDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DentalQuoteDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DentalQuoteDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
