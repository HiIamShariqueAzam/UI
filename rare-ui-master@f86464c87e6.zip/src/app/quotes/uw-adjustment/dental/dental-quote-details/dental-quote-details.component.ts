import { Component, OnInit, Input, OnChanges, SimpleChanges, input } from '@angular/core';
import { CommonService, AuthenticationService } from 'src/app/shared/services';
import { FormGroupDirective, FormGroup } from '@angular/forms';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { ActivatedRoute, Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { RenewalsConstants } from 'src/app/renewals/renewals-constants';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: 'app-dental-quote-details',
  templateUrl: './dental-quote-details.component.html',
  styleUrls: ['./dental-quote-details.component.css'],
  standalone: false
})
export class DentalQuoteDetailsComponent implements OnInit, OnChanges {

  constructor(private commonService: CommonService, private rootFormGroup: FormGroupDirective,
    private authService: AuthenticationService, private route: ActivatedRoute,
    private router: Router, private commonQuoteService: CommonQuoteService) {
      this.userRole = this.authService.userRole['_value'];
    this.showSpecialitySendToOpp = this.commonService.getRareSpecialitySendToOppEnabled();
     }
  @Input() RateData;
  @Input() fundingType;
  @Input() oldQuotesData;
  @Input() quoteHistory;
  @Input() disableAll;
  @Input() alternateQuote;
  @Input() isFileUpload;
  public isCollapsed = false;
  addr1: any;
  addr2: any;
  compZipcode: any;
  quoteReason: any;
  experienceIncluded: any;
  mbs: any;
  virginGroup: any;
  rateGuaranteeMonths: any;
  quotedCount: number=0;
  waivers: number=0;
  hideErrorPlan: boolean;
  rateGuarenteeEffDate: any;
  rateGuarenteeEndDate: any;
  supportingDocLinks: any;
  urlData: any;
  opportunityType: any = '';
  quotingType: any = '';
  marketSegment: any;
  peOverrideData: any;
  uwAdjustmentData: any
  contractStartDate: any;
  factorEffectiveDate: any;
  status: string;
  state: any;
  county: any;
  quoteHeaderID: string;
  sicCode: any;
  noData: string = "Not Available";
  totEligibleEmp: number=0;
  salesContactNo: any;
  columnSpan: number;
  isRenewalQuote: any;
  salesRepName: any;
  reqTier: any;
  form: FormGroup;
  accName= 'Loading';
  opportunityID: string;
  userRole:any;
  lob: any;
  quoteOrigin: string;
  isQuoteOriginAutoRunBatch: boolean = false;

  oppTypeToDisplay: string;
  readonly quoteOriginConstants = QUOTE_ORIGIN;
  showProgress = false;
  progressStyle;
  progressMessage;
  progressPercent;
  isSentToOpportunity: boolean = false;
  isUnifiedPayloadSubmission: boolean = false;
  ratingTransId;
  showSpecialitySendToOpp: boolean = false;
  actualMbrCount: number = 0;
  groupNumber: any;
  lobFundingTypeMapForSendToOpp = this.commonService.getEnableSendToOppMap();

  checkUserRole() {
    return CommonUtil.checkUserRole(this.userRole)
}

checkUnderwriterRole(){
  return CommonUtil.userHasUnderwriterRole(this.userRole);
}

checkRenewalBatchRole() {
  return CommonUtil.userHasRenewalBatchRole(this.userRole);
}
  ngOnChanges(changes:SimpleChanges) {
    if (changes.RateData && !changes.RateData.firstChange) {
      this.RateData = this.RateData;
      this.uwAdjustmentData = this.RateData['uwAdjustment'];
      if (this.uwAdjustmentData && this.uwAdjustmentData['peOverrideData']) {
        this.peOverrideData = this.uwAdjustmentData['peOverrideData'];
        this.peOverrideData.rateGuaranteeMonths = this.calculateOverriddenRateGuaranteeMonths(this.peOverrideData);
      }
      this.status = this.RateData.status ? this.RateData.status : this.noData;
    }
  }
  ngOnInit(): void {
    this.route.queryParamMap
      .subscribe((params) => {
        this.ratingTransId = params.get('ratingTransID');
        this.lob = params.get('lob');
      })
      .unsubscribe();
    this.form = this.rootFormGroup.control;
    let quoteReason = this.RateData['quoteReason'];
    if (quoteReason == 'TEST') {
     this.form.controls.quoteReason.setValue(true)
   } else {
     this.form.controls.quoteReason.setValue(false)
   }
   this.accName = this.RateData['accountName'];
    this.addr1 = this.RateData['addr1'];
    this.addr2 = this.RateData['addr2'];
    this.compZipcode = this.RateData['companyZipCode'];
    this.county = this.RateData['county'];
    this.experienceIncluded = this.RateData["dental"]['experienceClaimsAvailable'];
    this.virginGroup = this.RateData["virginGroup"];
    this.groupNumber = this.RateData["groupNbr"];
    this.rateGuaranteeMonths = this.RateData["dental"]["rateGuaranteeMonths"];

    if (this.RateData && this.RateData['dental'] && this.RateData['opportunityType'] == 'Renewal Local') {
      this.rateGuarenteeEffDate = this.RateData["dental"]["guaranteeEffectiveDate"];
      this.rateGuarenteeEndDate = this.RateData["dental"]["guaranteeEndDate"];
    }
    this.contractStartDate = this.RateData.contractEffectiveDate;
    this.mbs = this.RateData.mbs;
    this.supportingDocLinks = this.RateData.supportingDocLinks;
    this.urlData = this.getCOM2url();
    this.opportunityType = this.RateData['opportunityType'];
    this.quotingType = this.RateData['quotingType'];
    this.marketSegment = this.RateData['marketSegment'];
    this.uwAdjustmentData = this.RateData['uwAdjustment'];
    if (this.uwAdjustmentData && this.uwAdjustmentData['peOverrideData']) {
      this.peOverrideData = this.uwAdjustmentData['peOverrideData'];
      this.peOverrideData.rateGuaranteeMonths = this.calculateOverriddenRateGuaranteeMonths(this.peOverrideData);
    }

    this.oppTypeToDisplay = this.RateData.opportunityType.replace(' Local', '');
    this.quoteOrigin = this.RateData.quoteOrigin;
    this.isQuoteOriginAutoRunBatch = this.RateData.quoteOrigin == RenewalsConstants.AUTO_RUN_BATCH;
    if (this.RateData.primaryUserInfo) {
      //If primaryUser exist then it takes priority
      this.salesRepName = this.RateData.primaryUserInfo.fullName ?
        this.RateData.primaryUserInfo.fullName : this.noData;
      this.salesContactNo = this.RateData.primaryUserInfo.contactNumber ?
        this.RateData.primaryUserInfo.contactNumber : this.noData;
    } else {
      this.salesRepName = this.noData;
      this.salesContactNo = this.noData;
    }
    if (this.RateData.uwAdjustment) {
      this.reqTier = this.RateData.uwAdjustment.dentalOutputTier;
    }
    if (!this.reqTier) { this.reqTier = this.RateData.dentalOutputTier; }
    if (this.RateData?.censusCalc?.censusMember) {
      this.actualMbrCount = this.RateData.censusCalc.censusMember?.censusCount ? this.RateData.censusCalc.censusMember?.censusCount : 0;
    }
    if (this.RateData?.censusCalc?.censusSubscriber) {
      this.totEligibleEmp = this.RateData.censusCalc.censusSubscriber.denEligibilityLivesMap.E ?
        this.RateData.censusCalc.censusSubscriber.denEligibilityLivesMap.E : 0;
      this.quotedCount = this.RateData["censusCalc"]["censusSubscriber"]["denEligibilityLivesMap"]["QuotedCount"] ? this.RateData.censusCalc.censusSubscriber.denEligibilityLivesMap.QuotedCount : 0;
      this.waivers = this.RateData["censusCalc"]["censusSubscriber"]["denEligibilityLivesMap"]["W"] ? this.RateData.censusCalc.censusSubscriber.denEligibilityLivesMap.W : 0;
    }
    this.factorEffectiveDate = this.RateData.factorEffectiveDate;
    this.state = this.RateData.state ? this.RateData.state : this.noData;
    this.quoteHeaderID = this.RateData.quoteHeaderID ? this.RateData.quoteHeaderID : this.noData;
    this.opportunityID = this.RateData.opportunityID ? this.RateData.opportunityID : this.noData;
    this.status = this.RateData.status ? this.RateData.status : this.noData;
    this.getIsSentToOpportunity();
  }
  getCOM2url(): any {
    let supportingDocLinksKeywords=this.commonService.getSupportingDocLinksKeywords();
    return CommonUtil.getCOM2url(this.supportingDocLinks,supportingDocLinksKeywords);
  }
  isRenewalQuoteDisabled() {
    if (this.RateData != undefined) {
      this.isRenewalQuote = this.RateData['opportunityType'];
      if (this.isRenewalQuote == 'Renewal Local') {
        this.columnSpan = 1;
        return true;
      } else {
        this.columnSpan = 3;
        return false;
      }
    }
  }

  calculateOverriddenRateGuaranteeMonths(peOverrideData) {
    if (peOverrideData.rateGuaranteeEffectiveDate || peOverrideData.rateGuaranteeEndDate) {
      return this.commonQuoteService.calculateRateGuaranteeMonths(new Date(peOverrideData.rateGuaranteeEffectiveDate), new Date(peOverrideData.rateGuaranteeEndDate));
    } else {
      return null;
    }
  }


  stringConversion(value) {
    return StringUtils.convertToString(value);
  }

  isOverridden(original, overridden) {
    return !StringUtils.isEqual(String(original), String(overridden));
  }

  getAccName(){
    if(this.accName){
     return this.accName;
    }
  }


  openOpp() {
    const url = '/opportunity/create-opportunity-new';
    if (url) {
      const pathToNavigate = '/opportunity/create-opportunity-new';
      const url = this.router.serializeUrl(
        this.router.createUrlTree([pathToNavigate], {
          queryParams: {
            opportunityID: this.opportunityID
          }
        })
      );
      localStorage.setItem('quoteHeaderID', this.quoteHeaderID);
      localStorage.setItem('opportunityID', this.RateData.opportunityID);
      localStorage.setItem('isLoginAgain', 'true');
      localStorage.setItem('assignedUserRoles', this.authService.getUserRole());
      localStorage.setItem('assignedUserRolesTextToDisplay', this.authService.getUserRoleTextToDisplay());
      localStorage.setItem('sendToOpp', 'true');
      localStorage.setItem('assignedUserLobs', this.authService.getUserLob());
      localStorage.setItem('assignedUserStates', this.authService.getUserState());
      localStorage.setItem('disableAll', 'false');
      window.open(url, '_blank');
    } else {
      alert("Opportunity Details doesn't exist");
    }
  }

  disableCensusDownload() {
    // Check census privilege only for renewals - if no privilege, disable download
    const isRenewal = StringUtils.isEqualIgnoreCase(this.opportunityType, 'Renewal Local');
    if (isRenewal) {
      const hasCensusPrivilege = this.authService.isCensusPrivilegedUser(this.commonService.getAssignedUserGroup());
      if (!hasCensusPrivilege) {
        return true;
      }
    }

    if(this.marketSegment === 'LG'&& this.RateData && this.quotedCount > 0 && !this.isFileUpload) {
      return false;
    } else if (this.marketSegment === 'LG' && isRenewal && !this.alternateQuote) {
      return true;
    }
    return false;
  }

  sendToOppClicked() {
    this.showProgress = false;
    this.progressPercent = 20;
    this.progressStyle = 'progress-bar-warning';

    let quoteSelectorDetails = {
      quoteHeaderID: this.quoteHeaderID,
      lob: this.lob,
      fundingType: this.fundingType
    }
    
    if(!this.alternateQuote) {
      quoteSelectorDetails = null
    }

    this.commonQuoteService
      .sendToOpportunitiesQuote(this.opportunityID, this.lob, this.fundingType, this.ratingTransId, quoteSelectorDetails)
      .subscribe(
        (apiResponse) => {
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = 'progress-bar-warning';
          const apiStatus = apiResponse.data.status;
          if (apiStatus.code == '200') {
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            this.progressMessage = apiStatus.msg;

            // Set isSentToOpportunity to true and persist it
            this.isSentToOpportunity = true;
            localStorage.setItem(`isSentToOpportunity_${this.opportunityID}`, JSON.stringify(this.isSentToOpportunity));
          }
          setTimeout(() => {
            this.showProgress = false;
          }, this.commonService.getProgressBarTimeOut());

          this.isUnifiedPayloadSubmission = true;
        },
        (error) => {
          this.progressPercent = 90;
          this.progressStyle = 'progress-bar-danger';
          this.progressMessage = 'Error in getting response from Send To Opportunities';
          console.error('Error calling sendToOpportunities API:', error);
          setTimeout(() => {
            this.showProgress = false;
          }, this.commonService.getProgressBarTimeOut());
        }
      );
  }

  isRenewal() {
    return StringUtils.isEqualIgnoreCase(this.opportunityType, 'Renewal Local');
  }


  async getIsSentToOpportunity() {
    // Check localStorage for the persisted state of isSentToOpportunity
    const storedState = localStorage.getItem(`isSentToOpportunity_${this.opportunityID}`);
    if (storedState !== null) {
      this.isSentToOpportunity = JSON.parse(storedState);
    } else {
      this.isSentToOpportunity = false; // Default to false if no stored state

      // Fetch opportunities and update isSentToOpportunity if applicable
      let response = await firstValueFrom(this.commonQuoteService.getOpportunitesByOppID(this.opportunityID, this.lob));

      if (response != null) {
        for (var opp of response.opportunities) {
          if (opp && opp.opportunityID === this.opportunityID) {
            if (!this.isSentToOpportunity) {
              this.isSentToOpportunity = opp.isSentToOpportunity ?? false;

              // Persist the state in localStorage
              localStorage.setItem(`isSentToOpportunity_${this.opportunityID}`, JSON.stringify(this.isSentToOpportunity));
            }
          }
        }
      }

      if (this.isSentToOpportunity) {
        this.isUnifiedPayloadSubmission = true;
      }
    }
  }

  showSendToOppBasedOnConfig() {
    return (
      this.lobFundingTypeMapForSendToOpp &&
      Object.keys(this.lobFundingTypeMapForSendToOpp).includes(this.lob)
    );
  }

  downLoadCensus() {
    this.commonQuoteService.downLoadCensus(this.RateData['censusRefId'], this.lob, this.quoteHeaderID, this.opportunityType, this.groupNumber);
  }

  displayGuardrailErrorMessage(eleID, value) {
    switch (eleID) {
      case CommonConstants.IN_RATE_GUARANTEE:
        return CommonConstants.GAURD_RAIL_ERROR_MESSAGE_FOR_NOT_IN_RATE_GUARANTEE;
      default:
        return;
    }
  }

  failedGuardRailsForDentalQuote(failedGuardRails, name) {
    switch (name) {
      case CommonConstants.IN_RATE_GUARANTEE:
        return failedGuardRails?.includes(CommonConstants.Failed_Dental_Rate_Guarantee);
      case CommonConstants.LOSS_RATIO:
        return failedGuardRails?.includes(CommonConstants.GroupExpSummary_LossRatio);
      default:
        return;
    }
  }

  displayGuardrailErrorMessageForLossRatio() {
    return CommonConstants.GAURD_RAIL_ERROR_MESSAGE_FOR_LOSS_RATIO + ' ' + (this.RateData?.groupExperienceSummary?.lossRatio * 100).toFixed(2) + '%';
  }

}
