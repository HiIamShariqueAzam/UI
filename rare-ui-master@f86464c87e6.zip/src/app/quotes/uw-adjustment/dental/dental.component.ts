import { DatePipe, KeyValue, Location } from '@angular/common';
import { AfterViewInit, Component, ElementRef, Inject, OnDestroy, OnInit, Renderer2, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { MultiSelect } from 'primeng/multiselect';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { RateInfo } from 'src/app/shared/models';
import { AdjustmentForm } from 'src/app/shared/models/uwAdjustmentDental';
import { AuthenticationService, PrintExhibitService } from 'src/app/shared/services';
import { CommonService } from 'src/app/shared/services/common.service';
import { OffCycleModalService } from 'src/app/shared/services/off-cycle-modal.service';
import { OffCycleModalComponent } from 'src/app/shared/components/off-cycle-modal/off-cycle-modal.component';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { isArray } from 'util';
import { CommonQuoteService } from '../../services/common-quote.service';
import { DentalPremiumComparisonComponent } from './dental-premium-comparison/dental-premium-comparison.component';
import { DentalConstants } from './dental.constants';
import { QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
import { UWAdjustmentChangeSetService } from '../medical/uw-adjust-changeset.service';
import { CommonUtil } from 'src/app/shared/utils/common-util';

@Component({
  selector: 'app-dental',
  templateUrl: './dental.component.html',
  styleUrls: ['./dental.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class DentalComponent implements OnInit, OnDestroy, AfterViewInit {
  selectedProposalSheets: string[] = [];
  private eventSources: EventSource[] = [];

  @ViewChild(DentalPremiumComparisonComponent) dentalPremiumCoparisonComponent;
  @ViewChild(OffCycleModalComponent, { static: false }) offCycleModalComponent!: OffCycleModalComponent;
  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  RateInfo: any;
  RateData: any[];
  copyOfRateData: any;
  plans: RateInfo[];
  featuredPlans: RateInfo[];
  dentalAdjustmentNode = [];
  portfolioPlans: RateInfo[];
  calcDetails: any[];
  userSelectedTier: any;
  selectedQuoteAction: any;
  lobFundingType: any;
  adjustment_form: FormGroup<AdjustmentForm>;
  public isCollapsed = false;
  public isCollapsedAd = false;
  public div_visible = false;
  public disableSoldTab = false;
  value: Date;
  contractEndDate: any;
  factorEffectiveDate: any;
  reqTier: any;
  inputTier: any;
  accountName = 'Loading';
  salesRepName: any;
  noData: string = 'Not Available';
  salesContactNo: any;
  denPlans: any[];
  currentPlans: any[];
  errorPlans: any[] = [];
  rateColumns: any[];
  planColumnsF: any;
  planColumnsP: any;
  status: String;
  quoteError: any = '';
  quoteErrorMessage: boolean = false;
  currentPlanLog: any;
  currentPlanName: any;
  factorsList: any;
  printExhibitSheetName : any;
  productAdjustments: any = [];
  dentalPremiumComparison: any;
  disableAll: boolean;
  quoteReason: any;
  mbs: any;
  errorMessage: any;
  isAdjError: boolean = false;
  searchAnywhere: string;
  releaseOptions: any[] = [];
  selectedReleaseOption: any;
  isFileUpload: boolean = false;
  isChangedFlag = false;
  myArr = [];
  adjustedArr = [];
  manualEditFlagsBeforeSave: any = {};
  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  awaitingDataError: string = 'Nothing to display on this dental quote, due to STATUS. Please see status on this page.';
  planColumnsBefore = [
    { header: 'Contract Code' },
    { header: 'Plan Name' },
    { header: 'Plan Type' },
    { header: 'Participation Type' },
    { header: 'Eye Exam' },
    { header: 'Prescription Lens' },
    { header: 'Frames' },
    { header: 'Elective Contact Lens' },
    { header: 'Non Elective Contact Lens' }
  ];
  planColumns = [{ header: 'Error Info' }, { header: 'Plan Type' }];
  errorPlanColumns = [
    { header: 'Error Info' },
    { header: 'Contract Code' },
    { header: 'Plan Name' },
    { header: 'Plan Type' },
    { header: 'Commission' },
    { header: 'Rate Banck Adj %' },
    { header: 'Sales Adj %' },
    { header: 'Network Name' }
  ];
  fiveTierColumns = [
    { header: 'Employee' },
    { header: 'Employee +Spouse' },
    { header: 'Employee +Child' },
    { header: 'Employee +Children' },
    { header: 'Employee +Family' }
  ];
  fourTierColumns = [{ header: 'Employee' }, { header: 'Employee +Spouse' }, { header: 'Employee +Children' }, { header: 'Employee +Family' }];
  threeTierColumns = [{ header: 'Employee' }, { header: 'Employee+1' }, { header: 'Employee +Family' }];
  twoTierColumns = [{ header: 'Employee' }, { header: 'Employee +Family' }];
  oneTierColumns = [{ header: 'Employee' }];
  tierList = [{ tier: '2' }, { tier: '3' }, { tier: '4' }];
  actionList = [{ action: 'Quote' }, { action: 'Decline to Quote' }];

  successMessage: any;
  failureMessage: any;
  warningMessage: any;
  loadingMessage = CommonConstants.QUOTE_DETAILS_LOADING_MESSAGE;
  alertData: any;
  metaTransID: string;
  ratingTransID: string;
  calcDenPlan: any;
  opportunityID: string;
  quoteHeaderID: string;
  quoteOrigin: string;
  lob: string;
  fundingType: string;
  totEligibleEmp: number;
  rateInfoResponse: any;
  alphaNumericPattern = '^[a-z0-9_]{8,15}$';
  exhibitInfo: any[];
  documents: string | any[];
  intervalId: any;
  lobMedical = 'Medical';
  lob1: any;
  assctnDisc: any;
  activeTab: any = 'featured';
  hasPEOverrideError: boolean = false;
  benefitsColSpanE: any;
  benefitsColSpanF: any;
  benefitsColSpanP: any;
  isExpandedF: any;
  isExpandedP: any;
  expandClickedF = false;
  expandClickedP = false;
  portfolioPlanCount = 0;
  featuredPlanCount = 0;
  errorPlanCount = 0;
  medEmp: any;
  transID: any;
  oppID: any;
  dateFormatMMDDYYYY: string = 'MM-dd-yyyy';
  isReadOnlyRole: boolean = false;
  userRole: any;

  adjustedRates = [];
  initialQuotes = [];
  initialRates: any = [];
  uwAdjustedValue: any = 1;
  AdjData: any;
  opportunityData: any = {};
  adjustedPlans: any = [];
  processId: any;
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressStyle: String;
  progressMessage: any;
  dentalBenefits: any;
  activeTab1: string = 'P';
  hideErrorPlan: boolean;
  opportunityType: any = '';
  quotingType: any = '';
  marketSegment: any;
  SGBenefits: any;
  disableprint: boolean = false;
  isMEWARenOGQuote: boolean = false;
  quoteErrorCode: any = '';
  showAdjustmentHistory: boolean = false;
  alternateQuote: boolean = false;
  exhibitSheets: any[] = [];
  exhibitDentalEnabled: boolean = false;

  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute,
    private _location: Location,
    config: NgbModalConfig,
    private modalService: NgbModal,
    public datepipe: DatePipe,
    private authService: AuthenticationService,
    private el: ElementRef,
    private renderer: Renderer2,
    private peService: PrintExhibitService,
    private uwChangeSetService: UWAdjustmentChangeSetService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private commonQuoteService: CommonQuoteService,
    private changeDetectorRef: ChangeDetectorRef,
    public offCycleModalService: OffCycleModalService
  ) {
    config.backdrop = 'static';
    config.keyboard = false;
    this.disableSoldTab = true;
  }

  ngAfterViewInit() {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  setActiveTab(type: string) {
    this.activeTab1 = type;
  }
  open(content) {
    this.modalService.open(content);
  }
  checkUserRole() {
    if (this.userRole.includes('ADMIN') || this.userRole.includes('READONLY')) {
      return true;
    } else if (this.userRole.includes('ADMIN') && !this.userRole.includes('READONLY')) {
      return false;
    }
  }
  updateContractEndDate(e: any) {
    this.contractEndDate = new Date(e);
  }

  createPopup(plan: any) {
    if (this.isSGDentalRenewalQuote() || this.isAutoQuote()) {
      this.dentalBenefits = plan.pmtBenefits;
    } else {
      this.dentalBenefits = plan.planBenefits;
    }
    this.currentPlanLog = plan.trailLog;
    this.currentPlanName = plan.planName;
  }

  originalOrder = (a: KeyValue<string, any>, b: KeyValue<string, any>): number => {
    return 0;
  };
  setDynamicTier(tierValue) {
    if (tierValue == 5) {
      this.rateColumns = this.fiveTierColumns;
    } else if (tierValue == 4) {
      this.rateColumns = this.fourTierColumns;
    } else if (tierValue == 3) {
      this.rateColumns = this.threeTierColumns;
    } else if (tierValue == 2) {
      this.rateColumns = this.twoTierColumns;
    } else if (tierValue == 1) {
      this.rateColumns = this.oneTierColumns;
    }
  }

  isTabActive(plan) {
    this.activeTab = plan;
  }

  loadRateInfo() {
    this.failureMessage = false;
    this.quoteErrorCode = '';
    this.commonQuoteService.getRateInfo(this.transID, this.oppID, this.quoteHeaderID, this.quoteOrigin, this.lob1, this.fundingType).subscribe(
      (response) => {
        var source = this.commonService.listenForStream(response.processId);
        this.eventSources.push(source);
        source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS, (event: any) => {});
        source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS_COMPLETE, (event: any) => {
          source.close();
          let data;
          if (event && event.data) {
            data = JSON.parse(event.data);
          }
          if (data && data.payload) {
            if (data.payload.data && typeof data.payload.data.isFileUpload !== 'undefined') {
              this.isFileUpload = !!data.payload.data.isFileUpload;
            }
            this.adjustmentHistoryClicked();
            let response = data.payload;
            this.metaTransID = response.metadata.metaTransID;
            if (response != null && response.data) {
              this.RateData = response.data;
              // Handle case where RateData might be an array or object for uwAdjustment access
              const rateDataObj = Array.isArray(this.RateData) ? this.RateData[0] : this.RateData;
              this.productAdjustments = rateDataObj?.uwAdjustment?.productAdjustments;
              this.listenPrintExhibit(this.RateData['processID']);
              this.copyOfRateData = JSON.parse(JSON.stringify(response.data));

              this.factorsList = response.data.factors;
              this.printExhibitSheetName = response.data?.uwAdjustment?.peOverrideData?.printExhibitEligibility?.filter(item => item.sheetStatus === 'Include').map(item => item.printExhibitSheetName);
              this.mbs = response.data.mbs;
              this.opportunityType = this.RateData['opportunityType'];
              this.quoteHistoryClicked();
              this.quotingType = this.RateData['quotingType'];
              this.marketSegment = this.RateData['marketSegment'];
              let quoteReason = this.RateData['quoteReason'];
              this.authService.userRoleTextToDisplay.subscribe((data) => {
                if (data.includes('Read Only')) {
                  this.isReadOnlyRole = true;
                  this.adjustment_form.controls.quoteReason.disable();
                  this.adjustment_form.disable();
                }
              });
              if (quoteReason == 'TEST') {
                this.adjustment_form.controls.quoteReason.setValue(true);
              } else {
                this.adjustment_form.controls.quoteReason.setValue(false);
              }

              if (response.data.contractEndDate) {
                let ctrctDate = new Date(response.data.contractEndDate);
                this.contractEndDate = new Date(ctrctDate.getUTCFullYear(), ctrctDate.getUTCMonth(), ctrctDate.getUTCDate());
              }
              this.factorEffectiveDate = response.data.factorEffectiveDate;
              if (response.data.uwAdjustment) this.reqTier = response.data.uwAdjustment.dentalOutputTier;
              if (!this.reqTier) this.reqTier = response.data.dentalOutputTier;
              this.inputTier = response.data.dentalInputTier;
              if (response.data.factors && response.data.factors.assctnFctr) {
                this.assctnDisc = response.data.factors.assctnFctr;
              }
              this.setDynamicTier(this.reqTier);
              if (response.data.availableTiers) {
                this.tierList = response.data.availableTiers;
                this.tierList.sort((a, b) => (a.tier > b.tier ? 1 : b.tier > a.tier ? -1 : 0));
              }
              this.accountName = response.data.accountName;

              this.dentalPremiumComparison = response.data.dentalPremiumComparison ? response.data.dentalPremiumComparison : null;
              this.opportunityID = response.data.opportunityID ? response.data.opportunityID : this.noData;
              this.quoteHeaderID = response.data.quoteHeaderID ? response.data.quoteHeaderID : this.noData;
              this.status = response.data.status ? response.data.status : this.noData;

              this.rateInfoResponse = response;

              this.disableSoldTab = !(response.data.soldEnabled == true || response.data.soldEnabled == 'true');
              if (response.data.dental) {
                this.denPlans = response.data.dental.proposedPlans;
                this.currentPlans = response.data.dental.currentPlans;
                //enable after dental alt mrkt
                this.alternateQuote = response.data?.dental?.alternateQuote;
              }
              this.featuredPlans = [];
              this.portfolioPlans = [];

              this.errorPlans = [];
              this.featuredPlanCount = 0;
              this.portfolioPlanCount = 0;
              this.errorPlanCount = 0;
              if (this.denPlans) {
                this.denPlans.forEach((item) => {
                  if (item.errors && item.errors.metadata) {
                    this.errorPlans.push(item);
                    this.errorPlanCount++;
                  } else {
                    if (StringUtils.isEqual(item.planTypeRequested, 'F')) {
                      if (item.factors) {
                        this.featuredPlans.push(item);
                        this.featuredPlanCount++;
                      } else {
                        this.hideErrorPlan = true;
                        this.featuredPlans.push(item);
                        this.featuredPlanCount++;
                      }
                    } else if (StringUtils.isEqual(item.planTypeRequested, 'P')) {
                      this.portfolioPlans.push(item);
                      this.portfolioPlanCount++;
                    }
                  }
                });
              }

              // Update featured plans rateInfo with the latest data from proposedPlans
              if (response.data.dental && response.data.dental.proposedPlans) {
                response.data.dental.proposedPlans.forEach((proposedPlan: any) => {
                  const featuredPlanIndex = this.featuredPlans.findIndex(
                    (fp: any) => fp.ratingPlanID === proposedPlan.ratingPlanID
                  );
                  if (featuredPlanIndex !== -1) {

                    // Restore the manual edit flags from our stored map
                    const storedFlags = this.manualEditFlagsBeforeSave[proposedPlan.ratingPlanID];
                    if (storedFlags) {
                      // If manual edit flags exist, use the values from dentalPremiumComparison (which has the updated manual values)
                      const planComparison = this.dentalPremiumComparison?.planComparison.find(
                        (comparison: any) => comparison.quoteRatingPlanID === proposedPlan.ratingPlanID
                      );

                      if (planComparison && planComparison.quoteRates) {
                        // Update rateInfo with the manually edited values from premium comparison
                        const updatedRateInfo = { ...proposedPlan.rateInfo };
                        updatedRateInfo.single = planComparison.quoteRates.ratesT1;
                        updatedRateInfo.eeSpouse = planComparison.quoteRates.ratesT2;
                        updatedRateInfo.eeChildren = planComparison.quoteRates.ratesT3;
                        updatedRateInfo.eeChild = planComparison.quoteRates.ratesT3;
                        updatedRateInfo.family = planComparison.quoteRates.ratesT5 || planComparison.quoteRates.ratesT4 || planComparison.quoteRates.ratesT3 || planComparison.quoteRates.ratesT2;

                        (this.featuredPlans[featuredPlanIndex] as any).rateInfo = updatedRateInfo;
                      } else {
                        // Fallback to API response values
                        (this.featuredPlans[featuredPlanIndex] as any).rateInfo = { ...proposedPlan.rateInfo };
                      }

                      // Restore the manual edit flags
                      (this.featuredPlans[featuredPlanIndex] as any).wasProposedPlanRatesEdited = storedFlags.wasProposedPlanRatesEdited;
                      (this.featuredPlans[featuredPlanIndex] as any).isProposedPlanRatesEdited = storedFlags.isProposedPlanRatesEdited;
                    } else {
                      // No manual edit flags, use API response values
                      (this.featuredPlans[featuredPlanIndex] as any).rateInfo = { ...proposedPlan.rateInfo };
                    }

                  }
                });
              }

              if (response.data.uwAdjustment) {
                this.dentalAdjustmentNode = response.data.uwAdjustment.dentalAdjustments ? response.data.uwAdjustment.dentalAdjustments : [];

                this.adjustment_form.get(DentalConstants.uwNotesToSales).setValue(response.data.uwAdjustment.uwNotesToSales || '');
                this.adjustment_form.get(DentalConstants.uwComments).setValue(response.data.uwAdjustment.uwComments || '');
              }
              this.adjustment_form
                .get(DentalConstants.salesNotetoUW)
                .setValue(this.RateData['dental'][DentalConstants.salesNotetoUW] || '', { emitEvent: false });

              if (this.featuredPlanCount === 0) {
                this.portfolioPlanCount > 0 ? (this.activeTab = 'portfolio') : (this.activeTab = 'erred');
              }
              this.quoteError = '';
              if (response.data.errors && response.data.errors.errorList) {
                for (let error of response.data.errors.errorList) {
                  this.quoteErrorCode = error.code;
                  if (this.quoteError) this.quoteError = this.quoteError + ' , ' + error.msg;
                  else this.quoteError = error.msg;
                }
                this.quoteError = this.quoteError.replaceAll('. ,', '. ');
                if (this.quoteError) {
                  this.quoteErrorMessage = true;
                }
              }
                this.constructAdjPlansWhenNotAdjusted();
                this.initialRates = JSON.parse(JSON.stringify(this.featuredPlans));
                if (response.data.dentalPremiumComparison) {
                  this.initialQuotes = JSON.parse(JSON.stringify(this.dentalPremiumComparison.planComparison));
                }
            }
          }
        });
        source.addEventListener('FAILED', (message: any) => {
          source.close();
          this.div_visible = false;
          console.error('Received fail event:', message);
          this.div_visible = false;
        });
        this.div_visible = false;
      },
      (error) => {
        console.error(error);
      }
    );
  }

  loadPrintExhibitsInfo(callPrintExhibit: boolean, exhibitDocs: any) {
    if (callPrintExhibit) {
      this.commonQuoteService.getPrintExhibitInfo(this.transID, 'Dental').subscribe(
        (response) => {
          if (response != null) {
            this.documents = this.prepareUniquePrintExhibitList(response.exhibits);
          }
        },
        (error) => {
          console.error(error);
        }
      );
    } else {
      this.documents = this.prepareUniquePrintExhibitList(exhibitDocs);
    }
  }

  deepCopy(data: any) {
    if (data) {
      return JSON.parse(JSON.stringify(data));
    }
  }

  prepareUniquePrintExhibitList(exhibits): any[] {
    if (exhibits && isArray(exhibits)) {
      exhibits = exhibits.sort(function (a: any, b: any) {
        let dateA: any = new Date(a.submittedTimestamp);
        let dateB: any = new Date(b.submittedTimestamp);
        return dateB - dateA;
      });

      const result = [];
      const set = new Set();
      const peNameRegex = /(\d{4}-\d{2}-\d{2}T)(?!.*\1)/;
      for (const exhibit of exhibits) {
        if (!set.has(exhibit.exhibitDocId + exhibit.released) || exhibit.released) {
          set.add(exhibit.exhibitDocId + exhibit.released);
          let name = exhibit.fileName.substring(0, exhibit.fileName.match(peNameRegex).index - 1);
          exhibit['peName'] = name;
          result.push(exhibit);
        }
      }
      return result;
    }
    return exhibits;
  }
  downloadPrintExhibitsFile(contentKey) {
    if (contentKey != null && contentKey != '') {
      contentKey = contentKey.replace('{', '%7B');
      contentKey = contentKey.replace('}', '%7D');
    }
    this.commonQuoteService.getFileFromFilenet(contentKey).subscribe(
      (response) => {
        if (response != null) {
          let contentData = response.contentData ? response.contentData : this.noData;
          let contentName = response.contentName ? response.contentName : this.noData;
          const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, contentName);
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }

  currentTab: any;
  ngOnInit() {
    this.exhibitDentalEnabled = this.commonService.getenabledExhibitOverrideDental();
    this.releaseOptions.push({ label: 'Initial Release', value: 'initial' });
    // $(document).ready(function () {
    //   let modalContent: any = $('.modal-content');
    //   let modalHeader = $('.modal-body');
    //   let modalDialog = $('.modal-dialog');
    //   modalHeader.addClass('cursor-all-scroll');
    // });
    // $('#myModalRequoteDental').on('shown.bs.modal', function () {
    //   $(this).find('.modal-body').css({
    //     width: 'auto',
    //     height: 'auto',
    //     'max-width': '100%'
    //   });
    // });
    this.authService.userRoleTextToDisplay.subscribe((data) => {
      if (data.includes('Read Only')) {
        this.isReadOnlyRole = true;
        this.disableAll = true;
      }
    });
    window.scroll(0, 0);
    this.route.queryParams.subscribe((params) => {
      this.lob_FT = params['availableTabs'];
      var disableAllBoolean = params['disableAll'];
      this.disableAll = disableAllBoolean != undefined && disableAllBoolean === 'true';
      this.searchAnywhere = params[CommonConstants.SELECTED_SEARCH_ANYWHERE];

      this.opportunityData = {
        opportunityID: params[CommonConstants.OPPORTUNITY_ID],
        quoteHeaderID: params[CommonConstants.QUOTEHEADER_ID],
        ratingTransID: params[CommonConstants.RATINGTRANS_ID],
        lob: params[CommonConstants.LOB],
        fundingType: params[CommonConstants.FUNDING_TYPE],
        quoteOrigin: params[CommonConstants.QUOTE_ORIGIN],
        marketSegment: params[CommonConstants.MARKET_SEGMENT],
      };
    });
    this.quoteOrigin = this.opportunityData.quoteOrigin;
    this.benefitsColSpanF = 7;
    this.benefitsColSpanP = 7;
    this.benefitsColSpanE = 8;
    this.isExpandedF = false;
    this.isExpandedP = false;
    this.planColumnsF = this.planColumnsBefore;
    this.planColumnsP = this.planColumnsBefore;
    this.route.queryParams.subscribe((params) => {
      this.oppID = params[CommonConstants.OPPORTUNITY_ID];
      this.transID = params[CommonConstants.RATINGTRANS_ID];
      this.lob1 = params[CommonConstants.LOB];
      this.fundingType = params[CommonConstants.FUNDING_TYPE];
      this.quoteHeaderID = params[CommonConstants.QUOTEHEADER_ID];
      this.lob_FT = params[CommonConstants.AVAILABLE_TABS];
      this.getCurrentTabList();
    });

    this.selectedQuoteAction = { action: 'Quote' };
    this.userSelectedTier = '';
    this.loadRateInfo();
    setTimeout(() => {
      this.quoteHistoryClicked();
    }, 2000);
    this.loadPrintExhibitsInfo(true, null);
    this.initializeAdjustmentForm();

    this.userRole = this.authService.userRole['_value'];
    this.commonService.setOpportunityId(this.opportunityData.opportunityID);
    this.commonService.setquoteHeaderId(this.opportunityData.quoteHeaderID);
    const myDropdown = this.el.nativeElement.querySelector('releaseMouseHover');
    if (myDropdown) {
      myDropdown.click();
    }
  }
  isInitialQuoteUpdate: boolean = false;
  releaseType: string;
  lob_FT: any[];
  getRenDropdownClass() {
    return this.opportunityType == 'Renewal Local' ? 'renewal-bg' : '';
  }
  onMouseFocus(event) {
    this.multiSelect?.show();
    event.stopPropagation();
  }
  onRelease(event) {
    if (event != null) {
      this.releaseType = this.selectedReleaseOption;
    }
  }
  // needs to add functionality later
  onSubmit(form: FormGroup) {}

  ngOnDestroy() {
    this.eventSources.forEach((source) => source.close());
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }
  action: any;
  onApplyAdjustments(action: string) {
    let checkAdjErr = false;
    let errorCount = 0;
    this.action = action;
    this.featuredPlans.forEach((item, i) => {
      checkAdjErr = this.checkIfNull(this.featuredPlans[i]);
      if (checkAdjErr) errorCount++;
    });
    if (errorCount > 0) {
      this.alertData = 'Please fix the issue with UW Adjustment to proceed.';
      this.setWarningFlag();
      return;
    }

    if (this.hasPEOverrideError) {
      this.alertData = "Please enter Mandatory fields in Exhibit Overrides section\n";
      this.setWarningFlag();
      window.scroll(0, 0);
      return;
    }

    this.commonService.onResetClick = this.commonService.onMatchClick = false;
    window.scroll(0, 0);
    if (
      (StringUtils.isEqual(action, DentalConstants.declineAction) && !this.adjustment_form.controls.uwNotesToSales.value.trim()) ||
      (StringUtils.isEqual(action, DentalConstants.releaseAction) && !this.adjustment_form.controls.uwNotesToSales.value.trim() && this.isAdjusted) ||
      (StringUtils.isEqual(action, DentalConstants.releaseAction) && this.status == 'Modified' && !this.adjustment_form.controls.uwNotesToSales.value.trim())
    ) {
      this.alertData = 'Please enter UW notes to sales';
      this.setWarningFlag();
      return;
    } else {
      this.opportunityData.accountName = this.accountName;
      this.opportunityData.previousOutputTier = this.reqTier;
      this.opportunityData.opportunityType = this.RateData['opportunityType'];
      this.opportunityData.quotingType = this.RateData[CommonConstants.QUOTING_TYPE];
      this.AdjData = {
        opportunity: this.opportunityData,
        uwAdjustment: this.constructReqObj(),
        quoteReason: this.addQuote()
      };
      if (this.AdjData.uwAdjustment && this.AdjData.uwAdjustment['uwChangesetAdjustmentData']) {
        this.AdjData['uwChangesetAdjustmentData'] = this.AdjData.uwAdjustment['uwChangesetAdjustmentData'];
      }

      // Include off-cycle data for Declined, Lost, Termed, Transfer statuses OR Sold with user input
      CommonUtil.handleOffCycleData(
        this.AdjData,
        this.RateData,
        this.status?.toString() || '',
        action,
        this.offCycleModalService.offCycleSubmittedInCurrentSession,
        'Dental',
        'contractEffectiveDate'
      );

      // Reset flag after offCycle data is added to payload
      this.offCycleModalService.offCycleSubmittedInCurrentSession = false;

      this.onSubmitApplyAdjustment(action);
    }
  }

  getCurrentTabList() {
    let tabList = this.commonService.getQuoteTabList();

    // Check if a Medical MEWA Renewal original quote exists in this opportunity
    this.checkMEWARenewalOriginalQuoteExists();

    if (tabList && tabList.length) {
      this.currentTab = this.commonService.getCurrentTab(this.transID, this.lob1);
    } else {
      this.commonQuoteService.getOpportunitesByOppID(this.oppID, this.lob1).subscribe((response) => {
        if (response != null) {
          let lob_FT = [];
          let lob_FT_TransID = [];

          for (var opp of response.opportunities) {
            if (opp && opp.quoteHeaderID === this.quoteHeaderID) {
              let data =
                StringUtils.isEqual(opp.lob, DentalConstants.Medical) &&
                  StringUtils.isEqual(opp.opportunityType, DentalConstants.renewalLocal) &&
                  (StringUtils.isEqual(opp.quotingType, 'ACA') || StringUtils.isEqual(opp.quotingType, CommonConstants.MEWA))
                  ? opp.lob + '-' + opp.quotingType
                  : opp.lob + '-' + opp.fundingType;
              if (opp.marketSegment === this.opportunityData?.marketSegment || (this.opportunityData?.marketSegment === "undefined" || this.opportunityData?.marketSegment === undefined)) {
                if (!lob_FT.find((x) => x === data)) {
                  lob_FT.push(data);
                }
                lob_FT_TransID.push({
                  tabName: data,
                  tabStatus: opp.status,
                  ratingTransID: opp.ratingTransID,
                  fundingType: opp.fundingType,
                  quoteOrigin: opp.quoteOrigin
                });
              }
            }

          }
          this.lob_FT = lob_FT;
          lob_FT_TransID = lob_FT_TransID.filter( id => id.quoteOrigin != QUOTE_ORIGIN.AUTO_RUN_BATCH );
          this.commonService.setQuoteTabList(lob_FT_TransID);
          this.currentTab = this.commonService.getCurrentTab(this.transID, this.lob1);
        }
      });
    }
  }

  constructReqObj() {
    let action;
    let status;
    if (this.action == 'release') {
      action = 'release';
      status = 'Released';
    } else if (this.action == 'save' && !this.isAdjusted) {
      action = 'save';
    } else if (this.isAdjusted) {
      action = 'ADJUST';
      status = 'Modified';
    }

    // Use status from RateData if set (e.g., from Off-Cycle modal)
    if (this.RateData['status']) {
      status = this.RateData['status'];
    }
    const allSheetOptions = this.commonService.getExhibitOverrideDental()
      .filter(item => !!item)
      .map(item => ({ printExhibitSheetName: item, printExhibitTypeCode: item }));
    const printExhibitEligibility = allSheetOptions.map(option => ({
      ...option,
      sheetStatus: "Include"
    }));

    let reqObj = {
      ratingTransID: this.transID,
      action: action,
      status: status,
      dentalAdjustments: (this.isAdjusted || this.isChangedFlag) ? this.constructDentalAdjustmentProp(): [],
      outputTier: this.reqTier,
      dentalPremiumComparison: (this.isAdjusted || this.isChangedFlag) ? this.dentalPremiumComparison: null,
      uwNotesToSales: this.adjustment_form.value.uwNotesToSales,
      uwComments: this.adjustment_form.value.uwComments,
      assignedUWName: this.RateData['underwriterName'] ? this.RateData['underwriterName'] : '',
      dental: true,
      productAdjustments: (this.isAdjusted || this.isChangedFlag) ? this.constructproductAdjustments(this.constructDentalAdjustmentProp()) : [],
      quoteReason: this.addQuote()
    };

    if(this.exhibitDentalEnabled || (this.RateData['uwAdjustment'] && this.RateData['uwAdjustment']?.peOverrideData && this.RateData['uwAdjustment']?.peOverrideData?.rateGuaranteeEffectiveDate && this.RateData['uwAdjustment']?.peOverrideData?.rateGuaranteeEndDate)) {
    let peOverrideDataChangeset: any = this.uwChangeSetService.getPEOverrideDataChangeSetDetails(this.RateData, this.copyOfRateData, allSheetOptions);
    if (peOverrideDataChangeset?.peOverrideValue) {
      this.RateData['uwAdjustment'].peOverrideData.printExhibitEligibility = peOverrideDataChangeset.peOverrideValue.printExhibitEligibility;
      reqObj['peOverrideData'] = this.RateData['uwAdjustment']?.peOverrideData;
    } else{
      reqObj['peOverrideData'] = null;
    }
    reqObj['uwChangesetAdjustmentData'] = peOverrideDataChangeset?.changesetDetail;
   }

    return reqObj;
  }

  constructproductAdjustments(dentalAdjustments: any[]) {
    let productAdjObj = []
    dentalAdjustments.forEach((adj, index) => {
      let adjObj =
      {
        uwAdjustmentFactor: Number(adj.uwAdjustment),
        suggestedRateActionAdjustment: this.productAdjustments?.length > 0 ? this.productAdjustments[index]?.suggestedRateActionAdjustment: 1,
        planName: adj.planName,
        ratingPlanID: adj.ratingPlanID,
        empty: false
      }
      productAdjObj.push(adjObj);
    })

    return productAdjObj;
  }

  constructDentalAdjustmentProp() {
    if (this.status == 'Failed') {
      return [];
    } else if (!this.isAdjusted && this.status == 'Released' && !this.RateData['uwAdjustment'] && !this.adjustment_form.value.uwNotesToSales) {
      return [];
    } else if (this.RateData['showDentalPremiumComparison']) {
      // Always use constructReq() when premium comparison is shown and This ensures rateAdjustment object is included in payload
      return this.dentalPremiumCoparisonComponent.constructReq();
    } else {
      return this.adjustedPlans;
    }
  }
  addQuote() {
    let quoteReason = this.adjustment_form.value.quoteReason;
    if (!quoteReason) {
      quoteReason = 'REAL';
    } else {
      quoteReason = 'TEST';
    }
    return quoteReason;
  }

  isNewBusinessLocal(): boolean {
    return StringUtils.isEqual(this.opportunityType, DentalConstants.newBusinessLocal);
  }

  onSubmitApplyAdjustment(action: string) {
    // Store manual edit flags at the very beginning before any data refresh
    this.manualEditFlagsBeforeSave = {};
    this.featuredPlans.forEach((plan: any) => {
      if (plan.wasProposedPlanRatesEdited || plan.isProposedPlanRatesEdited === 'Y') {
        this.manualEditFlagsBeforeSave[plan.ratingPlanID] = {
          wasProposedPlanRatesEdited: plan.wasProposedPlanRatesEdited,
          isProposedPlanRatesEdited: plan.isProposedPlanRatesEdited
        };
      }
    });

    this.div_visible = true;
    if (this.AdjData.uwAdjustment.dentalAdjustments.length) {
      this.AdjData.uwAdjustment.dentalAdjustments.forEach((element) => {
        if (element.uwAdjustment == null) {
          element.uwAdjustment = 1;
        }
        element.uwAdjustment = Number(element.uwAdjustment);
      });
    }

    this.featuredPlans.forEach((plan: any) => {
      const adjustedPlan = this.adjustedPlans.find(adj => adj.ratingPlanID === plan.ratingPlanID);
      const hasAdjustmentFactor = adjustedPlan && adjustedPlan.uwAdjustment && adjustedPlan.uwAdjustment !== 1;
      if (hasAdjustmentFactor) {
        // Only clear manual edit flags if the plan was NOT manually edited
        // Preserve the Y flag if final rates were manually changed by the user
        if (!plan.wasProposedPlanRatesEdited && plan.isProposedPlanRatesEdited !== 'Y') {
          plan.isProposedPlanRatesEdited = 'N';
          plan.wasProposedPlanRatesEdited = false;
          const planComparison = this.dentalPremiumComparison?.planComparison.find(
            (comparison: any) => comparison.quoteRatingPlanID === plan.ratingPlanID
          );
          if (planComparison) {
            planComparison.isProposedPlanRatesEdited = 'N';
          }
        }
      }
    });

    var useRouterLogic = this.commonQuoteService.useRouterLogicToProcess(action);
    if (this.releaseType != undefined && this.releaseType.length > 0) {
      this.isInitialQuoteUpdate = true;
    } else {
      this.isInitialQuoteUpdate = false;
    }
    this.commonQuoteService
      .submitDentalApplyAdjustment(
        this.AdjData,
        this.metaTransID,
        this.opportunityData.ratingTransID,
        this.RateData['showDentalPremiumComparison'],
        action,
        useRouterLogic,
        this.isInitialQuoteUpdate
      )
      .subscribe(
        (response) => {
          if (response.status === 200) {
            this.adjustmentHistoryClicked();
            this.loadRateInfo();
            setTimeout(() => {
              this.quoteHistoryClicked();
            }, 2000);
            if (StringUtils.isEqual(action, DentalConstants.releaseAction)) {
              this.processId = response.body.processId;
              if (undefined != this.processId) {
                this.clearPreviousAlerts();
                this.showProgress = true;
                this.progressPercent = 1;
                this.progressStyle = 'progress-bar-warning';
                var source = this.commonService.listenForStream(this.processId);
                this.eventSources.push(source);

                source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener('ISOLATE_UWACTION_STATUS', (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener('SEND_EXHIBIT_TO_UI', (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener('DEN_SEND_EXHIBIT_TO_UI', (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);
                });

                source.addEventListener('ISOLATE_UWACTION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);
                });

                source.addEventListener('FAILED', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processFailedEvent(message);
                });
              } else {
                //for direct release without PE
                this.processOthersAction(action);
              }
            } else {
              //for scenarios other than release
              this.processOthersAction(action);
            }
          } else {
            this.processErrorResponse(this.getErrorResponse(action));
          }
        },
        (error) => {
          this.loadRateInfo();
          this.processErrorResponse('System Error');
        }
      );
  }

  processDefaultEvents(event: any) {
    this.progressStyle = '';
    let eventData = JSON.parse(event.data);
    var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
    this.progressPercent = percent;
    this.progressMessage = eventData.message;
  }

  processExhibitDocsEvents(event: any) {
    if (event.data) {
      let data = JSON.parse(event.data);
      if (data.payload && data.payload.exhibits) {
        this.loadPrintExhibitsInfo(false, this.deepCopy(data.payload.exhibits));
      }
    }
  }

  processEventComplete(message: any) {
    let eventData = JSON.parse(message.data);
    this.progressStyle = 'progress-bar-success';
    this.progressPercent = 100;
    this.progressMessage = eventData.message;
    let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
    element.click();
    this.loadRateInfo();
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  processFailedEvent(message: any) {
    console.error('Received event : ', JSON.stringify(message.data));
    this.progressStyle = 'progress-bar-danger';
    this.progressMessage = 'Print exhibit generation or storage to FileNet failed.';
    this.hideProgressBar();
  }

  processOthersAction(action: string) {
    this.alertData = this.getSuccessResponse(action);
    this.setSuccessFlag();
  }

  processErrorResponse(errorResponse: string) {
    this.alertData = errorResponse;
    this.setFailureFlag();
  }

  initializeAdjustmentForm() {
    this.adjustment_form = this.fb.group({
      uwNotesToSales: [''],
      uwComments: [''],
      quoteReason: [''],
      salesNotetoUW: ['']
      // quoteAdjustments: this.fb.group({
      // uwAdjustment: ["", [ValidationService.decimalValidator]],
      // }),
    });
  }
  checkIfNull(plan) {
    if (plan['uwAdjustment'] == null || plan['uwAdjustment'] == undefined) {
      return null;
    } else {
      if (String(plan['uwAdjustment']).match(/^(\d?(\.\d{1,10})?)?$/g)) {
        if (String(plan['uwAdjustment']) !== '0' && String(plan['uwAdjustment']) !== '' && plan['uwAdjustment'] !== undefined) {
          this.isAdjError = false;
          return null;
        } else {
          this.isAdjError = true;
          this.errorMessage = 'Invalid Value';
          return true;
        }
      } else {
        this.isAdjError = true;
        this.errorMessage = 'Invalid Value';
        return true;
      }
    }
  }

  // On Change of Adjustment
  @ViewChild('input') inputEl: ElementRef;
  isAdjusted: boolean;
  constructAdjPlansWhenNotAdjusted() {

    this.featuredPlans.forEach((item, ind) => {
      const fIndex = this.dentalAdjustmentNode.findIndex((obj) => obj.ratingPlanID === item['ratingPlanID'] && obj.planName === item['planName']);
      if (this.featuredPlans[ind]['rateInfo'] != undefined) {
        let cccRate = {
          single: this.featuredPlans[ind]['rateInfo'].EEpremiumWithACAFee,
          eeSpouse: this.featuredPlans[ind]['rateInfo'].ESpremiumWithACAFee,
          eeOne: this.featuredPlans[ind]['rateInfo'].E1premiumWithACAFee,
          eeChild: this.featuredPlans[ind]['rateInfo'].EKpremiumWithACAFee,
          eeChildren: this.featuredPlans[ind]['rateInfo'].ECpremiumWithACAFee,
          family: this.featuredPlans[ind]['rateInfo'].EFpremiumWithACAFee,
          monthlyPremium: 0,
          yearlyPremium: 0
        };
        let ccrRate = {
          single: this.featuredPlans[ind]['rateInfo'].EEpremiumWithACAFee,
          eeSpouse: this.featuredPlans[ind]['rateInfo'].ESpremiumWithACAFee,
          eeOne: this.featuredPlans[ind]['rateInfo'].E1premiumWithACAFee,
          eeChild: this.featuredPlans[ind]['rateInfo'].EKpremiumWithACAFee,
          eeChildren: this.featuredPlans[ind]['rateInfo'].ECpremiumWithACAFee,
          family: this.featuredPlans[ind]['rateInfo'].EFpremiumWithACAFee,
          monthlyPremium: 0,
          yearlyPremium: 0
        };
        let planObj = {
          planName: item['planName'],
          ratingPlanID: item['ratingPlanID'],
          uwAdjustment: null,
          matchCurrent: this.dentalAdjustmentNode.length && fIndex !== -1 ? this.dentalAdjustmentNode[fIndex].matchCurrent : false,
          matchRenewal: this.dentalAdjustmentNode.length && fIndex !== -1 ? this.dentalAdjustmentNode[fIndex].matchRenewal : false,
          reset: this.dentalAdjustmentNode.length && fIndex !== -1 ? this.dentalAdjustmentNode[fIndex].reset : false,
          cccRate: cccRate,
          ccrRate: ccrRate
        };
        if (this.dentalAdjustmentNode.length && fIndex !== -1) {
          planObj.uwAdjustment = this.dentalAdjustmentNode[fIndex].uwAdjustment;
          this.showAdjustmentHistory = true;
        } else {
          if (this.isRenewalQuoteDisabled() && this.dentalAdjustmentNode.length <= 0) {
            planObj.uwAdjustment = item['uwDiscret'];
            this.showAdjustmentHistory = false;
          } else {
            planObj.uwAdjustment = 1;
            this.showAdjustmentHistory = false;
          }
        }
        const findIndex = this.adjustedPlans.findIndex((obj) => obj.ratingPlanID === item['ratingPlanID'] && obj.planName === item['planName']);
        if (findIndex !== -1) {
          this.adjustedPlans[findIndex] = planObj;
        } else {
          this.adjustedPlans.push(planObj);
        }
      }
    });
  }

  adjustedRatingPlanID: any;

  navigateToSoldRates() {
    this.router.navigate([CommonConstants.SOLD_RATES_URL], {
      queryParams: {
        ratingTransID: this.transID,
        opportunityID: this.opportunityID,
        quoteOrigin: this.quoteOrigin,
        quoteHeaderID: this.quoteHeaderID,
        lob: this.lob1,
        groupName: this.accountName,
        fundingType: this.fundingType,
        availableTabs: this.lob_FT,
        state: this.RateData['state'],
        factorEffectiveDate: this.factorEffectiveDate
      }
    });
  }

  onQDMedical() {
    this.router.navigate(['quote/uw-rate'], {
      queryParams: {
        ratingTransID: this.transID,
        opportunityID: this.opportunityID,
        quoteOrigin: this.quoteOrigin,
        quoteHeaderID: this.quoteHeaderID,
        lob: this.lobMedical,
        groupName: this.accountName,
        fundingType: this.fundingType,
        availableTabs: this.lob_FT
      }
    });
  }

  onNavigateTab(data: string) {
    this.currentTab = data;
    let tabData = data.split('-');
    if (tabData[0] === 'Vision') {
      this.fundingType = tabData[1];
      this.ratingTransID = this.commonService.getTransIDforTab(tabData[0], tabData[1]);

      if (this.commonService.isVisionEnabled == 'true') {
        this.router.navigate(['quote/uw-rate-vision'], {
          queryParams: {
            ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
            opportunityID: this.opportunityID,
            quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
            quoteHeaderID: this.quoteHeaderID,
            lob: 'Vision',
            groupName: this.accountName,
            fundingType: tabData[1],
            availableTabs: this.lob_FT,
            searchAnywhere: this.searchAnywhere
          }
        });
      }
    }
    if (tabData[0] === 'Medical') {
      this.router.navigate(['quote/uw-rate'], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
          opportunityID: this.opportunityID,
          quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
          quoteHeaderID: this.quoteHeaderID,
          lob: tabData[0],
          groupName: this.accountName,
          fundingType: this.commonService.getFundingTypeforTab(tabData[0], tabData[1]),
          availableTabs: this.lob_FT,
          quotingTypeFromTab: tabData[1],
          searchAnywhere: this.searchAnywhere
        }
      });
    }
    if (StringUtils.isEqual(tabData[0], CommonConstants.SuppHealth)) {
      this.router.navigate(['quote/uw-rate-supplemental-health'], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
          opportunityID: this.opportunityID,
          quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
          quoteHeaderID: this.quoteHeaderID,
          lob: tabData[0],
          groupName: this.accountName,
          fundingType: this.commonService.getFundingTypeforTab(tabData[0], tabData[1]),
          availableTabs: this.lob_FT,
          searchAnywhere: this.searchAnywhere
        }
      });
    }
  }

  updatePEOverrideError(isError: boolean) {
    this.hasPEOverrideError = isError;
  }

  backClicked() {
    if (!this.storage.get('QuoteSearchQuery')) {
      let searchQuery = {};
      searchQuery['quoteReason'] = this.RateData['quoteReason'] !== 'TEST' ? { $nin: ['TEST'] } : { $in: ['TEST'] };
      searchQuery['alternateQuote'] = this.alternateQuote === true ? { $in: [true, false] } : { $in: [false] };
      searchQuery['opportunityID'] = { $regex: '.*' + this.opportunityData.opportunityID + '.*' };
      searchQuery['quoteOrigin'] = { $in: ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch'] };
      this.storage.set('QuoteSearchQuery', JSON.stringify(searchQuery));
      this.storage.set('fundingType', "");
      this.storage.set('lob', "");
      this.storage.set('quoteHeaderID', "");
      this.storage.set('quoteOrigin', ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch']);
      this.storage.set('alternateQuote', searchQuery['alternateQuote']);
      this.storage.set('showOpportunities', 'true');
      this.storage.set('opportunityID', this.opportunityData.opportunityID);
      this.storage.set('searchAnywhere', this.searchAnywhere);
      this.storage.set('quoteReason', this.RateData['quoteReason'] == 'TEST' ? true : false);
      this.storage.set('pageLimit', 10);
    }
    this.storage.set('searchAnywhere', this.searchAnywhere);
    this.router.navigate(['/quote']);
  }
  setWarningFlag() {
    this.warningMessage = true;
    this.successMessage = false;
    this.failureMessage = false;
  }
  setSuccessFlag() {
    this.div_visible = false;
    this.successMessage = true;
    this.failureMessage = false;
    this.warningMessage = false;
  }
  setFailureFlag() {
    this.div_visible = false;
    this.failureMessage = true;
    this.successMessage = false;
    this.warningMessage = false;
  }
  clearPreviousAlerts() {
    this.div_visible = false;
    this.alertData = '';
    this.removeSuccessMsg();
    this.warningMessage = false;
  }
  getSuccessResponse(action: string) {
    switch (action) {
      case 'release':
        return 'Quote Released Successfully';
      case 'decline':
        return 'Quote Declined Successfully';
      case 'requote':
        return 'Submitted for ReQuote Successfully';
      default:
        return 'Changes are saved successfully';
    }
  }

  getErrorResponse(action: string) {
    switch (action) {
      case 'release':
        return 'Error Releasing the Quote';
      case 'decline':
        return 'Error Declining the Quote';
      default:
        return 'Error in getting response for Underwriter Adjustment';
    }
  }

  removeFailureMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  removeSuccessMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  removeWarningMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  clickedFromDate() {
    let element: HTMLElement = document.querySelectorAll('.fromDateCalendar .p-inputtext')[0] as HTMLElement;
    element.click();
  }

  getDentalRates(plan, tierNumber, type: string): number {
    let currentPlan = this.currentPlans.find((x) => x.id === plan.currPlanId);
    if (currentPlan) {
      switch (this.reqTier) {
        case 1:
          if (tierNumber == 1) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT1;
            } else {
              return currentPlan.rnwlRatesT1;
            }
          }
          break;
        case 2:
          if (tierNumber == 1) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT1;
            } else {
              return currentPlan.rnwlRatesT1;
            }
          } else if (tierNumber == 2) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT2;
            } else {
              return currentPlan.rnwlRatesT2;
            }
          }
          break;
        case 3:
          if (tierNumber == 1) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT1;
            } else {
              return currentPlan.rnwlRatesT1;
            }
          } else if (tierNumber == 2) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT2;
            } else {
              return currentPlan.rnwlRatesT2;
            }
          } else if (tierNumber == 3) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT3;
            } else {
              return currentPlan.rnwlRatesT3;
            }
          }
          break;
        case 4:
          if (tierNumber == 1) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT1;
            } else {
              return currentPlan.rnwlRatesT1;
            }
          } else if (tierNumber == 2) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT2;
            } else {
              return currentPlan.rnwlRatesT2;
            }
          } else if (tierNumber == 3) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT3;
            } else {
              return currentPlan.rnwlRatesT3;
            }
          } else if (tierNumber == 4) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT4;
            } else {
              return currentPlan.rnwlRatesT4;
            }
          }
          break;
        case 5:
          if (tierNumber == 1) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT1;
            } else {
              return currentPlan.rnwlRatesT1;
            }
          } else if (tierNumber == 2) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT2;
            } else {
              return currentPlan.rnwlRatesT2;
            }
          } else if (tierNumber == 3) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT3;
            } else {
              return currentPlan.rnwlRatesT3;
            }
          } else if (tierNumber == 4) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT4;
            } else {
              return currentPlan.rnwlRatesT4;
            }
          } else if (tierNumber == 5) {
            if (StringUtils.isEqual(type, 'C')) {
              return currentPlan.currRatesT5;
            } else {
              return currentPlan.rnwlRatesT5;
            }
          }
          break;
      }
    }
    return 0;
  }

  isReleased(status) {
    if (status === true) {
      return 'releaseStyle';
    } else {
      return false;
    }
  }
  adjHistory = [];
  adjustmentHistoryClicked() {
    this.commonQuoteService
      .getAdjustmentHistory(this.transID, this.oppID, this.quoteHeaderID, this.quoteOrigin, this.lob1, this.fundingType)
      .subscribe((response) => {
        if (response) {
          this.adjHistory = response;
          this.adjHistory = this.adjHistory.map((adjData, index) => {
            adjData['AdjNo'] = this.adjHistory.length - index;
            return adjData;
          });
        }
      });
  }

  onGeneratePrintExhibit() {
    this.opportunityData.accountName = this.accountName;
    this.opportunityData.previousOutputTier = this.reqTier;
    this.disableprint = true;
    let openPEDropdown = false;
    this.AdjData = {
      opportunity: this.opportunityData,
      uwAdjustment: this.constructReqObj(),
      quoteReason: this.addQuote()
    };
    this.commonQuoteService.generatePrintExhibit(this.AdjData, this.metaTransID, this.transID, this.quoteErrorCode).subscribe(
      (response) => {
        if (response.status === 200) {
          this.processId = response.body.processId;
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = 'progress-bar-warning';
          var source = this.commonService.listenForStream(this.processId);
          this.eventSources.push(source);
          source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
            this.progressStyle = '';
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
          });
          source.addEventListener('SEND_EXHIBIT_TO_UI', (event: any) => {
            if (event.data) {
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.exhibits) {
                openPEDropdown = true;
                this.loadPrintExhibitsInfo(false, this.deepCopy(data.payload.exhibits));
              }
            }
          });
          source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
            console.log('Received complete event');
            source.close();
            this.commonQuoteService.cleanUpSSEEvents(this.processId);
            let eventData = JSON.parse(message.data);
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            this.progressMessage = eventData.message;
            let contentData = eventData.payload.contentData;
            let contentName = eventData.payload.contentName;
            if (eventData.payload.contentMetadata) {
              contentName = eventData.payload.contentMetadata[0].value;
            }
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
            let isXLSX;
            if (contentName.includes('.xlsx')) isXLSX = '';
            else isXLSX = '.xlsx';
            this.peService.createAndDownloadBlobFile(arrayBuffer, contentName + isXLSX);
            if (openPEDropdown) {
              let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
              element.click();
            }
            this.disableprint = false;
            setTimeout(() => {
              this.showProgress = false;
              if (this.quoteErrorCode == 'E1403') {
                this.loadRateInfo();
              }
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener('FAILED', (message: any) => {
            this.disableprint = false;
            console.log('Received fail event');
            source.close();
            this.commonQuoteService.cleanUpSSEEvents(this.processId);
            this.progressStyle = 'progress-bar-danger';
            this.progressMessage = 'Print exhibit generation or storage to FileNet failed.';
            this.hideProgressBar();
          });
        }
      },
      (error) => {
        this.disableprint = false;
        console.log(error);
        alert('Error while generating print exhibit');
      }
    );
  }

  listenPrintExhibit(processId: any) {
    if (processId != null && processId != undefined && processId !== '') {
      var source = this.commonService.listenForStreamTrackAndFail(processId);
      this.eventSources.push(source);
      source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
        this.showProgress = true;
        this.progressStyle = '';
        let eventData = JSON.parse(event.data);
        var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
        this.progressPercent = percent;
        this.progressMessage = eventData.message;
      });
      source.addEventListener('SEND_EXHIBIT_TO_UI', (event: any) => {
        this.showProgress = true;
        if (event.data) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.exhibits) {
            this.loadPrintExhibitsInfo(false, this.deepCopy(data.payload.exhibits));
          }
        }
      });
      source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
        this.showProgress = true;
        source.close();
        this.commonQuoteService.cleanUpSSEEvents(processId);
        let eventData = JSON.parse(message.data);
        this.progressStyle = 'progress-bar-success';
        this.progressPercent = 100;
        this.progressMessage = eventData.message;
        let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
        element.click();
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      });
      source.addEventListener('FAILED', (message: any) => {
        this.showProgress = true;
        source.close();
        this.commonQuoteService.cleanUpSSEEvents(processId);
        this.progressStyle = 'progress-bar-danger';
        this.progressPercent = 90;
        this.progressMessage = 'Print exhibit generation or storage to FileNet failed.';
        this.hideProgressBar();
      });
      source.addEventListener('NO_EVENTS', (message: any) => {
        source.close();
      });
    }
  }

  onMatchBtnClick(obj) {
    this.commonService.onMatchClick = true;
    let outputTier = this.RateData['dentalOutputTier'];
    let currRen;
    this.isAdjusted = true;
    const findIndex = this.featuredPlans.findIndex((item) => item['ratingPlanID'] == obj.plan.quoteRatingPlanID);

    if (StringUtils.isEqual(obj.type, 'C')) {
      currRen = 'currentRates';
    } else {
      currRen = 'renewalRates';
    }
    if (outputTier == 1) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = obj.plan[currRen]['ratesT1'];
    } else if (outputTier == 2) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = obj.plan[currRen]['ratesT1'];
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = obj.plan[currRen]['ratesT2'];
    } else if (outputTier == 3) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = obj.plan[currRen]['ratesT1'];
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = obj.plan[currRen]['ratesT2'];
      this.featuredPlans[findIndex]['rateInfo'].E1premiumWithACAFee = obj.plan[currRen]['ratesT3'];
    } else if (outputTier == 4) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = obj.plan[currRen]['ratesT1'];
      this.featuredPlans[findIndex]['rateInfo'].ESpremiumWithACAFee = obj.plan[currRen]['ratesT2'];
      this.featuredPlans[findIndex]['rateInfo'].ECpremiumWithACAFee = obj.plan[currRen]['ratesT3'];
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = obj.plan[currRen]['ratesT4'];
    } else if (outputTier == 5) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = obj.plan[currRen]['ratesT1'];
      this.featuredPlans[findIndex]['rateInfo'].ESpremiumWithACAFee = obj.plan[currRen]['ratesT2'];
      this.featuredPlans[findIndex]['rateInfo'].ECpremiumWithACAFee = obj.plan[currRen]['ratesT3'];
      this.featuredPlans[findIndex]['rateInfo'].EKpremiumWithACAFee = obj.plan[currRen]['ratesT4'];
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = obj.plan[currRen]['ratesT5'];
    }

    if (this.dentalAdjustmentNode.length) {
      this.dentalAdjustmentNode.forEach((item, i) => {
        if (item['ratingPlanID'] == obj.plan.quoteRatingPlanID) {
          this.dentalAdjustmentNode[findIndex].uwAdjustment = 1;
        }
      });
    }

    this.adjustedPlans.forEach((item, i) => {
      if (item['ratingPlanID'] === obj.plan.quoteRatingPlanID) {
        if (findIndex !== -1) {
          this.adjustedPlans[findIndex].uwAdjustment = 1;
          this.featuredPlans[findIndex]['uwAdjustment'] = 1;
        } else {
          this.featuredPlans[i]['uwAdjustment'] = this.adjustedPlans[i].uwAdjustment;
        }
      }
    });
  }

  onResetBtn(obj) {
    this.isAdjusted = true;
    this.commonService.onResetClick = true;
    let outputTier = this.RateData['dentalOutputTier'];
    let currRen;
    const findIndex = this.featuredPlans.findIndex((item) => item['ratingPlanID'] == obj.plan.quoteRatingPlanID);
    if (outputTier == 1) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = this.initialRates[findIndex].initialRates.EEpremiumWithACAFee;
    } else if (outputTier == 2) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = this.initialRates[findIndex].initialRates.EEpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = this.initialRates[findIndex].initialRates.EFpremiumWithACAFee;
    } else if (outputTier == 3) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = this.initialRates[findIndex].initialRates.EEpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = this.initialRates[findIndex].initialRates.EFpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].E1premiumWithACAFee = this.initialRates[findIndex].initialRates.E1premiumWithACAFee;
    } else if (outputTier == 4) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = this.initialRates[findIndex].initialRates.EEpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].ESpremiumWithACAFee = this.initialRates[findIndex].initialRates.ESpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].ECpremiumWithACAFee = this.initialRates[findIndex].initialRates.ECpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = this.initialRates[findIndex].initialRates.EFpremiumWithACAFee;
    } else if (outputTier == 5) {
      this.featuredPlans[findIndex]['rateInfo'].EEpremiumWithACAFee = this.initialRates[findIndex].initialRates.EEpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].ESpremiumWithACAFee = this.initialRates[findIndex].initialRates.ESpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].ECpremiumWithACAFee = this.initialRates[findIndex].initialRates.ECpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].EKpremiumWithACAFee = this.initialRates[findIndex].initialRates.EKpremiumWithACAFee;
      this.featuredPlans[findIndex]['rateInfo'].EFpremiumWithACAFee = this.initialRates[findIndex].initialRates.EFpremiumWithACAFee;
    }
    this.adjustedPlans.forEach((item, i) => {
      if (item['ratingPlanID'] === obj.plan.quoteRatingPlanID) {
        if (findIndex !== -1) {
          this.adjustedPlans[findIndex].uwAdjustment = 1;
          this.featuredPlans[findIndex]['uwAdjustment'] = 1;
        } else {
          this.featuredPlans[i]['uwAdjustment'] = this.adjustedPlans[i].uwAdjustment;
        }
      }
    });
    if (this.dentalAdjustmentNode.length) {
      this.dentalAdjustmentNode.forEach((item, i) => {
        if (item['ratingPlanID'] == obj.plan.quoteRatingPlanID) {
          this.dentalAdjustmentNode[findIndex].uwAdjustment = 1;
        }
      });
    }
  }
  onExportClick() {
    //EST

    let obj = {
      opportunityID: this.RateData['opportunityID'],
      quoteHeaderID: this.RateData['quoteHeaderID']
    };
    this.commonQuoteService.exportQuote(obj).subscribe((response) => {
      this.downloadExcel(response);
    });
  }
  downloadExcel(response) {
    let offset = -5.0;
    let clientDate = new Date();
    let utc = clientDate.getTime() + clientDate.getTimezoneOffset() * 60000;
    let serverDate = new Date(utc + 3600000 * offset);
    let fileName = this.RateData['accountName'] + '_' + this.RateData['opportunityID'] + '_' + serverDate.toLocaleString() + ' EST';

    var link = document.createElement('a');
    link.href = window.URL.createObjectURL(response);
    link.download = fileName + '.xlsx';
    link.click();
  }
  downloadFile(data) {
    const blob = new Blob([data], { type: 'application/vnd.openxmlformats-ficedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    window.open(url);
  }

  onExportQuote() {
    let obj = {
      opportunityID: this.RateData['opportunityID'],
      quoteHeaderID: this.RateData['quoteHeaderID'],
      fundingType: this.fundingType
    };
    this.commonQuoteService.exportQuote(obj).subscribe(
      (response) => {
        if (response.status === 200) {
          this.loadRateInfo();
          this.processId = response.body.processId;
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = 'progress-bar-warning';
          var source = this.commonService.listenForStream(this.processId);
          this.eventSources.push(source);
          source.addEventListener('REPORT_GENERATION_STATUS', (event: any) => {
            this.progressStyle = '';
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
          });
          source.addEventListener('REPORT_GENERATED', (message: any) => {
            console.log('Received complete event');
            source.close();
            let eventData = JSON.parse(message.data);
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            this.progressMessage = eventData.message;
            this.loadPrintExhibitsInfo(true, null);
            this.loadRateInfo();
            let contentData = eventData.payload.contentData;
            let contentName = eventData.payload.contentName;
            if (eventData.payload.contentMetadata) {
              contentName = eventData.payload.contentMetadata[1].value;
            }
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);

            this.peService.createAndDownloadBlobFile(arrayBuffer, contentName);

            this.disableprint = false;
            setTimeout(() => {
              this.showProgress = false;
              if (this.quoteErrorCode == 'E1403') {
                this.loadRateInfo();
              }
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener('FAILED', (message: any) => {
            console.log('Received fail event');
            source.close();
            this.progressStyle = 'progress-bar-danger';
            this.progressMessage = 'Error while exporting the quote';
            this.hideProgressBar();
          });
        }
      },
      (error) => {
        this.disableprint = false;
        console.log(error);
        this.loadRateInfo();
        alert('Error while exporting the quote');
      }
    );
  }
  checkTabData() {
    if (
      (this.featuredPlanCount > 0 && this.portfolioPlanCount == 0 && this.errorPlanCount == 0) ||
      (this.portfolioPlanCount > 0 && this.featuredPlanCount == 0 && this.errorPlanCount == 0) ||
      (this.errorPlanCount > 0 && this.portfolioPlanCount == 0 && this.featuredPlanCount == 0)
    ) {
      return true;
    } else {
      return false;
    }
  }

  isTabDisabled(tabName: String) {
    return this.commonQuoteService.shouldDisableTab(tabName);
  }

  isRenewalQuoteDisabled() {
    if (this.RateData != undefined) {
      this.isRenewalQuote = this.RateData['opportunityType'];
      if (StringUtils.isEqual(this.isRenewalQuote, DentalConstants.renewalLocal)) {
        this.columnSpan = 1;
        return true;
      } else {
        this.columnSpan = 3;
        return false;
      }
    }
  }
  columnSpan: number;
  isRenewalQuote: any;
  downLoadCensus() {
    this.commonQuoteService.downLoadCensus(this.RateData['censusRefId'], 'Dental', this.quoteHeaderID, this.RateData['opportunityType'], this.RateData['groupNbr']);
  }
  isRenewalSGQuoteDisabled() {
    if (this.RateData != undefined) {
      const isRenewalQuote = this.RateData['opportunityType'];
      const marketSegment = this.RateData['marketSegment'];
      if (StringUtils.isEqual(marketSegment, DentalConstants.smallGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        return false;
      } else if (StringUtils.isEqual(marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        return true;
      } else if (StringUtils.isEqual(marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.newBusinessLocal)) {
        return false;
      }
    }
  }
  isSGDentalRenewalQuote() {
    if (this.RateData != undefined) {
      const isRenewalQuote = this.RateData['opportunityType'];
      const marketSegment = this.RateData['marketSegment'];
      if (StringUtils.isEqual(marketSegment, DentalConstants.smallGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        return true;
      } else {
        return false;
      }
    }
  }
  quoteHistory: boolean = false;
  oldQuotesData: any;
  quoteHistoryClicked() {
    this.commonQuoteService.getOldQuotes(this.oppID, this.lob1, this.quoteHeaderID, this.fundingType, this.quoteOrigin, this.alternateQuote, this.quotingType, this.opportunityType).subscribe(
      (response) => {
        let updatedQuotesData = [];
        if (response.opportunities.length) {
          this.oldQuotesData = response.opportunities;
          this.quoteHistory = response.quoteHistory;
          updatedQuotesData = this.oldQuotesData.map((quotesData, index) => {
            quotesData['Version'] = this.oldQuotesData.length - index;
            return quotesData;
          });
          this.oldQuotesData = updatedQuotesData;
        } else {
          this.quoteHistory = false;
        }
      },
      (error) => {
        console.log(error);
        this.quoteHistory = false;
      }
    );
  }

  onRequote(action) {
    this.opportunityData.accountName = this.accountName;
    this.opportunityData.previousOutputTier = this.reqTier;
    this.opportunityData.opportunityType = this.RateData['opportunityType'];
    this.AdjData = {
      opportunity: this.opportunityData,
      uwAdjustment: this.constructReqObj(),
      quoteReason: this.addQuote()
    };
    this.AdjData['opportunity']['factorEffectiveDate'] = this.factorEffectiveDate ? this.factorEffectiveDate : '';
    this.AdjData['requestedScoreVersion'] = 'NOT REQUESTED';
    this.accountName = 'Loading';
    this.commonQuoteService.onSpecialtyRequote(this.AdjData, this.metaTransID, this.transID, action).subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.accountName = this.RateData['accountName'];
          this.backClicked();
        }
      },
      (error) => {
        this.failureMessage = true;
        this.alertData = this.commonQuoteService.specialtyRequoteErr;
        this.accountName = this.RateData['accountName'];
        console.log(error);
      }
    );
  }

  onCustomizePlan(){
    this.backClicked();
  }

  isAutoQuote() {
    if (
      this.RateData &&
      StringUtils.isEqual(this.opportunityType, DentalConstants.newBusinessLocal) &&
      StringUtils.isEqual(this.marketSegment, DentalConstants.smallGroup)
    ) {
      return true;
    }
  }
  isCalcPopudDisabled() {
    if (StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal)) {
      return true;
    } else if (
      StringUtils.isEqual(this.opportunityType, DentalConstants.newBusinessLocal) &&
      StringUtils.isEqual(this.marketSegment, DentalConstants.smallGroup)
    ) {
      return true;
    } else {
      return false;
    }
  }

  checkRenewalBg(): boolean {
    return this.opportunityType == 'Renewal Local';
  }
  onFactorAdj(event) {
    this.isAdjusted = event;
    // Trigger change detection to refresh all components when adjustments change
    setTimeout(() => {
      this.changeDetectorRef.detectChanges();
    }, 0);
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  onFeaturedPlanRateChange(event) {
    this.dentalPremiumComparison = event.dentalPremiumComparison;
    this.isChangedFlag = event.isChangedFlag;
    this.myArr = event.myArr;
    this.adjustedPlans = event.adjustedArr;
    this.adjustedArr = this.adjustedPlans;

    // Set isAdjusted flag to true when featured plan rates are changed
    if (event.isChangedFlag) {
      this.isAdjusted = true;
    }

    // Reset manual edit flags for plans that were manually edited in featured plans and This ensures plan adjustments work correctly after featured plans adjustments
    this.resetManualEditFlagsForAdjustedPlans();
  }

  private resetManualEditFlagsForAdjustedPlans() {
    if (this.myArr && this.myArr.length > 0) {
      this.myArr.forEach(planId => {
        const featuredPlan = this.featuredPlans.find(plan => plan['ratingPlanID'] === planId);
        if (featuredPlan) {
          // Clear manual edit flags when plan adjustments are made after featured plans adjustments
          featuredPlan['wasProposedPlanRatesEdited'] = false;
          // featuredPlan['isProposedPlanRatesEdited'] = 'N';
        }
      });
    }
  }

  private checkMEWARenewalOriginalQuoteExists(): void {
    this.commonQuoteService.getOpportunitesByOppID(this.oppID, this.lob1).subscribe((response) => {
      if (response != null) {
        this.isMEWARenOGQuote = response.opportunities.some((opp: any) =>
          opp.lob === DentalConstants.Medical &&
          opp.quotingType === CommonConstants.MEWA &&
          opp.opportunityType === DentalConstants.renewalLocal &&
          opp.quoteHeaderID === this.quoteHeaderID &&
          !opp.alternateQuote
        );
      }
    });
  }

  // Off-Cycle functionality
  onOffCycleOpen() {
    const modalElements = this.offCycleModalComponent?.getModalElements();
    if (modalElements) {
      this.offCycleModalService.onOffCycleOpen(this.RateData, modalElements, CommonConstants.Dental);
    }
  }

  onOffCycleReasonChange() {
    this.offCycleModalService.onOffCycleReasonChange();
  }

  setDefaultOffCycleDate() {
    this.offCycleModalService.setDefaultOffCycleDate();
  }

  clickOffCycleDate() {
    this.offCycleModalService.clickOffCycleDate();
  }

  onOffCycleConfirm() {
    const success = this.offCycleModalService.onOffCycleConfirm(this.RateData, 'Dental');
    if (success) {
      this.successMessage = true;
      this.alertData = 'Off-Cycle contract end date has been updated successfully.';
      this.onApplyAdjustments('save');
    }
  }

  isContractStarted(): boolean {
    return this.offCycleModalService.isContractStarted(this.RateData?.['contractEffectiveDate']);
  }

  isSold(): boolean {
    return this.offCycleModalService.isSold(this.status?.toString() || '');
  }

  shouldShowOffCycleButton(): boolean {
    return this.offCycleModalService.shouldShowOffCycleButton(
      this.RateData?.['contractEffectiveDate'],
      this.status?.toString() || '',
      CommonConstants.Dental,
      this.RateData?.['opportunityType']
    );
  }
}
