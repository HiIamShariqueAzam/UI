import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExhibitOverridesComponent } from './exhibit-overrides.component';

describe('ExhibitOverridesComponent', () => {
  let component: ExhibitOverridesComponent;
  let fixture: ComponentFixture<ExhibitOverridesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ExhibitOverridesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExhibitOverridesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
