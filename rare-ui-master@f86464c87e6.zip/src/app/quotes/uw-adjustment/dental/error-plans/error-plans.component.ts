import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-error-plans',
  templateUrl: './error-plans.component.html',
  styleUrls: ['./error-plans.component.css'],
  standalone: false
})
export class ErrorPlansComponent {

  @Input() RateData;
  @Input() errorPlanColumns;
  @Input() errorPlans;
 
  createToolTip(){
    return "toolTipDivPlan";
  }
  toolTipData(denPlan){
    let errorData='';
    if(denPlan.errors && denPlan.errors.rareError){
      for (let error of denPlan.errors.rareError) {
        if(errorData){
        errorData =errorData + ' , ' + error.overallErrorMessage;}
        else{
        errorData = error.overallErrorMessage;}
      }
    }
    return errorData;
  }
 
}