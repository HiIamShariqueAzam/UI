import { Component, OnInit, Input, OnChanges, SimpleChanges, LOCALE_ID, Inject, ViewEncapsulation, ChangeDetectorRef, Output, EventEmitter } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { DentalConstants } from "../dental.constants";
import { ActivatedRoute, Router } from "@angular/router";
import { CommonService } from "src/app/shared/services";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { DentalUtil } from "../dental.util";


@Component({
  selector: 'app-featured-plans-dental',
  templateUrl: './featured-plans.component.html',
  styleUrls: ['./featured-plans.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal],
  encapsulation: ViewEncapsulation.None
})
export class FeaturedPlansDentalComponent implements OnInit {
  constructor(private changeDet: ChangeDetectorRef, private commonService: CommonService, private router: Router,
    private commonQuoteService: CommonQuoteService,
    private route: ActivatedRoute) { }
  @Input() RateData;
  @Input() reqTier;
  @Input() featuredPlans;
  @Input() isReadOnlyRole;
  @Input() metaTransID;
  @Input() transID;
  @Input() alternateQuote;
 @Input() dentalPremiumComparison;
  @Input() adjustedPlans;
  @Output() customizePlanEvent = new EventEmitter<void>();
  @Output() onFeaturedPlanRateChange = new EventEmitter<any>()

  columnSpan:number;
  opportunityType: string = '';
  marketSegment: any;
  currentPlanLog: any;
  currentPlanName: any;
  dentalBenefits: any;
  status: any;
  ratingTransId;
  cuQueryCollection: any;
  selectedViewPPlan: any;
  isChangedFlag = false;
  myArr = [];
  adjustedArr = [];
  contractBaseCodeEnabled: boolean = false;

  ngOnInit() {
    this.opportunityType = this.RateData.opportunityType;
    this.marketSegment = this.RateData.marketSegment;
    this.status = this.RateData.status;
    this.getCuCollection();
    this.contractBaseCodeEnabled = this.commonService.getDentalBaseContractCodeFlowEnabled();
  }

  getCuCollection() {
    this.route.queryParamMap
      .subscribe((params) => {
        this.ratingTransId = params.get('ratingTransID');
      })
      .unsubscribe();
    if (this.ratingTransId) {
      this.commonQuoteService.getCuCollection(this.ratingTransId).subscribe((data) => {
        if (data) {
          this.cuQueryCollection = data;
        }
      });
    }
  }

  isSGDentalRenewalQuote() {
    if (this.RateData != undefined) {
      const isRenewalQuote = this.RateData['opportunityType'];
      const marketSegment = this.RateData["marketSegment"];
      if (StringUtils.isEqual(marketSegment, DentalConstants.smallGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        return true;
      }
      else {
        return false;
      }
    }
  }

  isLGDentalRenewalQuote() {
    if (this.RateData != undefined) {
      const isRenewalQuote = this.RateData['opportunityType'];
      const marketSegment = this.RateData["marketSegment"];
      if (StringUtils.isEqual(marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        return true;
      }
      else {
        return false;
      }
    }
  }

  hasContractCode(plan: any) {
    return plan && plan.contractCode;
  }

  areContractCodesIdentical(plan: any) {
    return plan && plan.baseContractCode && plan.contractCode && 
           plan.baseContractCode === plan.contractCode;
  }

  shouldShowContractCodeColumns() {
    return this.isLGDentalRenewalQuote() && this.featuredPlans && this.featuredPlans.some(plan => this.hasContractCode(plan));
  }

  shouldShowRateCodeColumn() {
    return this.shouldShowContractCodeColumns();
  }

  getContractCodeDisplay(plan: any) {
    if (plan.baseContractCode && plan.contractCode) {
      if (plan.baseContractCode === plan.contractCode) {
        return plan.contractCode;
      } else {
        return plan.baseContractCode;
      }
    } else {
      return plan.baseContractCode || plan.contractCode;
    }
  }

  getRateCodeDisplay(plan: any) {
    if (plan.baseContractCode && plan.contractCode) {
      if (plan.baseContractCode === plan.contractCode) {
        return '';
      } else {
        return plan.contractCode;
      }
    } else {
      return '';
    }
  }

  onCustomizePlan() {
    this.navigatePlanCustomization(this.selectedViewPPlan);
  }

  isRenewalQuoteDisabled() {
    if (this.RateData != undefined) {
      const isRenewalQuote = this.RateData['opportunityType'];
      if (StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        this.columnSpan=1;
        return true;
      } else {
        this.columnSpan=3;
        return false;
      }
    }
  }
  isCalcPopudDisabled() {
    if (StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal) && !( StringUtils.isEqual(this.marketSegment, DentalConstants.largeGroup) && (this.RateData?.dental?.oppOrigin?.['altMarket'] || this.RateData?.dental?.alternateQuote))) {
      return true;
    } else if (StringUtils.isEqual(this.opportunityType, DentalConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, DentalConstants.smallGroup)){
      return true;
    } else {
      return false;
    }
  }
  downloadData: any;
  calcFactor: any;
  createViewCalcPopup(plan: any) {
    this.calcFactor = plan.factors;
    this.currentPlanLog = plan.trailLog;
    this.currentPlanName = plan.planName;
    this.downloadData={
      "lob":plan.lob,
      "contractCode":plan.contractCode,
      "metaTransID" : this.metaTransID,
      "transID":this.transID
    }
  }

  navigatePlanCustomization(plan: any) {
    let url = this.commonService.getPlanCustomizationURL();
    if (this.cuQueryCollection[plan.ratingPlanID] && url && this.ratingTransId) {
      if (this.status !== 'Pending Customization') {
        let transID = crypto.randomUUID();
        this.commonQuoteService.updateDentalQuoteStatus(this.ratingTransId, plan.ratingPlanID, transID).subscribe((data) => {
          this.navigateCU(plan, url, transID);
        });
      } else {
        let queryPrams = this.cuQueryCollection[plan.ratingPlanID];
        this.navigateCU(plan, url, queryPrams?.transactionId);
      }
    } else {
      alert("Plan Customization details doesn't exist");
    }
  }

  navigateCU(plan: any, url: string, transId: string) {
    let queryPramsPlan = this.cuQueryCollection[plan.ratingPlanID];
    // Use URL to properly join base and path
    const baseUrl = url.endsWith('/') ? url : url + '/';
    const fullUrl = new URL('plan-customization', baseUrl);

    // Build query params
    const queryParams = {
      planId: queryPramsPlan?.planId ? queryPramsPlan.planId : '',
      transactionId: transId ? transId : '',
      quoteId: queryPramsPlan?.quoteId ? queryPramsPlan.quoteId : '',
      productId: queryPramsPlan?.productId ? queryPramsPlan.productId : '',
      ntwrkId: queryPramsPlan?.ntwrkId ? queryPramsPlan.ntwrkId : '',
      stCd: queryPramsPlan?.stCd ? queryPramsPlan.stCd : '',
      quoteEffDt: queryPramsPlan?.quoteEffDt ? queryPramsPlan.quoteEffDt : '',
      fctrEffDt: queryPramsPlan?.fctrEffDt ? queryPramsPlan.fctrEffDt : '',
      prodCd: queryPramsPlan?.prodCd ? queryPramsPlan.prodCd : '',
      prodCtgryCd: queryPramsPlan?.prodCtgryCd ? queryPramsPlan.prodCtgryCd : '',
      prdSubCtgryCd: queryPramsPlan?.prdSubCtgryCd ? queryPramsPlan.prdSubCtgryCd : '',
      oppType: queryPramsPlan?.oppType ? queryPramsPlan.oppType : '',
      fndngType: queryPramsPlan?.fndngType ? queryPramsPlan.fndngType : '',
      mrktSgmnt: queryPramsPlan?.mrktSgmnt ? queryPramsPlan.mrktSgmnt : '',
      groupSize: queryPramsPlan?.groupSize ? queryPramsPlan.groupSize : '',
      customizationType: queryPramsPlan?.customizationType ? queryPramsPlan.customizationType : 'FULL',
      cntrctCd: queryPramsPlan?.cntrctCd ? queryPramsPlan.cntrctCd : '',
      sourceSystem: queryPramsPlan?.sourceSystem ? queryPramsPlan.sourceSystem : 'RARE',
      mbs: this.RateData?.mbs ? this.RateData?.mbs : '',
      opportunityId: this.RateData?.opportunityID ? this.RateData?.opportunityID : '',
      lob: queryPramsPlan?.lob ? queryPramsPlan.lob : '',
    };

    // Append query params to the URL
    Object.entries(queryParams).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        fullUrl.searchParams.append(key, value as string);
      }
    });
    this.customizePlanEvent.emit();
    setTimeout(() => {
      const newWindow = window.open('', '_blank');
      if (newWindow) {
      newWindow.location.href = fullUrl.toString();
      }
    }, 1000);
  }

  createPopup(plan: any){
    if(this.isSGDentalRenewalQuote() || this.isAutoQuote()) {
      this.dentalBenefits = plan.pmtBenefits;
    } else{
      this.dentalBenefits=plan.planBenefits;
    }
    this.selectedViewPPlan = plan;
    this.currentPlanLog = plan.trailLog;
    this.currentPlanName = plan.planName;
  }
  isAutoQuote() {
    if (this.RateData && StringUtils.isEqual(this.opportunityType, DentalConstants.newBusinessLocal) && StringUtils.isEqual(this.marketSegment, DentalConstants.smallGroup)) {
      return true;
    }
  }
  isRenewalSGQuoteDisabled() {
    if (this.RateData != undefined) {
      const isRenewalQuote = this.RateData['opportunityType'];
      const marketSegment = this.RateData["marketSegment"];
      const alternateQuote = this.RateData.dental["alternateQuote"];
      if (StringUtils.isEqual(marketSegment, DentalConstants.smallGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        return false;
      } else if (StringUtils.isEqual(marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal) && alternateQuote === true) {
        return false;
      } else if (StringUtils.isEqual(marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.renewalLocal)) {
        return true;
      } else if (StringUtils.isEqual(marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(isRenewalQuote, DentalConstants.newBusinessLocal)) {
        return false;
      }
    }
  }
  getBenefitData(node, data){
    if(node && node[data]){
     return node[data].toFixed(2);
    } else { return 0;}

   }

   disableInputIfQuoteISRenewal() {
    return StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal)
  }

   disableInputIfQuoteISNewBusiness() {
    return (StringUtils.isEqual(this.opportunityType, DentalConstants.newBusinessLocal) || StringUtils.isEqual(this.marketSegment, DentalConstants.smallGroup))
  }

  roundedValue(value: number): number {
    return Math.round(value * 1000) / 1000;
  }

  // Format value for display to always show 2 decimal places
  formatDisplayValue(value: any): string {
    if (value === null || value === undefined || value === '') {
      return '';
    }
    const numValue = Number(value);
    if (isNaN(numValue)) {
      return '';
    }
    return numValue.toFixed(2);
  }

  isAdjustedPlansAvailable(denPlan) {    
    if (this.adjustedPlans?.length) {
      const findIndex = this.adjustedPlans.findIndex(obj => obj.ratingPlanID === denPlan.ratingPlanID);
      if(!this.adjustedPlans[findIndex].uwAdjustment) {
      return this.featuredPlans[findIndex].uwDiscret;
      
      } else {
      return this.adjustedPlans[findIndex].uwAdjustment == null ? 1 : this.adjustedPlans[findIndex].uwAdjustment;
      }
    } else {
      return (denPlan.uwDiscret || 1)
    }
  }

  // Method to trigger UI refresh when adjustments change
  onAdjustmentChange() {
    // Trigger change detection to update the Final Rates in real-time
    this.changeDet.detectChanges();
  }

   // Calculate and get the tier rates
  getTierRates(denPlan, tierVal, ageBand?) {
    // If the plan was manually edited (final rates changed), show the manual values
    if (denPlan.wasProposedPlanRatesEdited || denPlan.isProposedPlanRatesEdited === 'Y') {
      return this.formatDisplayValue(denPlan.rateInfo[tierVal]);
    }
    return this.formatDisplayValue(denPlan.rateInfo[tierVal]);
  }

  private refreshDenPlanData(denPlan, ageBand) {
    // Don't refresh rates if they were manually edited (final rates changed)
    if (denPlan.wasProposedPlanRatesEdited || denPlan.isProposedPlanRatesEdited === 'Y') {
      return;
    }
    
    const stringOutputTier = this.RateData['dentalOutputTier'];
    const outputTier = Number(stringOutputTier);

    let planComparison: any
      = this.dentalPremiumComparison?.planComparison.find(comparison => StringUtils.isEqualIgnoreCase(comparison.quoteRatingPlanID, denPlan.ratingPlanID));

      const planComparisonQuoteRates = planComparison?.quoteRates;
      const denPlanRateInfo = denPlan.rateInfo;

      denPlanRateInfo.single = planComparisonQuoteRates?.ratesT1;
      if (outputTier === 4 || outputTier === 5) {
        denPlanRateInfo.eeSpouse = planComparisonQuoteRates?.ratesT2;
      }
      if (outputTier === 4) {
        denPlanRateInfo.eeChildren = planComparisonQuoteRates?.ratesT3;
      }
      if (outputTier === 5) {
        denPlanRateInfo.eeChild = planComparisonQuoteRates?.ratesT3;
        denPlanRateInfo.eeChildren = planComparisonQuoteRates?.ratesT4;
      }
      this.setRateForFamilyFromComparisonRates(outputTier, denPlanRateInfo, planComparisonQuoteRates)
    
  }

  updatePremiumComparison(value, denPlan, tierVal, ageBand) {
      const stringOutputTier = this.RateData['dentalOutputTier'];
      const outputTier = Number(stringOutputTier);
      this.dentalPremiumComparison?.planComparison.forEach((planComparison: any) => {
        if (StringUtils.isEqual(planComparison.quoteRatingPlanID, denPlan.ratingPlanID)) {
          planComparison.wasProposedPlanRatesEdited = true;
          planComparison.isProposedPlanRatesEdited = CommonConstants.YES;
          let planRates;
          if (ageBand) {
            planRates = planComparison.ageBandQuotedRates[ageBand];
          } else {
            planRates = planComparison.quoteRates;
          }
          switch (tierVal) {
            case CommonConstants.SINGLE:
              planRates.ratesT1 = value;
              break;
            case CommonConstants.EE_SPOUSE:
              if (outputTier === 4 || outputTier === 5) {
                planRates.ratesT2 = value;
              }
              break;
            case CommonConstants.EE_ONE:
              planRates.ratesT2 = value;
              break;
            case CommonConstants.EE_CHILD:
              planRates.ratesT3 = value;
              break;
            case CommonConstants.EE_CHILDREN:
              if (outputTier === 4) {
                planRates.ratesT3 = value;
              }
              if (outputTier === 5) {
                planRates.ratesT4 = value;
              }
              break;
            case CommonConstants.FAMILY:
              this.setRateForFamilyTier(outputTier, planRates, value);
              break;
          }
          this.recalculateYearlyTotals(planComparison);
        }
      })
    }

    recalculateYearlyTotals(planComparison) {
    const enrollments = planComparison.quoteEnrollments;
    const rates = planComparison.quoteRates;
    const ratesT1 = rates.ratesT1 || 0;
    const ratesT2 = rates.ratesT2 || 0;
    const ratesT3 = rates.ratesT3 || 0;
    const ratesT4 = rates.ratesT4 || 0;
    const ratesT5 = rates.ratesT5 || 0;

    const enrollT1 = enrollments.enrollT1 || 0;
    const enrollT2 = enrollments.enrollT2 || 0;
    const enrollT3 = enrollments.enrollT3 || 0;
    const enrollT4 = enrollments.enrollT4 || 0;
    const enrollT5 = enrollments.enrollT5 || 0;

    const monthlyTotal = (ratesT1 * enrollT1) +
      (ratesT2 * enrollT2) +
      (ratesT3 * enrollT3) +
      (ratesT4 * enrollT4) +
      (ratesT5 * enrollT5);

    planComparison.quoteRates.monthlyTotal = monthlyTotal;
    planComparison.quoteRates.yearlyTotal = monthlyTotal * 12;

    if (planComparison.currentRates &&
      planComparison.currentRates.yearlyTotal &&
      planComparison.currentRates.yearlyTotal > 0 &&
      planComparison.quoteRates.yearlyTotal !== null &&
      planComparison.quoteRates.yearlyTotal !== undefined) {

      const currentYearly = planComparison.currentRates.yearlyTotal;
      const quoteYearly = planComparison.quoteRates.yearlyTotal;

      planComparison.diffToCurrentRatePercentage = (quoteYearly - currentYearly) / currentYearly;
      planComparison.diffToCurrentMonthlyRate =
        planComparison.quoteRates.monthlyTotal - (planComparison.currentRates.monthlyTotal || 0);
      planComparison.diffToCurrentYearlyRate = quoteYearly - currentYearly;
    } else {
      planComparison.diffToCurrentRatePercentage = 0;
      planComparison.diffToCurrentMonthlyRate = 0;
      planComparison.diffToCurrentYearlyRate = 0;
    }
  }

    constructAdjustedRates() {
    this.adjustedArr = [];
    for (let i = 0; i < this.featuredPlans.length; i++) {
      if (this.myArr.find(x => x === this.featuredPlans[i]['ratingPlanID'])) {
        // Get the existing uwAdjustment value from adjustedPlans if it exists
        let existingUwAdjustment = null;
        if (this.adjustedPlans && this.adjustedPlans.length > 0) {
          const existingPlan = this.adjustedPlans.find(plan => plan.ratingPlanID === this.featuredPlans[i]['ratingPlanID']);
          if (existingPlan) {
            existingUwAdjustment = existingPlan.uwAdjustment;
          }
        }
        
        let adjustedObj = {
          "planName": this.featuredPlans[i]['planName'],
          "ratingPlanID": this.featuredPlans[i]['ratingPlanID'],
          "single": this.featuredPlans[i]['rateInfo']?.single,
          "eeSpouse": this.featuredPlans[i]['rateInfo']?.eeSpouse,
          "eeChild": this.featuredPlans[i]['rateInfo']?.eeChild,
          "eeChildren": this.featuredPlans[i]['rateInfo']?.eeChildren,
          "eeOne": this.featuredPlans[i]['rateInfo']?.eeOne,
          "family": this.featuredPlans[i]['rateInfo']?.family,
          "uwAdjustment": this.calculateUWAdjustmentFromDiff(this.featuredPlans[i])
        }
        this.adjustedArr.push(adjustedObj);
      }

    }
    // Add back any plans from adjustedPlans that have UW adjustments but weren't edited
    if (this.adjustedPlans && this.adjustedPlans.length > 0) {
      this.adjustedPlans.forEach(existingPlan => {
        const alreadyInArr = this.adjustedArr.find(p => p.ratingPlanID === existingPlan.ratingPlanID && p.planName === existingPlan.planName);
        if (!alreadyInArr && existingPlan.uwAdjustment !== undefined && existingPlan.uwAdjustment !== null) {
          this.adjustedArr.push(existingPlan);
        }
      });
    }
    
    return this.adjustedArr;
  }

  calculateUWAdjustmentFromDiff(visPlan) {
    let calculatedUWAdjustment = 1;
    if (this.dentalPremiumComparison && this.dentalPremiumComparison.planComparison) {
      const planComparison = this.dentalPremiumComparison.planComparison.find(
        plan => plan.quoteRatingPlanID === visPlan.ratingPlanID
      );
      if (planComparison) {
        if (planComparison.diffToCurrentRatePercentage !== undefined && planComparison.diffToCurrentRatePercentage !== null) {
          calculatedUWAdjustment = 1 + planComparison.diffToCurrentRatePercentage;
          calculatedUWAdjustment = Math.round(calculatedUWAdjustment * 1000) / 1000;
          visPlan.uwDiscret = calculatedUWAdjustment;
        }
      }
    }
    return calculatedUWAdjustment;
  }

  setRateForFamilyFromComparisonRates(outputTier, rates, planComparisonQuoteRates) {
    switch (outputTier) {
      case 2:
        rates.family = planComparisonQuoteRates?.ratesT2;
        break;
      case 3:
        rates.family = planComparisonQuoteRates?.ratesT3;
        break;
      case 4:
        rates.family = planComparisonQuoteRates?.ratesT4;
        break;
      case 5:
        rates.family = planComparisonQuoteRates?.ratesT5;
        break;
    }
  }
  setRateForFamilyTier(outputTier, planRates, value) {
    switch (outputTier) {
      case 2:
        planRates.ratesT2 = value;
        break;
      case 3:
        planRates.ratesT3 = value;
        break;
      case 4:
        planRates.ratesT4 = value;
        break;
      case 5:
        planRates.ratesT5 = value;
        break;
    }
  }

  // Check if the uw entered valid number or not  
    isNumber(evt) {
      return DentalUtil.isNumber(evt);
    }

    overrideTierRate($event, visPlan, tierVal, ageBand?) {
      const stringValue = $event.target.value?.replace(/[^0-9.]/g, '');
      const value = Number(stringValue);
      // Format to 2 decimal places
      const formattedValue = Number(value.toFixed(2));
      
      if (ageBand) {
        visPlan.ageBandRateInfo[ageBand][tierVal] = formattedValue;
      } else {
        visPlan.rateInfo[tierVal] = formattedValue;
      }
      visPlan.wasProposedPlanRatesEdited = true;
      visPlan.isProposedPlanRatesEdited = CommonConstants.YES;
      
      // Reset plan adjustment factor to 1 when final rates are manually changed
      this.resetPlanAdjustmentForFinalRateChange(visPlan);
      
      this.updatePremiumComparison(formattedValue, visPlan, tierVal, ageBand);
      
      // Update the input field value to show formatted value
      $event.target.value = this.formatDisplayValue(formattedValue);
      if (!this.myArr.find(x => x === visPlan.ratingPlanID)) {
      this.myArr.push(visPlan.ratingPlanID);
    }
    this.constructAdjustedRates();
      
      // Set isChangedFlag to true to indicate changes were made
      this.isChangedFlag = true;
      
      // Trigger change detection to update the UI
      this.changeDet.detectChanges();
      let obj = {
        'dentalPremiumComparison': this.dentalPremiumComparison,
        'isChangedFlag': this.isChangedFlag,
        'myArr': this.myArr,
        'adjustedArr': this.adjustedArr
      }
      this.onFeaturedPlanRateChange.emit(obj);
    }

    private resetPlanAdjustmentForFinalRateChange(visPlan) {
      if (this.adjustedPlans && this.adjustedPlans.length > 0) {
        const planIndex = this.adjustedPlans.findIndex(plan => plan.ratingPlanID === visPlan.ratingPlanID);
        if (planIndex !== -1) {
          this.updatePremiumComparisonWithFinalRates(visPlan);
        }
      }
    }

    private updatePremiumComparisonWithFinalRates(visPlan) {
      const stringOutputTier = this.RateData['dentalOutputTier'];
      const outputTier = Number(stringOutputTier);
      
      this.dentalPremiumComparison?.planComparison.forEach((planComparison: any) => {
        if (StringUtils.isEqual(planComparison.quoteRatingPlanID, visPlan.ratingPlanID)) {
          planComparison.wasProposedPlanRatesEdited = true;
          planComparison.isProposedPlanRatesEdited = CommonConstants.YES;
          
          const planRates = planComparison.quoteRates;
          
          // Update all tiers with the final rates from the featured plan
          planRates.ratesT1 = visPlan.rateInfo?.single || 0;
          
          if (outputTier === 2) {
            planRates.ratesT2 = visPlan.rateInfo?.family || 0;
          } else if (outputTier === 3) {
            planRates.ratesT2 = visPlan.rateInfo?.eeOne || 0;
            planRates.ratesT3 = visPlan.rateInfo?.family || 0;
          } else if (outputTier === 4) {
            planRates.ratesT2 = visPlan.rateInfo?.eeSpouse || 0;
            planRates.ratesT3 = visPlan.rateInfo?.eeChildren || 0;
            planRates.ratesT4 = visPlan.rateInfo?.family || 0;
          } else if (outputTier === 5) {
            planRates.ratesT2 = visPlan.rateInfo?.eeSpouse || 0;
            planRates.ratesT3 = visPlan.rateInfo?.eeChild || 0;
            planRates.ratesT4 = visPlan.rateInfo?.eeChildren || 0;
            planRates.ratesT5 = visPlan.rateInfo?.family || 0;
          }
        }
      });
    }

    // Reverse calculate plan adjustment factor from final rate change
    private updatePlanAdjustmentFromFinalRate(visPlan, tierVal, newFinalRate) {
      if (!visPlan.initialRates || !visPlan.initialRates[tierVal]) {
        return;
      }

      const initialRate = parseFloat(visPlan.initialRates[tierVal]);
      if (initialRate === 0) {
        return;
      }

      // Calculate the adjustment factor: newFinalRate = initialRate * adjustmentFactor
      const adjustmentFactor = newFinalRate / initialRate;
      
      // Update the plan adjustment in adjustedPlans array
      if (this.adjustedPlans && this.adjustedPlans.length > 0) {
        const planIndex = this.adjustedPlans.findIndex(plan => plan.ratingPlanID === visPlan.ratingPlanID);
        if (planIndex !== -1) {
          this.adjustedPlans[planIndex].uwAdjustment = adjustmentFactor;
                  }
      }
    }

    private refreshVisPlanData(visPlan, ageBand) {
    // Don't refresh rates if they were manually edited (final rates changed)
    if (visPlan.wasProposedPlanRatesEdited || visPlan.isProposedPlanRatesEdited === 'Y') {
      return;
    }
    
    const stringOutputTier = this.RateData['dentalOutputTier']
    const outputTier = Number(stringOutputTier);

    let planComparison: any
      = this.dentalPremiumComparison?.planComparison.find(comparison => StringUtils.isEqualIgnoreCase(comparison.quoteRatingPlanID, visPlan.ratingPlanID));

      const planComparisonQuoteRates = planComparison.quoteRates;
      const visPlanRateInfo = visPlan.rateInfo;

      visPlanRateInfo.single = planComparisonQuoteRates.ratesT1;
      if (outputTier === 4 || outputTier === 5) {
        visPlanRateInfo.eeSpouse = planComparisonQuoteRates.ratesT2;
      }
      if (outputTier === 4) {
        visPlanRateInfo.eeChildren = planComparisonQuoteRates.ratesT3;
      }
      if (outputTier === 5) {
        visPlanRateInfo.eeChild = planComparisonQuoteRates.ratesT3;
        visPlanRateInfo.eeChildren = planComparisonQuoteRates.ratesT4;
      }
      this.setRateForFamilyFromComparisonRates(outputTier, visPlanRateInfo, planComparisonQuoteRates)
    
  }

  returnVPC(tierVal, denPlan) {
    if (this.dentalPremiumComparison) {
      const findIndex = this.dentalPremiumComparison.planComparison.findIndex(obj => obj.quoteRatingPlanID === denPlan.ratingPlanID)
      this.dentalPremiumComparison.planComparison.forEach(element => {
        if (denPlan.ratingPlanID == element.quoteRatingPlanID) {
          switch (Number(this.RateData['dentalOutputTier'])) {
            case 1:
              if (StringUtils.isEqual(tierVal, DentalConstants.single)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = denPlan.rateInfo.single;
              }
              break;
            case 2:
              if (StringUtils.isEqual(tierVal, DentalConstants.single)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = denPlan.rateInfo.single;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.family)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = denPlan.rateInfo.family;
              }
              break;
            case 3:
              if (StringUtils.isEqual(tierVal, DentalConstants.single)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = denPlan.rateInfo.single;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.eeOne)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = denPlan.rateInfo.eeOne;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.family)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT3 = denPlan.rateInfo.family;
              }
              break;
            case 4:
              if (StringUtils.isEqual(tierVal, DentalConstants.single)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = denPlan.rateInfo.single;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.eeSpouse)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = denPlan.rateInfo.eeSpouse;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.eeChildren)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT3 = denPlan.rateInfo.eeChildren;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.family)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT4 = denPlan.rateInfo.family;
              }
              break;
            case 5:
              if (StringUtils.isEqual(tierVal, DentalConstants.single)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT1 = denPlan.rateInfo.single;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.eeSpouse)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT2 = denPlan.rateInfo.eeSpouse;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.eeChild)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT3 = denPlan.rateInfo.eeChild;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.eeChildren)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT4 = denPlan.rateInfo.eeChildren;
              } else if (StringUtils.isEqual(tierVal, DentalConstants.family)) {
                this.dentalPremiumComparison.planComparison[findIndex].quoteRates.ratesT5 = denPlan.rateInfo.family;
              }
              break;
            default:
          }
        }
      });
    }
  }
}