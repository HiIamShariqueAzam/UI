import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { DentalComponent } from './dental.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {TableModule} from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import {RadioButtonModule} from 'primeng/radiobutton';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { ToastModule } from 'primeng/toast';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ViewCalcModalComponent } from './view-calc-modal/view-calc-modal.component';
import { DentalPremiumComparisonComponent } from './dental-premium-comparison/dental-premium-comparison.component';
import { ViewBenefitModalComponent } from './view-benefit-modal/view-benefit-modal.component';
import { AdjustmentsHistoryDentalComponent } from './adjustments-history/adjustments-history.component';
import { OpportunitiesHistoryDentalComponent } from './opportunities-history-dental/opportunities-history-dental.component';
import { DentalQuoteDetailsComponent } from './dental-quote-details/dental-quote-details.component';
import { ErrorPlansComponent } from './error-plans/error-plans.component';
import { FeaturedPlansDentalComponent } from './featured-plans/featured-plans.component';
import { AdjustmentsDentalComponent } from './adjustments-dental/adjustments-dental.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { ExhibitOverridesComponent } from './exhibit-overrides/exhibit-overrides.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { DatePicker } from 'primeng/datepicker';


@NgModule({
    declarations: [DentalComponent,
        ViewCalcModalComponent,
        ViewBenefitModalComponent,
        AdjustmentsHistoryDentalComponent,
        DentalPremiumComparisonComponent,
        OpportunitiesHistoryDentalComponent,
        DentalQuoteDetailsComponent,
        ErrorPlansComponent,
        FeaturedPlansDentalComponent,
        AdjustmentsDentalComponent,
        ExhibitOverridesComponent
    ],
    imports: [
        CommonModule, TableModule, ButtonModule, ReactiveFormsModule, RadioButtonModule, SelectModule, FlexLayoutModule, FormsModule, ToastModule, NgbModule, ProgressSpinnerModule,MultiSelectModule, SharedModule, DatePicker,
        RouterModule.forChild([
            { path: '', component: DentalComponent, pathMatch: 'full' }
        ])
    ],
    bootstrap: [DentalComponent],
    providers: [DatePipe],
    exports: [
        DentalComponent,
        OpportunitiesHistoryDentalComponent
    ]
})
export class DentalModule {

 }
