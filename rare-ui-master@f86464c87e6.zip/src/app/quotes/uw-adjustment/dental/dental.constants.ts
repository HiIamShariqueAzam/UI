export class DentalConstants {

    public static employee = 'Employee';
    public static spouse = 'Spouse';
    public static child = 'Child';
    public static children = 'Children';
    public static employeePlusOne = 'Employee+1';
    public static Family = 'Family';
    public static one = 'One';
    public static employeePlusSpouse = 'Employee +Spouse';
    public static employeePlusChild = 'Employee +Child';
    public static employeePlusChildren = 'Employee +Children';
    public static employeePlusFamily = 'Employee +Family';
    public static invalidValue = 'Invalid Value';
    public static single = 'single';
    public static family = 'family';
    public static eeOne = 'eeOne';
    public static eeSpouse = 'eeSpouse';
    public static eeChildren = 'eeChildren';
    public static eeChild = 'eeChild';

    // LOBs
    public static Vision = 'Vision';
    public static Medical = 'Medical';
    public static Dental = 'Dental';

    // Action
    public static releaseAction = 'release';
    public static declineAction = 'decline';

    // UW notes
    public static uwComments = 'uwComments';
    public static salesNotetoUW = 'salesNotetoUW';
    public static uwAdjustment = 'uwAdjustment';
    public static uwNotesToSales = 'uwNotesToSales';

    public static renewalLocal: string = 'Renewal Local';
    public static newBusinessLocal: string = 'New Business Local';
    public static smallGroup: string = 'SG';
    public static largeGroup: string = 'LG';
}