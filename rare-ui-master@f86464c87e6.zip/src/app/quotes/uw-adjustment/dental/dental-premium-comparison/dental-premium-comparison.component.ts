import { Component, OnInit, Input, Output, EventEmitter, Inject, LOCALE_ID, OnChanges, SimpleChanges } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';
import { formatCurrency, getCurrencySymbol, formatPercent } from '@angular/common';
import { dentalPremiumComparison } from 'src/app/shared/models/dentalComparison';
import { DentalUtil } from '../dental.util';
import { StringUtils } from "src/app/shared/utils/string-utils";
import { DentalConstants } from '../dental.constants';

@Component({
  selector: 'app-dental-premium-comparison',
  templateUrl: './dental-premium-comparison.component.html',
  styleUrls: ['./dental-premium-comparison.component.css'],
  standalone: false,
})
export class DentalPremiumComparisonComponent implements OnInit, OnChanges {

  @Input() dentalPremiumComparison: dentalPremiumComparison;
  @Input() featuredPlanCount;
  @Input() activeTab;
  @Input() status;
  @Input() adjustedPlans;
  @Input() RateData;
  @Input() initialRates;
  @Input() initialQuotes;
  @Input() dentalAdjustmentNode;
  @Input() adjustedRatingPlanID;
  @Input() alternateQuote;
  @Input() featuredPlans: any[];
  @Output() onMatchBtn = new EventEmitter<any>();
  @Output() onResetBtn = new EventEmitter<any>();
  lastPlanIndex;
  tierDescription: any = DentalUtil.tierDescription;
  defaultTierNames: any = DentalUtil.defaultTierNames;
  hideCurrentTier: boolean;
  hideRenewalTier: boolean;
  displayNoPermiumComparison: boolean = false;
  planCount = 0;
  opportunityType: any;
  marketSegment: any;
  isRenewal: boolean = false;
  isFileUpload: boolean = false;
  isLGDentalQuote: boolean = false;
  constructor(private commonService: CommonService, @Inject(LOCALE_ID) private locale: string) {

  }
  grandTotalDisplayed: boolean;
  ngOnChanges(changes: SimpleChanges) {
    if (changes.dentalPremiumComparison && !changes.dentalPremiumComparison.firstChange) {
      this.dentalPremiumComparison = this.dentalPremiumComparison;
    }
  }
  ngOnInit() {
    this.opportunityType = this.RateData['opportunityType'];
    this.marketSegment = this.RateData["marketSegment"];
    this.isFileUpload = this.RateData['isFileUpload'];
    this.isRenewal = (this.RateData && StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal));
    this.isLGDentalQuote = StringUtils.isEqual(this.marketSegment, DentalConstants.largeGroup);
    if (this.dentalPremiumComparison != null) {
      this.grandTotalDisplayed = this.dentalPremiumComparison['grandTotalDisplayed']
      this.dentalPremiumComparison.planComparison.forEach((plan, index) => {
        if (plan.showPlanInPrint && plan['hasQuotedRates'] && (plan.currentTier == plan.quoteTier || plan.renewalTier == plan.quoteTier)) {
          this.planCount++;
          this.lastPlanIndex = index;
        }
      })
    }
  }
  // Get Current monthly, Renewal Monthly and Quoted monthly rates
  getMonthlyRate(plan, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentRates && plan.currentRates.monthlyTotal) {
        return '' + plan.currentRates.monthlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (plan.renewalRates && plan.renewalRates.monthlyTotal) {
        return '' + plan.renewalRates.monthlyTotal;
      }
    } else {
      if (plan.quoteRates) {
        let rates = 0;
        for (let i = 1; i <= plan.quoteTier; i++) {
          let enr = 0;
          if (plan.quoteEnrollments != undefined && plan.quoteEnrollments['enrollT' + i] != undefined) {
            enr = plan.quoteEnrollments['enrollT' + i] ? plan.quoteEnrollments['enrollT' + i] : 0;
          }
          const rateValue = plan.quoteRates['ratesT' + i] ? parseFloat(plan.quoteRates['ratesT' + i]) : 0;
          rates = rates + (Math.round((rateValue + Number.EPSILON) * 100) / 100 * enr);
        }
        plan.quoteRates.monthlyTotal = Number(rates.toFixed(2));
        return '' + plan.quoteRates.monthlyTotal;
      }
    }
    return '' + 0;
  }
  // Check if the quote has monthly total to calculate the colspan
  hasMonthlyTotal(plan, forType: string): boolean {
    var total = this.getMonthlyRate(plan, forType);
    if (total && total != '0')
      return true
    else
      return false;
  }
  // Get the current and quoted enrollments
  getEnrollmentTotal(plan, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentEnrollments && plan.currentEnrollments.totalEnroll) {
        return '' + plan.currentEnrollments.totalEnroll;
      }
    } else {
      if (plan.quoteEnrollments && plan.quoteEnrollments.totalEnroll) {
        return '' + plan.quoteEnrollments.totalEnroll;
      }
    }
    return '' + 0;
  }
  // Get the annual rates of current, renewal and quoteed rates
  getAnnualRate(plan, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentRates && plan.currentRates.yearlyTotal) {
        return '' + plan.currentRates.yearlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (plan.renewalRates && plan.renewalRates.yearlyTotal) {
        return '' + plan.renewalRates.yearlyTotal;
      }
    } else {
      if (plan.quoteRates) {
        // Ensure monthlyTotal is calculated first
        if (!plan.quoteRates.monthlyTotal || plan.quoteRates.monthlyTotal === 0) {
          this.getMonthlyRate(plan, 'Q');
        }
        const monthlyTotal = parseFloat(plan.quoteRates.monthlyTotal) || 0;
        plan.quoteRates.yearlyTotal = (monthlyTotal * 12).toFixed(2);
        return '' + plan.quoteRates.yearlyTotal;
      }
    }
    return '' + 0;
  }
  // Check if the quote has renewal rates
  hasRenewalRates(plan): boolean {
    if (plan && plan.hasRenewalRates) {
      return true;
    }
    else
      return false;
  }
  // Check if the quote has premium comparison or not
  displayPremiumComparison(plan) {
    if (this.RateData['showDentalPremiumComparison']) {
      if (plan.showPlanInPrint && plan.hasQuotedRates && (plan.currentTier == plan.quoteTier || plan.renewalTier == plan.quoteTier)) {
        this.displayNoPermiumComparison = true;
        return true;
      }
      if (plan.currenTier !== plan.quoteTier && plan.renewalTier !== plan.quoteTier) {
        this.displayNoPermiumComparison = false;
        return false;
      }
    } else {
      this.displayNoPermiumComparison = false;
      this.planCount = 0;
      return false;
    }
  }
  // comparing the tier values of current tier, renewal tier and quoted tiers
  compareTierValues(plan, forType: string) {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentTier !== plan.quoteTier && plan.quoteTier == plan.renewalTier) {
        this.hideCurrentTier = true;
        return false;
      } else {
        this.hideCurrentTier = false;
        return true;
      }
    }
    if (StringUtils.isEqual(forType, 'R')) {
      if (plan.quoteTier !== plan.renewalTier && plan.quoteTier == plan.currentTier) {
        this.hideRenewalTier = true;
        return false;
      } else {
        this.hideRenewalTier = false;
        return true
      }
    }

  }
  // isPremiumCompHidden() {
  //   let plan = this.dentalPremiumComparison.planComparison;
  //   for (let i = 0; i < plan.length; i++) {
  //     if (plan[i].currentTier !== plan[i].quoteTier && plan[i].renewalTier !== plan[i].quoteTier) {
  //       return true;
  //     } else {
  //       return false;
  //     }
  //   }
  // }
  // Get the current and quoted enrollments
  getPlanEnrollment(plan, tierValue: number, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentEnrollments && (plan.currentEnrollments['enrollT' + tierValue] || plan.currentEnrollments['enrollT' + tierValue] == 0)) {
        return plan.currentEnrollments['enrollT' + tierValue];
      }
    } else {
      if (plan.quoteEnrollments && (plan.quoteEnrollments['enrollT' + tierValue] || plan.quoteEnrollments['enrollT' + tierValue] == 0)) {
        return plan.quoteEnrollments['enrollT' + tierValue];
      }
    }
    return '';
  }

  getPlanInfo(type: string, plan): string {
    if (StringUtils.isEqual(type, 'C')) {
      return 'Current Plan - ' + plan.currentplanName + ' (' + plan.currPlanId + ') ' + ' (' + plan.currentCarrierName + ')';
    }
    else {
      return 'Featured Plan - ' + plan.quotePlanName + ' (' + plan.quoteContractCode + ') ' + ' (' + plan.quoteLegalEntity + ')';
    }
  }
  // Get the proposoed tier value
  getMaxTier(plan): number {
    return plan.quoteTier;
  }
  // Calculate the colspan and return it
  getColSpan(type: string, plan): number {
    if (this.isRenewalQuoteDisabled()) {
      if (StringUtils.isEqual(type, 'H')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      }
      else if (StringUtils.isEqual(type, 'GHC')) {
        if (plan.currentTier !== plan.renewalTier)
          return 3;
        else
          return 4;
      }
      else if (StringUtils.isEqual(type, 'GHQ')) {
        return 3;
      }
      else if (StringUtils.isEqual(type, 'GHD')) {
        return 1;
      }
      else {
        return 6;

      }
    }
    else if (this.isSGRenewalQuoteDisabled()) {
      if (StringUtils.isEqual(type, 'H')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      }
      else if (StringUtils.isEqual(type, 'GHC')) {
        if (plan.currentTier !== plan.renewalTier)
          return 3;
        else
          return 4;
      }
      else if (StringUtils.isEqual(type, 'GHQ')) {
        return 3;
      }
      else if (StringUtils.isEqual(type, 'GHD')) {
        return 1;
      }
      else {
        return 6;
      }
    }
    else {
      if (StringUtils.isEqual(type, 'H')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      }
      else if (StringUtils.isEqual(type, 'GHC')) {
        if (plan.currentTier !== plan.renewalTier)
          return 3;
        else
          return 4;
      }
      else if (StringUtils.isEqual(type, 'GHQ')) {
        return 3;
      }
      else if (StringUtils.isEqual(type, 'GHD')) {
        return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, 'C') ? 2 : 1;
      }
      else {
        if (plan.currentTier !== plan.renewalTier)
          return this.hasRenewalRates(plan) ? 6 : 6;
        else
          return this.hasRenewalRates(plan) ? 7 : 6;
      }
    }
  }
  // Get the current rates, renewal rates and quoted rates
  getPlanRate(plan, tierValue: number, forType: string, index): string {
    let retValue;
    if (StringUtils.isEqual(forType, 'C')) {
      if (plan.currentRates && plan.currentRates['ratesT' + tierValue]) {
        retValue = plan.currentRates['ratesT' + tierValue];
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (plan.renewalRates && plan.renewalRates['ratesT' + tierValue]) {
        retValue = plan.renewalRates['ratesT' + tierValue];
      }
    } else {
      if (plan.quoteRates && plan.quoteRates['ratesT' + tierValue]) {
        retValue = plan.quoteRates["ratesT" + tierValue];
      }
    }
    if (isNaN(retValue)) {
      return retValue;
    }
    return formatCurrency(retValue, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
  }

  // Copying current rates to quoted rates on click of match current
  // Copying renewal rates to quoted rates on click of match renewal
  // Copying initial rates to quoted rates on click of reset to initial rates
  matchClick(plan, type, ind) {
    this.commonService.isMatchClicked = true;
    this.commonService.adjustedRatingPlanID = undefined;
    let outputTier = this.RateData['dentalOutputTier'];
    if (StringUtils.isEqual(type, 'C')) { // match current
      this.matchRates(plan, type, ind, outputTier)
    } else if (StringUtils.isEqual(type, 'R')) { // match renewal
      this.matchRates(plan, type, ind, outputTier)
    } else { // reset
      this.adjustedPlans.forEach((item, i) => {
        if (item.ratingPlanID == plan.quoteRatingPlanID) {
          this.adjustedPlans[i].matchCurrent = false;
          this.adjustedPlans[i].matchRenewal = false;
          this.adjustedPlans[i].reset = true;
        }
      });
      const findIndex = this.initialRates.findIndex(item => item['ratingPlanID'] == plan.quoteRatingPlanID);
      switch (Number(outputTier)) {
        case 1:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = Number(this.initialRates[findIndex].initialRates.EEpremiumWithACAFee);
          break;
        case 2:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = Number(this.initialRates[findIndex].initialRates.EEpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = Number(this.initialRates[findIndex].initialRates.EFpremiumWithACAFee);
          break;
        case 3:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = Number(this.initialRates[findIndex].initialRates.EEpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = Number(this.initialRates[findIndex].initialRates.E1premiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT3'] = Number(this.initialRates[findIndex].initialRates.EFpremiumWithACAFee);
          break;
        case 4:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = Number(this.initialRates[findIndex].initialRates.EEpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = Number(this.initialRates[findIndex].initialRates.ESpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT3'] = Number(this.initialRates[findIndex].initialRates.ECpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT4'] = Number(this.initialRates[findIndex].initialRates.EFpremiumWithACAFee);
          break;
        case 5:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = Number(this.initialRates[findIndex].initialRates.EEpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = Number(this.initialRates[findIndex].initialRates.ESpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT3'] = Number(this.initialRates[findIndex].initialRates.EKpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT4'] = Number(this.initialRates[findIndex].initialRates.ECpremiumWithACAFee);
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT5'] = Number(this.initialRates[findIndex].initialRates.EFpremiumWithACAFee);
          break;
        default:
      }
      let obj = {
        'plan': plan,
        'index': ind,
        'initialRates': this.initialRates
      }
      this.onResetBtn.emit(obj);
    }
    this.getMonthlyTotalRate(type);
    setTimeout(() => {
      this.getMonthlyTotalRateDifference(type);
    }, 500);

  }
  // Copying initial rates to quoted rates on click of reset to initial rates
  matchRates(plan, type, ind, outputTier) {
    this.adjustedPlans.forEach((item, i) => {
      if (item.ratingPlanID == plan.quoteRatingPlanID) {
        if (StringUtils.isEqual(type, 'C')) {
          this.adjustedPlans[i].matchCurrent = true;
          this.adjustedPlans[i].matchRenewal = false;
          this.adjustedPlans[i].reset = false;
        } else {
          this.adjustedPlans[i].matchCurrent = false;
          this.adjustedPlans[i].matchRenewal = true;
          this.adjustedPlans[i].reset = false;
        }
      }
    });
    let currRen;
    if (StringUtils.isEqual(type, 'C')) {
      currRen = 'currentRates'; // Passing current Rates object dynamically
      plan.reset = false;
    } else {
      currRen = 'renewalRates'; // Passing renewal rates object dynamically
      plan.reset = false;
    }
    if (this.dentalPremiumComparison.planComparison[ind].quoteRatingPlanID == plan.quoteRatingPlanID) {
      switch (Number(outputTier)) {
        case 1:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT1']
          break;
        case 2:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT1'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT2'];
          break;
        case 3:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT1'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT2'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT3'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT3'];
          break;
        case 4:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT1'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT2'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT3'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT3'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT4'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT4'];
          break;
        case 5:
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT1'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT1'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT2'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT2'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT3'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT3'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT4'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT4'];
          this.dentalPremiumComparison.planComparison[ind].quoteRates['ratesT5'] = this.dentalPremiumComparison.planComparison[ind][currRen]['ratesT5'];
      }
    }
    let obj = {
      'type': type,
      'plan': plan,
      'dentalPremiumComparison': this.dentalPremiumComparison.planComparison
    }
    this.onMatchBtn.emit(obj);
  }
  constructReq() {
    let outputTier = this.RateData['dentalOutputTier'];
    let dentalAdjustments = [];
    
    this.adjustedPlans.forEach((element, ind) => {
      let findIndex = this.dentalPremiumComparison.planComparison.findIndex(item => item.quoteRatingPlanID == this.adjustedPlans[ind].ratingPlanID);
      if (findIndex !== -1) {
        if (element.ratingPlanID == this.dentalPremiumComparison.planComparison[findIndex].quoteRatingPlanID) {
          
          // Calculate monthly and yearly totals for the plan
          const plan = this.dentalPremiumComparison.planComparison[findIndex];
          this.getMonthlyRate(plan, 'Q'); // This calculates and sets monthlyTotal
          this.getAnnualRate(plan, 'Q'); // This calculates and sets yearlyTotal
          
          // Create rateAdjustment object with current rates
          let rateAdjustment = {
            planName: element.planName || this.dentalPremiumComparison.planComparison[findIndex].quotePlanName,
            ratingPlanID: element.ratingPlanID,
            single: this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT1'] || 0,
            eeSpouse: this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT2'] || 0,
            eeChildren: this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT3'] || 0,
            family: this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT4'] || 0,
            eeChild: this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT3'] || 0,
            eeOne: this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT2'] || 0,
            monthlyTotal: plan.quoteRates.monthlyTotal || 0,
            yearlyTotal: plan.quoteRates.yearlyTotal || 0,
            uwAdjustment: element.uwAdjustment || 1
          };
          
          // Adjust rates based on output tier
          if (outputTier == 1) {
            rateAdjustment.single = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT1'];
          } else if (outputTier == 2) {
            rateAdjustment.single = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT1'];
            rateAdjustment.family = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT2'];
          } else if (outputTier == 3) {
            rateAdjustment.single = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT1'];
            rateAdjustment.eeOne = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT2'];
            rateAdjustment.family = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT3'];
          } else if (outputTier == 4) {
            rateAdjustment.single = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT1'];
            rateAdjustment.eeSpouse = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT2'];
            rateAdjustment.eeChildren = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT3'];
            rateAdjustment.family = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT4'];
          } else if (outputTier == 5) {
            rateAdjustment.single = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT1'];
            rateAdjustment.eeSpouse = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT2'];
            rateAdjustment.eeChild = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT3'];
            rateAdjustment.eeChildren = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT4'];
            rateAdjustment.family = this.dentalPremiumComparison.planComparison[findIndex].quoteRates['ratesT5'];
          }
          
          // Find the corresponding featured plan to get manual edit flags
          let featuredPlan = this.featuredPlans?.find(fp => fp.ratingPlanID === element.ratingPlanID);
          
          // Create dental adjustment object with expected structure
          let dentalAdjustment = {
            planName: element.planName || this.dentalPremiumComparison.planComparison[findIndex].quotePlanName,
            ratingPlanID: element.ratingPlanID,
            uwAdjustment: element.uwAdjustment || 1,
            rateAdjustment: {
              planName: element.planName || this.dentalPremiumComparison.planComparison[findIndex].quotePlanName,
              ratingPlanID: element.ratingPlanID,
              single: rateAdjustment.single,
              eeSpouse: rateAdjustment.eeSpouse,
              eeChildren: rateAdjustment.eeChildren,
              family: rateAdjustment.family,
              eeChild: rateAdjustment.eeChild,
              eeOne: rateAdjustment.eeOne,
              monthlyTotal: rateAdjustment.monthlyTotal,
              yearlyTotal: rateAdjustment.yearlyTotal,
              uwAdjustment: element.uwAdjustment || 1
            },
            matchCurrent: element.matchCurrent || false,
            matchRenewal: element.matchRenewal || false,
            reset: element.reset || false,
            wasProposedPlanRatesEdited: featuredPlan?.wasProposedPlanRatesEdited || false,
            isProposedPlanRatesEdited: featuredPlan?.isProposedPlanRatesEdited || 'N'
          };
          
          dentalAdjustments.push(dentalAdjustment);
        }
      }
    });
    
    return dentalAdjustments;
  }
  getTierName(plan, tierValue: number, forType: string): string {
    if (StringUtils.isEqual(forType, 'C') && plan.currentTier == plan.quoteTier) {
      if (tierValue <= plan.currentTier) {
        return this.getTierEmpDesc(tierValue, plan.currentTier);
      }
    } else if (StringUtils.isEqual(forType, 'C') && plan.renewalTier == plan.quoteTier) {
      return this.getTierEmpDesc(tierValue, plan.renewalTier);
    }
    else {
      if (tierValue <= plan.quoteTier) {
        return this.getTierEmpDesc(tierValue, plan.quoteTier);
      }
    }
    return '';
  }
  isMatchCurrentDisabled(plan) {
    if (!plan.currentTierEqual) {
      return true;
    } else if (plan.currentRates && Object.keys(plan.currentRates).length === 0) {
      return true;
    } else if (!this.compareTierValues(plan, 'C')) {
      return true;
    } else {
      return false;
    }
  }
  isMatchRenewalsDisabled(plan) {
    if (!plan.renewalTierEqual) {
      return true;
    } else if (plan.renewalRates && Object.keys(plan.renewalRates).length === 0) {
      return true;
    } else if (!this.compareTierValues(plan, 'R')) {
      return true;
    } else {
      return false;
    }
  }
  getTierEmpDesc(tierNumber: number, availableTiers: number): string {
    let tieredValue = this.tierDescription[availableTiers + '-Tier'];
    if (!tieredValue) {
      tieredValue = this.defaultTierNames;
    }
    switch (availableTiers) {
      case 1:
        if (tierNumber == 1) {
          return tieredValue.EE;
        }
        break;
      case 2:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.EF;
        }
        break;
      case 3:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.E1;
        } else if (tierNumber == 3) {
          return tieredValue.EF;
        }
        break;
      case 4:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EC;
        } else if (tierNumber == 4) {
          return tieredValue.EF;
        }
        break;
      case 5:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EK;
        } else if (tierNumber == 4) {
          return tieredValue.EC;
        } else if (tierNumber == 5) {
          return tieredValue.EF;
        }
        break;
    }
    return '';
  }
  getAbsoluteValue(value): number {
    if (value && value != Infinity)
      return Math.abs(value);
    else
      return 0;
  }
  getMonthlyRateDifference(plan, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      plan.diffToCurrentMonthlyRate = plan.quoteRates.monthlyTotal - plan.currentRates.monthlyTotal
      return plan.diffToCurrentMonthlyRate
    } else {
      plan.diffToRenewalMonthlyRate = plan.quoteRates.monthlyTotal - plan.renewalRates.monthlyTotal
      return plan.diffToRenewalMonthlyRate;
    }
  }
  getAnnualRateDifference(plan, forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      plan.diffToCurrentYearlyRate = plan.quoteRates.yearlyTotal - plan.currentRates.yearlyTotal
      return plan.diffToCurrentYearlyRate
    } else {
      plan.diffToRenewalYearlyRate = plan.quoteRates.yearlyTotal - plan.renewalRates.yearlyTotal
      return plan.diffToRenewalYearlyRate;
    }
  }
  getDifferencePecentage(plan, forType: string): number {
    if (this.isRenewalQuoteDisabled()) {
      this.getMonthlyRate(plan, 'C');
      this.getEnrollmentTotal(plan, 'Q');
      this.getMonthlyRate(plan, 'Q');
      this.getAbsoluteValue(this.getMonthlyRateDifference(plan, 'C'));
      this.getAnnualRate(plan, 'C');
      this.getAnnualRate(plan, 'Q');
      this.getAbsoluteValue(this.getAnnualRateDifference(plan, 'C'));
    }
    
    
    // Otherwise, calculate the rate difference percentage as before
    if (StringUtils.isEqual(forType, 'C')) {
      if (this.isRenewalQuoteDisabled()) {
        plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.quoteRates.monthlyTotal * 12, plan.currentRates.yearlyTotal);
        return plan.diffToCurrentRatePercentage;
      } else {
        plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.quoteRates.yearlyTotal, plan.currentRates.yearlyTotal);
        return plan.diffToCurrentRatePercentage;
      }
    } else {
      plan.diffToRenewalRatePercentage = this.calculateRatePer(plan.quoteRates.yearlyTotal, plan.renewalRates.yearlyTotal);
      return plan.diffToRenewalRatePercentage;
    }
  }
  classHighlighter(value): string {
    return value * 1 > 0 ? 'higher' : 'lesser';
  }
  getMonthlyTotalRate(forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      if (this.dentalPremiumComparison.currentMonthlyGrandTotal) {
        return '' + this.dentalPremiumComparison.currentMonthlyGrandTotal;
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (this.dentalPremiumComparison.renewalMonthlyGrandTotal) {
        return '' + this.dentalPremiumComparison.renewalMonthlyGrandTotal;
      }
    } else {
      if (this.dentalPremiumComparison.quoteMonthlyGrandTotal) {
        let monthlyGrandTotal = 0;
        this.dentalPremiumComparison.planComparison.forEach(item => {
          if (item.showPlanInPrint && item['hasQuotedRates'] && this.displayNoPermiumComparison) {
            monthlyGrandTotal = monthlyGrandTotal + item.quoteRates.monthlyTotal;
            this.dentalPremiumComparison.quoteMonthlyGrandTotal = monthlyGrandTotal;

          }
        });
        return '' + this.dentalPremiumComparison.quoteMonthlyGrandTotal;

      }
    }
    return '' + 0;
  }
  hasMonthlyGrandTotal(forType: string): boolean {
    var total = this.getMonthlyTotalRate(forType);
    if (total && total != '0')
      return true
    else
      return false;
  }

  getrenewalIncreasePercentage(forType: string): number {
    if (StringUtils.isEqual(forType, 'R')) {
      return this.dentalPremiumComparison.renewalIncreasePercentage ? this.dentalPremiumComparison.renewalIncreasePercentage : 0;
    }
  }
  getMonthlyTotalRateDifference(forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      this.dentalPremiumComparison.diffToCurrentMonthlyTotal = this.dentalPremiumComparison.quoteMonthlyGrandTotal - this.dentalPremiumComparison.currentMonthlyGrandTotal;
      return this.dentalPremiumComparison.diffToCurrentMonthlyTotal ? '' + this.dentalPremiumComparison.diffToCurrentMonthlyTotal : '';
    } else {
      this.dentalPremiumComparison.diffToRenewalMonthlyTotal = this.dentalPremiumComparison.quoteMonthlyGrandTotal - this.dentalPremiumComparison.renewalMonthlyGrandTotal;
      return this.dentalPremiumComparison.diffToRenewalMonthlyTotal ? '' + this.dentalPremiumComparison.diffToRenewalMonthlyTotal : '';
    }
  }

  getAnnualTotalRateDifference(forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      this.dentalPremiumComparison.diffToCurrentYearlyTotal = this.dentalPremiumComparison.quoteYearlyGrandTotal - this.dentalPremiumComparison.currentYearlyGrandTotal;
      return this.dentalPremiumComparison.diffToCurrentYearlyTotal ? '' + this.dentalPremiumComparison.diffToCurrentYearlyTotal : '';
    } else {
      this.dentalPremiumComparison.diffToRenewalYearlyTotal = this.dentalPremiumComparison.quoteYearlyGrandTotal - this.dentalPremiumComparison.renewalYearlyGrandTotal;
      return this.dentalPremiumComparison.diffToRenewalYearlyTotal ? '' + this.dentalPremiumComparison.diffToRenewalYearlyTotal : '';
    }
  }
  getAnnualTotalRate(forType: string): string {
    if (StringUtils.isEqual(forType, 'C')) {
      if (this.dentalPremiumComparison.currentYearlyGrandTotal) {
        return '' + this.dentalPremiumComparison.currentYearlyGrandTotal;
      }
    } else if (StringUtils.isEqual(forType, 'R')) {
      if (this.dentalPremiumComparison.renewalYearlyGrandTotal) {
        return '' + this.dentalPremiumComparison.renewalYearlyGrandTotal;
      }
    } else {
      if (this.dentalPremiumComparison.quoteYearlyGrandTotal) {
        this.dentalPremiumComparison.quoteYearlyGrandTotal = this.dentalPremiumComparison.quoteMonthlyGrandTotal * 12;
        return '' + this.dentalPremiumComparison.quoteYearlyGrandTotal;
      }
    }
    return '' + 0;
  }
  getColSpanGrand(): number {
    if (StringUtils.isEqual(this.marketSegment, DentalConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal)) {
      return 5;
    } else if (StringUtils.isEqual(this.marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal) && this.alternateQuote) {
      return 5;
    }
    return 2;
  }
  calculateRatePer(total, value) {
    let increase = total - value;
    let diffPer = (increase / value);
    return diffPer
  }

  getTotalDifferencePecentage(forType: string): number {
    if (StringUtils.isEqual(forType, 'C')) {
      this.dentalPremiumComparison.diffToCurrentRatePercentage = this.calculateRatePer(this.dentalPremiumComparison.quoteYearlyGrandTotal, this.dentalPremiumComparison.currentYearlyGrandTotal) * 100;
      return this.dentalPremiumComparison.diffToCurrentRatePercentage ? this.dentalPremiumComparison.diffToCurrentRatePercentage : 0;

    } else {
      this.dentalPremiumComparison.diffToRenewalRatePercentage = this.calculateRatePer(this.dentalPremiumComparison.quoteYearlyGrandTotal, this.dentalPremiumComparison.renewalYearlyGrandTotal) * 100;
      return this.dentalPremiumComparison.diffToRenewalRatePercentage ? this.dentalPremiumComparison.diffToRenewalRatePercentage : 0;
    }
  }
  getPercentage(value) {
    if (StringUtils.isEqual(this.marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal)) {
      return value.toFixed(1) + '%';
    } else {
      return value.toFixed(2) + '%';
    }
  }
  isDisabled(plan, tierValue: number, forType: string): string {
    if (!plan.quoteRatingPlanID) {
      return '';
    }
    else {
      if (StringUtils.isEqual(forType, 'C') || StringUtils.isEqual(forType, 'R')) {
        if (tierValue <= plan.currentTier) {
          return this.getTierEmpDesc(tierValue, plan.currentTier);
        }
      } else {
        if (tierValue <= plan.quoteTier) {
          return this.getTierEmpDesc(tierValue, plan.quoteTier);
        }
      }
    }
    return '';
  }

  isRenewalQuoteDisabled() {
    if (this.RateData != undefined) {
      if (StringUtils.isEqual(this.marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal) && !this.alternateQuote) {
        return true;
      } else {
        return false;
      }
    }
  }
  isSGRenewalQuoteDisabled() {
    if (this.RateData != undefined) {
      if (StringUtils.isEqual(this.marketSegment, DentalConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal)) {
        return true;
      } else if (StringUtils.isEqual(this.marketSegment, DentalConstants.largeGroup) && this.alternateQuote && StringUtils.isEqual(this.opportunityType, DentalConstants.renewalLocal)) {
        return true;
      } else {
        return false;
      }
    }
  }
  isNewBusinessQuote() {
    if (this.RateData != undefined) {
      if (StringUtils.isEqual(this.marketSegment, DentalConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, DentalConstants.newBusinessLocal)) {
        return true;
      } else {
        return false;
      }
    }
  }
}


