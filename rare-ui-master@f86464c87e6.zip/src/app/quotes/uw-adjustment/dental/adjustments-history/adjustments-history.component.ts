import { Component, OnInit, Input, AfterViewInit, ElementRef, ViewChild } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CommonUtil } from "src/app/shared/utils/common-util";
import { DateUtil } from "src/app/shared/utils/date-util";

@Component({
  selector: "app-adjustments-history-dental",
  templateUrl: "./adjustments-history.component.html",
  styleUrls: ["./adjustments-history.component.css"],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class AdjustmentsHistoryDentalComponent implements OnInit, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() adjHistory: any;
  columns = [
    {
      "header": "Version",
      "field": "quoteVersion"
    },
    {
      "header": "Adj No",
      "field": "AdjNo"
    },
    {
      "header": "Updated Time (EST)",
      "field": "submittedTimestamp"
    },
    {
      "header": "Last Updated by",
      "field": "underWriterName"
    },
    {
      "header": "Update Types",
      "field": "uwActions"
    },
    {
      "header": "Adjustment Summary",
      "field": "adjustmentSummary"
    }
  ]

  constructor(
    config: NgbModalConfig,
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit() {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  ngOnInit() {
  }

  // Formatting the local date string
  formatDate(timestamp) {
    return DateUtil.formatDate(timestamp);
  }
}
