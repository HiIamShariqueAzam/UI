import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { UwAdjustmentDentalComponent } from './uw-adjustment-dental.component';

describe('UwAdjustmentDentalComponent', () => {
  let component: UwAdjustmentDentalComponent;
  let fixture: ComponentFixture<UwAdjustmentDentalComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ UwAdjustmentDentalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UwAdjustmentDentalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
