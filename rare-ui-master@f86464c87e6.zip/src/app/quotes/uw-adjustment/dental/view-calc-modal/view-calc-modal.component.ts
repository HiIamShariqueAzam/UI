import { Component, OnInit, Input, OnChanges, SimpleChanges, AfterViewInit, ElementRef, ViewChild } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonService, PrintExhibitService } from 'src/app/shared/services';
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: 'app-view-calc-modal-dental',
  templateUrl: './view-calc-modal.component.html',
  styleUrls: ['./view-calc-modal.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class ViewCalcModalComponent implements OnInit, OnChanges, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  
  @Input() trailLogs: any;
  @Input() currentPlanName: any;
  @Input() factors: any;
  @Input() RateData: any;
  @Input() downloadData: any;
  @Input() alternateQuote;

  downloadFailed : boolean = false ;
  adjustmentFactors = [];
  headerVal = [];
  coinsuranceAdjustmentFactors: any;
  constructor(
    config: NgbModalConfig,
    private commonService:CommonService,
    private peService:PrintExhibitService, private commonQuoteService: CommonQuoteService
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }


  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }
  
  ngOnChanges(changes: SimpleChanges) {
    this.getFactorsValue();
  }
  ngOnInit() {
  }
  getFactorsValue() {
    if (this.factors) {
      this.coinsuranceAdjustmentFactors = this.factors.coinsuranceAdjustmentFactors;
      let adjustmentFactors = [{
        'description': 'Copay',
        'value': this.factors.ovCopayFctr
      },
      {
        'description': 'Deductible Adjustment',
        'inn': this.factors.innDdctblFctr,
        'oon': this.factors.oonDdctblFctr

      },
      {
        'description': 'Lifetime Deductible Adjustment',
        'inn': this.factors.ltDdtcblInnFctr,
        'oon': this.factors.ltDdtcblOonFctr
      },
      {
        'description': 'Annual Maximum Adjustment',
        'inn': this.factors.innAnnlMaxFctr,
        'oon': this.factors.oonAnnlMaxFctr
      },

      {
        'description': 'OOPM Adjustment',
        'inn': this.factors.oopmInnFctr,
        'oon': this.factors.oopmOonFctr
      },
      {
        'description': 'Employee Age Adjustment',
        'value': this.factors.weightedAgeFactor
      },
      {
        'description': 'Occupational Adjustment ',
        'value': this.factors.sicFctr
      },
      {
        'description': 'Child Dependent Age Adjustment',
        'value': this.factors.childDepAgeFctr
      },
      {
        'description': 'Annual Trend',
        'value': this.factors.trndFctr
      },
      {
        'description': 'Discount for Prior Coverage',
        'value': this.factors.prevCvrgFctr
      },
      {
        'description': 'Benefit Waiting Period Factor',
        'value': this.factors.waitPrdFctr?.[0]?.waitPrdFctr
      },
      {
        'description': 'Contract Length',
        'value': this.factors.cntrctLngthFctr
      },
      {
        'description': 'Participation Adjustment',
        'value': this.factors.prtcptnFctr
      },
      {
        'description': 'Submitted Charge Adjustment',
        'value': this.factors.weightedSbmtChrgFctr
      },
      {
        'description': 'Utilization Adjustment',
        'value': this.factors.weightedUtlztnFctr
      }
      ];
     this.adjustmentFactors = adjustmentFactors;
    }
    if (this.factors) {
      let retValues = [
        {
          'label': 'Retention - Fixed Cost PCPM',
          'content': '$' + this.factors.retentionPcpm
        },
        {
          'label': 'Retention - Percent of Premium',
          'content': (this.factors.rtntnFctr * 100).toFixed(2) +'%'
        },
        {
          'label': 'Commission - Percent of Premium',
          'content': (this.factors.comtnFctr * 100).toFixed(2) + '%'
        }
      ];
      let orthBuildUpVal = [
        {
          'label': 'Child Ortho Claim Cost',
          'content': '$' + this.factors.chldOrthoClmCostAmt
        },
        {
          'label': 'Adult Ortho Claim Cost',
          'content': '$' +this.factors.adltOrthoClmCostAmt
        },
        {
          'label': 'ACA Fee',
          'content': (this.factors.acaFeeFctr * 100).toFixed(2) +'%'
        }
      ]
      let adjustmentVal = [
        {
          'label': 'Discount Grp',
          'content': this.factors.dscntGrp
        },
        {
          'label': 'Association Discount Factor',
          'content': this.factors.assctnFctr
        },
        {
          'label': 'Exchange Factor % of Prem',
          'content':  this.factors.pctPremExchangeFctr
        },
        {
          'label': 'Exchange Factor PCPM',
          'content': '$' +this.factors.pcpmExchangeAdj
        },
        {
          'label': 'Special Discount Factor',
          'content': this.factors.splDscntFctr
        },
        {
          'label': 'UW  Adjustment',
          'content': this.factors.uwDiscretFctr
        },
        {
          'label': 'Sales Adjustment',
          'content': this.factors.salesAdjPct
        },
        {
          'label': 'Rate Bank Factor',
          'content': this.factors.rateBankAdjPct
        },
        {
          'label': 'Dual Option Adjustment',
          'content': this.factors.dualOptFctr
        }
      ]

      let headerVal = [
        {
          'title': 'Retention',
          'value': retValues
        },
        {
          'title': 'Ortho Build Up',
          'value': orthBuildUpVal
        },
        {
          'title': 'Adjustments',
          'value': adjustmentVal
        }
      ]
      this.headerVal = headerVal;
    }
   }
   downloadViewCalcExcel(){
    let obj = {};
    let data = {}
    obj["planName"] = String(this.currentPlanName);
    obj["quoteHeaderID"] = this.RateData.quoteHeaderID;
    obj["opportunityID"] = this.RateData.opportunityID;
    obj["lob"] = this.downloadData.lob;
    obj["contractCode"] = this.downloadData.contractCode;

     obj["startingClaimCost"] = { "primeIndClassOne":String('$'+this.factors.bnftCls1Indv.toFixed(2)),"primeIndClassTwo":String('$'+this.factors.bnftCls2Indv.toFixed(2)),"primeIndClassThree":String('$'+this.factors.bnftCls3Indv.toFixed(2)),"primeFamClassOne":String('$'+this.factors.bnftCls1Fmly.toFixed(2)),"primeFamClassTwo":String('$'+this.factors.bnftCls2Fmly.toFixed(2)),"primeFamClassThree":String('$'+this.factors.bnftCls3Fmly.toFixed(2)),"completeIndClassOne":String('$'+this.factors.bnftCls1Indv.toFixed(2)),"completeIndClassTwo":String('$'+this.factors.bnftCls2Indv.toFixed(2)),"completeIndClassThree":String('$'+this.factors.bnftCls3Indv.toFixed(2)),"completeFamClassOne":String('$'+this.factors.bnftCls1Fmly.toFixed(2)),"completeFamClassTwo":String('$'+this.factors.bnftCls2Fmly.toFixed(2)),"completeFamClassThree":String('$'+this.factors.bnftCls3Fmly.toFixed(2)),"outIndClassOne":String('$'+this.factors.bnftCls1Indv.toFixed(2)),"outIndClassTwo":String('$'+this.factors.bnftCls2Indv.toFixed(2)),"outIndClassThree":String('$'+this.factors.bnftCls3Indv.toFixed(2)),"outFamClassOne":String('$'+this.factors.bnftCls1Fmly.toFixed(2)),"outFamClassTwo":String('$'+this.factors.bnftCls2Fmly.toFixed(2)),"outFamClassThree":String('$'+this.factors.bnftCls3Fmly.toFixed(2)) };
     obj["coinsuranceAdjustment"] = { "primeIndClassOne":String(this.coinsuranceAdjustmentFactors['In-NetworkClass I'].toFixed(3)),"primeIndClassTwo":String(this.coinsuranceAdjustmentFactors['In-NetworkClass II'].toFixed(3)),"primeIndClassThree":String(this.coinsuranceAdjustmentFactors['In-NetworkClass III'].toFixed(3)),"primeFamClassOne":String(this.coinsuranceAdjustmentFactors['In-NetworkClass I'].toFixed(3)),"primeFamClassTwo":String(this.coinsuranceAdjustmentFactors['In-NetworkClass II'].toFixed(3)),"primeFamClassThree":String(this.coinsuranceAdjustmentFactors['In-NetworkClass III'].toFixed(3)),"completeIndClassOne":String(this.coinsuranceAdjustmentFactors['In-NetworkClass I'].toFixed(3)),"completeIndClassTwo":String(this.coinsuranceAdjustmentFactors['In-NetworkClass II'].toFixed(3)),"completeIndClassThree":String(this.coinsuranceAdjustmentFactors['In-NetworkClass III'].toFixed(3)),"completeFamClassOne":String(this.coinsuranceAdjustmentFactors['In-NetworkClass I'].toFixed(3)),"completeFamClassTwo":String(this.coinsuranceAdjustmentFactors['In-NetworkClass II'].toFixed(3)),"completeFamClassThree":String(this.coinsuranceAdjustmentFactors['In-NetworkClass III'].toFixed(3)),"outIndClassOne":String(this.coinsuranceAdjustmentFactors['Out-of-Network Class I'].toFixed(3)),"outIndClassTwo":String(this.coinsuranceAdjustmentFactors['Out-of-Network Class II'].toFixed(3)),"outIndClassThree":String(this.coinsuranceAdjustmentFactors['Out-of-Network Class III'].toFixed(3)),"outFamClassOne":String(this.coinsuranceAdjustmentFactors['Out-of-Network Class I'].toFixed(3)),"outFamClassTwo":String(this.coinsuranceAdjustmentFactors['Out-of-Network Class II'].toFixed(3)),"outFamClassThree":String(this.coinsuranceAdjustmentFactors['Out-of-Network Class III'].toFixed(3)) };
     obj["adjustedStartingClaimCost"] = { "primeIndClassOne":String('$'+this.factors.cls1IndvAdjStrtClmCost.toFixed(2)),"primeIndClassTwo":String('$'+this.factors.cls2IndvAdjStrtClmCost.toFixed(2)),"primeIndClassThree":String('$'+this.factors.cls3IndvAdjStrtClmCost.toFixed(2)),"primeFamClassOne":String('$'+this.factors.cls1FmlyAdjStrtClmCost.toFixed(2)),"primeFamClassTwo":String('$'+this.factors.cls2FmlyAdjStrtClmCost.toFixed(2)),"primeFamClassThree":String('$'+this.factors.cls3FmlyAdjStrtClmCost.toFixed(2)),"completeIndClassOne":String('$'+this.factors.cls1IndvAdjStrtClmCost.toFixed(2)),"completeIndClassTwo":String('$'+this.factors.cls2IndvAdjStrtClmCost.toFixed(2)),"completeIndClassThree":String('$'+this.factors.cls3IndvAdjStrtClmCost.toFixed(2)),"completeFamClassOne":String('$'+this.factors.cls1FmlyAdjStrtClmCost.toFixed(2)),"completeFamClassTwo":String('$'+this.factors.cls2FmlyAdjStrtClmCost.toFixed(2)),"completeFamClassThree":String('$'+this.factors.cls3FmlyAdjStrtClmCost.toFixed(2)),"outIndClassOne":String('$'+this.factors.oonCls1IndvAdjStrtClmCost.toFixed(2)),"outIndClassTwo":String('$'+this.factors.oonCls2IndvAdjStrtClmCost.toFixed(2)),"outIndClassThree":String('$'+this.factors.oonCls3IndvAdjStrtClmCost.toFixed(2)),"outFamClassOne":String('$'+this.factors.oonCls1FmlyAdjStrtClmCost.toFixed(2)),"outFamClassTwo":String('$'+this.factors.oonCls2FmlyAdjStrtClmCost.toFixed(2)),"outFamClassThree":String('$'+this.factors.oonCls3FmlyAdjStrtClmCost.toFixed(2)) };
     obj["combinedClaimCost"] = {"primeInd":String('$'+this.factors.innPrimeCmbndNnonOrthoClmCostAdjfctr.toFixed(2)),"primeFam":String('$'+this.factors.innPrimeFmlyCmbndNnonOrthoClmCostAdjfctr.toFixed(2)),"completeInd":String('$'+this.factors.innCmpltCmbndNnonOrthoClmCostAdjfctr.toFixed(2)),"completeFam":String('$'+this.factors.innCmpltFmlyCmbndNnonOrthoClmCostAdjfctr.toFixed(2)),"outInd":String('$'+this.factors.oonCmbndNnonOrthoClmCostAdjfctr.toFixed(2)),"outFam":String('$'+this.factors.oonFmlyCmbndNnonOrthoClmCostAdjfctr.toFixed(2)) };
     obj["copay"] = {"primeInd":String(this.factors.ovCopayFctr.toFixed(3)),"primeFam":String(this.factors.ovCopayFctr.toFixed(3)),"completeInd":String(this.factors.ovCopayFctr.toFixed(3)),"completeFam":String(this.factors.ovCopayFctr.toFixed(3)),"outInd":String(this.factors.ovCopayFctr.toFixed(3)),"outFam":String(this.factors.ovCopayFctr.toFixed(3)) };
     obj["deductibleAdjustment"] = {"primeInd":String(this.factors.innDdctblFctr.toFixed(3)),"primeFam":String(this.factors.innDdctblFctr.toFixed(3)),"completeInd":String(this.factors.innDdctblFctr.toFixed(3)),"completeFam":String(this.factors.innDdctblFctr.toFixed(3)),"outInd":String(this.factors.oonDdctblFctr.toFixed(3)),"outFam":String(this.factors.oonDdctblFctr.toFixed(3)) };
     obj["lifetimeDeductibleAdjustment"] = {"primeInd":String(this.factors.ltDdtcblInnFctr.toFixed(3)),"primeFam":String(this.factors.ltDdtcblInnFctr.toFixed(3)),"completeInd":String(this.factors.ltDdtcblInnFctr.toFixed(3)),"completeFam":String(this.factors.ltDdtcblInnFctr.toFixed(3)),"outInd":String(this.factors.ltDdtcblOonFctr.toFixed(3)),"outFam":String(this.factors.ltDdtcblOonFctr.toFixed(3)) };
     obj["annualMaximumAdjustment"] = {"primeInd":String(this.factors.innAnnlMaxFctr.toFixed(3)),"primeFam":String(this.factors.innAnnlMaxFctr.toFixed(3)),"completeInd":String(this.factors.innAnnlMaxFctr.toFixed(3)),"completeFam":String(this.factors.innAnnlMaxFctr.toFixed(3)),"outInd":String(this.factors.oonAnnlMaxFctr.toFixed(3)),"outFam":String(this.factors.oonAnnlMaxFctr.toFixed(3)) };
     obj["oopmAdjustment"] = {"primeInd":String(this.factors.oopmInnFctr.toFixed(3)),"primeFam":String(this.factors.oopmInnFctr.toFixed(3)),"completeInd":String(this.factors.oopmInnFctr.toFixed(3)),"completeFam":String(this.factors.oopmInnFctr.toFixed(3)),"outInd":String(this.factors.oopmOonFctr.toFixed(3)),"outFam":String(this.factors.oopmOonFctr.toFixed(3)) };
     obj["employeeAgeAdjustment"] = {"primeInd":String(this.factors.weightedAgeFactor.toFixed(3)),"primeFam":String(this.factors.weightedAgeFactor.toFixed(3)),"completeInd":String(this.factors.weightedAgeFactor.toFixed(3)),"completeFam":String(this.factors.weightedAgeFactor.toFixed(3)),"outInd":String(this.factors.weightedAgeFactor.toFixed(3)),"outFam":String(this.factors.weightedAgeFactor.toFixed(3)) };
     obj["occupationalAdjustment"] = {"primeInd":String(this.factors.sicFctr.toFixed(3)),"primeFam":String(this.factors.sicFctr.toFixed(3)),"completeInd":String(this.factors.sicFctr.toFixed(3)),"completeFam":String(this.factors.sicFctr.toFixed(3)),"outInd":String(this.factors.sicFctr.toFixed(3)),"outFam":String(this.factors.sicFctr.toFixed(3)) };
     obj["childDependentAgeAdjustment"] = {"primeInd":String(this.factors.childDepAgeFctr.toFixed(3)),"primeFam":String(this.factors.childDepAgeFctr.toFixed(3)),"completeInd":String(this.factors.childDepAgeFctr.toFixed(3)),"completeFam":String(this.factors.childDepAgeFctr.toFixed(3)),"outInd":String(this.factors.childDepAgeFctr.toFixed(3)),"outFam":String(this.factors.childDepAgeFctr.toFixed(3)) };
     obj["annualTrend"] = {"primeInd":String(this.factors.trndFctr.toFixed(3)),"primeFam":String(this.factors.trndFctr.toFixed(3)),"completeInd":String(this.factors.trndFctr.toFixed(3)),"completeFam":String(this.factors.trndFctr.toFixed(3)),"outInd":String(this.factors.trndFctr.toFixed(3)),"outFam":String(this.factors.trndFctr.toFixed(3)) };
     obj["discountForPriorCoverage"] = {"primeInd":String(this.factors.prevCvrgFctr.toFixed(3)),"primeFam":String(this.factors.prevCvrgFctr.toFixed(3)),"completeInd":String(this.factors.prevCvrgFctr.toFixed(3)),"completeFam":String(this.factors.prevCvrgFctr.toFixed(3)),"outInd":String(this.factors.prevCvrgFctr.toFixed(3)),"outFam":String(this.factors.prevCvrgFctr.toFixed(3)) };
     obj["benefitWaitingPeriodFactor"] = {"primeInd":String(this.factors.waitPrdFctr?.[0]?.waitPrdFctr.toFixed(3)),"primeFam":String(this.factors.waitPrdFctr?.[0]?.waitPrdFctr.toFixed(3)),"completeInd":String(this.factors.waitPrdFctr?.[0]?.waitPrdFctr.toFixed(3)),"completeFam":String(this.factors.waitPrdFctr?.[0]?.waitPrdFctr.toFixed(3)),"outInd":String(this.factors.waitPrdFctr?.[0]?.waitPrdFctr.toFixed(3)),"outFam":String(this.factors.waitPrdFctr?.[0]?.waitPrdFctr.toFixed(3)) };
     obj["contractLength"] = {"primeInd":String(this.factors.cntrctLngthFctr.toFixed(3)),"primeFam":String(this.factors.cntrctLngthFctr.toFixed(3)),"completeInd":String(this.factors.cntrctLngthFctr.toFixed(3)),"completeFam":String(this.factors.cntrctLngthFctr.toFixed(3)),"outInd":String(this.factors.cntrctLngthFctr.toFixed(3)),"outFam":String(this.factors.cntrctLngthFctr.toFixed(3)) };
     obj["participationAdjustment"] = {"primeInd":String(this.factors.prtcptnFctr.toFixed(3)),"primeFam":String(this.factors.prtcptnFctr.toFixed(3)),"completeInd":String(this.factors.prtcptnFctr.toFixed(3)),"completeFam":String(this.factors.prtcptnFctr.toFixed(3)),"outInd":String(this.factors.prtcptnFctr.toFixed(3)),"outFam":String(this.factors.prtcptnFctr.toFixed(3)) };
     obj["submittedChargeAdjustment"] = {"primeInd":String(this.factors.weightedSbmtChrgFctr.toFixed(3)),"primeFam":String(this.factors.weightedSbmtChrgFctr.toFixed(3)),"completeInd":String(this.factors.weightedSbmtChrgFctr.toFixed(3)),"completeFam":String(this.factors.weightedSbmtChrgFctr.toFixed(3)),"outInd":String(this.factors.weightedSbmtChrgFctr.toFixed(3)),"outFam":String(this.factors.weightedSbmtChrgFctr.toFixed(3)) };
     obj["utilizationAdjustment"] = {"primeInd":String(this.factors.weightedUtlztnFctr.toFixed(3)),"primeFam":String(this.factors.weightedUtlztnFctr.toFixed(3)),"completeInd":String(this.factors.weightedUtlztnFctr.toFixed(3)),"completeFam":String(this.factors.weightedUtlztnFctr.toFixed(3)),"outInd":String(this.factors.weightedUtlztnFctr.toFixed(3)),"outFam":String(this.factors.weightedUtlztnFctr.toFixed(3)) };
     obj["discountAdjustment"] = {"primeInd":String(this.factors.primeDscntFctr.toFixed(3)),"primeFam":String(this.factors.primeDscntFctr.toFixed(3)),"completeInd":String(this.factors.cmpltDscntFctr.toFixed(3)),"completeFam":String(this.factors.cmpltDscntFctr.toFixed(3)),"outInd":String(this.factors.oonReimbFctr.toFixed(3)),"outFam":String(this.factors.oonReimbFctr.toFixed(3)) };
     obj["networkUsage"] = {"primeInd":String(this.factors.weightedPrimeProdUsgFctr.toFixed(3)),"primeFam":String(this.factors.weightedPrimeProdUsgFctr.toFixed(3)),"completeInd":String(this.factors.wacmplProdUsgFctr.toFixed(3)),"completeFam":String(this.factors.wacmplProdUsgFctr.toFixed(3)),"outInd":String(this.factors.weightedOonUsgFctr.toFixed(3)),"outFam":String(this.factors.weightedOonUsgFctr.toFixed(3)) };
     obj["totalNonOrthoClaimCost"] = {"primeInd":String('$'+this.factors.innPrimeIndvTotNonOrthoClmCostAmt.toFixed(2)),"primeFam":String('$'+this.factors.innPrimeFmlyTotNonOrthoClmCostAmt.toFixed(2)),"completeInd":String('$'+this.factors.innCmpltIndvTotNonOrthoClmCostAmt.toFixed(2)),"completeFam":String('$'+this.factors.innCmpltFmlyTotNonOrthoClmCostAmt.toFixed(2)),"outInd":String('$'+this.factors.oonIndvTotNonOrthoClmCostAmt.toFixed(2)),"outFam":String('$'+this.factors.oonFmlyTotNonOrthoClmCostAmt.toFixed(2)) };
     obj["blendedNonOrthoClaimCost"] = {"primeInd":String('$'+this.factors.indvBlendedNonOrthoClmCostAmt.toFixed(2)),"primeFam":String('$'+this.factors.fmlyBlendedNonOrthoClmCostAmt.toFixed(2)),"completeInd":"","completeFam":"","outInd":"","outFam":"" };

     obj["retentionFixedCostPcpm"] = String('$' + this.factors.retentionPcpm);
     obj["retentionPercentOfPremium"] = String((this.factors.rtntnFctr * 100).toFixed(2) +'%');
     obj["commissionPercentOfPremium"] = String((this.factors.comtnFctr * 100).toFixed(2) + '%');
     obj["childOrthoClaimCost"] = String('$' + this.factors.chldOrthoClmCostAmt);
     obj["adultOrthoClaimCost"] = String('$' +this.factors.adltOrthoClmCostAmt);
     obj["acaFee"] = String((this.factors.acaFeeFctr * 100).toFixed(2) +'%');
     obj["discountGrp"] = String(this.factors.dscntGrp);
     obj["associationDiscountFactor"] = String(this.factors.assctnFctr);
     obj["exchangeFactorPercentOfPremium"] = String(this.factors.pctPremExchangeFctr);
     obj["exchangeFactorPcpm"] = String('$' +this.factors.pcpmExchangeAdj);
     obj["specialDiscountFactor"] = String(this.factors.splDscntFctr);
     obj["uwAdjustment"] = String(this.factors.uwDiscretFctr);
     obj["salesAdjustment"] = String(this.factors.salesAdjPct);
     obj["rateBankFactor"] = String(this.factors.rateBankAdjPct);
     obj["dualOptionAdjustment"] = String(this.factors.dualOptFctr);

    data["data"]=obj;
    this.downloadViewCalcExcelFile(data);

   }
   downloadViewCalcExcelFile(viewCalcDetails) {
    this.commonQuoteService.getViewCalcExcel(this.downloadData.metaTransID, this.downloadData.transID, viewCalcDetails).subscribe(
      response => {
        this.downloadFailed = false;
           let processId = response.processId;
            var source = this.commonService.listenForStream(processId);
             source.addEventListener("SEND_EXHIBIT_TO_UI", (message: any) => {
              let eventData = JSON.parse(message.data);
              let fileExt = '.xlsx';
              CommonService.exportFilename = (eventData.metaData.fileName ? eventData.metaData.fileName : "sheet"+ fileExt) ;
              let fileName = this.commonService.getExportFilename();
              let contentData = eventData.payload.contentData;
              const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            });
      },
      error => {
        this.downloadFailed = true;
        var promise = new Promise<any>((resolve) => {
          setTimeout(() => {resolve(false); }, 10000);
          });
          promise.then((res) => {
            this.downloadFailed = false;
          });
      }
    );
  }
  setDefault()
  {
    this.downloadFailed = false;
  }
}
