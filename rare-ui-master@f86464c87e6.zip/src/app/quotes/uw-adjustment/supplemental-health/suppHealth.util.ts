import { CommonConstants } from "src/app/shared/constants/common.constants";
import { StringUtils } from "src/app/shared/utils/string-utils";

export class SuppHealthUtil {
  public static isNumber(evt) {
    var el = evt.target;
    var charCode = evt.charCode;
    var number = el.value.split(".");
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (number.length > 1 && charCode == 46) {
      return false;
    }
    var caratPos = this.getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && number[1].length > 10) {
      return false;
    }
    return true;
  }

  public static getSelectionStart(o) {
    return o.selectionStart;
  }

  public static checkIfNull(plan) {
    plan['uwAdjustment'] = plan.factors.uwDiscretFctr;
    if (!plan.factors.uwDiscretFctr) {
      return null;
    }
    else {
      if ((String(plan.factors.uwDiscretFctr).match(/^(\d?(\.\d{1,10})?)?$/g))) {
        if (String(plan.factors.uwDiscretFctr) !== '0' && String(plan.factors.uwDiscretFctr) !== '' && plan.factors.uwDiscretFctr !== undefined) {
          return null;
        } else {
          return true;
        }
      } else {
        return true;
      }
    }
  }

  public static isTierApplicable(plan, tier: number, type: string): boolean {
    return StringUtils.isEqualIgnoreCase(type, 'Quote') ? plan.quoteTier >= tier : plan.currentTier >= tier;
  }

  public static calculatedFloatValue(factor: any): any {
    let floatValue = parseFloat(factor);
    if (isNaN(floatValue) || factor == "") {
      return "";
    } else {
      return floatValue !== 0 ? floatValue : "";
    }
  }

  public static isCurency(evt) {
    var el = evt.target;
    var charCode = evt.charCode;
    var number = el.value.split(".");
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (number.length > 1 && charCode == 46) {
      return false;
    }
    var caratPos = this.getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && number[1].length > 1) {
      return false;
    }
    return true;
  }
  public static roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }
  public static getPlanInfo(type: string, plan): string {
    if (StringUtils.isEqual(type, 'Current')) {
      return 'Current Plan - ' + plan.currentplanName + ' (' + plan.currPlanId + ') ' + ' (' + plan.currentCarrierName + ')';
    }
    else {
      return 'Featured Plan - ' + plan.quotePlanName + ' (' + plan.quoteContractCode + ') ' + ' (' + plan.quoteLegalEntity + ')';
    }
  }
  public static getPlanEnrollment(plan, tierValue: number, forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (
        plan.currentEnrollments &&
        (plan.currentEnrollments["enrollT" + tierValue] ||
          plan.currentEnrollments["enrollT" + tierValue] == 0)
      ) {
        return plan.currentEnrollments["enrollT" + tierValue];
      }
    } else {
      if (
        plan.quoteEnrollments &&
        (plan.quoteEnrollments["enrollT" + tierValue] ||
          plan.quoteEnrollments["enrollT" + tierValue] == 0)
      ) {
        return plan.quoteEnrollments["enrollT" + tierValue];
      }
    }
    return 0;
  }

  public static getAgeBandPlanEnrollment(plan, tierValue: number, forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.ageBandCurrentRates) {
        for (const [key, value] of Object.entries(plan.ageBandCurrentRates)) {
          let currentAgeBand = Object.entries(value)
          if (currentAgeBand["enrollT" + tierValue] ||
            currentAgeBand["enrollT" + tierValue] == 0) {
            return currentAgeBand["enrollT" + tierValue];
          }
        }
      }
      return 0;
    }
  }


  public static getEnrollmentTotal(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.currentEnrollments && plan.currentEnrollments.totalEnroll) {
        return plan.currentEnrollments.totalEnroll;
      }
    } else {
      if (plan.quoteEnrollments && plan.quoteEnrollments.totalEnroll) {
        return plan.quoteEnrollments.totalEnroll;
      }
    }
    return 0;
  }
  public static getMonthlyRateDifference(plan, forType: string): number {
    if (plan.hasQuotedRates) {
      if (StringUtils.isEqual(forType, 'Current')) {
        plan.diffToCurrentMonthlyRate = plan.quoteRates.monthlyTotal - plan.currentRates.monthlyTotal
        return plan.diffToCurrentMonthlyRate
      } else {
        plan.diffToRenewalMonthlyRate = plan.quoteRates.monthlyTotal - plan.renewalRates.monthlyTotal
        return plan.diffToRenewalMonthlyRate;
      }
    }
  }
  // Supp Health Guardrail error messages
  public static displayGuardrailErrorMessage(eleID, boundariesObjName, premiumGuardrail?) {
    switch (eleID) {
      case CommonConstants.contractEffectiveDateKey:
        return CommonConstants.contractEffectiveDateMessage;
      case CommonConstants.suppHealthCommissionPCPMKey:
        return CommonConstants.suppHealthCommissionPCPMMessage + boundariesObjName[eleID].maxVal + CommonConstants.dollar;
      case CommonConstants.suppHealthCommisionNYFactorKey:
        return CommonConstants.suppHealthCommisionNYFactorMessage + boundariesObjName[eleID].minVal + CommonConstants.percent + ' and ' + boundariesObjName[eleID].maxVal + CommonConstants.percent;
      case CommonConstants.suppHealthPremRateDifferenceKey:
        return CommonConstants.suppHealthPremRateDifferenceMessage + boundariesObjName[eleID].maxVal + CommonConstants.percent;
      case CommonConstants.suppHealthCompetativeAdjustmentKey:
        return CommonConstants.suppHealthCompetativeAdjustmentMessage + boundariesObjName[eleID].minVal + CommonConstants.percent + ' and ' + boundariesObjName[eleID].maxVal + CommonConstants.percent;
      case CommonConstants.suppHealthExperienceClaimsKey:
        return CommonConstants.suppHealthExperienceClaimsMessage;
      case CommonConstants.suppHealthAdjustmentFactorKey:
        return CommonConstants.suppHealthAdjustmentFactorMessage;
      case CommonConstants.suppHealthRateGuaranteeMonthsFactorKey:
        return CommonConstants.suppHealthRateGuaranteeMonthsFactorMessage + boundariesObjName[eleID].maxVal + ' ' + CommonConstants.months;
      case CommonConstants.suppHealthCommissionFactorKey:
        return CommonConstants.suppHealthCommissionFactorMessage + boundariesObjName[eleID].maxVal + CommonConstants.percent;
      case CommonConstants.suppHealthPremiumComparisonKey:
        return premiumGuardrail;
      default:
        return;
    }
  }

  public static getTierEmpDesc(tierNumber: number, availableTiers: number): string {
    let tieredValue = this.tierDescription[availableTiers + '-Tier'];
    if (!tieredValue) {
      tieredValue = this.defaultTierNames;
    }
    switch (availableTiers) {
      case 1:
        if (tierNumber == 1) {
          return tieredValue.EE;
        }
      case 2:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.EF;
        }
      case 3:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.E1;
        } else if (tierNumber == 3) {
          return tieredValue.EF;
        }
      case 4:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EC;
        } else if (tierNumber == 4) {
          return tieredValue.EF;
        }
      case 5:
        if (tierNumber == 1) {
          return tieredValue.EE;
        } else if (tierNumber == 2) {
          return tieredValue.ES;
        } else if (tierNumber == 3) {
          return tieredValue.EK;
        } else if (tierNumber == 4) {
          return tieredValue.EC;
        } else if (tierNumber == 5) {
          return tieredValue.EF;
        }
    }
    return '';
  }

  public static tierDescription: any = {
    "1-Tier": {
      "EE": CommonConstants.EE
    },
    "3-Tier": {
      "EE": CommonConstants.EE,
      "EF": CommonConstants.EF,
      "E1": CommonConstants.oneNumber
    },
    "4-Tier": {
      "EE": CommonConstants.EE,
      "EF": CommonConstants.EF,
      "ES": CommonConstants.ES,
      "EC": CommonConstants.EC
    },
    "5-Tier": {
      "EE": CommonConstants.EE,
      "EF": CommonConstants.EF,
      "EK": CommonConstants.EK,
      "ES": CommonConstants.ES,
      "EC": CommonConstants.EC
    },
    "2-Tier": {
      "EE": CommonConstants.EE,
      "EF": CommonConstants.EF
    }
  };
  public static defaultTierNames = {
    "EE": CommonConstants.EF,
    "EF": CommonConstants.EF,
    "EK": CommonConstants.EK,
    "EC": CommonConstants.EC,
    "ES": CommonConstants.ES,
    "E1": CommonConstants.oneNumber
  };
 
  public static getAnnualRate(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {      
      if(plan.hasAgeBandCurrentRates){
        plan.ageBandCurrentYearlyTotal = plan.ageBandCurrentMonthlyPremium * 12;
        return plan.ageBandCurrentYearlyTotal;
      } else if (plan.currentRates && plan.currentRates.yearlyTotal) {       
        plan.currentRates.yearlyTotal = plan.currentRates.monthlyTotal * 12;
        return plan.currentRates.yearlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      if (plan.renewalRates && plan.renewalRates.yearlyTotal) {
        plan.renewalRates.yearlyTotal = plan.renewalRates.monthlyTotal * 12
        return plan.renewalRates.yearlyTotal;
      }
    } else {
      if(plan.hasAgeBandQuotedRates){
        plan.ageBandQuotedYearlyTotal = plan.ageBandQuotedMonthlyPremium * 12;
        return plan.ageBandQuotedYearlyTotal;
      }else if (plan.quoteRates && plan.quoteRates.yearlyTotal) {
        plan.quoteRates.yearlyTotal = plan.quoteRates.monthlyTotal * 12;
        return plan.quoteRates.yearlyTotal;
      }
    }
    return 0;
  }

  public static calculateRatePer(total, value) {
    let increase = total - value;
    let diffPer = (increase / value);
    return diffPer;
  }   

  public static getAnnualRateDifference(plan, forType: string): number {
    if (plan.hasQuotedRates) {
      if (StringUtils.isEqual(forType, 'Current')) {
        plan.diffToCurrentYearlyRate = plan.quoteRates.yearlyTotal - plan.currentRates.yearlyTotal
        return plan.diffToCurrentYearlyRate;
      } else {
        plan.diffToRenewalYearlyRate = plan.quoteRates.yearlyTotal - plan.renewalRates.yearlyTotal
        return plan.diffToRenewalYearlyRate;
      }
    }
  }

  public static getMonthlyRate(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.hasAgeBandCurrentRates) {
        return plan.ageBandCurrentMonthlyPremium;
      }else if (plan.currentRates && plan.currentRates.monthlyTotal) {
        return plan.currentRates.monthlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      if (plan.renewalRates && plan.renewalRates.monthlyTotal) {
        return plan.renewalRates.monthlyTotal;
      }
    } else {    
      if(plan.hasAgeBandQuotedRates === true){
        return plan.ageBandQuotedMonthlyPremium;
      } else if(plan.hasQuotedRates === true){
        return plan.quoteRates.monthlyTotal;
      }     
    }
  }

  public static calculateRateGuaranteeMonths(date1: Date, date2: Date) {
    let months;
    // original calculation
    months = (date2.getFullYear() - date1.getFullYear()) * 12;
    months -= date1.getMonth() + 1; // months are indexed from 0
    months += date2.getMonth() + 1; // months are indexed from 0
    // check if the days of the month or if date2 is the last day of the month
    let endDay = new Date(date2.getFullYear(), date2.getMonth() + 1, 0).getDate();
    if (date2.getDate() >= date1.getDate() || date2.getDate() === endDay) {
      months += 1;
    }
    return months <= 0 ? 0 : months;
  }
}
