import { formatCurrency, formatPercent, getCurrencySymbol } from '@angular/common';
import { Component, EventEmitter, Inject, Input, LOCALE_ID, OnInit, Output, SimpleChanges } from '@angular/core';
import {
  Enrollments,
  PlanComparison,
  PlanRates,
  SuppHealthPremiumComparison
} from 'src/app/shared/models/suppHealthComparison';
import { CommonService } from 'src/app/shared/services';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CommonConstants } from '../../../../shared/constants/common.constants';
import { SuppHealthUtil } from '../suppHealth.util';


@Component({
  selector: 'app-supp-health-rate-comparison',
  templateUrl: './supp-health-rate-comparison.component.html',
  styleUrls: ['./supp-health-rate-comparison.component.css'],
  standalone: false,
})
export class SuppHealthRateComparisonComponent implements OnInit {
  expanded: boolean = false;
  opportunityType: any;
  marketSegment: any;
  isRenewal: boolean = false;
  hideCurrentTier: boolean;
  hideRenewalTier: boolean;
  currentPlansBenefitsList = [];
  premiumGuardrail: any;

  @Input() suppHealthPreCom: SuppHealthPremiumComparison;
  @Input() featuredPlans;
  @Input() boundariesObjName;
  @Input() isChangedFlag;
  @Input() suppHealthPremiumComparisonLoaded;
  @Input() rareData;
  @Input() isReadOnlyRole;
  @Input() status;
  @Input() adjustedPlans;

  @Output()
  onSHPCChange = new EventEmitter<any>();

  constructor(private commonService: CommonService, @Inject(LOCALE_ID) private locale: string) {

  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.suppHealthPreCom && !changes.suppHealthPreCom.firstChange) {
      this.suppHealthPreCom = this.suppHealthPreCom;
    }
    if (changes.featuredPlans && !changes.featuredPlans.firstChange) {
      this.featuredPlans = this.featuredPlans;
    }
  }

  ngOnInit() {
    this.opportunityType = this.rareData['opportunityType'];
    this.marketSegment = this.rareData["marketSegment"];
    this.isRenewal = (this.rareData && StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL));
  }
  isNumber(evt) {
    return SuppHealthUtil.isNumber(evt);
  }

  isCurrency(evt) {
    return SuppHealthUtil.isCurency(evt);
  }

  /**
   * This method is used to update the rates and totals for the plan
   * @param val is the entered value in the input field
   * @param tierNumber is the tier number
   * @param plan is the plan name
   * @param forType is the type of plan (Current, CR, RR)
   * @param ageBand is provided when age banded current rate is edited from premium comparison
   */
  updateSuppHealthPreComparison(val, tierNumber: number, plan: any, forType: string, ageBand: string) {
    let suppHealthPlan = this.getSHPlan(plan.quoteRatingPlanID);
    let value = val;
    let currentRates,
        currentMonthlyTotal, currentYearlyTotal,
        renewalMonthlyTotal, renewalYearlyTotal;
    if (ageBand) {
      currentRates = suppHealthPlan.ageBandCurrentRates[ageBand];
      currentMonthlyTotal = suppHealthPlan.ageBandCurrentMonthlyPremium;
      currentYearlyTotal = suppHealthPlan.ageBandCurrentYearlyTotal;
      renewalMonthlyTotal = suppHealthPlan.ageBandRenewalMonthlyPremium;
      renewalMonthlyTotal = suppHealthPlan.ageBandRenewalYearlyTotal;
    } else {
      currentRates = suppHealthPlan.currentRates;
      currentMonthlyTotal = suppHealthPlan.currentRates.monthlyTotal;
      currentYearlyTotal = suppHealthPlan.currentRates.yearlyTotal;
      renewalMonthlyTotal = suppHealthPlan.renewalRates.monthlyTotal;
      renewalYearlyTotal = suppHealthPlan.renewalRates.yearlyTotal;
    }
    if (StringUtils.isEqual(forType, 'Current')) {
      plan.currentEnrollments['enrollT' + tierNumber] = Number(val);
      suppHealthPlan.currentEnrollments.totalEnroll = this.getTotalEnrollment(suppHealthPlan, "Current");
      currentMonthlyTotal = this.getMonthlyTotal(suppHealthPlan, "Current", ageBand);
      currentYearlyTotal = this.getAnnualTotal(suppHealthPlan, "Current", ageBand);
      renewalMonthlyTotal = this.getMonthlyTotal(suppHealthPlan, "Renewal", ageBand);
      renewalYearlyTotal = this.getAnnualTotal(suppHealthPlan, "Renewal", ageBand);
    } else if (StringUtils.isEqual(forType, 'CR')) {
      value = value.replace("$", "").replace(/,/g, "");
      if (isNaN(value)) {
        currentRates["ratesT" + tierNumber] = Number(val);
      } else {
        currentRates["ratesT" + tierNumber] = parseFloat((+value).toFixed(2));
      }
      if (value == '') {
        currentRates["ratesT" + tierNumber] = '';
      }
      currentMonthlyTotal = this.getMonthlyTotal(suppHealthPlan, "Current", ageBand);
      currentYearlyTotal = this.getAnnualTotal(suppHealthPlan, "Current", ageBand);
      suppHealthPlan.wasCurrentPlanRatesEdited = true;
      suppHealthPlan.isCurrentPlanRatesEdited = CommonConstants.YES;
    } else if (StringUtils.isEqual(forType, 'RR')) {
      let value = val;
      value = value.replace("$", "").replace(/,/g, "");
      if (isNaN(value)) {
        suppHealthPlan.renewalRates["ratesT" + tierNumber] = Number(val);
      } else {
        suppHealthPlan.renewalRates["ratesT" + tierNumber] = (+value).toFixed(2);
      }
      if (value == '') {
        suppHealthPlan.renewalRates["ratesT" + tierNumber] = '';
      }
      renewalMonthlyTotal = this.getMonthlyTotal(suppHealthPlan, "Renewal", ageBand);
      renewalYearlyTotal = this.getAnnualTotal(suppHealthPlan, "Renewal", ageBand);
      suppHealthPlan.wasProposedPlanRatesEdited = true;
      suppHealthPlan.isProposedPlanRatesEdited = CommonConstants.YES;
    }
    const event = {
      suppHealthPreCom: this.suppHealthPreCom,
      editDetails: {
        currentRates: currentRates,
        plan: plan,
        tierNumber: tierNumber,
        ageBand: ageBand
      }
    }
    if (ageBand) {
      this.calculateAgeBandMonthlyRate(suppHealthPlan);
    } else {
      this.calculateMonthlyRate(suppHealthPlan);
    }
    this.onSHPCChange.emit(event)
  }

  getMonthlyTotal(plan, forType: string, ageBand: string) {
    let monthTotal = 0;
    let currentRates, renewalRates, quotedRates;
    if (ageBand) {
      currentRates = plan.ageBandCurrentRates[ageBand];
      renewalRates = plan.ageBandRenewalRates[ageBand];
      quotedRates = plan.ageBandQuotedRates[ageBand];
    } else {
      currentRates = plan.currentRates;
      renewalRates = plan.renewalRates;
      quotedRates = plan.quoteRates;
    }
    if (StringUtils.isEqual(forType, 'Current')) {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.currentEnrollments, currentRates, i);
      }
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.currentEnrollments, renewalRates, i);
      }
    } else if (StringUtils.isEqual(forType, 'Quote')) {
      for (let i = 1; i <= 5; i++) {
        monthTotal += this.getCalculatedRates(plan.quoteEnrollments, quotedRates, i);
      }
    }
    return monthTotal;
  }

  getCalculatedRates(enrollment: Enrollments, rate: PlanRates, index: number): number {
    let tierRate: string = '' + rate["ratesT" + index];
    if (tierRate) {
      tierRate = tierRate.replace("$", "").replace(/,/g, "");
    }
    return tierRate && !isNaN(parseFloat(tierRate)) ? parseFloat(tierRate) * this.getCalculatedEnrollments(enrollment, index) : 0;
  }

  getAnnualTotal(plan: any, forType: string, ageBand: string) {
    let yearTotal = 0;
    if (StringUtils.isEqual(forType, 'Current')) {
      yearTotal = this.getMonthlyTotal(plan, forType, ageBand) * 12;
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      yearTotal = this.getMonthlyTotal(plan, forType, ageBand) * 12;
    } else if (StringUtils.isEqual(forType, 'Quote')) {
      yearTotal = this.getMonthlyTotal(plan, forType, ageBand) * 12;
    }
    return SuppHealthUtil.roundedValue(yearTotal);
  }

  displayPremiumComparison(plan) {
    if (plan.hasQuotedRates && (plan.currentTier == plan.quoteTier || plan.renewalTier == plan.quoteTier)) {
      return true;
    }
    if (plan.currenTier !== plan.quoteTier && plan.renewalTier !== plan.quoteTier) {
      return false;
    }
  }

  getMaxTier(plan): number {
    if (plan.quoteTier && plan.currentTier) {
      return (plan.currentTier > plan.quoteTier) ? plan.currentTier : plan.quoteTier;
    }
    return plan.currentTier || plan.quoteTier;
  }

  getColSpan(type: string, plan): number {
    if (this.isRenewalQuoteDisabled()) {
      if (plan.hasAgeBandCurrentRates && plan.hasAgeBandQuotedRates) {
        if (StringUtils.isEqual(type, 'Header')) {
          return this.hasRenewalRates(plan) ? 2 : 1;
        } else if (StringUtils.isEqual(type, 'getHeaderCurrent')) {
          return this.hasRenewalRates(plan) ? 15 : 14;
        } else if (StringUtils.isEqual(type, 'getHeaderQuote')) {
          return 14;
        } else if (StringUtils.isEqual(type, 'getHeaderDiffrence')) {
          return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "Renewal") && this.hasMonthlyTotal(plan, "Current") ? 2 : 1;
        } else {
          if (this.hasRenewalRates(plan)) {
            if (!this.hasMonthlyTotal(plan, "Current")) {
              return 7;
            } else {
              return this.getAbsoluteValue(this.getDifferencePecentage(plan, "Current")) ? 7 : 8;
            }
          } else {
            return 28;
          }
        }
      }
      if (StringUtils.isEqual(type, 'Header')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      } else if (StringUtils.isEqual(type, 'getHeaderCurrent')) {
        return this.hasRenewalRates(plan) ? 3 : 2;
      } else if (StringUtils.isEqual(type, 'getHeaderQuote')) {
        return 2;
      } else if (StringUtils.isEqual(type, 'getHeaderDiffrence')) {
        return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "Renewal") && this.hasMonthlyTotal(plan, "Current") ? 2 : 1;
      } else {
        if (this.hasRenewalRates(plan)) {
          if (!this.hasMonthlyTotal(plan, "Current")) {
            return 7;
          } else {
            return this.getAbsoluteValue(this.getDifferencePecentage(plan, "Current")) ? 7 : 8;
          }
        } else {
          return 4;
        }
      }
    }
    else if (this.isSGRenewalQuoteDisabled()) {
      if (StringUtils.isEqual(type, 'Header')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      } else if (StringUtils.isEqual(type, 'getHeaderCurrent')) {
        return this.hasRenewalRates(plan) ? 3 : 3;
      } else if (StringUtils.isEqual(type, 'getHeaderQuote')) {
        return 3;
      } else if (StringUtils.isEqual(type, 'getHeaderDiffrence')) {
        return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "Renewal") && this.hasMonthlyTotal(plan, "Current") ? 2 : 1;
      } else {
        if (this.hasRenewalRates(plan)) {
          if (!this.hasMonthlyTotal(plan, "Current")) {
            return 7;
          } else {
            return this.getAbsoluteValue(this.getDifferencePecentage(plan, "Current")) ? 7 : 8;
          }
        } else {
          return 6;
        }
      }
    }
    else {
      if (StringUtils.isEqual(type, 'Header')) {
        return this.hasRenewalRates(plan) ? 2 : 1;
      } else if (StringUtils.isEqual(type, 'getHeaderCurrent')) {
        return this.hasRenewalRates(plan) ? 4 : 3;
      } else if (StringUtils.isEqual(type, 'getHeaderQuote')) {
        return 3;
      } else if (StringUtils.isEqual(type, 'getHeaderDiffrence')) {
        return this.hasRenewalRates(plan) && this.hasMonthlyTotal(plan, "Renewal") && this.hasMonthlyTotal(plan, "Current") ? 2 : 1;
      } else {
        if (this.hasRenewalRates(plan)) {
          if (!this.hasMonthlyTotal(plan, "Current")) {
            return 7;
          } else {
            return this.getAbsoluteValue(this.getDifferencePecentage(plan, "Current")) ? 7 : 8;
          }
        } else {
          return 6;
        }
      }
    }

  }

  getPlanRate(plan, tierValue: number, forType: string, index): string {
    let retValue;
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.currentRates && plan.currentRates["ratesT" + tierValue]) {
        retValue = plan.currentRates["ratesT" + tierValue];
      }

    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      if (plan.renewalRates && plan.renewalRates["ratesT" + tierValue]) {
        retValue = plan.renewalRates["ratesT" + tierValue];
      }
    } else {
      if (plan.quoteRates && plan.quoteRates["ratesT" + tierValue]) {
        retValue = plan.quoteRates["ratesT" + tierValue];
      }
    }
    if (retValue === 0 || isNaN(retValue)) {
      return formatCurrency(0, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
    }
    return formatCurrency(retValue, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
  }

  getAgeBandPlanRate(plan, tierValue: number, forType: string, index, key): string {
    let ageBandRateValue;
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.ageBandCurrentRates) {
        let ageCurrBandRate = plan.ageBandCurrentRates[key];
        if (ageCurrBandRate['ratesT' + tierValue]) {
          ageBandRateValue = formatCurrency(ageCurrBandRate['ratesT' + tierValue], this.locale, getCurrencySymbol('USD', 'wide'), '1.2-2')
        }
        else {
          return ageBandRateValue = formatCurrency(0, this.locale, getCurrencySymbol('USD', 'wide'), '1.2-2');
        }
      }
    } else {
      if (plan.ageBandQuotedRates) {
        let ageQuoteBandRate = plan.ageBandQuotedRates[key];
        if (ageQuoteBandRate['ratesT' + tierValue]) {
          ageBandRateValue = formatCurrency(ageQuoteBandRate['ratesT' + tierValue], this.locale, getCurrencySymbol('USD', 'wide'), '1.2-2')
        }
        else {
          return ageBandRateValue = formatCurrency(0, this.locale, getCurrencySymbol('USD', 'wide'), '1.2-2');
        }
      }
    }
    return ageBandRateValue
  }

  calculateRates(plan, tierValue, index) {
    return '' + plan.quoteRates['ratesT' + tierValue];
  }

  hasAgeBandCurrentRates(plan) {
    if (plan && plan.hasAgeBandCurrentRates) {
      return true
    }
    else {
      return false
    }
  }

  hasAgeBandQuotedRates(plan) {
    if (plan && plan.hasAgeBandQuotedRates) {
      return true
    }
    else {
      return false
    }
  }

  hasRenewalRates(plan): boolean {
    if (plan && plan.hasRenewalRates) {
      return true;
    }
    else
      return false;
  }

  hasMonthlyTotal(plan, forType: string): boolean {
    let total = this.getMonthlyRate(plan, forType);
    return total && total !== 0;
  }

  getTierName(plan, tierValue: number, forType: string): string {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (tierValue <= plan.currentTier) {
        return this.getTierEmpDesc(tierValue, plan.currentTier);
      }
    } else {
      if (tierValue <= plan.quoteTier) {
        return this.getTierEmpDesc(tierValue, plan.quoteTier);
      }
    }
    return "";
  }

  getTierEmpDesc(tierNumber: number, availableTiers: number): string {
    return SuppHealthUtil.getTierEmpDesc(tierNumber, availableTiers);
  }

  isTierApplicable(plan, tier: number, type: string): boolean {
    return SuppHealthUtil.isTierApplicable(plan, tier, type);
  }

  compareTierValues(plan, forType: string) {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.currentTier !== plan.quoteTier && plan.quoteTier == plan.renewalTier) {
        this.hideCurrentTier = true;
        return false;
      } else {
        this.hideCurrentTier = false;
        return true;
      }
    }
    if (StringUtils.isEqual(forType, 'Renewal')) {
      if (plan.quoteTier !== plan.renewalTier && plan.quoteTier == plan.currentTier) {
        this.hideRenewalTier = true;
        return false;
      } else {
        this.hideRenewalTier = false;
        return true
      }
    }

  }

  getAnnualRate(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.currentRates && plan.currentRates.yearlyTotal) {
        this.suppHealthPreCom.planComparison.forEach(response => {
        })
        plan.currentRates.yearlyTotal = plan.currentRates.monthlyTotal * 12
        return plan.currentRates.yearlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      if (plan.renewalRates && plan.renewalRates.yearlyTotal) {
        plan.renewalRates.yearlyTotal = plan.renewalRates.monthlyTotal * 12
        return plan.renewalRates.yearlyTotal;
      }
    } else {
      if (plan.quoteRates && plan.quoteRates.yearlyTotal) {
        plan.quoteRates.yearlyTotal = plan.quoteRates.monthlyTotal * 12;
        return plan.quoteRates.yearlyTotal;
      }
    }
    return 0;
  }

  getSHPlan(planID) {
    return this.suppHealthPreCom.planComparison.find(element => element.quoteRatingPlanID === planID);
  }

  getTotalEnrollment(plan, forType: string) {
    let total = 0;
    if (StringUtils.isEqual(forType, 'Current')) {
      for (let i = 1; i <= 5; i++) {
        total += this.getCalculatedEnrollments(plan.currentEnrollments, i);
      }
    } else if (StringUtils.isEqual(forType, 'Quote')) {
      for (let i = 1; i <= 5; i++) {
        total += this.getCalculatedEnrollments(plan.quoteEnrollments, i);
      }
    }
    return total;
  }

  getCalculatedEnrollments(enrollment: Enrollments, index: number): number {
    let tierEnroll = enrollment["enrollT" + index];
    return tierEnroll && !isNaN(tierEnroll) ? tierEnroll * 1 : 0;
  }

  getAnnualRateDifference(plan, forType: string): number {
    if (plan.hasQuotedRates) {
      if (StringUtils.isEqual(forType, 'Current')) {
        plan.diffToCurrentYearlyRate = plan.quoteRates.yearlyTotal - plan.currentRates.yearlyTotal
        return plan.diffToCurrentYearlyRate;
      } else {
        plan.diffToRenewalYearlyRate = plan.quoteRates.yearlyTotal - plan.renewalRates.yearlyTotal
        return plan.diffToRenewalYearlyRate;
      }
    }
  }

  getPercentage(value) {
    return value.toFixed(2) + '%';
  }

  getAbsoluteValue(value: number, type?: string): number | string {
    if (value && value != Infinity) {
      if (StringUtils.isEqual(type, 'percent')) {
        if (StringUtils.isEqual(this.marketSegment, CommonConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
          return formatPercent(Math.abs(value), this.locale, '1.2-2');
        } else {
          return formatPercent(Math.abs(value), this.locale, '1.0-2');
        }
      }
      return formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
    }
    return '0.0%';
  }

  getPlanInfo(type: string, plan): string {
    return SuppHealthUtil.getPlanInfo(type, plan);
  }

  getPlanEnrollment(plan, tierValue: number, forType: string): number {
    return SuppHealthUtil.getPlanEnrollment(plan, tierValue, forType)
  }

  getAgeBandPlanEnrollment(plan, tierValue: number, forType: string): number {
    return SuppHealthUtil.getAgeBandPlanEnrollment(plan, tierValue, forType)
  }

  getEnrollmentTotal(plan, forType: string): number {
    return SuppHealthUtil.getEnrollmentTotal(plan, forType);
  }

  getMonthlyRateDifference(plan, forType: string): number {
    return SuppHealthUtil.getMonthlyRateDifference(plan, forType);
  }

  getMonthlyRate(plan, forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      if (plan.currentRates && plan.currentRates.monthlyTotal) {
        return plan.currentRates.monthlyTotal;
      }
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      if (plan.renewalRates && plan.renewalRates.monthlyTotal) {
        return plan.renewalRates.monthlyTotal;
      }
    } else {
      if (!this.isChangedFlag && plan.hasQuotedRates === true) {
        return plan.quoteRates.monthlyTotal;
      } else {
        if (plan.quoteRates) {
          let enr = plan.quoteEnrollments['enrollT1'] ? plan.quoteEnrollments['enrollT1'] : 0;
          let rates = plan.quoteRates['ratesT1'] ? (Math.round((plan.quoteRates['ratesT1'] + Number.EPSILON) * 100) / 100 * enr) : 0;
          plan.quoteRates.monthlyTotal = rates;
          return plan.quoteRates.monthlyTotal;
        }
      }
    }
  }

  getDifferencePecentage(plan, forType: string): number {
    if (this.isRenewalQuoteDisabled()) {
      this.getMonthlyRate(plan, 'Current');
      this.getEnrollmentTotal(plan, 'Quote');
      this.getMonthlyRate(plan, 'Quote');
      this.getAbsoluteValue(this.getMonthlyRateDifference(plan, 'Current'));
      this.getAnnualRate(plan, 'Current');
      this.getAnnualRate(plan, 'Quote');
      this.getAbsoluteValue(this.getAnnualRateDifference(plan, 'Current'));
    }
    if (plan.hasQuotedRates === true) {
      if (StringUtils.isEqual(forType, 'Current')) {
        if (this.isRenewalQuoteDisabled()) {
          this.calculateMonthlyRate(plan);
          plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.quoteRates.monthlyTotal * 12, plan.currentRates.monthlyTotal * 12);
          return plan.diffToCurrentRatePercentage.toFixed(6);
        } else {
          plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.quoteRates.yearlyTotal, plan.currentRates.yearlyTotal);
          return plan.diffToCurrentRatePercentage;
        }
      } else {
        plan.diffToRenewalRatePercentage = this.calculateRatePer(plan.quoteRates.yearlyTotal, plan.renewalRates.yearlyTotal);
        return plan.diffToRenewalRatePercentage;
      }
    }
    if (plan.hasAgeBandQuotedRates) {
      if (StringUtils.isEqual(forType, 'Current')) {
        if (this.isRenewalQuoteDisabled()) {
          this.calculateAgeBandMonthlyRate(plan);
          plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.ageBandQuotedMonthlyPremium * 12, plan.ageBandCurrentMonthlyPremium * 12);
          return plan.diffToCurrentRatePercentage.toFixed(6);
        } else {
          plan.diffToCurrentRatePercentage = this.calculateRatePer(plan.ageBandQuotedYearlyTotal, plan.ageBandCurrentYearlyTotal);
          return plan.diffToCurrentRatePercentage;
        }
      } else {
        plan.diffToRenewalRatePercentage = this.calculateRatePer(plan.ageBandQuotedYearlyTotal, plan.renewalRates.yearlyTotal);
        return plan.diffToRenewalRatePercentage;
      }
    }
  }

  calculateMonthlyRate(plan) {
    if (this.featuredPlans) {
      this.featuredPlans.forEach(featuredPlan => {
        if (featuredPlan.ratingPlanID === plan.quoteRatingPlanID) {
          let adjFctr = 1;
          if (featuredPlan['uwAdjustmentFactor']) {
            adjFctr = featuredPlan['uwAdjustmentFactor'];
          } else if (featuredPlan.adjustments && featuredPlan.adjustments.uwAdjustmentFactor) {
            adjFctr = featuredPlan.adjustments.uwAdjustmentFactor;
          }
          let enrollment = plan.quoteEnrollments['enrollT1'] ? plan.quoteEnrollments['enrollT1'] : 0;
          plan.quoteRates.monthlyTotal = plan.currentRates['ratesT1'] * (adjFctr) * enrollment;
          if (StringUtils.isEqualIgnoreCase(plan.isCurrentPlanRatesEdited, CommonConstants.YES)) {
            plan.currentRates.monthlyTotal = plan.currentRates['ratesT1'] * enrollment;
          }
        }
      });
    }
  }

  calculateAgeBandMonthlyRate(plan) {
    if (this.featuredPlans) {
      let monthlyRate = 0;
      let currentMonthlyRate = 0;
      this.featuredPlans.forEach(featuredPlan => {
        if (featuredPlan.ratingPlanID === plan.quoteRatingPlanID) {
          let ageBandCurrentRates: Map<string, Object> = new Map(Object.entries(plan.ageBandCurrentRates));
          let adjFctr = 1;
          if (featuredPlan['uwAdjustmentFactor']) {
            adjFctr = featuredPlan['uwAdjustmentFactor'];
          } else if (featuredPlan.adjustments && featuredPlan.adjustments.uwAdjustmentFactor) {
            adjFctr = featuredPlan.adjustments.uwAdjustmentFactor;
          }
          for (let rates of ageBandCurrentRates) {
            let currentRates = rates[1];
            let key = rates[0];
            let enr = plan.quoteEnrollments['enrollT1'] ? plan.quoteEnrollments['enrollT1'] : 0;
            monthlyRate = monthlyRate + (plan.ageBandCurrentRates[key]['ratesT1'] * (adjFctr) * enr);
          }
          plan.ageBandQuotedMonthlyPremium = monthlyRate;
          if (StringUtils.isEqualIgnoreCase(plan.isCurrentPlanRatesEdited, CommonConstants.YES)) {
            for (let rates of ageBandCurrentRates) {
              let key = rates[0];
              let enr = plan.quoteEnrollments['enrollT1'] ? plan.quoteEnrollments['enrollT1'] : 0;
              currentMonthlyRate = currentMonthlyRate + (plan.ageBandCurrentRates[key]['ratesT1'] * enr);
            }
            plan.ageBandCurrentMonthlyPremium = currentMonthlyRate;
          }
        }
      });
    }
  }

  calculateRatePer(total, value) {
    if (value === 0) {
      return 0;
    }
    let increase = total - value;
    return (increase / value);
  }

  classHighlighter(value): string {
    return value * 1 > 0 ? 'higher' : 'lesser';
  }

  hasMonthlyGrandTotal(forType: string): boolean {
    let total = this.getMonthlyTotalRate(forType);
    return total && total !== 0;
  }

  getColSpanGrand(): number {
    if (this.suppHealthPreCom.hasRenewalRates) {
      if (this.getRenewalIncreasePercentage("Renewal")) {
        if (!this.hasMonthlyGrandTotal("Current")) {
          return 3;
        } else {
          return this.getTotalDifferencePecentage("Current") ? 3 : 4;
        }
      } else {
        return 7;
      }
    } else {
      return 6;
    }
  }

  getRenewalIncreasePercentage(forType: string) {
    if (StringUtils.isEqual(forType, 'Renewal')) {
      return this.suppHealthPreCom.renewalIncreasePercentage ? this.suppHealthPreCom.renewalIncreasePercentage : 0;
    }
  }

  getMonthlyTotalRate(forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      return (this.suppHealthPreCom.currentMonthlyGrandTotal || 0);
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      return (this.suppHealthPreCom.renewalMonthlyGrandTotal || 0);
    } else {
      if (this.suppHealthPreCom.quoteMonthlyGrandTotal) {
        let monthlyGrandTotal = 0;
        this.suppHealthPreCom.planComparison.forEach(item => {
          if (item['hasQuotedRates']) {
            monthlyGrandTotal = monthlyGrandTotal + item.quoteRates.monthlyTotal;
            this.suppHealthPreCom.quoteMonthlyGrandTotal = monthlyGrandTotal;

          }
        });
        return this.suppHealthPreCom.quoteMonthlyGrandTotal;

      }
    }
  }

  getAnnualTotalRate(forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      return (this.suppHealthPreCom.currentYearlyGrandTotal || 0);
    } else if (StringUtils.isEqual(forType, 'Renewal')) {
      return (this.suppHealthPreCom.renewalYearlyGrandTotal || 0);
    } else {
      if (this.suppHealthPreCom.quoteYearlyGrandTotal) {
        this.suppHealthPreCom.quoteYearlyGrandTotal = this.suppHealthPreCom.quoteMonthlyGrandTotal * 12;
        return this.suppHealthPreCom.quoteYearlyGrandTotal;
      }
    }
  }

  getMonthlyTotalRateDifference(forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      this.calculateGrandTotal();
      this.suppHealthPreCom.diffToCurrentMonthlyTotal = this.suppHealthPreCom.quoteMonthlyGrandTotal - this.suppHealthPreCom.currentMonthlyGrandTotal;
      return this.suppHealthPreCom.diffToCurrentMonthlyTotal ? this.suppHealthPreCom.diffToCurrentMonthlyTotal : 0;
    } else {
      this.suppHealthPreCom.diffToRenewalMonthlyTotal = this.suppHealthPreCom.quoteMonthlyGrandTotal - this.suppHealthPreCom.renewalMonthlyGrandTotal;
      return this.suppHealthPreCom.diffToRenewalMonthlyTotal ? this.suppHealthPreCom.diffToRenewalMonthlyTotal : 0;
    }
  }

  getAnnualTotalRateDifference(forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      this.calculateGrandTotal();
      this.suppHealthPreCom.diffToCurrentYearlyTotal = this.suppHealthPreCom.quoteYearlyGrandTotal - this.suppHealthPreCom.currentYearlyGrandTotal;
      return this.suppHealthPreCom.diffToCurrentYearlyTotal ? this.suppHealthPreCom.diffToCurrentYearlyTotal : 0;
    } else {
      this.suppHealthPreCom.diffToRenewalYearlyTotal = this.suppHealthPreCom.quoteYearlyGrandTotal - this.suppHealthPreCom.renewalYearlyGrandTotal;
      return this.suppHealthPreCom.diffToRenewalYearlyTotal ? this.suppHealthPreCom.diffToRenewalYearlyTotal : 0;
    }
  }

  getTotalDifferencePecentage(forType: string): number {
    if (StringUtils.isEqual(forType, 'Current')) {
      this.suppHealthPreCom.diffToCurrentRatePercentage = this.calculateRatePer(this.suppHealthPreCom.quoteYearlyGrandTotal, this.suppHealthPreCom.currentYearlyGrandTotal) * 100;
      this.calculateGrandTotal();
      return this.suppHealthPreCom.diffToCurrentRatePercentage ? this.suppHealthPreCom.diffToCurrentRatePercentage : 0;

    } else {
      this.suppHealthPreCom.diffToRenewalRatePercentage = this.calculateRatePer(this.suppHealthPreCom.quoteYearlyGrandTotal, this.suppHealthPreCom.renewalYearlyGrandTotal) * 100;
      return this.suppHealthPreCom.diffToRenewalRatePercentage ? this.suppHealthPreCom.diffToRenewalRatePercentage : 0;
    }
  }

  onCurrentBenefits(plan: any) {
    this.currentPlansBenefitsList = plan.currentPlanBenefits.length ? plan.currentPlanBenefits : null;
  }

  calculateGrandTotal() {
    this.suppHealthPreCom.currentMonthlyGrandTotal = 0;
    this.suppHealthPreCom.currentYearlyGrandTotal = 0;
    this.suppHealthPreCom.quoteMonthlyGrandTotal = 0;
    this.suppHealthPreCom.quoteYearlyGrandTotal = 0;
    this.suppHealthPreCom.renewalMonthlyGrandTotal = 0;
    this.suppHealthPreCom.renewalYearlyGrandTotal = 0;
    this.suppHealthPreCom.planComparison.forEach((pc: PlanComparison) => {
      if (pc.quoteRates && pc.quoteRatingPlanID) {
        if (pc.currentRates.monthlyTotal && pc.currentRates.yearlyTotal != undefined) {
          this.suppHealthPreCom.currentMonthlyGrandTotal += pc.currentRates.monthlyTotal;
          this.suppHealthPreCom.currentYearlyGrandTotal += pc.currentRates.yearlyTotal;
        }
        this.suppHealthPreCom.quoteMonthlyGrandTotal += pc.quoteRates.monthlyTotal;
        this.suppHealthPreCom.quoteYearlyGrandTotal += pc.quoteRates.yearlyTotal;
        if (pc.hasRenewalRates) {
          this.suppHealthPreCom.renewalMonthlyGrandTotal += pc.renewalRates.monthlyTotal;
          this.suppHealthPreCom.renewalYearlyGrandTotal += pc.renewalRates.yearlyTotal;
        }
      }
    });
    if (this.suppHealthPreCom.currentMonthlyGrandTotal)
      this.suppHealthPreCom.diffToCurrentRatePercentage = this.suppHealthPreCom.diffToCurrentMonthlyTotal / this.suppHealthPreCom.currentMonthlyGrandTotal;
    else this.suppHealthPreCom.diffToCurrentRatePercentage = 0;
  }

  markGuardRailFailuresPlanLevel(guardRail, suppHealthPlans) {
    if (this.featuredPlans) {
      let filteredEleList = {};
      let failedGuardRails = [];
      this.featuredPlans.forEach(element => {
        if (element.ratingPlanID == suppHealthPlans.quoteRatingPlanID) {
          if (element.failedGuardRails && element.failedGuardRails.length) {
            failedGuardRails = element.failedGuardRails;
          }
        }
      });
      if (suppHealthPlans.quoteRatingPlanID && failedGuardRails.length) {
        failedGuardRails.forEach(response => {
          let guardrailRepRes = response.split('.');
          filteredEleList[guardrailRepRes[guardrailRepRes.length - 1]] = 1;
        });
        let list = [];
        list = Object.keys(filteredEleList);
        if (list.find(element => element === guardRail)) {
          return true;
        } else {
          return false;
        }
      }
    }
  }

  markGuardRailFailuresPremiumComparison() {
    if (this.suppHealthPreCom && this.suppHealthPreCom['guardRailStatus'] && this.suppHealthPreCom['guardRailStatus'].CPQuotedEnrollmentCount.status == 'Failed') {
      this.premiumGuardrail = (this.suppHealthPreCom['guardRailStatus'].CPQuotedEnrollmentCount.value || '');
      return true;
    } else {
      return false;
    }
  }

  displayErrorMessage(eleID) {
    return SuppHealthUtil.displayGuardrailErrorMessage(eleID, this.boundariesObjName, this.premiumGuardrail);
  }

  isRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
      if (StringUtils.isEqual(this.marketSegment, CommonConstants.largeGroup) && StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
        return true;
      } else {
        return false;
      }
    }
  }

  isSGRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
      if (StringUtils.isEqual(this.marketSegment, CommonConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
        return true;
      } else {
        return false;
      }
    }
  }

  buildAgeBand(item: any) {
    return item?.value?.ageBandStart + '-' + item?.value?.ageBandEnd;
  }

  protected readonly CommonConstants = CommonConstants;

}
