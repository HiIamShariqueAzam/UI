import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuppHealthRateComparisonComponent } from './supp-health-rate-comparison.component';

describe('SuppHealthRateComparisonComponent', () => {
  let component: SuppHealthRateComparisonComponent;
  let fixture: ComponentFixture<SuppHealthRateComparisonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuppHealthRateComparisonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SuppHealthRateComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
