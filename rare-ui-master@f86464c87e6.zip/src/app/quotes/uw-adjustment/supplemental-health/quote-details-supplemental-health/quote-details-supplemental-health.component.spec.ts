import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteDetailsSupplementalHealthComponent } from './quote-details-supplemental-health.component';

describe('QuoteDetailsSupplementalHealthComponent', () => {
  let component: QuoteDetailsSupplementalHealthComponent;
  let fixture: ComponentFixture<QuoteDetailsSupplementalHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuoteDetailsSupplementalHealthComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuoteDetailsSupplementalHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
