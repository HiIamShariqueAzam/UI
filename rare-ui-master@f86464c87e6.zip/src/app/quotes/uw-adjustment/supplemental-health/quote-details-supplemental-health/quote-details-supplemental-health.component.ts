import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { StringUtils } from "../../../../shared/utils/string-utils";
import { descending } from "d3";
import { AuthenticationService, CommonService, ProcessQuoteDetailsService } from 'src/app/shared/services';
import { FormGroup, FormGroupDirective } from '@angular/forms';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { CommonConstants } from '../../../../shared/constants/common.constants';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
import { RenewalsConstants } from 'src/app/renewals/renewals-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-quote-details-supplemental-health',
  templateUrl: './quote-details-supplemental-health.component.html',
  styleUrls: ['./quote-details-supplemental-health.component.css'],
  standalone: false,
})
export class QuoteDetailsSupplementalHealthComponent implements OnInit, OnChanges {

  @Input() quoteDetailsObj;
  @Input() userRole;
  @Input() disableAll;
  @Input() boundariesObjName;
  @Input() featuredPlans;
  @Input() quotelevelFailData;
  @Input() initializeQuote;
  @Input() guardrailBoundariesToQuoteDetails;
  @Input() oldQuotesData;
  @Input() quoteHistory;
  @Input() rareData;
  @Input() statusReasons: any;
  @Input() peOverrideData;
  @Input() defaultValue: any = {};
  @Input() uwAdjustmentFetchObject: any;
  @Input() statusReasonsObj: any;
  @Output() userSelectionChanges = new EventEmitter<any>();

  form: FormGroup;
  supportingDocLinks: any;
  isCollapsed = false;
  urlData: any;
  opportunityType: string;
  marketSegment: string;
  rateGuaranteeEffDate: any;
  rateGuaranteeEndDate: any;
  mbuList: any;
  createOpportunityURL: string = '/opportunity/create-opportunity-new';
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  alternateQuote: any;
  isSentToOpportunity: any;
  isUnifiedPayloadSubmission: boolean = false;
  readonly quoteOriginConstants = QUOTE_ORIGIN;
  arrowCallRestrictionMap = this.commonService.getArrowCallRestrictionMap();
  isCrossSelled: boolean;
  isSGMarketSegment: boolean;
  mbuChanged: boolean;
  LGFItoSGAbfCrossSelling: boolean;
  hideRollingLossRatio: boolean;
  opportunityID: any;
  quoteHeaderID: any;
  quotingTypeFromTab: any;
  quoteOrigin: any;
  accountName: any;
  status: any;
  censusID: any;
  assignedUWName: string;
  lob: any;
  fundingType: any;
  ratingTransID: any;
  isQuoteOriginAutoRunBatch: boolean;
  underwriterList: any;
  userSelectedUWName: { label: string; value: string; };
  userSelectedStatus: { label: any; value: any; };
  userSelectedReason: boolean;
  siteMatchData: any;
  processedQuoteDetails: any;
  restrictArrowCall: any;
  initialRiskScoreValue: any;
  hitRate: any = null;
  initialCurvToolTip: string = null;
  isBlinking: boolean = false;
  experienceSummaryID: any;
  medicalInputTier: any;
  isInitialLoad = true;
  statusOptions: any[] = [];
  selectedStatusReasons: any;  
  lobFundingTypeMapForSendToOpp = this.commonService.getEnableSendToOppMap();

  constructor(
    private commonService: CommonService,
    private rootFormGroup: FormGroupDirective,
    private authService: AuthenticationService,
    private commonQuoteService: CommonQuoteService,
    private router: Router,
    private actRoute: ActivatedRoute,
    private processDetailsService: ProcessQuoteDetailsService,
    ) {
  }
  ngOnChanges(changes: SimpleChanges) {
    if ((changes.quoteDetailsObj && !changes.quoteDetailsObj.firstChange) || (changes.oldQuotesData && !changes.oldQuotesData.firstChange)) {
      this.handleRateInitialResponse();
      this.oldQuotesData = this.oldQuotesData;
    }
  }
  ngOnInit(): void {
    this.form = this.rootFormGroup.control;
    this.opportunityType = this.rareData.opportunityType;
    this.marketSegment = this.rareData.marketSegment;
    this.alternateQuote = this.rareData?.medical?.alternateQuote;
    this.isSentToOpportunity = this.rareData?.isSentToOpportunity;
    this.isQuoteOriginAutoRunBatch = this.rareData.quoteOrigin === RenewalsConstants.AUTO_RUN_BATCH;
    this.getIsSentToOpportunity();
    if (this.isSentToOpportunity) {
      this.isUnifiedPayloadSubmission = true;
    }
    if (this.rareData?.oppOrigin?.['Market Segment']) {
      this.isCrossSelled = true;
    }
    if (this.rareData?.marketSegment === 'SG') {
      this.isSGMarketSegment = true;
    }
    if (this.rareData?.oppOrigin?.['MBU']) {
      this.mbuChanged = true;
    }
    if (
      this.rareData?.oppOrigin?.['Fundingtype'] &&
      StringUtils.isEqual(this.rareData?.oppOrigin?.Fundingtype, CommonConstants.fundingTypeFiToAbfChanged)
    ) {
      this.LGFItoSGAbfCrossSelling = true;
    }
    if ((this.isCrossSelled && this.rareData?.oppOrigin?.Fundingtype) || this.alternateQuote) {
      this.hideRollingLossRatio = true;
    }
    this.urlData = "";
    if (this.rareData?.suppHealth && StringUtils.isEqual(this.rareData.opportunityType, CommonConstants.RENEWAL_LOCAL) && StringUtils.isEqual(this.marketSegment, CommonConstants.largeGroup)) {
      this.rateGuaranteeEffDate = this.rareData.suppHealth.guaranteeEffectiveDate;
      this.rateGuaranteeEndDate = this.rareData.suppHealth.guaranteeEndDate;
    }
    this.commonService.getNationalMbu().subscribe(response => {
      this.mbuList = response;
    });
    this.handleRateInitialResponse();
  }
  // Downloading the census
  downLoadCensus() {
    this.commonQuoteService.downLoadCensus(this.quoteDetailsObj.censusID, this.quoteDetailsObj.lob, this.quoteDetailsObj.quoteHeaderID, this.rareData['opportunityType'], this.rareData?.['groupNbr']);
  }
  getAddrOne() {
    if (this.quoteDetailsObj["address1"]) {
      return this.quoteDetailsObj["address1"];
    }
  }

  getAddrTwo() {
    if (this.quoteDetailsObj["address2"]) {
      return this.quoteDetailsObj["address2"];
    }
  }
  async getIsSentToOpportunity() {
    // Check localStorage for the persisted state of isSentToOpportunity
    const storedState = localStorage.getItem(`isSentToOpportunity_${this.opportunityID}`);
    if (storedState !== null) {
      this.isSentToOpportunity = JSON.parse(storedState);
    } else {
      if(!this.opportunityID || !this.lob) {
        return; 
      }
      
      this.isSentToOpportunity = false; // Default to false if no stored state

      // Fetch opportunities and update isSentToOpportunity if applicable
      let response = await firstValueFrom(this.commonQuoteService.getOpportunitesByOppID(this.opportunityID, this.lob));

      if (response != null) {
        for (var opp of response.opportunities) {
          if (opp && opp.opportunityID === this.opportunityID) {
            if (!this.isSentToOpportunity) {
              this.isSentToOpportunity = opp.isSentToOpportunity ?? false;

              // Persist the state in localStorage
              localStorage.setItem(`isSentToOpportunity_${this.opportunityID}`, JSON.stringify(this.isSentToOpportunity));
            }
          }
        }
      }

      if (this.isSentToOpportunity) {
        this.isUnifiedPayloadSubmission = true;
      }
    }
  }
  markGuardRailFailuresQuoteLevel(guardRail) {
  }

  displayErrorMessage(eleID) {
  }
  // Check if the quote is renewal local
  isRenewalQuoteDisabled() {
    if (this.rareData) {
      return StringUtils.isEqual(this.rareData.opportunityType, CommonConstants.RENEWAL_LOCAL);
    }
  }

  stringConversion(value) {
    return StringUtils.convertToString(value);
  }

  handleRateInitialResponse() {
    let quoteReason = this.rareData['quoteReason'];
    let sicDescription = "";
    let failedGuardRails;
    const sicCode = 'sicCode';
    if (quoteReason == 'TEST') {
      this.form.controls.quoteReason.setValue(true)
    } else {
      this.form.controls.quoteReason.setValue(false)
    }
    this.authService.userRoleTextToDisplay.subscribe(data => {
      if (data.includes('Read Only')) {
        this.form.controls.quoteReason.disable();
      }
    })
    this.supportingDocLinks = this.rareData.supportingDocLinks;

    if (this.quoteDetailsObj?.factors && this.quoteDetailsObj.factors?.sicDescription) {
      sicDescription = this.quoteDetailsObj.factors?.sicDescription;
    }
    if (this.rareData.failedGuardRails) {
      failedGuardRails = this.rareData.failedGuardRails?.length > 0 ? this.fetchQuotelevelFailRes(this.rareData.failedGuardRails) : null
    }
    this.quoteDetailsObj = {
      'censusID': this.quoteDetailsObj.censusID,
      'accountName': this.rareData.accountName,
      'opportunityID': this.quoteDetailsObj.oppID,
      'state': this.rareData.state,
      'address1': this.quoteDetailsObj.address1,
      'address2': this.quoteDetailsObj.address2,
      'compZipcode': this.quoteDetailsObj.compZipcode,
      'county': this.rareData.county,
      'fundingType': this.quoteDetailsObj.fundingType,
      'marketSegment': this.quoteDetailsObj.marketSegment,
      'opportunityType': this.quoteDetailsObj.opportunityType,
      'groupNumber': this.quoteDetailsObj.groupNumber,
      'virginGroup': this.quoteDetailsObj.virginGroup,
      'experienceIncluded': this.quoteDetailsObj.experienceIncluded,
      'salesRepName': this.quoteDetailsObj.salesRepName,
      'salesContactNo': this.quoteDetailsObj.salesContactNo,
      'factorEffectiveDate': this.quoteDetailsObj.factorEffectiveDate,
      'contractStartDate': this.quoteDetailsObj.contractStartDate,
      'rateGuaranteeMonths': this.quoteDetailsObj.rateGuaranteeMonths,
      'inputTier': this.quoteDetailsObj.inputTier,
      'reqTier': this.quoteDetailsObj.reqTier,
      'quotedSubs': this.quoteDetailsObj.quotedSubs,
      'waivers': this.quoteDetailsObj.waivers,
      'totEligibleEmp': this.quoteDetailsObj.totEligibleEmp,
      'status': this.quoteDetailsObj.status,
      'quoteHeaderID': this.rareData.quoteHeaderID,
      'lob': this.quoteDetailsObj.lob,
      'oppID': this.quoteDetailsObj.oppID,
      'sicCode': this.quoteDetailsObj.sicCode,
      'rateGuaranteeEffDate': this.getRateGuaranteeEffectiveDate(),
      'rateGuaranteeEndDate': this.getRateGuaranteeEndDate(),
      'quoteHeaderIDURL': 'https://commercial.my.salesforce.com/?ec=302&startURL=%2Flightning%2Fr%2F0064N00000dNuCuQAK%2Frelated%2FCombinedAttachments%2Fview',
      'factors': this.quoteDetailsObj.factors,
      'failedGuardRails': failedGuardRails,
      'hasGuardRailFailures': this.markGuardRailFailures(sicCode, failedGuardRails),
      'sicCodeDescription': this.quoteDetailsObj.sicCode + (sicDescription ? " - " : "") + sicDescription,
      'guardRailErrorMessage': this.displayGuardrailErrorMessage(sicCode, this.quoteDetailsObj.sicCode + (sicDescription ? " - " : "") + sicDescription),
      'valueToolTip': this.markGuardRailFailures(sicCode, failedGuardRails) ? '' : (this.quoteDetailsObj.sicCode + (sicDescription ? " - " : "") + sicDescription)
    }
    if (this.quoteDetailsObj) {
      this.accountName = this.quoteDetailsObj.accountName;
      this.status = this.quoteDetailsObj.status;
      this.supportingDocLinks = this.quoteDetailsObj.supportingDocLinks;
      this.userRole = this.authService.userRole['_value'];
      this.censusID = this.quoteDetailsObj.censusRefId;
      this.opportunityType = this.quoteDetailsObj.opportunityType || '';
      this.assignedUWName = '';
      this.lob = this.quoteDetailsObj.lob || '';
      this.fundingType = this.quoteDetailsObj.fundingType || '';
      this.opportunityID = this.quoteDetailsObj.opportunityID || '';
      this.quoteHeaderID = this.quoteDetailsObj.quoteHeaderID || '';
      // this.ratingTransID = this.quoteDetailsObj.ratingTransID || '';
      this.quotingTypeFromTab = this.quoteDetailsObj.quotingType;
      this.quoteOrigin = (this.quoteDetailsObj?.quoteOrigin)? this.quoteDetailsObj.quoteOrigin : this.rareData?.quoteOrigin;
      this.ratingTransID  = (this.quoteDetailsObj?.ratingTransID)? this.quoteDetailsObj.ratingTransID : this.rareData?.metadata?.ratingTransID;
      this.setQuoteDetails();
      }
    let lobStatusReason = localStorage.getItem("statusReasons" + "_" + this.quoteDetailsObj.quoteHeaderID + "_" + CommonConstants.SuppHealth + "_" + this.quoteDetailsObj.fundingType);
    if (typeof (lobStatusReason) != 'undefined' && lobStatusReason != null) {
      let statusReasons: any;
      if (lobStatusReason.includes(";")) {
        if (lobStatusReason.includes("; ")) {
          statusReasons = lobStatusReason.split("; ").join(";");
        }
        statusReasons = lobStatusReason.split(";").join("; ");
      } else {
        statusReasons = lobStatusReason;
      }
      this.statusReasons = "Decline Reasons: " + statusReasons;
    }
    this.urlData = this.getCOM2url();
    this.getIsSentToOpportunity();
  }

  getRateGuaranteeEffectiveDate(): any {
    if (this.rareData && this.rareData.suppHealth && this.rareData.suppHealth.guaranteeEffectiveDate) {
      return this.rareData.suppHealth.guaranteeEffectiveDate;
    }
  }

  getRateGuaranteeEndDate(): any {
    if (this.rareData && this.rareData.suppHealth && this.rareData.suppHealth.guaranteeEndDate) {
      return this.rareData.suppHealth.guaranteeEndDate;
    }
  }

  getCOM2url(): any {
    let supportingDocLinksKeywords = this.commonService.getSupportingDocLinksKeywords();
    return CommonUtil.getCOM2url(this.supportingDocLinks, supportingDocLinksKeywords);
  }
  getAccName() {
    if (this.rareData["accountName"]) {
      return this.rareData["accountName"];
    }
  }
  getQuoteHeaderID() {
    if (this.rareData["quoteHeaderID"]) {
      return this.rareData["quoteHeaderID"];
    }
  }
  markGuardRailFailures(guardRail, failedGuardRails) {
    return failedGuardRails && failedGuardRails[guardRail];
  }
  displayGuardrailErrorMessage(eleID, value) {
    switch (eleID) {
      case CommonConstants.SIC_CODE:
        return value + CommonConstants.GAURD_RAIL_ERROR_MESSAGE_FOR_SIC_CODE_POST_FIX;
      case CommonConstants.IN_RATE_GUARANTEE:
        return CommonConstants.GAURD_RAIL_ERROR_MESSAGE_FOR_NOT_IN_RATE_GUARANTEE;
      case CommonConstants.IS_NATIONAL:
        return CommonConstants.GUARD_RAIL_ERROR_MESSAGE_FOR_NATIONAL_GROUP;
      default:
        return;
    }
  }

  getMBUNational(mbuValue) {
    let mbu = "";
    if (!this.mbuList) {
      return mbuValue;
    }

    if (this.rareData?.mbu) {
      mbu = this.rareData.mbu.substring(0, this.rareData.mbu.length - 2);
    }

    return mbu in this.mbuList ? CommonConstants.RENEWAL_NATIONAL : mbuValue;
  }

  fetchQuotelevelFailRes(array) {
    let guardRailErrorObj = {};
    array.map((guardRail) => {
      let guardrailList = guardRail.split('.');
      if (guardrailList.length === 1) {
        guardRailErrorObj[(guardrailList[0])] = 1;
      }
      else {
        guardRailErrorObj[guardrailList[guardrailList.length - 1]] = 1;
      }
    })
    return guardRailErrorObj;
  }

  isOverridden(original, overridden) {
    return !StringUtils.isEqual(String(original), String(overridden));
  }

  sendToOppClicked() {
    this.showProgress = false;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';

    this.commonQuoteService.sendToOpportunitiesQuote(this.opportunityID, this.lob, this.fundingType, this.ratingTransID).subscribe(
      (apiResponse) => {
        this.showProgress = true;
        this.progressPercent = 1;
        this.progressStyle = 'progress-bar-warning';
        const apiStatus = apiResponse.data.status;
        if (apiStatus.code == '200') {
          this.progressStyle = 'progress-bar-success';
          this.progressPercent = 100;
          this.progressMessage = apiStatus.msg;

          // Set isSentToOpportunity to true and persist it
          this.isSentToOpportunity = true;
          localStorage.setItem(`isSentToOpportunity_${this.opportunityID}`, JSON.stringify(this.isSentToOpportunity));
        }
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
        this.isUnifiedPayloadSubmission = true;
      },
      (error) => {
        this.progressPercent = 90;
        this.progressStyle = 'progress-bar-danger';
        this.progressMessage = 'Error in getting response from Send To Opportunities';
        console.error('Error calling sendToOpportunities API:', error);
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      }
    );
  }

  checkReadonlyRole() {
    if (this.userRole.includes('READONLY')) {
      return true;
    }
  }
  isRenewal(): boolean {
    return StringUtils.isEqualIgnoreCase(this.opportunityType, 'Renewal Local');
  }

  openOpp() {
    const url = this.createOpportunityURL;
    if (url) {
      const pathToNavigate = this.createOpportunityURL;
      const url = this.router.serializeUrl(
        this.router.createUrlTree([pathToNavigate], {
          queryParams: {
            opportunityID: this.opportunityID
          }
        })
      );
      localStorage.setItem('quoteHeaderID', this.quoteHeaderID);
      localStorage.setItem('opportunityID', this.opportunityID);
      localStorage.setItem('isLoginAgain', 'true');
      localStorage.setItem('assignedUserRoles', this.authService.getUserRole());
      localStorage.setItem('assignedUserRolesTextToDisplay', this.authService.getUserRoleTextToDisplay());
      localStorage.setItem('sendToOpp', 'true');
      localStorage.setItem('assignedUserLobs', this.authService.getUserLob());
      localStorage.setItem('assignedUserStates', this.authService.getUserState());
      localStorage.setItem('disableAll', 'false');
      window.open(url, '_blank');
    } else {
      alert("Opportunity Details doesn't exist");
    }
  }

  setQuoteDetails() {
    this.updateAssignedUWName();
    this.setUnderwriterList(this.rareData.state);
    if (!this.underwriterList.find((uwDetails) => uwDetails.value === this.assignedUWName)) {
      this.underwriterList.push({ label: this.assignedUWName, value: this.assignedUWName });
    }
    this.sortObjectArr(this.underwriterList);
    if (this.assignedUWName) {
      this.userSelectedUWName = { label: this.assignedUWName, value: this.assignedUWName };
    } else {
      this.userSelectedUWName = { label: '-', value: this.assignedUWName };
    }
    if (this.status) {
      this.userSelectedStatus = { label: this.status, value: this.status };
    }
    this.userSelectedReason = this.rareData.quoteReason && this.rareData.quoteReason !== 'REAL';
    if (this.rareData && this.rareData.factors && this.rareData.factors.medNetworkFactor) {
      this.siteMatchData = this.rareData.factors.medNetworkFactor;
    }
    this.quotelevelFailData = {};
    if (this.rareData && this.rareData.failedGuardRails) this.quotelevelFailData = this.fetchQuotelevelFailRes(this.rareData.failedGuardRails) || null;

    this.actRoute.queryParams.subscribe((params) => {
      // TODO: This code needs to be removed
      if (params['quotingTypeFromTab'] && params['quotingTypeFromTab'] == 'MEWA') this.rareData.quotingType = 'MEWA';
    });

    this.setRistirictArrowCall();
    this.processedQuoteDetails = this.processDetailsService.process(
      this.rareData,
      this.lob.toLocaleLowerCase(),
      this.fundingType,
      this.defaultValue,
      this.restrictArrowCall,
      this.quotelevelFailData
    );
    this.initialRiskScoreValue = this.rareData?.riskScore;
    this.hitRate = this.rareData?.hitRate?.toFixed(2);
    this.initialCurvToolTip = 'Risk Score: ' + this.initialRiskScoreValue + (this.hitRate ? ', Hit Rate: ' + this.hitRate + '%' : '');

    this.isBlinking = true;
    // if ((this.rareData, this.rareData.riskScore != -99999)) {
    //   this.curvRiskScoreChange.emit({ initialRiskScoreValue: this.initialRiskScoreValue, isSSEEvent: false });
    // }
    this.onUserSelection();
    if (this.rareData.groupExperienceSummary && this.rareData.groupExperienceSummary.summaryReferenceID) {
      this.experienceSummaryID = this.rareData.groupExperienceSummary.summaryReferenceID;
    }
    this.medicalInputTier = this.rareData['medicalInputTier'];
  }
  updateAssignedUWName() {
    if (this.rareData.underwriterName) {
      this.assignedUWName = this.rareData.underwriterName;
    } else if (this.rareData && this.rareData['uwAdjustment']) {
      this.assignedUWName = this.rareData['uwAdjustment'].assignedUWName || this.assignedUWName;
    }
  }

  setUnderwriterList(state) {
    this.underwriterList = this.commonQuoteService.underwriterList[state];
    if (this.underwriterList === undefined || this.underwriterList.length <= 0) {
      this.underwriterList = [];
    } else {
      this.underwriterList = this.underwriterList.slice(0);
    }
    this.underwriterList.push({ label: '-', value: '' });
  }
  sortObjectArr(objectArr) {
    objectArr.sort((a, b) => 0 - (a.label > b.label ? -1 : 1));
  }
  setRistirictArrowCall() {
    if (this.rareData && this.rareData.opportunityType === 'New Business Local') {
      const fundingType = this.rareData.fundingType;
      const lobRestrictions = this.arrowCallRestrictionMap['New Business Local']?.[fundingType];
      const isEnabled = lobRestrictions?.includes('ALL') || lobRestrictions?.includes(this.rareData.derivedState);
      this.restrictArrowCall = !isEnabled;
    }
  }
  onUserSelection() {
    this.isInitialLoad = true;
    this.statusOptions = [];
    let allStatusReasons = [];

    if (this.statusReasonsObj) {
      const selectedStatusReasons = this.statusReasonsObj[this.userSelectedStatus?.value];
      if (selectedStatusReasons?.length > 0) {
        this.statusOptions = selectedStatusReasons.map((reasonOptions) => ({ label: reasonOptions, value: reasonOptions }));
      } else {
        this.isInitialLoad = true;
      }
    }
    this.emitUserSelectionChanges();
  }
  onUserSelectionReason() {
    this.emitUserSelectionChanges();
  }

  private emitUserSelectionChanges() {
    this.userSelectionChanges.emit({
      quoteReason: this.userSelectedReason ? 'TEST' : 'REAL',
      assignedUWName: this.userSelectedUWName.value,
      status: this.userSelectedStatus?.value ?? '',
      selectedStatusReasons: this.selectedStatusReasons,
      statusReasonMap: this.statusReasonsObj
    });
  }

  showSendToOppBasedOnConfig() {
    return (
      this.lobFundingTypeMapForSendToOpp &&
      Object.keys(this.lobFundingTypeMapForSendToOpp).includes(this.quoteDetailsObj.lob)
    );
  }
  protected readonly descending = descending;
}
