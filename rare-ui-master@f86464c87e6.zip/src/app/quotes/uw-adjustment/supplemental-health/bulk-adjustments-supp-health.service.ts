import {Inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {AuthenticationService, CommonService} from "../../../shared/services";
import {SESSION_STORAGE, WebStorageService} from "ngx-webstorage-service";

@Injectable({
  providedIn: 'root'
})
export class BulkAdjustmentsSuppHealthService {

  constructor(private http: HttpClient,
              private commonService: CommonService,
              private authenticationService: AuthenticationService,
              @Inject(SESSION_STORAGE) private storage: WebStorageService,) { }

  showSuppHealthBulkAdjustmentScreen(){
    const url = this.commonService.getRareUiUrl() + "/showSuppHealthBulkAdjustmentScreen";
    let headers = this.commonService.setRequestHeaders();
    return  this.http.get(url, { headers: headers });
  }
}
