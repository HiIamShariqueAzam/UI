import { Component, OnInit, Input, AfterViewInit, ElementRef, ViewChild } from "@angular/core";
import { NgbModalConfig, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CommonService } from "src/app/shared/services";
import { Router } from "@angular/router";
import { DateUtil } from "src/app/shared/utils/date-util";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: 'app-adjustment-history',
  templateUrl: './adjustment-history.component.html',
  styleUrls: ['./adjustment-history.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class AdjustmentHistoryComponent implements OnInit, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  @Input() adjHistory: any;
  columns = [
    {
      "header": "Version",
      "field": "quoteVersion"
    },
    {
      "header": "Adj No",
      "field": "AdjNo"
    },
    {
      "header": "Updated Time (EST)",
      "field": "submittedTimestamp"
    },
    {
      "header": "Last Updated by",
      "field": "underWriterName"
    },
    {
      "header": "Update Types",
      "field": "uwActions"
    },
    {
      "header": "Adjustment Summary",
      "field": "adjustmentSummary"
    }
  ]

  constructor(
    config: NgbModalConfig) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  ngOnInit() {
  }

  formatDate(timestamp) {
    return DateUtil.formatDate(timestamp);
  }
}
