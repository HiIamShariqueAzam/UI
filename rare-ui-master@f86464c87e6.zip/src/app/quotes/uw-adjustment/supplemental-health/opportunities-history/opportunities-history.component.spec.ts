import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunitiesHistoryComponent } from './opportunities-history.component';

describe('OpportunitiesHistoryComponent', () => {
  let component: OpportunitiesHistoryComponent;
  let fixture: ComponentFixture<OpportunitiesHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpportunitiesHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OpportunitiesHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
