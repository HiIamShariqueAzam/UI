import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opportunities-history',
  templateUrl: './opportunities-history.component.html',
  styleUrls: ['./opportunities-history.component.css'],
  standalone: false
})
export class OpportunitiesHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}