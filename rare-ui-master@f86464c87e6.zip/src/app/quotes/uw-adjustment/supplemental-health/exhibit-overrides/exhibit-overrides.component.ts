import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { PeSheets, SuppHealthPeOverrideData } from "../../../../shared/models/exhibitOverrides";
import moment from "moment/moment";
import { DatePipe } from "@angular/common";
import { ValidationService } from "../../../../shared/services/validation.service";
import { CommonConstants } from "../../../../shared/constants/common.constants";
import { SuppHealthUtil } from "../suppHealth.util";

@Component({
  selector: 'app-exhibit-overrides-supplemental-health',
  templateUrl: './exhibit-overrides.component.html',
  styleUrls: ['./exhibit-overrides.component.css'],
  standalone: false,
})
export class ExhibitOverridesComponent implements OnInit, OnChanges {

  @Input() rareData: any;
  @Input() exhibitSheets: any;
  @Input() disableAll: boolean;
  @Output() onError = new EventEmitter< any>();

  isRenewal = false;

  peOverrideData: FormGroup<SuppHealthPeOverrideData>;
  peSheets : FormGroup<PeSheets>;
  overriddenData: any;

  // Rate Guarantee Dates
  rateGuaranteeEffectiveDate: any;
  rateGuaranteeEndDate: any;
  rateGuaranteeMonths: string;
  minDate: any;

  // PE Sheets
  availableSheets : any[];
  selectedProposalSheets : any;
  incomingSelectedSheets : any;
  incomingExhibitSheets : any[];
  modifiedExhibitSheets : any[];

  constructor(private fb: FormBuilder, public datepipe: DatePipe) {}

  ngOnInit(){
    this.peOverrideData = this.fb.group({
      rateGuaranteeEffectiveDate: ['', [ValidationService.dateVaidator]],
      rateGuaranteeEndDate: ['', [ValidationService.dateVaidator]],
      rateGuaranteeMonths: ['', [Validators.required, ValidationService.numberValidator]],
    });

    this.peSheets = this.fb.group({
      proposalSheets: ['',[Validators.required]]
    });

    this.setPeSheets();

    if (this.disableAll) {
      this.peOverrideData.disable();
      this.peSheets.disable();
    } else {
      this.peOverrideData.enable();
      this.peSheets.enable();
    }

    if (this.rareData) {
      this.isRenewal = this.rareData.opportunityType == CommonConstants.RENEWAL_LOCAL;
      this.setPEoverrideControlValues();
    }

    this.peSheets.get("proposalSheets").valueChanges.subscribe(sheetCodes=> {
      this.rareData.uwAdjustment.peOverrideData.sheetCodes = sheetCodes;
      this.onError.emit(this.peOverrideData.status === 'INVALID' || this.peSheets.controls.proposalSheets.errors)
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.rareData) {
      this.initializePEOverrideValues();
      if (this.rareData.uwAdjustment.peOverrideData) {
        this.overriddenData = (this.rareData.uwAdjustment && this.rareData.uwAdjustment.peOverrideData) || {};
        if (this.peOverrideData) {
          this.setPEoverrideControlValues();
        }
      }
    }
  }

  setPeSheets(){
    if (this.rareData?.uwAdjustment?.peOverrideData?.printExhibitEligibility) {
      this.setIncludeExcludeSheets(this.rareData.uwAdjustment.peOverrideData.printExhibitEligibility);
    } else if (this.exhibitSheets) {
      this.setIncludeExcludeSheets(this.exhibitSheets);
    }
  }

  setIncludeExcludeSheets(peSheets : any){
    let includeSheets = [];
    let allSheets = [];
    peSheets.forEach((val) => {
      allSheets.push({"label": val.printExhibitSheetName, "value": val.printExhibitTypeCode});
      if (val.sheetStatus === "Include") {
        includeSheets.push(val.printExhibitTypeCode);
      }
    });
    this.incomingExhibitSheets = JSON.parse(JSON.stringify(peSheets));
    this.modifiedExhibitSheets = JSON.parse(JSON.stringify(peSheets));
    this.selectedProposalSheets = includeSheets;
    this.incomingSelectedSheets = includeSheets;
    this.availableSheets = allSheets;
    if (this.rareData.uwAdjustment.peOverrideData.sheetCodes) {
      this.selectedProposalSheets = this.rareData.uwAdjustment.peOverrideData.sheetCodes;
    }
  }

  setPEoverrideControlValues() {
    if (this.overriddenData) {
      if (this.overriddenData.rateGuaranteeEffectiveDate) {
        let startDate = new Date(this.overriddenData.rateGuaranteeEffectiveDate);
        this.rateGuaranteeEffectiveDate = new Date(startDate.getUTCFullYear(), startDate.getUTCMonth(), startDate.getUTCDate());
      }
      if (this.overriddenData.rateGuaranteeEndDate) {
        let endDate = new Date(this.overriddenData.rateGuaranteeEndDate);
        this.rateGuaranteeEndDate = new Date(endDate.getUTCFullYear(), endDate.getUTCMonth(), endDate.getUTCDate());
      }
      this.minDate = this.rateGuaranteeEffectiveDate;
    }
    this.setControlValues();
  }

  setControlValues() {
    if (this.rateGuaranteeEffectiveDate) {
      this.peOverrideData.controls.rateGuaranteeEffectiveDate.setValue(this.transformDate(this.rateGuaranteeEffectiveDate));
    }
    if (this.rateGuaranteeEndDate) {
      this.peOverrideData.controls.rateGuaranteeEndDate.setValue(this.transformDate(this.rateGuaranteeEndDate));
    }

    this.rateGuaranteeMonths = SuppHealthUtil.calculateRateGuaranteeMonths(new Date(this.rateGuaranteeEffectiveDate), new Date(this.rateGuaranteeEndDate));
    this.peOverrideData.controls.rateGuaranteeMonths.setValue(this.rateGuaranteeMonths);
  }

  initializePEOverrideValues() {
    if (this.rareData) {
      if (!this.rareData.uwAdjustment) {
        this.rareData.uwAdjustment = {};
      }
      if (!this.rareData.uwAdjustment.peOverrideData) {
        this.rareData.uwAdjustment.peOverrideData = {};
      }

      if (!this.rareData.uwAdjustment.peOverrideData ||
          !Object.keys(this.rareData.uwAdjustment.peOverrideData).includes(CommonConstants.RATE_GUARANTEE_EFFECTIVE)) {
        if (!this.rareData.uwAdjustment.peOverrideData) {
          this.rareData.uwAdjustment.peOverrideData = {};
        }
        this.rareData.uwAdjustment.peOverrideData[CommonConstants.RATE_GUARANTEE_EFFECTIVE] =  this.rareData.suppHealth.guaranteeEffectiveDate;
        this.rareData.uwAdjustment.peOverrideData[CommonConstants.RATE_GUARANTEE_END] =  this.rareData.suppHealth.guaranteeEndDate;
        this.rareData.uwAdjustment.peOverrideData[CommonConstants.RATE_GUARANTEE_MONTHS] = this.rareData.suppHealth.rateGuaranteeMonths;
      }
    }
  }

  editRateGuaranteeEffectiveDate(e) {
    if (moment(e.target.value, 'MM-DD-YYYY', true).isValid())
      this.peOverrideData.controls.rateGuaranteeEffectiveDate.setValue(this.transformDate(e.target.value));
    else {
      this.peOverrideData.controls.rateGuaranteeEffectiveDate.setValue(null);
      this.rateGuaranteeEffectiveDate = null;
    }
  }

  editRateGuaranteeEndDate(e) {
    if (moment(e.target.value, 'MM-DD-YYYY', true).isValid())
      this.peOverrideData.controls.rateGuaranteeEndDate.setValue(this.transformDate(e.target.value));
    else {
      this.peOverrideData.controls.rateGuaranteeEndDate.setValue(null);
      this.rateGuaranteeEndDate = null
    }
  }

  updateRateGuaranteeEffectiveDate(e) {
    this.rateGuaranteeEffectiveDate = new Date(e);
    this.peOverrideData.controls.rateGuaranteeEffectiveDate.setValue(this.transformDate(this.rateGuaranteeEffectiveDate));
    const originalRateGuaranteeMonths = Number(this.rareData.suppHealth.rateGuaranteeMonths);
    let endDate: any;
    let year = this.rateGuaranteeEffectiveDate.getFullYear();
    let month = this.rateGuaranteeEffectiveDate.getMonth();
    let date = this.rateGuaranteeEffectiveDate.getDate();
    endDate = new Date(year, month + originalRateGuaranteeMonths, date - 1);
    this.rateGuaranteeEndDate = endDate;
    this.peOverrideData.controls.rateGuaranteeEndDate.setValue(this.transformDate(this.rateGuaranteeEndDate));

    this.minDate = this.rateGuaranteeEffectiveDate;
    this.reflectChanges();
  }

  updateRateGuaranteeEndDate(e) {
    this.rateGuaranteeEndDate = new Date(e);
    this.peOverrideData.controls.rateGuaranteeEndDate.setValue(this.transformDate(this.rateGuaranteeEndDate));
    this.reflectChanges();
  }

  updateRateGuaranteeMonths($event) {
    let value = ($event.target.value || $event.target.value === "0") ? $event.target.value : "";
    this.peOverrideData.controls.rateGuaranteeMonths.setValue(value);
  }

  transformDate(dateValue) {
    return this.datepipe.transform(dateValue, "yyyy-MM-dd");
  }

  isNumber(event) {
    return !(event.charCode > 31 && (event.charCode < 48 || event.charCode > 57));
  }

  clickedDatePicker(elemendId) {
    const selector = `.${elemendId} .p-inputtext`;
    let element: HTMLElement = document.querySelectorAll(selector)[0] as HTMLElement;
    element.click();
  }

  reflectChanges() {
    this.rateGuaranteeMonths = SuppHealthUtil.calculateRateGuaranteeMonths(new Date(this.rateGuaranteeEffectiveDate), new Date(this.rateGuaranteeEndDate));
    this.peOverrideData.controls.rateGuaranteeMonths.setValue(this.rateGuaranteeMonths);
    this.rareData.uwAdjustment.peOverrideData.rateGuaranteeMonths = this.rateGuaranteeMonths;

    if (this.overriddenData) {
      let peValues = this.peOverrideData.value;
      Object.keys(peValues).forEach(key => {
        this.overriddenData[key] = peValues[key];
      });

      Object.keys(this.overriddenData).forEach(key => {
        this.rareData.uwAdjustment.peOverrideData[key] = this.overriddenData[key];
      });
    }
    this.onError.emit(this.peOverrideData.status === 'INVALID' || this.peSheets.controls.proposalSheets.errors)
  }

}
