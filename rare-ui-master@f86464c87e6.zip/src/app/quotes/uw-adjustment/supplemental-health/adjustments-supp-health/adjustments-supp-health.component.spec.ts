import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustmentsSuppHealthComponent } from './adjustments-supp-health.component';

describe('AdjustmentsSuppHealthComponent', () => {
  let component: AdjustmentsSuppHealthComponent;
  let fixture: ComponentFixture<AdjustmentsSuppHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdjustmentsSuppHealthComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdjustmentsSuppHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
