import { Component, EventEmitter, Inject, Input, LOCALE_ID, OnInit, Output, SimpleChanges } from "@angular/core";
import { FormBuilder, FormGroup, FormGroupDirective } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { CommonQuoteService } from "src/app/quotes/services/common-quote.service";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import { AdjustmentSuppHealth } from "src/app/shared/models/uwAdjustmentSuppHealth";
import { CommonService, ProcessQuoteDetailsService } from "src/app/shared/services";
import { CommonUtil } from "src/app/shared/utils/common-util";
import { StringUtils } from "src/app/shared/utils/string-utils";
import { SuppHealthUtil } from "../suppHealth.util";
import { formatCurrency, formatPercent, getCurrencySymbol } from '@angular/common';
import { SuppHealthPremiumComparison } from "../../../../shared/models/suppHealthComparison";

@Component({
  selector: 'app-adjustments-supp-health',
  templateUrl: './adjustments-supp-health.component.html',
  styleUrls: ['./adjustments-supp-health.component.css'],
  standalone: false
})

export class AdjustmentsSuppHealthComponent implements OnInit {
  isRenewalQuote: any;
  opportunityType: string;
  activeTab: string = "Q";
  isChangedFlag = false;
  factorAdjArray = [];
  adjustedArr = [];
  errorMessage = CommonConstants.invalidValue;
  form: FormGroup;
  isCollapsed: boolean = false;
  adjustment_form: FormGroup<AdjustmentSuppHealth>;
  predefinedDeclineReasons: any[] = [];
  uwAdjustment = {};
  proposedPlans = [];
  oppID: any;
  transID: any;
  lob: any;
  fundingType = 'FI';
  quoteHeaderID: any;
  quoteOrigin: any;
  totalFactor: any;
  actualDeclineReason: any;
  userTypedDeclineReasons: any;
  selectedTierRatioCalculationType: string;
  showCurrentRateRow: any = false;
  showStandardRateRow: any = false;
  adjHistory = [];
  @Input() requestedTier;
  @Input() rareData;
  @Input() rareDataObj;
  @Input() isReadOnlyRole;
  @Input() status;
  @Input() disableAll;
  @Input() featuredPlans;
  @Input() currentPlans;
  @Input() uwLoaded;
  @Input() suppHealthInputTier;
  @Output() onFactorAdj = new EventEmitter<any>();
  @Output() onTotalFactorAdj = new EventEmitter<any>();
  @Input() declineResaonsFromUWAdjs: any;
  @Input() quoteDetailsObj: any;
  @Input() adjustedPlans;
  @Input() showAdjustmentHistory
  @Output() declineReaonsToBeChecked = new EventEmitter<any>();
  @Input() suppHealthPreCom: SuppHealthPremiumComparison;

  constructor(private fb: FormBuilder, private rootFormGroup: FormGroupDirective,
    private route: ActivatedRoute, private commonService: CommonService, private processQuoteService: ProcessQuoteDetailsService,
    private commonQuoteService: CommonQuoteService, @Inject(LOCALE_ID) private locale: string) {

  }
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.oppID = params[CommonConstants.OPPORTUNITY_ID];
      this.transID = params[CommonConstants.RATINGTRANS_ID];
      this.lob = params[CommonConstants.LOB];
      this.fundingType = params[CommonConstants.FUNDING_TYPE];
      this.quoteHeaderID = params[CommonConstants.QUOTEHEADER_ID];
      this.quoteOrigin = params[CommonConstants.QUOTE_ORIGIN];
    });
    this.form = this.rootFormGroup.control;
    this.form.get(CommonConstants.salesNotetoUW).disable();
    this.uwAdjustment = this.rareData;
    this.proposedPlans = this.rareData?.suppHealth?.proposedPlans;
    this.opportunityType = this.rareData.opportunityType;
    this.setFormValue();
    this.onFormValueChanges();
    this.showCurrentRateRowTable();
    let uwNotesSplit: any[] = [];

    if (this.rareData.uwAdjustment && this.rareData?.uwAdjustment?.uwNotesToSales.includes(";")) {
      uwNotesSplit = this.rareData.uwAdjustment.uwNotesToSales.split(";")
    } else {
      if (this.rareData.uwAdjustment) {
        uwNotesSplit.push(this.rareData.uwAdjustment.uwNotesToSales);
      }
    }
    if (uwNotesSplit != null && this.rareData.uwAdjustment &&
      this.rareData?.uwAdjustment?.uwNotesToSales != "") {
      var declineCheckboxes = this.predefinedDeclineReasons.filter(response => {
        return uwNotesSplit.findIndex(item => item === response) != -1
      });
      if (!declineCheckboxes) {
        this.declineReaonsToBeChecked.emit(declineCheckboxes);
      }
    }

  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.uwLoaded && !changes.uwLoaded.firstChange) {
      this.setFormValue();
      this.showCurrentRateRowTable();
    }
    if (changes.adjustedPlans && !changes.adjustedPlans.firstChange) {
      this.adjustedPlans = this.adjustedPlans;
    }
    if (changes.featuredPlans && !changes.featuredPlans.firstChange) {
      this.uwAdjustment = this.rareData;
      this.proposedPlans = this.rareData?.suppHealth?.proposedPlans;
      this.setFormValue();
      this.showCurrentRateRowTable();
    }
    if (changes.rareData && !changes.rareData.firstChange) {
      this.rareData = this.rareData;
      this.setFormValue();
      this.showCurrentRateRowTable();
    }
    if (changes.declineResaonsFromUWAdjs) {
      this.setDeclineReasonsToUWNotes(null, false);
    }
    if (this.processQuoteService.declineOptionsValues) {
      this.processQuoteService.declineOptionsValues.subscribe(value => {
        if (value != null) {
          this.processQuoteService.setDeclineOptionsChecked(value);
          this.setDeclineReasonsToUWNotes(value, true);
        }
      });
    }
    if (this.form) {
      this.form.get(CommonConstants.uwNotesToSales).valueChanges.subscribe(val => {
        this.setNonAdjustmentFields('uwNotesToSales', val);
        this.processQuoteService.declineOptionsValues.subscribe(value => {
          if (value != null) {
            this.setDeclineReasonsToUWNotes(value, true);
          }
        });
      });
    }
  }


  // Emitting the decline selected checkboxes to parent component
  emitDeclineCheckboxOptions() {
    let uwNotesSplit: any[] = [];
    let uwNotesSplitTrim: any[] = [];
    if (this.rareData?.uwAdjustment?.uwNotesToSales.includes(";")) {
      uwNotesSplit = this.rareData.uwAdjustment.uwNotesToSales.split(";");
    } else if (this.rareData?.uwAdjustment?.uwNotesToSales) {
      uwNotesSplit.push(this.rareData.uwAdjustment.uwNotesToSales);
    }
    if (uwNotesSplit.length > 0) {
      uwNotesSplit.forEach(element => {
        let newElement = element.trim();
        uwNotesSplitTrim.push(newElement);
      });
    }
    if (this.predefinedDeclineReasons.length == 0) {
      this.predefinedDeclineReasons = this.processQuoteService.declineOptionsFromBackend;
    }
    if (uwNotesSplit != null && this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.uwNotesToSales) {
      var declineCheckboxes = this.predefinedDeclineReasons.filter(response => {
        return uwNotesSplitTrim.findIndex(item => item === response) != -1
      });
      if (declineCheckboxes) {
        const uniqueDeclineChecboxes = [...new Set(declineCheckboxes)];
        this.declineReaonsToBeChecked.emit(uniqueDeclineChecboxes);
      }
    } else {
      this.declineReaonsToBeChecked.emit([]);
    }
  }

  // Setting the quote decline reasons to UW notes
  setDeclineReasonsToUWNotes(reasons, formChanges) {
    let userTypedDeclineReasonsSplit: any[] = [];
    let userSelectedDeclineReasons: any[] = [];

    if (this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.uwNotesToSales) {
      this.form.get(CommonConstants.uwNotesToSales).setValue(this.rareData.uwAdjustment.uwNotesToSales || "", { emitEvent: false });
      this.userTypedDeclineReasons = this.rareData.uwAdjustment.uwNotesToSales;
    } else if (typeof (this.form) != 'undefined') {
      this.userTypedDeclineReasons = this.form.get(CommonConstants.uwNotesToSales).value;
    }

    if (reasons != null && this.declineResaonsFromUWAdjs != null
      && reasons.length === this.declineResaonsFromUWAdjs.length) {
      userSelectedDeclineReasons = this.declineResaonsFromUWAdjs;
    } else if (this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.uwNotesToSales != null && this.rareData.uwAdjustment.uwNotesToSales != "" && formChanges) {
      userSelectedDeclineReasons = this.rareData.uwAdjustment.uwNotesToSales;
    } else {
      if (reasons && reasons.length) {
        if (typeof (localStorage.getItem("statusReasons" + "_" + this.quoteHeaderID + "_" + "Supp Health" + "_" + this.fundingType)) != 'undefined' && localStorage.getItem("statusReasons" + "_" + this.quoteHeaderID + "_" + "Supp Health" + "_" + this.fundingType) != null) {
          let declineOptionArray = localStorage.getItem("statusReasons" + "_" + this.quoteHeaderID + "_" + "Supp Health" + "_" + this.fundingType).split(";");
          reasons = declineOptionArray;
        }
      }
      userSelectedDeclineReasons = reasons;
    }
    if (!this.actualDeclineReason) {
      if (this.userTypedDeclineReasons != null && userSelectedDeclineReasons != null &&
        this.userTypedDeclineReasons.includes(";")) {
        let uwNotesSplitTrim: any[] = [];
        userTypedDeclineReasonsSplit = this.userTypedDeclineReasons.split(";");
        if (userTypedDeclineReasonsSplit.length > 0) {
          userTypedDeclineReasonsSplit.forEach(element => {
            let newElement = element.trim();
            uwNotesSplitTrim.push(newElement);
          });
        }
        if (this.predefinedDeclineReasons.length === 0) {
          this.predefinedDeclineReasons = this.processQuoteService.declineOptionsFromBackend;
        }
        if (uwNotesSplitTrim && this.predefinedDeclineReasons && this.predefinedDeclineReasons.length) {
          this.actualDeclineReason = uwNotesSplitTrim.filter(response => {
            return this.predefinedDeclineReasons.indexOf(response) == -1;
          });
        }
      } else {
        this.actualDeclineReason = this.userTypedDeclineReasons;
      }
    } else {
      this.actualDeclineReason = "";
      let uwNotesSplitTrim: any[] = [];
      if (this.userTypedDeclineReasons != null) {
        if (this.userTypedDeclineReasons.includes(";")) {
          userTypedDeclineReasonsSplit = this.userTypedDeclineReasons.split(";");
        } else {
          userTypedDeclineReasonsSplit.push(this.userTypedDeclineReasons);
        }
        if (userTypedDeclineReasonsSplit.length > 0) {
          userTypedDeclineReasonsSplit.forEach(element => {
            let newElement = element.trim();
            uwNotesSplitTrim.push(newElement);
          });
        }
        var finalArray = uwNotesSplitTrim.filter(response => {
          return this.predefinedDeclineReasons.findIndex(item => item === response) === -1
        })
        if (finalArray.length > 0) {
          finalArray.forEach(elementsArr => {
            if (this.actualDeclineReason == "") {
              this.actualDeclineReason = elementsArr;
            } else {
              this.actualDeclineReason = this.actualDeclineReason + ';' + elementsArr;
            }

          })
        }
      } else {
        this.actualDeclineReason = this.userTypedDeclineReasons;
      }
    }

    let finalUWNote;
    if (this.actualDeclineReason != null && this.actualDeclineReason.length > 0 &&
      this.actualDeclineReason.constructor === Array) {
      let actualDeclineReason;
      this.actualDeclineReason.forEach(element => {
        if (actualDeclineReason == null) {
          actualDeclineReason = element;
        } else if (!actualDeclineReason.includes(element)) {
          actualDeclineReason = actualDeclineReason + ';' + element;
        }
      });
      this.actualDeclineReason = actualDeclineReason;
    }
    if (userSelectedDeclineReasons != null && userSelectedDeclineReasons.length > 0) {
      if (userSelectedDeclineReasons.constructor === Array) {
        userSelectedDeclineReasons.forEach(element => {
          if (finalUWNote == null) {
            finalUWNote = this.actualDeclineReason && !element.includes(this.actualDeclineReason) ? this.actualDeclineReason + ';' + element : element;
            this.processQuoteService.setUwNotesToSales(finalUWNote);
            this.processQuoteService.setUserTypedDeclineReasons(this.userTypedDeclineReasons);
          } else if (!finalUWNote.includes(element)) {
            finalUWNote = finalUWNote + ';' + element;
            this.processQuoteService.setUwNotesToSales(finalUWNote);
            this.processQuoteService.setUserTypedDeclineReasons(this.userTypedDeclineReasons);
          }
        });
        if (finalUWNote != null && finalUWNote.includes(";")) {
          finalUWNote = CommonUtil.htmlEntitiesToString(finalUWNote);
          if (finalUWNote.includes("; ")) {
            finalUWNote = finalUWNote.split("; ").join(";");
          }
          finalUWNote = finalUWNote.split(";").join("; ");
          finalUWNote = CommonUtil.convertSpecialCharToASCII(finalUWNote);
        }
        this.processQuoteService.setUwNotesToSales(finalUWNote);
      }
    } else {
      finalUWNote = this.actualDeclineReason;
      if (finalUWNote != null && finalUWNote.includes(";")) {
        finalUWNote = CommonUtil.htmlEntitiesToString(finalUWNote);
        if (finalUWNote.includes("; ")) {
          finalUWNote = finalUWNote.split("; ").join(";");
        }
        finalUWNote = finalUWNote.split(";").join("; ");
        finalUWNote = CommonUtil.convertSpecialCharToASCII(finalUWNote);
      }
      this.processQuoteService.setUwNotesToSales(finalUWNote);
      this.processQuoteService.setUserTypedDeclineReasons(this.userTypedDeclineReasons);
    }
  }

  // Getting the current rates ratios and standard rates ratios
  showCurrentRateRowTable() {
    if (this.featuredPlans) {
      let currentTierRatio = this.featuredPlans[0]['factors'].tierRatioCurrentPlanId;
      if (currentTierRatio !== undefined && this.featuredPlans[0]['factors'].currentRateTierFactor[currentTierRatio].eeFactor && this.suppHealthInputTier == this.requestedTier) {
        this.showCurrentRateRow = true;
      } else {
        this.showCurrentRateRow = false;
      }
      let standardTierRatio = this.featuredPlans[0]['factors'].tierRatioStandardPlanId;
      if (standardTierRatio !== undefined && this.featuredPlans[0]['factors'].standardRateTierFactor[standardTierRatio].eeFactor) {
        this.showStandardRateRow = true;
      } else {
        this.showStandardRateRow = false;
      }
    }

  }

  // fetching the quote adjustment history
  adjustmentHistoryClicked() {
    this.commonQuoteService
      .getAdjustmentHistory(this.transID, this.oppID, this.quoteHeaderID, this.quoteOrigin, this.lob, this.fundingType)
      .subscribe(
        response => {
          if (response) {
            this.adjHistory = response;
            this.adjHistory = response.map((adjData, index) => {
              adjData['AdjNo'] = this.adjHistory.length - index;
              return adjData;
            });
          }
        }
      )
  }

  // On tier rates selection standard and current rate ratios
  onTierSelect(type: string) {
    this.selectedTierRatioCalculationType = type;
  }

  // Check if the uw entered valid number or not
  isNumber(evt) {
    return SuppHealthUtil.isNumber(evt);
  }

  isRenewalQuoteDisabled() {
    this.isRenewalQuote = this.rareData.opportunityType;
    if (StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
      this.activeTab = 'P';
      return true;
    } else {
      return false;
    }
  }

  // Fetch the plan adjustment factor for each plans. Assign 1 if the plan is new (not adjusted before)
  getUWAdjustment(plan) {
    if (this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.adjustedRates) {
      this.rareData.uwAdjustment.adjustedRates.forEach(item => {
        if (item.ratingPlanID == plan.ratingPlanID) {
          plan['uwAdjustment'] = item.uwAdjustment ? item.uwAdjustment : 1;
        }
      });
      return this.getPercentValue(plan['uwAdjustment']);
    } else {
      return this.getPercentValue(1);
    }
  }

  getUWAdjustmentFactor(plan) {
    if (this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.adjustedRates) {
      this.rareData.uwAdjustment.adjustedRates.forEach(adjustedRate => {
        if (!adjustedRate["uwAdjustmentFactor"]) {
          adjustedRate["uwAdjustmentFactor"] = adjustedRate.uwAdjustment;
        }
      })

      this.rareData.uwAdjustment.adjustedRates.forEach(item => {
        if (item.ratingPlanID == plan.ratingPlanID) {
          plan['uwAdjustmentFactor'] = item["uwAdjustmentFactor"] ? item["uwAdjustmentFactor"] : 1;
        }
      });
      return Number(plan['uwAdjustmentFactor']).toFixed(6);
    } else {
      return 1;
    }
  }

  getPercentValue(value) {
    if (!value) {
      value = 0
    } else {
      value = (value - 1) * 100
    }

    return value.toFixed(4);
  }

  onTotalFactorChange(value) {
    if (value && this.form.get('adjustedRateActionPercent').errors) {
      return;
    }

    if (!value) {
      value = 0;
    }
    const convertedValue = ((value / 100) + 1).toFixed(6);
    this.resetAllRatesEditedFlagToNo();
    this.resetFeaturedPlansToCurrentRates();
    this.rareData.suppHealth.proposedPlans.forEach(proposedPlan => {
      proposedPlan.factors['uwAdjustment'] = convertedValue;
      proposedPlan.uwDiscret = convertedValue;

      if (this.adjustedPlans.length) {
        const findIndex = this.adjustedPlans.findIndex(planObj => planObj.ratingPlanID === proposedPlan['ratingPlanID']);
        if (!this.adjustedPlans[findIndex]) {
          this.addToAdjustedPlans(proposedPlan, convertedValue);
        }
      }
    });
    this.totalFactor = ((value / 100) + 1).toFixed(6);
    this.adjustedPlans.forEach(adjustedPlan => {
      adjustedPlan.uwAdjustment = convertedValue;
      if (this.rareData.uwAdjustment && this.rareData.uwAdjustment.adjustedRates) {
        this.rareData.uwAdjustment.adjustedRates.forEach(adjustedRate => {
          adjustedRate.uwAdjustment = convertedValue;
          adjustedRate.uwAdjustmentFactor = convertedValue;
        })
      }
      if (!this.factorAdjArray.find(plan => plan === adjustedPlan.ratingPlanID)) {
        this.factorAdjArray.push(adjustedPlan.ratingPlanID);
      }
      this.updatePremiumComparison(adjustedPlan, convertedValue);
    });

    this.isChangedFlag = true;

    this.constructRequest();
    let obj = {
      'isChangedFlagFactor': this.isChangedFlag,
      'myArrFactor': this.factorAdjArray,
      'adjustedPlans': this.adjustedPlans,
      'suppHealthPremiumComparison': this.rareData.suppHealthPremiumComparison
    }
    this.onTotalFactorAdj.emit(obj);
  }

  resetFeaturedPlansToCurrentRates() {
    this.featuredPlans.forEach(featuredPlan => {
      this.resetFeaturedPlanToCurrentRates(featuredPlan);
    })
  }

  /**
   * Resets current rates to featuredPlan rateInfo or ageBandRateInfo objects
   * @param featuredPlan
   */
  resetFeaturedPlanToCurrentRates(featuredPlan) {
    if (Object.keys(featuredPlan?.ageBandRateInfo)?.length > 0) {
      featuredPlan.ageBandRateInfo = JSON.parse(JSON.stringify(featuredPlan.currentPlanRateInfo));
    } else {
      featuredPlan.rateInfo = JSON.parse(JSON.stringify(featuredPlan.currentPlanRateInfo));
    }
  }

  private resetAllRatesEditedFlagToNo() {
    this.featuredPlans.forEach(featuredPlan => featuredPlan.isProposedPlanRatesEdited = CommonConstants.NO_CHAR);
    this.featuredPlans.forEach(featuredPlan => featuredPlan.isProposedPlanRatesEdited = CommonConstants.NO_CHAR);
  }

  // Construct adjusted plans array on factor change
  onAdjChange(value, plan, isCurrentRateEdit = false) {
    if (StringUtils.isEqual(plan.isProposedPlanRatesEdited, CommonConstants.YES)) {
      plan.isProposedPlanRatesEdited = CommonConstants.NO_CHAR;
      let featuredPlan = this.featuredPlans.find(featuredPlan => StringUtils.isEqualIgnoreCase(featuredPlan.ratingPlanID, plan.ratingPlanID));
      this.resetFeaturedPlanToCurrentRates(featuredPlan);
    }
    if (!value) {
      this.rareData.suppHealth.proposedPlans.forEach(element => {
        if (element.ratingPlanID == plan.ratingPlanID) {
          element.factors['uwAdjustment'] = null;
          element.uwDiscret = null;
          if (this.adjustedPlans.length) {
            const findIndex = this.adjustedPlans.findIndex(planObj => planObj.ratingPlanID === plan['ratingPlanID']);
            this.adjustedPlans[findIndex].uwAdjustment = null;
          }
        }
      });
    } else {
      const convertedValue = ((value / 100) + 1).toFixed(6);
      this.rareData.suppHealth.proposedPlans.forEach(element => {
        if (element.ratingPlanID == plan.ratingPlanID) {
          element.factors['uwAdjustment'] = convertedValue;
          element.uwDiscret = convertedValue;
          if (this.adjustedPlans.length) {
            const findIndex = this.adjustedPlans.findIndex(planObj => planObj.ratingPlanID === plan['ratingPlanID']);
            this.adjustedPlans[findIndex].uwAdjustment = convertedValue;
            this.adjustedPlans[findIndex].rateInfo = element.rateInfo;
            this.adjustedPlans[findIndex].ageBandRateInfo = element.ageBandRateInfo;
            this.updatePremiumComparison(plan, convertedValue, isCurrentRateEdit);
          }

          this.rareData.uwAdjustment.adjustedRates.forEach(adjustedRate => {
            if (adjustedRate.ratingPlanID == plan.ratingPlanID) {
              adjustedRate.uwAdjustmentFactor = ((value / 100) + 1).toFixed(4);
            }
          })
        }
      });
    }
    this.calculateTotalFactor();
    this.isChangedFlag = true;
    if (!this.factorAdjArray.find(response => response === plan.ratingPlanID)) {
      this.factorAdjArray.push(plan.ratingPlanID);
    }
    this.constructRequest();
    let obj = {
      'isChangedFlagFactor': this.isChangedFlag,
      'myArrFactor': this.factorAdjArray,
      'adjustedPlans': this.adjustedPlans,
      'suppHealthPremiumComparison': this.rareData.suppHealthPremiumComparison,
      'ratingPlanID': plan.ratingPlanID,
      'isCurrentRateEdit': isCurrentRateEdit
    }
    this.onFactorAdj.emit(obj)
  }

  updatePremiumComparison(plan, adjustmentFactor, isCurrentRateEdit = false) {

    this.rareData.suppHealthPremiumComparison.planComparison.forEach(planComp => {
      if (adjustmentFactor && planComp.quoteRatingPlanID === plan.ratingPlanID) {
        planComp.isProposedPlanRatesEdited = CommonConstants.NO_CHAR;
        if (this.hasAgeBandQuotedRates(planComp)) {
          this.recalculateQuotedAgeBandRates(planComp, adjustmentFactor)
        } else {
          plan = this.recalculateQuotedRates(planComp, adjustmentFactor);
        }
        this.getDifferencePecentage(planComp, "Current");
      }
    })
  }

  calculateQuotedTierRates(currentRates, quotedRates, enrollments, quoteTier, adjustmentFactor) {
    let monthlyRate = 0;
    for (let i = 1; i <= quoteTier; i++) {
      quotedRates['ratesT' + i] = this.roundedValue(currentRates['ratesT' + i] * (adjustmentFactor || 0));
    }
  }

  recalculateQuotedAgeBandRates(plan, adjustmentFactor) {
    let myObject: Map<string, Object> = new Map(Object.entries(plan.ageBandCurrentRates));
    let monthlyRate = 0;
    for (let item of myObject) {
      var currentRates = item[1];
      var key = item[0];
      this.calculateQuotedTierRates(currentRates, plan.ageBandQuotedRates[key], plan.quoteEnrollments, plan.quoteTier, adjustmentFactor);

      let enr = plan.quoteEnrollments['enrollT1'] ? plan.quoteEnrollments['enrollT1'] : 0;
      monthlyRate = monthlyRate + (Math.round((plan.ageBandQuotedRates[key]['ratesT1'] + Number.EPSILON) * 100) / 100 * enr);
    }
    plan.ageBandQuotedMonthlyPremium = monthlyRate;
  }

  recalculateQuotedRates(planComparison, adjustmentFactor) {
    this.calculateQuotedTierRates(planComparison.currentRates, planComparison.quoteRates, planComparison.quoteEnrollments, planComparison.quoteTier, adjustmentFactor)
    let enr = planComparison.quoteEnrollments['enrollT1'] ? planComparison.quoteEnrollments['enrollT1'] : 0;
    planComparison.quoteRates['monthlyTotal'] = (Math.round((planComparison.quoteRates['ratesT1'] + Number.EPSILON) * 100) / 100 * enr);
    return planComparison;
  }

  roundedValue(value: number): number {
    return Math.round(value * 100) / 100;
  }

  hasAgeBandQuotedRates(plan) {
    return plan && plan.hasAgeBandQuotedRates;
  }

  getAbsoluteValue(value: number, type?: string): number | string {
    if (value && value != Infinity) {
      if (StringUtils.isEqual(type, 'percent')) {
        return formatPercent(Math.abs(value), this.locale, '1.1-1');
      }
      return formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.2-2');
    }
    return 0;
  }

  getDifferencePecentage(plan, forType: string): number {
    SuppHealthUtil.getMonthlyRate(plan, 'Current');
    SuppHealthUtil.getEnrollmentTotal(plan, 'Quote');
    SuppHealthUtil.getMonthlyRate(plan, 'Quote');
    this.getAbsoluteValue(SuppHealthUtil.getMonthlyRateDifference(plan, 'Current'));
    SuppHealthUtil.getAnnualRate(plan, 'Current');
    SuppHealthUtil.getAnnualRate(plan, 'Quote');
    this.getAbsoluteValue(SuppHealthUtil.getAnnualRateDifference(plan, 'Current'));

    if (plan.hasQuotedRates === true) {
      if (StringUtils.isEqual(forType, 'Current')) {
        plan.diffToCurrentRatePercentage = SuppHealthUtil.calculateRatePer(plan.quoteRates.yearlyTotal, plan.currentRates.yearlyTotal);
        return plan.diffToCurrentRatePercentage;
      } else {
        plan.diffToRenewalRatePercentage = SuppHealthUtil.calculateRatePer(plan.quoteRates.yearlyTotal, plan.renewalRates.yearlyTotal);
        return plan.diffToRenewalRatePercentage;
      }
    }
    if (plan.hasAgeBandQuotedRates) {
      if (StringUtils.isEqual(forType, 'Current')) {

        plan.diffToCurrentRatePercentage = SuppHealthUtil.calculateRatePer(plan.ageBandQuotedYearlyTotal, plan.ageBandCurrentYearlyTotal);
        return plan.diffToCurrentRatePercentage;
      } else {
        plan.diffToRenewalRatePercentage = SuppHealthUtil.calculateRatePer(plan.ageBandQuotedYearlyTotal, plan.renewalRates.yearlyTotal);
        return plan.diffToRenewalRatePercentage;
      }

    }
  }

  addToAdjustedPlans(plan, value) {
    const adjustedPlanFound = this.adjustedPlans.find((adjustedPlan) => adjustedPlan.ratingPlanID === plan.ratingPlanID);

    if (!adjustedPlanFound) {
      this.adjustedPlans.push({
        CDHPIndicator: '',
        empty: false,
        ratingPlanID: plan.ratingPlanID,
        planName: plan.planName,
        uwAdjustment: value,
        rateInfo: plan.rateInfo,
        ageBandRateInfo: plan.ageBandRateInfo
      })
      if (this.rareData.uwAdjustment && this.rareData.uwAdjustment.adjustedRates) {
        this.rareData.uwAdjustment.adjustedRates.push({
          ratingPlanID: plan.ratingPlanID,
          planName: plan.planName,
          uwAdjustment: value
        })
      }
    } else {
      if (!adjustedPlanFound.uwAdjustment && adjustedPlanFound.uwAdjustmentFactor) {
        adjustedPlanFound.uwAdjustment = adjustedPlanFound.uwAdjustmentFactor;
      }
    }
  }

  calculateTotalFactor() {
    let currentPlansTotal = 0;
    let adjustedPlansTotal = 0;
    this.rareData.suppHealth.currentPlans.forEach(currentPlan => {
      if (currentPlan.rateInfo.TIERED && currentPlan.rateInfo.TIERED.TOT.ACTIVE) {
        const currentRateSingle = this.getCurrentRatesSingle(currentPlan.contractCode) ?? 0;
        currentPlansTotal = currentPlansTotal + Number(currentRateSingle);
        adjustedPlansTotal = adjustedPlansTotal + Number(currentRateSingle) * Number(this.getUWAdjustmentByPlanID(currentPlan.id));
      } else if (currentPlan.rateInfo.AGETIERED && currentPlan.rateInfo.AGETIERED.TOT.ACTIVE) {
        const currentRatesAgeBanded = this.getCurrentRatesAgeBanded(currentPlan.contractCode);
        let ageTieredTotalCurrent = 0;
        let ageTieredTotalAdjusted = 0;
        for (const key in currentRatesAgeBanded) {
          ageTieredTotalCurrent = ageTieredTotalCurrent + Number(currentRatesAgeBanded[key].single ?? currentRatesAgeBanded[key].ratesT1 ?? 0);
          ageTieredTotalAdjusted = ageTieredTotalAdjusted + Number(currentRatesAgeBanded[key].single ?? currentRatesAgeBanded[key].ratesT1 ?? 0) * Number(this.getUWAdjustmentByPlanID(currentPlan.id));
        }
        currentPlansTotal = currentPlansTotal + ageTieredTotalCurrent;
        adjustedPlansTotal = adjustedPlansTotal + ageTieredTotalAdjusted;
      }
    });
    const totalFactorPercentage = ((adjustedPlansTotal / currentPlansTotal) - 1) * 100;
    this.form.get(CommonConstants.adjustedRateActionPercent).setValue(totalFactorPercentage.toFixed(4));
    this.totalFactor = Number((totalFactorPercentage / 100) + 1).toFixed(6);
  }

  getCurrentRatesSingle(contractCode: string): number {
    const proposedPlan = this.rareData.suppHealth.proposedPlans.find(proposedPlan => proposedPlan.contractCode === contractCode);
    const mcpPlan = this.suppHealthPreCom?.planComparison.find(mcp => mcp.quoteRatingPlanID === proposedPlan.ratingPlanID);

    if (mcpPlan && StringUtils.isEqualIgnoreCase(mcpPlan.isCurrentPlanRatesEdited, CommonConstants.YES)) {
      return mcpPlan?.currentRates.ratesT1;
    }
    return proposedPlan.currentPlanRateInfo.single;
  }

  getCurrentRatesAgeBanded(contractCode: string) {
    const proposedPlan = this.rareData.suppHealth.proposedPlans.find(proposedPlan => proposedPlan.contractCode === contractCode);
    const mcpPlan = this.suppHealthPreCom?.planComparison.find(mcp => mcp.quoteRatingPlanID === proposedPlan.ratingPlanID);

    if (mcpPlan && StringUtils.isEqualIgnoreCase(mcpPlan.isCurrentPlanRatesEdited, CommonConstants.YES)) {
      return mcpPlan?.ageBandCurrentRates;
    }

    return proposedPlan.currentPlanRateInfo;
  }

  getUWAdjustmentByPlanID(currPlanId) {
    if (this.adjustedPlans.length) {
      let ratingPlanID;
      this.featuredPlans?.forEach(featurePlan => {
        if (featurePlan.currPlanId && featurePlan.currPlanId.length > 0 && featurePlan.currPlanId[0] === currPlanId) {
          ratingPlanID = featurePlan.ratingPlanID;
        }
      })
      const findIndex = ratingPlanID ? this.adjustedPlans.findIndex(obj => obj.ratingPlanID === ratingPlanID) : -1;
      if (findIndex === -1) {
        return 1;
      }
      if (!StringUtils.isEmpty(this.adjustedPlans[findIndex].uwAdjustment)) {
        return this.adjustedPlans[findIndex].uwAdjustment;
      }
      else {
        return this.getUWAdjustmentAdjFactor(this.adjustedPlans[findIndex]);

      }
    } else {
      return 1;
    }
  }
  getUWAdjustmentAdjFactor(plan: any) {
    let uwAdjustmentFactor = 1;
    if (!this.rareData.suppHealth.inRateGuarantee) {
      plan.factors.lstShpAdjFctr.forEach(factor => {
        if (plan.planName.toUpperCase().includes(factor.prodNm.toUpperCase())) {
          uwAdjustmentFactor = factor.adjFctr;
        }
      });
    }
    return uwAdjustmentFactor;
  }
  // Constructing the requested object on click of save/release
  constructRequest() {
    this.adjustedArr = [];
    for (let i = 0; i < this.featuredPlans.length; i++) {
      if (this.factorAdjArray.find(response => response === this.rareData.suppHealth.proposedPlans[i]['ratingPlanID'])) {
        let adjustedObj = {
          "planName": this.rareData.suppHealth.proposedPlans[i].planName,
          "ratingPlanID": this.rareData.suppHealth.proposedPlans[i]['ratingPlanID'],
          "single": this.rareData.suppHealth.proposedPlans[i]['rateInfo'].single,
          "eeSpouse": this.rareData.suppHealth.proposedPlans[i]['rateInfo'].eeSpouse,
          "eeChild": this.rareData.suppHealth.proposedPlans[i]['rateInfo'].eeChild,
          "eeChildren": this.rareData.suppHealth.proposedPlans[i]['rateInfo'].eeChildren,
          "eeOne": this.rareData.suppHealth.proposedPlans[i]['rateInfo'].eeOne,
          "family": this.rareData.suppHealth.proposedPlans[i]['rateInfo'].family,
          "uwAdjustment": this.rareData.suppHealth.proposedPlans[i].factors.uwAdjustment
        }
        this.adjustedArr.push(adjustedObj);
      }
    }
    return this.adjustedArr;
  }

  // Check if uw entered a valid number (factor)
  checkIfNull(plan) {
    return SuppHealthUtil.checkIfNull(plan)
  }

  onUwNoteToSalesEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.form.get(CommonConstants.uwNotesToSales).setValue(ASCII || "", { emitEvent: false });
    }
    else {
      this.form.get(CommonConstants.uwNotesToSales).setValue("", { emitEvent: false });
    }
  }

  onUwNoteToSelfEvent(event) {
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.form.get(CommonConstants.uwComments).setValue(ASCII || "", { emitEvent: false });
    }
    else {
      this.form.get(CommonConstants.uwComments).setValue("", { emitEvent: false });
    }
  }

  // setting the active tab plan adjustment and quote adjustment
  setActiveTab(type: string) {
    this.activeTab = type;
  }

  calculatedFloatValue(factor: any): any {
    return SuppHealthUtil.calculatedFloatValue(factor);
  }

  // Getting the tier factor value, standard tier rates and current tier rates
  getTierFactorValue(type: string, factor: string): number | string {
    let floatValue = 0;
    let currentRateTierFactor = this.featuredPlans[0]['factors'].currentRateTierFactor;
    let standardRateTierFactor = this.featuredPlans[0]['factors'].standardRateTierFactor;
    let standardTierRatio = this.featuredPlans[0]['factors'].tierRatioStandardPlanId;
    let currentTierRatio = this.featuredPlans[0]['factors'].tierRatioCurrentPlanId ? this.featuredPlans[0]['factors'].tierRatioCurrentPlanId : '';
    switch (type) {
      case "standard":
        floatValue = this.calculatedFloatValue(standardRateTierFactor[standardTierRatio][factor]);
        break;
      case "current":
        floatValue = this.calculatedFloatValue(currentRateTierFactor[currentTierRatio][factor]);
        break;
    }
    return floatValue ? floatValue.toFixed(3) : "";
  }

  setFormValue() {
    if (this.featuredPlans) {
      let declineReasons;
      let statusReasons;
      if (this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.statusReasons && this.rareData.uwAdjustment.statusReasons.length > 0) {
        declineReasons = this.rareData.uwAdjustment.statusReasons;
        this.rareData.uwAdjustment.statusReasons.forEach(element => {
          if (statusReasons == null) {
            statusReasons = element;
          } else {
            if (!statusReasons.includes(element)) {
              statusReasons = statusReasons != "" && !element.includes(statusReasons) ? statusReasons + ';' + element : element;
            }
          }
        });
        localStorage.setItem("statusReasons" + "_" + this.quoteHeaderID + "_" + "Supp Health" + "_" + this.fundingType, statusReasons);
      }
      this.setDeclineReasonsToUWNotes(declineReasons, false);
      if (this.processQuoteService.uwNotesToSales != "" && this.actualDeclineReason && this.rareData && this.rareData.uwAdjustment &&
        this.rareData.uwAdjustment.uwNotesToSales) {
        this.rareData.uwAdjustment.uwNotesToSales = this.processQuoteService.uwNotesToSales;
      }
      if (this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.uwNotesToSales && this.rareData.uwAdjustment.uwNotesToSales != "") {
        this.form.get(CommonConstants.uwNotesToSales).setValue(this.rareData.uwAdjustment.uwNotesToSales || "", { emitEvent: false });
        this.userTypedDeclineReasons = this.rareData.uwAdjustment.uwNotesToSales;
        this.processQuoteService.setUwNotesToSales(this.rareData.uwAdjustment.uwNotesToSales);
        this.emitDeclineCheckboxOptions();
      }
      if (this.rareData && this.rareData.uwAdjustment && this.rareData.uwAdjustment.uwComments) {
        this.form.get(CommonConstants.uwComments).setValue(this.rareData[CommonConstants.uwAdjustment][CommonConstants.uwComments] || "", { emitEvent: false });
      }
      this.form.get(CommonConstants.salesNotetoUW).setValue(this.rareData['suppHealth'][CommonConstants.salesNotetoUW] || "", { emitEvent: false });
      this.selectedTierRatioCalculationType = (this.featuredPlans[0].factors.tierRatioCalculationType) ||
        "Standard";
      this.initiateAdjustmentAndFactorData();
    }
  }

  initiateAdjustmentAndFactorData() {
    this.rareData.suppHealth.proposedPlans?.forEach(proposedPlan => {
      this.addToAdjustedPlans(proposedPlan, 1);
    })
    this.calculateTotalFactor();
  }

  // on changing the form values like uw notes to sales and uw comments
  onFormValueChanges() {
    this.form.get(CommonConstants.uwNotesToSales).valueChanges.subscribe(val => {
      this.setNonAdjustmentFields('uwNotesToSales', val);
      this.processQuoteService.declineOptionsValues.subscribe(value => {
        if (value != null) {
          this.setDeclineReasonsToUWNotes(value, true);
        }
      });
    });
    this.form.get(CommonConstants.uwComments).valueChanges.subscribe(val => { this.setNonAdjustmentFields(CommonConstants.uwComments, val) });
  }
  // setting non-adjustment fields
  setNonAdjustmentFields(key: string, val: any) {
    this.rareData.uwAdjustment[key] = val;
    this.userTypedDeclineReasons = val;
    this.processQuoteService.setUwNotesToSales(val);
  }

}
