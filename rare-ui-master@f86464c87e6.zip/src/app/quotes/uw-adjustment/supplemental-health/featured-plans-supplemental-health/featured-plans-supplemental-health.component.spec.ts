import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeaturedPlansSupplementalHealthComponent } from './featured-plans-supplemental-health.component';

describe('FeaturedPlansSupplementalHealthComponent', () => {
  let component: FeaturedPlansSupplementalHealthComponent;
  let fixture: ComponentFixture<FeaturedPlansSupplementalHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeaturedPlansSupplementalHealthComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FeaturedPlansSupplementalHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
