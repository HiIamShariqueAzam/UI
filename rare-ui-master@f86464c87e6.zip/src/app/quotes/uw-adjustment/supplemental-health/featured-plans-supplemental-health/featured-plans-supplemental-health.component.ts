import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { StringUtils } from "../../../../shared/utils/string-utils";
import { SuppHealthUtil } from "../../supplemental-health/suppHealth.util";
import { CommonConstants } from "../../../../shared/constants/common.constants";
import { RateInfo } from "../../../../shared/models";
import { SuppHealthPremiumComparison } from 'src/app/shared/models/suppHealthComparison';

@Component({
  selector: 'app-featured-plans-supplemental-health',
  templateUrl: './featured-plans-supplemental-health.component.html',
  styleUrls: ['./featured-plans-supplemental-health.component.css'],
  standalone: false,
})
export class FeaturedPlansSupplementalHealthComponent implements OnInit, OnChanges {

  @Input() featuredPlans: any[];
  @Input() status;
  @Input() boundariesObjName;
  @Input() quotelevelFailData;
  @Input() guardrailBoundariesToQuoteDetails;
  @Input() reqTier;
  @Input() EE;
  @Input() EF;
  @Input() ES;
  @Input() E1;
  @Input() EK;
  @Input() EC;
  @Input() isReadOnlyRole;
  @Input() rareData;
  @Input() rareDataObj;
  @Input() isFactorChanged;
  @Input() adjustedPlans;
  @Input() suppHealthPreCom: SuppHealthPremiumComparison;
  @Input() adjustedRates;
  @Input() adjustedAgeBandRates;
  @Output() onFeaturedPlanRateChange = new EventEmitter<any>()

  factorEffectiveDate: any;
  benefitsColSpanF: any;
  expandClicked: boolean = true;
  planColumnsF: any;
  rateColumns: any[];
  planColumnsAfter = [
    { header: CommonConstants.contractCode },
    { header: CommonConstants.planName },
    { header: CommonConstants.genAgentCommission },
    { header: CommonConstants.association },
    { header: CommonConstants.adjustmentType },
    { header: CommonConstants.salesAdjustment },
    { header: CommonConstants.applyCurrentRatio },
    { header: CommonConstants.planType }
  ];
  planColumnsRenewal = [
    { header: CommonConstants.contractCode },
    { header: CommonConstants.planName },
    { header: CommonConstants.genAgentCommission },
    { header: CommonConstants.planType }
  ];
  fiveTierColumns = [
    { header: CommonConstants.employee },
    { header: CommonConstants.employee + ' +' + CommonConstants.spouse },
    { header: CommonConstants.employee + ' +' + CommonConstants.child },
    { header: CommonConstants.employee + ' +' + CommonConstants.children },
    { header: CommonConstants.employee + ' +' + CommonConstants.family },
  ];
  fourTierColumns = [
    { header: CommonConstants.employee },
    { header: CommonConstants.employee + ' +' + CommonConstants.spouse },
    { header: CommonConstants.employee + ' +' + CommonConstants.children },
    { header: CommonConstants.employee + ' +' + CommonConstants.family },
  ];
  threeTierColumns = [
    { header: CommonConstants.employee },
    { header: CommonConstants.employeePlusOne },
    { header: CommonConstants.employee + ' +' + CommonConstants.family },
  ];
  twoTierColumns = [
    { header: CommonConstants.employee },
    { header: CommonConstants.employee + ' +' + CommonConstants.family },
  ];
  oneTierColumns = [
    { header: CommonConstants.employee },
  ];

  // Left side columns for Supplemental Health
  supplementalHealthColumns = [
    { header: CommonConstants.contractCode },
    { header: CommonConstants.productName },
    { header: CommonConstants.ageBand }
  ];

  opportunityType: string;
  marketSegment: string;
  columnSpan: number;
  planColumnsFSG: any;
  isRenewalQuote: any;
  viewCalcPlan: any;
  isChangedFlag = false;
  factorAdjArray = [];
  adjustedArr = [];

  constructor() { }

  ngOnInit(): void {
    //columns before
    this.columnSpan = 3;
    //columns after
    this.benefitsColSpanF = 1;
    this.opportunityType = CommonConstants.RENEWAL_LOCAL;
    this.setDynamicTier(Number(this.reqTier));
  }

  ngOnChanges(changes: SimpleChanges) {
    this.setDynamicTier(Number(this.reqTier));
  }

  isAgeBandPlan(plan: any) {
    const ageBandRateInfo = plan.ageBandRateInfo;
    return Object.keys(ageBandRateInfo).length > 0 && ageBandRateInfo.constructor === Object;
  }
  showBenefits() {
    // TODO implement rules
    return false;
  }

  benefitsExpand() {

  }

  /**
   * Allow to edit certain table fields
   */
  isEditable() {
    // condition
    return this.status === 'Failed' || this.isReadOnlyRole || this.disableInputIfQuoteIsRenewal()
  }

  // check if the quote is renewal
  disableInputIfQuoteIsRenewal() {
    return StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)
  }

  // Check if the calc popup to be disabled or not
  isCalcPopudDisabled() {
    if (StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
      return true;
    } else if (StringUtils.isEqual(this.opportunityType, CommonConstants.NEW_BUSINESS_LOCAL) && StringUtils.isEqual(this.marketSegment, CommonConstants.smallGroup)) {
      return true;
    } else {
      return false;
    }
  }

  // Assigning a plan object on click of view calc
  createViewCalcPopup(suppHealthPlan) {
    this.viewCalcPlan = {}
    this.viewCalcPlan = suppHealthPlan;
  }

  setDynamicTier(tierValue) {
    let tierColumns;

    switch (tierValue) {
      case 1:
        tierColumns = this.oneTierColumns;
        break;
      case 2:
        tierColumns = this.twoTierColumns;
        break;
      case 3:
        tierColumns = this.threeTierColumns;
        break;
      case 4:
        tierColumns = this.fourTierColumns;
        break;
      case 5:
        tierColumns = this.fiveTierColumns;
        break;
      default:
        break;
    }
    if (tierColumns) {
      this.rateColumns = [...this.supplementalHealthColumns, ...tierColumns];
    }
  }
  isNumber(evt) {
    return SuppHealthUtil.isNumber(evt);
  }
  // Calculate and get the tier rates
  getTierRates(suppHealthPlan, tierVal, ageBand) {
    let outputTier = this.rareData['suppHealthOutputTier'];
    if (this.disableInputIfQuoteIsRenewal() && this.isFactorChanged) {
      let rateInfo = new RateInfo;
      this.rareData.suppHealth.proposedPlans.forEach(item => {
        if (item.ratingPlanID == suppHealthPlan.ratingPlanID) {
          if (StringUtils.isEqual(suppHealthPlan.isProposedPlanRatesEdited, CommonConstants.NO_CHAR)) {
            const comparisonPlan = this.suppHealthPreCom.planComparison.find(plan => StringUtils.isEqualIgnoreCase(plan.quoteRatingPlanID, suppHealthPlan.ratingPlanID));
            switch (outputTier) {
              case "1":
                if (ageBand) {
                  rateInfo.single = comparisonPlan.ageBandCurrentRates[ageBand].ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                } else {
                  rateInfo.single = comparisonPlan.currentRates.ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                }
                break;
              case "2":
                if (ageBand) {
                  rateInfo.single = comparisonPlan.ageBandCurrentRates[ageBand].ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.ageBandCurrentRates[ageBand].ratesT2 * this.isAdjustedPlansAvailable(suppHealthPlan);
                } else {
                  rateInfo.single = comparisonPlan.currentRates.ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.currentRates.ratesT2  * this.isAdjustedPlansAvailable(suppHealthPlan);
                }
                break;
              case "3":
                if (ageBand) {
                  rateInfo.single = comparisonPlan.ageBandCurrentRates[ageBand].ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeOne = comparisonPlan.ageBandCurrentRates[ageBand].ratesT2 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.ageBandCurrentRates[ageBand].ratesT3 * this.isAdjustedPlansAvailable(suppHealthPlan);
                } else {
                  rateInfo.single = comparisonPlan.currentRates.ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeOne = comparisonPlan.currentRates.ratesT2 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.currentRates.ratesT3 * this.isAdjustedPlansAvailable(suppHealthPlan);
                }
                break;
              case "4":
                if (ageBand) {
                  rateInfo.single = comparisonPlan.ageBandCurrentRates[ageBand].ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeSpouse = comparisonPlan.ageBandCurrentRates[ageBand].ratesT2 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeChildren = comparisonPlan.ageBandCurrentRates[ageBand].ratesT3 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.ageBandCurrentRates[ageBand].ratesT4 * this.isAdjustedPlansAvailable(suppHealthPlan);
                } else {
                  rateInfo.single = comparisonPlan.currentRates.ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeSpouse = comparisonPlan.currentRates.ratesT2 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeChildren = comparisonPlan.currentRates.ratesT3 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.currentRates.ratesT4 * this.isAdjustedPlansAvailable(suppHealthPlan);
                }
                break;
              case "5":
                if (ageBand) {
                  rateInfo.single = comparisonPlan.ageBandCurrentRates[ageBand].ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeSpouse = comparisonPlan.ageBandCurrentRates[ageBand].ratesT2 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeChild = comparisonPlan.ageBandCurrentRates[ageBand].ratesT3 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeChildren = comparisonPlan.ageBandCurrentRates[ageBand].ratesT4 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.ageBandCurrentRates[ageBand].ratesT5 * this.isAdjustedPlansAvailable(suppHealthPlan);
                } else {
                  rateInfo.single = comparisonPlan.currentRates.ratesT1 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeSpouse = comparisonPlan.currentRates.ratesT2 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeChild = comparisonPlan.currentRates.ratesT3 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.eeChildren = comparisonPlan.currentRates.ratesT4 * this.isAdjustedPlansAvailable(suppHealthPlan);
                  rateInfo.family = comparisonPlan.currentRates.ratesT5 * this.isAdjustedPlansAvailable(suppHealthPlan);
                }
                break;
            }
          } else  {
            if (ageBand) {
              rateInfo.single = suppHealthPlan.ageBandRateInfo[ageBand].single;
              rateInfo.eeSpouse = suppHealthPlan.ageBandRateInfo[ageBand].eeSpouse;
              rateInfo.eeChild = suppHealthPlan.ageBandRateInfo[ageBand].eeChild;
              rateInfo.eeChildren = suppHealthPlan.ageBandRateInfo[ageBand].eeChildren;
              rateInfo.family = suppHealthPlan.ageBandRateInfo[ageBand].family;
            } else {
              rateInfo.single = suppHealthPlan.rateInfo.single;
              rateInfo.eeSpouse = suppHealthPlan.rateInfo.eeSpouse;
              rateInfo.eeChild = suppHealthPlan.rateInfo.eeChild;
              rateInfo.eeChildren = suppHealthPlan.rateInfo.eeChildren;
              rateInfo.family = suppHealthPlan.rateInfo.family;
            }
          }
        }
      });
      return this.roundSixDecimals(rateInfo[tierVal]);
    } else {
      if (ageBand) {
        return this.roundSixDecimals(suppHealthPlan.ageBandRateInfo[ageBand][tierVal]);
      } else {
        return this.roundSixDecimals(suppHealthPlan.rateInfo[tierVal]);
      }
    }
  }

  // Check if the adjusted plan is available in the adjusted plans array and return the adjusted factor
  // Return one if the adjusted factor is invalid or not found
  isAdjustedPlansAvailable(suppHealthPlan) {
    if (this.adjustedPlans.length) {
      const findIndex = this.adjustedPlans.findIndex(obj => obj.ratingPlanID === suppHealthPlan.ratingPlanID);
      return this.adjustedPlans[findIndex].uwAdjustment == null || this.adjustedPlans[findIndex].uwAdjustment == undefined ?
        this.getUwAdjustmentFactor(this.adjustedPlans[findIndex]) : this.adjustedPlans[findIndex].uwAdjustment;

    } else {
      return (suppHealthPlan.uwDiscret || 1)
    }
  }

  getUwAdjustmentFactor(plan: any) {
    let adjustmentFactor = 1;
    if (plan.uwAdjustmentFactor) {
      adjustmentFactor = plan.uwAdjustmentFactor
    }
    else if (!this.rareData.suppHealth.inRateGuarantee &&
      plan.factors && plan.factors.lstShpAdjFctr.length > 0) {
      plan.factors.lstShpAdjFctr.forEach(factor => {
        if (plan.planName.toUpperCase().includes(factor.prodNm.toUpperCase())) {
          adjustmentFactor = factor.adjFctr;
        }
      });

    }
    return adjustmentFactor;
  }

  /**
   * As ageBand column is always present for Supp Health
   * this calculates tier size + 1
   */
  getRatesColSpan() {
    const ageBandColSpan = 1;
    return this.reqTier + ageBandColSpan;
  }

  roundSixDecimals(value) {
    if (value === 0 || isNaN(value)) {
      return 0;
    }
    if (value) {
      return Math.round(value * 1000000) / 1000000
    }
  }


  /**
   * Checks if multiRate field in the plan is equal to 'Y'
   * @param suppHealthPlan
   */
  isMultiRate(suppHealthPlan) {
    return StringUtils.isEqual(suppHealthPlan?.multiRate, CommonConstants.YES);
  }

  overrideTierRate($event, suppHealthPlan, tierVal, ageBand) {
    this.refreshSuppHealthPlanData(suppHealthPlan, ageBand);
    const stringValue = $event.target.value?.replace(/[^0-9.]/g, '');
    const value = Number(stringValue);
    if (ageBand) {
      suppHealthPlan.ageBandRateInfo[ageBand][tierVal] = value;
    } else {
      suppHealthPlan.rateInfo[tierVal] = value;
    }
    suppHealthPlan.wasProposedPlanRatesEdited = true;
    suppHealthPlan.isProposedPlanRatesEdited = CommonConstants.YES;
    this.updatePremiumComparison(value, suppHealthPlan, tierVal, ageBand);
    this.updateAdjustedRatesSet(suppHealthPlan, ageBand);
  }

  private refreshSuppHealthPlanData(suppHealthPlan, ageBand) {
    const stringOutputTier = this.rareData['suppHealthOutputTier'];
    const outputTier = Number(stringOutputTier);

    let planComparison: any
      = this.suppHealthPreCom?.planComparison.find(comparison => StringUtils.isEqualIgnoreCase(comparison.quoteRatingPlanID, suppHealthPlan.ratingPlanID));

    if (ageBand) {
      const planComparisonQuoteRates = planComparison.ageBandQuotedRates;
      Object.keys(planComparison.ageBandQuotedRates).forEach(key => {
        let planComparisonAgeBandQuoteRates = planComparisonQuoteRates[key];
        let suppHealthPlanAgeBandRateInfo = suppHealthPlan.ageBandRateInfo[key];

        suppHealthPlanAgeBandRateInfo.single = planComparisonAgeBandQuoteRates.ratesT1;
        if (outputTier === 4 || outputTier === 5) {
          suppHealthPlanAgeBandRateInfo.eeSpouse = planComparisonAgeBandQuoteRates.ratesT2;
        }
        if (outputTier === 4) {
          suppHealthPlanAgeBandRateInfo.eeChildren = planComparisonAgeBandQuoteRates.ratesT3;
        }
        if (outputTier === 5) {
          suppHealthPlanAgeBandRateInfo.eeChild = planComparisonAgeBandQuoteRates.ratesT3;
          suppHealthPlanAgeBandRateInfo.eeChildren = planComparisonAgeBandQuoteRates.ratesT4;
        }
        this.setRateForFamilyFromComparisonRates(outputTier, suppHealthPlanAgeBandRateInfo, planComparisonAgeBandQuoteRates)
      });
    } else {
      const planComparisonQuoteRates = planComparison.quoteRates;
      const suppHealthPlanRateInfo = suppHealthPlan.rateInfo;

      suppHealthPlanRateInfo.single = planComparisonQuoteRates.ratesT1;
      if (outputTier === 4 || outputTier === 5) {
        suppHealthPlanRateInfo.eeSpouse = planComparisonQuoteRates.ratesT2;
      }
      if (outputTier === 4) {
        suppHealthPlanRateInfo.eeChildren = planComparisonQuoteRates.ratesT3;
      }
      if (outputTier === 5) {
        suppHealthPlanRateInfo.eeChild = planComparisonQuoteRates.ratesT3;
        suppHealthPlanRateInfo.eeChildren = planComparisonQuoteRates.ratesT4;
      }
      this.setRateForFamilyFromComparisonRates(outputTier, suppHealthPlanRateInfo, planComparisonQuoteRates)
    }
  }

  /**
   * Function for handling adjustedRates and adjustedAgeBandRates sets
   * @param suppHealthPlan
   * @param ageBand
   */
  updateAdjustedRatesSet(suppHealthPlan, ageBand) {
    const planInfo = ageBand ? suppHealthPlan.ageBandRateInfo : suppHealthPlan.rateInfo;
    const adjustedRatesArray = ageBand ? this.adjustedAgeBandRates : this.adjustedRates;

    this.addOrUpdateAdjustedRateSet(suppHealthPlan, planInfo, adjustedRatesArray, ageBand);
  }

  addOrUpdateAdjustedRateSet(suppHealthPlan, planInfo, adjustedRatesArray, ageBand) {
    let index = adjustedRatesArray.findIndex(item => item.ratingPlanID === suppHealthPlan.ratingPlanID);

    if (ageBand) {
      const currentRate = {
        ...planInfo[ageBand],
        ageBand: `${planInfo[ageBand].ageBandStart}-${planInfo[ageBand].ageBandEnd}`
      };

      if (index === -1) {  // ratingPlanID doesn't exist
        adjustedRatesArray.push({
          planName: suppHealthPlan.planName,
          ratingPlanID: suppHealthPlan.ratingPlanID,
          ageBandRates: [currentRate]
        });
      } else {  // ratingPlanID does exist
        const ageBandIndex = adjustedRatesArray[index].ageBandRates.findIndex(item => item.ageBandStart === currentRate.ageBandStart);

        if (ageBandIndex !== -1) {  // ageBandStart exists
          adjustedRatesArray[index].ageBandRates[ageBandIndex] = currentRate;  // Replace the object
        } else {  // ageBandStart doesn't exist
          adjustedRatesArray[index].ageBandRates.push(currentRate);  // Append object to ageBandRates
        }
      }
    } else {
      if (index === -1) {  // ratingPlanID doesn't exist
        adjustedRatesArray.push({
          planName: suppHealthPlan.planName,
          ratingPlanID: suppHealthPlan.ratingPlanID,
          ...planInfo
        });
      } else {  // ratingPlanID exists
        // Maintain the existing ageBandRates array and update the rest of the properties
        adjustedRatesArray[index] = {
          ...adjustedRatesArray[index],
          planName: suppHealthPlan.planName,
          ...planInfo
        };
      }
    }
  }

  updatePremiumComparison(value, suppHealthPlan, tierVal, ageBand) {
    const stringOutputTier = this.rareData['suppHealthOutputTier'];
    const outputTier = Number(stringOutputTier);
    this.suppHealthPreCom?.planComparison.forEach((planComparison: any) => {
      if (StringUtils.isEqual(planComparison.quoteRatingPlanID, suppHealthPlan.ratingPlanID)) {
        planComparison.wasProposedPlanRatesEdited = true;
        planComparison.isProposedPlanRatesEdited = CommonConstants.YES;
        let planRates;
        if (ageBand) {
          planRates = planComparison.ageBandQuotedRates[ageBand];
        } else {
          planRates = planComparison.quoteRates;
        }
        switch (tierVal) {
          case CommonConstants.SINGLE:
            planRates.ratesT1 = value;
            break;
          case CommonConstants.EE_SPOUSE:
            if (outputTier === 4 || outputTier === 5) {
              planRates.ratesT2 = value;
            }
            break;
          case CommonConstants.EE_ONE:
            planRates.ratesT2 = value;
            break;
          case CommonConstants.EE_CHILD:
            planRates.ratesT3 = value;
            break;
          case CommonConstants.EE_CHILDREN:
            if (outputTier === 4) {
              planRates.ratesT3 = value;
            }
            if (outputTier === 5) {
              planRates.ratesT4 = value;
            }
            break;
          case CommonConstants.FAMILY:
            this.setRateForFamilyTier(outputTier, planRates, value);
            break;
        }
      }
    })
  }

  setRateForFamilyTier(outputTier, planRates, value) {
    switch (outputTier) {
      case 2:
        planRates.ratesT2 = value;
        break;
      case 3:
        planRates.ratesT3 = value;
        break;
      case 4:
        planRates.ratesT4 = value;
        break;
      case 5:
        planRates.ratesT5 = value;
        break;
    }
  }

  setRateForFamilyFromComparisonRates(outputTier, rates, planComparisonQuoteRates) {
    switch (outputTier) {
      case 2:
        rates.family = planComparisonQuoteRates.ratesT2;
        break;
      case 3:
        rates.family = planComparisonQuoteRates.ratesT3;
        break;
      case 4:
        rates.family = planComparisonQuoteRates.ratesT4;
        break;
      case 5:
        rates.family = planComparisonQuoteRates.ratesT5;
        break;
    }
  }


  isCurrency(event) {
    let element = event.target;
    let charCode = event.charCode;
    let number = element.value.split(".");
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (number.length > 1 && charCode == 46) {
      return false;
    }
    let caratPos = this.getSelectionStart(element);
    let dotPos = element.value.indexOf(".");
    return !(caratPos > dotPos && dotPos > -1 && number[1].length > 1);
  }

  getSelectionStart(selection) {
    return selection.selectionStart;
  }

  protected readonly CommonConstants = CommonConstants;
}
