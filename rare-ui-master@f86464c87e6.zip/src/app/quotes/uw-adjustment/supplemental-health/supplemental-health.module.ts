import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { SupplementalHealthComponent } from "./supplemental-health.component";
import { MultiSelectModule } from "primeng/multiselect";
import { RouterModule } from "@angular/router";
import { FlexLayoutModule, FlexModule } from "@ngbracket/ngx-layout";
import { PaginatorModule } from "primeng/paginator";
import { TableModule } from "primeng/table";
import { ButtonModule } from "primeng/button";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RadioButtonModule } from "primeng/radiobutton";
import { ToastModule } from "primeng/toast";
import { SharedModule } from 'src/app/shared/shared.module';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ProgressSpinnerModule } from "primeng/progressspinner";
import { QuoteDetailsSupplementalHealthComponent } from './quote-details-supplemental-health/quote-details-supplemental-health.component';
import { TooltipModule } from "primeng/tooltip";
import { FeaturedPlansSupplementalHealthComponent } from './featured-plans-supplemental-health/featured-plans-supplemental-health.component';
import { AdjustmentsSuppHealthComponent } from './adjustments-supp-health/adjustments-supp-health.component';
import { AdjustmentHistoryComponent } from './adjustment-history/adjustment-history.component';
import { SuppHealthRateComparisonComponent } from './supp-health-rate-comparison/supp-health-rate-comparison.component';
import { OpportunitiesHistoryComponent } from './opportunities-history/opportunities-history.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import { DeclineQuoteModule } from '../common/decline-quote/decline-quote.module';
import { OpportunitiesHistorySuppHealthComponent } from './opportunities-history-supp-health/opportunities-history-supp-health.component';
import { ExhibitOverridesComponent } from './exhibit-overrides/exhibit-overrides.component';
import { DatePickerModule } from 'primeng/datepicker';


@NgModule({
  declarations: [SupplementalHealthComponent, QuoteDetailsSupplementalHealthComponent, AdjustmentsSuppHealthComponent, AdjustmentHistoryComponent, SuppHealthRateComparisonComponent, FeaturedPlansSupplementalHealthComponent, OpportunitiesHistoryComponent, OpportunitiesHistorySuppHealthComponent, ExhibitOverridesComponent],
  imports: [
    CommonModule,
    TableModule,
    ButtonModule,
    ReactiveFormsModule,
    RadioButtonModule,
    FlexLayoutModule,
    FormsModule,
    ToastModule,
    NgbModule,
    SharedModule,
    ProgressSpinnerModule,
    MultiSelectModule,
    DeclineQuoteModule,
    FlexModule,
    DatePickerModule,
    PaginatorModule,
    RouterModule.forChild([
      { path: 'longterm', component: SupplementalHealthComponent, pathMatch: 'full' },
      { path: '', redirectTo: 'longterm', pathMatch: 'full' },
    ]),
    TooltipModule,
  ],
  bootstrap: [SupplementalHealthComponent],
  providers: [DatePipe, ConfirmationService, MessageService],
  exports: [
    SupplementalHealthComponent,
    QuoteDetailsSupplementalHealthComponent
  ]
})
export class SupplementalHealthModule {

}
