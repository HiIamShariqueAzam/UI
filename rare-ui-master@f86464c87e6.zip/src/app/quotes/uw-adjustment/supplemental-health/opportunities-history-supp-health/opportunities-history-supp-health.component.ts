import { AfterViewInit, Component, ElementRef, Input, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { DateUtil } from 'src/app/shared/utils/date-util';


@Component({
  selector: 'app-opportunities-history-supp-health',
  templateUrl: './opportunities-history-supp-health.component.html',
  styleUrls: ['./opportunities-history-supp-health.component.css'],
  standalone: false,
})
export class OpportunitiesHistorySuppHealthComponent implements AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() opportunities: any;
  QuoteLEoption = "Anthem";
  quoteNonWholeCaseStr = "Non-Whole Case";
  lob_FT: any[];
  lob_FT_TransID: any[];
  ratingTransID: string;
  quoteHeaderID: string;
  quoteOrigin: string;
  oppID: string;
  lob: string;
  columns = [
    {
      "header": "Version",
      "field": "Version"
    },
    {
      "header": "Eff Date",
      "field": "contractEffectiveDate"
    },
    {
      "header": "Submitted Time (EST)",
      "field": "submittedTimestamp"
    },
    {
      "header": "Status",
      "field": "status"
    },
    {
      "header": "UW Name",
      "field": "underwriterName"
    },
    {
      "header": "UW Notes",
      "field": "currentAdjustment"
    },
    {
      "header": "Batch Name",
      "field": "batchName"
    },
    {
      "header": "Last Updated (EST)",
      "field": "currentAdjustment"
    },
    {
      "header": "Last Updated by",
      "field": "currentAdjustment"
    },
    {
      "header": "Submitted by",
      "field": "submitterUserInfo"
    }
  ];

  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private router: Router, private commonQuoteService: CommonQuoteService
  ) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }


  ngOnInit() {
  }

  // Formatting date format
  formatDate(timestamp) {
    return DateUtil.formatDate(timestamp);
  }

  // Navigating to new window
  onGoToPage(rowData, $event) {
    this.ratingTransID = rowData["ratingTransID"];
    this.quoteHeaderID = rowData["quoteHeaderID"];
    this.lob = rowData.lob;
    this.oppID = rowData.opportunityID;
    this.quoteOrigin = rowData.quoteOrigin;

    this.lob_FT = [];
    this.lob_FT_TransID = [];
    this.commonService.setQuoteTabList(this.lob_FT_TransID);
    this.commonQuoteService.getOpportunitesByOppID(this.oppID, this.lob).subscribe(
      response => {
        if (response != null) {
          for (var opp of response.opportunities) {
            if (opp && opp.quoteHeaderID === this.quoteHeaderID) {
              let data = (opp.lob == 'Medical' && (opp.quotingType == 'ACA' || opp.quotingType == 'MEWA')) ? opp.lob + '-' + opp.quotingType : opp.lob + '-' + opp.fundingType;
              if (!this.lob_FT.find(lobFundingType => lobFundingType === data)) {
                this.lob_FT.push(data);
                this.lob_FT_TransID.push({
                  tabName: data,
                  ratingTransID: opp.ratingTransID,
                  fundingType: opp.fundingType,
                  quoteOrigin: opp.quoteOrigin
                });
              }
            }
          }
          this.lob_FT = this.lob_FT.sort(function (ascending, descending) {
            return ascending > descending ? 1 : ascending < descending ? -1 : 0;
          });
          this.commonService.setQuoteTabList(this.lob_FT_TransID);

          if (this.ratingTransID) {
            const url = this.router.serializeUrl(
              this.router.createUrlTree(["/quote/supplemental-health/longterm"], {
                queryParams: {
                  quoteHeaderID: this.quoteHeaderID,
                  opportunityID: this.oppID,
                  ratingTransID: this.ratingTransID,
                  lob: rowData.lob,
                  fundingType: rowData.fundingType,
                  availableTabs: this.lob_FT,
                  isLoginAgain: true,
                  disableAll: true,
                  quoteOrigin: this.quoteOrigin,
                }
              })
            );
            if (/Edge/.test(navigator.userAgent)) {
              if (localStorage.getItem("isLoginAgain")) {
                this.commonService.removeHistoryLocalStorage();
              }
            }
            localStorage.setItem("quoteHeaderID", this.quoteHeaderID);
            localStorage.setItem("opportunityID", this.oppID);
            localStorage.setItem("ratingTransID", this.ratingTransID);
            localStorage.setItem("quoteOrigin", this.quoteOrigin);
            localStorage.setItem("lob", rowData.lob);
            localStorage.setItem("fundingType", rowData.fundingType);
            localStorage.setItem(
              "availableTabs",
              this.lob_FT.map(tabs => tabs).join(",")
            );
            localStorage.setItem("isLoginAgain", "true");
            localStorage.setItem("assignedUserRoles", this.authenticationService.getUserRole());
            localStorage.setItem("assignedUserRolesTextToDisplay", this.authenticationService.getUserRoleTextToDisplay())
            localStorage.setItem("assignedUserLobs", this.authenticationService.getUserLob())
            localStorage.setItem("assignedUserStates", this.authenticationService.getUserState())
            localStorage.setItem("disableAll", "true");

            window.open(url, "_blank");
          } else {
            alert("Please select the Opportunity ");
          }
        }
      },
      error => {
        console.error(error);
      }
    );
  }
}
