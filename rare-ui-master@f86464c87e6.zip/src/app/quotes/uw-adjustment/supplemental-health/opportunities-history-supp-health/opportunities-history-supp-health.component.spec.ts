import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunitiesHistorySuppHealthComponent } from './opportunities-history-supp-health.component';

describe('OpportunitiesHistorySuppHealthComponent', () => {
  let component: OpportunitiesHistorySuppHealthComponent;
  let fixture: ComponentFixture<OpportunitiesHistorySuppHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpportunitiesHistorySuppHealthComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OpportunitiesHistorySuppHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
