import { Component, ElementRef, Inject, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { SESSION_STORAGE, WebStorageService } from "ngx-webstorage-service";
import { CommonConstants } from "src/app/shared/constants/common.constants";
import {
  AuthenticationService,
  CommonService,
  PrintExhibitService,
  ProcessQuoteDetailsService
} from "src/app/shared/services";
import { OffCycleModalService } from 'src/app/shared/services/off-cycle-modal.service';
import { OffCycleModalComponent } from 'src/app/shared/components/off-cycle-modal/off-cycle-modal.component';
import { StringUtils } from "src/app/shared/utils/string-utils";
import { ValidationService } from "src/app/shared/services/validation.service";
import { CommonQuoteService } from "../../services/common-quote.service";
import { MultiSelect } from 'primeng/multiselect';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AdjustmentSuppHealth } from "src/app/shared/models/uwAdjustmentSuppHealth";
import { RateInfo } from 'src/app/shared/models';
import { CommonUtil } from "src/app/shared/utils/common-util";
import { UWAdjustmentChangeSetService } from "../medical/uw-adjust-changeset.service";
import { SuppHealthUtil } from "./suppHealth.util";
import {
  FeaturedPlansSupplementalHealthComponent
} from "./featured-plans-supplemental-health/featured-plans-supplemental-health.component";
import { AdjustmentsSuppHealthComponent } from "./adjustments-supp-health/adjustments-supp-health.component";

@Component({
  selector: 'supplemental-health',
  templateUrl: './supplemental-health.component.html',
  styleUrls: ['./supplemental-health.component.css'],
  standalone: false,
})

export class SupplementalHealthComponent implements OnInit, OnDestroy {
  private eventSources: EventSource[] = [];
  activeTab: string = 'featured';
  disableAll: boolean = false;
  hasPortfolioPlans: boolean = false;
  hasFeaturedPlans: boolean = false;
  hasErredPlans: boolean = false;
  currentTab: any;
  rareData: any = {};
  fundingType: string;
  ratingTransID: string;
  opportunityID: string;
  quoteHeaderID: string;
  quoteOrigin: string;
  accountName = 'Loading';
  oppID: any;
  transID: any;
  lob: any;
  disableBackBtn: boolean;
  alternateQuote: boolean = false;
  lob_FT: any;
  public disableSoldTab = false;
  state: any;
  factorEffectiveDate: any;
  quotingType: any;
  declineQuoteBool: boolean = false;
  gridApi;
  gridColumnApi;
  RateInfo: any;
  plans: RateInfo[];
  featuredPlans: any[];
  planLevelFailData: any;
  portfolioPlans: RateInfo[];
  calcDetails: any[];
  userSelectedTier: any;
  selectedQuoteAction: any;
  lobFundingType: any;
  isCollapsed = false;
  isAdjCollapsed = false;
  div_visible = false;
  proposedPlans: any;
  suppHealthPremiumComparison: any;
  showSuppHealthPremiumComparison: boolean;
  opportunityData: any;
  AdjData: any;
  value: Date;
  contractStartDate: any;
  contractEndDate: any;
  reqTier: any;
  suppHealthInputTier: any;
  salesRepName: any;
  noData: string = "Not Available";
  salesContactNo: any;
  empEnrolPlan: any;
  eligibleEmp: any;
  riskScore: any;
  suppHealthPlans: any[];
  errorPlans: any[] = [];
  rateColumns: any[];
  totGroupSize: any;
  status: string;
  quoteError: any = '';
  quoteErrorMessage: boolean = false;
  quoteHistory: boolean = false;
  oldQuotesData: any;
  processId: any;
  quoteErrorCode: any = '';
  declineReasons: any[] = [];
  declineCheckboxes: any[] = [];
  showProgress: boolean = false;
  expandClicked: boolean = true;
  progressPercent: number = 0;
  progressStyle: string;
  progressMessage: any;
  addr1: any;
  addr2: any;
  compZipcode: any;
  scrollTop: any;
  censusID: any;
  opportunityType: string;
  marketSegment: string;
  initializeQuote: boolean = false;
  factorsAndTierLivesLoaded: boolean = false;
  uwLoaded: boolean = false;
  suppHealthPremiumComparisonLoaded: boolean = false;
  allPlansLoaded: boolean = false;
  portfolioPlanLoaded: boolean = false;
  featuredPlanLoaded: boolean = false;
  featuredPlanCount = 0;
  erredPlanLoaded: boolean = false;
  noOfPlans: number = 0;
  noOfPlansLoadComplete: number = 0;
  releaseOptions: any[] = [];
  selectedReleaseOption: any;
  isReadOnlyRole: boolean = false;
  isRenewalQuote: any;
  factorAdjArray = [];
  quoteDetailsObj: any = {};
  peOverrideData: {
    rateGuaranteeMonths: any;
  };
  exhibitSheets: any = [];
  hasPEOverrideError: boolean = false;
  releaseType: string;
  disableprint: boolean = false;
  reqObj = {};
  metaTransID: string;
  adjustedArr = [];
  isSuppHealthPremiumComparison: boolean = false;
  documents: any[];
  adjustment_form: FormGroup<AdjustmentSuppHealth>;
  metaSenderApp: string;
  experienceIncluded: any;
  totEligibleEmp: any = 0;
  quotedSubs: number;
  waivers: number = 0;
  receivedEventsList: any = [];
  InitialRateData: any = {};
  adjustedPlans = [];
  isChangedFlag = false;
  rareDataObj: any = {};
  InitialFeaturedPlansData: any;
  portfolioPlanCount = 0;
  guardrailBoundaries: any;
  searchAnywhere: string;
  boundariesObjName = {}
  guardrailBoundariesToQuoteDetails: any = {}
  EE: any = 0;
  EF: any = 0;
  ES: any = 0;
  EC: any = 0;
  E1: any = 0;
  EK: any = 0;
  statusReasons: any;
  alertData: any;
  successMessage: any;
  failureMessage: any;
  warningMessage: any;
  isInitialQuoteUpdate: boolean = false;
  virginGroup: any;
  multiselectEle: any;
  isLoading: boolean = true;
  loadingMessage = CommonConstants.QUOTE_DETAILS_LOADING_MESSAGE;
  public showAdjustmentHistory: boolean = true;
  isSuppHealthPremiumComparisonChanged: boolean = false;
  adjustedRates = [];
  adjustedAgeBandRates = [];
  userSelectionChanges: any;
  curvRiskScore: any;
  sseCurvRiskScore: string = null;

  @ViewChild(AdjustmentsSuppHealthComponent) adjustmentsSuppHealthComponent: AdjustmentsSuppHealthComponent;
  @ViewChild(FeaturedPlansSupplementalHealthComponent) featuredPlansSupplementalHealthComponent: FeaturedPlansSupplementalHealthComponent;
  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  userRole: any;
  abfSLDefaultValues: {};
  erFundLvlDfltVal: any;

  displayOptionsPannel() {
    if (this.multiselectEle) {
      this.multiselectEle.focus();
    }
  }

  constructor(private fb: FormBuilder, private router: Router, private commonService: CommonService, private peService: PrintExhibitService,
    private route: ActivatedRoute, @Inject(SESSION_STORAGE) private storage: WebStorageService, private commonQuoteService: CommonQuoteService, private processQuoteService: ProcessQuoteDetailsService, private authService: AuthenticationService, private elRef: ElementRef,
    private uwChangeSetService: UWAdjustmentChangeSetService, public offCycleModalService: OffCycleModalService) {
  }

  onSubmit(form: FormGroup) {
    // on submit Adjustment form code will be here
  }

  handleRateInitialResponse(metadata, data) {
    this.rareData.metadata = this.commonService.deepCopy(metadata);
    this.metaTransID = this.rareData.metadata.metaTransID;
    this.metaSenderApp = this.rareData.metadata.sourceSystem;
    this.mergeRateDataWithAsyncData(JSON.parse(JSON.stringify(data)));
    if (data.errors && data.errors.errorList) {
      for (let error of data.errors.errorList) {
        this.quoteErrorCode = error.code;
        if (this.quoteError)
          this.quoteError = this.quoteError + ' , ' + error.msg;
        else
          this.quoteError = error.msg;
      }
      this.quoteError = this.quoteError.replaceAll('. ,', '. ');
      if (this.quoteError) {
        this.quoteErrorMessage = true;
      }
    }
    this.accountName = data.accountName;
    let rareData = data;
    this.censusID = rareData['censusRefId'];
    this.quoteHeaderID = rareData['quoteHeaderID'];
    this.addr1 = rareData['addr1'];
    this.addr2 = rareData['addr2'];
    this.compZipcode = rareData['companyZipCode'];
    this.virginGroup = rareData['virginGroup'];
    this.opportunityType = rareData['opportunityType'];
    this.quotingType = this.rareData['quotingType'];
    this.marketSegment = rareData['marketSegment'];
    this.quoteOrigin = rareData['quoteOrigin'] ? rareData['quoteOrigin']: null;
    this.experienceIncluded = data.suppHealth.experienceClaimsAvailable ? data.suppHealth.experienceClaimsAvailable : '';
    this.abfSLDefaultValues = {};
      this.abfSLDefaultValues['SURPLUS_REFUND'] = [];
      this.abfSLDefaultValues['ASL_AGG_ATCH_PT'] = [];
      this.abfSLDefaultValues['SSL_CONTRACT_BASIS'] = [];
      this.abfSLDefaultValues['SSL_DEDUCTIBLE'] = []
      this.abfSLDefaultValues['ER_FUNDING_LEVEL'] = [];

    if (data.primaryUserInfo) {
      //If primaryUser exist then it takes priority
      this.salesRepName = data.primaryUserInfo.fullName ? data.primaryUserInfo.fullName : this.noData;
      this.salesContactNo = data.primaryUserInfo.contactNumber ? data.primaryUserInfo.contactNumber : this.noData;
    } else {
      this.salesRepName = this.noData;
      this.salesContactNo = this.noData;
    }
    this.status = data.status ? data.status : this.noData;
    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap &&
      data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.QuotedCount) {
      this.totEligibleEmp = data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.QuotedCount ?
        data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.EligibleCount : 0;
    }
    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap &&
      data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.QuotedCount) {
      this.quotedSubs = data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.QuotedCount ?
        data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.EligibleCount : 0;
    }
    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap &&
      data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.QuotedCount) {
      this.waivers = data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.W ? data.censusCalc.censusSubscriber.suppHealthEligibilityLivesMap.W : 0;
    }
    this.disableSoldTab = !(data.soldEnabled == true || data.soldEnabled == "true");
    this.reqTier = data.suppHealthOutputTier;
    this.suppHealthInputTier = data.suppHealthInputTier;
    this.quotedSubs = this.totEligibleEmp - this.waivers;
    this.factorEffectiveDate = data.factorEffectiveDate;
    this.quoteDetailsObj = {
      'censusID': this.censusID,
      'accountName': data.accountName,
      'opportunityID': this.oppID,
      'state': this.state = data.state ? data.state : this.noData,
      'address1': this.addr1,
      'address2': this.addr2,
      'compZipcode': this.compZipcode,
      'fundingType': this.fundingType,
      'virginGroup': this.virginGroup,
      'experienceIncluded': this.experienceIncluded,
      'salesRepName': this.salesRepName,
      'salesContactNo': this.salesContactNo,
      'factorEffectiveDate': data.factorEffectiveDate,
      'contractStartDate': data.contractEffectiveDate,
      'rateGuaranteeMonths': data.suppHealth.rateGuaranteeMonths,
      'inputTier': data.suppHealthInputTier,
      'reqTier': data.suppHealthOutputTier,
      'quotedSubs': this.quotedSubs,
      'waivers': this.waivers,
      'totEligibleEmp': this.totEligibleEmp,
      'status': this.status,
      'quoteHeaderID': this.quoteHeaderID,
      'lob': this.lob,
      'lob1': this.lob,
      'oppID': this.oppID,
      'opportunityType': this.opportunityType,
      'marketSegment': this.marketSegment,
      'mbs': data.mbs,
      'groupNumber': data.groupNbr,
      'sicCode': data.sicCode,
    }
    this.declineQuoteBool = false;
    setTimeout(() => {
      this.declineQuoteBool = true;
    });
  }

  loadRateInfo() {
    this.clearAllAdjustedRates();
    this.commonQuoteService.getRateInfoSuppHealth(this.transID, this.oppID, this.quoteHeaderID, this.quoteOrigin, this.lob, this.fundingType).subscribe(response => {
      var source = this.commonService.listenForStream(response.processId);
      this.eventSources.push(source);
      source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS, (event: any) => {
        if (event && event.data) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data && data.payload.metadata) {
            this.handleRateInitialResponse(data.payload.metadata, data.payload.data);
            this.quoteHistoryClicked();
            this.initializeQuote = true;
          }
        }
      });
      source.addEventListener(CommonConstants.OTHER_DETAILS_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.OTHER_DETAILS_FETCH)) {
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handleFactorsAndTierLives(data.payload.data);
            this.factorsAndTierLivesLoaded = true;
          }
        }
      });
      source.addEventListener(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH)) {
          this.receivedEventsList.push(CommonConstants.UNDERWRITER_ADJUSTMENT_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handleUWResponse(data.payload.data);
            this.peOverrideData = JSON.parse(JSON.stringify(this.rareData?.uwAdjustment?.peOverrideData ?? {}));
            this.peOverrideData.rateGuaranteeMonths = this.calculateOverriddenRateGuaranteeMonths(this.peOverrideData);
          }
          const isEmpty = Object.keys(data.payload.data).length === 0;
          if (isEmpty) {
            this.showAdjustmentHistory = false;
          } else {
            this.showAdjustmentHistory = true;
          }
        }
      });
      source.addEventListener(CommonConstants.SUPPHEALTH_PREMIUM_COMPARISON_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.SUPPHEALTH_PREMIUM_COMPARISON_FETCH)) {
          this.receivedEventsList.push(CommonConstants.SUPPHEALTH_PREMIUM_COMPARISON_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handleSHPCResponse(data.payload.data);
            this.suppHealthPremiumComparisonLoaded = true;
          }
        }
      });

      source.addEventListener(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH)) {
          this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH);
          if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            let dataObj = JSON.parse(JSON.stringify(data.payload.data));
            if (dataObj.dataExists) {
              this.hasFeaturedPlans = true;
              this.noOfPlans++;
            }
          } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });

      source.addEventListener(CommonConstants.FEATURED_PLAN_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_FETCH)) {
          this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handlePlanData(data.payload.data);
            this.loadFeaturedSuppHealthPlans(data.payload.data);
            this.featuredPlanLoaded = true;
            this.noOfPlansLoadComplete++;
            if (!this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH);
              this.hasFeaturedPlans = true;
              this.noOfPlans++;
            }
            if (this.noOfPlans == this.noOfPlansLoadComplete &&
              this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.allPlansLoaded = true;
            }
          } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });
      source.addEventListener(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH)) {
          this.receivedEventsList.push(CommonConstants.GUARD_RAIL_FAILED_STATUS_KEY_FETCH);
          let data = JSON.parse(event.data);
          if (data?.payload?.data) {
            this.handleGRFSKResponse(data.payload.data);
          } else {
            this.handleGRFSKResponse(null);
          }
        }
      });

      source.addEventListener(CommonConstants.ERROR_PLAN_FETCH, (event: any) => {
        if (event && event.data && !this.checkIfEventRecieved(CommonConstants.ERROR_PLAN_FETCH)) {
          this.receivedEventsList.push(CommonConstants.ERROR_PLAN_FETCH);
          let data = JSON.parse(event.data);
          if (data.payload && data.payload.data) {
            this.handlePlanData(data.payload.data);
            this.noOfPlansLoadComplete++;
            if (!this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.receivedEventsList.push(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH);
              this.hasErredPlans = true;
              this.noOfPlans++;
            }
            if (this.noOfPlans == this.noOfPlansLoadComplete &&
              this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
              this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
              this.allPlansLoaded = true;
            }

          } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
            this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
            this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
            this.allPlansLoaded = true;
          }
        } else if (this.noOfPlans == this.noOfPlansLoadComplete &&
          this.checkIfEventRecieved(CommonConstants.FEATURED_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.PORTFOLIO_PLAN_INDICATOR_FETCH) &&
          this.checkIfEventRecieved(CommonConstants.ERRORED_PLAN_INDICATOR_FETCH)) {
          this.allPlansLoaded = true;
        }
      });

      source.addEventListener(CommonConstants.QUOTE_DETAILS_STATUS_COMPLETE, (event: any) => {
        source.close();
        this.initializePlans();
        this.isLoading = false;
      });

      source.addEventListener("FAILED", (message: any) => {
        source.close();
        console.error("Received fail event for : loadRateInfo()");
        this.commonQuoteService.cleanUpSSEEvents(this.processId);
        this.failureMessage = true;
        this.alertData = CommonConstants.ALERT_MESSAGE;
        this.isLoading = false;
        this.featuredPlans = null;
      });
    })

  }

  ngOnInit(): void {
    this.releaseOptions.push({ "label": "Initial Release", "value": "initial" })
    this.adjustment_form = this.fb.group({
      uwAdjustmentFactor: ['', [Validators.required]],
      employerRiskFactor: ['', Validators.required],
      salesAdjustmentFactor: ['', [Validators.required]],
      wholeHealthAdjustmentFactor: ['', [Validators.required]],
      uwNotesToSales: ['', Validators.required],
      uwComments: ['', [Validators.required]],
      salesNotetoUW: [''],
      contractEndDate: ['', Validators.required],
      exhibitName: ['', [Validators.required]],
      approvalStatus: ['', [Validators.required]],
      submittedTimestamp: ['', [Validators.required]],
      quoteReason: [''],
      adjustedRateActionPercent: ['', [Validators.required, ValidationService.validateDecimalNumbers]]
    });

    window.scroll(0, 0);

    this.route
      .queryParams
      .subscribe(params => {
        this.oppID = params[CommonConstants.OPPORTUNITY_ID];
        this.opportunityID = this.oppID;
        this.transID = params[CommonConstants.RATINGTRANS_ID];
        this.lob = params[CommonConstants.LOB];
        this.fundingType = params[CommonConstants.FUNDING_TYPE];
        this.quoteHeaderID = params[CommonConstants.QUOTEHEADER_ID];
        this.searchAnywhere = params[CommonConstants.SELECTED_SEARCH_ANYWHERE];
        this.lob_FT = params[CommonConstants.AVAILABLE_TABS];
        var disableAllBoolean = params[CommonConstants.DISABLE_ALL];
        this.disableBackBtn = params[CommonConstants.DISABLE_BACK_BTN];
        this.quoteOrigin = params[CommonConstants.QUOTE_ORIGIN];
        if (disableAllBoolean && disableAllBoolean === 'true') {
          this.disableAll = true;
          this.adjustment_form.disable();
        } else {
          this.disableAll = false;
          this.adjustment_form.enable();
        }
        this.getCurrentTabList();
      });

    this.authService.userRoleTextToDisplay.subscribe(data => {
      if (data.includes('Read Only')) {
        this.isReadOnlyRole = true;
      }
    })
    this.selectedQuoteAction = { action: 'Quote' };
    this.userSelectedTier = '';
    this.loadRateInfo();
    this.loadPrintExhibitsInfo(true, null);
    this.userRole = this.authService.userRole['_value'];
    this.commonService.setOpportunityId(this.oppID);
    this.commonService.setquoteHeaderId(this.quoteHeaderID);

    const myDropdown = this.elRef.nativeElement.querySelector("releaseMouseHover");
    if (myDropdown) {
      myDropdown.click();
    }
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }

  initializePlans() {
    let planTabs = ['featured', 'portfolio', 'erred'];
    if (planTabs.includes(this.activeTab) && this.activeTab == "featured") {
      this.activeTab = this.hasFeaturedPlans ? 'featured' : this.hasPortfolioPlans ? 'portfolio' : 'erred';
    }
  }

  mergeRateDataWithAsyncData(data: any) {
    Object.keys(data).forEach(key => {
      let proposedPlans;
      if (this.rareData[key] && this.rareData[key].proposedPlans) {
        proposedPlans = this.rareData[key].proposedPlans;
      }

      if (this.rareData[key] !== data[key]) {
        this.rareData[key] = this.commonService.deepCopy(data[key]);
      }
      if (proposedPlans && this.rareData[key] && !this.rareData[key].proposedPlans) {
        this.rareData[key]['proposedPlans'] = proposedPlans;
      }

      if (this.InitialRateData[key] !== data[key]) {
        this.InitialRateData[key] = this.commonService.deepCopy(data[key]);
      }
    });
    this.reloadChildComponents();
  }

  reloadChildComponents() {
    if (this.rareData && this.rareData.suppHealth && this.proposedPlans && !this.rareData.suppHealth.proposedPlans) {
      this.rareData.suppHealth.proposedPlans = this.proposedPlans;
    }

    if (this.rareData && this.proposedPlans && ((!this.rareData.uwAdjustment) || (this.rareData.uwAdjustment && !this.rareData.uwAdjustment.adjustedRates))) {
      this.updateAdjustedRates(this.proposedPlans);
    }

    this.rareData = this.commonService.deepCopy(this.rareData);
    this.InitialRateData = this.commonService.deepCopy(this.InitialRateData);
    this.adjustedPlans = this.commonService.deepCopy(this.adjustedPlans);
    this.quoteDetailsObj = this.commonService.deepCopy(this.quoteDetailsObj);
  }

  updateAdjustedRates(plans) {
    let adjustedRates = [];
    plans.forEach(plan => {
      adjustedRates.push({
        ratingPlanID: plan.ratingPlanID,
        uwAdjustment: this.getUwAdjustmentFactor(plan),
        uwAdjustmentFactor: this.getUwAdjustmentFactor(plan)
      })
    })
    if ((!this.rareData.uwAdjustment) || (this.rareData.uwAdjustment && !this.rareData.uwAdjustment.adjustedRates)) {
      this.rareData.uwAdjustment = { adjustedRates };
    }
  }
  getUwAdjustmentFactor(plan: any) {
    let uwAdjustmentFactor = 1;
    if (plan.uwAdjustmentFactor) {
      uwAdjustmentFactor = plan.uwAdjustmentFactor
    } else if (!this.rareData?.suppHealth?.inRateGuarantee &&
      plan.factors && plan.factors.lstShpAdjFctr.length > 0) {
      plan.factors.lstShpAdjFctr.forEach(factor => {
        if (plan.planName.toUpperCase().includes(factor.prodNm.toUpperCase())) {
          uwAdjustmentFactor = factor.adjFctr;
        }
      });

    }
    return uwAdjustmentFactor;
  }
  checkIfEventRecieved(eventType: string) {
    if (this.receivedEventsList && this.receivedEventsList.includes(eventType))
      return true;
    else
      return false;
  }

  checkTabData() {
    const medicalPlanTabsWrapper = document.querySelector('.nav-pills-wrapper');
    const tabCount = medicalPlanTabsWrapper.querySelectorAll('li').length;
    if (tabCount == 2) {
      return 'tabWidth_2';
    }
    if (tabCount == 3) {
      return 'tabWidth_3';
    }
    if (tabCount > 3) {
      return 'tabWidth_4';
    }
    return 'tabWidth';
  }

  isTabActive(plan) {
    this.activeTab = plan;
  }

  checkRenewalBg(): boolean {
    return (this.rareData && StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL));
  }

  backClicked() {
    if (!this.storage.get('QuoteSearchQuery')) {
      let searchQuery = {};
      searchQuery['quoteReason'] = this.rareData['quoteReason'] !== 'TEST' ? { "$nin": ["TEST"] } : { "$in": ["TEST"] };
      searchQuery['opportunityID'] = { "$regex": ".*" + this.rareData['opportunityID'] + ".*" };
      searchQuery['quoteOrigin'] = { $in: ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch'] };
      this.storage.set('QuoteSearchQuery', JSON.stringify(searchQuery));
      this.storage.set('quoteOrigin', ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch']);
      this.storage.set('showOpportunities', 'true');
      this.storage.set('opportunityID', this.rareData['opportunityID']);
      this.storage.set('searchAnywhere', this.searchAnywhere);
      this.storage.set('quoteReason', this.rareData['quoteReason'] !== 'TEST' ? false : true);
      this.storage.set('pageLimit', 10);
    }
    this.storage.set('searchAnywhere', this.searchAnywhere);
    this.router.navigate(['/quote']);
  }

  isTabDisabled(tabName: String) {
    return this.commonQuoteService.shouldDisableTab(tabName);
  }

  onNavigateTab(data: string) {
    this.currentTab = data;
    let tabData = data.split("-");
    if (StringUtils.isEqual(tabData[0], CommonConstants.SuppHealth)) {
      this.fundingType = tabData[1];
      this.ratingTransID = this.commonService.getTransIDforTab(tabData[0], tabData[1]);
      this.loadRateInfo();
    }
    if (StringUtils.isEqual(tabData[0], CommonConstants.Medical)) {
      this.router.navigate(['quote/uw-rate'], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]), opportunityID: this.opportunityID, quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
          quoteHeaderID: this.quoteHeaderID, lob: tabData[0], groupName: this.accountName, fundingType: this.commonService.getFundingTypeforTab(tabData[0], tabData[1]), availableTabs: this.lob_FT,quotingTypeFromTab: tabData[1]
        }
      });
    }
    if (StringUtils.isEqual(tabData[0], CommonConstants.Dental)) {
      this.router.navigate(["quote/uw-rate-dental"], {
        queryParams: {
          ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
          opportunityID: this.opportunityID,
          quoteHeaderID: this.quoteHeaderID,
          quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
          lob: tabData[0],
          groupName: this.accountName,
          fundingType: tabData[1],
          availableTabs: this.lob_FT
        }
      });
    }
    if (tabData[0] === 'Vision') {
      if (this.commonService.isVisionEnabled == 'true') {
        this.router.navigate(["quote/uw-rate-vision"], {
          queryParams: {
            ratingTransID: this.commonService.getTransIDforTab(tabData[0], tabData[1]),
            opportunityID: this.opportunityID,
            quoteHeaderID: this.quoteHeaderID,
            lob: tabData[0],
            groupName: this.accountName,
            fundingType: tabData[1],
            quoteOrigin: this.commonService.getQuoteOriginforTab(tabData[0], tabData[1]),
            availableTabs: this.lob_FT
          }
        });
      }
    }
  }

  getCurrentTabList() {
    let tabList = this.commonService.getQuoteTabList();
    if (tabList && tabList.length) {
      this.currentTab = this.commonService.getCurrentTab(this.transID, this.lob);
    } else {
      this.commonQuoteService.getOpportunitesByOppID(this.oppID, this.lob).subscribe(
        response => {
          if (response != null) {
            let lob_FT = [];
            let lob_FT_TransID = [];
            for (var opp of response.opportunities) {
              if (opp && opp.quoteHeaderID === this.quoteHeaderID) {
                let data = (StringUtils.isEqual(opp.lob, CommonConstants.SuppHealth) && StringUtils.isEqual(opp.opportunityType, CommonConstants.RENEWAL_LOCAL) && StringUtils.isEqual(opp.quotingType, 'ACA')) ? opp.lob + '-' + opp.quotingType : opp.lob + '-' + opp.fundingType;
                if (!lob_FT.find(response => response === data)) {
                  lob_FT.push(data);
                  lob_FT_TransID.push({
                    tabName: data,
                    tabStatus: opp.status,
                    ratingTransID: opp.ratingTransID,
                    fundingType: opp.fundingType,
                    quoteOrigin: opp.quoteOrigin
                  });
                }
              }
            }
            this.commonService.setQuoteTabList(lob_FT_TransID);
            this.currentTab = this.commonService.getCurrentTab(this.transID, this.lob);
          }
        });
    }
  }

  navigateToSoldRates() {
    this.router.navigate([CommonConstants.SOLD_RATES_URL], {
      queryParams: {
        ratingTransID: this.transID, opportunityID: this.oppID, quoteOrigin: this.quoteOrigin,
        quoteHeaderID: this.quoteHeaderID, lob: this.lob, groupName: this.accountName, fundingType: this.fundingType, availableTabs: this.lob_FT,
        state: this.state,
        factorEffectiveDate: this.factorEffectiveDate
      }
    });
  }


  isSGRenewalQuoteDisabled() {
    if (this.rareData != undefined) {
      this.isRenewalQuote = this.rareData.opportunityType;
      if (StringUtils.isEqual(this.marketSegment, CommonConstants.smallGroup) && StringUtils.isEqual(this.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
        return true;
      }
      else {
        return false
      }
    }
  }

  checkIfEventReceived(eventType: string) {
    if (this.receivedEventsList && this.receivedEventsList.includes(eventType))
      return true;
    else
      return false;
  }

  loadFeaturedSuppHealthPlans(data) {
    let dataObj = JSON.parse(JSON.stringify(data));
    this.suppHealthPlans = data.suppHealth.proposedPlans;
    this.proposedPlans = data.suppHealth.proposedPlans;
    this.featuredPlans = [];
    this.planLevelFailData = {};
    this.featuredPlanCount = 0;
    let accidentPlans = [];
    let criticalIllnessPlans = [];
    let hospitalIndemnityPlans = [];
    if (this.suppHealthPlans) {
      this.suppHealthPlans.forEach(item => {
        if (StringUtils.isEqualIgnoreCase(item.planTypeRequested, "F")) {
          if (item['currentPlanRateInfo'] != null) {
            if (this.isAgeBandPlan(item)) {
              item.rateInfo = JSON.parse(JSON.stringify(item['ageBandRateInfo']));
            } else {
              item.rateInfo = JSON.parse(JSON.stringify(item['rateInfo']));
            }
          }

          let planName = item.planName.toLowerCase();
          if (planName.includes(CommonConstants.ACCIDENT)) {
            accidentPlans.push(item)
          }
          else if (planName.includes(CommonConstants.HOSPITAL)) {
            hospitalIndemnityPlans.push(item)
          }
          else {
            criticalIllnessPlans.push(item)
          }
          this.featuredPlanCount++;
        }
        if (item.failedGuardRails) {
          this.planLevelFailData = this.fetchPlanLevelFailRes(item.failedGuardRails);
        }
        if (accidentPlans) {
          accidentPlans.sort((asc, desc) => {
            const numA = parseInt(asc.planName.match(/\d+/)?.[0] || '0')
            const numB = parseInt(desc.planName.match(/\d+/)?.[0] || '0')
            return numA - numB
          })
        }
        if (hospitalIndemnityPlans) {
          hospitalIndemnityPlans.sort((asc, desc) => {
            const numA = parseInt(asc.planName.match(/\d+/)?.[0] || '0')
            const numB = parseInt(desc.planName.match(/\d+/)?.[0] || '0')
            return numA - numB
          })
        }
        if (criticalIllnessPlans) {
          criticalIllnessPlans.sort((asc, desc) => {
            const numA = parseInt(asc.planName.match(/\d+/)?.[0] || '0')
            const numB = parseInt(desc.planName.match(/\d+/)?.[0] || '0')
            return numA - numB
          })
        }
      });
      this.featuredPlans = [].concat(accidentPlans, hospitalIndemnityPlans, criticalIllnessPlans);
    }
    if (!this.adjustedPlans || this.adjustedPlans.length == 0) {
      this.adjustedPlans = this.featuredPlans;
      this.adjustedPlans.forEach(plan => {
        if (this.rareData.uwAdjustment && this.rareData.uwAdjustment.adjustedRates) {
          this.rareData.uwAdjustment.adjustedRates.push({
            ratingPlanID: plan.ratingPlanID,
            uwAdjustment: this.getUwAdjustmentFactor(plan)
          })
        }
      })
      if (!this.rareData.uwAdjustment || !this.rareData.uwAdjustment.adjustedRates || this.rareData.uwAdjustment.adjustedRates.length == 0) {
        let adjustedRates = [];
        this.adjustedPlans.forEach(adjustedPlan => {
          adjustedRates.push({
            ratingPlanID: adjustedPlan.ratingPlanID,
            uwAdjustment: this.getUwAdjustmentFactor(adjustedPlan)
          })
        })
        this.rareData.uwAdjustment = {
          adjustedRates: adjustedRates
        }
      }
      this.reloadChildComponents();
    }
  }

  isAgeBandPlan(plan: any) {
    const ageBandRateInfo = plan.ageBandRateInfo;
    return Object.keys(ageBandRateInfo).length > 0 && ageBandRateInfo.constructor === Object;
  }

  handlePlanData(data: any) {
    let rateData = JSON.parse(JSON.stringify(data));
    if (this.rareData.suppHealth && this.rareData.suppHealth.proposedPlans) {
      let hasRateData = this.rareData.suppHealth.proposedPlans;
      this.rareData.suppHealth.proposedPlans = this.commonService.deepCopy(this.mergeArrays(hasRateData, rateData.suppHealth.proposedPlans));
    } else if (this.rareData.suppHealth) {
      this.rareData.suppHealth.proposedPlans = this.commonService.deepCopy(this.mergeArrays([], rateData.suppHealth.proposedPlans));
    }
    if (this.InitialRateData.suppHealth && this.InitialRateData.suppHealth.proposedPlans) {
      let hasInitialRateData = this.InitialRateData.suppHealth.proposedPlans;
      this.InitialRateData.suppHealth.proposedPlans = this.commonService.deepCopy(this.mergeArrays(hasInitialRateData, rateData.suppHealth.proposedPlans));
    } else if (this.rareData.suppHealth) {
      this.InitialRateData.suppHealth.proposedPlans = this.commonService.deepCopy(this.mergeArrays([], rateData.suppHealth.proposedPlans));
    }
    this.reloadChildComponents();
  }

  mergeArrays(...arrays) {
    let jointArray = []
    arrays.forEach(array => {
      jointArray = [...jointArray, ...array]
    });
    return [...new Set([...jointArray])]
  }

  fetchPlanLevelFailRes(array) {
    let filteredEleList = {};
    array.map((ele) => {
      let guardrailRepRes = ele.split('.');
      if (guardrailRepRes.length === 1) {
        filteredEleList[(guardrailRepRes[0])] = 1;
      }
      else {
        filteredEleList[guardrailRepRes[guardrailRepRes.length - 1]] = 1;
        return filteredEleList;
      }
    })
  }

  onApplyAdjustments(action: string) {
    window.scroll(0, 0);

    let hasSomeFormErrors = false;
    let errorMessage = "Please fix below listed issues to proceed: \n\n";
    let errorCount: number = 1;

    if (this.hasPEOverrideError) {
      errorMessage += errorCount++ + ". Please enter Mandatory fields in Exhibit Overrides section\n";
      hasSomeFormErrors = true;
    }

    if (hasSomeFormErrors && this.exhibitSheets.length > 0) {
      this.alertData = errorMessage;
      this.setWarningFlag();
      return;
    } else {
      this.alertData = '';
      this.warningMessage = false;
    }

    if (
      (StringUtils.isEqual(action, CommonConstants.releaseAction)
        && (this.isValidStatusForReleaseAction(this.status) || this.factorAdjArray.length > 0)
        && !this.adjustment_form.value.uwNotesToSales.trim())) {
      this.alertData = "Please enter UW notes to sales";
      this.setWarningFlag();
      return;
    } else {
      this.onSubmitApplyAdjustment(action);
    }
  }

  isValidStatusForReleaseAction(status: string) {
    const validStatuses = [
      CommonConstants.releasedStatus,
      CommonConstants.modifiedStatus,
      CommonConstants.pendingReviewStatus
    ];
    return validStatuses.includes(status);
  }

  onMouseFocus(event) {
    this.multiSelect.show();
    event.stopPropagation();
  }
  onRelease(event) {
    if (event != null) {
      this.releaseType = this.selectedReleaseOption
    }
  }
  isAutoQuote() {
    if (this.rareData && StringUtils.isEqual(this.opportunityType, CommonConstants.NEW_BUSINESS_LOCAL) && StringUtils.isEqual(this.marketSegment, CommonConstants.smallGroup)) {
      return true;
    }
  }

  getRenewalDropdownClass() {
    return this.quoteDetailsObj['opportunityType'] == 'Renewal Local' ? 'renewal-bg' : '';
  }


  declineReasonsToBeChecked(declineReasons) {
    this.declineCheckboxes = declineReasons;
  }

  contructReqObj() {
    let adjArr = [];
    adjArr = this.adjustedArr;
    let suppHealthPremComparison;
    if (adjArr.length > 0 || this.isSuppHealthPremiumComparisonChanged) {
      suppHealthPremComparison = this.suppHealthPremiumComparison;
    } else {
      suppHealthPremComparison = null;
    }
    let reqObj = {
      "opportunity": {
        "opportunityID": this.rareData['opportunityID'],
        "quoteHeaderID": this.rareData['quoteHeaderID'],
        "lob": "Supp Health",
        "fundingType": "FI",
        "accountName": this.rareData['accountName'],
        "quotingType": this.rareData.quotingType,
        "ratingTransID": this.transID
      },
      "uwAdjustment": {
        "ratingTransID": this.transID,
        "action": "ADJUST",
        "productAdjustments": adjArr,
        "suppHealthPremiumComparison": suppHealthPremComparison,
        "uwNotesToSales": this.adjustment_form.value.uwNotesToSales == '' ? null : this.adjustment_form.value.uwNotesToSales,
        "statusReasons": [],
        "uwComments": this.adjustment_form.value.uwComments == '' ? null : this.adjustment_form.value.uwComments,
        "salesNoteToUW": this.adjustment_form.value.salesNotetoUW,
        "assignedUWName": this.rareData['underwriterName'] ? this.rareData['underwriterName'] : '',
        "status": this.rareData.status,
        "suppHealth": true,
        "peOverrideData": this.peOverrideData,
        "adjustedRates": this.adjustedRates,
        "adjustedAgeBandRates": this.adjustedAgeBandRates
      },
      "quoteReason": this.addQuote()
    }
    return reqObj;
  }

  addQuote() {
    let quoteReason = this.adjustment_form.value.quoteReason;
    if (!quoteReason) {
      quoteReason = 'REAL';
    } else {
      quoteReason = 'TEST';
    }
    return quoteReason;
  }

  isReleased(status) {
    return status ? 'releaseStyle' : false;
  }

  handleFactorsAndTierLives(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    if (dataObj.factors) {
      this.rareData['factors'] = this.commonService.deepCopy(dataObj.factors);
      this.InitialRateData.factors = this.commonService.deepCopy(dataObj.factors);
      this.quoteDetailsObj.factors = this.commonService.deepCopy(dataObj.factors);
    }
    if (dataObj.calculatedTierLives) {
      this.rareData['calculatedTierLives'] = this.commonService.deepCopy(dataObj.calculatedTierLives);
      this.InitialRateData.calculatedTierLives = this.commonService.deepCopy(dataObj.calculatedTierLives);
    }
    if (dataObj.availableTiers) {
      this.rareData['availableTiers'] = this.commonService.deepCopy(dataObj.availableTiers);
      this.InitialRateData.availableTiers = this.commonService.deepCopy(dataObj.availableTiers);
    }
    if (dataObj?.factors?.shpTblPeSheetSlcts) {
      this.buildExhibitSheets(this.commonService.deepCopy(dataObj.factors.shpTblPeSheetSlcts));
    } else if (dataObj?.factors?.lstTblPeSheetSlct) {
      this.buildExhibitSheets(this.commonService.deepCopy(dataObj.factors.lstTblPeSheetSlct));
    }
    this.reloadChildComponents();
  }

  fectchBoundaries(guardRailsList) {
    let boundariesObj = {};
    guardRailsList.map((guardRailObj) => {
      if (StringUtils.isEqual(guardRailObj.guardName, 'Premium Guard Rail')) {
        boundariesObj[guardRailObj.guardName] = '$' + guardRailObj.minVal + ' - ' + '$' + guardRailObj.maxVal;
      } else {
        boundariesObj[guardRailObj.guardName] = guardRailObj.minVal + ' - ' + guardRailObj.maxVal;
        let obj = {
          minVal: guardRailObj.minVal,
          maxVal: guardRailObj.maxVal
        }
        this.boundariesObjName[guardRailObj.guardName] = obj;
        this.guardrailBoundariesToQuoteDetails = this.boundariesObjName;
      }
      return boundariesObj;
    })
    boundariesObj['state'] = this.state;
    return boundariesObj;
  }

  downloadPrintExhibitsFile(contentKey) {
    if (contentKey != null && contentKey != "") {
      contentKey = contentKey.replace("{", "%7B");
      contentKey = contentKey.replace("}", "%7D");
    }
    this.commonQuoteService.getFileFromFilenet(contentKey).subscribe(response => {
      if (response != null) {
        let contentData = response.contentData ? response.contentData : this.noData;
        let contentName = response.contentName ? response.contentName : this.noData;
        const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
        this.peService.createAndDownloadBlobFile(arrayBuffer, contentName);
      }
    }, error => {
      console.log(error);
    });
  }

  handleUWResponse(data: any) {
    let dataObj = JSON.parse(JSON.stringify(data));
    this.rareData.uwAdjustment = this.commonService.deepCopy(dataObj.uwAdjustment);
    this.InitialRateData.uwAdjustment = this.commonService.deepCopy(dataObj.uwAdjustment);
    this.uwLoaded = true;
    this.handleAdjustments();
    this.reloadChildComponents();
  }

  handleAdjustments() {
    if (this.rareData.uwAdjustment && this.rareData.uwAdjustment.productAdjustments) {
      this.adjustedPlans = this.rareData.uwAdjustment.productAdjustments;
      this.rareData.uwAdjustment = this.generateUWAdjustment(this.rareData.uwAdjustment);
    } else {
      this.adjustedPlans = this.featuredPlans;
      this.rareData.uwAdjustment = this.generateUWAdjustment(null);
    }
  }

  generateUWAdjustment(uwAdjustment) {
    let productAdjustments = uwAdjustment?.productAdjustments;
    let adjustedRates = [];
    if (productAdjustments) {
      productAdjustments.forEach(productAdjustment => {
        adjustedRates.push(
          {
            CDHPIndicator: productAdjustment.CDHPIndicator,
            uwAdjustment: productAdjustment.uwAdjustmentFactor,
            planName: productAdjustment.planName,
            ratingPlanID: productAdjustment.ratingPlanID,
            empty: productAdjustment.empty,
            ageBandedRateInfo: null,
            rateInfo: null
          }
        )
      })
    }
    if (uwAdjustment) {
      uwAdjustment.adjustedRates = adjustedRates;
    }
    return uwAdjustment;
  }

  onFactorAdj(event) {
    this.isChangedFlag = event.isChangedFlagFactor;
    this.factorAdjArray = event.myArrFactor;
    this.adjustedPlans = event.adjustedPlans
    this.suppHealthPremiumComparison = event.suppHealthPremiumComparison;
    if (!event.isCurrentRateEdit) {
      this.clearAdjustedRatesByRatingPlanID(event.ratingPlanID);
    }
  }

  onTotalFactorAdj(event) {
    this.isChangedFlag = event.isChangedFlagFactor;
    this.factorAdjArray = event.myArrFactor;
    this.adjustedPlans = event.adjustedPlans
    this.suppHealthPremiumComparison = event.suppHealthPremiumComparison;
    this.clearAllAdjustedRates();
  }

  clearAdjustedRatesByRatingPlanID(ratingPlanIDToRemove: string) {
    this.adjustedRates = this.adjustedRates.filter(obj => !StringUtils.isEqualIgnoreCase(obj.ratingPlanID, ratingPlanIDToRemove));
    this.adjustedAgeBandRates = this.adjustedAgeBandRates.filter(obj => !StringUtils.isEqualIgnoreCase(obj.ratingPlanID, ratingPlanIDToRemove));
  }

  clearAllAdjustedRates() {
    this.adjustedRates = [];
    this.adjustedAgeBandRates = [];
  }

  onSubmitApplyAdjustment(action: string) {
    this.div_visible = true;
    this.adjustedArr = this.constructRequestForRenewal();
    this.reqObj = this.contructReqObj();
    if (StringUtils.isEqual(action, CommonConstants.declineAction)) {
      if (this.processQuoteService.uwNotesToSales) {
        if (this.processQuoteService.uwNotesToSales.includes("; ")) {
          this.processQuoteService.uwNotesToSales = this.processQuoteService.uwNotesToSales.split("; ").join(";");
        }
        this.processQuoteService.uwNotesToSales = this.processQuoteService.uwNotesToSales.split(";").join("; ");
        this.reqObj['uwAdjustment'].uwNotesToSales = this.processQuoteService.getUwNotesToSales();

        var checkobexsFound = this.processQuoteService.declineOptionsChecked.some(cbs => this.processQuoteService.uwNotesToSales.includes(cbs));

        if (this.processQuoteService.declineOptionsChecked.length === 5 && !checkobexsFound) {
          let finalUWNote;
          if (this.processQuoteService.declineOptionsChecked != null && this.processQuoteService.declineOptionsChecked.length > 0) {
            this.processQuoteService.declineOptionsChecked.forEach(element => {
              if (finalUWNote == null) {
                finalUWNote = this.processQuoteService.uwNotesToSales != "" && !this.processQuoteService.uwNotesToSales.includes(element) ? this.processQuoteService.uwNotesToSales + ';' + element : element;
              } else if (!finalUWNote.includes(element)) {
                finalUWNote = finalUWNote + ';' + element;
              }
            });
          } else {
            finalUWNote = this.processQuoteService.uwNotesToSales;
          }
          if (typeof (finalUWNote) != 'undefined' && finalUWNote.includes("; ")) {
            finalUWNote = finalUWNote.split("; ").join(";");
          }
          finalUWNote = finalUWNote.split(";").join("; ");
          this.reqObj['uwAdjustment'].uwNotesToSales = finalUWNote;
        }

      }
      else {
        let noCheckboxesChecked: boolean = true;
        if (this.processQuoteService.declineOptionsChecked != null && this.processQuoteService.declineOptionsChecked.length > 0) {
          noCheckboxesChecked = false;
        }
        if (StringUtils.isEqual(action, CommonConstants.declineAction) && !noCheckboxesChecked) {
          let declineCheckboxes: any;
          if (this.reqObj['uwAdjustment'].uwNotesToSales != null) {
            declineCheckboxes = this.reqObj['uwAdjustment'].uwNotesToSales;
          }
          if (this.declineCheckboxes != null) {
            if (this.declineCheckboxes.length == 0) {
              this.declineCheckboxes = this.processQuoteService.declineOptionsChecked;
            }
            this.declineCheckboxes.forEach(element => {
              if (declineCheckboxes == null) {
                declineCheckboxes = element;
              } else {
                if (!declineCheckboxes.includes(element)) {
                  declineCheckboxes = declineCheckboxes != "" && !element.includes(declineCheckboxes) ? declineCheckboxes + ';' + element : element;
                }
              }
            });
            if (declineCheckboxes && declineCheckboxes.includes("; ")) {
              declineCheckboxes = declineCheckboxes.split("; ").join(";");
            }
            declineCheckboxes = declineCheckboxes.split(";").join("; ");
            this.reqObj['uwAdjustment'].uwNotesToSales = declineCheckboxes;
          }
        }
      }
      let statusReason: any;
      let statusReasonsList: any[] = [];
      this.processQuoteService.declineOptionsValues.subscribe(checkboxesSelected => {
        if (checkboxesSelected != null && checkboxesSelected.length > 0) {
          statusReasonsList = checkboxesSelected;
          checkboxesSelected.forEach(element => {
            if (statusReason == null) {
              statusReason = element;
            } else {
              if (!statusReason.includes(element)) {
                statusReason = statusReason != "" && !element.includes(statusReason) ? statusReason + ';' + element : element;
              }
            }
          });
        }
        this.statusReasons = statusReason;
      });
      const setQuoteHeaderID = this.reqObj['opportunity'].quoteHeaderID;
      const setFundingType = this.reqObj['opportunity'].fundingType;
      localStorage.setItem("statusReasons" + "_" + setQuoteHeaderID + "_" + "Supp Health" + "_" + setFundingType, statusReason);
      this.reqObj['uwAdjustment'].statusReasons = statusReasonsList;
    } else {
      let statusReasonsToList: any[] = [];
      if (action == 'save' || action == 'release') {
        if (this.reqObj['uwAdjustment'].uwNotesToSales && this.reqObj['uwAdjustment'].uwNotesToSales.includes(";")) {
          this.reqObj['uwAdjustment'].uwNotesToSales = CommonUtil.htmlEntitiesToString(this.reqObj['uwAdjustment'].uwNotesToSales);
          if (typeof (this.reqObj['uwAdjustment'].uwNotesToSales) != 'undefined' && this.reqObj['uwAdjustment'].uwNotesToSales.includes("; ")) {
            this.reqObj['uwAdjustment'].uwNotesToSales = this.reqObj['uwAdjustment'].uwNotesToSales.split("; ").join(";");
          }
          this.reqObj['uwAdjustment'].uwNotesToSales = this.reqObj['uwAdjustment'].uwNotesToSales.split(";").join("; ");
          this.reqObj['uwAdjustment'].uwNotesToSales = CommonUtil.convertSpecialCharToASCII(this.reqObj['uwAdjustment'].uwNotesToSales);
        }
        if (typeof (localStorage.getItem("statusReasons" + "_" + this.reqObj['opportunity'].quoteHeaderID + "_" + "Supp Health" + "_" + this.reqObj['opportunity'].fundingType)) != 'undefined' &&
          localStorage.getItem("statusReasons" + "_" + this.reqObj['opportunity'].quoteHeaderID + "_" + "Supp Health" + "_" + this.reqObj['opportunity'].fundingType) != null &&
          localStorage.getItem("statusReasons" + "_" + this.reqObj['opportunity'].quoteHeaderID + "_" + "Supp Health" + "_" + this.reqObj['opportunity'].fundingType).includes(";")) {
          this.reqObj['uwAdjustment'].statusReasons = localStorage.getItem("statusReasons" + "_" + this.reqObj['opportunity'].quoteHeaderID + "_" + "Supp Health" + "_" + this.reqObj['opportunity'].fundingType).split(";");
        } else {
          if (localStorage.getItem("statusReasons" + "_" + this.reqObj['opportunity'].quoteHeaderID + "_" + "Supp Health" + "_" + this.reqObj['opportunity'].fundingType) != 'undefined' &&
            localStorage.getItem("statusReasons" + "_" + this.reqObj['opportunity'].quoteHeaderID + "_" + "Supp Health" + "_" + this.reqObj['opportunity'].fundingType) != null) {
            statusReasonsToList.push(localStorage.getItem("statusReasons" + "_" + this.reqObj['opportunity'].quoteHeaderID + "_" + "Supp Health" + "_" + this.reqObj['opportunity'].fundingType));
            this.reqObj['uwAdjustment'].statusReasons = statusReasonsToList;
          }
        }

      }
    }
    let peOverrideDataChangeset: any = this.uwChangeSetService.getPEOverrideDataChangeSetDetails(this.rareData, this.InitialRateData, this.exhibitSheets);
    if (peOverrideDataChangeset?.peOverrideValue) {
      this.rareData.uwAdjustment.peOverrideData.printExhibitEligibility = peOverrideDataChangeset.peOverrideValue.printExhibitEligibility;
      this.reqObj['uwAdjustment'].peOverrideData = this.rareData.uwAdjustment.peOverrideData;
    } else {
      this.reqObj['uwAdjustment'].peOverrideData = null;
    }
    this.reqObj['uwChangesetAdjustmentData'] = peOverrideDataChangeset?.changesetDetail;

    if (StringUtils.isEqual(action, CommonConstants.declineAction) && (!this.reqObj['uwAdjustment'].uwNotesToSales)) {
      this.alertData = "Please enter UW notes to sales";
      this.setWarningFlag();
      return;
    }

    this.reqObj['uwAdjustment'].action = action;
    this.reqObj['opportunity'].quoteOrigin = this.quoteOrigin;
    if (StringUtils.isEqual(this.rareData.opportunityType, CommonConstants.RENEWAL_LOCAL)) {
      this.reqObj['opportunity'].opportunityType = CommonConstants.RENEWAL_LOCAL;
    } else {
      this.reqObj['opportunity'].opportunityType = CommonConstants.NEW_BUSINESS_LOCAL;
    }

    // Include off-cycle data for Declined, Lost, Termed, Transfer statuses OR Sold with user input
    CommonUtil.handleOffCycleData(
      this.reqObj,
      this.rareData,
      this.status?.toString() || '',
      action,
      this.offCycleModalService.offCycleSubmittedInCurrentSession,
      CommonConstants.SuppHealth,
      'contractEffectiveDate'
    );

    // Reset flag after offCycle data is added to payload
    this.offCycleModalService.offCycleSubmittedInCurrentSession = false;

    var useRouterLogic = this.commonQuoteService.useRouterLogicToProcess(action);
    if (this.releaseType != undefined && this.releaseType.length > 0) {
      this.isInitialQuoteUpdate = true;
    }
    else {
      this.isInitialQuoteUpdate = false;
    }
    this.commonQuoteService.onReleaseSuppHealthQuote(this.metaTransID, this.metaSenderApp, this.transID, this.reqObj, action, useRouterLogic, this.isInitialQuoteUpdate)
      .subscribe(
        (response: any) => {
          if (response.status === 200) {

            this.isChangedFlag = false;
            this.receivedEventsList = [];
            this.declineQuoteBool = false;
            setTimeout(() => {
              this.declineQuoteBool = true;
            });
            if (StringUtils.isEqual(action, CommonConstants.releaseAction)) {
              this.processId = response.body.processId;
              if (undefined != this.processId) {
                this.clearPreviousAlerts();
                this.showProgress = true;
                this.progressPercent = 1;
                this.progressStyle = "progress-bar-warning";
                var source = this.commonService.listenForStream(this.processId);
                this.eventSources.push(source);

                source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener("ISOLATE_UWACTION_STATUS", (event: any) => {
                  this.processDefaultEvents(event);
                });

                source.addEventListener("SEND_EXHIBIT_TO_UI", (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener("SUPPHEALTH_SEND_EXHIBIT_TO_UI", (event: any) => {
                  this.processExhibitDocsEvents(event);
                });

                source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);
                });

                source.addEventListener('ISOLATE_UWACTION_STATUS_COMPLETE', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processEventComplete(message);

                  this.quoteHistoryClicked();
                  this.loadRateInfo();
                });

                source.addEventListener('FAILED', (message: any) => {
                  source.close();
                  this.commonQuoteService.cleanUpSSEEvents(this.processId);
                  this.processFailedEvent();
                });
              } else {
                //for direct release without PE
                this.processOthersAction(action);
              }
            } else {
              //for scenarios other than release
              this.processOthersAction(action);
              this.quoteHistoryClicked();
              this.loadRateInfo();
            }
          } else {
            this.processErrorResponse(this.getErrorResponse(action));
          }
        },
        error => {
          this.loadRateInfo();
          this.processErrorResponse("System Error");
        }
      );
  }

  removeFailureMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;

  }

  processExhibitDocsEvents(event: any) {
    if (event.data) {
      let data = JSON.parse(event.data);
      if (data.payload && data.payload.exhibits) {
        this.loadPrintExhibitsInfo(false, this.commonService.deepCopy(data.payload.exhibits));
      }
    }
  }

  removeWarningMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  isRenewalQuoteCheck() {
    return StringUtils.isEqual(this.rareData.opportunityType, CommonConstants.RENEWAL_LOCAL)
  }

  constructRequestForRenewal() {
    this.adjustedArr = [];
    if (this.adjustedPlans.length) {
      for (let i = 0; i < this.adjustedPlans.length; i++) {
        if (this.adjustedPlans[i].uwAdjustment == null) {
          this.adjustedPlans[i].uwAdjustment = this.getUwAdjustmentFactor(this.adjustedPlans[i]);
        }
        let adjustedObj = {
          "planName": this.adjustedPlans[i].planName,
          "ratingPlanID": this.adjustedPlans[i]['ratingPlanID'],
          "uwAdjustmentFactor": this.adjustedPlans[i].uwAdjustment
        }
        this.adjustedArr.push(adjustedObj);
      }
    } else {
      for (let i = 0; i < this.rareDataObj.suppHealth.proposedPlans.length; i++) {
        let adjustedObj = {
          "planName": this.rareDataObj.suppHealth.proposedPlans[i]['planBenefits'].planName,
          "ratingPlanID": this.rareDataObj.suppHealth.proposedPlans[i]['ratingPlanID'],
          "uwAdjustmentFactor": this.rareDataObj.suppHealth.proposedPlans[i].uwDiscret
        }
        this.adjustedArr.push(adjustedObj);
      }
    }

    return this.adjustedArr;
  }

  setWarningFlag() {
    this.div_visible = false;
    this.warningMessage = true;
    this.successMessage = false;
    this.failureMessage = false;
  }

  handleSHPCResponse(data: any) {
    let suppHealthResponse = JSON.parse(JSON.stringify(data));
    // Custom Sort for Plan (ACCIDENT, HOSPITAL, CRITICAL ILLNESS)
    let accidentPlans = [];
    let criticalIllnessPlans = [];
    let hospitalIndemnityPlans = [];
    if (suppHealthResponse.suppHealthPremiumComparison.planComparison) {
      suppHealthResponse.suppHealthPremiumComparison.planComparison.forEach(plan => {
        let planName = plan.currentplanName.toLowerCase();
        if (planName.includes(CommonConstants.ACCIDENT)) {
          accidentPlans.push(plan)
        }
        else if (planName.includes(CommonConstants.HOSPITAL)) {
          hospitalIndemnityPlans.push(plan)
        }
        else {
          criticalIllnessPlans.push(plan)
        }
      });
      suppHealthResponse.suppHealthPremiumComparison.planComparison = [].concat(accidentPlans, hospitalIndemnityPlans, criticalIllnessPlans);
    }
    this.rareData.suppHealthPremiumComparison = this.commonService.deepCopy(suppHealthResponse.suppHealthPremiumComparison);
    this.suppHealthPremiumComparison = this.commonService.deepCopy(suppHealthResponse.suppHealthPremiumComparison);
    this.showSuppHealthPremiumComparison = this.rareData['showSuppHealthPremiumComparison'];
    this.InitialRateData.suppHealthPremiumComparison = this.commonService.deepCopy(suppHealthResponse.suppHealthPremiumComparison);
    this.suppHealthPremiumComparison = this.commonService.deepCopy(suppHealthResponse.suppHealthPremiumComparison);
    this.reloadChildComponents();
  }

  clearPreviousAlerts() {
    this.div_visible = false;
    this.alertData = "";
    this.removeSuccessMsg();
    this.warningMessage = false;
  }
  removeSuccessMsg() {
    this.successMessage = false;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  processDefaultEvents(event: any) {
    this.progressStyle = "";
    let eventData = JSON.parse(event.data);
    var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
    this.progressPercent = percent;
    this.progressMessage = eventData.message;
  }

  processEventComplete(message: any) {
    let eventData = JSON.parse(message.data);
    this.progressStyle = "progress-bar-success";
    this.progressPercent = 100;
    this.progressMessage = eventData.message;
    let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
    element.click();
    this.loadRateInfo();
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  processFailedEvent() {
    this.progressStyle = "progress-bar-danger";
    this.progressMessage = "Print exhibit generation or storage to FileNet failed.";
    this.hideProgressBar();
  }

  processOthersAction(action: string) {
    this.alertData = this.getSuccessResponse(action);
    this.setSuccessFlag();
  }

  getSuccessResponse(action: string) {
    switch (action) {
      case "release":
        return "Quote Released Successfully";
      case "decline":
        return "Quote Declined Successfully";
      case "requote":
        return "Submitted for ReQuote Successfully";
      default:
        return "Changes are saved successfully";
    }
  }

  setSuccessFlag() {
    this.div_visible = false;
    this.successMessage = true;
    this.failureMessage = false;
    this.warningMessage = false;
  }

  processErrorResponse(errorResponse: string) {
    this.alertData = errorResponse;
    this.setFailureFlag();
  }

  setFailureFlag() {
    this.div_visible = false;
    this.failureMessage = true;
    this.successMessage = false;
    this.warningMessage = false;
  }

  getErrorResponse(action: string) {
    switch (action) {
      case "release":
        return "Error Releasing the Quote";
      case "decline":
        return "Error Declining the Quote";
      default:
        return "Error in getting response for Underwriter Adjustment";
    }
  }

  onDecline(declineReasons) {
    this.declineReasons = declineReasons;
  }

  declineReaonsToBeChecked(declineReasons) {
    this.declineCheckboxes = declineReasons;
  }

  quoteHistoryClicked() {
    this.commonQuoteService
      .getOldQuotes(this.oppID, this.lob, this.quoteHeaderID, this.fundingType,this.quoteOrigin, false, this.quotingType, this.opportunityType)
      .subscribe(
        response => {
          let updatedQuotesData = [];
          if (response.opportunities.length) {
            this.oldQuotesData = response.opportunities;
            this.quoteHistory = response.quoteHistory;
            updatedQuotesData = this.oldQuotesData.map((quotesData, index) => {
              quotesData['Version'] = this.oldQuotesData.length - index;
              return quotesData;
            });
            this.oldQuotesData = updatedQuotesData;
          } else {
            this.quoteHistory = false;
          }
        },
        error => {
          console.log(error);
          this.quoteHistory = false;
        }
      );
  }
  onGeneratePrintExhibit() {
    this.disableprint = true;
    this.reqObj = this.contructReqObj();
    let openPEDropdown = false;
    this.commonQuoteService.generatePrintExhibit(this.reqObj, this.metaTransID, this.transID, this.quoteErrorCode).subscribe(
      (response) => {
        if (response.status === 200) {
          this.processId = response.body.processId;
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = "progress-bar-warning";
          var source = this.commonService.listenForStream(this.processId);
          this.eventSources.push(source);
          source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
            this.progressStyle = "";
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
          });
          source.addEventListener("SEND_EXHIBIT_TO_UI", (event: any) => {
            if (event.data) {
              let data = JSON.parse(event.data);
              if (data.payload && data.payload.exhibits) {
                openPEDropdown = true;
                this.loadPrintExhibitsInfo(false, this.commonService.deepCopy(data.payload.exhibits));
              }
            }
          });
          source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
            source.close();
            this.commonQuoteService.cleanUpSSEEvents(this.processId);
            let eventData = JSON.parse(message.data);
            this.progressStyle = "progress-bar-success";
            this.progressPercent = 100;
            this.progressMessage = eventData.message;
            let contentData = eventData.payload.contentData;
            let contentName = eventData.payload.contentName;
            if (eventData.payload.contentMetadata) {
              contentName = eventData.payload.contentMetadata[0].value;
            }
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
            let isXLSX;
            if (contentName.includes('.xlsx'))
              isXLSX = "";
            else isXLSX = ".xlsx";
            this.peService.createAndDownloadBlobFile(arrayBuffer, contentName + isXLSX);

            this.disableprint = false;
            if (openPEDropdown) {
              let element: HTMLElement = document.getElementById('dropdownMenuButton') as HTMLElement;
              element.click();
            }
            setTimeout(() => {
              this.showProgress = false;
              if (this.quoteErrorCode == 'E1403')
                this.loadRateInfo();
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener('FAILED', (message: any) => {
            source.close();
            this.commonQuoteService.cleanUpSSEEvents(this.processId);
            let eventData = JSON.parse(message.data);
            this.progressStyle = "progress-bar-danger";
            this.progressMessage = "Print exhibit generation or storage to FileNet failed.";
            this.hideProgressBar();
          });
        }

      },
      error => {
        this.disableprint = false;
        alert("Error while generating print exhibit");
      }
    );
  }
  loadPrintExhibitsInfo(callPrintExhibit: boolean, exhibitDocs: any) {
    if (callPrintExhibit) {
      this.commonQuoteService
        .getPrintExhibitInfo(this.transID, "Supp Health")
        .subscribe(
          response => {
            if (response != null) {
              this.documents = this.prepareUniquePrintExhibitList(response.exhibits);
            }
          },
          error => {
            console.error(error);
          }
        );
    } else {
      this.documents = this.prepareUniquePrintExhibitList(exhibitDocs);
    }

  }
  prepareUniquePrintExhibitList(exhibits): any[] {
    if (exhibits && Array.isArray(exhibits)) {
      exhibits = exhibits.sort(function (a, b) {
        let dateA: any = new Date(a.submittedTimestamp);
        let dateB: any = new Date(b.submittedTimestamp);
        return dateB - dateA;
      });

      const result = [];
      const map = new Map();
      const peNameRegex = /(\d{4}-\d{2}-\d{2}T)(?!.*\1)/;
      for (const exhibit of exhibits) {
        if (!map.has(exhibit.exhibitDocId)) {
          map.set(exhibit.exhibitDocId, true);
          let name = exhibit.fileName.substring(0, exhibit.fileName.match(peNameRegex).index - 1);
          exhibit['peName'] = name;
          result.push(exhibit);
        }
      }
      return result;
    }
    return exhibits;
  }


  onSHPCChange(event) {
    this.isSuppHealthPremiumComparisonChanged = true;
    this.rareData.suppHealthPremiumComparison = JSON.parse(JSON.stringify(event.suppHealthPreCom));
    this.suppHealthPremiumComparison = JSON.parse(JSON.stringify(event.suppHealthPreCom));
    this.updateEditedCurrentPlanData(event.editDetails);
    this.resetAdjustedProductPercent(event.editDetails);
  }

  buildExhibitSheets(exhibitSheetsData) {
    this.exhibitSheets = [];
    exhibitSheetsData.forEach(exhibitSheetData => {
      let exhibitSheet: any = {};
      exhibitSheet.printExhibitTypeCode = exhibitSheetData.sheetCd;
      exhibitSheet.printExhibitSheetName = exhibitSheetData.sheetNm;
      exhibitSheet.sheetStatus = exhibitSheetData.dfltIncl === 'Y' ? 'Include' : 'Exclude';
      this.exhibitSheets.push(exhibitSheet);
    });
  }

  updatePEOverrideError(isError: boolean) {
    this.hasPEOverrideError = isError;
  }
  handleGRFSKResponse(data: any) {
    if (data) {
      let dataObj = JSON.parse(JSON.stringify(data));
      this.rareData.failedGuardRails = this.commonService.deepCopy(dataObj.failedGuardRails);
      this.InitialRateData.failedGuardRails = this.commonService.deepCopy(dataObj.failedGuardRails);
      this.quoteDetailsObj.failedGuardRails = this.commonService.deepCopy(dataObj.failedGuardRails);
    } else {
      this.rareData.failedGuardRails = null;
      this.InitialRateData.failedGuardRails = null;
      this.quoteDetailsObj.failedGuardRails = null;
    }
    this.reloadChildComponents();
  }

  calculateOverriddenRateGuaranteeMonths(peOverrideData) {
    if (peOverrideData.rateGuaranteeEffectiveDate || peOverrideData.rateGuaranteeEndDate) {
      return SuppHealthUtil.calculateRateGuaranteeMonths(new Date(peOverrideData.rateGuaranteeEffectiveDate), new Date(peOverrideData.rateGuaranteeEndDate));
    } else {
      return null;
    }
  }

  /**
   * This method is used to set the adjusted product percent to 0
   */
  resetAdjustedProductPercent(editDetails: any) {
    let adjustedRate = this.rareData.uwAdjustment.adjustedRates.find(rate => StringUtils.isEqualIgnoreCase(rate.ratingPlanID, editDetails.plan.quoteRatingPlanID));
    adjustedRate['uwAdjustment'] = 0;

    let featuredPlan = this.featuredPlans.find(featuredPlan => StringUtils.isEqualIgnoreCase(featuredPlan.ratingPlanID, editDetails.plan.quoteRatingPlanID));
    this.adjustmentsSuppHealthComponent.onAdjChange("0", featuredPlan, true);
  }

  /**
   * This method is used to update the edited current plan data
   * @param editDetails
   */
  updateEditedCurrentPlanData(editDetails: any) {
    let featuredPlan = this.featuredPlans.find(featuredPlan => StringUtils.isEqualIgnoreCase(featuredPlan.ratingPlanID, editDetails.plan.quoteRatingPlanID));
    if (featuredPlan) {
      let featuredPlanCurrentRateInfo = editDetails.ageBand ? featuredPlan.currentPlanRateInfo[editDetails.ageBand] : featuredPlan.currentPlanRateInfo;
      let featuredPlanRateInfo = editDetails.ageBand ? featuredPlan.ageBandRateInfo[editDetails.ageBand] : featuredPlan.rateInfo;
      const editedCurrentRates = editDetails.ageBand ? editDetails.plan.ageBandCurrentRates[editDetails.ageBand] : editDetails.plan.currentRates;

      featuredPlanCurrentRateInfo.single = editedCurrentRates.ratesT1;
      featuredPlanRateInfo.single = editedCurrentRates.ratesT1;
      const outputTier = editDetails.plan.currentTier;
      if (outputTier === 4 || outputTier === 5) {
        featuredPlanCurrentRateInfo.eeSpouse = editedCurrentRates.ratesT2;
        featuredPlanRateInfo.eeSpouse = editedCurrentRates.ratesT2;
      }
      if (outputTier === 4) {
        featuredPlanCurrentRateInfo.eeChildren = editedCurrentRates.ratesT3;
        featuredPlanRateInfo.eeChildren = editedCurrentRates.ratesT3;
      }
      if (outputTier === 5) {
        featuredPlanCurrentRateInfo.eeChild = editedCurrentRates.ratesT3;
        featuredPlanRateInfo.eeChild = editedCurrentRates.ratesT3;
        featuredPlanCurrentRateInfo.eeChildren = editedCurrentRates.ratesT4;
        featuredPlanRateInfo.eeChildren = editedCurrentRates.ratesT4;
      }
      this.setRateForFamilyFromEditedCurrentRates(outputTier, featuredPlanCurrentRateInfo, featuredPlanRateInfo, editedCurrentRates);
      this.updateAdjustedRatesByRatingPlanID(editDetails.ageBand, editDetails.plan.quoteRatingPlanID, editDetails.plan, featuredPlanRateInfo);
    }
  }

  /**
   * This method is used to set the rate for family from edited current rates
   * @param outputTier
   * @param currentRateInfo
   * @param editedCurrentRates
   */
  setRateForFamilyFromEditedCurrentRates(outputTier, currentRateInfo, rateInfo, editedCurrentRates) {
    switch (outputTier) {
      case 2:
        currentRateInfo.family = editedCurrentRates.ratesT2;
        rateInfo.family = editedCurrentRates.ratesT2;
        break;
      case 3:
        currentRateInfo.family = editedCurrentRates.ratesT3;
        rateInfo.family = editedCurrentRates.ratesT3;
        break;
      case 4:
        currentRateInfo.family = editedCurrentRates.ratesT4;
        rateInfo.family = editedCurrentRates.ratesT4;
        break;
      case 5:
        currentRateInfo.family = editedCurrentRates.ratesT5;
        rateInfo.family = editedCurrentRates.ratesT5;
        break;
    }
  }

  /**
   * This method is used to update the adjusted rates from current rate edits
   * It works on top of the adjustedRates/adjustedAgeBandedRates arrays sent with the save/submit request
   * @param ageBand
   * @param ratingPlanID
   * @param plan
   * @param featuredPlanRateInfo
   */
  updateAdjustedRatesByRatingPlanID(ageBand: string, ratingPlanID: string, plan: any, featuredPlanRateInfo: any) {
    let adjustedRates = ageBand ? this.adjustedAgeBandRates : this.adjustedRates;
    let adjustedRate = adjustedRates.find(adjustedRate => StringUtils.isEqualIgnoreCase(adjustedRate.ratingPlanID, ratingPlanID));
    if (adjustedRate) {
      if (ageBand) {
        let ageBandRateIndex = adjustedRate.ageBandRates.findIndex(obj => StringUtils.isEqualIgnoreCase(`${ obj.ageBandStart }-${ obj.ageBandEnd }`, ageBand));
        if (ageBandRateIndex !== -1) {
          adjustedRate.ageBandRates[ageBandRateIndex] = {
            ...featuredPlanRateInfo,
            ageBand: ageBand
          };
        } else {
          adjustedRate.ageBandRates.push({
            ...featuredPlanRateInfo,
            ageBand: ageBand
          });
        }
      } else {
        adjustedRate.single = featuredPlanRateInfo.single;
        adjustedRate.eeChild = featuredPlanRateInfo.eeChild;
        adjustedRate.eeChildren = featuredPlanRateInfo.eeChildren;
        adjustedRate.eeSpouse = featuredPlanRateInfo.eeSpouse;
        adjustedRate.family = featuredPlanRateInfo.family;
      }
    } else {
      if (ageBand) {
        adjustedRates.push({
          ratingPlanID: ratingPlanID,
          planName: plan.currentplanName,
          ageBandRates: [{
            ...featuredPlanRateInfo,
            ageBand: ageBand
          }]
        });
      } else {
        adjustedRates.push({
          ratingPlanID: ratingPlanID,
          planName: plan.currentplanName,
          ...featuredPlanRateInfo
        });
      }
    }
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  onUserSelectionChange(data) {
    this.userSelectionChanges = data;
  }
  updateCurvRiskScore(event:any) {
    if(event.isSSEEvent){
      this.sseCurvRiskScore = event.initialRiskScoreValue;
    }else {
      this.curvRiskScore = event.initialRiskScoreValue;
    }
    this.erFundLvlDfltVal = this.abfSLDefaultValues['ER_FUNDING_LEVEL'];
  }

  // Off-Cycle functionality
  @ViewChild(OffCycleModalComponent, { static: false }) offCycleModalComponent!: OffCycleModalComponent;

  onOffCycleOpen() {
    const modalElements = this.offCycleModalComponent?.getModalElements();
    if (modalElements) {
      this.offCycleModalService.onOffCycleOpen(this.rareData, modalElements, CommonConstants.SuppHealth);
    }
  }

  onOffCycleReasonChange() {
    this.offCycleModalService.onOffCycleReasonChange();
  }

  setDefaultOffCycleDate() {
    this.offCycleModalService.setDefaultOffCycleDate();
  }

  clickOffCycleDate() {
    this.offCycleModalService.clickOffCycleDate();
  }

  onOffCycleConfirm() {
    const success = this.offCycleModalService.onOffCycleConfirm(this.rareData, CommonConstants.SuppHealth);
    if (success) {
      this.successMessage = true;
      this.alertData = 'Off-Cycle contract end date has been updated successfully.';
      this.onApplyAdjustments('save');
    }
  }

  isContractStarted(): boolean {
    return this.offCycleModalService.isContractStarted(this.rareData?.['contractEffectiveDate']);
  }

  isSold(): boolean {
    return this.offCycleModalService.isSold(this.status?.toString() || '');
  }

  shouldShowOffCycleButton(): boolean {
    return this.offCycleModalService.shouldShowOffCycleButton(
      this.rareData?.['contractEffectiveDate'], 
      this.status?.toString() || '', 
      CommonConstants.SuppHealth,
      this.rareData?.opportunityType
    );
  }
}
