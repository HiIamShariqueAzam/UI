import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { Observable, throwError } from 'rxjs';
import { catchError, switchMap, timeout } from 'rxjs/operators';
import { ConfigService } from 'src/app/main/services/config.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { AlertType } from 'src/app/shared/models/renewal-batch-details';
import { AuthenticationService, CommonService, PrintExhibitService } from 'src/app/shared/services';
import { StringUtils } from 'src/app/shared/utils/string-utils';

@Injectable({
  providedIn: 'root'
})
export class CommonQuoteService {
  underwriterList: any = {};
  isNewReleaseFlowEnabled: boolean = true;

  alert = {
    show: false,
    message: '',
    type: '',
    cssClass: '',
    header: '',
    headerVisibility: true
  };

  constructor(
    private http: HttpClient,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private peService: PrintExhibitService,
    private configService: ConfigService
  ) {}

  setNewReleaseFlow(val) {
    this.isNewReleaseFlowEnabled = val;
  }

  /*Quotes Service*/
  getQuotes(form: FormGroup, pageLimit: number, cursor: any, sortMetaData: any): Observable<any> {
    let queryObject = {};
    let dateArray = <any>[];
    let flagFromdate: boolean = false;
    let flagTodate: boolean = false;
    let isSearchAnywhereSelected = form.value.searchAnywhere;

    Object.keys(form.controls).forEach((key) => {
      if (key === 'quoteReason') {
        queryObject[key] = form.value[key] ? { $in: ['TEST'] } : { $nin: ['TEST'] };
      } else if (key === 'alternateQuote') {
        queryObject[key] = form.value[key] ? { $in: [true, false] } : { $in: [false] };
      } else {
        if (form.value[key] != '' && form.value[key] != null) {
          if (key == 'fromdate' || key == 'todate') {
            let day = form.value[key].getDate();
            let month = form.value[key].getMonth() + 1;
            let year = form.value[key].getFullYear();
            let date = year + '-' + month + '-' + day;
            dateArray.push(date);
          } else {
            let keyValue = form.value[key];
            const keysThatMayUseRegEx = ['groupNbr', 'opportunityID', 'quoteHeaderID'];
            const keysThatShouldBeMatchedUsingStartsWith = ['underwriterName', 'accountName'];
            if (keysThatMayUseRegEx.includes(key)) {
              keyValue = this.getSearchValueBasedOnRegExFlag(keyValue, isSearchAnywhereSelected);
            } else if (keysThatShouldBeMatchedUsingStartsWith.includes(key)) {
              keyValue = this.getSearchValueForStartsWith(keyValue, isSearchAnywhereSelected);
            } else if (key === 'state') {
              keyValue = { $in: form.get('state').value };
            } else if (key === 'quoteLegalEntity') {
              keyValue = { $in: form.get('quoteLegalEntity').value };
            } else if (key === 'status') {
              keyValue = { $in: form.get('status').value };
            } else if (key === 'lob') {
              keyValue = { $in: form.get('lob').value };
            } else if (key === 'fundingType') {
              const selectedFT = form.get('fundingType').value || [];
              const quotingTypes = selectedFT.filter((ft) => [CommonConstants.ACA, CommonConstants.MEWA].includes(ft));
              const fundingTypes = selectedFT.filter((ft) => [CommonConstants.FI, CommonConstants.ABF].includes(ft));
              if (fundingTypes.length > 0) {
                keyValue = { $in: fundingTypes };
                queryObject['fundingType'] = keyValue;
              } else {
                delete queryObject['fundingType'];
                keyValue = undefined;
              }
              if (quotingTypes.length > 0) {
                queryObject['quotingType'] = { $in: quotingTypes };
              } else {
                delete queryObject['quotingType'];
              }
            } else if (key === 'opportunityType') {
              keyValue = { $in: form.get('opportunityType').value };
            } else if (key === 'mbs') {
              keyValue = { $in: form.get('mbs').value };
            } else if (key === 'quoteHasPortfolioPlans') {
              keyValue = { $in: form.get('quoteHasPortfolioPlans').value };
            } else if (key === 'quoteOrigin') {
              keyValue = { $in: form.get('quoteOrigin').value };
            }
            queryObject[key] = keyValue;
          }
        } else {
          if (key === 'fromdate') {
            flagFromdate = true;
          } else if (key === 'todate') {
            flagTodate = true;
          }
        }
      }
    });

    if (dateArray.length) {
      let key = 'contractEffectiveDate';
      let value1;
      if (dateArray.length === 2) {
        value1 = { $gte: dateArray[0] + ' 00:00:00', $lte: dateArray[1] + ' 23:59:59' };
      } else {
        if (flagFromdate) {
          value1 = { $lte: dateArray[0] + ' 23:59:59' };
        }
        if (flagTodate) {
          value1 = { $gte: dateArray[0] + ' 00:00:00' };
        }
      }
      queryObject[key] = value1;
    }
    this.removeSearchAnywhereFieldFromQueryObject(queryObject);
    let queryString = JSON.stringify(queryObject);
    this.storage.set('QuoteSearchQuery', queryString);
    let urlComponents = '?query=' + encodeURIComponent(queryString);
    if (pageLimit) {
      this.storage.set('pageLimit', pageLimit);
      urlComponents = urlComponents + '&pageLimit=' + pageLimit;
    }
    if (cursor) {
      this.storage.set('cursor', cursor);
      urlComponents = urlComponents + '&cursor=' + encodeURIComponent(JSON.stringify(cursor));
    }
    if (sortMetaData) {
      urlComponents = urlComponents + '&sortMetaData=' + encodeURIComponent(sortMetaData);
    }
    let headers = this.commonService.setRequestHeaders();

    return this.http.get<any>(this.commonService.getRareUiUrl() + '/opportunities' + urlComponents, { headers: headers });
  }

  getQuotesByQuery(queryString, pageLimit, cursor, sortMetaData) {
    let headers = this.commonService.setRequestHeaders();
    this.storage.set('QuoteSearchQuery', queryString);
    if (pageLimit) this.storage.set('pageLimit', pageLimit);
    if (cursor) this.storage.set('cursor', cursor);
    queryString = encodeURIComponent(queryString);
    if (sortMetaData) {
      queryString = queryString + '&sortMetaData=' + encodeURIComponent(JSON.stringify(sortMetaData));
    }
    if (pageLimit && cursor)
      return this.http.get<any>(
        this.commonService.getRareUiUrl() +
          '/opportunities?cursor=' +
          encodeURIComponent(JSON.stringify(cursor)) +
          '&pageLimit=' +
          pageLimit +
          '&query=' +
          queryString,
        { headers: headers }
      );
    else if (pageLimit)
      return this.http.get<any>(this.commonService.getRareUiUrl() + '/opportunities?pageLimit=' + pageLimit + '&query=' + queryString, { headers: headers });
    else return this.http.get<any>(this.commonService.getRareUiUrl() + '/opportunities?query=' + queryString, { headers: headers });
  }

  submitApplyAdjustment(
    adjValue: any,
    metaTransID: string,
    ratingTransID: string,
    removedPlanids: any,
    changeSetDetail: any,
    action: string,
    useRouterLogic: boolean,
    isInitialQuoteUpdate?: boolean
  ) {
    let formData: FormData = new FormData();
    formData.append('uw-request', adjValue);
    removedPlanids ? formData.append('removed-planids', removedPlanids) : '';
    changeSetDetail ? formData.append('uw-action-changeset', changeSetDetail) : '';
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);
    let changeset;
    let planIds;
    let request;
    if (removedPlanids) {
      planIds = removedPlanids;
    }
    if (changeSetDetail) {
      changeset = changeSetDetail;
    }
    if (isInitialQuoteUpdate) {
      request = {
        'uw-request': adjValue,
        'removed-planids': planIds,
        'uw-action-changeset': changeset,
        isInitialQuoteUpdate: isInitialQuoteUpdate
      };
    } else {
      request = {
        'uw-request': adjValue,
        'removed-planids': planIds,
        'uw-action-changeset': changeset
      };
    }
    this.setQuoteOriginIfMissing(request);
    let rareURequest = this.commonService.getRareUiRequest(request);

    var endPoint = '';
    if (useRouterLogic) {
      endPoint = '/ui/uwadjustment/';
    } else {
      endPoint = '/ui/uwadjustment/medical/';
    }
    return this.http.post<any>(this.commonService.getRareUiUrl() + endPoint + action, rareURequest,
      { headers: headers, observe: 'response' })
      .pipe(
        timeout(240000),
        catchError(err => {
          return throwError(() => new Error("Timeout has occurred"));
        }));
  }

  submitDentalApplyAdjustment(
    adjValue,
    metaTransID: string,
    ratingTransID: string,
    showDentalPremiumComparison,
    action: string,
    useRouterLogic: boolean,
    isInitialQuoteUpdate?: boolean
  ) {
    adjValue.uwAdjustment.dentalAdjustments.forEach((element, i) => {
      if (showDentalPremiumComparison) {
        if (adjValue.uwAdjustment.dentalAdjustments[i].matchCurrent) {
          delete element.ccrRate;
        } else if (adjValue.uwAdjustment.dentalAdjustments[i].matchRenewal) {
          delete element.cccRate;
        } else if (adjValue.uwAdjustment.dentalAdjustments[i].reset) {
          delete element.cccRate;
          delete element.ccrRate;
        } else {
          delete element.cccRate;
          delete element.ccrRate;
        }
      } else {
        delete element.cccRate;
        delete element.ccrRate;
      }
    });
    let formData: FormData = new FormData();
    formData.append('uw-request', JSON.stringify(adjValue));
    let request = {};
    if (isInitialQuoteUpdate) {
      request = {
        'uw-request': adjValue,
        isInitialQuoteUpdate: isInitialQuoteUpdate
      };
    } else {
      request = {
        'uw-request': adjValue
      };
    }
    this.setQuoteOriginIfMissing(request);
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);

    var endPoint = '';
    if (useRouterLogic) {
      endPoint = '/ui/uwadjustment/';
    } else {
      endPoint = '/ui/premium/cost/dental/';
    }

    return this.http.post<any>(this.commonService.getRareUiUrl() + endPoint +
      action, rareUiRequest, { headers: headers, observe: 'response' })
      .pipe(
        timeout(240000),
        catchError(err => {
          console.log(err)
          return throwError(() => new Error("Timeout has occurred"));
        }));
  }

  submitRequote(adjValue: any, metaTransID: string, ratingTransID: string, action: string) {
    let rareUiRequest = this.commonService.getRareUiRequest(adjValue);
    this.setQuoteOriginIfMissing(rareUiRequest);
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/ui/medical/" + action, rareUiRequest,
      { headers: headers, observe: 'response' })
      .pipe(
        timeout(240000),
        catchError(err => {
          return throwError(() => new Error("Timeout has occurred"));
        }));
  }

  onReleaseVisionQuote(
    metaTransID: string,
    metaSenderApp: string,
    ratingTransID: string,
    reqObj,
    action,
    useRouterLogic: boolean,
    isInitialQuoteUpdate?: boolean
  ) {
    let request = {};
    if (isInitialQuoteUpdate) {
      request = {
        'uw-request': reqObj,
        isInitialQuoteUpdate: isInitialQuoteUpdate
      };
    } else {
      request = {
        'uw-request': reqObj
      };
    }
    this.setQuoteOriginIfMissing(request);
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    let formData: FormData = new FormData();
    formData.append('uw-request', JSON.stringify(reqObj));
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);

    var endPoint = '';
    if (useRouterLogic) {
      endPoint = '/ui/uwadjustment/';
    } else {
      endPoint = '/ui/premium/cost/vision/';
    }

    return this.http.post<any>(this.commonService.getRareUiUrl() + endPoint + action, rareUiRequest,
      { headers: headers, observe: 'response' })
      .pipe(
        timeout(240000),
        catchError(err => {
          return throwError(() => new Error("Timeout has occurred"));
        }));
  }

  onReleaseSuppHealthQuote(
    metaTransID: string,
    metaSenderApp: string,
    ratingTransID: string,
    reqObj,
    action,
    useRouterLogic: boolean,
    isInitialQuoteUpdate?: boolean
  ) {
    let request = {};
    if (isInitialQuoteUpdate) {
      request = {
        'uw-request': reqObj,
        isInitialQuoteUpdate: isInitialQuoteUpdate
      };
    } else {
      request = {
        'uw-request': reqObj
      };
    }
    this.setQuoteOriginIfMissing(request);
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    let formData: FormData = new FormData();
    formData.append('uw-request', JSON.stringify(reqObj));
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);

    var endPoint = '';
    if (useRouterLogic) {
      endPoint = '/ui/uwadjustment/';
    } else {
      endPoint = '/ui/premium/cost/suppHealth/';
    }

    return this.http.post<any>(this.commonService.getRareUiUrl() + endPoint + action, rareUiRequest,
      { headers: headers, observe: 'response' })
      .pipe(
        timeout(240000),
        catchError(err => {
          return throwError(() => new Error("Timeout has occurred"));
        }));
  }

  exportQuote(obj) {
    let headers = new HttpHeaders().set('userid', this.authenticationService.getUserID()).set('username', this.authenticationService.getUserName());

    return this.http
      .get<any>(
        this.commonService.getRareUiUrl() +
          '/print/soldRates/exportFile?fundingType=' +
          obj.fundingType +
          '&lob=Dental&opportunityID=' +
          obj.opportunityID +
          '&quoteHeaderID=' +
          obj.quoteHeaderID +
          '&quoteOrigin=' +
          obj.quoteOrigin,
        { headers: headers, observe: 'response' }
      )
      .pipe(
        timeout(240000),
        catchError(err => {
          console.log(err)
          return throwError(() => new Error("Timeout has occurred"));
        }));
  }

  removeHistorySessionStorage() {
    this.storage.remove('quoteHeaderID');
    this.storage.remove('quoteOrigin');
    this.storage.remove('opportunityID');
    this.storage.remove('ratingTransID');
    this.storage.remove('lob');
    this.storage.remove('fundingType');
    this.storage.remove('availableTabs');
    this.storage.remove('isLoginAgain');
    this.storage.remove('disableAll');
    this.storage.remove('insertedTimestamp');
    this.storage.remove('quoteHistoryId');
    this.storage.remove('version');
  }

  getUnderWriters() {
    return this.http.get<any>('assets/mock-jsons/underwriter.json');
  }

  getUnderwriters() {
    let headers = this.commonService.setRequestHeaders();
    const apiUrl = this.commonService.getRareUiUrl() + '/ui/manager/underwriters?key='
    this.configService.updateAPIInLocalStorage(apiUrl,false,headers,CommonConstants.UNDERWRITERS).subscribe(
    (response) => {
        Object.keys(response).forEach((key) => {
          let uwStatewiseList = [];
          response[key].forEach((val) => {
            let uwDetails = {};
            uwDetails['label'] = val;
            uwDetails['value'] = val;
            uwStatewiseList.push(uwDetails);
          });
          this.underwriterList[key] = uwStatewiseList;
        });
      },
      (err) => {
        alert('Error in getting response from getUnderwriters API....' + err);
      }
    );
  }

  shouldDisableTab(selectedTabName) {
    let statusListForDisablingTab = ['received', 'processing', 'awaiting risk score'];
    //Do not disable for ADMIN roles.
    //For ADMIN + READ ONLY we want to keep it disabled
    if (this.authenticationService.isUserRoleAdmin(this.commonService.getUserRoles()) && !this.commonService.hasReadOnlyRole()) return false;
    if (typeof this.commonService.getStatusforTab(selectedTabName) != 'undefined') {
      let lowerCaseTabStatus = this.commonService.getStatusforTab(selectedTabName).toLowerCase();
      return statusListForDisablingTab.includes(lowerCaseTabStatus);
    }
  }

  downLoadCensus(censusRefId, lob, quoteID, opportunityType, groupNumber?) {
    let reqHeaders = this.commonService.setRateInfoHeaders();
    reqHeaders = reqHeaders
      .set('Access-Control-Allow-Origin', '*')
      .set('Content-Type', 'application/json')
      .set('Access-Control-Expose-Headers', 'TestHeaderToExpose');

    const parameters = new HttpParams()
      .set('lob', lob)
      .set('censusRefId', censusRefId)
      .set('opportunityType', opportunityType)
      .set('isFullCensusAccessible', this.authenticationService.isCensusPrivilegedUser(this.commonService.assignedUserGroup));
    return this.http
      .get<any>(this.commonService.getRareUiUrl() + '/generate/census', {
        params: parameters,
        headers: reqHeaders,
        responseType: 'arraybuffer' as 'json'
      })
      .subscribe(
        (response) => {
          if (response) {
            let fileName = 'Census_' + quoteID + (groupNumber && opportunityType === 'Renewal Local' ? '_' + groupNumber : '') + '.xlsx';
            this.peService.createAndDownloadBlobFile(response, fileName);
          }
        },
        (error) => {
          alert('Error while generating census response: ' + error);
        }
      );
  }

  // Fetch experience Summary
  getRenewalExperienceSummary(
    opportunityID?: string,
    quoteHeaderID?: string,
    quoteOrigin?: string,
    fundingType?: string,
    lob?: string,
    ratingTransID?: string
  ): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/groupExperienceSummary', {
      params: new HttpParams()
        .set('opportunityID', opportunityID)
        .set('quoteHeaderID', quoteHeaderID)
        .set('quoteOrigin', quoteOrigin)
        .set('fundingType', fundingType)
        .set('lob', lob)
        .set('rating-transid', ratingTransID),
      headers: header
    });
  }
  printRenewalExperienceSummary(data: any): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/groupExperienceSummary/download', requestData, {
      headers: header,
      observe: 'response'
    });
  }

  specialtyRequoteErr: string = '';
  onSpecialtyRequote(adjValue: any, metaTransID, ratingTransID, action) {
    this.setQuoteOriginIfMissing(adjValue);
    let rareUiRequest = this.commonService.getRareUiRequest(adjValue);
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/ui/medical/" + action, rareUiRequest,
      { headers: headers, observe: 'response' })
      .pipe(
        timeout(240000),
        catchError(err => {
          console.log(err);
          this.specialtyRequoteErr = err.error ? err.error : '';
          return throwError(() => new Error("Timeout has occurred"));
        }));
  }

  getDeclineOptions(obj, ratingTransID) {
    let headers = this.commonService.setRequestHeaders();
    let lob = obj.lob ? obj.lob : obj.lob1;
    let params = { lob: lob, fundingType: obj.fundingType, ratingTransID: ratingTransID };
    const parameters = new HttpParams().appendAll(params);
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/ui/decline-reasons?', { params: parameters, headers: headers });
  }

  getStatusReasonsOptions(lob, fundingType, ratingTransID) {
    const headers = this.commonService.setRequestHeaders();
    const params = new HttpParams().set('lob', lob).set('fundingType', fundingType).set('ratingTransID', ratingTransID);

    const url = `${this.commonService.getRareUiUrl()}/ui/status-reasons`;
    return this.http.get<any>(url, { params, headers });
  }

  generatePrintExhibit(adjValue, metaTransID, ratingTransID, quoteErrorCode) {
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);
    let formData: FormData = new FormData();
    formData.append('uw-request', adjValue);
    formData.append('errorCode', quoteErrorCode);
    let request = {
      'uw-request': adjValue,
      errorCode: quoteErrorCode
    };
    this.setQuoteOriginIfMissing(request);
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/opportunity/quote/generate-print-exhibit', rareUiRequest, {
      headers: headers,
      observe: 'response'
    });
  }

  getRateInfoVision(ratingTransID: String, oppID: String, quoteHeaderID: String, quoteOrigin: String, lob: String, fundingType: String) {
    let epochTime = new Date().getTime();
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(
      this.commonService.getRareUiUrl() +
        '/quoteDetails/vision/initialResponse?opportunityID=' +
        oppID +
        '&rating-transid=' +
        ratingTransID +
        '&quoteHeaderID=' +
        quoteHeaderID +
        '&quoteOrigin=' +
        quoteOrigin +
        '&fundingType=' +
        fundingType +
        '&lob=' +
        lob +
        '&epochTime=' +
        epochTime,
      { headers: headers }
    );
  }

  getRateInfoSuppHealth(ratingTransID: String, oppID: String, quoteHeaderID: String, quoteOrigin: String, lob: String, fundingType: String) {
    let epochTime = new Date().getTime();
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(
      this.commonService.getRareUiUrl() +
        '/quoteDetails/supphealth/initialResponse?opportunityID=' +
        oppID +
        '&rating-transid=' +
        ratingTransID +
        '&quoteHeaderID=' +
        quoteHeaderID +
        '&quoteOrigin=' +
        quoteOrigin +
        '&fundingType=' +
        fundingType +
        '&lob=' +
        lob +
        '&epochTime=' +
        epochTime,
      { headers: headers }
    );
  }

  getRateInfo(ratingTransID: String, oppID: String, quoteHeaderID: String, quoteOrigin: String, lob: String, fundingType: String) {
    let epochTime = new Date().getTime();
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(
      this.commonService.getRareUiUrl() +
        '/quoteDetails?opportunityID=' +
        oppID +
        '&rating-transid=' +
        ratingTransID +
        '&quoteHeaderID=' +
        quoteHeaderID +
        '&quoteOrigin=' +
        quoteOrigin +
        '&fundingType=' +
        fundingType +
        '&lob=' +
        lob +
        '&epochTime=' +
        epochTime,
      { headers: headers }
    );
  }

  getRateInfoInitialResponse(ratingTransID: String, oppID: String, quoteHeaderID: String, quoteOrigin: String, lob: String, fundingType: String) {
    let epochTime = new Date().getTime();
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(
      this.commonService.getRareUiUrl() +
        '/quoteDetails/medical/initialResponse?opportunityID=' +
        oppID +
        '&rating-transid=' +
        ratingTransID +
        '&quoteHeaderID=' +
        quoteHeaderID +
        '&quoteOrigin=' +
        quoteOrigin +
        '&fundingType=' +
        fundingType +
        '&lob=' +
        lob +
        '&epochTime=' +
        epochTime,
      { headers: headers }
    );
  }

  getPrintExhibitInfo(ratingTransID: any, lob: any) {
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/printExhibits?rating-transid=' + ratingTransID + '&lob=' + lob, { headers: headers });
  }

  getOldQuotes(
    opportunityID: String,
    lob: String,
    quoteHeaderID: String,
    fundingType: String,
    quoteOrigin: String,
    alternateQuote?: boolean,
    quotingType?: String,
    opportunityType?: string
  ) {
    let headers = this.commonService.setRequestHeaders();
    const alternateQuoteValue = alternateQuote ?? false;
    const quotingTypeValue = quotingType ?? '';
    let url =
      this.commonService.getRareUiUrl() +
      '/opportunities/oldQuotes?opportunityID=' +
      opportunityID +
      '&lob=' +
      lob +
      '&quoteHeaderID=' +
      quoteHeaderID +
      '&fundingType=' +
      fundingType +
      '&quoteOrigin=' +
      quoteOrigin +
      '&alternateQuote=' +
      alternateQuoteValue +
      '&quotingType=' +
      quotingTypeValue +
      "&opportunityType=" +
      opportunityType;
    return this.http.get<any>(url, { headers: headers });
  }

  getAdjustmentHistory(ratingTransID: String, oppID: String, quoteHeaderID: String, quoteOrigin: String, lob: String, fundingType: String) {
    let epochTime = new Date().getTime();
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(
      this.commonService.getRareUiUrl() +
        '/uwAdjustment/history?opportunityID=' +
        oppID +
        '&rating-transid=' +
        ratingTransID +
        '&quoteHeaderID=' +
        quoteHeaderID +
        '&quoteOrigin=' +
        quoteOrigin +
        '&fundingType=' +
        fundingType +
        '&lob=' +
        lob +
        '&epochTime=' +
        epochTime,
      { headers: headers }
    );
  }

  getOpportunitesByOppID(queryString: any, lob: any, sortMetaData?: any) {
    let headers = this.commonService.setRequestHeaders();
    queryString = '%7B%22opportunityID%22%3A%22' + queryString + '%22%7D';
    let urlComponents = this.commonService.getRareUiUrl() + '/opportunities?query=' + queryString + '&lob=' + lob;
    if (sortMetaData) {
      urlComponents += '&sortMetaData=' + encodeURIComponent(JSON.stringify(sortMetaData));
    }
    return this.http.get<any>(urlComponents, { headers: headers });
  }

  getSendToOpportunitesByOppID(queryString: any, lob: any, sortMetaData?: any) {
    let headers = this.commonService.setRequestHeaders();
    queryString = encodeURIComponent(JSON.stringify({
      lob: { $in: [lob] },
      opportunityID: queryString
    }));
    let urlComponents = this.commonService.getRareUiUrl() + '/opportunities?query=' + queryString;
    if (sortMetaData) {
      urlComponents += '&sortMetaData=' + encodeURIComponent(JSON.stringify(sortMetaData));
    }
    return this.http.get<any>(urlComponents, { headers: headers });
  }

  getFileFromFilenet(exhibitDocId) {
    let headers = this.commonService.setRequestHeaders();
    let request = {
      exhibitDocId: exhibitDocId
    };
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/opportunity/quote/exhibits/get-exhibit', rareUiRequest, { headers: headers });
  }

  getViewCalcExcel(metaTransID, ratingTransID, viewCalcDetails) {
    let headers = this.commonService.setSubmitHeadersSoldRate(metaTransID, ratingTransID);
    let metadata = {
      userid: this.authenticationService.getUserID(),
      username: this.authenticationService.getUserName()
    };
    viewCalcDetails['metadata'] = metadata;
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/calculationSheet/download', viewCalcDetails, { headers: headers });
  }

  cleanUpSSEEvents(processId) {
    let headers = this.commonService.setRequestHeaders();
    this.http
      .get<any>(this.commonService.getRareUiUrl() + '/clear/sse-events?processId=' + processId, { headers: headers, responseType: 'text' as 'json' })
      .subscribe(
        (response) => {
          console.log(processId + ' = ' + response);
        },
        (error) => {
          console.error(error);
        }
      );
  }

  useRouterLogicToProcess(action: string) {
    var useRouterLogic = false;
    var routerallowedActions = ['release', 'decline', 'save'];
    if (routerallowedActions.includes(action) && this.isNewReleaseFlowEnabled) {
      useRouterLogic = true;
    }
    return useRouterLogic;
  }

  dashboardIcon(batchId) {
    this.dashboardIconUrl(batchId).subscribe((response) => {
      const url = response.description;
      if (url) {
        window.open(url, '_blank');
      }
    });
  }

  dashboardIconUrl(batchID) {
    let headers = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/renewalDashboard/' + batchID, { headers: headers });
  }

  sendToOpportunitiesQuote(oppID, lob, fundingType, ratingTransId, altQuoteSelectorDetails: any = null) {
    let headers = this.commonService.setRequestHeaders();
    let sortMetaData = [{ field: 'lob', order: 1 }];
    return this.getSendToOpportunitesByOppID(oppID, lob, sortMetaData).pipe(
      switchMap((response) => {
        // Prepare request data
        let requestData = {
          metadata: {
            userid: this.authenticationService.getUserID(),
            username: this.authenticationService.getUserName()
          },
          data: {
            rareQuoteKeys: response.opportunities.map((opp) => ({
              quoteHeaderID: opp.quoteHeaderID,
              opportunityID: opp.opportunityID,
              quoteOrigin: opp.quoteOrigin,
              ratingTransID: this.prepareRatingTransId(ratingTransId, opp.ratingTransID, fundingType, opp.fundingType, lob, opp.lob),
              lob: opp.lob,
              fundingType: opp.fundingType,
			  quotingType: opp.quotingType
            }))
          }
        };


        if(altQuoteSelectorDetails) {
          requestData.data.rareQuoteKeys = requestData.data.rareQuoteKeys.filter((item) => item.quoteHeaderID === altQuoteSelectorDetails.quoteHeaderID
           && item.fundingType === altQuoteSelectorDetails.fundingType && item.lob === altQuoteSelectorDetails.lob);
        }
        // Call the sendToOpportunities API
        return this.http.post<any>(this.commonService.getRareUiUrl() + '/sendToOpportunities', requestData, { headers: headers });
      })
    );
  }

  prepareRatingTransId(ratingTransId, oppRatingTransId, fundingType, oppFundingType, lob, oppLob) {
    if (StringUtils.isEqual(lob, oppLob) && StringUtils.isEqual(fundingType, oppFundingType)) {
      return ratingTransId;
    } else {
      return oppRatingTransId;
    }
  }

  convertAutoRunToRegularGroup(metaTransID, ratingTransID, requestObj) {
    let headers = this.commonService.setAdjHeaders(metaTransID, ratingTransID);
    let requestData = {
      metadata: {
        userid: this.authenticationService.getUserID(),
        username: this.authenticationService.getUserName(),
        emailId: this.authenticationService.getUserEmail(),
        role: this.authenticationService.getUserRole()
      },
      data: {
        opportunity: requestObj
      }
    };
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/autorun/convert', requestData, { headers: headers });
  }

  setQuoteOriginIfMissing(request) {
    if (request && request['uw-request'] && request['uw-request'].opportunity) {
      let opportunity = request['uw-request'].opportunity;
      if (!opportunity.quoteOrigin) {
        this.route.queryParams.subscribe((params) => {
          opportunity.quoteOrigin = params[CommonConstants.QUOTE_ORIGIN];
        });
      }
    }
  }
  getRiskScoreDetails(ratingTransID?: string): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/risk/score', {
      params: new HttpParams().set('ratingTransId', ratingTransID),
      headers: header
    });
  }

  getCuCollection(ratingTransID?: string): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/customizationRequestData', {
      params: new HttpParams().set('rating-transid', ratingTransID),
      headers: header
    });
  }

  updateDentalQuoteStatus(ratingTransID?: string, ratingPlanID?: string, transactionId?: string): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    return this.http.post<any>(
      this.commonService.getRareUiUrl() + '/updateDentalQuoteStatus?ratingTransID=' + ratingTransID + '&ratingPlanID=' + ratingPlanID + '&transactionId=' + transactionId,
      {},
      {
      headers: header
      }
    );
  }

  calculateRateGuaranteeMonths(date1: Date, date2: Date) {
    // Calculate the difference in months regardless of the day
    let months = (date2.getFullYear() - date1.getFullYear()) * 12 + (date2.getMonth() - date1.getMonth());
    // If the end date's day is greater than or equal to the start date's day, count as a full month
    if (date2.getDate() >= date1.getDate()) {
      months += 1;
    }
    // Always return at least 0
    return months <= 0 ? 0 : months;
  }

  /**
   * Calculates the Rate End Date given the Rate Effective Date and number of months.
   * @param rateEffDate The Rate Effective Date
   * @param months The number of months for the rate guarantee
   * @returns The Rate End Date (last day of the month, (months-1) months after rateEffDate)
   */
  calculateRateEndDate(rateEffDate: Date, months: number): Date {
    if (!rateEffDate || !months || months < 1) return rateEffDate;
    // Add (months - 1) months to the effective date
    const year = rateEffDate.getFullYear();
    const month = rateEffDate.getMonth() + (months - 1);
    // Set to the last day of the resulting month
    return new Date(year, month + 1, 0);
  }

  /**
   * Returns the search value based on whether search anywhere is selected.
   * If RegEx is selected, it returns a regex pattern; otherwise, it returns the trimmed value.
   * @param value The value to be searched.
   * @param isSearchAnywhereSelected Boolean indicating if RegEx search is selected.
   */
  getSearchValueBasedOnRegExFlag(value: string, isSearchAnywhereSelected: boolean): any {
    const escapedValue = this.commonService.escapeRegExp(value.trim());
    return isSearchAnywhereSelected ? { $regex: '.*' + escapedValue + '.*' } : value.trim();
  }

  /**
     * Returns a search value for "starts with" matching, optionally using a RegExp pattern.
     * If `isSearchAnywhereSelected` is true, returns a RegExp pattern that matches the value anywhere in the string.
     * Otherwise, returns a RegExp pattern that matches values starting with the given value.
     * @param value The string value to search for.
     * @param isSearchAnywhereSelected Whether to use a RegExp pattern for "anywhere" matching.
     * @returns An object representing the search pattern for use in queries.
     */
  getSearchValueForStartsWith(value: string, isSearchAnywhereSelected: boolean): any {
    const escapedValue = this.commonService.escapeRegExp(value.trim());
    return isSearchAnywhereSelected ? { $regex: '.*' + escapedValue + '.*' } : { $regex: '^' + value.trim() };
  }

  /**
   * Removes the 'searchAnywhere' field from the query object if it exists.
   * This is used to clean up the query object before sending it to the server.
   * @param queryObject The query object to modify.
   */
  removeSearchAnywhereFieldFromQueryObject(queryObject: {}) {
    if (queryObject && typeof queryObject === 'object' && 'searchAnywhere' in queryObject) {
      delete queryObject['searchAnywhere'];
    }
  }

  setAlertVisibility(visibility: boolean, type = '', message: string = '', headervisibility?: boolean) {
    window.scroll(0, 0);
    this.alert.show = visibility;
    this.alert.type = type || '';
    this.alert.message = message;
    this.alert.cssClass = type === AlertType.ERROR ? 'alert-danger' : `alert-${type}`;
    this.alert.header = type === AlertType.ERROR ? 'failed' : type;
    if (headervisibility != undefined) {
      this.alert.headerVisibility = headervisibility;
    }
  }

  fetchGroupExperienceForNewBusiness(ratingTransID: string, lob: string): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    const params = { 'rating-transid': ratingTransID, lob: lob };
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/newBusiness/groupExperience', {
      params: new HttpParams().appendAll(params),
      headers: header
    });
  }
}
