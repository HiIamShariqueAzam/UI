import { TestBed } from '@angular/core/testing';

import { CommonQuoteService } from './common-quote.service';

describe('CommonQuoteService', () => {
  let service: CommonQuoteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommonQuoteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
