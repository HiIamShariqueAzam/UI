import { Component, OnInit, OnChanges, SimpleChanges, Input, EventEmitter, Output, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { CommonUtil } from 'src/app/shared/utils/common-util';

@Component({
  selector: 'app-search-preference',
  templateUrl: './search-preference.component.html',
  styleUrls: ['./search-preference.component.css'],
  standalone: false,
})
export class SearchPreferenceComponent implements OnInit, OnChanges, AfterViewInit  {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;

  @Input() preferenceData: any[];
  @Input() currentPreference: any;
  preferenceValue: any;
  @Output()
  getPreferenceOP = new EventEmitter< any >();
  @Output()
  savePreferenceOP = new EventEmitter< any >();
  @Output()
  deletePreferenceOP = new EventEmitter< any >();
  @Output()
  defaultPreferenceOP = new EventEmitter< any >();

  columns = [
    {
      header: "Criteria Name",
      field: "preferenceName"
    },
    {
      header: "Default?",
      field: "isDefault"
    },
    {
      header: "Criteria",
      field: "preferences"
    },
    {
      header: "Delete",
      field: "id"
    }
  ];


  constructor(
    config: NgbModalConfig,
    private datePipe: DatePipe
  ) {
    config.backdrop = "static";
    config.keyboard = false;

  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [footer]);
  }

  ngOnChanges(changes: SimpleChanges) {
    this.preferenceValue = this.currentPreference;
  }

  ngOnInit() {
  }

  getPreferenceValue(preference: any) {
    let value = '';
    if (preference) {
      let keys = Object.keys(preference);
      for (var i = 0, n = keys.length; i < n; i++) {
        let key = keys[i];
        if (preference[key] && Array.isArray(preference[key])) {
          preference[key].forEach(function (data) {
            value = value + data + ', ';
          });
        }
        else {
          if (preference[key]){
            if(key === 'fromDate' || key === 'toDate'){
              value = value + this.datePipe.transform(preference[key], 'MM-dd-yyyy') + ', ';
            }
            else{
              value = value + preference[key] + ', ';
            }
          }
        }

      }
      if (value.charAt(value.length - 2) == ',') {
        value = value.substr(0, value.length - 2);
      }
      return value;
    }
    else
      return "";
  }

  onGoToOppScreen(preference: any, preferenceName: any) {
    this.getPreferenceOP.emit({preference, preferenceName});
    this.preferenceValue = preferenceName;
  }

  updatePreference(event) {
    this.preferenceValue = event.target.value;
  }

  createPreference() {
    if(this.preferenceValue){
    this.savePreferenceOP.emit(this.preferenceValue);
    }
  }

  deletePreference(id: any) {
    this.deletePreferenceOP.emit(id);
  }

  changeAsDefault(preferenceObj: any, isChecked: any) {
    this.defaultPreferenceOP.emit({preferenceObj, isChecked});
  }

}
