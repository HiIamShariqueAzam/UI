import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { SearchPreferenceComponent } from './search-preference.component';

describe('SearchPreferenceComponent', () => {
  let component: SearchPreferenceComponent;
  let fixture: ComponentFixture<SearchPreferenceComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchPreferenceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPreferenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
