import {CommonConstants} from 'src/app/shared/constants/common.constants';

export class SearchConstants {
  public static SUPP_Health = 'Supp Health';
  public static OPPORTUNITY_TYPE_LIST = [
    { "label": "New Business Local", "value": "New Business Local" },
    { "label": "Renewal Local", "value": "Renewal Local" }
  ];
  public static LOB_LIST = CommonConstants.LOB_LIST;
  public static FUNDING_TYPE_LIST = CommonConstants.FUNDING_TYPE_LIST_QUOTE;
  public static QUOTING_TYPE_LIST = CommonConstants.QUOTING_TYPE_LIST_QUOTE;
  public static STATUS_LIST = [
    { "label": "Pending Review", "value": "Pending Review" },
    { "label": "Released", "value": "Released" },
    { "label": "Declined", "value": "Declined" },
    { "label": "Modified", "value": "Modified" },
    { "label": "Pre-Sold", "value": "Pre-Sold" },
    { "label": "Sold", "value": "Sold" },
    { "label": "Failed", "value": "Failed" },
    { "label": "Partial Success", "value": "Partial Success" },
    { "label": "Sold Modified", "value": "Sold Modified" },
    { "label": "Awaiting Risk Score", "value": "Awaiting Risk Score" },
    { "label": "Received", "value": "Received" },
    { "label": "Processing", "value": "Processing" },
    { "label": "Lost", "value": "Lost" },
    { "label": "Missing Information", "value": "Missing Information" },
    { "label": "In Analysis", "value": "In Analysis" },
    { "label": "Awaiting P2A data", "value": "Awaiting P2A data" },
    { "label": "Ready to Export", "value": "Ready to Export" },
    { "label": "Exported", "value": "Exported" },
    { "label": "Termed", "value": "Termed" },
    { "label": "Transfer", "value": "Transfer" },
    { "label": "Pending Exhibit", "value": "Pending Exhibit" },
    { "label": "Close", "value": "Close" },
    { "label": "Pending Customization", "value": "Pending Customization" },
    { "label": "Sold-Pending UW Review", "value": "Sold-Pending UW Review" }
  ];

  public static DEFAULT_STATUS_LIST = [
    'Released',
    'Pending Review',
    'Modified',
    'Sold Modified',
    'Pre-Sold',
    'Failed',
    'Declined',
    'Sold',
    'Lost',
    'Missing Information',
    'In Analysis',
    'Termed',
    'Transfer',
    'Close',
    'Sold-Pending UW Review',
    'Awaiting Risk Score'
  ];

  public static DEFAULT_QUOTE_ORIGIN_LIST = ['partnerAPI', 'convertedAutoRun', 'oppScreen', 'userBatch'];

  public static MBS_LIST = [
    { "label": "Key", "value": "Key" },
    { "label": "Non-Key", "value": "Non-Key" },
    { "label": "SG", "value": "SG" }
  ];

  public static HAS_PORTFOLIO_PLANS_LIST = [
    { "label": "Yes", "value": true },
    { "label": "No", "value": false }
  ];

  public static OUOTE_SEARCH_TABLE_COLUMN = [
		{
			"header": "Opp",
			"field": "opportunityType"
		}, {
			"header": "Opportunity ID",
			"field": "opportunityID"
		}, {
			"header": "Quote ID",
			"field": "quoteHeaderID"
		}, {
			"header": "LOBs-FA",
			"field": "lob"
		}, {
			"header": "Group Name",
			"field": "accountName"
		}, {
			"header": "Eff Date",
			"field": "contractEffectiveDate"
		}, {
			"header": "State",
			"field": "state"
		}, {
			"header": "UW Name",
			"field": "underwriterName"
		}, {
			"header": "Mkt Seg",
			"field": "marketSegment"
		}, {
			"header": "MBS",
			"field": "mbs"
		}, {
			"header": "Status",
			"field": "status"
		}
	];
}
