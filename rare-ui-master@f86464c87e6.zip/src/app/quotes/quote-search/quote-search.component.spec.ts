import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { OidcSecurityService, AuthModule } from 'angular-auth-oidc-client';
import { ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { RadioButtonModule } from 'primeng/radiobutton';
import { By } from '@angular/platform-browser';
import { provideAnimations } from '@angular/platform-browser/animations';
import { CommonService } from 'src/app/shared/services';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { QuoteSearchComponent } from './quote-search.component';
describe('QuoteComponent', () => {
  let component: QuoteSearchComponent;
  let fixture: ComponentFixture<QuoteSearchComponent>;
  let fromDateCalendar;
  let toDateCalendar;
  let searchButton;
  let rate_exhibit;
  let select_opportunity;
  let commonService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QuoteSearchComponent],
      imports: [ReactiveFormsModule, FlexLayoutModule, TableModule, ButtonModule, CalendarModule, RadioButtonModule,
        AuthModule.forRoot()],
      providers: [provideAnimations(), provideHttpClient(), FormBuilder, {
        provide: Router,
        useClass: class { navigate = jasmine.createSpy("navigate"); },
        OidcSecurityService
      }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteSearchComponent);
    component = fixture.componentInstance;
    fromDateCalendar = fixture.debugElement.query(By.css('.fomDateCalendar'));
    toDateCalendar = fixture.debugElement.query(By.css('.toDateCalendar'));
    searchButton = fixture.debugElement.query(By.css('.opportunity_search'));
    rate_exhibit = fixture.debugElement.query(By.css('#rate_exhibit'));
    select_opportunity = fixture.debugElement.query(By.css('.select_opportunity'));
    commonService = TestBed.get(CommonService);
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });

  xit('should trigger fromDate click', () => {
    fromDateCalendar.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css(".ui-datepicker"))).toBeTruthy();
  });

  xit('should trigger toDate click', () => {
    toDateCalendar.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css(".ui-datepicker"))).toBeTruthy();
  });

  xit('should trigger Select Opportunity button click', () => {
    component.selectOpportunity = false;
    component.onSelectOpportunity();
    expect(component.selectOpportunity).toBe(true);
  });


  xit('should trigger Rate Exhibit button click', () => {
    component.rateExhibit = false;
    component.onRateExhibit();
    expect(component.rateExhibit).toBe(true);
  });

  xit('should call Search click', () => {
    let response =
    {
      "cols": [
        {
          "header": "Opportunity ID",
          "field": "Opportunity_ID"
        },
        {
          "header": "Group Name",
          "field": "Group_Name"
        },
        {
          "header": "Effective Date",
          "field": "Effective_Date"
        },
        {
          "header": "UW Name",
          "field": "UW_Name"
        },
        {
          "header": "Pending UW Approval",
          "field": "Pending_UW_Approval"
        }
      ],
      "rowData": [
        {
          "Opportunity_ID": "ADF",
          "Group_Name": "Group1",
          "Effective_Date": "2/25/2020",
          "UW_Name": "Name1",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "GFGFG",
          "Group_Name": "Group2",
          "Effective_Date": "2/26/2020",
          "UW_Name": "Name2",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "ZFGFG",
          "Group_Name": "Group3",
          "Effective_Date": "2/28/2020",
          "UW_Name": "Name3",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "RFGFG",
          "Group_Name": "Group4",
          "Effective_Date": "2/29/2020",
          "UW_Name": "Name4",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "QFGF",
          "Group_Name": "Group5",
          "Effective_Date": "3/2/2020",
          "UW_Name": "Name5",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "YHJHJH",
          "Group_Name": "Group6",
          "Effective_Date": "4/25/2020",
          "UW_Name": "Name6",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "CHRH",
          "Group_Name": "Group7",
          "Effective_Date": "5/26/2020",
          "UW_Name": "Name7",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "TGHHT",
          "Group_Name": "Group8",
          "Effective_Date": "6/27/2020",
          "UW_Name": "Name8",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "HJH",
          "Group_Name": "Group9",
          "Effective_Date": "7/25/2020",
          "UW_Name": "Name9",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "WTRY",
          "Group_Name": "Group10",
          "Effective_Date": "8/25/2020",
          "UW_Name": "Name10",
          "Pending_UW_Approval": "yes"
        }
      ]
    }
    let form: FormGroup;
    spyOn(commonService, 'getQuotes').and.returnValue(of(response));
    fixture.detectChanges();
    component.onSubmit(form);
    expect(commonService.getQuotes).toHaveBeenCalled();
  });

  xit('should call Search click error case', () => {
    let response =
    {
      "cols": [
        {
          "header": "Opportunity ID",
          "field": "Opportunity_ID"
        },
        {
          "header": "Group Name",
          "field": "Group_Name"
        },
        {
          "header": "Effective Date",
          "field": "Effective_Date"
        },
        {
          "header": "UW Name",
          "field": "UW_Name"
        },
        {
          "header": "Pending UW Approval",
          "field": "Pending_UW_Approval"
        }
      ],
      "rowData": [
        {
          "Opportunity_ID": "ADF",
          "Group_Name": "Group1",
          "Effective_Date": "2/25/2020",
          "UW_Name": "Name1",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "GFGFG",
          "Group_Name": "Group2",
          "Effective_Date": "2/26/2020",
          "UW_Name": "Name2",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "ZFGFG",
          "Group_Name": "Group3",
          "Effective_Date": "2/28/2020",
          "UW_Name": "Name3",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "RFGFG",
          "Group_Name": "Group4",
          "Effective_Date": "2/29/2020",
          "UW_Name": "Name4",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "QFGF",
          "Group_Name": "Group5",
          "Effective_Date": "3/2/2020",
          "UW_Name": "Name5",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "YHJHJH",
          "Group_Name": "Group6",
          "Effective_Date": "4/25/2020",
          "UW_Name": "Name6",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "CHRH",
          "Group_Name": "Group7",
          "Effective_Date": "5/26/2020",
          "UW_Name": "Name7",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "TGHHT",
          "Group_Name": "Group8",
          "Effective_Date": "6/27/2020",
          "UW_Name": "Name8",
          "Pending_UW_Approval": "yes"
        },
        {
          "Opportunity_ID": "HJH",
          "Group_Name": "Group9",
          "Effective_Date": "7/25/2020",
          "UW_Name": "Name9",
          "Pending_UW_Approval": "No"
        },
        {
          "Opportunity_ID": "WTRY",
          "Group_Name": "Group10",
          "Effective_Date": "8/25/2020",
          "UW_Name": "Name10",
          "Pending_UW_Approval": "yes"
        }
      ]
    }
    let form: FormGroup;
    spyOn(commonService, 'getQuotes').and.returnValue(throwError("Error"));
    fixture.detectChanges();
    component.onSubmit(form);
    expect(commonService.getQuotes).toHaveBeenCalled();
  });
  it('should call Search click error case', () => {
    /* let fb:FormBuilder;
    component.opportunity_form = fb.group({
			group_name: ['', [Validators.required, Validators.pattern(this.alphaNumericPattern)]],
			approval: ['', Validators.required],
			uw_name: ['', [Validators.required, Validators.pattern(this.alphaNumericPattern)]],
			opportunity_id: ['', [Validators.required, Validators.pattern(this.alphaNumericPattern)]],
			fromdate: ['Mon Mar 09 2020 00:00:00 GMT+0530 (India Standard Time)', Validators.required],
			todate: ['Tue Mar 10 2020 00:00:00 GMT+0530 (India Standard Time)', Validators.required],
		},
			{
				validator: this.validateDate('fromdate', 'todate'),
			}
    ); */
    let fb:FormBuilder;
    component.testDate=false;
    component.ngOnInit();
    debugger;
   /*  component.opportunity_form.value["fromdate"]='Mon Mar 09 2020 00:00:00 GMT+0530 (India Standard Time)';
    let fromdate='Mon Mar 09 2020 00:00:00 GMT+0530 (India Standard Time)';
    let todate='Tue Mar 10 2020 00:00:00 GMT+0530 (India Standard Time)'; */
    component.opportunity_form.value["fromdate"]='Mon Mar 09 2020 00:00:00 GMT+0530 (India Standard Time)';
    fixture.detectChanges();
       //component.validateDate(fromdate,todate);
    expect(component.testDate).toBe(true);
  });

  xit('should call Search click error case', () => {
    component.testDate=false;
    component.ngOnInit();
    let todate='03/05/2020';
    let fromdate='03/04/2020';
    component.validateDate(fromdate,todate);
    expect(component.testDate).toBe(true);
  });
});
