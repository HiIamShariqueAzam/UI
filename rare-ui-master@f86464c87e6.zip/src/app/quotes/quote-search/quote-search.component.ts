import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { OpportunityForm } from 'src/app/shared/models/quoteDetails';
import { AlertType, QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { HttpClientService } from 'src/app/shared/services/http-client.service';
import { StringUtils } from "../../shared/utils/string-utils";
import { CommonQuoteService } from '../services/common-quote.service';
import { SearchConstants } from './constants';

@Component({
	selector: 'app-quote-search',
	templateUrl: './quote-search.component.html',
	styleUrls: ['./quote-search.component.css'],
	standalone: false,
	providers: [NgbModalConfig, NgbModal]
})
export class QuoteSearchComponent implements OnInit {
	[x: string]: any;
	isSmallGroupIntakeEnabled: boolean = false;
	opportunitySubmit: any;
	rateExhibit: boolean = false;
	selectOpportunity: boolean = false;
	showOpportunities: boolean = false;
	showNextButton: boolean = false;
	showPrevButton: boolean = false;
	nextCursor: any;
	prevCursor: any;
	testDate: boolean = false;
	filteredUnderwritersSingle: any[];
	dateTime = new Date();
	opportunity_form: FormGroup<OpportunityForm>;
	alphaNumericPattern = "^[a-z0-9_]{8,15}$";
	title = 'app';
	showSummary: boolean = false;
	selectedOpportunity = [];
	date1: Date;
	todate: Date;
	rowData: any[];
	pageIndex = 1;
	totalPages;
	QuoteLEoption = "Anthem";
	quoteNonWholeCaseStr = "Non-Whole Case";
	isSearched: boolean = false;
	isEmpty: boolean = false;
	showEmptyFromDate: boolean = false;
	ratingTransID: string;
	quoteHeaderID: string;
	allUniqueQuotedLE: any;
	availableLOB: any[];
	availableFT: any[];
	availableOppType: any[];
	availableStatus: any[];
	availableStates: any[];
	availableQuotedLE: any[];
	availableHasPortFolioOptions: any[];
	quotedLEResponse: any;
	selectedLOB: any;
	selectedQuoteLE: any;
	selcetedFromDate: any;
	selectedToDate: any;
	selectedFT: any;
	selectedOppType: any;
	selectedState: any;
	selectedStatus: any;
	multiselectEle: any;
	quoteReason: any;
	searchAnywhere: any;
	alternateQuote: any;
	selectedQuoteReason: boolean = false;
	selectedSearchAnywhere: boolean = false;
	selectedAlternateQuote: boolean = false;
	selectedQuoteHasPortfolioPlans: any;
	selectedQuoteOrigin: any;
	quoteOrigin: string;
	oppID: string;
	lob: string;
	first = 0;
	rows = 10;
	uwName: any;
	lob_FT: any[];
	lob_FT_TransID: any[];
	rowsPerPage: any[];
	selectedPageSize: any;
	nextButtonClicked: boolean;
	prevButtonClicked: boolean;
	userRole: any;
	public isCollapsed = false;
	currentPreference: any;
	availableMbs: any[];
	selectedMbs: any;
	multiSortMeta = [
		{
			"field": "lob", "order": 1
		}, {
			"field": "status", "order": 1
		}
	];
	cols = SearchConstants.OUOTE_SEARCH_TABLE_COLUMN;
	commonFormStorage = ['accountName', 'groupNbr', 'state', 'lob', 'quoteHasPortfolioPlans', 'quoteOrigin', 'quoteLegalEntity', 'fundingType', 'opportunityType', 'underwriterName', 'opportunityID', 'quoteHeaderID', 'fromdate', 'todate', 'mbs'];

	filterUnderwriterSingle(event) {
		let query = event.query;
		this.commonQuoteService.getUnderWriters().subscribe(underwriters => {
			this.filteredUnderwritersSingle = this.filterUnderwriter(query, underwriters.data);
		});
	}

	filterUnderwriter(query, underwriters) {
		let filtered: any[] = [];
		for (let i = 0; i < underwriters.length; i++) {
			let underwriter = underwriters[i];
			if (underwriter.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
				filtered.push(underwriter);
			}
		}
		return filtered;
	}

	alert = {
		show: false,
		message: '',
		type: '',
		cssClass: '',
		header: '',
		headerVisibility: true
	};

	constructor(private fb: FormBuilder, private commonService: CommonService, private httpClientService: HttpClientService, public datepipe: DatePipe,
		private router: Router, @Inject(SESSION_STORAGE) private storage: WebStorageService, private authService: AuthenticationService, private commonQuoteService: CommonQuoteService) {
		this.dateTime.setDate(this.dateTime.getDate());
		this.isSmallGroupIntakeEnabled = this.commonService.isSmallGroupIntakeEnabled;
	}

	open(content) {
		this.modalService.open(content);
	}

	setFormValue() {
		this.opportunity_form.setValue({
			accountName: this.storage.get('accountName') || '',
			groupNbr: this.storage.get('groupNbr') || '',
			status: this.storage.get('status') || null,
			state: this.storage.get('state') || null,
			lob: this.storage.get('lob') || null,
			fundingType: this.storage.get('fundingType') || null,
			opportunityType: this.storage.get('opportunityType') || null,
			underwriterName: this.storage.get('underwriterName') || '',
			quoteReason: this.storage.get('quoteReason') || false,
			searchAnywhere: this.storage.get('searchAnywhere') || false,
			alternateQuote: this.storage.get('alternateQuote') || false,
			quoteHasPortfolioPlans: this.storage.get('quoteHasPortfolioPlans') || null,
			quoteOrigin: this.storage.get('quoteOrigin') || null,
			opportunityID: this.storage.get('opportunityID') || '',
			quoteHeaderID: this.storage.get('quoteHeaderID') || '',
			fromdate: this.storage.get('fromdate') ? new Date(this.storage.get('fromdate')) : null,
			todate: this.storage.get('todate') ? new Date(this.storage.get('todate')) : null,
			quoteLegalEntity: this.storage.get('quoteLegalEntity') || null,
			mbs: this.storage.get('mbs') || null
		});
		this.selectedStatus = this.storage.get('status');
		if (this.storage.get('state'))
			this.selectedState = this.storage.get('state');
		if (this.storage.get('lob'))
			this.selectedLOB = this.isJson(this.storage.get('lob'));
		if (this.storage.get('quoteReason'))
			this.selectedQuoteReason = this.storage.get('quoteReason');
		if (this.storage.get('searchAnywhere'))
			this.selectedSearchAnywhere = this.storage.get('searchAnywhere') === 'true';
		if (this.storage.get('alternateQuote'))
			this.selectedAlternateQuote = this.storage.get('alternateQuote');
		if (this.storage.get('quoteHasPortfolioPlans'))
			this.selectedQuoteHasPortfolioPlans = this.storage.get('quoteHasPortfolioPlans');
		if (this.storage.get('quoteOrigin'))
			this.selectedQuoteOrigin = this.isJson(this.storage.get('quoteOrigin'));
		if (this.storage.get('fundingType'))
			this.selectedFT = this.isJson(this.storage.get('fundingType'));
		if (this.storage.get('opportunityType'))
			this.selectedOppType = this.storage.get('opportunityType');
		if (this.storage.get('mbs'))
			this.selectedMbs = this.storage.get('mbs');
		this.selectedQuoteLE = this.storage.get('quoteLegalEntity');
		if (this.storage.get('pageLimit'))
			this.selectedPageSize = { label: "" + this.storage.get('pageLimit') + "", value: this.storage.get('pageLimit') };
	}

	isJson(str) {
		if (typeof str === 'string') {
			let storeItem = [];
			storeItem.push(str)
			return storeItem;
		}
		else {
			return str;
		}
	}

	ngOnInit() {
		this.opportunity_form = this.fb.group({
			accountName: ['', { validators: [Validators.minLength(3), Validators.pattern(this.alphaNumericPattern)], updateOn: "submit" }],
			groupNbr: ['', { validators: [Validators.minLength(3), Validators.pattern(this.alphaNumericPattern)], updateOn: "submit" }],
			status: [''],
			state: [''],
			quoteLegalEntity: [''],
			lob: [''],
			quoteReason: false,
			searchAnywhere: false,
			alternateQuote: false,
			quoteHasPortfolioPlans: [''],
			quoteOrigin: [''],
			fundingType: [''],
			opportunityType: [''],
			underwriterName: ['', { validators: [Validators.minLength(3), Validators.pattern(this.alphaNumericPattern)], updateOn: "submit" }],
			opportunityID: ['', { validators: [Validators.minLength(3), Validators.pattern(this.alphaNumericPattern)], updateOn: "submit" }],
			quoteHeaderID: ['', { validators: [Validators.minLength(3), Validators.pattern(this.alphaNumericPattern)], updateOn: "submit" }],
			fromdate: [''],
			todate: [''],
			mbs: ['']
		},
			{
				validator: this.validateDate('fromdate', 'todate'),
			}
		);

		this.rowsPerPage = [
			{ label: "10", value: 10 },
			{ label: "20", value: 20 },
			{ label: "30", value: 30 }
		];
		this.selectedPageSize = this.rowsPerPage[0];
		this.availableLOB = SearchConstants.LOB_LIST;
		this.availableFT = SearchConstants.FUNDING_TYPE_LIST;
		this.availableQT = SearchConstants.QUOTING_TYPE_LIST;
		this.combinedFT = this.availableFT.concat(this.availableQT);
		this.availableOppType = SearchConstants.OPPORTUNITY_TYPE_LIST;
		this.availableMbs = SearchConstants.MBS_LIST;
		this.availableStatus = SearchConstants.STATUS_LIST;
		this.availableHasPortFolioOptions = SearchConstants.HAS_PORTFOLIO_PLANS_LIST;
		this.quoteOriginOptions = Object.values(QUOTE_ORIGIN).map(value =>
			typeof value === 'string'
			  ? {
				  label: value === 'autoRunBatch'
					? 'AutoRun Batch'
					: value === 'convertedAutoRun'
					? 'Converted AutoRun'
					: value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, str => str.toUpperCase()),
				  value: value.charAt(0).toLowerCase() + value.slice(1)
				}
			  : value
		  );
		this.selectedStatus = [...SearchConstants.DEFAULT_STATUS_LIST];
		this.selectedQuoteOrigin = [...SearchConstants.DEFAULT_QUOTE_ORIGIN_LIST];
		this.availableStates = this.commonService.getStateList();
		this.commonQuoteService.getUnderwriters();
		this.userRole = this.authService.userRole['_value'];
		this.quotedLEResponse = this.storage.get("quotedLegalEntityList");
		let entityList = {};
		Object.keys(this.quotedLEResponse).forEach((ele) => {
			this.quotedLEResponse[ele].forEach(item => {
				entityList[item] = true;
			});
		});
		this.allUniqueQuotedLE = Object.keys(entityList);
		this.availableQuotedLE = this.getLegalEntityArr(this.allUniqueQuotedLE);

		if (this.storage.get('showOpportunities') === 'true') {
			this.showOpportunities = this.storage.get('showOpportunities');
			if (this.storage.get('QuoteSearchQuery')) {
				this.getRowData(this.storage.get('QuoteSearchQuery'), this.storage.get('pageLimit'), this.storage.get('cursor'), this.storage.get('multiSortMeta'));
				this.setFormValue();
			}
			else
				this.showOpportunities = false;
			this.totalPages = this.storage.get('totalPages');
			if (this.storage.get('first') && this.totalPages > 1) {
				this.first = this.storage.get('first');
				this.pageIndex = this.storage.get('pageIndex');
			}
			else {
				this.first = 0;
				this.pageIndex = 1;
			}
		}
		else {
			this.showOpportunities = false;
			this.rowData = [];
			this.totalPages = 0;
			this.first = 0;
			this.getsaveQuery();
		}
		this.multiSortMeta = this.storage.get('multiSortMeta');

	}

	ngAfterViewInit() {
		this.multiselectEle = document.querySelector('.ui-multiselect');
		if (this.multiselectEle != null) {
			this.multiselectEle.setAttribute('tabindex', -1);
		}
	}

	checkUserRole() {
		if (this.userRole.includes('ADMIN') || this.userRole.includes('READONLY') || this.userRole.includes('UNDERWRITER')) {
			return true;
		} else if (this.userRole.includes('ADMIN') && !this.userRole.includes('READONLY')) {
			return false;
		}
	}

	validateDate(dateFrom: string, dateTo: string) {
		this.testDate = true;
		return (formGroup: FormGroup) => {
			const datefrom = formGroup.controls[dateFrom];
			const dateto = formGroup.controls[dateTo];
			if ((new Date(datefrom.value)) > (new Date(dateto.value))) {
				datefrom.setErrors({ invalidFromDate: true });
			}
			else {
				if (datefrom.hasError('required')) {
					datefrom.setErrors(null);
					datefrom.setErrors({ required: true });
				}
				else {
					datefrom.setErrors(null);
				}
			}
		}
	}

	onRowSelect($event) {
		this.ratingTransID = $event.data["rrating-transid"];
		this.quoteHeaderID = $event.data["quoteHeaderID"];
		this.oppID = $event.data["opportunityID"];
		this.lob = $event.data["lob"];
		this.quoteOrigin = $event.data["quoteOrigin"];
	}
	onGoToPage(rowData, $event) {
		this.ratingTransID = rowData["ratingTransID"];
		this.quoteHeaderID = rowData["quoteHeaderID"];
		this.quoteOrigin = rowData["quoteOrigin"];
		this.lob = rowData.lob;
		this.oppID = rowData.opportunityID;
		this.storage.set('multiSortMeta', this.multiSortMeta);

		this.lob_FT = [];
		this.lob_FT_TransID = [];
		this.commonService.setQuoteTabList(this.lob_FT_TransID);
		this.commonService.logUserOpeningQuoteEvent(this.ratingTransID, this.oppID, this.quoteHeaderID, this.lob, rowData["fundingType"], rowData["marketSegment"], this.quoteOrigin, "Quote-Search");
		this.commonQuoteService
			.getOpportunitesByOppID(this.oppID, this.lob)
			.subscribe(
				response => {
					if (response != null) {
						for (var opp of response.opportunities) {
							if (opp && opp.quoteHeaderID === this.quoteHeaderID) {
								let data = (opp.lob == 'Medical' && (opp.quotingType == 'ACA' || opp.quotingType == 'MEWA')) ? opp.lob + '-' + opp.quotingType : opp.lob + '-' + opp.fundingType;
								if (!(this.lob_FT.find(x => x === data && x.opportunityType == opp.opportunityType))) {
									this.lob_FT.push(data);
									this.lob_FT_TransID.push({
										"tabName": data,
										"ratingTransID": opp.ratingTransID,
										"tabStatus": opp.status,
										"fundingType": opp.fundingType,
										"quoteOrigin": opp.quoteOrigin
									});
								}
							}
						}
						let filteredData;
						const tabNameCounts = this.lob_FT_TransID.reduce((acc, item) => {
							acc[item.tabName] = (acc[item.tabName] || 0) + 1;
							return acc;
						}, {});

						if (this.quoteOrigin === CommonConstants.AUTO_RUN_BATCH && this.lob === CommonConstants.MEDICAL_LOB && rowData["quotingType"] === "POOL") {
							filteredData = this.lob_FT_TransID.filter(item => 
								(item.tabName === "Medical-FI" || item.tabName === "Medical-ABF") &&
								item.quoteOrigin !== CommonConstants.AUTO_RUN_BATCH &&
								tabNameCounts[item.tabName] === 1
							);
						} else if (this.quoteOrigin !== CommonConstants.AUTO_RUN_BATCH && this.lob ===  CommonConstants.MEDICAL_LOB && rowData["quotingType"] === "POOL") {
							filteredData = this.lob_FT_TransID.filter(item => 
								(item.tabName === "Medical-FI" || item.tabName === "Medical-ABF") &&
								item.quoteOrigin === CommonConstants.AUTO_RUN_BATCH &&
								tabNameCounts[item.tabName] === 1
							);
						}

						// Remove matched values from lob_FT
						if (this.lob ===  CommonConstants.MEDICAL_LOB && rowData["quotingType"] === "POOL") {
							this.lob_FT = this.lob_FT.filter(item => 
								!filteredData.some(filteredItem => filteredItem.tabName === item)
							);
						}
						this.lob_FT = this.lob_FT.sort(function (a, b) {
							return a > b ? 1 : a < b ? -1 : 0
						});
						this.lob_FT = [...new Set(this.lob_FT)];
						if(rowData.lob === CommonConstants.Vision || rowData.lob === CommonConstants.Dental) {
						this.lob_FT_TransID = this.lob_FT_TransID.filter( id => id.quoteOrigin != QUOTE_ORIGIN.AUTO_RUN_BATCH );
						}
						if (rowData.lob === CommonConstants.Medical && rowData.quoteOrigin !== QUOTE_ORIGIN.AUTO_RUN_BATCH) {
							this.lob_FT_TransID = this.lob_FT_TransID.filter(id => id.quoteOrigin !== QUOTE_ORIGIN.AUTO_RUN_BATCH);
						}
						this.commonService.setQuoteTabList(this.lob_FT_TransID);
						if (this.ratingTransID && (this.lob == 'Medical')) {
							this.router.navigate(['/quote/uw-rate'], {
								queryParams: {
									quoteHeaderID: this.quoteHeaderID, opportunityID: this.oppID, quoteOrigin:this.quoteOrigin,
									ratingTransID: this.ratingTransID, lob: rowData.lob, fundingType: rowData.fundingType, insertedTimestamp: rowData.insertedTimestamp, availableTabs: this.lob_FT, searchAnywhere: this.selectedSearchAnywhere, marketSegment: rowData["marketSegment"]
								}
							});
						} else if (this.ratingTransID && (this.lob == 'Vision')) {
							if (this.commonService.isVisionEnabled == 'true') {
								this.router.navigate(['/quote/uw-rate-vision'], {
									queryParams: {
										quoteHeaderID: this.quoteHeaderID, opportunityID: this.oppID,quoteOrigin:this.quoteOrigin,
										ratingTransID: this.ratingTransID, lob: rowData.lob, fundingType: rowData.fundingType, availableTabs: this.lob_FT, searchAnywhere: this.selectedSearchAnywhere, marketSegment: rowData["marketSegment"]
									}
								});
							}

						} else if (this.ratingTransID && (this.lob == 'Dental')) {
							this.router.navigate(['/quote/uw-rate-dental'], {
								queryParams: {
									quoteHeaderID: this.quoteHeaderID, opportunityID: this.oppID,quoteOrigin:this.quoteOrigin,
									ratingTransID: this.ratingTransID, lob: rowData.lob, fundingType: rowData.fundingType, availableTabs: this.lob_FT, searchAnywhere: this.selectedSearchAnywhere, marketSegment: rowData["marketSegment"]
								}
							});
						}
						else if (this.ratingTransID && (this.lob == SearchConstants.SUPP_Health)) {
							this.router.navigate(['/quote/uw-rate-supplemental-health'], {
								queryParams: {
									quoteHeaderID: this.quoteHeaderID, opportunityID: this.oppID,quoteOrigin:this.quoteOrigin,
									ratingTransID: this.ratingTransID, lob: rowData.lob, fundingType: rowData.fundingType, availableTabs: this.lob_FT, searchAnywhere: this.selectedSearchAnywhere, marketSegment: rowData["marketSegment"]
								}
							});
						}
						else {
							alert('Please select the Opportunity ');
						}
					}
				},
				error => {
					console.error(error);
				}
			);
	}

	focusFromDateEle() {
		if (this.selcetedFromDate) {
			this.selcetedFromDate.focus();
		}
	}

	focusToDateEle() {
		if (this.selectedToDate) {
			this.selectedToDate.focus();
		}
	}

	clickedFromDate() {
		let element: HTMLElement = document.querySelectorAll('.fromdate .p-inputtext')[0] as HTMLElement;
		this.selcetedFromDate = element;
		if (typeof (element) != 'undefined') {
			element.click();
		}
		if (document.querySelector(".fromDateCalendar"))
			(<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar-blue.svg";
		(<HTMLImageElement>document.querySelector(".toDateCalendar")).src = "./assets/calendar.svg";
	}

	clickedToDate() {
		let element: HTMLElement = document.querySelectorAll('.todate .p-inputtext')[0] as HTMLElement;
		this.selectedToDate = element;
		if (typeof (element) != 'undefined') {
			element.click();
		}
		if (document.querySelector(".toDateCalendar"))
			(<HTMLImageElement>document.querySelector(".toDateCalendar")).src = "./assets/calendar-blue.svg";
		(<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar.svg";
	}
	getLegalEntityArr(list) {
		let availableEntityList = [];
		list.map((entity) => {
			availableEntityList.push({ "label": entity, value: entity })
		})
		return availableEntityList;
	}


	getSelectedStateQuoteLE() {
		this.availableQuotedLE = this.getLegalEntityArr(this.quotedLEResponse[this.selectedState.label])
	}

	displayOptionsPannel() {
		if (this.multiselectEle) {
			this.multiselectEle.focus();
		}
	}

	nextClicked() {
		if (this.showNextButton) {
			this.nextButtonClicked = true;
			this.searchClicked();
			this.nextButtonClicked = false;
		}
	}

	prevClicked() {
		if (this.showPrevButton) {
			this.prevButtonClicked = true;
			this.searchClicked();
			this.prevButtonClicked = false;
		}
	}

	formatDate(dateValue) {
		let day = dateValue.getDate();
		let month = dateValue.getMonth() + 1;
		let year = dateValue.getFullYear();
		let date = year + '-' + month + '-' + day;
		return date;
	}

	getPreferenceOPChanged(event) {
		this.getPreferenceData(event.preference, event.preferenceName);
	}

	savePreferenceOPChanged(event) {
		this.savePreference(event);
	}

	deletePreferenceChanged(event) {
		this.deletePreference(event);
	}

	defaultPreferenceChanged(event) {
		this.defaultPreference(event.preferenceObj, event.isChecked);
	}

	savePreference(preferenceValue) {
		let preferenceObj = {
			"userID": this.authService.getUserID(),
			"preferenceType": "Search",
			"preferenceName": preferenceValue,
			"isDefault": false,
			"preferences": this.preparePreference()
		};

		if (preferenceObj.preferences['fromDate']) {
			preferenceObj.preferences['fromDate'] = this.formatDate(preferenceObj.preferences['fromDate']);
		}

		if (preferenceObj.preferences['toDate']) {
			preferenceObj.preferences['toDate'] = this.formatDate(preferenceObj.preferences['toDate']);
		}

		let isPreferenceExisted = this.preferenceData.find(x => x.preferenceName === preferenceValue);
		if (isPreferenceExisted) {
			preferenceObj['id'] = isPreferenceExisted.id;
			preferenceObj['isDefault'] = isPreferenceExisted.isDefault;
			this.commonService.updatePreferenceInfo(preferenceObj).subscribe(response => {
				if (response) {
					this.saveQueryClicked();
				}
			},
				error => {
				});
		}
		else {
			if (!this.preferenceData || !this.preferenceData.length)
				preferenceObj['isDefault'] = true;
			this.commonService.postPreferenceInfo(preferenceObj).subscribe(response => {
				if (response) {
					this.saveQueryClicked();
				}
			},
				error => {
				});
		}
	}

	preparePreference() {
		let flagFocus = false;
		let preferences = {};
		if (this.selectedStatus)
			this.opportunity_form.controls.status.setValue(this.selectedStatus);

		if (this.selectedQuoteLE) {
			this.opportunity_form.controls.quoteLegalEntity.setValue(this.selectedQuoteLE);
		}
		if (this.uwName)
			this.opportunity_form.controls.underwriterName.setValue(this.uwName);

		let form = this.opportunity_form;

		Object.keys(form.controls).forEach(key => {
			if (key === 'underwriterName' || key === 'accountName' || key === 'opportunityID' || key === 'quoteHeaderID' || key === 'groupNbr') {
				if (form.get(key)['_pendingValue'] || form.get(key)['_pendingValue'] === false)
					preferences[key] = form.get(key)['_pendingValue'];
			}
			else {
				if (form.value[key] || form.value[key] === false) {
					if (key === 'fromdate') {
						preferences['fromDate'] = form.value[key];
					}
					else if (key === 'todate') {
						preferences['toDate'] = form.value[key];
					}
					else {
						preferences[key] = form.value[key];
					}
				}
			}
		});

		return preferences;

	}

	searchClicked(isRefresh?: boolean) {
		let flagFocus = false;
		this.isSearched = true;
		this.isEmpty = false;
		let pageLimit = 10;
		let cursor: any;
		let sortMetaData: any = null;

		if (this.selectedPageSize)
			pageLimit = this.selectedPageSize.value;

		if (this.nextButtonClicked) {
			cursor = this.nextCursor;
		}

		if (this.prevButtonClicked) {
			cursor = this.prevCursor;
		}

		if (this.multiSortMeta != undefined) {
			sortMetaData = JSON.stringify(this.multiSortMeta);
		}

		if (this.selectedStatus) {
			this.opportunity_form.controls.status.setValue(this.selectedStatus);
		}

		if (this.selectedQuoteHasPortfolioPlans) {
			this.opportunity_form.controls.quoteHasPortfolioPlans.setValue(this.selectedQuoteHasPortfolioPlans);
		}

		if (this.selectedQuoteOrigin) {
				this.opportunity_form.controls.quoteOrigin.setValue(this.selectedQuoteOrigin);
		}
		if (this.selectedSearchAnywhere) {
			this.opportunity_form.controls.searchAnywhere.setValue(this.selectedSearchAnywhere);
		}

		if (this.selectedQuoteLE) {
			this.opportunity_form.controls.quoteLegalEntity.setValue(this.selectedQuoteLE);
		}
		if (this.uwName)
			this.opportunity_form.controls.underwriterName.setValue(this.uwName);

		let form = this.opportunity_form;

		/*If Fromdate has value and Todate has no value*/
		if (form.get("fromdate").value !== "" && (form.get("todate").value === "" || form.get("todate").value === null)) {
			form.get("todate").setValue("");
		}
		/*If  quoteReason has has no value*/
		if (form.get("quoteReason").value !== "" && (form.get("quoteReason").value === "" || form.get("quoteReason").value === null)) {
			form.get("quoteReason").setValue(false);
		}
		if (form.get("searchAnywhere").value === null || form.get("searchAnywhere").value === undefined) {
			form.get("searchAnywhere").setValue(false);
		}

		/*If  alternateQuote has has no value*/
		if (form.get("alternateQuote").value !== "" && (form.get("alternateQuote").value === "" || form.get("alternateQuote").value === null)) {
			form.get("alternateQuote").setValue(false);
		}

		/*If Fromdate has no value*/
		if ((form.get("fromdate").value === "" || form.get("fromdate").value === null) && (form.get("todate").value !== "" && form.get("todate").value !== null)) {
			this.showEmptyFromDate = true;
		}
		else {
			this.showEmptyFromDate = false;
		}
		Object.keys(form.controls).forEach(field => {
			if (flagFocus == false) {
				const control = form.get(field).errors;
				if (control) {
					Object.keys(control).forEach(field1 => {
						if (field1 == "minlength") {
							flagFocus = true;
						}
					});
					let element: HTMLElement = document.querySelectorAll('[formcontrolname="' + field + '"]')[0] as HTMLElement;
					element.focus();
				}
			}
		});

		if (!this.showEmptyFromDate && !flagFocus) {
			this.showOpportunities = false;
			this.rowData = [];
			this.totalPages = 0;
			this.getOpportunityData(form, pageLimit, cursor, sortMetaData, isRefresh);

		}
		else {
			this.showOpportunities = false;
			this.isSearched = false;
			this.storage.set('showOpportunities', 'false');
		}
	}

	preferenceData: any[] = [];
	saveQueryClicked() {
		this.commonService.getPreferenceInfo("Search").subscribe(response => {
			this.preferenceData = response;
		}, error => {
		});
	}

	getsaveQuery() {
		this.commonService.getPreferenceInfo("Search").subscribe(response => {
			if (response.length && response.length > 0) {
				let DefaultPreference = response.find(x => x.isDefault == true);
				if (typeof (DefaultPreference) != 'undefined') {
					this.getPreferenceData(DefaultPreference.preferences, DefaultPreference.preferenceName);
				}
			}
		}, error => {
		});
	}

	collapseDiv() {
		this.isCollapsed = !this.isCollapsed;
	}

	deletePreference(id: any) {
		this.commonService.deletePreferenceInfo(id).subscribe(response => {
			if (response) {
				let preferenceData = this.preferenceData.find(x => x.id === id);
				if (preferenceData.preferenceName === this.currentPreference)
					this.currentPreference = null;
				this.saveQueryClicked();
			}
		}, error => {
		});
	}

	defaultPreference(preferenceObj: any, isChecked: any) {
		let preference = {
			"id": preferenceObj.id,
			"userID": this.authService.getUserID(),
			"preferenceType": "Search",
			"preferenceName": preferenceObj.preferenceName,
			"preferences": preferenceObj.preferences
		};
		if (isChecked === 'on') {
			preference['isDefault'] = true;
		}
		else {
			preference['isDefault'] = false;
		}

		this.commonService.updatePreferenceInfo(preference).subscribe(response => {
			if (response) {
				this.saveQueryClicked();
			}
		},
			error => {
			});
	}

	getPreferenceData(preferenceValue: any, preferenceName: any) {
		this.currentPreference = preferenceName;
		this.opportunity_form.setValue({
			accountName: preferenceValue.accountName || '',
			groupNbr: preferenceValue.groupNbr || '',
			status: preferenceValue.status || null,
			state: preferenceValue.state || null,
			lob: preferenceValue.lob || null,
			fundingType: preferenceValue.fundingType || null,
			underwriterName: preferenceValue.underwriterName || '',
			quoteReason: preferenceValue.quoteReason || false,
			searchAnywhere: preferenceValue.searchAnywhere || false,
			alternateQuote: preferenceValue.alternateQuote || false,
			opportunityType: preferenceValue.opportunityType || null,
			quoteHasPortfolioPlans: preferenceValue.quoteHasPortfolioPlans || null,
			quoteOrigin: preferenceValue.quoteOrigin || null,
			opportunityID: preferenceValue.opportunityID || '',
			quoteHeaderID: preferenceValue.quoteHeaderID || '',
			fromdate: preferenceValue.fromDate ? new Date(preferenceValue.fromDate) : null,
			todate: preferenceValue.toDate ? new Date(preferenceValue.toDate) : null,
			quoteLegalEntity: preferenceValue.quoteLegalEntity || null,
			mbs: preferenceValue.mbs || null
		});
		this.selectedStatus = preferenceValue.status;
		if (preferenceValue.state)
			this.selectedState = preferenceValue.state;
		if (preferenceValue.lob)
			this.selectedLOB = preferenceValue.lob;
		if (preferenceValue.quoteReason)
			this.selectedQuoteReason = preferenceValue.quoteReason;
		if (preferenceValue.searchAnywhere)
			this.selectedSearchAnywhere = preferenceValue.searchAnywhere;
		if (preferenceValue.alternateQuote)
			this.selectedAlternateQuote = preferenceValue.alternateQuote;
		if (preferenceValue.quoteHasPortfolioPlans)
			this.selectedQuoteHasPortfolioPlans = preferenceValue.quoteHasPortfolioPlans;
		if (preferenceValue.quoteOrigin)
			this.selectedQuoteOrigin = preferenceValue.quoteOrigin;
		if (preferenceValue.fundingType)
			this.selectedFT = preferenceValue.fundingType;
		if (preferenceValue.opportunityType)
			this.selectedOppType = preferenceValue.opportunityType;
		this.selectedQuoteLE = preferenceValue.quoteLegalEntity;
		if (preferenceValue.mbs)
			this.selectedMbs = preferenceValue.mbs;
		this.showOpportunities = false;
		this.isSearched = false;
		this.storage.set('showOpportunities', 'false');
	}

	resetClicked() {
		this.opportunity_form.reset();
		this.showEmptyFromDate = false;
		this.selectedLOB = null;
		this.selectedQuoteReason = false;
		this.selectedSearchAnywhere = false;
		this.selectedAlternateQuote = false;
		this.selectedQuoteHasPortfolioPlans = null;
		this.selectedQuoteOrigin = null;
		this.selectedFT = null;
		this.selectedOppType = null;
		this.selectedQuoteLE = null;
		this.isEmpty = false;
		this.isSearched = false;
		this.showOpportunities = false;
		this.rowData = [];
		this.totalPages = 0;
		this.multiSortMeta = null;
		this.currentPreference = null;
		let removeStorageList = ['showOpportunities', 'totalPages', 'first', 'pageIndex', 'QuoteSearchQuery', 'pageLimit', 'cursor', 'multiSortMeta', ...this.commonFormStorage];
		this.updateStorage('remove', removeStorageList);
		this.availableQuotedLE = this.getLegalEntityArr(this.allUniqueQuotedLE);
		this.selectedStatus = [...SearchConstants.DEFAULT_STATUS_LIST];
		this.selectedQuoteOrigin = [...SearchConstants.DEFAULT_QUOTE_ORIGIN_LIST];
		this.setAlertVisibility(false)
	}

	onRateExhibit() {
		this.rateExhibit = true;
	}

	onSelectOpportunity() {
		if (this.ratingTransID) {
			this.router.navigate(['/quote/uw-rate'], { queryParams: { ratingTransID: this.ratingTransID, lob: this.lob } });
		}
		else {
			alert('Please select the Opportunity ');
		}
	}

	onSoldRate() {
		this.router.navigate(['/soldRate']);
	}

	paginate(event) {
		this.pageIndex = event.first / event.rows + 1;
		this.storage.set('first', event.first);
		this.storage.set('pageIndex', this.pageIndex);
	}
	getEffectiveDate(effectiveDate) {
		if (effectiveDate) {
			let ctrctDate = new Date(effectiveDate);
			return this.datepipe.transform(new Date(ctrctDate.getUTCFullYear(), ctrctDate.getUTCMonth(), ctrctDate.getUTCDate()), 'MM-dd-yyyy');
		}
	}

	getOpportunityData(form, pageLimit, cursor, sortMetaData, isRefresh?: boolean) {
		this.opportunitySubmit =
			this.commonQuoteService.getQuotes(form, pageLimit, cursor, sortMetaData).subscribe(response => {
				if (response.opportunities.length) {
					this.showOpportunities = true;
					this.showNextButton = response.hasNextCursor;
					this.showPrevButton = response.hasPrevCursor;
					this.nextCursor = response.nextCursor;
					this.prevCursor = response.prevCursor;
					this.rowData = response.opportunities;
					this.totalPages = Math.ceil(this.rowData.length / 10);
					this.first = 0;
					this.pageIndex = 1;
					this.storage.set('first', 0);
					this.storage.set('showOpportunities', 'true');
					this.storage.set('totalPages', this.totalPages);
					this.storage.set('pageIndex', 1);
					let storageFormStorageList = ['status', 'quoteReason', ...this.commonFormStorage];
					this.updateStorage('set', storageFormStorageList);
					if (isRefresh) {
						this.storage.remove('cursor');
					}
				}
				else {
					this.showOpportunities = false;
					this.storage.set('showOpportunities', 'false');
					this.isEmpty = true;
				}
			}, error => {
				this.showOpportunities = false;
				this.storage.set('showOpportunities', 'false');
			});
	}

	updateStorage(type, storageList) {
		if (StringUtils.isEqual(type, 'set')) {
			storageList.forEach(key => this.storage.set(key, this.opportunity_form.controls[key].value));
			this.storage.set('alternateQuote', this.opportunity_form.controls['alternateQuote'].value); // Save alternateQuote
		} else {
			storageList.forEach(key => this.storage.remove(key));
			this.storage.remove('alternateQuote'); // Remove alternateQuote
		}

	}

	getRowData(query, pageLimit, cursor, multiSortMeta) {
		this.commonQuoteService.getQuotesByQuery(query, pageLimit, cursor, multiSortMeta).subscribe(response => {
			if (response.opportunities.length) {
				this.showOpportunities = true;
				this.showNextButton = response.hasNextCursor;
				this.showPrevButton = response.hasPrevCursor;
				this.nextCursor = response.nextCursor;
				this.prevCursor = response.prevCursor;
				this.rowData = response.opportunities;
			}
			else {
				this.showOpportunities = false;
				this.storage.set('showOpportunities', 'false');
				this.isEmpty = true;
			}
		}, error => {
			this.showOpportunities = false;
			this.storage.set('showOpportunities', 'false');
		});
	}

	saveMultiSortMeta(event) {
		let lobField, fundingTypeField, fundingtypeIndex;
		this.multiSortMeta = event.multisortmeta;
		this.multiSortMeta.forEach((meta, i) => {
			if (meta.field === "lob") {
				lobField = meta;
			}
			if (meta.field == "fundingType") {
				fundingTypeField = meta;
				fundingtypeIndex = i;
			}

		})

		if (lobField && !fundingTypeField) {
			this.multiSortMeta.push({ field: "fundingType", order: lobField.order })
		}
		if (lobField && fundingTypeField) {
			this.multiSortMeta[fundingtypeIndex] = { field: "fundingType", order: lobField.order }
		}
	}

	extractOppType(value: string): string {
		return value ? value.charAt(0) : '';
	}

	isSearchAnywhereForQuoteSearchEnabled(): boolean {
		return this.commonService.getIsSearchAnywhereForQuoteSearchEnabled();
	}

	searchAnywhereToggled(isSearchAnywhereSelected: boolean) {
		if (isSearchAnywhereSelected) {
			this.setAlertVisibility(true, AlertType.WARNING, 'Search anywhere is selected. Please note that this may take longer to return results.', true);
		} else {
			this.setAlertVisibility(false);
		}
	}

	setAlertVisibility(visibility: boolean, type = '', message: string = '', headervisibility?: boolean) {
		window.scroll(0, 0);
		this.alert.show = visibility;
		this.alert.type = type || '';
		this.alert.message = message;
		this.alert.cssClass = type === AlertType.ERROR ? 'alert-danger' : `alert-${type}`;
		this.alert.header = type === AlertType.ERROR ? 'failed' : type;
		if (headervisibility != undefined) {
			this.alert.headerVisibility = headervisibility;
		}
	}

	showAlertBasedOnConditions(message: string) {
		return {
			'alert-largeText alertContainer-largeText renewal-alert-largeText': message.length > 150,
			'alert alertContainer renewal-alert': message.length < 150
		};
	}

}
