import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CheckboxModule } from 'primeng/checkbox';
import { MultiSelectModule } from 'primeng/multiselect';
import { SearchPreferenceComponent } from './search-preference';
import { QuoteSearchComponent } from './quote-search.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { DatePickerModule } from 'primeng/datepicker';

@NgModule({
    declarations: [QuoteSearchComponent, SearchPreferenceComponent],
    imports: [
        CommonModule, TableModule, ButtonModule, ReactiveFormsModule, SelectModule, RadioButtonModule, FlexLayoutModule,
        AutoCompleteModule, CheckboxModule, FormsModule, MultiSelectModule, ButtonModule, SharedModule, DatePickerModule,
        RouterModule.forChild([
            { path: '', component: QuoteSearchComponent, pathMatch: 'full' }
        ])
    ],
    exports: [
        QuoteSearchComponent,
        SearchPreferenceComponent
    ],
    providers: [DatePipe]
})
export class QuoteSearchModule { }
