import {NgModule} from '@angular/core';
import {TokenComponent} from "./token.component";
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {ButtonModule} from 'primeng/button';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  declarations: [
    TokenComponent
  ],
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule, SharedModule, RouterModule.forChild([
      {path: '', component: TokenComponent, pathMatch: 'full'}
    ]), ButtonModule
  ],
  exports: [
    TokenComponent
  ],
  providers: [
    RouterModule
  ]
})
export class TokenModule {
}
