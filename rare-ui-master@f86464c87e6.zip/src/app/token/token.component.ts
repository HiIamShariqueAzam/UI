import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {MessageService} from 'primeng/api';
import {FormBuilder, FormGroup} from "@angular/forms";
import {CommonService} from "../shared/services";

@Component({
  selector: 'app-admin',
  templateUrl: './token.component.html',
  standalone: false,
})
export class TokenComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private commonService: CommonService,
    private messageService: MessageService) {
  }

  ngOnInit() {
    this.token_form = this.fb.group({
        tokenResult: [''],
        tokenBody: ['']
      }
    );
  }

  con

  navigate(pageName: string) {
    this.router.navigate(['/' + pageName]);
    this.messageService.clear();
  }

  token_form: FormGroup;
  bodyContent: any;

  generateToken(body: string) {
    this.commonService
      .generateToken(body)
      .subscribe(
        response => {
          this.token_form.get("tokenResult").setValue(response);
        },
        error => {
          console.error(error);
        }
      );
  }


}
