import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MultiSelectModule } from 'primeng/multiselect';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SharedRoutingModule } from './shared-routing.module';
import { DateFormatPipe } from './pipes/date-format-pipe';
import { OnlynumberDirective } from './directives/only-number-directive.directive';
import { GlobalHeaderComponent } from './components/global-header/global-header.component';
import { GlobalFooterComponent } from './components/global-footer/global-footer.component';
import { WaveLoaderComponent } from './components/wave-loader/wave-loader.component';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ValidationMessagesComponent } from './components/validation/validation-messages.component';
import { AlertComponent } from './components/alert/alert.component';
import { PercentageToFactorDirective } from "./directives/percentage-factor-directive.directive";
import { OmitSpecialCharDirective } from "./directives/omit-specialchar-directive.directive";
import { WhSavingModalComponent } from './components/wh-saving-modal/wh-saving-modal.component';
import { SearchPipe } from './pipes/search.pipe';
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { ErrorInterceptor } from "./services/error-interceptor.service";
import { DialogModule } from "primeng/dialog";
import { ButtonModule } from "primeng/button";
import { DatePickerModule } from "primeng/datepicker";
import { ErrorDialogComponent } from "./components/dialog/error-dialog.component";
import { PrewrapPipe } from './pipes/prewrap.pipe';
import { OffCycleModalComponent } from './components/off-cycle-modal/off-cycle-modal.component';


@NgModule({
  declarations: [
    DateFormatPipe,
    OnlynumberDirective,
    PercentageToFactorDirective,
    OmitSpecialCharDirective,
    GlobalHeaderComponent,
    GlobalFooterComponent,
    WaveLoaderComponent,
    ValidationMessagesComponent,
    AlertComponent,
    WhSavingModalComponent,
    SearchPipe,
    ErrorDialogComponent,
    PrewrapPipe,
    OffCycleModalComponent
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    TooltipModule,
    ToastModule,
    MultiSelectModule, FormsModule,
    ReactiveFormsModule,
    DialogModule,
    ButtonModule,
    DatePickerModule
  ],
  exports: [
    DateFormatPipe,
    OnlynumberDirective,
    PercentageToFactorDirective,
    OmitSpecialCharDirective,
    GlobalHeaderComponent,
    GlobalFooterComponent,
    WaveLoaderComponent,
    ValidationMessagesComponent,
    WhSavingModalComponent,
    SearchPipe,
    ErrorDialogComponent,
    PrewrapPipe,
    OffCycleModalComponent
  ],
  providers: [
      MessageService,
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ]
})
export class SharedModule { }
