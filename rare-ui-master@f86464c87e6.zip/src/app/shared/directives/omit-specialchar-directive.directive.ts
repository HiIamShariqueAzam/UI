import { Directive, HostListener, Input, Output, Renderer2, ElementRef, EventEmitter } from '@angular/core';


@Directive({
    selector: '[appOmitSpecialChar]',
    standalone: false
})
export class OmitSpecialCharDirective {

    @Input('appOmitSpecialChar') expression: RegExp;
    @Output() pasteEmitter = new EventEmitter();
    constructor(private renderer: Renderer2, private el: ElementRef) { }

    @HostListener('paste', ['$event'])
    onPaste(event: ClipboardEvent) {
        this.expression = new RegExp('[^a-zA-Z0-9/]');
        let clipboardData = event.clipboardData;
        let pastedText = clipboardData.getData('text');        
        let trimmedText = pastedText.replace(/[^a-zA-Z0-9]/g, '');
        let test = this.expression.test(pastedText);
        this.renderer.setProperty(this.el.nativeElement, "value", trimmedText);
        this.pasteEmitter.emit(event);
    }

}