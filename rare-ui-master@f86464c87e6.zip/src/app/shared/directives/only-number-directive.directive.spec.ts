import { OnlyNumberDirectiveDirective } from './only-number-directive.directive';

describe('OnlyNumberDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyNumberDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
