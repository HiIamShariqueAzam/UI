import { Directive, ElementRef, HostListener, forwardRef, Renderer2 } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { StringUtils } from "../utils/string-utils";

/**
 * Directive to convert a percentage input to a factor actual value.
 *
 * Usage:
 * <input type="text" appPercentToFactor [(ngModel)]="value">
 *
 * Implements ControlValueAccessor to integrate with Angular forms.
 */
@Directive({
  selector: '[appPercentToFactor]',
  standalone: false,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PercentageToFactorDirective),
      multi: true
    }
  ]
})
export class PercentageToFactorDirective implements ControlValueAccessor {

  onChange: any = () => {};
  onTouch: any = () => {};

  constructor(private elem: ElementRef, private renderer: Renderer2) { }

  @HostListener('input', ['$event.target.value'])
  onInput(input) {
    const caretPosition = this.elem.nativeElement.selectionStart;
    const numberOfPercentageSigns = (input.match(/%/g) || []).length;

    if (numberOfPercentageSigns > 1 || (numberOfPercentageSigns === 1 && isNaN(input.replace(/%/g, ""))) || isNaN(Number(input.replace(/%/g, "")))) {
      // If input contains more '%' symbols or the input is not a number (without the '%'), or is not a valid number even without '%', set updateChanges to null
      this.updateChanges(null);
    } else if (numberOfPercentageSigns <= 1 && !isNaN(input.replace(/%/g, ""))) {
      let value = input.replace(/%/g, "");
      // If there is only one '%' or none and the rest is a valid number, perform the conversion
      this.updateChanges(this.roundFourDecimals(this.transformPercentToFactor(value)));
    }

    this.renderer.setProperty(this.elem.nativeElement, "value", input);
    this.setCaretPosition(caretPosition);
  }

  @HostListener('blur', ['$event.target.value'])
  onBlur(input) {
    // Checks if the input is empty
    if (input === "") {
      this.renderer.setProperty(this.elem.nativeElement, "value", "");
      return;
    }

    // Counts the number of '%' in the input
    const numberOfPercentageSigns = (input.match(/%/g) || []).length;

    if (numberOfPercentageSigns == 0 && !isNaN(input)) {
      // If no '%' and input is a valid number, add '%' at the end
      this.renderer.setProperty(this.elem.nativeElement, "value", input + '%');
    } else if (numberOfPercentageSigns == 1 && !isNaN(input.replace(/%/g, ""))) {
      // If one '%' and input is a valid number without '%', move '%' to the end
      this.renderer.setProperty(this.elem.nativeElement, "value",  input.replace(/%/g, "") + '%');
    } else if (numberOfPercentageSigns > 1) {
      // If more than one '%', do nothing and return the input
      this.renderer.setProperty(this.elem.nativeElement, "value", input);
    }
  }

  private setCaretPosition(position: number) {
    this.elem.nativeElement.setSelectionRange(position, position);
  }

  writeValue(value: any): void {
    const caretPosition = this.elem.nativeElement.selectionStart;
    const percent = this.roundFourDecimals(this.transformFactorToPercent(value));
    this.renderer.setProperty(this.elem.nativeElement, "value", this.formatToPercentage(percent));
    this.setCaretPosition(caretPosition);
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouch = fn;
  }

  updateChanges(value: number) {
    this.writeValue(value);
    this.onChange(String(value));
  }

  private transformPercentToFactor(value) {
    // Convert the percent to a factor
    return parseFloat(value) / 100 + 1;
  }

  private transformFactorToPercent(value) {
    // Convert the factor to a percent
    return (parseFloat(value) - 1) * 100;
  }
  formatToPercentage(value){
    if(StringUtils.isEmpty(value) || value === "%"){
      return "";
    }
    return String(value).replace(/%/g, "").concat("%")
  }

  roundFourDecimals(value) {
    if (isNaN(value)) {
      return null;
    }
    return Math.round(value * 10000) / 10000;
  }
}
