export interface CreateOpportunity {
    unifiedRequest:boolean;
    censusRefId: string;
    metaData: any;
    data: any;
}
