import { FormControl } from "@angular/forms";

export interface OpportunityDetails {
    groupName: FormControl<any>;
    state: FormControl<string>;
    marketSegment: FormControl<string>;
    opportunityType: FormControl<string>;
    quoteReason: FormControl<any>;
    opportunityID: FormControl<any>;
  }