export interface ErrorDetails {
    tableName:string, 
    rowNumber:string,
    columnName:string,    
    errorText:string
 } 
 export interface LobDetails{ 
    label:string, 
    value:string
 } 