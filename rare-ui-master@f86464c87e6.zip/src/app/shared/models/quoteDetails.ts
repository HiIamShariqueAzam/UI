import { FormControl } from "@angular/forms";

export interface OpportunityForm {
	accountName: FormControl<string>;
	groupNbr: FormControl<string>;
	status: FormControl<string>;
	state: FormControl<string>;
	quoteLegalEntity: FormControl<string>;
	lob: FormControl<string>;
	quoteReason: FormControl<any>;
	searchAnywhere: FormControl<boolean>;
	alternateQuote: FormControl<any>;
	quoteHasPortfolioPlans: FormControl<string>;
	quoteOrigin: FormControl<string>;
	fundingType: FormControl<string>;
	opportunityType: FormControl<string>;
	underwriterName: FormControl<string>;
	opportunityID: FormControl<string>;
	quoteHeaderID: FormControl<string>;
	fromdate: FormControl<any>;
	todate: FormControl<any>;
	mbs: FormControl<string>;
}
