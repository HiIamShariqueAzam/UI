import { FormControl } from "@angular/forms";

export interface SoldRatesForm {
    caseNumber: FormControl<string>;
    caseNumberUpdate: FormControl<string>;
    classValue: FormControl<string>;
    ccCodeOverride: FormControl<string>;
    classValueUpdate: FormControl<string>;
    ccCodeOverrideUpdate: FormControl<string>;
    ccValue: FormControl<string>;
    includeInRates: FormControl<string>;
    cccValue: FormControl<string>;
}