import { FormControl } from "@angular/forms";

export interface AdjustmentForm {
    uwNotesToSales: FormControl<string>;
    uwComments:  FormControl<any>;
    quoteReason: FormControl<any>;
    salesNotetoUW: FormControl<any>;
}