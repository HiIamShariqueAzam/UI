
export class CurrentPlanRates {

    planId: number;
    planDescription: string;
    ecrRates: RatesInfo;
  
}
export class RatesInfo {
    carrierName: string;
    planName: string;

    fundingType: string;
   
    currRatesT1: string;
    currRatesT2: string;
    currRatesT3: string;
    currRatesT4: string;
    currRatesT5: string;


    rnwlRatesT1: string;
    rnwlRatesT2: string;
    rnwlRatesT3 : string;
    rnwlRatesT4: string;
    rnwlRatesT5: string;


    eeContribution: string;
    depContribution: string;
}
