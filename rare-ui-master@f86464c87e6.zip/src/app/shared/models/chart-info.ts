export class ChartInfo {
  chartName: string;
  chartLabel: string;
  filters: Record<string, any>;

  constructor(chartName: string, chartLabel: string, filters: Record<string, any> = {}) {
    this.chartName = chartName;
    this.chartLabel = chartLabel;
    this.filters = filters;
  }
}
