export class Opportunity {
    quoteHeaderID: string;
    lob: string;
    status: string;
    marketSegment: string;
    fundingType: string;
    insertedTimestamp: string;
    contractEffectiveDate: string;
    contractEndDate: string;
    versionNumber: number;
    submittedTimestamp: string;
    submittedUser: string;
    quoteHistoryID: string;

}