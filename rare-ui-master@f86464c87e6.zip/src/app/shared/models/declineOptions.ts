import { FormControl } from "@angular/forms";

export interface DeclineOptions {
	declineOptionsForm: FormControl<any>;
}