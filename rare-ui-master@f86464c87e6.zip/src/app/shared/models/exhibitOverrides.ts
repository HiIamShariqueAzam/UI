import { FormControl } from "@angular/forms";

export interface PeOverrideData {
    quotedCount: FormControl<string>;
    eligibleCount: FormControl<string>;
    waiverCount: FormControl<string>;
    contractEndDate: FormControl<string>;
    contractEffectiveDate: FormControl<string>;
    contractEffectiveDateIncurred: FormControl<string>;
}

export interface SuppHealthPeOverrideData {
    rateGuaranteeEffectiveDate: FormControl<string>;
    rateGuaranteeEndDate: FormControl<string>;
    rateGuaranteeMonths : FormControl<string>;
}

export interface DentalPeOverrideData {
    rateGuaranteeEffectiveDate: FormControl<string>;
    rateGuaranteeEndDate: FormControl<string>;
    rateGuaranteeMonths : FormControl<string>;
}

export interface VisionPeOverrideData {
    rateGuaranteeEffectiveDate: FormControl<string>;
    rateGuaranteeEndDate: FormControl<string>;
    rateGuaranteeMonths : FormControl<string>;
}

export interface Lives {
    eeCount: FormControl<string>;
    esCount: FormControl<string>;
    e1Count: FormControl<string>;
    ecCount: FormControl<string>;
    ekCount: FormControl<string>;
    efCount: FormControl<string>;
}

export interface PeSheets {
    proposalSheets: FormControl<string>;
}