import { FormControl } from "@angular/forms";

export interface LoginGroup {
    usergroup: FormControl<any>;
}