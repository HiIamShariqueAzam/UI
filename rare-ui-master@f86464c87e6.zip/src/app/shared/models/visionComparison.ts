export class Enrollments {
    enrollT1: number;
    enrollT2: number;
    enrollT3: number;
    enrollT4: number;
    enrollT5: number;
    totalEnroll: number;
}

export class PlanRates {
    ratesT1: number;
    ratesT2: number;
    ratesT3: number;
    ratesT4: number;
    ratesT5: number;
    monthlyTotal: number;
    yearlyTotal: number;
}

export class PlanComparison {

    currPlanId: string;
    currentCarrierName: string;
    currentplanName: string;
    currentFundingType: string;

    quoteRatingPlanID: string;
    quoteContractCode: string;
    quoteLegalEntity: string;
    quotePlanName: string;
    quoteFundingType: string;

    eeContribution: string;
    depContribution: string;

    currentTier: number;
    quoteTier: number;

    currentEnrollments: Enrollments;
    quoteEnrollments: Enrollments;

    currentRates: PlanRates;
    renewalRates: PlanRates;
    quoteRates: PlanRates;

    diffToCurrentMonthlyRate: number;
    diffToCurrentYearlyRate: number;
    diffToCurrentRatePercentage: number;

    diffToRenewalMonthlyRate: number;
    diffToRenewalYearlyRate: number;
    diffToRenewalRatePercentage: number;

    showPlanInPrint: boolean;
    hasRenewalRates: boolean;
    tempQuoteRatingPlanID: string;
}

export class VisionPremiumComparison {

    currentDate: Date;
    renewalDate: Date;
    quoteDate: Date;

    planComparison: PlanComparison[];

    currentMonthlyGrandTotal: number;
    renewalMonthlyGrandTotal: number;
    quoteMonthlyGrandTotal: number;

    currentYearlyGrandTotal: number;
    renewalYearlyGrandTotal: number;
    quoteYearlyGrandTotal: number;


    diffToCurrentMonthlyTotal: number;
    diffToCurrentYearlyTotal: number;
    diffToCurrentRatePercentage: number;

    diffToRenewalMonthlyTotal: number;
    diffToRenewalYearlyTotal: number;
    diffToRenewalRatePercentage: number;

    diffToCurrentRenewalPercentage: number;
    renewalIncreasePercentage : number;
    differenceToCurrentRenewalYearlyTotal: number;
    userModified: boolean;
    hasRenewalRates: boolean;
}


