import { FormControl } from "@angular/forms";

export interface CuriaReportForm {
    state: FormControl<string>;
    fromdate: FormControl<any>;
    todate: FormControl<any>;
    states: FormControl<string>;
    t3stFilter: FormControl<string>;
}

export interface ReportForm {
    lob: FormControl<string>;
    state: FormControl<string>;
    dateField: FormControl<string>;
    fromdate: FormControl<any>;
    todate: FormControl<any>;
    t3stFilter: FormControl<string>;
    reportDataType: FormControl<string>;
    status: FormControl<string>;
    fundingType: FormControl<string>;
    opportunityType: FormControl<string>;
    marketSegment: FormControl<string>;
}
export interface JsonFormValidators {
    min?: number;
    max?: number;
    required?: boolean;
    requiredTrue?: boolean;
    email?: boolean;
    minLength?: boolean;
    maxLength?: boolean;
    pattern?: string;
    nullValidator?: boolean;
  }
  export interface JsonFormControlOptions {
    defaults?: [];
    elements?: [];
   
  }
  export interface JsonFormControls {
    name: string;
    label: string;
    value: string;
    type: string;
    placeholder:string;
    options?: JsonFormControlOptions;
    required: boolean;
    validators: JsonFormValidators;
  }
  export interface JsonFormData {
    reportName:string,
    reportValue:string,
    controls: JsonFormControls[];
  }
  export interface AnalyticsReportData
  {
    reportUUID:string;
    reportName:string;
    reportCriteria:AnalyticsReportCriteria[];
  }
  export interface AnalyticsReportCriteria
  {
    fieldDisabled: string;
    criteriaId: string;
    fieldName: string;
    fieldType: string;
    mandatory: string;
    fieldLabel: string;
    fieldDefault:string;
    selectedDefaultValue: string;
  }