import { FormControl } from "@angular/forms";

export interface RenewalForm {
    lobs: FormControl<string>;
    batchName: FormControl<string>;
    createdBy: FormControl<string>;
    fromdate: FormControl<any>;
    todate: FormControl<any>;
    quoteReason: FormControl<string>;
    batchOrigin: FormControl<string>;
}