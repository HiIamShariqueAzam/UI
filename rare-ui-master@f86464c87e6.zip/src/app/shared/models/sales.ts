import { FormControl } from "@angular/forms";

export interface salesForm {
    Rows: any;
}