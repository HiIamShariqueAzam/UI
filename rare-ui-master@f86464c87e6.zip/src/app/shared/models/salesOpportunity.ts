import { FormControl } from "@angular/forms";

export interface GroupInformation {
    groupName: FormControl<any>;
    addr1: FormControl<string>;
    addr2: FormControl<string>;
    city: FormControl<string>;
    companyZipCode: FormControl<string>;
    state: FormControl<any>;
    sicFrmCtrlName: FormControl<any>;
    msFrmCtrlName: FormControl<any>;
    quoteReason:FormControl<any>;
}

export interface MarketSegInformation {
    marketBusinessSegment: FormControl<any>;
    mbuFrmCtrlName: FormControl<any>;
    participationName: FormControl<any>;
    chamberName: FormControl<any>;
    premiumDelayName: FormControl<any>;
    empFundLevelName: FormControl<any>;
    virGrpQteName: FormControl<any>;
    calEffDateName: FormControl<string>;
    conDueDateName: FormControl<any>;
    conEndDateName: FormControl<string>;
    quoteName: FormControl<string>;
    specialQuoteType: FormControl<any>;
}

export interface CommissionInformation {
    srFrmCtrlName: FormControl<any>;
    aslFrmCtrlName: FormControl<any>;
    sslFrmCtrlName: FormControl<any>;
    ftFrmCtrlName: FormControl<any>;
    cpFrmCtrlName: FormControl<any>;
    fiCommFrmCtrlName: FormControl<any>;
    fiCommValFrmCtrlName: FormControl<any>;
    abfCommFrmCtrlName: FormControl<any>;
    abfCommValFrmCtrlName: FormControl<any>;
}

export interface PlanFormGroup {
    Rows: any;
}