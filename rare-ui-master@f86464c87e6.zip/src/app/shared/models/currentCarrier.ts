import { FormControl } from "@angular/forms";

export interface CurrentCrrForm {
    tblAllCheck: any;
    Rows: any;
}