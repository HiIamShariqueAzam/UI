import { FormControl } from "@angular/forms";

export interface LoginForm {
    serviceID: FormControl<string>;
    password: FormControl<string>;
}