import { FormControl } from "@angular/forms";

export interface BatchSearchForm {
    groupName: FormControl<any>;
    groupNumber: FormControl<any>;
    states: FormControl<any>;
    lob: FormControl<any>;
    marketSegments: FormControl<any>;
    fundingTypes: FormControl<any>;
    renewalMonths: FormControl<any>;
    renewalYears: FormControl<any>;
    renewalMonthYear: FormControl<any>;
    mbs: FormControl<any>;
    association: FormControl<any>;
    system: FormControl<any>;
    dataSource: FormControl<any>;
    includeTestQuotes: FormControl<any>;
}

export interface BatchSaveGroup {
    batchName: FormControl<string>;
    quoteReason: FormControl<string>;
    isAutoRunBatch: FormControl<string>;
}

export interface DownloadForm {
    downloadOptions: FormControl<string>;
}