// RENEWAL_BATCH
export interface RenewalBatch {
  id?: string;
  batchName?: string;
  submissionProcessID?: string,
  statusEmitterID?: string,
  batchStatus?: SubmissionStatus;
  batchQuoteStatusEmitStatus?: BatchQuoteStatusEmitStatus;
  createdBy?: string;
  loggedUserID?: string;
  loggedUserName?: string;
  updatedBy?: string;
  updatedTimestamp?: string;
  fileUploadStatus?: string;
  adjustmentStatus?: string;
  recentReleaseProcessStatus?: string;
  errorList?: [];
  quoteReason?: string;
  batchOrigin?: string;
  quoteOrigin?: string;
  actionPerformed?: string;
  lobs?: string[];
  tieringInfo?: any; 
  tieringStatus?: string;
  tieringStatusEmitterID?: string;
  groupRiskDetails?: any;
  groupsExcludedFromTiering?: any;
}

// RENEWAL_BATCH_DETAILS
export interface RenewalBatchDetails {
  id?: string;
  batchID?: string;
  currentQuoteStatusBatchID?: string;
  currentQuoteStatusBatchName?: string;
  uniqueRecordID?: string;
  statusEmitterID?: string;
  renewalDate: string;
  fundingType: string;
  groupName: string;
  groupNumber: string;
  lob: string;
  marketSegment: string;
  state: string;
  included?: boolean;
  uploadStatus?: string;
  quoteRenewalStatus?: string;
  submissionStatus?: QuoteSubmissionStatus;
  opportunityID?: string;
  quoteHeaderID?: string;
  isSubmitted?: boolean;
  isQueuedForDataGathering?: boolean;
  isRenewalDashboardSubmission?: boolean;
  isRequestCreated?: boolean;
  isSubmittedToGateWay?: boolean;
  isSpecialtySubmittedToGateWay?: boolean;
  isUnifiedPayloadSubmission?: boolean;
  isSSEQuoteStatusReceived?: boolean;
  submittedTimestamp?: string;
  submissionFailCheckPoint: string;
  submissionErrors?: any;
  quoteErrors?: any;
  specialtySubmittedStatus?: string;
  specialtyErrors?: any;
  mbu: string;
  sslLevel?: any;
  aslLevel?: any;
  refundPct?: any;
  originalGroupNumber?: string;
  commissionValue?: any;
  commissionValueNew?: any;
  commissionType?: string;
  commissionTypeNew?: string;
  isCommissionOverridden?: string;
  adjustmentsTrail?: any;
  priorGroupNumbers?: any;
  invalidGroupNumbersForMerge?: any;
  alternateQuotes?: any;
  source?: string;
  inRateGuarantee?: boolean;
  assnCd?: string;
}

// RENEWAL_BATCH_WRAPPER
export interface RenewalBatchWrapper {
  renewalBatch: RenewalBatch,
  renewalBatchDetails: RenewalBatchDetails[] | [],
  failedGrpNbrsInSearch: string[] | [],
}

//SUBMISSION_STATUS
export enum SubmissionStatus {
  SUBMITTED = "Submitted", //When the Batch is submitted
  NOT_SUBMITTED = "Not Submitted", //When the Batch is yet to be submitted
  SUCCESS = "Executed Successfully", //When all the quotes in the Batch are submitted to Gateway Successfully
  PARTIAL = "Executed with errors", //When some of the quotes in the Batch are submitted to Gateway Successfully and rest are failed.
  FAILED = "Failed", //When all the quotes in the Batch are NOT submitted to Gateway Successfully
  LOADING = "Loading..." // Only for UI Purpose
}

//This should be in sync with src/main/java/com/anthem/rare/service/common/constant/EnumConstants.java
export enum QUOTE_ORIGIN {
  PARTNER_API = "partnerAPI",
  CONVERTED_AUTO_RUN = "convertedAutoRun",
  OPPORTUNITY_SCREEN = "oppScreen",
  USER_BATCH = "userBatch",
  AUTO_RUN_BATCH = "autoRunBatch"
}

//This should be in sync with src/main/java/com/anthem/rare/service/common/constant/EnumConstants.java
export enum BATCH_ORIGIN {
  AUTO_RUN_BATCH = "autoRunBatch",
  USER_BATCH = "userBatch"
}

//BATCH_SSE_PROCESS
export enum BatchSSEProcess {
  SUBMISSION = "SSE_SBMSN", //Represents Submission To Gateway SSE Events Process
  QUOTESTATUSRETRIEVAL = "SSE_QSR" //Represents Quote Status retrieval SSE Events Process
}

//BATCH_QUOTESTATUS_EMIT_STATUS
export enum BatchQuoteStatusEmitStatus {
  NOT_STARTED = "Not Started", //When quote retrieval status in batch is not started
  STARTED = "Started", //When quote retrieval status in batch is started
  COMPLETED = "Completed"//When all the quotes in the Batch receives their initial End statuses successfully in a batch.
}

//QUOTE_SUBMISSION_STATUS
export enum QuoteSubmissionStatus {
  //This is all about submitting to Gateway.
  NOT_SUBMITTED = 'Not Submitted', //When the Quote in a Batch is yet to be submitted
  SUBMITTED = 'Submitted', //When the Quote in a Batch is submitted
  QUEUED_FOR_DATA_GATHERING = 'Queued for Data Gathering', //When the Quote in a Batch is queued for data gathering
  QUEUED_FOR_RATING = 'Queued for Rating', //When the Quote in a Batch is queued for Rating
  DASHBOARD_SUBMISSION_SUCCESS = 'Renewal Dashboard Submission',
  GATEWAY_SUBMISSION = 'Gateway Submission', //When the Quote in a Batch is submitted to Gateway
  OPPORTUNITY_SUBMISSION = 'Opportunity Submission', //When the Quote in a Batch is opportunity submission
  SUCCESS = 'Success', //When Quote in a Batch is successfully submitted to Gateway
  FAILED = 'Failed' //When Quote in a batch failed submitting to Gateway
}

//RELEASE_STEPS
export enum ReleaseSteps {
  MED_ADJUST = "Medical Adjustment Save",
  MED_GENERATE_EXHIBIT = "Medical Exhibit Generation",
  VIS_GENERATE_EXHIBIT = "Vision Exhibit Generation",
  DEN_GENERATE_EXHIBIT = "Dental Exhibit Generation",
  MED_MERGE_EXHIBITS = "Merge Exhibits",
  MED_GENERATE_FINAL_RESPONSE = "Medical Response Generation",
  MED_SUBMIT_RESPONSE_EXTERNAL = "Medical Response Submission",
  MED_UPDATE_STATUS = "Medical Update Status",
  VIS_ADJUST = "Vision Adjustment Save",
  DEN_ADJUST = "Dental Adjustment Save",
  VIS_GENERATE_FINAL_RESPONSE = "Vision Response Generation",
  VIS_SUBMIT_RESPONSE_EXTERNAL = "Vision Response Submission",
  VIS_UPDATE_STATUS = "Vision Update Status",
  DEN_GENERATE_FINAL_RESPONSE = "Dental Response Generation",
  DEN_SUBMIT_RESPONSE_EXTERNAL = "Dental Response Submission",
  DEN_UPDATE_STATUS = "Dental Update Status",
  SUPP_HEALTH_ADJUST = "Supp Health Adjustment Save",
  SUPP_HEALTH_GENERATE_EXHIBIT = "Supp Health Exhibit Generation",
  SUPP_HEALTH_GENERATE_FINAL_RESPONSE = "Supp Health Response Generation",
  SUPP_HEALTH_SUBMIT_RESPONSE_EXTERNAL = "Supp Health Response Submission",
  SUPP_HEALTH_UPDATE_STATUS = "Supp Health Update Status"
}

//ALERT_TYPE
export enum AlertType {
  SUCCESS = "success",
  WARNING = "warning",
  ERROR = "error"
}

//QUOTE_RENEWAL_STATUS
export enum QuoteRenewalStatus {
  PROCESSING = "Processing",
  PENDING = "Pending Review",
  RELEASED = "Released",
  DECLINED = "Declined",
  SUCCESS = "Success",
  FAIL = "Failed",
  MODIFIED = "Modified",
  SOLD = "Sold",
  SOLD_MODIFIED = "Sold Modified",
  PRESOLD = "Pre-Sold",
  QUOTE = "Quote",
  PROCESSED = "Processed",
  RECEIVED = "Received",
  AWAITING_P2A_DATA = "Awaiting P2A data",
  AWAITING_RISK_SCORE = "Awaiting Risk Score",
  READY_TO_EXPORT = "Ready to Export",
  EXPORTED = "Exported",
  FAILED_TO_GATEWAY = 'Failed to Gateway',
  SENT_TO_RARE = 'Sent To Rare',
  PENDING_EXHIBIT = 'Pending Exhibit',
  MISSING_INFO = 'Missing Information',
  IN_ANALYSIS = 'In Analysis',
  LOST = 'Lost',
  TRANSFER = 'Transfer',
  CLOSE = 'Close'
}

export enum NonChangeableRenewalStatuses {
  AWAITING_RISK_SCORE = "Awaiting Risk Score",
  AWAITING_P2A_DATA = "Awaiting P2A data",
  RECEIVED = "Received",
  FAILED_TO_GATEWAY = 'Failed to Gateway',
  SENT_TO_RARE = 'Sent To Rare'
}

export enum ConvertBulkStatus {
  CONVERT_STARTED = 'Convert Started',
  CONVERT_CHECK_ELIGIBILITY = 'Check Eligibility',
  CONVERTED = 'Converted Successfully'
}
