import { FormControl } from "@angular/forms";

export interface AnalyticsData {
    fromdate: FormControl<string>;
    todate: FormControl<string>;
}