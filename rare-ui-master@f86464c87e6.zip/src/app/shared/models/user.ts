﻿export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    token: string;
}
export interface LoginUser{
    username:string;
    password:string;
    role:string;
}

export class RateInfo {
    single: number;
    eeOne: number;
    eeSpouse: number;
    eeChild: number;
    eeChildren: number;
    family: number;
}

export class MedicalPlans {
    innDedIndividual: number;
    innDedFamily: number;
}
