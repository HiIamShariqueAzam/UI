import { FormControl } from "@angular/forms";

export interface TierInfo {
    inputTierCtrl: FormControl<any>;
    outputTierCtrl: FormControl<any>;
}