export class Lives {
    eeCount: number;
    esCount: number;
    e1Count: number;
    efCount: number;
    ecCount: number;
    ekCount: number;
}

export class PlanLevelLives {
    ratingPlanID: string;
    lives: Lives;
}