export class RareConstants {
    public static medical='Medical';
    public static vision='Vision';
    public static dental='Dental';
    public static suppHealth='Supp Health'
    public static medicalLC='medical';
    public static visionLC='vision';
    public static dentalLC='dental';
    public static ABF='ABF';
 }
