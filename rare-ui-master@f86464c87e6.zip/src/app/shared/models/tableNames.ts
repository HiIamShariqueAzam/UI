export interface TableNames {  
    displayName?; 
    tableName?;
}