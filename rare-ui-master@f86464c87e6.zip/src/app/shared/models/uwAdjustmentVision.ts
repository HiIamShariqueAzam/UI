import { FormControl } from "@angular/forms";

export interface AdjustmentVision {
    uwAdjustmentFactor: FormControl<string>;
    employerRiskFactor: FormControl<string>;
    salesAdjustmentFactor: FormControl<string>;
    wholeHealthAdjustmentFactor: FormControl<string>;
    outputTier: FormControl<string>;
    uwNotesToSales: FormControl<string>;
    uwComments: FormControl<string>;
    salesNotetoUW: FormControl<string>;
    contractEndDate: FormControl<string>;
    exhibitName: FormControl<string>;
    approvalStatus: FormControl<string>;
    submittedTimestamp: FormControl<string>;
    quoteReason: FormControl<string>;
}