import { FormControl } from "@angular/forms";

export interface ChartFilterForm {
    state: FormControl<string>;
    lob: FormControl<string>;
    opportunityType: FormControl<string>;
    fundingType: FormControl<string>;
    marketSegment: FormControl<string>;
    mbs: FormControl<string>;
    fromdate: FormControl<any>;
    todate: FormControl<any>;
    timePeriod3: FormControl<any>;
    chartType: FormControl<any>;
    dateType: FormControl<any>;
  }