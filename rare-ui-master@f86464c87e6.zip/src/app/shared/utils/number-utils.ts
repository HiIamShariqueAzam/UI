 export class NumberUtils {
   
     public static isKeyPressForAValidNumber(event: KeyboardEvent, decimalPlaces: number): void {
      const inputChar = event.key;
      const inputValue = event.target['value'];
    
      // Ensure the input is a valid number with limited decimal places
      const regex = new RegExp(`^-?\\d*(\\.\\d{0,${decimalPlaces}})?$`);
      
      if (regex.test(inputValue + inputChar)) {
        return; // Allow the input
      }
    
      event.preventDefault(); // Prevent the input if it doesn't match the criteria
    }
 
 
   
  }
