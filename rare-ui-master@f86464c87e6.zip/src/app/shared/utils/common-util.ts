/** *****************************************************************************
 * Copyright (c) Anthem. All rights reserved.
 * Use is subject to license terms.
 * CommonUtil class to support common functionalities across modules.
 * Need to create new common shared module and move this to shared module.
 *
 ***********************************************************************************/

import { CommonConstants } from "../constants/common.constants";
import { AuthenticationService } from "../services";
import { DateUtil } from "./date-util";
import { StringUtils } from "./string-utils";

export class CommonUtil {

  private static DEFAULT_DECIMAL_PLACES_FOR_INPUT_FIELDS = 10;

  /**
   * Check if the given LOB is a specialty LOB (Dental, Vision, or Supplemental Health)
   * @param lobName - Name of the LOB
   * @returns true if specialty LOB, false otherwise
   */
  private static isSpecialtyLob(lobName: string): boolean {
    return [CommonConstants.Dental, CommonConstants.Vision, CommonConstants.SuppHealth]
      .some(lob => StringUtils.isEqual(lob, lobName));
  }

  /**
   * Function to check if user has Admin role.
   * @param userRole
   * @returns
   */
  public static userHasAdminRole(userRole) {
    return String(userRole).indexOf("ADMIN") !== -1 ? true : false;
  }

  public static userHasRenewalBatchRole(userRole) {
    return userRole.includes('RENEWALBATCH') ? true : false;
  }

  public static userHasUnderwriterRole(userRole) {
    return userRole.includes('UNDERWRITER') ? true : false;
  }
  public static checkUserRole(role) {
    if (role.includes('ADMIN') || role.includes('READONLY')) {
      return true;
    } else if (role.includes('ADMIN') && !role.includes('READONLY')) {
      return false;
    }
  }
  /**
 * method to get COM2 url for quoteHeaderId hyperlink
 * @param supportingDocLinks
 * @param supportingDocLinksKeywords
 */
  public static getCOM2url(supportingDocLinks, supportingDocLinksKeywords): any {
    let isIEbrowser = window.navigator.userAgent.toUpperCase().indexOf("TRIDENT/") != -1
      || window.navigator.userAgent.toUpperCase().indexOf("MSIE") != -1;
    if (supportingDocLinks && Array.isArray(supportingDocLinks)) {
      //Combined Attachments check to support existing quotes before september 2021 relase.
      let combinedAttachmentsExists = supportingDocLinks.find(link => link.search(/CombinedAttachments/i) !== -1);
      for (let docLink of supportingDocLinks) {
        if (docLink) {
          if (isIEbrowser) {
            if (!combinedAttachmentsExists) {
              if (this.checkDocLinkKeywords(docLink, false, supportingDocLinksKeywords)) {
                return { showHyperlink: true, href: docLink };
              }
            } else if (docLink && docLink.search(/lightning/i) == -1 &&
              docLink.search(/CombinedAttachments/i) == -1 &&
              docLink.search(/commercial/i) !== -1) {
              return { showHyperlink: true, href: docLink };
            }
          } else {
            if (!combinedAttachmentsExists) {
              if (this.checkDocLinkKeywords(docLink, true, supportingDocLinksKeywords)) {
                return { showHyperlink: true, href: docLink };
              }
            } else if (docLink.search(/lightning/i) !== -1 && docLink.search(/CombinedAttachments/i) !== -1) {
              return { showHyperlink: true, href: docLink };
            }
          }
        }
      }
    }
    return { showHyperlink: false, href: null };
  }
  public static checkDocLinkKeywords(docLink: any, equalCheck: any, supportingDocLinksKeywords) {
    if (supportingDocLinksKeywords) {
      for (let keyword of supportingDocLinksKeywords.split(',')) {
        let regEx = new RegExp(`\\b${keyword}\\b`, 'i');
        if (equalCheck) {
          if (docLink.search(regEx) == -1) {
            return false;
          }
        } else if (docLink.search(regEx) !== -1) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * Check if the UW factor is valid number or not
   *
   * @param evt The event object from the input field.
   * @returns Returns true if the input is a number with up to the DEFAULT_DECIMAL_PLACES_FOR_INPUT_FIELDS, and false otherwise.
   */
  public static isNumber(evt) {
    return CommonUtil.isNumberWithGivenDecimalPlaces(evt, CommonUtil.DEFAULT_DECIMAL_PLACES_FOR_INPUT_FIELDS);
  }

  /**
   * Checks if the input is a number with a given number of decimal places.
   *
   * @param evt The event object from the input field.
   * @param decimalPlaces The maximum number of decimal places allowed.
   * @returns Returns true if the input is a number with up to the given number of decimal places, and false otherwise.
   */
  public static isNumberWithGivenDecimalPlaces(evt, decimalPlaces) {
    var el = evt.target;
    var charCode = evt.charCode;
    var number = el.value.split(".");
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (number.length > 1 && charCode == 46) {
      return false;
    }
    var caratPos = this.getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && number[1].length > decimalPlaces - 1) {
      return false;
    }
    return true;
  }

  public static getSelectionStart(o) {
    return o.selectionStart;
  }

  public static convertSpecialCharToASCII(str) {
    let result = '';
    for (let i = 0; i < str.length; i++) {
      let char = str[i];
      if (/[<>&]/.test(char)) {
        let entity = '&#' + char.charCodeAt(0) + ';';
        result += entity;
      } else {
        result += char;
      }
    }
    return result;
  }

  public static asciiToCharacter(val) {
    return val.replace(/#%/g, "<").replace(/%#/g, ">");
  }

  public static stringToAscii(val) {
    return val.replace(/</g, "#%").replace(/>/g, "%#");
  }

  public static htmlEntitiesToString(str) {
    var result = "";
    for (var i = 0; i < str.length; i++) {
      if (str[i] === "&") {
        var j = str.indexOf(";", i + 1);
        if (j === -1) {
          result += str[i];
          continue;
        }
        var entity = str.substring(i, j + 1);
        var code = entity.substring(2, entity.length - 1);
        result += String.fromCharCode(code);
        i = j;
      } else {
        result += str[i];
      }
    }
    return result;
  }

  public static getSortedList(unsortedList) {
    if (unsortedList && unsortedList.length > 1) {
      return unsortedList.sort();
    }
    return unsortedList;
  }

  public static getUserIDHeader(authenticationService) {
    if (authenticationService.getUserID()) {
      return authenticationService.getUserID()
    }
    return CommonConstants.DEFAULT_USER_ID_HEADER;
  }

  public static getUserNameHeader(authenticationService) {
    if (authenticationService.getUserName()) {
      return authenticationService.getUserName()
    }
    return CommonConstants.DEFAULT_USER_NAME_HEADER;
  }

  public static isEmptyValue(value) {
    return ( !value || value === '' || value === 'null');
  }

  public static modalPopup(content: HTMLElement, modalHandler: HTMLElement[] = []): () => void {
    if (!content) return () => { };
    const dialog = content.closest<HTMLElement>('.modal-dialog') || content;
    const cleanup: Array<() => void> = [];

    // Fix Dropdowns: Force them to render relative to viewport to avoid clipping
    content.querySelectorAll('[data-bs-toggle="dropdown"]').forEach(btn => {
      btn.setAttribute('data-bs-boundary', 'viewport');
    });
    
    if (modalHandler?.length) {
    // 1. Optimized Dragging (Resolution-Safe)
      modalHandler.forEach(h => {
      h.style.cursor = 'move';
      const onDown = (e: MouseEvent) => {
        if (e.button !== 0) return;
        const r = dialog.getBoundingClientRect();
        const offsetX = e.clientX - r.left, offsetY = e.clientY - r.top;

        const move = (ev: MouseEvent) => {
          // Use percentages for positioning to stay responsive
          const leftPct = ((ev.clientX - offsetX) / window.innerWidth) * 100;
          const topPct = ((ev.clientY - offsetY) / window.innerHeight) * 100;
          Object.assign(dialog.style, {
            position: 'fixed', margin: '0',
            left: `${leftPct}%`, top: `${topPct}%`,
            transform: 'none' // Remove BS default transform
          });
        };
        const up = () => {
          document.removeEventListener('mousemove', move);
          document.removeEventListener('mouseup', up);
        };
        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
      };
      h.addEventListener('mousedown', onDown);
      cleanup.push(() => h.removeEventListener('mousedown', onDown));
    });
  }

    // 2. Optimized Resizing
    // Instead of overflow: auto (which kills dropdowns), we add a tiny resize handle
    Object.assign(content.style, { resize: 'both', overflow: 'visible' });
    // Ensure the handle is visible even with overflow: visible
    content.style.setProperty('display', 'block', 'important');

    return () => cleanup?.forEach(fn => fn());
  }

  /**
   * A quote that was never sold has no coverage in force, so terminating it
   * ends the contract one day before it would have started.
   * @param rateData - The rate data containing the quote status
   */
  public static isQuoteNeverSold(rateData: any): boolean {
    return (rateData?.status?.toString() || '') !== 'Sold';
  }

  /**
   * Utility method to handle off-cycle data for UW adjustments
   * Shared across Medical, Dental, and Vision LOBs
   * @param reqObj - The request object to populate with off-cycle data
   * @param rateData - The rate data containing off-cycle information
   * @param status - Current status of the quote
   * @param action - Action being performed (save, decline, etc.)
   * @param offCycleSubmittedInCurrentSession - Flag indicating if off-cycle was submitted in current session
   * @param lobName - Name of the LOB (Medical, Dental, Vision)
   * @param contractEffectiveDateField - Field name for contract effective date in rateData
   */
  public static handleOffCycleData(
    reqObj: any,
    rateData: any,
    status: string,
    action: string,
    offCycleSubmittedInCurrentSession: boolean,
    lobName: string,
    contractEffectiveDateField: string = 'contractEffectiveDate'
  ): void {
    const currentStatus = status?.toString() || '';
    const opportunityType = rateData?.opportunityType || '';
    const isNewBusiness = opportunityType === CommonConstants.NEW_BUSINESS_LOCAL;
    
    const requiresOffCycleData = ['Declined', 'Lost', 'Termed', 'Transfer'].includes(currentStatus) 
      || StringUtils.isEqual(action, CommonConstants.declineAction);
    
    // Specialty LOBs (Dental, Vision, Supplemental Health) should NOT auto-add offCycle on decline
    // But should still allow it when user explicitly clicks Off-Cycle button
    const isDeclineAction = StringUtils.isEqual(action, CommonConstants.declineAction) 
      || StringUtils.isEqual(currentStatus, CommonConstants.declinedStatus);
    
    // Skip auto-adding offCycle for specialty LOBs on decline (unless user explicitly submitted via Off-Cycle button)
    const skipAutoOffCycle = this.isSpecialtyLob(lobName) && isDeclineAction && !offCycleSubmittedInCurrentSession;
    if (skipAutoOffCycle) {
      return;
    }

    // For New Business: do NOT send off-cycle data for Declined, Lost, Termed, Transfer, or decline action
    // For Renewals: send off-cycle data for all terminal statuses
    if ((!isNewBusiness || !requiresOffCycleData) && (requiresOffCycleData || offCycleSubmittedInCurrentSession)) {
      if (!reqObj.uwAdjustment) {
        reqObj.uwAdjustment = {};
      }

      if (!reqObj.uwAdjustment.offCycle) {
        reqObj.uwAdjustment.offCycle = {};
      }

      // Use existing off-cycle data if present (user entered via modal)
      if (rateData.offCycle && rateData.offCycle.contractEndDate) {
        reqObj.uwAdjustment.offCycle.contractEndDate = rateData.offCycle.contractEndDate;
        reqObj.uwAdjustment.offCycle.lobs = rateData.offCycle.lobs || [rateData.lob || lobName];

        // Always include status reason in the payload
        reqObj.uwAdjustment.offCycle.statusReason = rateData.offCycle.statusReason;

        // Set terminationFlag based on status
        if (requiresOffCycleData) {
          // Always true for terminal statuses
          reqObj.uwAdjustment.offCycle.terminationFlag = true;
        } else {
          // For Sold status, use the terminationFlag from rateData if explicitly set, otherwise check if contract has started
          reqObj.uwAdjustment.offCycle.terminationFlag = rateData.offCycle.terminationFlag !== undefined 
            ? rateData.offCycle.terminationFlag 
            : DateUtil.isDateInPast(rateData[contractEffectiveDateField]);
        }
        
        // Update status in request object if it was set in rateData (e.g., from Off-Cycle modal)
        if (rateData.status) {
          reqObj.uwAdjustment.status = rateData.status;
        }
      } else if (requiresOffCycleData) {
        // Auto-calculate for terminal statuses when no user input
        reqObj.uwAdjustment.offCycle.contractEndDate = DateUtil.calculateOffCycleEndDate(
          rateData[contractEffectiveDateField],
          CommonUtil.isQuoteNeverSold(rateData)
        );
        reqObj.uwAdjustment.offCycle.lobs = [rateData.lob || lobName];
        reqObj.uwAdjustment.offCycle.terminationFlag = true;
      }
    }
  }
}
