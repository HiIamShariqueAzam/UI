export class DateUtil {
    public static checkDateDifference(date1, date2) {
        if (date1 <= date2) {
            return false;
        }
        else {
            return true;
        }
    }

    public static formatDate(timestamp) {
        return new Date(timestamp).toLocaleDateString("en-US", {
            month: "short",
            day: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        });
    }

 /**
     * Parse a date string in various formats (YYYY-MM-DD, MM-DD-YYYY, or ISO) to a Date object
     * @param dateStr - Date string to parse
     * @returns Date object with time set to 00:00:00, or null if invalid
     */
    public static parseDate(dateStr: string): Date | null {
        if (!dateStr) return null;

        let parsedDate: Date;
        if (dateStr.includes('-')) {
            const parts = dateStr.split('-');
            if (parts[0].length === 4) {
                // YYYY-MM-DD format
                parsedDate = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
            } else {
                // MM-DD-YYYY format
                parsedDate = new Date(parseInt(parts[2]), parseInt(parts[0]) - 1, parseInt(parts[1]));
            }
        } else {
            parsedDate = new Date(dateStr);
        }
        parsedDate.setHours(0, 0, 0, 0);
        return parsedDate;
    }

    /**
     * Get the last day of the current month
     * @returns Date object representing the last day of current month
     */
    public static getLastDayOfCurrentMonth(): Date {
        const today = new Date();
        return new Date(today.getFullYear(), today.getMonth() + 1, 0);
    }

    /**
     * Check if a date has already passed (is before or equal to today)
     * @param dateStr - Date string to check
     * @returns true if date is in the past or today, false otherwise
     */
    public static isDateInPast(dateStr: string): boolean {
        const date = this.parseDate(dateStr);
        if (!date) return false;

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return date <= today;
    }

    /**
     * Check if a date is in the future (is after today)
     * @param dateStr - Date string to check
     * @returns true if date is in the future, false otherwise
     */
    public static isDateInFuture(dateStr: string): boolean {
        const date = this.parseDate(dateStr);
        if (!date) return false;

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return date > today;
    }

    /**
     * Get one day before a given date string
     * @param dateStr - Date string
     * @returns Date object representing one day before the input date, or null if invalid
     */
    public static getOneDayBeforeDate(dateStr: string): Date | null {
        const date = this.parseDate(dateStr);
        if (!date) return null;

        return this.getOneDayBefore(date);
    }

    /**
     * Format a Date object to YYYY-MM-DD string
     * @param date - Date object to format
     * @returns Date string in YYYY-MM-DD format
     */
    public static formatToYYYYMMDD(date: Date): string {
        if (!date) return '';
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    /**
     * Get one day before a given date
     * @param date - Date object
     * @returns New Date object representing one day before the input date
     */
    public static getOneDayBefore(date: Date): Date {
        const newDate = new Date(date.getTime());
        newDate.setDate(newDate.getDate() - 1);
        newDate.setHours(0, 0, 0, 0);
        return newDate;
    }

    /**
     * Calculate default off-cycle end date based on contract effective date
     * @param contractEffectiveDateStr - Contract effective date string
     * @param wasNeverSold - true when the quote was never sold, so no coverage ever started
     * @returns Date string in YYYY-MM-DD format
     */
    public static calculateOffCycleEndDate(contractEffectiveDateStr: string, wasNeverSold: boolean = false): string {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const contractEffDate = this.parseDate(contractEffectiveDateStr);

        let defaultEndDate: Date;
        if (contractEffDate && wasNeverSold) {
            // Coverage never started - use one day before contract eff date, even when it is in the past
            defaultEndDate = this.getOneDayBefore(contractEffDate);
        } else if (contractEffDate && contractEffDate < today) {
            // Contract already started - use last day of current month
            defaultEndDate = this.getLastDayOfCurrentMonth();
        } else if (contractEffDate && contractEffDate >= today) {
            // Contract not started - use one day before contract eff date
            defaultEndDate = this.getOneDayBefore(contractEffDate);
        } else {
            // Fallback - use last day of current month
            defaultEndDate = this.getLastDayOfCurrentMonth();
        }

        return this.formatToYYYYMMDD(defaultEndDate);
    }

}
