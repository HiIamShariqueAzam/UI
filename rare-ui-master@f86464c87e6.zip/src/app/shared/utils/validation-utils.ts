export class ValidationUtils {
   
    public static doNotAllowFirstCharacterToBeSpecialCharacter(event: any): void {
        const specialChars = /^[!@#$%^&*(),.?":{}|<>;+=/_~`'[\]\\-]+$/;
        let input = event.target.value;
        while (specialChars.test(input.charAt(0))) {
            input = input.slice(1);
        }
        event.target.value = input;
    }
  
 }