/** *****************************************************************************
 * Copyright (c) 2017 Anthem. All rights reserved.
 * Use is subject to license terms.
 ***********************************************************************************/
export class StringUtils {
  /**
   * Method to check if a string consecutively repeats 'n' character in another string
   * @param first string, second string and number of consecutive char to check
   */
  public static consecutiveCharCheck(string1, string2, matchChars: number) {
    return !!string2.split('').find(function (item, index) {
      if (index + matchChars <= string2.length) {
        return string1.includes(string2.substring(index, index + matchChars));
      }
      return false;
    });
  }

  // Method to insert the passed string at given index.
  public static insStrAtSpecifiedIndex(str?: string, insStr?: string, pos?: number) {
    if (typeof pos === undefined) {
      pos = 0;
    }
    if (typeof insStr === undefined) {
      insStr = '';
    }
    return str.slice(0, pos) + insStr + str.slice(pos);
  }

  public static isEmpty(value: any): boolean {
    if (value === null || value === undefined || value === '') {
      return true;
    } else {
      return false;
    }
  }

  /**
   * Method to check two strings equal or not
   * @param str1
   * @param str2
   */
  public static isEqual(str1?: string, str2?: string): boolean {
    if (!this.isEmpty(str1) && !this.isEmpty(str2)) {
      if (str1 === str2) {
        return true;
      }
    }
    return false;
  }

  /**
* Method to check two strings equal or not ignoring the case
* @param str1
* @param str2
*/
  public static isEqualIgnoreCase(str1?: string, str2?: string): boolean {
    if (!this.isEmpty(str1) && !this.isEmpty(str2)) {
      str1 = str1.toUpperCase();
      str2 = str2.toUpperCase();
      if (str1 === str2) {
        return true;
      }
    }
    return false;
  }


  /**
   * Checks if two strings are not equal, ignoring case.
   *
   * @param str1 - The first string to compare.
   * @param str2 - The second string to compare.
   * @returns `true` if the strings are not equal ignoring case, `false` otherwise.
   */
  public static isNotEqualIgnoreCase(str1?: string, str2?: string): boolean {
    return !this.isEqualIgnoreCase(str1, str2);
  }

  /**
   * method to check empty object
   * @param obj
   */
  public static isObjectEmpty(obj?: any): boolean {
    return Object.keys(obj).length === 0 && obj.constructor === Object;
  }

  /**
   * Method to check if a variable is undefined
   * @param value
   */
  public static isUndefined(value: any): value is undefined {
    return typeof value === 'undefined';
  }

  /**
   * Method to check if a varaible is of type string
   * @param value
   */
  public static isString(value: any): value is string {
    return typeof value === 'string';
  }

  /**
   * Method to trim empty spaces
   * @param value
   */
  public static trimSpace(value: string) {
    return value ? value.trim() : value;
  }
  /**
   * Method returns String
   * @param value
   */
  public static convertToString(value: string) {
    if (!this.isEmpty(value)) {
      return value.toString();
    }
  }
  /**
   * Method returns Boolean
   * @param value
   * @param array
   */
  public static checkStrExitsInArr(value: string, arr: string[]) {
    return arr.indexOf(value) !== -1;
  }

  /**
   * Checks if any element in the provided string or array of strings exists in the given array.
   *
   * @param {string | string[]} str - The string or array of strings to check.
   * @param {string[]} arr - The array in which to check for the existence of elements.
   * @returns {boolean} - `true` if any element in `str` exists in `arr`, `false` otherwise.
   */
  public static checkArrayObjectExitsInArr(str: string | string[], arr: string[]): boolean {
    const matchedList = Array.isArray(str) ? str : str?.split(',');
    if (!this.isEmpty(matchedList)) {
      return arr.filter((value) => matchedList.some((obj) => obj.includes(value)))?.length > 0;
    }
    return false;
  }
}
