/** *****************************************************************************
 * Copyright (c) 2017 Anthem. All rights reserved.
 * Use is subject to license terms.
 ***********************************************************************************/
export class CalculatorUtils {

    /*
  Calculates total increase in percentage given current plans total and adjusted plans total
  Adjusted plans total must be already multiplied by its increased factor
  */
  public static calculateTotalIncreasePercentage(currentPlansTotal : number, adjustedPlansTotal : number){
    return ((adjustedPlansTotal / currentPlansTotal) - 1) * 100;
  }

  public static convertFactorToPercentage(factor: number): number {
    return (factor - 1) * 100;
  }

    public static convertPercentageToFactor(percentage: number): number {
    return CalculatorUtils.roundFourDecimals((percentage / 100) + 1);
  }

  public static roundFourDecimals(value: number) : number {
    return Math.round(value * 10000) / 10000;
  }
}
