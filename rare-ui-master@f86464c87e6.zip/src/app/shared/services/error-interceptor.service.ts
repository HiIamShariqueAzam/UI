import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ErrorDialogService } from "./error-dialog.service";

/**
 * HTTP interceptor for handling and displaying error messages.
 * This interceptor catches HTTP errors and uses the `ErrorDialogService` to display user-friendly error messages.
 */
@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  /**
   * Constructor for the `ErrorInterceptor`.
   * @param {ErrorDialogService} errorDialogService - Service for displaying error messages in a dialog.
   */
  constructor(private errorDialogService: ErrorDialogService) {}

  /**
   * Intercepts HTTP requests and handles errors.
   * @param {HttpRequest<any>} req - The outgoing HTTP request.
   * @param {HttpHandler} next - The next interceptor in the chain.
   * @returns {Observable<HttpEvent<any>>} - An observable of the HTTP event stream.
   */
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        // Skip 401 errors - handled by OktaTokenInterceptorService for token refresh/redirect
        if (error.status === 401) {
          return throwError(() => error);
        }

        // Skip 400 errors from Okta token endpoint (expired/invalid refresh tokens)
        // These are handled by OktaTokenInterceptorService's catchError
        if (error.status === 400 && error.url && (
          error.url.includes('/token') ||
          error.url.includes('/oauth2/') ||
          error.error?.error === 'invalid_grant'
        )) {
          return throwError(() => error);
        }

        // Log only safe properties to avoid circular reference issues
        console.error('HTTP Error:', {
          status: error.status,
          statusText: error.statusText,
          url: error.url,
          message: error.message
        });

        // Handle parsing errors (200 OK with non-JSON response)
        if (error.error?.text && typeof error.error.text === 'string') {
          console.warn('Received text response instead of JSON:', error.error.text);
          // Don't show dialog for parsing errors - let component handle it
          return throwError(() => error);
        }

        // Safely extract error details
        let errorDetails = 'Unknown error';
        try {
          errorDetails = typeof error.error === 'string'
            ? error.error
            : JSON.stringify(error.error, null, 2);
        } catch (e) {
          errorDetails = error.message || 'Error details unavailable';
        }

        if (error.status === 400) {
          // Handle other 400 Bad Request errors (not auth-related)
          this.errorDialogService.show(`Bad Request (400): Please clear your browser cache and try again. If the problem persists, please contact the RARE team at <a href="mailto:dl-RARE-IT@anthem.com">dl-RARE-IT@anthem.com</a>. Error details: ${errorDetails}`);

          // Optionally propagate error or return a user-friendly error message

          //return throwError(() => new Error('Bad Request (400): Please clear your browser cache and try again'));
          return throwError(() => error);
        }
        // else {
        //   // Handle other errors
        //   this.errorDialogService.show(`Error: Please try again. If the problem persists, please contact the RARE team at <a href="mailto:dl-RARE-IT@anthem.com">dl-RARE-IT@anthem.com</a>. Error details: ${errorDetails}`);
        // }

        // Propagate the error message
        return throwError(() => error);
      })
    );
  }
}
