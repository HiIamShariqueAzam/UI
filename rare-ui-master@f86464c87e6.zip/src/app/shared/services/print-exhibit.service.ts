import { Injectable } from "@angular/core";
import { isArray } from 'util';

declare global {
  interface Navigator {
      msSaveBlob?: (blob: any, defaultName?: string) => boolean
  }
}
@Injectable({ providedIn: "root" })
export class PrintExhibitService {

  constructor() {}

  prepareUniquePrintExhibitList(exhibits): any[] {
    if(exhibits && isArray(exhibits))  {
      exhibits = exhibits.sort(function(a:any, b:any) {
        let dateA: any = new Date(a.submittedTimestamp);
        let dateB: any = new Date(b.submittedTimestamp);
        return dateB - dateA;
      });

      const result = [];
      const set = new Set();
      const peNameRegex=/(\d{4}-\d{2}-\d{2}T)(?!.*\1)/;
      for (const exhibit of exhibits) {
        if(!set.has(exhibit.exhibitDocId + exhibit.released) || exhibit.released){
            set.add(exhibit.exhibitDocId + exhibit.released);
            let name=exhibit.fileName.substring(0,exhibit.fileName.match(peNameRegex).index-1);
            exhibit['peName']=name;
            result.push(exhibit);
        }
      }
      return result;
    }
    return exhibits;
  }



  base64ToArrayBuffer(base64: string) {
    const binaryString = window.atob(base64); // Comment this if not using base64
    const bytes = new Uint8Array(binaryString.length);
    return bytes.map((byte, i) => binaryString.charCodeAt(i));
  }

  createAndDownloadBlobFile(body, filename) {
    const blob = new Blob([body]);
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement("a");
      // Browsers that support HTML5 download attribute
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

}
