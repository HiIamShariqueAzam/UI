﻿import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  showMenu: BehaviorSubject<boolean>;
  //siteminderAuthenticationRequested: BehaviorSubject<boolean>;
  isSiteminderAuthenticated: BehaviorSubject<boolean>;
  userLoggedInUsingSiteminder: BehaviorSubject<boolean>;
  //userLoggedOut: BehaviorSubject<boolean>;
  appEnvironment: BehaviorSubject<any>;
  userID: BehaviorSubject<any>;
  userName: BehaviorSubject<any>;
  userEmail: BehaviorSubject<any>;
  userRole: BehaviorSubject<any>;
  userRoleTextToDisplay: BehaviorSubject<any>;
  userLob: BehaviorSubject<any>;
  userState: BehaviorSubject<any>;

  constructor(
    private http: HttpClient,
    private router: Router,
    private oidcSecurityService: OidcSecurityService
  ) {
    this.showMenu = new BehaviorSubject<boolean>(false);
    this.isSiteminderAuthenticated = new BehaviorSubject<boolean>(false);
    this.userLoggedInUsingSiteminder = new BehaviorSubject<boolean>(false);
    this.appEnvironment = new BehaviorSubject<any>(null);
    this.userID = new BehaviorSubject<any>(null);
    this.userName = new BehaviorSubject<any>(null);
    this.userEmail = new BehaviorSubject<any>(null);
    this.userRole = new BehaviorSubject<any>(null);
    this.userRoleTextToDisplay = new BehaviorSubject<any>(null);
    this.userLob = new BehaviorSubject<any>(null);
    this.userState = new BehaviorSubject<any>(null);
  }

  getAppEnvironment() {
    return this.appEnvironment.value;
  }

  getShowMenu() {
    return this.showMenu.value;
  }

  // isSiteminderAuthenticationRequested(){
  //     return this.siteminderAuthenticationRequested.value;
  // }

  getSiteminderAuthenticated() {
    return this.isSiteminderAuthenticated.value;
  }

  getUserRole() {
    return this.userRole.value;
  }

  getUserName() {
    return this.userName.value;
  }

  getUserEmail() {
    return this.userEmail.value;
  }

  getUserID() {
    return this.userID.value;
  }

  getUserLob() {
    return this.userLob.value;
  }

  getUserState() {
    return this.userState.value;
  }

  getUserRoleTextToDisplay() {
    return this.userRoleTextToDisplay.value;
  }

  isUserRoleAdmin(userRole) {
    if (String(userRole).indexOf('ADMIN') !== -1) {
      return true;
    }
    return false;
  }

  isUserRoleActuarial(userRole) {
    if (String(userRole).indexOf('ACTUARIAL') !== -1) {
      return true;
    }
    return false;
  }

  isUserRoleUnderwriter(userRole) {
    if (String(userRole).indexOf('UNDERWRITER') !== -1) {
      return true;
    }
    return false;
  }

  isUserRoleManagement(userRole) {
    if (String(userRole).indexOf('MANAGEMENT') !== -1) {
      return true;
    }
    return false;
  }

  isUserReadOnly(userRole) {
    if (String(userRole).indexOf('READONLY') !== -1) {
      return true;
    }
    return false;
  }

  isUserMarketSegmentSmallGroup(userRole) {
    if (String(userRole).indexOf('SGSALES') !== -1) {
      return true;
    }
    return false;
  }

  isUserMarketSegmentLargeGroup(userRole) {
    if (String(userRole).indexOf('LGSALES') !== -1) {
      return true;
    }
    return false;
  }

  isUserRenewalGroup(userRole) {
    if (String(userRole).indexOf('RENEWALGROUP') !== -1) {
      return true;
    }
    return false;
  }

  isUserRenewalBatch(userRole) {
    if (String(userRole).indexOf('RENEWALBATCH') !== -1) {
      return true;
    }
    return false;
  }

  isCensusPrivilegedUser(userGroup) {
    return String(userGroup).indexOf('RARE_CENSUS_PRIVILEGE') !== -1;
  }

  changeShowMenu(data: boolean) {
    this.showMenu.next(data);
  }

  // changeSiteminderAuthenticationRequested(data: boolean){
  //     this.siteminderAuthenticationRequested.next(data);
  // }

  changeSiteminderAuthenticated(data: boolean) {
    this.isSiteminderAuthenticated.next(data);
  }

  changeAppEnvironment(data: string) {
    this.appEnvironment.next(data);
  }

  changeUserID(data: string) {
    this.userID.next(data);
  }

  changeUserName(data: string) {
    this.userName.next(data);
  }

  changeUserEmail(data: string) {
    this.userEmail.next(data);
  }

  changeUserRole(data: string) {
    this.userRole.next(data);
  }

  changeUserRoleTextToDisplay(data: string) {
    this.userRoleTextToDisplay.next(data);
  }

  changeUserLob(data: string) {
    this.userLob.next(data);
  }

  changeUserState(data: string) {
    this.userState.next(data);
  }

  // changeUserLoggedOut(data: boolean) {
  //     this.userLoggedOut.next(data);
  // }

  setUserLoggedInUsingSiteminder(data: boolean) {
    this.userLoggedInUsingSiteminder.next(data);
  }

  getUserLoggedInUsingSiteminder() {
    return this.userLoggedInUsingSiteminder.value;
  }

  getUserRoleGroups() {
    return this.http
      .get<any>('assets/mock-jsons/login.json')
      .toPromise()
      .then((res) => res.rolegroups)
      .then((data) => {
        return data;
      });
  }

  getEnvironmentGroups() {
    return this.http
      .get<any>('assets/mock-jsons/login.json')
      .toPromise()
      .then((res) => res.environmentgroups)
      .then((data) => {
        return data;
      });
  }

  logout(isTimedOut?: boolean) {
    this.changeShowMenu(false);
    this.changeSiteminderAuthenticated(false);

    if (isTimedOut) {
      // For idle timeout, use logoffLocal() to avoid race condition with token revocation
      // This clears local tokens without calling Okta /revoke endpoint
      this.oidcSecurityService.logoffLocal();
      this.oidcSecurityService.authorize();
    } else {
      // For manual logout, revoke tokens at Okta server
      this.oidcSecurityService.logoff();
      this.router.navigate(['/login']);
    }
  }

  isUserFactorTable(userRole) {
    if (String(userRole).indexOf('RARE_FACTOR_TABLE') !== -1) {
      return true;
    }
    return false;
  }

  isUserModifyOpp(userRole) {
    if (String(userRole).indexOf('RARE_MODIFY_OPP') !== -1) {
      return true;
    }
    return false;
  }

  isUserFactorTableERE(userRole) {
    if (String(userRole).indexOf('RARE_FACTOR_TABLE_ERE') !== -1) {
      return true;
    }
    return false;
  }
  isUserFactorTableAdmin(userRole) {
    if (String(userRole).indexOf('RARE_FACTOR_TABLE_ADMIN') !== -1) {
      return true;
    }
    return false;
  }

}
