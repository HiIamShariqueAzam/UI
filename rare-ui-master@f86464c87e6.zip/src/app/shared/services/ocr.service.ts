import { Injectable } from '@angular/core';
import { createWorker } from 'tesseract.js';

@Injectable({
  providedIn: 'root'
})
export class OcrService {

  private worker: any = null;
  private isInitialized = false;

  constructor() {
    console.log('OCR Service initialized with Tesseract.js (local processing)');
  }

  /**
   * Initialize Tesseract worker (lazy loading)
   */
  private async initializeWorker(): Promise<void> {
    if (this.isInitialized && this.worker) {
      return;
    }

    this.worker = await createWorker('eng', 1, {
      logger: (m: any) => {
        if (m.status === 'recognizing text') {
          console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
        }
      }
    });
    this.isInitialized = true;
  }

  /**
   * Extract text from image using local Tesseract.js OCR
   * No external API calls - runs entirely in browser
   */
  async extractTextFromImage(imageBase64: string): Promise<string> {
    try {

      // Initialize worker if needed
      await this.initializeWorker();

      // Perform OCR
      const result = await this.worker.recognize(imageBase64);


      // Return extracted text
      const text = result.data.text.trim();

      if (!text) {
        console.warn('No text extracted from image');
        return '';
      }

      return text;

    } catch (error: any) {
      console.error('Local OCR extraction failed:', error);
      throw new Error(`OCR failed: ${error.message}`);
    }
  }

  /**
   * Cleanup worker when done
   */
  async cleanup(): Promise<void> {
    if (this.worker) {
      await this.worker.terminate();
      this.worker = null;
      this.isInitialized = false;
    }
  }

  /**
   * Check if OCR is configured
   * Tesseract.js is always available (local processing)
   */
  isOcrConfigured(): boolean {
    return true; // Always available - no API key needed
  }
}
