import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

/**
 * Service for managing and broadcasting error messages to be displayed in an error dialog.
 * This service uses an RxJS `Subject` to emit error messages, which can be subscribed to by other components.
 */
@Injectable({
  providedIn: 'root',
})
export class ErrorDialogService {
  /**
   * Subject used to emit error messages.
   * @private
   * @type {Subject<string>}
   */
  private errorMessageSubject = new Subject<string>();

  /**
   * Observable that components can subscribe to in order to receive error messages.
   * @type {Observable<string>}
   */
  errorMessage$ = this.errorMessageSubject.asObservable();

  /**
   * Emits a new error message to all subscribers.
   * @param {string} message - The error message to be displayed.
   */
  show(message: string) {
    this.errorMessageSubject.next(message);
  }
}
