import { Injectable } from '@angular/core';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { AuthenticationService } from './authentication.service';
import { CacheService } from './cache-service.service';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class ResourceConfigService {
  constructor(
    private authenticationService: AuthenticationService,
    private cacheService: CacheService,
    private commonService: CommonService,
    private commonQuoteService: CommonQuoteService
  ) {}
  setConfigResourceData(resources) {
    this.authenticationService.changeAppEnvironment(resources['RARE_APPLICATION_ENV']);
    this.commonService.setSecurityAuthMode(resources['SECURITY_AUTH_MODE']);
    this.commonService.setFactorManagerMainUrl(resources['FACTOR_DATA_MANAGER_URL']);
    this.cacheService.setFactorManagerMainUrl(resources['FACTOR_DATA_MANAGER_URL']);
    this.commonService.setProductLevelAdjustments(resources['PRODUCT_LEVEL_ADJUSTMENTS_ENABLED']);
    this.commonService.setTablesUrl(resources['TABLES_URL']);
    this.commonService.setCalculatorPremiumMedicalUrl(resources['CALCULATOR_PREMIUM_MEDICAL_URL']);
    this.commonService.setCalculatorSoldRatesUrl(resources['CALCULATOR_SOLD_RATES_URL']);
    this.commonService.setReQuoteUrl(resources['RARE_RATING_BASE_URL']);
    this.commonService.setPrintEngineUrl(resources['PRINT_ENGINE_URL']);
    this.commonService.setAnalyticsBaseUrl(resources['RARE_ANALYTICS_BASE_URL']);
    this.commonService.enableAutoSubmitFlag(resources['RARE_UI_AUTO_SUBMIT_ENABLED']);
    this.commonService.setDentalBaseUrl(resources['CALCULATOR_PREMIUM_FI_DENTAL_URL']);
    this.commonService.setVisionBaseUrl(resources['DRIVER_VISION_URL']);
    this.commonService.setToggleVision(resources['VISION_ADJUSTMENT_ENABLED']);
    this.commonService.setToggleSmallGroupIntake(resources['SMALLGROUP_INTAKE_ENABLED']);
    this.commonService.setRareUIUrl('/api/rare/v1');
    this.cacheService.setRareUIUrl('/api/rare/v1');
    this.commonService.setRareUINginxUrl(resources['RARE_UI_NGINX_URL']);
    this.commonService.setProgressBarTimeOut(resources['PROGRESSBAR_TIMEOUT']);
    this.commonService.setInsertedTimestamp(resources['RARE_INDUSTRY_FACTOR_DISPLAY_INSERTED_TIMESTAMP']);
    this.commonService.setSupportingDocLinksKeywords(resources['COM2_SUPPORTING_DOC_LINKS_KEYWORDS']);
    this.commonService.setMedicalCacheRefreshUrl(resources['RARE_CACHE_MEDICAL_URL']);
    this.commonService.setDentalCacheRefreshUrl(resources['RARE_CACHE_DENTAL_URL']);
    this.commonService.setVisionCacheRefreshUrl(resources['RARE_CACHE_VISION_URL']);
    this.commonService.setGatewayCacheRefreshUrl(resources['RARE_CACHE_GATEWAY_URL']);
    this.commonService.setPlanCustomizationURL(resources['PLAN_CUSTOMIZATION_URL']);
    this.commonService.setRenewals(JSON.parse(resources['RENEWAL_PARAMETER']));
    this.commonQuoteService.setNewReleaseFlow(JSON.parse(resources['RARE_QUOTE_NEW_RELEASE_FLOW']));
    this.commonService.setFactorMigationEnabled(JSON.parse(resources['RARE_FACTOR_MIGRATION_ENABLED']));
    this.commonService.setExperienceExtractionEnabled(JSON.parse(resources['RARE_EXPERIENCE_EXTRACTION_ENABLED']));
    this.commonService.setFiRenewalEnabled(JSON.parse(resources['RARE_FI_RENEWAL_ENABLED']));
    this.commonService.setFactorMigrationPartialExclusionSystems(resources['RARE_FACTOR_MIGRATION_PARTIAL_EXCLUSION_SYSTEMS']);
    this.commonService.setFactorMigrationRemoveExclusionSystems(resources['RARE_FACTOR_MIGRATION_REMOVE_EXCLUSION_SYSTEMS']);
    this.commonService.setFactorMigrationImportFileSize(JSON.parse(resources['RARE_FACTOR_MIGRATON_IMPORT_FILE_SIZE']));
    this.commonService.setFactorExportEnabled(JSON.parse(resources['RARE_EXPORT_ENABLED']));
    this.commonService.setFactorImportEnabled(JSON.parse(resources['RARE_IMPORT_ENABLED']));
    this.commonService.setSoldRestructureTabEnabled(JSON.parse(resources['RARE_SOLD_RESTRUCTURE_TAB_ENABLED']));
    this.commonService.setNewCreateOpportunityFlow(JSON.parse(resources['RARE_CREATE_OPPORTUNITY_NEW_FLOW']));
    this.commonService.setManagementReportFlag(JSON.parse(resources['RARE_LEGACY_MANAGEMENT_REPORT_FLOW']));
    this.commonService.setCurrentEnvironment(resources['RARE_APPLICATION_ENV']);
    this.commonService.setAutoRunBatchEnabledToggle(resources['IS_AUTORUN_BATCH_ENABLED']);
    this.commonService.setEnableSendToOppMap(resources['ENABLE_SEND_TO_OPP_MAP']);
    this.commonService.setArrowCallRestrictionMap(resources['ARROW_CALL_RESTRICTION_MAP']);
    this.commonService.setMedSGAcaRareRouteEnabled(JSON.parse(resources['ENABLE_MEDICAL_SG_ACA_RARE_ROUTE']));
    this.commonService.setCrossSellingRestrictionMap(resources['CROSS_SELLING_RESTRICTED_STATES_MAP']);
    this.commonService.setAutoRunACAQuoteActionsEnabled(JSON.parse(resources['ENABLE_AUTORUN_ACA_QUOTE_ACTIONS']));
    this.commonService.setCrossSellingEnabled(resources['RARE_CROSS_SELLING_ENABLED']);
    this.commonService.setTieringEnabled(resources['TIERING_ENABLED']);
    this.commonService.setTieringConfig(resources['TIERING_CONFIG']);
    this.commonService.setShowViewCalc(resources['SHOW_VIEW_CALC']);
    this.commonService.setIsSearchAnywhereForQuoteSearchEnabled(JSON.parse(resources['IS_SEARCH_ANYWHERE_FOR_QUOTE_SEARCH_ENABLED']));
    this.commonService.setEnabledBatchGroupDownload(resources['ENABLE_BATCH_GROUPS_DOWNLOAD']);
    this.commonService.setMewaPortfolioEnabled(resources['MEWA_PORTFOLIO_ENABLED']);
    this.commonService.setQuoteOptionStatesMap(resources['RENEWAL_BATCH_QUOTE_OPTIONS_STATES']);
    this.commonService.setRareSpecialitySendToOppEnabled(resources['RARE_SPECIALTY_SEND_TO_OPP_ENABLED']);
    this.commonService.setExpiryDateForStaticApi(resources['EXPIRY_DATE_FOR_STATIC_API']);
    this.commonService.setSpecialtyLobsEnabledForBatchSubmission(resources['SPECIALTY_LOBS_ENABLED_FOR_BATCH_SUBMISSION']);
    this.commonService.setOktaInterceptUrls(resources['OKTA_INTERCEPT_URLS']);
    this.commonService.setRareEnableBulkImport(resources['ENABLE_BULK_IMPORT']);
    this.commonService.setExhibitOverrideDental(resources['EXHIBIT_OVERRIDE_DENTAL']);
    this.commonService.setMedicareStateMarkerMap(resources['MEDICARE_STATE_MARKER_MAP']);
    this.commonService.setCreateOppMEWAEnabled(resources['CREATE_MEWA_ENABLED']);
    this.commonService.setExhibitOverrideVision(resources['EXHIBIT_OVERRIDE_VISION']);
    this.commonService.setenabledBulkAdjVisDen(resources['ENABLE_BULK_ADJ_FOR_VIS_DEN']);
    this.commonService.setenabledExhibitOverrideDental(resources['ENABLE_VISION_EXHIBIT_OVERRIDE']);
    this.commonService.setenabledExhibitOverrideVision(resources['ENABLE_DENTAL_EXHIBIT_OVERRIDE']);
    this.commonService.setDisableVisionDentalLgBatchSubmit(resources['DISABLE_VISION_DENTAL_LG_BATCH_SUBMIT']);
    this.commonService.setBulkUploadImportConfig(resources['BULK_UPLD_IMPORT_CONFIG']);
    this.commonService.setDatasourcesForBatchScreenSearchOverlay(resources['BATCH_SCREEN_SEARCH_OVERLAY_DATASOURCE']);
    this.commonService.setRenewalSoldAsIsEnabled(resources['RENEWAL_SOLD_AS_IS_ENABLED']);
    this.commonService.setMEWAOriginalQuoteEnabled(resources['ENABLE_MEWA_ORIGINAL_QUOTE']);
    this.commonService.setCustomSparkWidgetUrl(resources['SPARK_ALLOWED_IFRAME_URL']);
    this.commonService.setOppSpecialityPlanUpdateConfig(resources['OPPORTUNITY_SPECIALTY_PLAN_UPDATE_CONFIG']);
    this.commonService.setEnabledTieringVisionLGBatch(resources['ENABLE_AUTO_TIERING_VISION_LG_BATCH']);
    this.commonService.setEnabledTieringDentalLGBatch(resources['ENABLE_AUTO_TIERING_DENTAL_LG_BATCH']);
    this.commonService.setMEWAOriginalQuoteReleaseEnabled(resources['ENABLE_MEWA_ORIGINAL_QUOTE_RELEASE']);
    this.commonService.setCustomTierRatioTypeRateActionFixEnabled(resources['ENABLE_CUSTOM_TIER_RATIO_TYPE_RATE_ACTION_FIX']);
    this.commonService.setDentalBaseContractCodeFlowEnabled(resources['RARE_DENTAL_BASE_CONTRACT_CODE_FLOW_ENABLED']);
    this.commonService.setLossRationVisionViewOnBulkScreenEnabled(resources['ENABLE_VISION_LOSS_RATIO_VIEW_ON_BULK_SCREEN']);
    this.commonService.setDefaultABFcommission(resources['ABF_DEFAULT_COMMISSION']);
    this.commonService.setEnabledNBGroupExpSummary(resources['NB_GROUP_EXPERIENCE_SUMMARY_ENABLED']);
    this.commonService.setNBCurrentRatesEnabled(resources['NB_CURRENT_RATES_ENABLED']);
    this.commonService.setNewBusinessUploadEnabledConfig(resources['RARE_NEWBUSINESS_UPLOAD_ENABLED']);
    this.commonService.setBatchAltQuoteSubmitThreshold(resources['BATCH_ALT_QUOTE_SUBMIT_THRESHOLD_CONFIG']);
    this.commonService.setBatchOppQuoteSubmitThreshold(resources['BATCH_OPP_QUOTE_SUBMIT_THRESHOLD_CONFIG']);
    this.commonService.setSGSpecialtyVisionDentalEnabled(resources['SG_SPECIALTY_VISION_DENTAL_ENABLE']);

  }
}
