import { AbstractControl, ValidatorFn, ValidationErrors  } from "@angular/forms";
import  moment from "moment";

export class ValidationService {
  // function to set error messages
  static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
    let config = {
      invalidDecimalValue: "Invalid Value",
      invalidNumber: "Invalid Count",
      invalidDate: "Invalid Date",
      invalidPMPM: "Invalid Value",
      required: "Mandatory"
      };

    return config[validatorName];
  }

  static decimalValidator(control: AbstractControl) {
    if (String(control.value).match(/^(\d?(\.\d{1,10})?)?$/g)) {
      return null;
    } else {
      return { invalidDecimalValue: true };
    }
  }

  static validateDecimalNumbers(control: AbstractControl) {
    if (String(control.value).match('^-?\\d{1,9}(\\.\\d{1,6})?$')) {
      return null;
    } else {
      return { invalidDecimalValue: true };
    }
  }

  /**
   * Function to validate if asl inputNumber is decimal number and with in rage of 0 - 2.
   * Maximum allowed decimals limited to 2
   * @param inputNumber
   */
  static validateASLDecimalNumber(inputNumber) {
    return String(inputNumber).match(/^([0-1]?(\.\d{1,2}?)?|[2])$/g) ? true : false;
  }

  /**
   * Function to validate if group refund inputNumber is decimal number and with in rage of 0 - 1
   * Maximum allowed decimals limited to 3
   * @param inputNumber
   */
   static validateRefundPCTDecimalNumber(inputNumber) {
    return String(inputNumber).match(/^([0]?(\.\d{1,3}|[1])?)?$/g) ? true : false;
  }

  /**
   * Function to validate if commission input number is a positive decimal number
   * @param inputNumber
   */
  static validateCommissionDecimalNumber(inputNumber) {
    return String(inputNumber).match(/^([0-9]*?(\\.[0-9]*)?)?$/g) ? true : false;
  }

  static numberValidator(control: AbstractControl) {
    if ((!control.value && control.value != null &&
        String(control.value).length == 0) || String(control.value).match(/^[0-9]*$/)
    ) {
      return null;
    } else {
      return { invalidNumber: true };
    }
  }

  static addonPMPMValidator(control: AbstractControl) {
    if ((!control.value && control.value.length == 0) || String(control.value).match(/^([+-](?=\.?\d{1,10}))?(\d+)?(\.\d{1,10})?$/g)) {
      return null;
    } else {
      return { invalidPMPM: true };
    }
  }

  static greaterThanZeroValidator(control: AbstractControl) {
    if (control.value > 0) {
      return null;
    } else {
      return { invalidDecimalValue: true };
    }
  }

  static emptyAndGreaterThanZeroValidator(control: AbstractControl) {
    if ((!control.value && control.value.length == 0) || control.value > 0) {
      return null;
    } else {
      return { invalidDecimalValue: true };
    }
  }

  static dateVaidator(AC: AbstractControl) {
    if (AC && AC.value && moment(AC.value, "YYYY-MM-DD", true).isValid()) {
      return null;
    } else {
      return { invalidDate: true };
    }
  }

  // check only for alphabets , no special characters
  static containsCharacter(control: AbstractControl) {
    for (let index = 0; index < control.value.length; index++) {
      if ((control.value.charCodeAt(index) >= 65 && control.value.charCodeAt(index) <= 90)
        || (control.value.charCodeAt(index) >= 97 && control.value.charCodeAt(index) <= 122)) {
        return { invalidData: true };
      }
    }
    return null;
  }
  /**
   * @author koushik
   * @param numberOfDecimalPoints
   *
   * validates whole number or number with decimal values
   */
  static validateNumberWithOrWithoutDecimalPoints( numberOfDecimalPoints?: number): ValidatorFn {

    return (control: AbstractControl): ValidationErrors  | null => {

   if (control.value == null || control.value.toString() === '' || control.value === undefined) {
       return null;
    }

    if (isNaN(control.value) ) {
      return {invalidData: true};
    }

  const num = control.value.toString().split('.');
   if (numberOfDecimalPoints) {
    if(num.includes(""))
    {
      return {invalidData: true};
    }
    return  ValidationService.checkForNanAndDecimal(control , num, numberOfDecimalPoints );
   } else {
      return  (isNaN(control.value) || num.includes('')) ? {invalidData: true} : null;
   }
    }
  }

  private static checkForNan(control , eachValue) {
  for (let index = 0 ; index < control.value.length ; index++ ) {

    if (eachValue[index] && isNaN(eachValue[index])) {
      return {invalidData: true};
    }

   }

}



  private static checkForNanAndDecimal(control, num, numberOfDecimalPoints) {
    if (isNaN(control.value)) {
      return { invalidData: true };
    }
    if (numberOfDecimalPoints && (('' + control.value).indexOf('.') > -1) && num[1].length > numberOfDecimalPoints) {
      return { limitExceded: true };
    }
    return null;
  }

  static checkIsNumberAndAllowDecimalPoints(event , numberOfDecimalPoints: number) {
    const el = event.target;
    const charCode = event.charCode;
    const num = el.value.split('.');
    if (charCode !== 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false ;
    }
    if (num.length > 1 && charCode === 46) {
      return false ;
    }
    const dotPos = el.value.indexOf('.');
    if ( el.selectionStart > dotPos && dotPos > -1 && num[1].length >  (numberOfDecimalPoints > 0 ?
      (numberOfDecimalPoints - 1) : -1)) {
      return false ;
    }

    return true;
  }


  static allowNumbers(event) {
    const charCode = event.charCode;
    if ( charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false ;
    }

    return true;

  }

  static isValidUrl(url?: string) {
    const pattern = /^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/gm;
    return pattern.test(url);
  }
   /**
   * Function to validate postive and negative decimals and vlaidate is decimal number enter as .00 or 0.00
   * @param formControl
   */
  static decimalValidatorOptionalSign(control: AbstractControl) {
    if (String(control.value).match(/^-?(\d?(\.\d{1,10})?)?$/g)) {
      return null;
    } else {
      return { invalidDecimalValue: true };
    }
  }

}
