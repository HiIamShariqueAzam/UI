import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, EMPTY, BehaviorSubject, of } from 'rxjs';
import { AuthenticationService } from './authentication.service';
import { Router } from '@angular/router';
import { catchError, shareReplay } from 'rxjs/operators';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { Location } from '@angular/common';
import { DateFormatPipe } from '../pipes/date-format-pipe';
@Injectable({
  providedIn: 'root'
})
export class CacheService {
  factorManagerMainUrl: any;

  //Global objects for lobs and map of Role-Tablenames
  cache = {};
  sicCache = {};
  countyCodeCache = {};
  zipCache = {};
  mbuCache = {};
  premCache = {};
  commCache = {};
  cachePlan = {};
  cacheVisionPlan = {};
  cacheDentalPlan = {};
  cacheQuotablePlans = {};
  rareUIUrl: string = '';

  constructor(
    private http: HttpClient,
    private router: Router,
    private authenticationService: AuthenticationService,
    private dateFormatPipe: DateFormatPipe,
    private location: Location,
    @Inject(SESSION_STORAGE) private storage: WebStorageService
  ) {}
  opportunityId: any;
  quoteHeaderId: any;
  setOpportunityId(opportunityId: string) {
    this.opportunityId = opportunityId;
  }

  getopportunityId(): string {
    return this.opportunityId;
  }

  setquoteHeaderId(quoteHeaderId: string) {
    this.quoteHeaderId = quoteHeaderId;
  }

  getquoteHeaderId(): string {
    return this.quoteHeaderId;
  }

  getRareUiRequest(data) {
    let metaDta = {
      userid: this.authenticationService.getUserID(),
      username: this.authenticationService.getUserName()
    };
    let RareUiRequest = {
      metadata: null,
      data: null
    };
    RareUiRequest.metadata = metaDta;
    RareUiRequest.data = data;

    return RareUiRequest;
  }

  getPlanBenefits(planbenefitsCache: string, state, quoteEffDate, factorEffectiveDate, rtngMkrtSgmnt, mbs): Observable<any> {
    let headers = this.setRequestHeaders();

    if (this.cachePlan[planbenefitsCache]) {
      return this.cachePlan[planbenefitsCache];
    }

    this.cachePlan[planbenefitsCache] = this.http
      .get(
        this.rareUIUrl +
          '/ui/manager/plan-benefits?state=' +
          state +
          '&quoteEffDate=' +
          quoteEffDate +
          '&factorEffectiveDate=' +
          factorEffectiveDate +
          '&rtngMkrtSgmnt=' +
          rtngMkrtSgmnt +
          '&mbs=' +
          mbs,
        { headers: headers }
      )
      .pipe(
        shareReplay(1),
        catchError((err) => {
          delete this.cachePlan[planbenefitsCache];
          return EMPTY;
        })
      );

    return this.cachePlan[planbenefitsCache];
  }

  getVisionPlanBenefits(planbenefitsCache: string, state, quoteEffDate, factorEffectiveDate, rtngMkrtSgmnt): Observable<any> {
    let headers = this.setRequestHeaders();

    if (this.cacheVisionPlan[planbenefitsCache]) {
      return this.cacheVisionPlan[planbenefitsCache];
    }
    
    this.cacheVisionPlan[planbenefitsCache] = this.http
      .get(
        this.rareUIUrl +
          '/ui/manager/vision-plan-benefits?state=' +
          state +
          '&quoteEffDate=' +
          quoteEffDate +
          '&factorEffectiveDate=' +
          factorEffectiveDate +
          '&rtngMkrtSgmnt=' +
          rtngMkrtSgmnt,
        { headers: headers }
      )
      .pipe(
        shareReplay(1),
        catchError((err) => {
          delete this.cacheVisionPlan[planbenefitsCache];
          return EMPTY;
        })
      );

    return this.cacheVisionPlan[planbenefitsCache];
  }

  getDentalPlanBenefits(planbenefitsCache: string, state, quoteEffDate, factorEffectiveDate): Observable<any> {
    let headers = this.setRequestHeaders();

    if (this.cacheDentalPlan[planbenefitsCache]) {
      return this.cacheDentalPlan[planbenefitsCache];
    }
    
    this.cacheDentalPlan[planbenefitsCache] = this.http
      .get(
        this.rareUIUrl +
          '/ui/manager/dental-plan-benefits?state=' +
          state +
          '&quoteEffDate=' +
          quoteEffDate +
          '&factorEffectiveDate=' +
          factorEffectiveDate ,
        { headers: headers }
      )
      .pipe(
        shareReplay(1),
        catchError((err) => {
          delete this.cacheDentalPlan[planbenefitsCache];
          return EMPTY;
        })
      );

    return this.cacheDentalPlan[planbenefitsCache];
  }

  getQuotablePlans(requestPayload: any): Observable<any> {
    let headers = this.setRequestHeaders()
      .set('Content-Type', 'application/json')
      .set('emailid', this.authenticationService.getUserEmail() ?? '')
      .set('role', this.authenticationService.getUserRole() ?? '');
    const cacheKey = JSON.stringify(requestPayload);

    if (this.cacheQuotablePlans[cacheKey]) {
      return this.cacheQuotablePlans[cacheKey];
    }

    const request = {
      metadata: {
        username: this.authenticationService.getUserName() ?? '',
        userid: this.authenticationService.getUserID() ?? ''
      },
      data: requestPayload
    };

    this.cacheQuotablePlans[cacheKey] = this.http.post(`${this.rareUIUrl}/quotablePlans`, request, {
      headers: headers
    }).pipe(
      shareReplay(1),
      catchError((err) => {
        delete this.cacheQuotablePlans[cacheKey];
        return EMPTY;
      })
    );

    return this.cacheQuotablePlans[cacheKey];
  }

  getStates(stateCache: string): Observable<any> {
    let headers = this.setRequestHeaders();

    if (this.cache[stateCache]) {
      return this.cache[stateCache];
    }

    this.cache[stateCache] = this.http.get(this.rareUIUrl + '/ui/manager/state-codes', { headers: headers }).pipe(
      shareReplay(1),
      catchError((err) => {
        delete this.cache[stateCache];
        return EMPTY;
      })
    );
    return this.cache[stateCache];
  }

  getSICCodeList(sicCacheString: any) {
    let headers = this.setRequestHeaders();
    if (this.sicCache[sicCacheString]) {
      return this.sicCache[sicCacheString];
    }
    this.sicCache[sicCacheString] = this.http.get(this.rareUIUrl + '/ui/manager/sic-codes', { headers: headers }).pipe(
      shareReplay(1),
      catchError((err) => {
        delete this.sicCache[sicCacheString];

        alert('Error in getting response from SicCodes API....' + err);
        return EMPTY;
      })
    );
    return this.sicCache[sicCacheString];
  }

  getCountyCodeDetails(zipCode: any) {
    let headers = this.setRequestHeaders();
    if (this.countyCodeCache[zipCode]) {
      return this.countyCodeCache[zipCode];
    }
    this.countyCodeCache[zipCode] = this.http.get(this.rareUIUrl + '/ui/manager/county-codes?zipCode=' +zipCode, { headers: headers }).pipe(
      shareReplay(1),
      catchError((err) => {
        delete this.countyCodeCache[zipCode];

        alert('Error in getting response from CountyCode API....' + err);
        return EMPTY;
      })
    );
    return this.countyCodeCache[zipCode];
  }

  getZipCodeList(zipCacheString: any) {
    let headers = this.setRequestHeaders();
    if (this.zipCache[zipCacheString]) {
      return this.zipCache[zipCacheString];
    }
    this.zipCache[zipCacheString] = this.http.get(this.rareUIUrl + '/ui/manager/zip-codes', { headers: headers }).pipe(
      shareReplay(1),
      catchError((err) => {
        delete this.zipCache[zipCacheString];
        return EMPTY;
      })
    );
    return this.zipCache[zipCacheString];
  }

  getMBUCodesList(mbuCodeString, state, mrktSgmnt, quoteEffDate, factorEffectiveDate) {
    let headers = this.setRequestHeaders();
    if (this.mbuCache[mbuCodeString]) {
      return this.mbuCache[mbuCodeString];
    }
    this.mbuCache[mbuCodeString] = this.http
      .get(
        this.rareUIUrl +
          '/ui/manager/mbu-codes?state=' +
          state +
          '&mrktSgmnt=' +
          mrktSgmnt +
          '&quoteEffDate=' +
          quoteEffDate +
          '&factorEffectiveDate=' +
          factorEffectiveDate,
        { headers: headers }
      )
      .pipe(
        shareReplay(1),
        catchError((err) => {
          delete this.mbuCache[mbuCodeString];
          return EMPTY;
        })
      );
    return this.mbuCache[mbuCodeString];
  }

  getPremDelayDays(premCacheString, state, rtngMkrtSgmnt, quoteEffDate, factorEffectiveDate, fundingType) {
    let headers = this.setRequestHeaders();
    if (this.premCache[premCacheString]) {
      return this.premCache[premCacheString];
    }
    this.premCache[premCacheString] = this.http
      .get(this.rareUIUrl + '/ui/manager/prem-delay-days', {
        params: {
          state: state,
          rtngMkrtSgmnt: rtngMkrtSgmnt,
          quoteEffDate: quoteEffDate,
          factorEffectiveDate: factorEffectiveDate,
          fundingType: fundingType
        },
        headers: headers
      })
      .pipe(
        shareReplay(1),
        catchError((err) => {
          delete this.premCache[premCacheString];
          return EMPTY;
        })
      );
    return this.premCache[premCacheString];
  }

  setCommCache(res, cache) {
    this.commCache[cache] = res;
  }

  getCommissionInfoNoOppType(commCacheString, state, rtngMkrtSgmnt, fundingType, quoteEffDate, factorEffectiveDate) {
    let headers = this.setRequestHeaders();

    if (this.commCache[commCacheString]) {
      return this.commCache[commCacheString];
    }
    this.commCache[commCacheString] = this.http
      .get(
        this.rareUIUrl +
          '/ui/manager/defaultvales?state=' +
          state +
          '&rtngMkrtSgmnt=' +
          rtngMkrtSgmnt +
          '&fundingType=' +
          fundingType +
          '&quoteEffDate=' +
          quoteEffDate +
          '&factorEffectiveDate=' +
          factorEffectiveDate,

        { headers: headers }
      )
      .pipe(
        shareReplay(1),
        catchError((err) => {
          delete this.commCache[commCacheString];
          return EMPTY;
        })
      );
    return this.commCache[commCacheString];
  }

  getCommissionInfo(commCacheString, state, rtngMkrtSgmnt, fundingType, quoteEffDate, factorEffectiveDate, opportunityType, isAlternate) {
    let headers = this.setRequestHeaders();

    if (this.commCache[commCacheString]) {
      return this.commCache[commCacheString];
    }
    this.commCache[commCacheString] = this.http
      .get(
        this.rareUIUrl +
          '/ui/manager/defaultvales?state=' +
          state +
          '&rtngMkrtSgmnt=' +
          rtngMkrtSgmnt +
          '&fundingType=' +
          fundingType +
          '&quoteEffDate=' +
          quoteEffDate +
          '&factorEffectiveDate=' +
          factorEffectiveDate +
          '&opportunityType=' +
          opportunityType +
          '&isAlternate=' +
          isAlternate,
        { headers: headers }
      )
      .pipe(
        shareReplay(1),
        catchError((err) => {
          delete this.commCache[commCacheString];
          return EMPTY;
        })
      );
    return this.commCache[commCacheString];
  }

  saveOpportunityGroupInfo(groupData: any) {
    let rareUiRequest = this.getRareUiRequest(groupData);
    let headers = this.setRequestHeaders();
    return this.http.post<any>(this.rareUIUrl + '/saveOpportunity', rareUiRequest, { headers: headers });
  }

  saveUpdateQuoteDetails(quoteData: any, oppID: any, qHeaderID: any) {
    let headers = this.setRequestHeaders();
    let groupData = {
      opportunityID: oppID,
      quoteHeaderID: qHeaderID,
      quoteData: quoteData
    };
    let rareUiRequest = this.getRareUiRequest(groupData);
    return this.http.post<any>(this.rareUIUrl + '/saveOrUpdateQuoteDetails', rareUiRequest, { headers: headers });
  }

  submitQuoteDetails(quoteData: any, oppID: any, qHeaderID: any) {
    let request = {
      opportunityID: oppID,
      quoteHeaderID: qHeaderID,
      quoteData: quoteData
    };
    let rareUiRequest = this.getRareUiRequest(request);
    let headers = this.setRequestHeaders();
    return this.http.post<any>(this.rareUIUrl + '/submitQuote', rareUiRequest, { headers: headers });
  }

  setRequestHeaders() {
    let headers = this.setHeaders();
    if (this.opportunityId && this.quoteHeaderId) {
      headers = this.setHeaders().set('opportunityID', this.getopportunityId()).set('quoteHeaderID', this.getquoteHeaderId());
    }
    return headers;
  }

  setHeaders() {
    return new HttpHeaders()
      .set('meta-transid', 'abc')
      .set('userid', this.authenticationService.getUserID() ?? '')
      .set('username', this.authenticationService.getUserName() ?? '');
  }

  setFactorManagerMainUrl(url) {
    this.factorManagerMainUrl = url;
  }

  setRareUIUrl(url) {
    this.rareUIUrl = url;
  }
}
