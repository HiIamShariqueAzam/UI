import { Injectable, ElementRef } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DateUtil } from '../utils/date-util';
import { CommonUtil } from '../utils/common-util';
import { CommonConstants } from '../constants/common.constants';
import { StringUtils } from '../utils/string-utils';

@Injectable({
  providedIn: 'root'
})
export class OffCycleModalService {
  
  offCycleEndDate: Date;
  offCycleStatusReason: string;
  offCycleOtherReason: string;
  offCycleSubmittedInCurrentSession: boolean = false;
  offCycleStatusReasonOptions: any[] = CommonConstants.OFF_CYCLE_STATUS_REASON_OPTIONS;
  isDatePickerDisabled: boolean = false;
  isFutureContractDate: boolean = false;

  constructor(private datepipe: DatePipe) {}

  /**
   * Check if the LOB is a specialty LOB (Vision, Dental, or Supp Health)
   * @param lobName - LOB name to check
   * @returns true if specialty LOB, false otherwise
   */
  private isSpecialtyLob(lobName: string): boolean {
    return [CommonConstants.Vision, CommonConstants.Dental, CommonConstants.SuppHealth].includes(lobName);
  }

  /**
   * Initialize and open the off-cycle modal
   * @param rateData - The rate data object containing off-cycle information
   * @param modalRefs - Object containing modal element references {content, header, footer}
   * @param lobName - LOB name (Medical, Vision, Dental, Supp Health) - optional, defaults to empty
   */
  onOffCycleOpen(rateData: any, modalRefs: { content: ElementRef, header: ElementRef, footer: ElementRef }, lobName: string = ''): void {
    // Check if contract start date is in future (for Vision, Dental, Supp Health only)
    const isSpecialtyLob = this.isSpecialtyLob(lobName);
    const contractEffectiveDate = rateData?.contractEffectiveDate;
    this.isFutureContractDate = isSpecialtyLob && contractEffectiveDate && DateUtil.isDateInFuture(contractEffectiveDate);

    if (rateData?.offCycle?.contractEndDate) {
      this.offCycleEndDate = new Date(rateData.offCycle.contractEndDate);

      const predefinedReasons = this.offCycleStatusReasonOptions.map(opt => opt.value);
      const savedReason = rateData.offCycle.statusReason;
      
      if (predefinedReasons.includes(savedReason)) {
        this.offCycleStatusReason = savedReason;
        this.offCycleOtherReason = null;
      } else {
        this.offCycleStatusReason = 'Other';
        this.offCycleOtherReason = savedReason;
      }
      // Date picker is disabled if contract is in future
      this.isDatePickerDisabled = this.isFutureContractDate;
    } else {
      // Calculate default off-cycle end date based on contract effective date
      if (this.isFutureContractDate) {
        const endDateStr = DateUtil.calculateOffCycleEndDate(contractEffectiveDate);
        this.offCycleEndDate = DateUtil.parseDate(endDateStr) || DateUtil.getLastDayOfCurrentMonth();
        this.isDatePickerDisabled = true;
      } else {
        this.setDefaultOffCycleDate();
        this.isDatePickerDisabled = false;
      }
      this.offCycleStatusReason = null;
      this.offCycleOtherReason = null;
    }

    setTimeout(() => {
      if (modalRefs.content && modalRefs.header && modalRefs.footer) {
        const content = modalRefs.content.nativeElement;
        const header = modalRefs.header.nativeElement;
        const footer = modalRefs.footer.nativeElement;
        CommonUtil.modalPopup(content, [header, footer]);
      }
    }, 100);
  }

  /**
   * Handle status reason dropdown change
   * Clears "Other" reason field when a predefined reason is selected
   */
  onOffCycleReasonChange(): void {
    if (this.offCycleStatusReason !== 'Other') {
      this.offCycleOtherReason = null;
    }
  }

  /**
   * Set default off-cycle end date to last day of current month
   */
  setDefaultOffCycleDate(): void {
    this.offCycleEndDate = DateUtil.getLastDayOfCurrentMonth();
  }

  /**
   * Programmatically trigger the datepicker
   */
  clickOffCycleDate(): void {
    if (!this.offCycleEndDate) {
      this.setDefaultOffCycleDate();
    }
    setTimeout(() => {
      let inputElement = document.querySelector('#offCycleModal .calendar .p-inputtext') as HTMLElement;
      if (!inputElement) {
        inputElement = document.querySelector('#offCycleModal .requote-modal-calendar .p-inputtext') as HTMLElement;
      }
      if (!inputElement) {
        inputElement = document.querySelector('#offCycleModal .p-datepicker .p-inputtext') as HTMLElement;
      }
      if (!inputElement) {
        inputElement = document.querySelector('#offCycleModal input[data-test="offCycleEndDate"]') as HTMLElement;
      }
      
      if (inputElement) {
        inputElement.focus();
        inputElement.click();
      }
    }, 100);
  }

  /**
   * Validate and confirm off-cycle data
   * @param rateData - The rate data object to update
   * @param lobName - Name of the LOB (Medical, Dental, Vision)
   * @returns true if validation passes, false otherwise
   */
  onOffCycleConfirm(rateData: any, lobName: string): boolean {
    if (!this.offCycleEndDate || !this.offCycleStatusReason ||
        (this.offCycleStatusReason === 'Other' && !this.offCycleOtherReason)) {
      return false;
    }

    if (!rateData.offCycle) {
      rateData.offCycle = {};
    }
    
    rateData.offCycle.contractEndDate = this.datepipe.transform(this.offCycleEndDate, 'yyyy-MM-dd');
    rateData.offCycle.statusReason = this.offCycleStatusReason === 'Other' ? this.offCycleOtherReason : this.offCycleStatusReason;
    rateData.offCycle.lobs = [rateData.lob || lobName];
    rateData.offCycle.terminationFlag = true;
    
    // Update status to 'Termed' for future-dated contracts in specialty LOBs
    if (this.isFutureContractDate && this.isSpecialtyLob(lobName)) {
      rateData.status = CommonConstants.termedStatus;
    }
    
    this.offCycleSubmittedInCurrentSession = true;
    
    return true;
  }

  /**
   * Check if contract has started (effective date is in the past)
   * @param contractEffectiveDate - Contract effective date
   */
  isContractStarted(contractEffectiveDate: string): boolean {
    return DateUtil.isDateInPast(contractEffectiveDate);
  }

  /**
   * Check if status is "Sold"
   * @param status - Current quote status
   */
  isSold(status: string): boolean {
    const statusStr = status?.toString() || '';
    return StringUtils.isEqual(statusStr, 'Sold');
  }

  /**
   * Determine if off-cycle button should be shown
   * @param contractEffectiveDate - Contract effective date
   * @param status - Current quote status
   * @param lobName - LOB name (Medical, Vision, Dental, Supp Health) - optional
   * @param opportunityType - Opportunity type (New Business, Renewal, etc.) - optional
   */
  shouldShowOffCycleButton(contractEffectiveDate: string, status: string, lobName: string = '', opportunityType: string = ''): boolean {
    const isSpecialtyLob = this.isSpecialtyLob(lobName);
    
    // For specialty LOBs: show button if contract is in future (any status) OR if contract started and status is Sold
    if (isSpecialtyLob) {
      const isFutureContract = Boolean(contractEffectiveDate && DateUtil.isDateInFuture(contractEffectiveDate));
      const isNewBusiness = StringUtils.isEqual(opportunityType, CommonConstants.NEW_BUSINESS_LOCAL);
      
      // Hide button for New Business with future effective date ONLY if status is NOT Sold
      if (isNewBusiness && isFutureContract && !this.isSold(status)) {
        return false;
      }
      
      return isFutureContract || (this.isContractStarted(contractEffectiveDate) && this.isSold(status));
    }
    
    // For Medical: existing logic (contract started AND status is Sold)
    return this.isContractStarted(contractEffectiveDate) && this.isSold(status);
  }

  /**
   * Reset the service state
   */
  reset(): void {
    this.offCycleEndDate = null;
    this.offCycleStatusReason = null;
    this.offCycleOtherReason = null;
    this.offCycleSubmittedInCurrentSession = false;
    this.isDatePickerDisabled = false;
    this.isFutureContractDate = false;
  }
}
