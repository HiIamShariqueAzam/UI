import { Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { CommonConstants } from '../constants/common.constants';
import { LobDetails } from '../models';
import { StringUtils } from '../utils/string-utils';
import { AuthenticationService } from './authentication.service';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private router: Router
  ) {}

  setUserGlobalData(assignedUserGroups: any, isSimulation?: boolean) {
    const currentEnvironment = this.authenticationService.getAppEnvironment();
    if (!isSimulation && !StringUtils.isEqualIgnoreCase(currentEnvironment, 'PROD') && !StringUtils.isEqualIgnoreCase(currentEnvironment, 'LOCAL')) {

      for (const [index, group] of assignedUserGroups.entries()) {
        // Skip groups matching the current environment
        if (StringUtils.isEqualIgnoreCase(group, 'RARE_DEV') || StringUtils.isEqualIgnoreCase(group, `RARE_${currentEnvironment}`) ) {
          continue;
        }
        if (typeof group === 'string' && typeof currentEnvironment === 'string') {
          if (currentEnvironment.indexOf('DEV') !== -1) {
            assignedUserGroups[index] = group.replace(new RegExp(`[_-]?DEV$`), '');
            continue;
          }
          // Replace the group value safely
          assignedUserGroups[index] = group.replace(new RegExp(`[_-]?${currentEnvironment}$`), '');
        } else {
          console.error('Invalid input: group or currentEnvironment must be a string');
        }
      }
    }
    this.commonService.setAssignedUserGroup(assignedUserGroups);
    let fullTablesList: any[] = [];
    let allAvailableLobList: any[] = [];
    let userAssignedLobList: any[] = [];
    let allAvailableStateList: any[] = CommonConstants.allAvailableStateList;
    let userAssignedStateList: any[] = [];
    let map = new Map<string, string[]>();
    this.authenticationService.getUserRoleGroups().then((data) => {
      var assignedUserRoles = '';
      var assignedUserRolesTextToDisplay = '';
      var assignedUserLobs = '';
      var assignedUserStates = '';
      for (let rolegroups of data) {
        if (String(assignedUserGroups).indexOf(rolegroups['usergroup']) !== -1) {
          assignedUserRoles = assignedUserRoles.length == 0 ? rolegroups['role'] : assignedUserRoles + ',' + rolegroups['role'];
          assignedUserRolesTextToDisplay =
            assignedUserRolesTextToDisplay.length == 0 ? rolegroups['roletext'] : assignedUserRolesTextToDisplay + ' / ' + rolegroups['roletext'];
          assignedUserLobs = assignedUserLobs.length == 0 ? rolegroups['lob'] : assignedUserLobs + ',' + rolegroups['lob'];
          assignedUserStates = assignedUserStates.length == 0 ? rolegroups['state'] : assignedUserStates + ',' + rolegroups['state'];
        }
      }
      if (assignedUserRoles === 'READONLY') {
        alert(
          'You cannot login with RARE_APP_READ_ONLY role only. Please get access to another role along with RARE_APP_READ_ONLY role to login. Please contact RARE team <dl-RARE-IT@anthem.com> for access related questions...!'
        );
        this.router.navigate(['/unauthorized']);
      } else if (assignedUserRoles === 'RARE_MODIFY_OPP') {
        alert(
          'You cannot login with RARE_MODIFY_OPP role only. Please get access to another role along with RARE_MODIFY_OPP role to login. Please contact RARE team <dl-RARE-IT@anthem.com> for access related questions...!'
        );
        this.router.navigate(['/unauthorized']);
      }
      this.commonService.setUserRoles(assignedUserRoles.split(','));
      this.authenticationService.changeUserRole(assignedUserRoles);
      this.authenticationService.changeUserRoleTextToDisplay(assignedUserRolesTextToDisplay);
      this.authenticationService.changeUserLob(assignedUserLobs);
      this.authenticationService.changeUserState(assignedUserStates);
      this.commonService.getQuotedLegalEntityList();
      this.commonService.getTables('ALL').subscribe(
        (response) => {
          Object.keys(response).forEach((key) => {
            if (key === 'lobDesc') {
              for (var i = 0; i < response[key].length; i++) {
                let lobName = response[key][i].lobName;
                /*Filling the Dropdown*/
                var lobItem: LobDetails = {
                  label: response[key][i].lobDesc,
                  value: lobName
                };
                allAvailableLobList.push(lobItem);

                if (String(this.authenticationService.getUserLob()).indexOf(lobName) !== -1) {
                  userAssignedLobList.push(lobItem);
                }
              }
            } else {
              /*Filling the dropdown for lobs */
              map.set(key, response[key]);

              let tableArrayForSingleLob: [] = response[key];
              for (let table in tableArrayForSingleLob) {
                fullTablesList.push(tableArrayForSingleLob[table]);
              }
            }
          });
          if (String(this.authenticationService.getUserLob()).indexOf('ALL') !== -1) {
            this.commonService.setLobList(allAvailableLobList);
          } else {
            this.commonService.setLobList(userAssignedLobList);
          }
          if (String(this.authenticationService.getUserState()).indexOf('ALL') !== -1) {
            this.commonService.setStateList(allAvailableStateList);
          } else {
            Object.keys(allAvailableStateList).forEach((key) => {
              if (String(this.authenticationService.getUserState()).indexOf(allAvailableStateList[key].label) !== -1) {
                userAssignedStateList.push(allAvailableStateList[key]);
              }
            });
            this.commonService.setStateList(userAssignedStateList);
          }
          this.commonService.setMapOfRoleAndTableNames(map);
          this.commonService.setFullTablesList(fullTablesList);
          this.authenticationService.changeShowMenu(true);
          if (localStorage.getItem('isLoginAgain')) {
            this.storage.set('quoteHeaderID', localStorage.getItem('quoteHeaderID'));
            this.storage.set('opportunityID', localStorage.getItem('opportunityID'));
            this.storage.set('ratingTransID', localStorage.getItem('ratingTransID'));
            this.storage.set('lob', localStorage.getItem('lob'));
            this.storage.set('quoteOrigin', localStorage.getItem('quoteOrigin'));
            this.storage.set('fundingType', localStorage.getItem('fundingType'));
            this.storage.set('marketSegment', localStorage.getItem('marketSegment'));
            this.storage.set('insertedTimestamp', localStorage.getItem('insertedTimestamp'));
            this.storage.set('availableTabs', localStorage.getItem('availableTabs'));
            this.storage.set('isLoginAgain', 'true');
            this.storage.set('disableAll', localStorage.getItem('disableAll'));
            this.storage.set('isEnableQuoteHistory', localStorage.getItem(CommonConstants.IS_ENABLE_QUOTE_HISTORY));
            this.storage.set('quoteHistoryId', localStorage.getItem('quoteHistoryId'));
            this.storage.set('version', localStorage.getItem('version'));
            this.storage.set('assignedUserRoles', localStorage.getItem('assignedUserRoles'));
            this.storage.set('assignedUserRolesTextToDisplay', localStorage.getItem('assignedUserRolesTextToDisplay'));
            this.storage.set('assignedUserLobs', localStorage.getItem('assignedUserLobs'));
            this.storage.set('assignedUserStates', localStorage.getItem('assignedUserStates'));
            this.storage.set('sendToOpp', localStorage.getItem('sendToOpp'));
            this.commonService.removeHistoryLocalStorage();
          }
          if (this.storage.get('isLoginAgain')) {
            let path = '';
            this.authenticationService.changeUserRole(this.storage.get('assignedUserRoles'));
            this.authenticationService.changeUserRoleTextToDisplay(this.storage.get('assignedUserRolesTextToDisplay'));
            this.authenticationService.changeUserLob(this.storage.get('assignedUserLobs'));
            this.authenticationService.changeUserState(this.storage.get('assignedUserStates'));
            
            if (['Medical', 'Vision', 'Dental', 'Supp Health'].includes(this.storage.get('lob'))
            && this.storage.get('quoteHistoryId')) {
              path = '/opportunity/create-opportunity-new';
              this.router.navigate([path], {
                queryParams: {
                  opportunityID: this.storage.get('opportunityID'),
                  quoteId: this.storage.get('quoteHeaderID'),
                  version: this.storage.get('version'),
                  quoteHistoryId: this.storage.get('quoteHistoryId'),
                  fundingType: this.storage.get('fundingType'),
                  marketSegment: this.storage.get('marketSegment'),
                  quoteOrigin: this.storage.get('quoteOrigin'),
                  lob: this.storage.get('lob')
                }
              });
            } else if (this.storage.get('lob') === 'Medical') {
              path = '/quote/uw-rate';
              this.router.navigate([path], {
                queryParams: {
                  quoteHeaderID: this.storage.get('quoteHeaderID'),
                  opportunityID: this.storage.get('opportunityID'),
                  ratingTransID: this.storage.get('ratingTransID'),
                  lob: this.storage.get('lob'),
                  fundingType: this.storage.get('fundingType'),
                  insertedTimestamp: this.storage.get('insertedTimestamp'),
                  disableAll: this.storage.get('disableAll'),
                  quoteOrigin: this.storage.get('quoteOrigin'),
                  isEnableQuoteHistory: this.storage.get(CommonConstants.IS_ENABLE_QUOTE_HISTORY),
                  availableTabs: this.storage.get('availableTabs').split(','),
                  marketSegment: this.storage.get('marketSegment')
                }
              });
            } else if (this.storage.get('lob') === 'Vision') {
              path = '/quote/uw-rate-vision';
              this.router.navigate([path], {
                queryParams: {
                  quoteHeaderID: this.storage.get('quoteHeaderID'),
                  opportunityID: this.storage.get('opportunityID'),
                  ratingTransID: this.storage.get('ratingTransID'),
                  lob: this.storage.get('lob'),
                  fundingType: this.storage.get('fundingType'),
                  insertedTimestamp: this.storage.get('insertedTimestamp'),
                  disableAll: this.storage.get('disableAll'),
                  availableTabs: this.storage.get('availableTabs').split(','),
                  quoteOrigin: this.storage.get('quoteOrigin'),
                  marketSegment: this.storage.get('marketSegment')
                }
              });
            } else if (this.storage.get('lob') === 'Dental') {
              path = 'quote/uw-rate-dental';
              this.router.navigate([path], {
                queryParams: {
                  quoteHeaderID: this.storage.get('quoteHeaderID'),
                  opportunityID: this.storage.get('opportunityID'),
                  ratingTransID: this.storage.get('ratingTransID'),
                  lob: this.storage.get('lob'),
                  fundingType: this.storage.get('fundingType'),
                  insertedTimestamp: this.storage.get('insertedTimestamp'),
                  disableAll: this.storage.get('disableAll'),
                  availableTabs: this.storage.get('availableTabs').split(','),
                  quoteOrigin: this.storage.get('quoteOrigin'),
                  marketSegment: this.storage.get('marketSegment')
                }
              });
            } else if (StringUtils.isEqualIgnoreCase(this.storage.get('lob'), CommonConstants.SuppHealth)) {
              path = 'quote/uw-rate-supplemental-health';
              this.router.navigate([path], {
                queryParams: {
                  quoteHeaderID: this.storage.get('quoteHeaderID'),
                  opportunityID: this.storage.get('opportunityID'),
                  ratingTransID: this.storage.get('ratingTransID'),
                  lob: this.storage.get('lob'),
                  fundingType: this.storage.get('fundingType'),
                  insertedTimestamp: this.storage.get('insertedTimestamp'),
                  disableAll: this.storage.get('disableAll'),
                  availableTabs: this.storage.get('availableTabs')?.split(','),
                  quoteOrigin: this.storage.get('quoteOrigin'),
                  marketSegment: this.storage.get('marketSegment')
                }
              });
            } else if (this.storage.get('sendToOpp')) {
              path = '/opportunity/create-opportunity-new';
              this.router.navigate([path], {
                queryParams: {
                  opportunityID: this.storage.get('opportunityID')
                }
              });
              this.storage.remove('sendToOpp');
              this.storage.remove('isLoginAgain');
            }
          } else {
            if (this.authenticationService.isUserRoleAdmin(assignedUserRoles)) {
              this.router.navigate(['/' + CommonConstants.adminMenu[0].value]);
            } else if (this.authenticationService.isUserRoleUnderwriter(assignedUserRoles)) {
              this.router.navigate(['/' + CommonConstants.underwriterMenu[0].value]);
              this.storage.remove('showOpportunities');
              this.storage.remove('QuoteSearchQuery');
              this.storage.remove('totalPages');
              this.storage.remove('first');
              this.storage.remove('pageIndex');
              this.storage.remove('accountName');
              this.storage.remove('groupNbr');
              this.storage.remove('status');
              this.storage.remove('state');
              this.storage.remove('lob');
              this.storage.remove('fundingType');
              this.storage.remove('underwriterName');
              this.storage.remove('opportunityID');
              this.storage.remove('quoteHeaderID');
              this.storage.remove('quoteOrigin');
              this.storage.remove('fromdate');
              this.storage.remove('todate');
              this.storage.remove('sendToOpp');
            } else if (this.authenticationService.isUserRoleActuarial(assignedUserRoles)) {
              if (
                this.commonService.factorMigrationEnabled &&
                StringUtils.checkArrayObjectExitsInArr(this.commonService.getAssignedUserGroup(), CommonConstants.RARE_DMT_ACCESS_FOR_ACTUARIAL)
              ) {
                this.router.navigate(['/' + CommonConstants.factorTableMenu[0].subValue]);
              } else if (this.commonService.factorImportEnabled) {
                this.router.navigate(['/' + CommonConstants.actuarialMenu[0].subValue]);
              } else if (this.commonService.factorExportEnabled) {
                this.router.navigate(['/' + CommonConstants.actuarialMenu[0].subValue]);
              }
            } else if (this.authenticationService.isUserRoleManagement(assignedUserRoles)) {
              this.router.navigate(['/generate-report']);
            } else if (
              this.authenticationService.isUserMarketSegmentLargeGroup(assignedUserRoles) ||
              this.authenticationService.isUserMarketSegmentSmallGroup(assignedUserRoles)
            ) {
              this.router.navigate(['/' + CommonConstants.salesMenu[0].value]);
            } else if (this.authenticationService.isUserRenewalGroup(assignedUserRoles)) {
              this.router.navigate(['/' + CommonConstants.renewalGroupMenu[0].subValue]);
            } else if (this.authenticationService.isUserRenewalBatch(assignedUserRoles)) {
              this.router.navigate(['/' + CommonConstants.renewalBatchMenu[0].subValue]);
            } else if (this.authenticationService.isUserFactorTable(assignedUserRoles)) {
              this.router.navigate(['/' + CommonConstants.factorTableMenu[0].subValue]);
            }
          }
        },
        (err) => {
          alert('Error in getting response from getTables API....' + err);
        }
      );
    });
  }
}
