import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { StringUtils } from '../utils/string-utils';
import { ValidationService } from './validation.service';
import { OpportunityType } from 'src/app/opportunity/create-opportunity-new/constants/create-opportunity.constants';
import { CommonService } from './common.service';

@Injectable({ providedIn: 'root' })
export class ProcessQuoteDetailsService {
  guardrailBoundaries: any;
  quotelevelFailData: any;
  noData: string = 'Not Available';
  declineOptionsValues: BehaviorSubject<any>;
  declineOptionsFromBackend: any[];
  uwNotesToSales: any;
  declineOptionsChecked: any[];
  userTypedDeclineReasons: any;

  constructor(public datepipe: DatePipe,
    private commonService: CommonService
  ) {
    this.declineOptionsValues = new BehaviorSubject<any>(null);
    this.declineOptionsFromBackend = [];
    this.declineOptionsChecked = [];
  }

  process(
    data: any,
    lob: string,
    fundingType: string,
    erFundingLevelData: any,
    processWithArrow: any,
    quotelevelFailData?: any,
    guardrailBoundaries?: any
  ): any[] {
    if (lob == 'medical') {
      this.quotelevelFailData = quotelevelFailData;
      this.guardrailBoundaries = guardrailBoundaries || this.fetchBoundaries(data.factors && data.factors.guardRails);
      return this.medicalProcessed(data, fundingType, erFundingLevelData, processWithArrow);
    }
    return [];
  }

  medicalProcessed(data: any, fundingType: string, erFundingLevelData: any, processWithArrow): any[] {
    if (data.opportunityType && data.quotingType === 'ACA') {
      return this.medicalQuotingTypeACA(data, fundingType);
    } else if (data.opportunityType && data.quotingType === 'MEWA') {
      return this.medicalQuotingTypeMEWA(data, fundingType);
    }
    let elements = [];
    elements.push(this.populateQuoteHeaderID(data));
    elements.push(this.populateFundingType(fundingType, data, 'medical'));
    elements.push(this.populateState(data));
    // Rearrange the fields for opp type renewal
    if (data.opportunityType && data.opportunityType === 'Renewal Local') {
      elements.push(this.popuplateGroupNumber(data));
      elements.push(this.populateSalesContact(data, 'Medical'));
      elements.push(this.populateBrokerName(data, 'Medical'));

      elements.push(this.populateAgeSexFactor(data));
      elements.push(this.populateSIC(data));
      elements.push(this.populateSICFactor(data));
      // if (data.fundingType !== 'ABF') {
      //   elements.push(this.populateRiskScore(data));
      // }
    } else {
      elements.push(this.populateSIC(data));
      elements.push(this.populateSalesContact(data, 'Medical'));
      elements.push(this.populateBrokerName(data, 'Medical'));

      elements.push(this.populateSICFactor(data));
      elements.push(this.populateAgeSexFactor(data));
      if (data?.factors !== undefined) {
        elements.push(this.populateRiskScore(data, processWithArrow));
      }
    }

    elements.push(this.populateContractStartDate(data));
    elements.push(this.populateContractEndDate(data));
    elements.push(this.populateFactorEffectiveDate(data));

    elements.push(this.populateTierDetails(data, 'Medical'));
    elements.push(this.populateEligibleEmployees(data, 'Medical'));
    elements.push(this.populateWaivers(data, 'Medical'));
    elements.push(this.populateQuotedSubscribers(data, 'Medical'));
    elements.push(this.populateEstimatedMembers(data, 'Medical'));
    elements.push(this.populateMemberContractRatio(data, 'Medical'));

    if (data.opportunityType && data.opportunityType === 'Renewal Local') {
      if (data.fundingType !== 'FI') {
        elements.push(this.populateVirginGroup(data));
      }
    } else {
      elements.push(this.populateVirginGroup(data));
    }
    let erFunding = this.populateERFunding(data, erFundingLevelData);
    if (erFunding) {
      elements.push(erFunding);
    }

    if (fundingType.toLowerCase() != 'fi') {
      let contractBasis = this.populateContractBasisRefund(data);
      let sslASL = this.populateSSLASL(data);
      if (contractBasis) {
        elements.push(contractBasis);
      }
      if (sslASL) {
        elements.push(sslASL);
      }
    }
    elements.push(this.populateUnderwriterName(data));
    elements.push(this.populateStatus(data));

    let retValue = [];
    let rows: number = 6;
    // Math.floor(elements.length / 4) + (elements.length % 4 > 0 ? 1 : 0);
    for (let iLoop: number = 0; iLoop < 4; iLoop++) {
      let startIndex: number = rows * iLoop;
      let endingIndex: number = startIndex + rows;
      retValue.push(elements.slice(startIndex, endingIndex));
    }
    return retValue;
  }

  medicalQuotingTypeMEWA(data: any, fundingType: string): any[] {
    let firstCol = [];
    let secondCol = [];
    let thirdCol = [];
    let fourthCol = [];
    firstCol.push(this.populateQuoteHeaderID(data));
    firstCol.push(this.populateFundingType(fundingType, data, 'medical'));
    firstCol.push(this.populateState(data));
    firstCol.push(data?.opportunityType === 'Renewal Local' ? this.popuplateGroupNumber(data) : this.populateSIC(data));
    firstCol.push(this.populateSalesContact(data, 'Medical'));
    firstCol.push(this.populateBrokerName(data, 'Medical'));

    secondCol.push(this.populateDefaultRiskFactor(data));
    secondCol.push(this.populateAssociation(data));
    if (data.opportunityType && data.opportunityType === 'Renewal Local') {
       secondCol.push(this.populateSIC(data));
     }
    secondCol.push(this.populateContractStartDate(data));
    secondCol.push(this.populateContractEndDate(data));
    secondCol.push(this.populateFactorEffectiveDate(data));

    thirdCol.push(this.populateTierDetails(data, 'Medical'));
    thirdCol.push(this.populateEligibleEmployees(data, 'Medical'));
    thirdCol.push(this.populateWaivers(data, 'Medical'));
    thirdCol.push(this.populateQuotedSubscribers(data, 'Medical'));
    thirdCol.push(this.populateEstimatedMembers(data, 'Medical'));

    fourthCol.push(this.populateUnderwriterName(data));
    fourthCol.push(this.populateStatus(data));

    return [firstCol, secondCol, thirdCol, fourthCol];
  }

  medicalQuotingTypeACA(data: any, fundingType: string): any[] {
    let firstCol = [];
    let secondCol = [];
    let thirdCol = [];
    let fourthCol = [];
    firstCol.push(this.populateQuoteHeaderID(data));
    firstCol.push(this.populateFundingType(fundingType, data, 'medical'));
    firstCol.push(this.populateState(data));

    secondCol.push(this.populateContractStartDate(data));
    secondCol.push(this.populateContractEndDate(data));

    thirdCol.push(this.populateQuotedSubscribers(data, 'Medical'));
    thirdCol.push(this.populateEstimatedMembers(data, 'Medical'));

    fourthCol.push(this.populateStatus(data));

    return [firstCol, secondCol, thirdCol, fourthCol];
  }

  populateQuoteHeaderID(data): any {
    let quoteHeaderID = data.quoteHeaderID || this.noData;
    let quoteType = this.getQuoteType(data);
    let riderNamesList = data['riderNamesList'] && data['riderNamesList'].length ? data['riderNamesList'].join(', ') : null;
    return {
      key: 'quoteHeaderID',
      label: 'Quote ID',
      value: quoteHeaderID,
      labelSuffix: quoteType ? '*' : null,
      labelToolTip: quoteType,
      valueSuffix: riderNamesList ? '*' : null,
      valueTooltip: riderNamesList
    };
  }

  getQuoteType(data): any {
    let proposedPrdctSubCtgry = data['medical'] && data['medical'].proposedPrdctSubCtgry;
    let quoteType = null;
    if (proposedPrdctSubCtgry != null) {
      if (proposedPrdctSubCtgry.length > 1 || (proposedPrdctSubCtgry.length == 1 && !proposedPrdctSubCtgry.includes('STANDARD'))) {
        quoteType = proposedPrdctSubCtgry.toString();
      }
    }
    return quoteType;
  }

  populateState(data): any {
    let state = data.state || this.noData;
    let quotedLegalEntity = data.quoteLegalEntity;
    let address1 = data.addr1 || '';
    let address2 = data.addr2 || '';
    let compZipcode = data.companyZipCode || '';
    let county = data.county || '';

    return {
      key: 'state',
      label: 'State/Legal Entity',
      value: state + '/' + quotedLegalEntity,
      labelToolTip: address1 + ' ' + address2 + ' ' + compZipcode + (county ? ', County: ' + county : ''),
      valueToolTip: quotedLegalEntity
    };
  }

  populateSalesContact(data, lob: string): any {
    let salesRepName = this.noData;

    if (data.primaryUserInfo) {
      salesRepName = data.primaryUserInfo.fullName || this.noData;
    }

    return {
      key: 'salesRepName',
      label: 'Sales Contact Name',
      value: salesRepName
    };
  }

  populateBrokerName(data, lob: string): any {
    let brokerName = this.noData;

     if (data.brokerUserInfo && data.brokerUserInfo.Medical) {
           brokerName = data.brokerUserInfo.Medical.fullName || this.noData;
         }

    return {
      key: 'brokerName',
      label: 'Broker Name',
      value: brokerName
    };
  }

  populateSIC(data): any {
    let sicCode = data.sicCode || this.noData;
    let sicDescription = '';
    if (data.factors && data.factors.sicDescription) {
      sicDescription = data.factors.sicDescription;
    }

    let hasGuardRailFailures = this.markGuardRailFailures('sicCode');

    return {
      key: 'sicCode',
      label: 'SIC Code-Desc',
      value: sicCode + (sicDescription ? ' - ' : '') + sicDescription,
      valueToolTip: hasGuardRailFailures ? '' : sicCode + (sicDescription ? ' - ' : '') + sicDescription,
      hasGuardRailFailures: hasGuardRailFailures,
      guardRailErrorMessage: this.displayErrorMessage('sicCode', sicCode + (sicDescription ? ' - ' : '') + sicDescription)
    };
  }

  populateFundingType(fundingType: string, data: any, lob: string): any {
    let marketSegment = data.marketSegment;
    let oppType = data.opportunityType.replace(' Local', '');
    let label = 'FA TP/Mkt Seg/Opp TP';
    if (data.quotingType === 'ACA' || data.quotingType === 'MEWA') {
      fundingType = data.quotingType;
    }
    let value = fundingType + '/' + marketSegment + '/' + oppType;
    // Check for altquote and appending the value
    let altquote = data.medical.alternateQuote;
    if (altquote === true || altquote === 'yes') {
      value += ' ' + 'Alt';
    }
    let key = data.opportunityType && data.opportunityType === 'Renewal Local' ? 'fundingTypeRenewal' : 'fundingType';
    let showExperienceSummaryIcon =
      data.quotingType != 'MEWA' &&
      (data.opportunityType === 'Renewal Local' ||
        (this.commonService.getEnabledNBGroupExpSummary() &&
          data.opportunityType === OpportunityType.NewBusinessLocal))
      data.groupExperienceSummary &&
      data[lob] &&
      data[lob].experienceClaimsAvailable.toLocaleLowerCase() === 'yes';

    let showNewBusinessGroupExpIcon =
      ![true,'yes'].includes(altquote) &&
      this.commonService.getExperienceExtractionEnabled() &&
      data.opportunityType === OpportunityType.NewBusinessLocal;

    let labelToolTip = this.tooltipMessageForOppOrigin(data);

    return {
      key,
      label,
      value,
      labelToolTip,
      valueToolTip: value,
      showExperienceSummaryIcon,
      showNewBusinessGroupExpIcon
    };
  }

  tooltipMessageForOppOrigin(data: any) {
    if (data?.oppOrigin) {
      const marketSegment = data.oppOrigin['Market Segment'];
      const mbu = data.oppOrigin['MBU'];

      if (marketSegment) {
        return data.marketSegment === 'SG' ? 'Key to SG' : 'SG to Key';
      } else if (mbu) {
        return mbu;
      }
    }
  }

  popuplateGroupNumber(data): any {
    return {
      key: 'groupNumber',
      label: 'Group Number',
      value: data.groupNbr ? data.groupNbr : '',
      show: data.opportunityType === 'Renewal Local'
    };
  }

  populateERFunding(data: any, erFundingLevelData: any): any {
    let errFundingFactor = null;
    if (data.medical && (data.medical.employerFundingLevel || data.medical.employerFundingLevel === 0)) {
      errFundingFactor = parseFloat((data.medical.employerFundingLevel * 100).toFixed(1));
    } else if (erFundingLevelData && (erFundingLevelData.dfltPct || erFundingLevelData.dfltPct === 0)) {
      errFundingFactor = parseFloat((erFundingLevelData.dfltPct * 100).toFixed(1));
    }

    if (errFundingFactor != null) {
      return {
        key: 'erFunding',
        label: 'ER Ded Fund%',
        value: errFundingFactor
      };
    }

    return null;
  }

  populateSICFactor(data): any {
    let sicFactor =
      data.factors && data.factors.industryFactor && !isNaN(parseFloat(data.factors.industryFactor))
        ? parseFloat(data.factors.industryFactor).toFixed(10)
        : 'N/A';
    return {
      key: 'sicFactor',
      label: 'SIC Factor',
      value: sicFactor
    };
  }

  populateAgeSexFactor(data): any {
    let medAgeSex =
      data.factors && data.factors.medicalFactors && !isNaN(parseFloat(data.factors.medicalFactors.ageSexFactor))
        ? parseFloat(data.factors.medicalFactors.ageSexFactor).toFixed(10)
        : 'N/A';
    let rxAgeSex =
      data.factors && data.factors.rxFactors && !isNaN(parseFloat(data.factors.rxFactors.ageSexFactor))
        ? parseFloat(data.factors.rxFactors.ageSexFactor).toFixed(10)
        : 'N/A';
    return {
      key: 'medAgeSex',
      label: 'Age/Sex Fctr',
      value: medAgeSex,
      valueToolTip: 'Med: ' + medAgeSex + ', RX: ' + rxAgeSex,
      hasGuardRailFailures: this.markGuardRailFailures('ageSexFactor'),
      guardRailErrorMessage: this.displayErrorMessage('medAgeSex', data.derivedState)
    };
  }

  populateAssociation(data): any {
    let association = data.factors?.mewaFactors?.assnNm || this.noData;
    return {
      key: 'association',
      label: 'Association',
      value: association,
      valueToolTip: association
    };
  }

  populateDefaultRiskFactor(data): any {
    // TODO: Need to check after the api is ready
    let riskFactor =
      data.medical.riskFactor == -99999
        ? this.noData
        : data.medical.riskFactor && !isNaN(parseFloat(data.medical.riskFactor))
          ? parseFloat(data.medical.riskFactor).toFixed(10)
          : this.noData;
    let hasGuardRailFailures = this.markGuardRailFailures('riskFactor');
    return {
      key: 'defaultRiskFactor',
      label: 'Default Risk factor',
      value: riskFactor,
      hasGuardRailFailures: hasGuardRailFailures,
      valueToolTip: hasGuardRailFailures == 1 ? this.displayErrorMessage('riskFactor') : ''
    };
  }

  populateRiskScore(data, processWithArrow): any {
    let riskScoreCheck = data.riskScore;
    let riskScore =
      data.riskScore == -99999 ? this.noData : data.riskScore && !isNaN(parseFloat(data.riskScore)) ? parseFloat(data.riskScore).toFixed(10) : this.noData;
    let curvScore = data.riskScore == -99999 ? '' : data.riskScore && !isNaN(parseFloat(data.riskScore)) ? parseFloat(data.riskScore).toString().split('.')[0] + '.' + (parseFloat(data.riskScore).toString().split('.')[1]?.substring(0, 2) || '') : '';
    let hasGuardRailFailures = this.markGuardRailFailures('riskScore');
    let receivedRiskScoreVersion = data.receivedRiskScoreVersion;
    let statusDescription = data.riskScoreStatusDescription ? 'Arrow Message: ' + data.riskScoreStatusDescription : '';
    let curvRiskFactorGuardRail = data.factors?.guardRails.find(gr => gr.attrbNm == "request.riskScore");
    let failedCurvGuardRails = data.riskScore < Number(curvRiskFactorGuardRail.minVal) || data.riskScore > Number(curvRiskFactorGuardRail.maxVal);
    let curvStatusDescription = failedCurvGuardRails ? `Risk factor is out of range : ${curvRiskFactorGuardRail.minVal} - ${curvRiskFactorGuardRail.maxVal}` : '';
    if (data.riskScoreType == 'NA' || data.riskScoreType == 'CURV') {
      return {
        key: 'curvRiskScore',
        label: 'Risk Score',
        labelSuperScript: 'CURV',
        value: data.riskScore.toString().length == 1 ? riskScoreCheck : curvScore,
        hasGuardRailFailures: data.riskScore != -99999 && failedCurvGuardRails ? failedCurvGuardRails : null,
        labelToolTip: data.riskScore != -99999 && failedCurvGuardRails ? curvStatusDescription : ''
      };
    } else {
      return {
        key: 'riskScore',
        label: 'Risk Score',
        labelSuperScript: receivedRiskScoreVersion,
        value: riskScore,
        riskScoreVersionModified: !!data?.riskScoreVersionModified,
        valueWithURL: ValidationService.isValidUrl(data.arrowURL) && !StringUtils.isEqual(riskScore, this.noData) ? data.arrowURL : '',
        hasGuardRailFailures: hasGuardRailFailures,
        labelToolTip: statusDescription,
        valueToolTip: hasGuardRailFailures == 1 ? this.displayErrorMessage('riskScore', data.derivedState) : ''
      };
    }
  }

  populateContractStartDate(data): any {
    let effectiveDateCode = this.datepipe.transform(data.submittedTimestamp, 'MM-dd-yyyy');
    let contractStartDate = this.datepipe.transform(data.contractEffectiveDate, 'yyyy-MM-dd');
    let origiContEffDate = '';
    let peOverideConEffdate = '';
    let labelTooltip = '';
    let valueSuffix = '';
    let valueToolTip = '';
    if (data.uwAdjustment && data.uwAdjustment.peOverrideData) {
      let overrideData = data.uwAdjustment.peOverrideData;
      if (overrideData.contractEffectiveDate) {
        peOverideConEffdate = this.datepipe.transform(this.getDateFormate(overrideData.contractEffectiveDate), 'yyyy-MM-dd');
        if (peOverideConEffdate != contractStartDate) {
          origiContEffDate = contractStartDate;
          contractStartDate = peOverideConEffdate;
        }
      }
    }

    let hasGuardRailFailures = this.markGuardRailFailures('contractEffectiveDate');
    let guardRailErrorMessage = this.displayErrorMessage('contractEffectiveDate', effectiveDateCode);
    if (origiContEffDate) {
      labelTooltip = hasGuardRailFailures ? guardRailErrorMessage : '';
      valueSuffix = '!';
      valueToolTip = 'Orig Eff Dt: ' + this.datepipe.transform(origiContEffDate, 'MM-dd-yyyy');
      hasGuardRailFailures = false;
      guardRailErrorMessage = '';
    }

    return {
      key: 'contractEffectiveDate',
      label: 'Cont Eff Date',
      labelTooltip,
      value: this.datepipe.transform(contractStartDate, 'MM-dd-yyyy'),
      valueSuffix,
      valueToolTip,
      hasGuardRailFailures,
      guardRailErrorMessage
    };
  }

  populateContractEndDate(data): any {
    let contractEndDate = this.datepipe.transform(data.contractEndDate, 'yyyy-MM-dd');
    let origiContEndDate = '';
    let peOverideConEnddate = '';
    let valueSuffix = '';
    let valueToolTip = '';
    if (data.uwAdjustment && data.uwAdjustment.peOverrideData) {
      let overrideData = data.uwAdjustment.peOverrideData;
      if (overrideData.contractEndDate) {
        peOverideConEnddate = this.datepipe.transform(this.getDateFormate(overrideData.contractEndDate), 'yyyy-MM-dd');
        if (peOverideConEnddate != contractEndDate) {
          origiContEndDate = contractEndDate;
          contractEndDate = peOverideConEnddate;
        }
      }
    }

    if (origiContEndDate) {
      valueSuffix = '!';
      valueToolTip = 'Orig End Dt: ' + this.datepipe.transform(origiContEndDate, 'MM-dd-yyyy');
    }

    return {
      key: 'contractEndDate',
      label: 'Cont End Date',
      value: this.datepipe.transform(contractEndDate, 'MM-dd-yyyy'),
      valueSuffix,
      valueToolTip
    };
  }

  populateFactorEffectiveDate(data): any {
    let factorEffectiveDate = this.datepipe.transform(data.factorEffectiveDate, 'MM-dd-yyyy');
    return {
      key: 'factorEffectiveDate',
      label: 'Factor Eff Date',
      value: factorEffectiveDate
    };
  }

  populateTierDetails(data, lob: string): any {
    let inputTier = data.medicalInputTier;
    let outputTier = data.medicalOutputTier;
    return {
      key: 'tierDetails',
      label: 'Input/Req Tier',
      value: inputTier + '/' + outputTier
    };
  }

  populateEligibleEmployees(data, lob: string): any {
    let eligibleEmp = 0;
    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.medEligibilityLivesMap) {
      eligibleEmp = data.censusCalc.censusSubscriber.medEligibilityLivesMap.EligibleCount || 0;
    }

    return {
      key: 'eligibleEmp',
      label: 'Eligible Emps',
      value: eligibleEmp,
      hasGuardRailFailures: this.markGuardRailFailures('subscriberOnlyCensus'),
      guardRailErrorMessage: this.displayErrorMessage('eligibleEmp')
    };
  }

  populateWaivers(data, lob: string): any {
    let waivers = 0;
    if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.medEligibilityLivesMap) {
      waivers = data.censusCalc.censusSubscriber.medEligibilityLivesMap.WaiverCount || 0;
    }

    return {
      key: 'waivers',
      label: 'Waivers',
      value: waivers
    };
  }

  populateEstimatedMembers(data, lob: string): any {
    let estMembers = 'N/A';
    let toolTipVal;
    let guardRailFailed = false;
    let isActurial = false;
    if (data.factors && data.factors.estMembers && !isNaN(parseFloat(data.factors.estMembers))) {
      estMembers = parseFloat(data.factors.estMembers).toFixed(0);
      guardRailFailed = this.markGuardRailFailures('useActurialCensus');
      isActurial = data.factors.useActurialCensus == undefined || data.factors.useActurialCensus || data.censusCalc.subscriberOnlyCensus;
      toolTipVal = isActurial ? 'Estimated Member Count' : 'Actual Member Count';
    }

    return estMembers == 'N/A'
      ? {
          key: 'estMembers',
          label: 'Estimated Mbrs',
          value: estMembers
        }
      : {
          key: 'estMembers',
          label: 'Estimated Mbrs',
          value: estMembers,
          valueToolTip: toolTipVal,
          guardRailFailedForEsm: guardRailFailed,
          isActualMemberCount: !isActurial
        };
  }

  populateQuotedSubscribers(data, lob: string): any {
    let totalMedEmp = 0;
    if (data.quotingType === 'ACA') {
      totalMedEmp = data?.factors?.eligibleSubCount || 0;
      return {
        key: 'quotedSubscribers',
        label: 'Quoted Subs',
        value: totalMedEmp
      };
    } else if (data.censusCalc && data.censusCalc.censusSubscriber && data.censusCalc.censusSubscriber.medEligibilityLivesMap) {
      totalMedEmp = data.censusCalc.censusSubscriber.medEligibilityLivesMap.QuotedCount || 0;
    }
    return {
      key: 'quotedSubscribers',
      label: 'Quoted Subs',
      labelToolTip: 'Click to download census',
      value: totalMedEmp,
      hasGuardRailFailures: this.markGuardRailFailures('outOfStateSubscribers'),
      guardRailErrorMessage: this.displayErrorMessage('totalMedEmp')
    };
  }

  populateMemberContractRatio(data, lob: string): any {
    let acsFactor =
      data.factors && data.factors.acsFactor && !isNaN(parseFloat(data.factors.acsFactor)) ? parseFloat(data.factors.acsFactor).toFixed(2) : 'N/A';

    let unroundedAcsFactor = acsFactor != 'N/A' ? data.factors.acsFactor : '';
    let hasGuardRailFailuresForAcs = this.markGuardRailFailures('acsFactorDifferenceWithActualCensus');
    if (hasGuardRailFailuresForAcs && data.factors && data.factors.acsFactorDifferenceWithActualCensus) {
      unroundedAcsFactor +=
        ' Actual member based ACS is ' +
        (data.factors.acsFactorDifferenceWithActualCensus * 100).toFixed(0) +
        '% higher than Actuarial estimated member based ACS';
    }

    return {
      key: 'acsFactor',
      label: 'Mbr/Ctrct Ratio',
      value: acsFactor,
      valueToolTip: unroundedAcsFactor,
      guardRailFailureForAcs: hasGuardRailFailuresForAcs
    };
  }

  populateVirginGroup(data): any {
    let virginGroup = data.virginGroup ? 'Y' : 'N';

    return {
      key: 'virginGroup',
      label: 'Virgin Group',
      value: virginGroup
    };
  }

  populateStatus(data): any {
    let status = data.status;
    return {
      key: 'status',
      label: 'Status',
      value: status
    };
  }

  populateUnderwriterName(data): any {
    let underwriterName = data.underwriterName;

    return {
      key: 'underwriter',
      label: 'UW Name',
      value: underwriterName
    };
  }

  populateContractBasisRefund(data): any {
    let stopLossCovg: any = {};
    let value = '';
    if (data && data.medical && data.medical.stopLossCovg && Array.isArray(data.medical.stopLossCovg)) {
      stopLossCovg = data.medical.stopLossCovg[0];
    }
    if (stopLossCovg && Object.keys(stopLossCovg).length > 0) {
      let refundValue: number | any = parseFloat(stopLossCovg.surplusRefund);
      if (isNaN(refundValue)) {
        refundValue = 0;
      }
      refundValue = (refundValue * 100).toFixed(0);
      let refundValueDiff: number = 100 - refundValue;

      if (stopLossCovg.sslContractBasis == data.sslContractBasisForHeaderDisplay) {
        value = '( ' + (data.sslContractBasisForHeaderDisplay || ' - ') + ' )/( ' + refundValue + '% / ' + refundValueDiff + '% )';
      } else {
        value = data.sslContractBasisForHeaderDisplay + '/( ' + refundValue + '% / ' + refundValueDiff + '% )';
      }
    }
    return {
      key: 'coinBasis',
      label: 'Cont basis/Refund',
      value
    };
  }

  populateSSLASL(data): any {
    let stopLossCovg: any = {};
    let value = '';
    if (data && data.medical && data.medical.stopLossCovg && Array.isArray(data.medical.stopLossCovg)) {
      stopLossCovg = data.medical.stopLossCovg[0];
    }
    if (stopLossCovg && Object.keys(stopLossCovg).length > 0) {
      value = '$' + parseFloat(stopLossCovg.sslDeductible || 0).toFixed(0) + '/' + ((stopLossCovg.aggSLCorridor || 0) * 100).toFixed(0) + '%';
    }
    return {
      key: 'sslAsl',
      label: 'SSL/ASL',
      value
    };
  }

  displayErrorMessage(eleID, value?: any) {
    switch (eleID) {
      case 'contractEffectiveDate':
        return 'Contract start date is in the past, request /update is submitted on ' + value;
      case 'eligibleEmp':
        return 'Subscriber Only Census';
      case 'totalMedEmp':
        return '100% OOS';
      case 'sicCode':
        return value + '- SIC code belongs to Risky industry';
      case 'medAgeSex':
        return (
          'Age-Gender factor is out of range - Min&Max for ' +
          value +
          ' is: ' +
          ((this.guardrailBoundaries && this.guardrailBoundaries['Demographic Age Factor']) || 'NA')
        );
      case 'riskScore':
        return (
          'Risk score is out of range - Min&Max for ' + value + ' is: ' + (this.guardrailBoundaries && this.guardrailBoundaries['Arrow Risk Score']) || 'NA'
        );
      case 'riskFactor':
        return 'MEWA risk factor is out of range : ' + (this.guardrailBoundaries && this.guardrailBoundaries['MEWA Risk  Factor']) || 'NA';
      default:
        return;
    }
  }

  markGuardRailFailures(guardRail) {
    return this.quotelevelFailData && this.quotelevelFailData[guardRail];
  }

  setDeclineOptions(declineOptions) {
    this.declineOptionsFromBackend = declineOptions;
  }

  getDeclineOptions() {
    return this.declineOptionsFromBackend;
  }

  setUwNotesToSales(uwNotesToSales) {
    this.uwNotesToSales = uwNotesToSales;
  }

  getUwNotesToSales() {
    return this.uwNotesToSales;
  }

  setDeclineOptionsChecked(declineOptionsChecked) {
    this.declineOptionsChecked = declineOptionsChecked;
  }

  getDeclineOptionsChecked() {
    return this.declineOptionsChecked;
  }

  setUserTypedDeclineReasons(userTypedDeclineReasons) {
    this.userTypedDeclineReasons = userTypedDeclineReasons;
  }

  getUserTypedDeclineReasons() {
    return this.userTypedDeclineReasons;
  }

  getDateFormate(date) {
    let updatedEffDate = new Date(date);
    return new Date(updatedEffDate.getUTCFullYear(), updatedEffDate.getUTCMonth(), updatedEffDate.getUTCDate());
  }

  fetchBoundaries(guardRailsList) {
    let boundariesObj = {};
    guardRailsList &&
      guardRailsList.forEach((guardrail) => {
        if (guardrail.chkLvl === 'Quote') {
          boundariesObj[guardrail.guardName] = `${guardrail.minVal} - ${guardrail.maxVal}`;
        }
      });

    return boundariesObj;
  }
}
