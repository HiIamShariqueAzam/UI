import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class HttpClientService {
  private restApi: any;

  constructor(private http: HttpClient) {
    this.restApi = {};
  }

  createCustomHeaders(headerParam?: HttpHeaders) {
    // Add custom headers
    if (headerParam) {
      return headerParam;
    } else {
      let headers = new HttpHeaders();
      return headers.set('Content-Type', 'application/json');
    }
  }
  get(url, headerParam?: HttpHeaders, responseTypeParam?: any) {
    if (responseTypeParam != undefined && responseTypeParam != null) {
      return this.http.get(url, { responseType: responseTypeParam, headers: headerParam });
    } else {
      return this.http.get(url, { headers: headerParam });
    }
  }
  post(url: string, data: any, headerParam?: HttpHeaders, responseTypeParam?: any) {
    if (responseTypeParam != undefined && responseTypeParam != null) {
      return this.http.post(url, data, { responseType: responseTypeParam, headers: {} });
    } else {
      return this.http.post(url, data, { headers: {} });
    }
  }
}
