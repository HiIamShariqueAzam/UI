import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { Observable } from 'rxjs';
import { CommonConstants } from '../constants/common.constants';
import { DateFormatPipe } from '../pipes/date-format-pipe';
import { CommonUtil } from '../utils/common-util';
import { AuthenticationService } from './authentication.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  opportunityId: string;
  quoteHeaderId: string;
  ratingTransID: any;
  rareUIUrl: string = '';
  gatewayCacheRefreshUrl: string;
  medicalCacheRefreshUrl: string;
  visionCacheRefreshUrl: string;
  dentalCacheRefreshUrl: string;
  ratingCacheRefreshUrl: string;
  factorManagerExternalUrl: string;
  showServiceIDLoginPage: boolean = false;
  factorManagerMainUrl: any;
  calculatorPremiumMedicalUrl: any;
  reQuoteUrl: any;
  calculatorSoldRatesUrl: any;
  tablesUrl: any;
  printEngineUrl: string;
  analyticsBaseUrl: string;
  autoSubmitBDFlag: boolean;
  productAdjustmentsEnabled: boolean;
  rareUINginxUrl: string = '';
  public static availableTableList: string[] = [];
  readonlyRoleList: any;
  lobList: string[] = [];
  stateList: string[] = [];
  mapOfRoleAndTableNames = new Map<string, string[]>();
  fullTablesList: any[] = [];
  quoteTabList: any[] = [];
  public static exportFilename: any;
  visionBaseUrl: any;
  dentalBaseUrl: any;
  isVisionEnabled: any = 'true';
  isSmallGroupIntakeEnabled: boolean = false;
  public static progressBarTimeOut: number;
  assignedUserGroup: any;
  insertedTimestamp: any;
  supportingDocLinksKeywords: any;
  isRenewalEnabled: boolean = true;
  isMatchClicked: boolean = false;
  onMatchClick: boolean = false;
  onResetClick: boolean = false;
  adjustedRatingPlanID: any;
  factorMigrationEnabled: boolean = false;
  experienceExtractionEnabled: boolean = false;
  fiRenewalEnabled: boolean = true;
  factorMigrationPartialExclusionSystems: any;
  factorMigrationRemoveExclusionSystems: any;
  factorMigrationImportFileSize: number = 7.45;
  factorImportEnabled: boolean = false;
  factorExportEnabled: boolean = false;
  soldRestructureTabEnabled: boolean = false;
  newCreateOpportunityFlow: boolean = false;
  medSGAcaRareRouteEnabled: boolean = false;
  managementReportEnable: boolean = false;
  currentEnvironment: any;
  isAutoRunBatchEnabled: boolean = true;
  private newCreateOppAltLinkEnabled: boolean = false;
  private _oktaAuthEnabled: boolean = false;
  private createOppSGAltLinkEnabled: boolean = false;
  enabledSendToOppMap: any;
  arrowCallRestrictionMap: any;
  medicareStateMarkerMap: any;
  crossSellingRestrictionMap: object;
  enableAutorunACAQuoteActions: boolean = false;
  isCrossSellingEnabled: boolean = true;
  showViewCalc: boolean;
  exhibitDental: any[] = [];
  isSearchAnywhereForQuoteSearchEnabled: boolean = true;
  enabledBatchGroupDownload: boolean;
  mewaPortfolioEnabled: boolean = false;
  quoteOptionStatesMap: any;
  rareSpecialitySendToOppEnabled: boolean = false;
  rareEnableBulkImport: boolean = false;
  planCustomizationURL: string;
  expiryDateForStaticApi: number;
  specialtyLobsEnabledForBatchSubmission: any;
  isTieringEnabled: boolean = false;
  tieringConfig: any;
  oktaInterceptUrls: string[] = [];
  createOppMEWAEnabled: boolean;
  exhibitVision: any[] = [];
  bulkAdjForVisDenEnabled: boolean = false;
  exhibitVisionEnabled: boolean = false;
  exhibitDentalEnabled: boolean = false;
  disableVisionDentalLgBatchSubmit: boolean = false;
  bulkUploadImportConfig: any;
  datasourcesForBatchScreenSearchOverlay: any[] = [];
  renewalASIsSoldEnabled: boolean = false;
  mewaOriginalQuoteEnabled: boolean;
  customSparkWidgetUrl: any;
  oppSpecialityPlanUpdateConfig: any;
  enabledTieringVisionLGBatch: boolean = false;
  enabledTieringDentalLGBatch: boolean = false;
  mewaOriginalQuoteReleaseEnabled: boolean;
  customTierRatioTypeRateActionFixEnabled: boolean;
  dentalBaseContractCodeFlowEnabled: boolean;
  lossRationVisionViewOnBulkScreenEnabled: boolean;
  securityAuthMode: string = '';
  abfDefaultCommissionValue: any;
  abfDefaultCommissionType: any;
  enabledNBGroupExpSummary: boolean;
  isNBCurrentRatesEnabled: boolean;
  newBusinessUploadEnabledConfig: any;
  batchAltQuoteSubmitThreshold: any;
  batchOppQuoteSubmitThreshold: any;
  sgSpecialtyVisionDentalEnabled: boolean;

  constructor(
    private authenticationService: AuthenticationService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private http: HttpClient,
    private router: Router,
    private dateFormatPipe: DateFormatPipe,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer
  ) {}

  setOpportunityId(opportunityId: string) {
    this.opportunityId = opportunityId;
  }

  setquoteHeaderId(quoteHeaderId: string) {
    this.quoteHeaderId = quoteHeaderId;
  }

  setRatingTransID(ratingTransID: any) {
    this.ratingTransID = ratingTransID;
  }

  getRatingTransID(): string {
    return this.ratingTransID;
  }

  getopportunityId(): string {
    return this.opportunityId;
  }

  getquoteHeaderId(): string {
    return this.quoteHeaderId;
  }

  setRareUIUrl(url) {
    this.rareUIUrl = url;
  }

  getRareUiUrl() {
    return this.rareUIUrl;
  }

  setGatewayCacheRefreshUrl(gatewayCacheRefreshUrl: string) {
    this.gatewayCacheRefreshUrl = gatewayCacheRefreshUrl;
  }

  getGatewayCacheRefreshUrl(): string {
    return this.gatewayCacheRefreshUrl;
  }

  setPlanCustomizationURL(planCustomizationURL: string) {
    this.planCustomizationURL = planCustomizationURL;
  }

  getPlanCustomizationURL(): string {
    return this.planCustomizationURL;
  }

  setFactorMigrationPartialExclusionSystems(factorMigrationPartialExclusionSystems: any) {
    this.factorMigrationPartialExclusionSystems = factorMigrationPartialExclusionSystems;
  }

  getFactorMigrationPartialExclusionSystems() {
    return this.factorMigrationPartialExclusionSystems;
  }

  setFactorMigrationRemoveExclusionSystems(factorMigrationRemoveExclusionSystems: any) {
    this.factorMigrationRemoveExclusionSystems = factorMigrationRemoveExclusionSystems;
  }

  getFactorMigrationRemoveExclusionSystems() {
    return this.factorMigrationRemoveExclusionSystems;
  }

  setHeadersInfo() {
    return new HttpHeaders()
      .set('userid', this.authenticationService.getUserID())
      .set('username', this.authenticationService.getUserName())
      .set('emailId', this.authenticationService.getUserEmail())
      .set('role', this.authenticationService.getUserRole());
  }

  setRequestHeadersSoldRate() {
    let headers = this.setHeadersInfo();
    if (this.opportunityId && this.quoteHeaderId && this.ratingTransID) {
      headers = this.setHeadersInfo()
        .set('opportunityID', this.opportunityId)
        .set('quoteHeaderID', this.quoteHeaderId)
        .set('rating-transid', this.ratingTransID);
    }
    return headers;
  }

  setHeaders(metaTransID: string, ratingTransID: string) {
    return new HttpHeaders()
      .set('meta-transid', metaTransID)
      .set('rating-transid', ratingTransID)
      .set('meta-senderapp', 'RARE-UI')
      .set('Access-Control-Allow-Origin', '*')
      .set('userid', CommonUtil.getUserIDHeader(this.authenticationService))
      .set('username', CommonUtil.getUserNameHeader(this.authenticationService))
      .set('emailId', this.authenticationService.getUserEmail())
      .set('role', this.authenticationService.getUserRole());
  }

  setRequestHeaders() {
    return new HttpHeaders()
      .set('meta-transid', 'abc')
      .set('userid', CommonUtil.getUserIDHeader(this.authenticationService))
      .set('username', CommonUtil.getUserNameHeader(this.authenticationService))
      .set('emailId', this.authenticationService.getUserEmail() ? this.authenticationService.getUserEmail() : 'test@anthem.com')
      .set('role', this.authenticationService.getUserRole() ? this.authenticationService.getUserRole() : 'LOCAL_ADMIN');
  }

  getRareUiRequest(data) {
    let metaData = {
      userid: this.authenticationService.getUserID(),
      username: this.authenticationService.getUserName(),
      emailId: this.authenticationService.getUserEmail(),
      role: this.authenticationService.getUserRole()
    };
    let rareUiRequest = {
      metadata: null,
      data: null
    };
    rareUiRequest.metadata = metaData;
    rareUiRequest.data = data;
    return rareUiRequest;
  }

  getTieringRequestForLGVisDen(data) {
    let req = {
      "batchID": data.renewalBatchDetails[0]?.batchID,
      "renewalMonth": data.renewalBatchDetails[0]?.renewalMonth,
      "fundingType": data.renewalBatchDetails[0]?.fundingType,
      "marketSegment": data.renewalBatchDetails[0]?.marketSegment,
      "state": data.renewalBatchDetails?.filter( batch => batch.included)[0].state,
      "repull": false,
      "lob": data.renewalBatchDetails[0]?.lob,
    }
    return req;
  }

  setSubmitHeadersSoldRate(metaTransID, ratingTransID) {
    let headers = this.setHeaders(metaTransID, ratingTransID);
    if (this.opportunityId && this.quoteHeaderId) {
      headers = this.setHeaders(metaTransID, ratingTransID).set('opportunityID', this.getopportunityId()).set('quoteHeaderID', this.getquoteHeaderId());
    }
    return headers;
  }

  getRareUiRequestForSpecialtyUpload(data) {
    let metaDta = {
      userid: this.authenticationService.getUserID(),
      username: this.authenticationService.getUserName()
    };
    let data1 = {
      batchName: data
    };
    let RareUiRequest = {
      metadata: null,
      data: null
    };
    RareUiRequest.metadata = metaDta;
    RareUiRequest.data = data1;
    return RareUiRequest;
  }

  getRareUiRequestForImportFileUpload(data) {
    let metaDta = {
      userid: this.authenticationService.getUserID(),
      username: this.authenticationService.getUserName()
    };
    let data1 = {
      batchId: data
    };
    let RareUiRequest = {
      metadata: null,
      data: null
    };
    RareUiRequest.metadata = metaDta;
    RareUiRequest.data = data1;
    return RareUiRequest;
  }

  escapeRegExp(stringVal) {
    return stringVal.replace(/[-\/\\^$*+?.()|[\]{}%<>=#_]/g, '\\$&');
  }
  /**
   * - matches the character -
   * \/ matches the character /
   * \\ matches the character \
   * ^$*+?()|[ matches a single character in the list ^$*+?()|[
   * \] matches the character ]
   * {} matches a single character in the list {}
   */
  escapeNameRegExp(stringVal) {
    return stringVal.replace(/[-\/\\^$*+?()|[\]{}]/g, '\\$&');
  }

  constructChartFilterRequest(obj) {
    let metadata = {
      userid: this.authenticationService.getUserID(),
      username: this.authenticationService.getUserName(),
      emailId: this.authenticationService.getUserEmail()
    };
    let rareUiRequest = {
      metadata: null,
      data: null
    };
    rareUiRequest.metadata = metadata;
    rareUiRequest.data = obj;
    return rareUiRequest;
  }

  generateID(idType: string): string {
    var length = !idType ? 18 : 16;
    return idType + Math.floor(Math.pow(10, length - 1) + Math.random() * (Math.pow(10, length) - Math.pow(10, length - 1) - 1));
  }

  setCacheInfoHeaders() {
    return new HttpHeaders()
      .set('userid', this.authenticationService.getUserID())
      .set('username', this.authenticationService.getUserName())
      .set('meta-transid', this.generateID('AC'))
      .set('emailId', this.authenticationService.getUserEmail())
      .set('role', this.authenticationService.getUserRole());
  }

  hasSgRole() {
    let hasSgRole = false;
    if (this.authenticationService.getUserRole()) {
      this.authenticationService
        .getUserRole()
        .split(',')
        .forEach((element) => {
          if (!hasSgRole && CommonConstants.opportunityRoles[1] === element) {
            hasSgRole = true;
          }
        });
    }
    return hasSgRole;
  }

  hasLgRole() {
    let hasLgRole = false;
    if (this.authenticationService.getUserRole()) {
      this.authenticationService
        .getUserRole()
        .split(',')
        .forEach((element) => {
          if (!hasLgRole && CommonConstants.opportunityRoles[2] === element) {
            hasLgRole = true;
          }
        });
    }
    return hasLgRole;
  }

  hasFlatRateRole() {
    if (String(this.assignedUserGroup).indexOf('RARE_APPLY_FLAT_INCREASE') !== -1) {
      return true;
    } else {
      return false;
    }
  }

  deepCopy(data: any) {
    if (data !== null && data !== undefined) {
      return JSON.parse(JSON.stringify(data));
    }
  }

  hasRenewalRestoreRole() {
    if (String(this.assignedUserGroup).indexOf('RARE_RENEWAL_GRP_UNLNK') !== -1) {
      return true;
    } else {
      return false;
    }
  }

  setRateInfoHeaders() {
    let headers = this.setHeadersInfo();
    if (this.opportunityId && this.quoteHeaderId) {
      headers = this.setHeadersInfo().set('opportunityID', this.getopportunityId()).set('quoteHeaderID', this.getquoteHeaderId());
    }
    return headers;
  }

  setBatchHeaders(batchID) {
    return new HttpHeaders()
      .set('batchID', batchID)
      .set('meta-senderapp', 'RARE-UI')
      .set('userid', CommonUtil.getUserIDHeader(this.authenticationService))
      .set('username', CommonUtil.getUserNameHeader(this.authenticationService))
  }

  setMedicalCacheRefreshUrl(medicalCacheRefreshUrl: string) {
    this.medicalCacheRefreshUrl = medicalCacheRefreshUrl;
  }
  setFactorManagerExternalUrl(factorManagerExternalUrl: string) {
    this.factorManagerExternalUrl = factorManagerExternalUrl;
  }

  getFactorManagerExternalUrl(): string {
    return this.factorManagerExternalUrl;
  }
  getMedicalCacheRefreshUrl(): string {
    return this.medicalCacheRefreshUrl;
  }

  setVisionCacheRefreshUrl(visionCacheRefreshUrl: string) {
    this.visionCacheRefreshUrl = visionCacheRefreshUrl;
  }

  getVisionCacheRefreshUrll(): string {
    return this.visionCacheRefreshUrl;
  }

  setDentalCacheRefreshUrl(dentalCacheRefreshUrl: string) {
    this.dentalCacheRefreshUrl = dentalCacheRefreshUrl;
  }

  getDentalCacheRefreshUrl(): string {
    return this.dentalCacheRefreshUrl;
  }

  setShowServiceIDLoginPage(serviceIDLogin: boolean) {
    this.showServiceIDLoginPage = serviceIDLogin;
  }

  getShowServiceIDLoginPage(): boolean {
    return this.showServiceIDLoginPage;
  }

  setInsertedTimestamp(insertedTimestamp: any) {
    this.insertedTimestamp = insertedTimestamp;
  }

  getInsertedTimestamp() {
    return this.insertedTimestamp;
  }

  setSupportingDocLinksKeywords(supportingDocLinksKeywords: any) {
    this.supportingDocLinksKeywords = supportingDocLinksKeywords;
  }

  getSupportingDocLinksKeywords() {
    return this.supportingDocLinksKeywords;
  }

  redirectServiceIDLoginPage() {
    this.router.navigate(['/login-with-serviceid']);
  }

  getTables(lob: any) {
    let headers = this.setRequestHeaders();
    return this.http.get<any>(this.rareUIUrl + this.tablesUrl + '?lob=' + lob, { headers: headers });
  }
  getRemoveTables(lob: any, state: any, map: Map<string, string>) {
    let headers = this.setRequestHeaders();
    let conMap = {};
    map.forEach((val: string, key: string) => {
      conMap[key] = val;
    });
    let obj = {
      tableMap: conMap,
      lob: lob,
      stateCode: state
    };
    let rareUiRequest = this.getRareUiRequest(obj);
    return this.http.post<any>(this.rareUIUrl + '/ui/manager/tables/getExistingVersionsFromView', rareUiRequest, { headers: headers });
  }
  submitRemoveTables(lob: any, removeObj: any) {
    let headers = this.setRequestHeaders();
    let rareUiRequest = this.getRareUiRequest(removeObj);
    return this.http.post<any>(this.rareUIUrl + '/ui/manager/tables/deleteversions' + '?lob=' + lob, rareUiRequest, { headers: headers });
  }
  submitImportFactorTables(lob: any, tableNames: any, file: File, imageFile?: File[]) {
    let formData: FormData = new FormData();
    let rareUiRequest: any = this.getRareUiRequest(tableNames);
    formData.append('file', file);
    if (imageFile != undefined) {
      for (let i = 0; i < imageFile.length; i++) {
        formData.append('images', imageFile[i]);
      }
    }
    formData.append('request', JSON.stringify(rareUiRequest));
    let headers = this.setRequestHeaders();
    return this.http.post<any>(this.rareUIUrl + '/ui/manager/tables' + '/' + lob + '/load', formData, { headers: headers, observe: 'response' });
  }

  downloadData(lob: any, tableNames: any, appEnvironment: any): Observable<any> {
    let userID = this.authenticationService.getUserID();
    var dateTimeForExportFileName = this.dateFormatPipe.transform(new Date(), 'ddMMMyyyy_hhmmssa');
    var exportFilename = userID + '_' + appEnvironment + '_' + lob + '_FACTORS_' + dateTimeForExportFileName + '.xlsx';
    let url = this.rareUIUrl + this.tablesUrl + '/' + lob + '/export';
    let headers = new HttpHeaders()
      .set('Access-Control-Allow-Origin', '*')
      .set('Content-Type', 'application/json')
      .set('Access-Control-Expose-Headers', 'TestHeaderToExpose')
      .set('meta-transid', 'abc')
      .set('userid', this.authenticationService.getUserID())
      .set('username', this.authenticationService.getUserName())
      .set('User', userID);
    CommonService.exportFilename = exportFilename;
    const body = tableNames;
    let rareUiRequest = this.getRareUiRequest(body);
    return this.http.post<any>(url, rareUiRequest, { headers: headers, observe: 'response' });
  }

  getPreferenceInfo(type: any) {
    let headers = this.setRateInfoHeaders();
    return this.http.get<any>(this.rareUIUrl + '/preferences?type=' + type, { headers: headers });
  }
  postPreferenceInfo(data: any) {
    let headers = this.setRateInfoHeaders();
    let raeUiRequest = this.getRareUiRequest(data);
    return this.http.post<any>(this.rareUIUrl + '/preferences', raeUiRequest, { headers: headers });
  }

  updatePreferenceInfo(data: any) {
    let headers = this.setRateInfoHeaders();
    let raeUiRequest = this.getRareUiRequest(data);
    return this.http.put<any>(this.rareUIUrl + '/preferences', raeUiRequest, { headers: headers });
  }

  deletePreferenceInfo(id: any) {
    let headers = this.setRateInfoHeaders();
    return this.http.delete<any>(this.rareUIUrl + '/preferences/' + id, { headers: headers });
  }

  listenForStream(processId) {
    return new EventSource(this.rareUIUrl + '/track/' + processId);
  }

  listenForStreamTrackAndFail(processId) {
    return new EventSource(this.rareUIUrl + '/trackAndFail/' + processId);
  }

  getQuotedLegalEntityList() {
    let headers = this.setRequestHeaders();
    return this.http.get<any>(this.rareUIUrl + '/ui/manager/legal-entities', { headers: headers }).subscribe(
      (response) => {
        this.storage.set('quotedLegalEntityList', response);
      },
      (err) => {
        alert('Error in getting response from getQuotedLegalEntityList API....' + err);
      }
    );
  }

  setAdjHeaders(metaTransID: string, ratingTransID: string) {
    let headers = this.setHeaders(metaTransID, ratingTransID);
    if (this.opportunityId && this.quoteHeaderId) {
      headers = headers.set('opportunityID', this.getopportunityId()).set('quoteHeaderID', this.getquoteHeaderId());
    }
    return headers;
  }

  getTransIDforTab(lob, FT) {
    let data = lob + '-' + FT;
    return this.quoteTabList.find((x) => x.tabName === data).ratingTransID;
  }

  getQuoteOriginforTab(lob, FT) {
    let data = lob + '-' + FT;
    return this.quoteTabList.find((x) => x.tabName === data).quoteOrigin;
  }

  getCurrentTab(ratingTransID, lob) {
    let tabQuote = this.quoteTabList.find((x) => x.ratingTransID === ratingTransID && x.tabName.includes(lob));
    return tabQuote ? tabQuote['tabName'] : '';
  }

  getFundingTypeforTab(lob, FT) {
    let data = lob + '-' + FT;
    return this.quoteTabList.find((x) => x.tabName === data).fundingType;
  }

  getStatusforTab(selectedTabName) {
    if (this.quoteTabList && this.quoteTabList.length && this.quoteTabList.find((x) => x.tabName === selectedTabName)) {
      return this.quoteTabList.find((x) => x.tabName === selectedTabName).tabStatus;
    }
  }

  getExportFilename() {
    return CommonService.exportFilename;
  }
  setAvailableTables(tables) {
    CommonService.availableTableList = tables;
  }
  getAvailableTables() {
    return CommonService.availableTableList;
  }

  //setters and getters for loblist
  setLobList(lobListDetails) {
    const orderedLobList = lobListDetails;
    const customOrderList = ['Medical', 'Vision', 'Dental', 'Supp Health', 'System'];
    if (orderedLobList) {
      this.lobList = orderedLobList.sort((a, b) => customOrderList.indexOf(a.label) - customOrderList.indexOf(b.label));
    }
  }
  getLobList() {
    return this.lobList;
  }

  setStateList(stateListDetails) {
    this.stateList = stateListDetails;
  }
  getStateList() {
    return this.stateList;
  }
  setMapOfRoleAndTableNames(mapDetails) {
    this.mapOfRoleAndTableNames = mapDetails;
  }
  getMapOfRoleAndTableNames() {
    return this.mapOfRoleAndTableNames;
  }
  setFullTablesList(tablesList) {
    this.fullTablesList = tablesList;
  }
  getFullTablesList() {
    return this.fullTablesList;
  }
  setQuoteTabList(tabList) {
    this.quoteTabList = tabList;
  }
  getQuoteTabList() {
    return this.quoteTabList;
  }
  setFactorManagerMainUrl(url) {
    this.factorManagerMainUrl = url;
  }
  setProductLevelAdjustments(enabled: string) {
    this.productAdjustmentsEnabled = enabled === 'true' ? true : false;
  }
  setCalculatorPremiumMedicalUrl(url) {
    this.calculatorPremiumMedicalUrl = url;
  }
  setReQuoteUrl(url) {
    this.reQuoteUrl = url;
  }
  setCalculatorSoldRatesUrl(url) {
    this.calculatorSoldRatesUrl = url;
  }
  setDentalBaseUrl(url) {
    this.dentalBaseUrl = url;
  }
  setVisionBaseUrl(url) {
    this.visionBaseUrl = url;
  }
  setToggleVision(val) {
    this.isVisionEnabled = val;
  }
  setRenewals(val) {
    this.isRenewalEnabled = val;
  }
  setTablesUrl(url) {
    this.tablesUrl = url;
  }
  setPrintEngineUrl(url) {
    this.printEngineUrl = url;
  }
  setAnalyticsBaseUrl(url) {
    this.analyticsBaseUrl = url;
  }
  enableAutoSubmitFlag(flag) {
    this.autoSubmitBDFlag = flag;
  }
  isAutoSubmitFlagEnabled() {
    return this.autoSubmitBDFlag;
  }
  setRareUINginxUrl(url) {
    this.rareUINginxUrl = url;
  }
  setToggleSmallGroupIntake(val) {
    this.isSmallGroupIntakeEnabled = val === 'true' || val === true;
  }
  setProgressBarTimeOut(timeOut) {
    CommonService.progressBarTimeOut = timeOut;
  }

  getProgressBarTimeOut() {
    return CommonService.progressBarTimeOut;
  }

  removeHistoryLocalStorage() {
    localStorage.removeItem('quoteHeaderID');
    localStorage.removeItem('opportunityID');
    localStorage.removeItem('ratingTransID');
    localStorage.removeItem('lob');
    localStorage.removeItem('fundingType');
    localStorage.removeItem('marketSegment');
    localStorage.removeItem('availableTabs');
    localStorage.removeItem('isLoginAgain');
    localStorage.removeItem('disableAll');
    localStorage.removeItem('isEnableQuoteHistory');
    localStorage.removeItem('insertedTimestamp');
    localStorage.removeItem('quoteHistoryId');
    localStorage.removeItem('version');
    localStorage.removeItem('assignedUserRoles');
    localStorage.removeItem('assignedUserRolesTextToDisplay');
    localStorage.removeItem('assignedUserLobs');
    localStorage.removeItem('assignedUserStates');
    localStorage.removeItem('sendToOpp');
  }
  hasSessionLoginAgain() {
    return this.storage.get('isLoginAgain');
  }
  setUserRoles(userRoleList) {
    this.readonlyRoleList = userRoleList;
  }
  getUserRoles() {
    return this.readonlyRoleList;
  }
  setAssignedUserGroup(assignedUserGroup) {
    this.assignedUserGroup = assignedUserGroup;
  }
  getAssignedUserGroup() {
    return this.assignedUserGroup;
  }
  getHealthCheckInfo() {
    return this.http.get(this.rareUIUrl + '/healthcheckinfo');
  }

  getFileNetInHealthCheckInfo() {
    return this.http.get(this.rareUIUrl + '/ui/fileNet/healthCheckInfo');
  }

  getFileNetStreamingHealthCheckInfo() {
    return this.http.get(this.rareUIUrl + '/ui/fileNetStreaming/healthCheckInfo');
  }

  hasReadOnlyRole() {
    let hasReadOnlyRole = false;
    if (this.authenticationService.getUserRole()) {
      this.authenticationService
        .getUserRole()
        .split(',')
        .forEach((element) => {
          if (!hasReadOnlyRole && 'READONLY' === element) {
            hasReadOnlyRole = true;
          }
        });
    }
    return hasReadOnlyRole;
  }

  getFiles(path) {
    return this.http.get(this.rareUIUrl + '/file/browse?path=' + path);
  }
  getDownloadAllAsZip(folderName) {
    return this.http.get(this.rareUINginxUrl + '/file/downloadZip?path=' + folderName, { responseType: 'blob' });
  }
  downloadSelectedFiles(currentPath, arr) {
    let obj = {
      currentPath: currentPath,
      files: arr
    };
    return this.http.post(this.rareUINginxUrl + '/file/downloadZip', obj, { responseType: 'blob' });
  }
  folderDownload(folderName: string) {
    return this.http.get(this.rareUINginxUrl + '/file/downloadZip?path=' + folderName, { responseType: 'blob' });
  }
  fileDownload(folderName, fileName) {
    return this.http.get(this.rareUINginxUrl + '/file/download?path=' + folderName + '&file-name=' + fileName, { responseType: 'blob' });
  }
  formatDateForGraph(date: Date) {
    return date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
  }

  logUserOpeningQuoteEvent(
    ratingTransID: String,
    oppID: String,
    quoteHeaderID: String,
    lob: String,
    fundingType: String,
    marketSegment: string,
    quoteOrigin: String,
    userOnScreen: String
  ) {
    let headers = this.setRateInfoHeaders();
    this.http
      .get(
        this.rareUIUrl +
          '/logevent/user-opening-quote?opportunityID=' +
          oppID +
          '&rating-transid=' +
          ratingTransID +
          '&quoteHeaderID=' +
          quoteHeaderID +
          '&fundingType=' +
          fundingType +
          '&lob=' +
          lob +
          '&marketSegment=' +
          marketSegment +
          '&userOnScreen=' +
          userOnScreen +
          '&quoteOrigin=' +
          quoteOrigin,
        { responseType: 'text', headers: headers }
      )
      .subscribe(
        (response) => {
          console.log('response from log User Opening Quote Event: ', response);
        },
        (error) => {
          console.error('Error occurred While user opeing quote in search: ', error);
        }
      );
  }

  isMedicalMEWA(quoteDetailsObj: any) {
    return (quoteDetailsObj && quoteDetailsObj.quotingType && quoteDetailsObj.quotingType == CommonConstants.MEWA);
  }

  isMedicalAca(quoteDetailsObj: any) {
    return (
      quoteDetailsObj &&
      quoteDetailsObj.opportunityType &&
      ((quoteDetailsObj.productsQuoted && quoteDetailsObj.productsQuoted.length == 0) || quoteDetailsObj.productsQuoted == undefined) &&
      quoteDetailsObj.quotingType &&
      quoteDetailsObj.quotingType == 'ACA'
    );
  }
  isVisionAca(quoteDetailsObj: any) {
    return quoteDetailsObj && quoteDetailsObj.opportunityType && quoteDetailsObj.quotingType && quoteDetailsObj.quotingType == 'ACA';
  }
  setFactorMigationEnabled(flag) {
    this.factorMigrationEnabled = flag;
  }
  getFactorMigationEnabled() {
    return this.factorMigrationEnabled;
  }
  setExperienceExtractionEnabled(flag) {
    this.experienceExtractionEnabled = flag;
  }
  getExperienceExtractionEnabled() {
    return this.experienceExtractionEnabled;
  }
  setFactorImportEnabled(flag) {
    this.factorImportEnabled = flag;
  }
  getFactorImportEnabled() {
    return this.factorImportEnabled;
  }
  setFactorExportEnabled(flag) {
    this.factorExportEnabled = flag;
  }
  getFactorExportEnabled() {
    return this.factorExportEnabled;
  }
  setFiRenewalEnabled(flag) {
    this.fiRenewalEnabled = flag;
  }
  getFiRenewalEnabled() {
    return this.fiRenewalEnabled;
  }

  setFactorMigrationImportFileSize(size) {
    this.factorMigrationImportFileSize = size;
  }
  getFactorMigrationImportFileSize() {
    return this.factorMigrationImportFileSize;
  }
  generateToken(body) {
    let headers = this.setRequestHeaders();
    let HTTPOptions: Object = {
      headers: headers,
      responseType: 'text'
    };
    return this.http.post<any>(this.getRareUiUrl() + '/create/token', body, HTTPOptions);
  }

  getFactorTables(system: string) {
    let headers = this.setRequestHeaders();
    return this.http.get(this.rareUIUrl + '/factor/tables?system=' + system, { headers: headers });
  }

  getFactorTableMetadata(tables, system: string) {
    let headers = this.setRequestHeaders();
    return this.http.get(this.rareUIUrl + '/factor/metadata?tables=' + tables + '&system=' + system, { headers: headers });
  }

  getFactorSystems() {
    let headers = this.setRequestHeaders();
    return this.http.get(this.rareUIUrl + '/factor/systems', { headers: headers });
  }

  getTargetDatabases(system: string, migrationReason?: string) {
    let headers = this.setRequestHeaders();
    return this.http.get(this.rareUIUrl + '/factor/databases?system=' + system + '&migrationReason=' + migrationReason, { headers: headers });
  }

  cleanUpSSEEvents(processId) {
    let headers = this.setRequestHeaders();
    this.http.get<any>(this.getRareUiUrl() + '/clear/sse-events?processId=' + processId, { headers: headers, responseType: 'text' as 'json' }).subscribe(
      (response) => {
        console.log(processId + ' = ' + response);
      },
      (error) => {
        console.error(error);
      }
    );
  }

  getNationalMbu() {
    let reqHeaders = this.setRequestHeaders();
    return this.http.get<any>(this.rareUIUrl + '/ui/renewal/national-mbus', { headers: reqHeaders });
  }

  getAssociationList() {
    let reqHeaders = this.setRequestHeaders();
    return this.http.get<any>(this.rareUIUrl + '/ui/manager/associations', { headers: reqHeaders });
  }

  setSoldRestructureTabEnabled(flag) {
    this.soldRestructureTabEnabled = flag;
  }

  getSoldRestructureTabEnabled() {
    return this.soldRestructureTabEnabled;
  }

  setNewCreateOpportunityFlow(flag: boolean) {
    this.newCreateOpportunityFlow = flag;
  }


  setBatchOppQuoteSubmitThreshold(value: any) {
    this.batchOppQuoteSubmitThreshold = value;
  }

  getBatchOppQuoteSubmitThreshold(): any {
    return this.batchOppQuoteSubmitThreshold;
  }

  getNewCreateOpportunityFlow() {
    return this.newCreateOpportunityFlow;
  }

  setManagementReportFlag(flag: boolean) {
    this.managementReportEnable = flag;
  }

  getManagementReportFlag() {
    return this.managementReportEnable;
  }

  setMedSGAcaRareRouteEnabled(flag: boolean) {
    this.medSGAcaRareRouteEnabled = flag;
  }

  getMedSGAcaRareRouteEnabled() {
    return this.medSGAcaRareRouteEnabled;
  }

  setCurrentEnvironment(environment: string) {
    this.currentEnvironment = environment;
  }

  getCurrentEnvironment() {
    return this.currentEnvironment;
  }

  setAutoRunBatchEnabledToggle(autoRunBatchEnabled: boolean) {
    this.isAutoRunBatchEnabled = autoRunBatchEnabled;
  }

  getAutoRunBatchEnabledToggle() {
    return this.isAutoRunBatchEnabled;
  }

  getQuoteOrigin(data: any) {
    if (data.opportunityId) {
      if (!data.quoteOrigin) {
        this.route.queryParams.subscribe((params) => {
          return params[CommonConstants.QUOTE_ORIGIN];
        });
      } else {
        return data.quoteOrigin;
      }
    }
  }


  getOktaAuthEnabled(): boolean {
    return this._oktaAuthEnabled;
  }

  setOktaAuthEnabled(value: boolean) {
    this._oktaAuthEnabled = value;
  }

  getEnableSendToOppMap(): object {
    return this.enabledSendToOppMap;
  }

  setEnableSendToOppMap(value) {
    this.enabledSendToOppMap = value;
  }

  setTieringConfig(value) {
    this.tieringConfig = value;
  }

  getTieringConfig(): object {
    return this.tieringConfig;
  }

  setArrowCallRestrictionMap(value) {
    this.arrowCallRestrictionMap = value;
  }
  getArrowCallRestrictionMap(): object {
    return this.arrowCallRestrictionMap;
  }

  setCrossSellingRestrictionMap(value) {
    this.crossSellingRestrictionMap = value;
  }

  setCrossSellingEnabled(value) {
    this.isCrossSellingEnabled = value;
  }

  setTieringEnabled(value) {
    this.isTieringEnabled = value;
  }

  getCrossSellingEnabled(): boolean {
    return this.isCrossSellingEnabled;
  }

  getTieringEnabled(): boolean {
    return this.isTieringEnabled;
  }

  getCrossSellingRestrictionMap(): object {
    return this.crossSellingRestrictionMap;
  }

  setAutoRunACAQuoteActionsEnabled(value: boolean) {
    this.enableAutorunACAQuoteActions = value;
  }

  getAutoRunACAQuoteActionsEnabled(): boolean {
    return this.enableAutorunACAQuoteActions;
  }

  setShowViewCalc(value) {
    this.showViewCalc = value;
  }

  getShowViewCalc(): boolean {
    return this.showViewCalc;
  }

  setExhibitOverrideDental(value: any[]) {
    this.exhibitDental = value;
  }

  getExhibitOverrideDental(): any[] {
    return this.exhibitDental;
  }

  setExhibitOverrideVision(value: any[]) {
    this.exhibitVision = value;
  }

  getExhibitOverrideVision(): any[] {
    return this.exhibitVision;
  }

  setIsSearchAnywhereForQuoteSearchEnabled(value) {
    this.isSearchAnywhereForQuoteSearchEnabled = value;
  }

  getIsSearchAnywhereForQuoteSearchEnabled(): boolean {
    return this.isSearchAnywhereForQuoteSearchEnabled;
  }

  getSafeOppAndQuoteHeaderID(): Observable<any> {
    return this.http.get<any>(this.getRareUiUrl() + '/generate-ids')
  }

  setEnabledBatchGroupDownload(value) {
    this.enabledBatchGroupDownload = value;
  }

  getEnabledBatchGroupDownload(): boolean {
    return this.enabledBatchGroupDownload;
  }

  setMewaPortfolioEnabled(value) {
    this.mewaPortfolioEnabled = value;
  }

  getMewaPortfolioEnabled(): boolean {
    return this.mewaPortfolioEnabled;
  }

  setQuoteOptionStatesMap(value) {
    this.quoteOptionStatesMap = value;
  }

  getQuoteOptionStatesMap() {
    return this.quoteOptionStatesMap;
  }

  setMedicareStateMarkerMap(value) {
    this.medicareStateMarkerMap = value;
  }
  getMedicareStateMarkerMap(): object {
    return this.medicareStateMarkerMap;
  }

  setRareSpecialitySendToOppEnabled(value) {
    this.rareSpecialitySendToOppEnabled = value;
  }

  getRareSpecialitySendToOppEnabled() {
    return this.rareSpecialitySendToOppEnabled;
  }
  setExpiryDateForStaticApi(expiryDate:number){
    this.expiryDateForStaticApi = expiryDate;
  }
   getExpiryDateForStaticApi(){
    return this.expiryDateForStaticApi;
  }

  setSpecialtyLobsEnabledForBatchSubmission(value) {
    this.specialtyLobsEnabledForBatchSubmission = value;
  }

  getSpecialtyLobsEnabledForBatchSubmission() {
    return this.specialtyLobsEnabledForBatchSubmission;
  }

  setOktaInterceptUrls(urls: string[]) {
    this.oktaInterceptUrls = urls;
  }
  getOktaInterceptUrls(): string[] {
    return this.oktaInterceptUrls;
  }

  setRareEnableBulkImport(value) {
    this.rareEnableBulkImport = value;
  }

  getRareEnableBulkImport() {
    return this.rareEnableBulkImport;
  }
  setCreateOppMEWAEnabled(value) {
    this.createOppMEWAEnabled = value;
  }
  getCreateOppMEWAEnabled() {
    return this.createOppMEWAEnabled;
  }
  setenabledBulkAdjVisDen(value: boolean) {
    this.bulkAdjForVisDenEnabled = value;
  }

  getenabledBulkAdjVisDen() {
    return this.bulkAdjForVisDenEnabled;
  }

  setenabledExhibitOverrideDental(value: boolean) {
    this.exhibitDentalEnabled = value;
  }

  getenabledExhibitOverrideDental() {
    return this.exhibitDentalEnabled;
  }

  setenabledExhibitOverrideVision(value: boolean) {
    this.exhibitVisionEnabled = value;
  }

  getenabledExhibitOverrideVision() {
    return this.exhibitVisionEnabled;
  }

  setDisableVisionDentalLgBatchSubmit(value: boolean) {
    this.disableVisionDentalLgBatchSubmit = value;
  }
  getDisableVisionDentalLgBatchSubmit() {
    return this.disableVisionDentalLgBatchSubmit;
  }

  setBulkUploadImportConfig(value) {
    this.bulkUploadImportConfig = value;
  }

  getBulkUploadImportConfig(): object {
    return this.bulkUploadImportConfig;
  }

  getDatasourcesForBatchScreenSearchOverlay(): any[] {
    return this.datasourcesForBatchScreenSearchOverlay;
  }
  setDatasourcesForBatchScreenSearchOverlay(value: any[]) {
    this.datasourcesForBatchScreenSearchOverlay = value;
  }

  getRenewalSoldAsIsEnabled() {
    return this.renewalASIsSoldEnabled;
  }
  setRenewalSoldAsIsEnabled(value: boolean) {
    this.renewalASIsSoldEnabled = value;
  }

  setMEWAOriginalQuoteEnabled(value) {
    this.mewaOriginalQuoteEnabled = value;
  }

  getMEWAOriginalQuoteEnabled() {
    return this.mewaOriginalQuoteEnabled;
  }


  setCustomSparkWidgetUrl(url: string): void {
    this.customSparkWidgetUrl = url;
  }

  getCustomSparkWidgetUrl(): string {
    return this.customSparkWidgetUrl;
  }

  setEnabledTieringVisionLGBatch(isEnabled: boolean): void {
    this.enabledTieringVisionLGBatch = isEnabled;
  }

  getEnabledTieringVisionLGBatch(): boolean {
    return this.enabledTieringVisionLGBatch;
  }

  setEnabledTieringDentalLGBatch(isEnabled: boolean): void {
    this.enabledTieringDentalLGBatch = isEnabled;
  }

  getEnabledTieringDentalLGBatch(): boolean {
    return this.enabledTieringDentalLGBatch;
  }

  //URL Sanitize method

  sanitizeUrl(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }


  getOppSpecialityPlanUpdateConfig() {
    return this.oppSpecialityPlanUpdateConfig;
  }
  setOppSpecialityPlanUpdateConfig(value: any) {
    this.oppSpecialityPlanUpdateConfig = value;
  }

  setMEWAOriginalQuoteReleaseEnabled(value :boolean) {
    this.mewaOriginalQuoteReleaseEnabled = value;
  }

  getMEWAOriginalQuoteReleaseEnabled(): boolean {
    return this.mewaOriginalQuoteReleaseEnabled;
  }

  setCustomTierRatioTypeRateActionFixEnabled(value :boolean) {
    this.customTierRatioTypeRateActionFixEnabled = value;
  }

  getCustomTierRatioTypeRateActionFixEnabled(): boolean {
    return this.customTierRatioTypeRateActionFixEnabled;
  }

  setDentalBaseContractCodeFlowEnabled(value :boolean) {
    this.dentalBaseContractCodeFlowEnabled = value;
  }

  getDentalBaseContractCodeFlowEnabled(): boolean {
    return this.dentalBaseContractCodeFlowEnabled;
  }

  setLossRationVisionViewOnBulkScreenEnabled(value :boolean) {
    this.lossRationVisionViewOnBulkScreenEnabled = value;
  }

  getLossRationVisionViewOnBulkScreenEnabled(): boolean {
    return this.lossRationVisionViewOnBulkScreenEnabled;
  }

  setSecurityAuthMode(securityAuthMode: string) {
    this.securityAuthMode = securityAuthMode;
  }

  getSecurityAuthMode(): string {
    return this.securityAuthMode;
  }

   setDefaultABFcommission(commissionMap: any) {
    if (!commissionMap) {
      return;
    }
    this.abfDefaultCommissionValue = commissionMap.value;
    this.abfDefaultCommissionType = commissionMap.type;
  }

  getDefaultCommissionValue(): string {
    return this.abfDefaultCommissionValue;
  }

  getDefaultCommissionType(): string {
    return this.abfDefaultCommissionType;
  }

  setEnabledNBGroupExpSummary(value: boolean) {
    this.enabledNBGroupExpSummary = value;
  }

  getEnabledNBGroupExpSummary(): boolean {
    return this.enabledNBGroupExpSummary;
  }

  setNBCurrentRatesEnabled(isEnabled: boolean) {
    this.isNBCurrentRatesEnabled = isEnabled;
  }

  getNBCurrentRatesEnabled(): boolean { 
    return this.isNBCurrentRatesEnabled;
  }
  
  setNewBusinessUploadEnabledConfig(value: any) {
    this.newBusinessUploadEnabledConfig = value;
  }

  getNewBusinessUploadEnabledConfig(): any {
    return this.newBusinessUploadEnabledConfig;
  }

  setBatchAltQuoteSubmitThreshold(value: any) {
    this.batchAltQuoteSubmitThreshold = value;
  }

  getBatchAltQuoteSubmitThreshold(): any {
    return this.batchAltQuoteSubmitThreshold;
  }

  setSGSpecialtyVisionDentalEnabled(value: any) {
    this.sgSpecialtyVisionDentalEnabled = value === 'true' || value === true;
  }

  getSGSpecialtyVisionDentalEnabled(): boolean {
    return this.sgSpecialtyVisionDentalEnabled;
  }
}
