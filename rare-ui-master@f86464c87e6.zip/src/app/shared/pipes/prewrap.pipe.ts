import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({
  name: 'prewrap',
  standalone: false,
})
export class PrewrapPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}

  transform(value: string): SafeHtml {
    if (!value) return '';
    const styled = `<span style="white-space: pre-wrap; word-break: break-word;">${value}</span>`;
    return this.sanitizer.bypassSecurityTrustHtml(styled);
  }
}