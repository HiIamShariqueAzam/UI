import { PrewrapPipe } from './prewrap.pipe';

describe('PrewrapPipe', () => {
  it('create an instance', () => {
    const pipe = new PrewrapPipe();
    expect(pipe).toBeTruthy();
  });
});
