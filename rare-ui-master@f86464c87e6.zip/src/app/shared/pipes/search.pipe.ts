import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search',
  standalone: false,
})
export class SearchPipe implements PipeTransform {

  transform(searchArry: any[], searchText: string, ...args: unknown[]): unknown {
    console.log(searchArry, searchText, args)
    if (!searchArry || !searchText) {
      return searchArry;
    }
    else {
      return searchArry.filter(x =>
        x[args[0].toString()].toLowerCase().indexOf(searchText.toLowerCase()) !== -1);
    }
  }
}
