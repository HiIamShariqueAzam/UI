﻿import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'dateFormat',
  standalone: false,
})
@Injectable({ providedIn: 'root' })
export class DateFormatPipe extends DatePipe implements PipeTransform {
  transform(value: any, dateFormat: any, args?: any): any {
    return super.transform(value, dateFormat);
  }
}