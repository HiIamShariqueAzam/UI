export class CommonConstants {
  public static OPPORTUNITY_ID = 'opportunityID';
  public static RATINGTRANS_ID = 'ratingTransID';
  public static LOB = 'lob';
  public static FUNDING_TYPE = 'fundingType';
  public static QUOTING_TYPE = 'quotingType';
  public static QUOTEHEADER_ID = 'quoteHeaderID';
  public static QUOTE_ORIGIN = 'quoteOrigin';
  public static SELECTED_SEARCH_ANYWHERE = 'searchAnywhere';
  public static AVAILABLE_TABS = 'availableTabs';
  public static DISABLE_ALL = 'disableAll';
  public static IS_ENABLE_QUOTE_HISTORY = 'isEnableQuoteHistory';
  public static DISABLE_BACK_BTN = 'disableBackBtn';
  public static PLAN_NAME = 'planName';
  public static CONTRACT_CODE = 'contractCode';
  public static DOWNLOAD_REPORT_DATA_STATUS_STARTED = 'DOWNLOAD_REPORT_DATA_STATUS_STARTED';
  public static DOWNLOAD_REPORT_DATA_STATUS_COMPLETE = 'DOWNLOAD_REPORT_DATA_STATUS_COMPLETE';
  public static ERROR = 'error';
  public static FAILED = 'FAILED';
  public static Failed = 'Failed';
  public static FAILED_MESSAGE = 'Failed to fetch progress because of communication failure';
  public static PROGRESS_BAR_DANGER = 'progress-bar-danger';
  public static PROGRESS_BAR_SUCCESSS = 'progress-bar-success';
  public static PROGRESS_BAR_WARNING = 'progress-bar-warning';
  public static XSLX = '.xlsx';
  public static FROM_DATE = 'fromDate';
  public static TO_DATE = 'toDate';
  public static DATE = 'Date';
  public static DATE_FORMAT = 'yyyy-MM-dd';
  public static DATE_FORMAT_MONTH = 'dd-MMM-yy';
  public static DATE_ERROR = 'From Date should not be greater than To Date';
  public static TEST = 'TEST';
  public static EMAIL_ID = 'emailId';
  public static SELECTED_VALUES = 'selectedValues';
  public static CONTRACT_EFFECTIVEDATE_END = 'contract_effective_date_end';
  public static CONTRACT_EFFECTIVEDATE_START = 'contract_effective_date_start';
  public static EMPTY_STRING = '';
  public static EMPTY_RECORD = 'Generated empty workbook';
  public static NO_RESULTS_FOUND = 'No results found.';
  public static NOT_SUBMITTED = 'Not Submitted';
  public static SUBMITTED = 'Submitted';

  public static ADDITIONAL_PROGRAM_ADDED_TO_ADMIN = 'Added to Admin';
  public static ADDITIONAL_PROGRAM_ADDED_TO_TOTAL = 'Added to Total';
  public static ADDITIONAL_PROGRAM_EMBEDDED = 'Rates embedded';

  public static EMPLOYMENT_CATEGORIES_FOR_SELECTED_PLANS_DO_NOT_MATCH =
    'Employment Category of Sold Plans are not same. Add Additional Program by selecting the sold plan manually.';

  public static SOLD_NOTIFICATION_ACCEPTED_MESSAGE =
    'The Latest Sold notification has been accepted. Please resubmit the Plans to SORDS, as previous submission have been invalidated.';

  public static ADDITIONAL_PROGRAM_RATES_NOT_VALID = 'Please enter rates';
  public static CUSTOM_TIER = 'Custom';
  public static CURRENT_TIER = 'Current';
  public static STANDARD_TIER = 'Standard';
  public static FI = 'FI';
  public static ABF = 'ABF';
  public static ASO = 'ASO';
  public static MEWA = 'MEWA';
  public static RENEWAL_LOCAL = 'Renewal Local';
  public static RENEWAL_NATIONAL = 'Renewal National';
  public static NEW_BUSINESS_LOCAL = 'New Business Local';
  public static OTHER = 'Other';
  public static DISCOUNT_SPLITS = 'discountSplits';
  public static NO = 'No';
  public static CURV = 'CURV';
  public static AUTO_RUN_BATCH = 'autoRunBatch';
  public static MEDICAL_LOB = 'Medical';
  public static MEMBER_RATED = 'memberRated';

  public static SIC_CODE = 'sicCode';
  public static GAURD_RAIL_ERROR_MESSAGE_FOR_SIC_CODE_POST_FIX = '- SIC code belongs to Risky industry';
  public static GAURD_RAIL_ERROR_MESSAGE_FOR_NOT_IN_RATE_GUARANTEE = 'Not in Rate Guarantee';
  public static GUARD_RAIL_ERROR_MESSAGE_FOR_NATIONAL_GROUP = 'National Group';
  public static MARKET_SEGMENT = 'marketSegment';
  public static marketSegmentChange = 'Market Segment Changed';
  public static fundingTypeFiToAbfChanged = 'FI to ABF';
  public static fundingTypeMarketSegmentLabel = 'FA TP/Mkt Seg/Opp TP';
  public static GroupExpSummary_LossRatio= 'request.groupExperienceSummary.lossRatio';
  public static Failed_Dental_Rate_Guarantee= 'request.dental.inRateGuarantee';
  public static Failed_Vision_Rate_Guarantee= 'request.vision.inRateGuarantee';

  public static LOSS_RATIO = 'lossRatio';
  public static GAURD_RAIL_ERROR_MESSAGE_FOR_LOSS_RATIO = 'Loss Ratio: '
  public static MARKET_SEGEMENT_LIST = [
    { label: 'Small Group', value: 'SG', disabled: false },
    { label: 'Large Group', value: 'LG', disabled: false }
  ];

  public static MARKET_SEGEMENT_SG_LIST = [{ label: 'Small Group', value: 'SG', disabled: false }];
  public static MARKET_SEGEMENT_LG_LIST = [{ label: 'Large Group', value: 'LG', disabled: false }];
  public static LOB_LIST = [
    { label: 'Medical', value: 'Medical' },
    { label: 'Vision', value: 'Vision' },
    { label: 'Dental', value: 'Dental' },
    { label: 'Supp Health', value: 'Supp Health' }
  ];
  public static FUNDING_TYPE_LIST = [
    { label: 'FI', value: 'FI', disabled: false },
    { label: 'ABF', value: 'ABF', disabled: false },
    { label: 'ASO', value: 'ASO', disabled: false },
    { label: 'MEWA', value: 'MEWA', disabled: false },
    { label: 'ACA', value: 'ACA', disabled: false }
  ];
  public static FUNDING_TYPE_LIST_QUOTE = [
    { label: 'FI', value: 'FI', disabled: false },
    { label: 'ABF', value: 'ABF', disabled: false }
  ];
  public static QUOTING_TYPE_LIST_QUOTE = [
    { label: 'ACA', value: 'ACA', disabled: false },
    { label: 'MEWA', value: 'MEWA', disabled: false }
  ];
  public static FUNDING_TYPE_LIST_SG = [
    { label: 'ABF', value: 'ABF', disabled: false },
    { label: 'MEWA', value: 'MEWA', disabled: false }
  ];
  public static MBS_LIST = [
    { label: 'Key', value: 'Key' },
    { label: 'Non-Key', value: 'Non-Key' }
  ];

  public static MONTHS_LIST = [
    { label: 'January', value: '01' },
    { label: 'February', value: '02' },
    { label: 'March', value: '03' },
    { label: 'April', value: '04' },
    { label: 'May', value: '05' },
    { label: 'June', value: '06' },
    { label: 'July', value: '07' },
    { label: 'August', value: '08' },
    { label: 'September', value: '09' },
    { label: 'October', value: '10' },
    { label: 'November', value: '11' },
    { label: 'December', value: '12' }
  ];

  public static opportunityRoles = ['ADMIN', 'SGSALES', 'LGSALES'];

  public static adminMenu = [
    {
      label: 'Admin',
      value: 'admin',
      isSubMenu: false
    },
    {
      label: 'Opportunities',
      value: 'opportunity',
      isSubMenu: false
    },
    {
      label: 'Quotes',
      value: 'quote',
      isSubMenu: false
    },
    {
      label: 'Factor Maintenance',
      isSubMenu: true,
      subMenu: 'Import',
      subValue: 'import-factors',
      subMenu1: 'Export',
      subValue1: 'export-factors',
      subMenu2: 'Remove',
      subValue2: 'remove-factors',
      subMenu3: 'Cache Refresh',
      subValue3: 'cache-refresh'
    },
    {
      label: 'Reports',
      isSubMenu: true,
      subMenu: 'Management Report',
      subValue: 'generate-report'
    },
    {
      label: 'Health Check',
      value: 'healthcheck',
      isSubMenu: false
    },
    {
      label: 'Files',
      value: 'files',
      isSubMenu: false
    },
    {
      label: 'Analytics Reports',
      isSubMenu: true,
      subMenu: 'Load data',
      subValue: 'analytics-reports/load-data',
      subMenu1: 'Charts',
      subValue1: 'analytics-reports',
      subMenu2: 'Sold Report',
      subValue2: 'analytics-reports/sold-report',
      subMenu3: 'Reports',
      subValue3: 'analytics-reports/dynamic-report'
    },
    {
      label: 'Experience Extraction',
      value: 'experience-extraction',
      isSubMenu: false
    },
    {
      label: 'Token',
      value: 'token',
      isSubMenu: false
    }
  ];
  public static tokenMenu = [
    {
      label: 'Admin',
      value: 'admin',
      isSubMenu: false
    },
    {
      label: 'Opportunities',
      value: 'opportunity',
      isSubMenu: false
    },
    {
      label: 'Quotes',
      value: 'quote',
      isSubMenu: false
    },
    {
      label: 'Factor Maintenance',
      isSubMenu: true,
      subMenu: 'Import',
      subValue: 'import-factors',
      subMenu1: 'Export',
      subValue1: 'export-factors',
      subMenu2: 'Remove',
      subValue2: 'remove-factors',
      subMenu3: 'Cache Refresh',
      subValue3: 'cache-refresh'
    },
    {
      label: 'Reports',
      isSubMenu: true,
      subMenu: 'Management Report',
      subValue: 'generate-report'
    },
    {
      label: 'Health Check',
      value: 'healthcheck',
      isSubMenu: false
    },
    {
      label: 'Files',
      value: 'files',
      isSubMenu: false
    },
    {
      label: 'Analytics Reports',
      isSubMenu: true,
      subMenu: 'Load data',
      subValue: 'analytics-reports/load-data',
      subMenu1: 'Charts',
      subValue1: 'analytics-reports',
      subMenu2: 'Sold Report',
      subValue2: 'analytics-reports/sold-report',
      subMenu3: 'Reports',
      subValue3: 'analytics-reports/dynamic-report'
    },
    {
      label: 'Token',
      value: 'token',
      isSubMenu: false
    }
  ];
  public static adminMenuIntakeEnabled = [
     {
      label: 'Renewals',
      value: 'renewals',
      isSubMenu: true,
      subMenu: 'Batch',
      subValue: 'group/batch'
    }
  ];

  public static underwriterMenu = [
    {
      label: 'Quotes',
      value: 'quote',
      isSubMenu: false
    },
    {
      label: 'Factor Maintenance',
      isSubMenu: true,
      subMenu: 'Export',
      subValue: 'export-factors'
    }
  ];

  public static renewalBatchMenu = [
    {
      label: 'Renewals',
      value: 'renewals',
      isSubMenu: true,
      subMenu: 'Batch',
      subValue: 'group/batch'
    }
  ];

  public static renewalGroupMenu = [
    {
      label: 'Renewals',
      value: 'renewals',
      isSubMenu: true,
      subMenu: 'Group',
      subValue: 'group'
    }
  ];

  public static underwriterMenuIntakeEnabled = [
    {
      label: 'Opportunities',
      value: 'opportunity',
      isSubMenu: false
    },
    {
      label: 'Quotes',
      value: 'quote',
      isSubMenu: false
    }
  ];

  public static actuarialMenu = [
    {
      label: 'Factor Maintenance',
      isSubMenu: true,
      subMenu: 'Data Migration',
      subValue: 'factor-migration'
    }
  ];

  public static actuarialMenuIntakeEnabled = [
    {
      label: 'Opportunities',
      value: 'opportunity',
      isSubMenu: false
    },
    {
      label: 'Factor Maintenance',
      isSubMenu: true,
      subMenu: 'Data Migration',
      subValue: 'factor-migration'
    }
  ];

  public static reportMenu = [
    {
      label: 'Reports',
      isSubMenu: true,
      subMenu: 'Management Report',
      subValue: 'generate-report'
    }
  ];

  public static reportMenuIntakeEnabled = [
    {
      label: 'Opportunities',
      value: 'opportunity',
      isSubMenu: false
    },
    {
      label: 'Reports',
      isSubMenu: true,
      subMenu: 'Management Report',
      subValue: 'generate-report'
    }
  ];
  public static oppMenuForManagementRole = [
    {
      label: 'Opportunities',
      value: 'opportunity',
      isSubMenu: false
    }
  ];

  public static salesMenu = [
    {
      label: 'Opportunities',
      value: 'opportunity',
      isSubMenu: false
    }
  ];

  public static allAvailableStateList = [
    { label: 'CA', value: 'CA' },
    { label: 'CO', value: 'CO' },
    { label: 'CT', value: 'CT' },
    { label: 'GA', value: 'GA' },
    { label: 'IN', value: 'IN' },
    { label: 'KY', value: 'KY' },
    { label: 'ME', value: 'ME' },
    { label: 'MO', value: 'MO' },
    { label: 'NH', value: 'NH' },
    { label: 'NV', value: 'NV' },
    { label: 'NY', value: 'NY' },
    { label: 'OH', value: 'OH' },
    { label: 'VA', value: 'VA' },
    { label: 'WI', value: 'WI' }
  ];

  public static inputTier = [{ inputTierName: '1' }, { inputTierName: '2' }, { inputTierName: '3' }, { inputTierName: '4' }, { inputTierName: '5' }];

  public static outputTier = [{ outputTierName: '1' }, { outputTierName: '2' }, { outputTierName: '3' }, { outputTierName: '4' }, { outputTierName: '5' }];

  public static abfCommission = [
    { abfCommissionType: 'PCPM' },
    { abfCommissionType: 'Percent' },
    { abfCommissionType: 'PMPM' },
    { abfCommissionType: 'Flat Dollar' }
  ];

  public static fiCommission = [
    { fiCommissionName: 'PCPM' },
    { fiCommissionName: 'Percent' },
    { fiCommissionName: 'PMPM' },
    { fiCommissionName: 'Flat Dollar' }
  ];

  public static quotesCol = [
    { field: 'contractCode', header: 'Contract Code' },
    { field: 'network', header: 'Network' },
    { field: 'productCat', header: 'Product Cat' },
    { field: 'productCode', header: 'Product Code' },
    { field: 'productName', header: 'Plan Name' }
  ];

  public static FACTOR_MIGRATION_MENU = {
    label: 'Factor Maintenance',
    isSubMenu: true,
    subMenu: 'Import',
    subValue: 'import-factors',
    subMenu1: 'Export',
    subValue1: 'export-factors',
    subMenu2: 'Remove',
    subValue2: 'remove-factors',
    subMenu3: 'Cache Refresh',
    subValue3: 'cache-refresh',
    subMenu4: 'Data Migration',
    subValue4: 'factor-migration'
  };

  public static factorTableMenu = [
    {
      label: 'Factor Maintenance',
      value: 'factor-migration',
      isSubMenu: false,
      subMenu: 'Factor Maintenance',
      subValue: 'factor-migration'
    }
  ];

  public static DEFAULT_USER_ID_HEADER = 'Local userid';
  public static DEFAULT_USER_NAME_HEADER = 'Local username';

  public static FACTOR_MIGRATION_ROLE_MENU = {
    label: 'Factor Maintenance',
    isSubMenu: true,
    subMenu: 'Data Migration',
    subValue: 'factor-migration'
  };

  public static staticDeclineOptions = ['Other', 'High CURV Score', 'High Risk', 'Not Competitive', 'Large Claims', 'Under Performing', 'Missing Information'];

  public static smallGroup: string = 'SG';
  public static largeGroup: string = 'LG';
  public static dollar = '$';
  public static percent = '%';
  public static months = 'months';
  public static invalidValue = 'Invalid Value';
  public static family = 'family';
  public static contractCode = 'Contract Code';
  public static planName = 'Plan Name';
  public static productName = 'Product Name';
  public static genAgentCommission = 'General Agent Commission';
  public static association = 'Association';
  public static adjustmentType = 'Adjustment Type';
  public static applyCurrentRatio = 'Apply Current Ratio';
  public static salesAdjustment = 'Sales Adjustment';
  public static planType = 'Plan Type';
  public static ageBand = 'Age Band';
  public static employee = 'Employee';
  public static spouse = 'Spouse';
  public static child = 'Child';
  public static children = 'Children';
  public static employeePlusOne = 'Employee+1';
  public static EE = 'EE';
  public static ES = 'ES';
  public static EK = 'EK';
  public static EC = 'EC';
  public static EF = 'EF';
  public static oneNumber = '1';

  public static Vision = 'Vision';
  public static Medical = 'Medical';
  public static Dental = 'Dental';
  public static SuppHealth = 'Supp Health';
  public static HSAAdmin = 'HSA Admin Account';
  public static HRAAdmin = 'HRA Admin Account';

  // Action
  public static releaseAction = 'release';
  public static declineAction = 'decline';

  // status
  public static releasedStatus = 'Released';
  public static modifiedStatus = 'Modified';
  public static pendingReviewStatus = 'Pending Review';
  public static declinedStatus = 'Declined';
  public static termedStatus = 'Termed';

  public static uwComments = 'uwComments';
  public static salesNotetoUW = 'salesNotetoUW';
  public static uwAdjustment = 'uwAdjustment';
  public static uwNotesToSales = 'uwNotesToSales';
  public static adjustedRateActionPercent = 'adjustedRateActionPercent';

  public static ACCIDENT = 'accident';
  public static HOSPITAL = 'hospital';

  // PE Overrides
  public static RATE_GUARANTEE_EFFECTIVE = 'rateGuaranteeEffectiveDate';
  public static RATE_GUARANTEE_END = 'rateGuaranteeEndDate';
  public static RATE_GUARANTEE_MONTHS = 'rateGuaranteeMonths';

  // Sold Rates messages
  public static PRINT_TOOLTIP_SUPP_HEALTH_WARNING = 'Supp Health plans cannot be printed';

  // Guardrail messages
  public static contractEffectiveDateMessage = 'Contract start date is in the past, request /update is submitted on ';
  public static suppHealthCommissionPCPMMessage = 'Commission PCPM value is greater than ';
  public static suppHealthCommisionNYFactorMessage = 'Commission is not between ';
  public static suppHealthPremRateDifferenceMessage = 'Difference between quoted premium and anthem premium is more than ';
  public static suppHealthCompetativeAdjustmentMessage = 'Competitive Rate Adjustment percent is not between ';
  public static suppHealthExperienceClaimsMessage = 'Experience Claims is included';
  public static suppHealthAdjustmentFactorMessage = 'Adjustment type is Beat';
  public static suppHealthRateGuaranteeMonthsFactorMessage = 'Rate Guarantee months is greater than ';
  public static suppHealthCommissionFactorMessage = 'Commission is greater than';

  public static contractEffectiveDateKey = 'contractEffectiveDate';
  public static suppHealthCommissionPCPMKey = 'Supp Health Commission PCPM';
  public static suppHealthCommisionNYFactorKey = 'Supp Health NY Commission Factor';
  public static suppHealthPremRateDifferenceKey = 'Supp Health Premium Rate Diff';
  public static suppHealthCompetativeAdjustmentKey = 'Supp Health Competitive Adjustment';
  public static suppHealthExperienceClaimsKey = 'Experience Claims';
  public static suppHealthAdjustmentFactorKey = 'Supp Health adjustmentType Factor';
  public static suppHealthRateGuaranteeMonthsFactorKey = 'Supp Health Rate Guarantee Months Factor';
  public static suppHealthCommissionFactorKey = 'Supp Health Commission Factor';
  public static suppHealthPremiumComparisonKey = 'Supp Health Premium comparison';

  public static QUOTE_REASON = 'quoteReason';
  public static BATCH_ORIGIN = 'batchOrigin';
  public static REAL = 'REAL';
  public static T3ST = 'T3ST';
  public static ORIGINAL_GROUP_NUMBER_LABEL = 'Original Group Number';
  public static ORIGINAL_GROUP_NUMBER_KEY = 'originalGroupNumber';
  public static SG = 'SG';
  public static LG = 'LG';
  public static RENEWAL_WHA_PERCENT = 'renewalWHAPercent';
  public static IN_RATE_GUARANTEE = 'inRateGuarantee';
  public static IS_NATIONAL = 'isNational';

  public static ACCIDENT_COLUMN = 'RA - Adj - Accident';
  public static CRITICAL_ILLNESS_COLUMN = 'RA - Adj - Crit Illness';
  public static HOSPITAL_COLUMN = 'RA - Adj - Hosp Indem';

  public static RA_COLUMN_PLAN_1 = 'RA - Adj - Plan 1';
  public static RA_COLUMN_PLAN_2 = 'RA - Adj - Plan 2';
  public static RA_COLUMN_PLAN_3 = 'RA - Adj - Plan 3';
  public static RA_COLUMN_PLAN_4 = 'RA - Adj - Plan 4';
  public static RA_COLUMN_PLAN_5 = 'RA - Adj - Plan 5';
  public static RA_COLUMN_PLAN_6 = 'RA - Adj - Plan 6';

  public static SUGGESTED_INCR_ACCIDENT_COLUMN = 'Suggested Increase - Accident';
  public static SUGGESTED_INCR_HOSP_INDEM_COLUMN = 'Suggested Increase - Hosp Indem';
  public static SUGGESTED_INCR_CRIT_ILLNESS_COLUMN = 'Suggested Increase - Crit Illness';

  public static SUGGESTED_INCR_PLAN_1 = 'Suggested Increase - Plan 1';
  public static SUGGESTED_INCR_PLAN_2 = 'Suggested Increase - Plan 2';
  public static SUGGESTED_INCR_PLAN_3 = 'Suggested Increase - Plan 3';
  public static SUGGESTED_INCR_PLAN_4 = 'Suggested Increase - Plan 4';
  public static SUGGESTED_INCR_PLAN_5 = 'Suggested Increase - Plan 5';
  public static SUGGESTED_INCR_PLAN_6 = 'Suggested Increase - Plan 6';

  public static PRODUCT_TYPE_ACCIDENT = 'ACCIDENT';
  public static PRODUCT_TYPE_CRITICAL_ILLNESS = 'CRITICAL ILLNESS';
  public static PRODUCT_TYPE_HOSPITAL_IDEMNITY = 'HOSPITAL INDEMNITY';

  public static SUPP_HEALTH_RA_ADJ_COLUMNS = [CommonConstants.ACCIDENT_COLUMN, CommonConstants.CRITICAL_ILLNESS_COLUMN, CommonConstants.HOSPITAL_COLUMN];

  public static DEN_VIS_RA_ADJ_COLUMNS = [
    CommonConstants.RA_COLUMN_PLAN_1,
    CommonConstants.RA_COLUMN_PLAN_2,
    CommonConstants.RA_COLUMN_PLAN_3,
    CommonConstants.RA_COLUMN_PLAN_4,
    CommonConstants.RA_COLUMN_PLAN_5,
    CommonConstants.RA_COLUMN_PLAN_6
  ];

  public static DEN_VIS_RA_ADJ_COLUMNS_PROPERTIES = ['adjPlan1', 'adjPlan2', 'adjPlan3', 'adjPlan4', 'adjPlan5', 'adjPlan6'];

  public static SUGGESTED_INCR_COLUMNS = [
    CommonConstants.SUGGESTED_INCR_ACCIDENT_COLUMN,
    CommonConstants.SUGGESTED_INCR_HOSP_INDEM_COLUMN,
    CommonConstants.SUGGESTED_INCR_CRIT_ILLNESS_COLUMN
  ];

  public static SUGGESTED_INCR_VIS_DEN_COLUMNS = [
    CommonConstants.SUGGESTED_INCR_PLAN_1,
    CommonConstants.SUGGESTED_INCR_PLAN_2,
    CommonConstants.SUGGESTED_INCR_PLAN_3,
    CommonConstants.SUGGESTED_INCR_PLAN_4,
    CommonConstants.SUGGESTED_INCR_PLAN_5,
    CommonConstants.SUGGESTED_INCR_PLAN_6
  ];

  public static SUPP_HEALTH_RA_ADJ_COLUMN_PROPERTIES = ['accidentAdjustments', 'hospitalIndemnityAdjustments', 'criticalIllnessAdjustments'];

  public static CRITICAL_ILLNESS_NON_TOBACCO_PLAN_INFO = 'Tobacco rates exist but are not displayed';
  public static CRITICAL_ILLNESS_NON_TOBACCO_PRODUCT_INFO = 'For Critical Illness products, Tobacco rates exist but are not displayed';

  public static CURRENT_RATES_EDITED = 'Current plan rates edited';

  public static quoteRoutingUrls = {
    Medical: '/quote/uw-rate',
    Vision: 'quote/uw-rate-vision',
    Dental: 'quote/uw-rate-dental',
    'Supp Health': 'quote/uw-rate-supplemental-health'
  };

  public static FEATURED_PLAN_INDICATOR_FETCH = 'FEATURED_PLAN_INDICATOR_FETCH';
  public static PORTFOLIO_PLAN_INDICATOR_FETCH = 'PORTFOLIO_PLAN_INDICATOR_FETCH';
  public static ERRORED_PLAN_INDICATOR_FETCH = 'ERRORED_PLAN_INDICATOR_FETCH';
  public static OTHER_DETAILS_FETCH = 'OTHER_DETAILS_FETCH';
  public static UNDERWRITER_ADJUSTMENT_FETCH = 'UNDERWRITER_ADJUSTMENT_FETCH';
  public static MEDICAL_PREMIUM_COMPARISON_FETCH = 'MEDICAL_PREMIUM_COMPARISON_FETCH';
  public static VISION_PREMIUM_COMPARISON_FETCH = 'VISION_PREMIUM_COMPARISON_FETCH';
  public static SUPPHEALTH_PREMIUM_COMPARISON_FETCH = 'SUPPHEALTH_PREMIUM_COMPARISON_FETCH';
  public static ASSUMPTIONS_AND_CONDITIONS_FETCH = 'ASSUMPTIONS_AND_CONDITIONS_FETCH';
  public static GUARD_RAIL_FAILED_STATUS_KEY_FETCH = 'GUARD_RAIL_FAILED_STATUS_KEY_FETCH';
  public static AGGREGATED_PROPOSED_PLANS_FETCH = 'AGGREGATED_PROPOSED_PLANS_FETCH';
  public static FEATURED_PLAN_FETCH = 'FEATURED_PLAN_FETCH';
  public static PORTFOLIO_PLAN_FETCH = 'PORTFOLIO_PLAN_FETCH';
  public static ERROR_PLAN_FETCH = 'ERROR_PLAN_FETCH';
  public static QUOTE_DETAILS_STATUS = 'QUOTE_DETAILS_STATUS';
  public static QUOTE_DETAILS_STATUS_COMPLETE = 'QUOTE_DETAILS_STATUS_COMPLETE';
  public static ALERT_MESSAGE = 'Error while getting quotes. Please contact RARE support team dl-RARE-IT@anthem.com';
  public static QUOTE_DETAILS_LOADING_MESSAGE = 'Loading Opportunity Details, Please Wait ...';

  public static ACA = 'ACA';
  public static medicalACA = 'Medical-ACA';
  public static sold_navigation = '/soldRate';
  public static SOLD_RATES_URL = '/soldRates';
  public static featured = 'featured';
  public static save = 'save';
  public static system_error = 'System Error';
  public static ADMIN = 'ADMIN';
  public static READONLY = 'READONLY';

  public static YES = 'Y';
  public static FEATURE_PLAN_TYPE = 'F';
  public static PORTFOLIO_PLAN_TYPE = 'P';
  public static PRE_SOLD = 'Pre-Sold';
  public static SOLD_PENDING_UW_REVIEW = 'Sold-Pending UW Review';
  public static SOLD_MODIFIED = 'Sold Modified';
  public static ACTIVE = 'Active';
  public static ENROLLMENTS = 'enrollments';
  public static TARGET_ENV_ERROR = 'Please select 4 or fewer target environments';
  public static RARE_DMT_ACCESS_FOR_ACTUARIAL = ['RARE_ACTUARIAL_DENTAL', 'RARE_ACTUARIAL_VISION', 'RARE_ACTUARIAL_MEDICAL'];
  public static NO_CHAR = 'N';

  public static SINGLE = 'single';
  public static EE_ONE = 'eeOne';
  public static EE_SPOUSE = 'eeSpouse';
  public static EE_CHILD = 'eeChild';
  public static EE_CHILDREN = 'eeChildren';
  public static FAMILY = 'family';

  public static COMMISSION = 'COMMISSION';
  public static COMMISSION_TYPE = 'COMMISSION_TYPE';
  public static COMMISSION_ERRORS = 'commissionErrors';
  public static COMMISSION_OPTIONS = ['PCPM', 'Percent', 'Flat Dollar', 'PMPM'];
  public static COMMISSION_COLUMNS = ['Comm Value', 'Comm Type'];

  public static SSL = 'SSL';
  public static REFUND_PCT = 'REFUND_PCT';
  public static ASL = 'ASL';

  public static FACTOR_MAINTENANCE = 'Factor Maintenance';
  public static SUB_MENU = 'subMenu';
  public static SUB_MENU1 = 'subMenu1';
  public static SUB_VALUE = 'subValue';
  public static SUB_VALUE1 = 'subValue1';
  public static INITIAL_RELEASE = 'Initial Release';
  public static STATUS_REASONS = 'statusReasons';
  public static QUOTINGTYPE_FROM_TAB = 'quotingTypeFromTab';

  public static ADJUSTMENTS_TRAIL = 'adjustmentsTrail';
  public static COMPONENT_ADJUSTMENTS = 'componentAdjustments';

  public static ADJUSTMENT_TYPE = 'adjustmentType';
  public static ADJUSTMENT_VALUE = 'adjustmentValue';
  public static UW_ACTIONS = 'uwActions';
  public static UW_ACTION_COMMISSION_OVERRIDDEN = 'COMMISSION_OVERRIDDEN';
  public static COMPONENT_ADJUSTMENT_COMMISSION_TYPE_OVERRIDDEN = 'COMMISSION_TYPE_OVERRIDDEN';
  public static COMPONENT_ADJUSTMENT_COMMISSION_VALUE_OVERRIDDEN = 'COMMISSION_VALUE_OVERRIDDEN';

  public static AUTORUN_QUOTE_CONVERT_QUOTE_TO_SAVE = 'This is an autorun quote, pls convert the quote to save or release it';
  public static APP_NAME = 'RARE';

  public static BULK_IMPORT_FACTOR_MESSAGES = {
    INITIATED: 'Migration Plan execution initiated successfully',
    VALIDATION_COMPLETE: 'Plan Validation is complete',
    READING_AND_MIGRATION_DATA_INPROGRESS: 'Reading and Data migration in progress',
    READING_DATA_COMPLETE: 'Reading table data complete',
    CONNECTION_ESTABLISHED: 'Database Connection Established',
    DATA_INSERT_COMPLETE: 'Data Insert is completed for the full update',
    EXECUTION_FAILED: 'Migration plan execution failed',
    EXECUTION_SUCCESSFUL: 'Migration plan execution successful'
  };

  public static UNDERWRITERS = 'underwriters';
  public static APP_RESOURCE = 'appResource';

  public static CONTRACT_CODE_ALREADY_EXIST =
    'This contract code is already added for this product. Please use a different contract code or update the existing entry.';

  // Login/Logout routes where spark widget should be hidden
  public static LOGIN_ROUTES = ['/login', '/login-local', '/login-with-serviceid', '/forbidden', '/unauthorized'];

  // Off-Cycle status reason options (shared across Medical, Dental, Vision)
  public static OFF_CYCLE_STATUS_REASON_OPTIONS = [
    { label: 'Employer Switched to Another Carrier', value: 'Employer Switched to Another Carrier' },
    { label: 'Employer Discontinued Health Benefits', value: 'Employer Discontinued Health Benefits' },
    { label: 'Employer Merged with Another Organization', value: 'Employer Merged with Another Organization' },
    { label: 'Employer Acquisition / Ownership Change', value: 'Employer Acquisition / Ownership Change' },
    { label: 'Employer Ceased Operations', value: 'Employer Ceased Operations' },
    { label: 'Reduction in Workforce / Group No Longer Eligible', value: 'Reduction in Workforce / Group No Longer Eligible' },
    { label: 'Non-Payment of Premium, Insolvency/Bankruptcy', value: 'Non-Payment of Premium, Insolvency/Bankruptcy' },
    { label: 'Other', value: 'Other' }
  ];
}
