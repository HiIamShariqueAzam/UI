import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-wave-loader',
  templateUrl: './wave-loader.component.html',
  standalone: false,
})
export class WaveLoaderComponent implements OnInit {

  public waves: Array<number>;

  ngOnInit() {
    this.waves = [1,2,3,4,5,6,7]
  }

}
