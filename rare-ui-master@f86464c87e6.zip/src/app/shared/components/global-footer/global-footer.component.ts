import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-global-footer',
  templateUrl: './global-footer.component.html',
  standalone: false,
})
export class GlobalFooterComponent implements OnInit {

  constructor() { }

  currentyear: number = new Date().getFullYear();

  ngOnInit() {
    
  }

}
