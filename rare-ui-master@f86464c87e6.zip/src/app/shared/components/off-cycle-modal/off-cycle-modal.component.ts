import { Component, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { OffCycleModalService } from '../../services/off-cycle-modal.service';

@Component({
  selector: 'app-off-cycle-modal',
  templateUrl: './off-cycle-modal.component.html',
  styleUrls: ['./off-cycle-modal.component.css'],
  standalone: false
})
export class OffCycleModalComponent {
  @ViewChild('offCycleModalContent', { static: false }) offCycleModalContent!: ElementRef;
  @ViewChild('offCycleModalHeader', { static: false }) offCycleModalHeader!: ElementRef;
  @ViewChild('offCycleModalFooter', { static: false }) offCycleModalFooter!: ElementRef;

  @Input() rateData: any;
  @Input() alternateQuote: boolean = false;
  @Input() opportunityType: string = '';
  
  @Output() confirm = new EventEmitter<void>();
  @Output() reasonChange = new EventEmitter<void>();
  @Output() dateClick = new EventEmitter<void>();

  constructor(public offCycleModalService: OffCycleModalService) {}

  onOffCycleConfirm() {
    this.confirm.emit();
  }

  onOffCycleReasonChange() {
    this.reasonChange.emit();
  }

  clickOffCycleDate() {
    this.dateClick.emit();
  }

  getModalElements() {
    return {
      content: this.offCycleModalContent,
      header: this.offCycleModalHeader,
      footer: this.offCycleModalFooter
    };
  }
}
