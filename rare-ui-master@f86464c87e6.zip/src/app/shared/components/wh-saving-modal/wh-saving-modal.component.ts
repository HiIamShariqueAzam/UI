import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonConstants } from '../../constants/common.constants';
import { StringUtils } from '../../utils/string-utils';
import { ValidationService } from '../../services/validation.service';
import { CommonUtil } from '../../utils/common-util';

@Component({
  selector: 'app-wh-saving-modal',
  templateUrl: './wh-saving-modal.component.html',
  styleUrls: ['./wh-saving-modal.component.css'],
  standalone: false,
})
export class WhSavingModalComponent implements OnInit, OnChanges, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  @ViewChild('modalValidation', { static: false }) modalValidation!: ElementRef;

  specialityType = [];
  selectedSpecialityList: any;
  selectedSpecialityForm: FormGroup<any>;
  public dynamic_specialityForm: FormGroup = this.formBuilder.group({});
  otherUnitType: string;
  whDefaultValue = 0;
  @Input() uwAdjustment;
  @Input() quoteDetail;
  @Input() allPlansLoaded: boolean;
  @Input() quoteAdjustments: boolean;
  @Output() adjustmentsUpdated = new EventEmitter<any>();
  @Input() uwAdjustmentFetchObject;
  @Input() isRenewal;
  displaySpecialityTypes = [];
  whAdjustmentsFromResponse = [];
  isAdjustmentSubmit: boolean = false;
  whSavingsSpecialtyTypesNew = {};

  constructor(private formBuilder: FormBuilder) {

  }

  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  
  ngOnChanges(changes: SimpleChanges) {
    if ((changes.uwAdjustmentFetchObject && !changes.uwAdjustmentFetchObject.firstChange)
      || (changes.quoteAdjustments && !changes.quoteAdjustments.firstChange)
      || (changes.uwAdjustment && !changes.uwAdjustment.firstChange)) {
      this.initializeComponentVariables()
    }
  }

  initializeComponentVariables() {
    this.specialityType = [];
    this.whAdjustmentsFromResponse=[];
    this.selectedSpecialityList=[];
    this.dynamic_specialityForm.reset();
    if (this.uwAdjustmentFetchObject?.uwAdjustment?.abfRateActionAdjustment
      && this.uwAdjustmentFetchObject?.uwAdjustment?.abfRateActionAdjustment?.discountSplits
      && this.uwAdjustmentFetchObject?.uwAdjustment?.abfRateActionAdjustment?.renewalWHAPercent) {
      this.whAdjustmentsFromResponse = this.uwAdjustmentFetchObject?.uwAdjustment?.abfRateActionAdjustment?.discountSplits;
    } else if (this.uwAdjustmentFetchObject?.uwAdjustment?.abfRateActionAdjustment && StringUtils.isUndefined(this.uwAdjustmentFetchObject?.uwAdjustment?.abfRateActionAdjustment?.discountSplits) && this.uwAdjustmentFetchObject?.uwAdjustment?.abfRateActionAdjustment?.renewalWHAPercent) {
      this.otherUnitType = CommonConstants.OTHER;
      this.whAdjustmentsFromResponse = [{
        "value": this.uwAdjustmentFetchObject.uwAdjustment.abfRateActionAdjustment.renewalWHAPercent,
        "id": CommonConstants.OTHER
      }]
    }
    else if (this.uwAdjustmentFetchObject?.uwAdjustment?.quoteAdjustments && this.uwAdjustmentFetchObject?.uwAdjustment?.quoteAdjustments?.wholeHealthAdjustmentFactor
      && StringUtils.isUndefined(this.uwAdjustmentFetchObject?.uwAdjustment?.quoteAdjustments?.discountSplits)) {
      this.otherUnitType = CommonConstants.OTHER;
      this.whAdjustmentsFromResponse = [{
        "value": this.uwAdjustmentFetchObject.uwAdjustment.quoteAdjustments.wholeHealthAdjustmentFactor,
        "id": CommonConstants.OTHER
      }]
    }
    else if (this.uwAdjustmentFetchObject?.uwAdjustment?.quoteAdjustments && this.uwAdjustmentFetchObject?.uwAdjustment?.quoteAdjustments?.wholeHealthAdjustmentFactor
      && this.uwAdjustmentFetchObject?.uwAdjustment?.quoteAdjustments?.discountSplits) {
      this.whAdjustmentsFromResponse = this.uwAdjustmentFetchObject.uwAdjustment.quoteAdjustments.discountSplits;
    }
    else if (this.uwAdjustmentFetchObject?.isBulkFlow && this.uwAdjustmentFetchObject?.wholeHealthAdjustmentFactor && this.uwAdjustmentFetchObject?.discountSplits) {
        this.whAdjustmentsFromResponse = this.uwAdjustmentFetchObject.discountSplits;
      }
    else if (this.uwAdjustmentFetchObject?.isBulkFlow && this.uwAdjustmentFetchObject?.wholeHealthAdjustmentFactor && StringUtils.isUndefined(this.uwAdjustmentFetchObject?.discountSplits)) {
        this.otherUnitType = CommonConstants.OTHER;
        this.whAdjustmentsFromResponse = [{
          "value": this.uwAdjustmentFetchObject.wholeHealthAdjustmentFactor,
          "id": CommonConstants.OTHER
        }]
      }
    else if (this.uwAdjustmentFetchObject?.isBulkFlow && this.uwAdjustmentFetchObject?.renewalWHAPercent && this.uwAdjustmentFetchObject?.discountSplits) {
        this.whAdjustmentsFromResponse = this.uwAdjustmentFetchObject.discountSplits;
      }
    else if (this.uwAdjustmentFetchObject?.isBulkFlow && this.uwAdjustmentFetchObject?.renewalWHAPercent && StringUtils.isUndefined(this.uwAdjustmentFetchObject?.discountSplits)) {
        this.otherUnitType = CommonConstants.OTHER;
        this.whAdjustmentsFromResponse = [{
          "value": this.uwAdjustmentFetchObject.renewalWHAPercent,
          "id": CommonConstants.OTHER
        }]
      }

    this.getSpecialityTypes();
    const preSelectedSpecialities = this.specialityType.filter((specialityType) => this.whAdjustmentsFromResponse?.find(({ id }) => StringUtils.isEqual(specialityType.label, id)));
    this.selectedSpecialityList = preSelectedSpecialities.map(preSelectedSpeciality => preSelectedSpeciality['value'])
    this.selectedSpecialityForm = this.formBuilder.group({
      selectedSpeciality: ['']
    })
    if (this.uwAdjustmentFetchObject?.isBulkFlow) {
      this.addSpeciality();
    }
  }
  getSpecialityTypes() {
    this.specialityType = [];
    this.whSavingsSpecialtyTypesNew = this.uwAdjustmentFetchObject?.whSavingsSpecialtyTypes;
    let specilityKeys = !StringUtils.isUndefined(this.whSavingsSpecialtyTypesNew) ? Object.keys(this.whSavingsSpecialtyTypesNew) : [];
    this.whAdjustmentsFromResponse.forEach(responseSpeciality => {
      if (!specilityKeys.includes(responseSpeciality.id)) {
        specilityKeys.push(responseSpeciality.id)
      }
    })
    specilityKeys?.forEach(specialityType => {
      this.specialityType.push({ label: specialityType, value: specialityType })
    })
    specilityKeys = [];
  }
  ngOnInit(): void {
    this.isAdjustmentSubmit = false;
    this.getSpecialityTypes();
    this.initializeComponentVariables()
  }
  addSpeciality() {
    this.displaySpecialityTypes = [];
    Object.keys(this.dynamic_specialityForm.controls).forEach(key => {
      if (!this.selectedSpecialityList.includes(key)) {
        this.dynamic_specialityForm?.get(key)?.reset();
        this.dynamic_specialityForm.removeControl(key)
      }
    })
    this.selectedSpecialityList?.forEach(selectedSpecialityList => {
      this.specialityType.forEach(specialityType => {
        if (selectedSpecialityList == specialityType.value) {
          specialityType['defaultValue'] = this.whSavingsSpecialtyTypesNew[specialityType.value];
          this.dynamic_specialityForm.addControl(
            selectedSpecialityList,
            this.formBuilder.control('', [Validators.required,ValidationService.decimalValidatorOptionalSign]),
          );
          this.displaySpecialityTypes.push(specialityType)
        }
      })
    })
    if (this.whAdjustmentsFromResponse) {
      this.whAdjustmentsFromResponse.forEach(whadjstment => {
        this.displaySpecialityTypes.forEach(displaySpeciality => {
          if (whadjstment.id == displaySpeciality.label) {
            if (StringUtils.isEqual(whadjstment.id, CommonConstants.OTHER)) {
              this.otherUnitType = whadjstment.id
            }
            displaySpeciality['defaultValue'] = whadjstment.value;
          }
        })
      })
    }
    if (this.selectedSpecialityList) {
      this.selectedSpecialityList?.forEach(selectedSpeciality => {
        this.dynamic_specialityForm.addControl(
          selectedSpeciality,
          this.formBuilder.control('', [Validators.required,ValidationService.decimalValidatorOptionalSign])
        );
      })
    }
    if(!this.uwAdjustmentFetchObject?.isBulkFlow)
    {
      this.adjustmentsUpdated.emit({
        'whSavingsAdjustment': this.dynamic_specialityForm,
        'otherUnitType': this.otherUnitType,
        'SpecialityTypes': this.displaySpecialityTypes,
        'isInitialUpdate': true,
        'uwAdjustment': this.uwAdjustment
      })
    }
  }
  setValues() {
    this.isAdjustmentSubmit = true;
    if (this.dynamic_specialityForm.invalid) {
      return;
    } else {
      this.isAdjustmentSubmit = false;
      this.adjustmentsUpdated.emit({
        'whSavingsAdjustment': this.dynamic_specialityForm,
        'otherUnitType': this.otherUnitType,
        'SpecialityTypes': this.displaySpecialityTypes,
        'isInitialUpdate': false,
        'uwAdjustment': this.uwAdjustment
      })
      this.modalValidation.nativeElement.setAttribute("data-bs-dismiss", "modal");
      this.modalValidation.nativeElement.click();
    }
  }
  setwhadjValue(event, speciality) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      if (StringUtils.isEqual(this.quoteDetail?.opportunityType, CommonConstants.NEW_BUSINESS_LOCAL) || ((StringUtils.isEqual(this.quoteDetail?.opportunityType, CommonConstants.RENEWAL_LOCAL) || this.uwAdjustment?.isBulkFlow) && charCode != 45) ) {
        return false;
      }
    } else {
      this.dynamic_specialityForm?.get(speciality.value)?.setValue(event.target.value)
    }
  }
  checkIsRenewal() {
    return StringUtils.isEqual(this.quoteDetail?.opportunityType, CommonConstants.RENEWAL_LOCAL) || this.isRenewal;
  }
  addOtherSpeciality(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode < 48 || charCode > 57) && (charCode < 97 || charCode > 122) && (charCode < 65 || charCode > 90)) {
      return false;
    } else {
      this.otherUnitType = event.target?.value;
    }
  }
  closeWHModel(){
    this.isAdjustmentSubmit = false;
  }
}
