import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WhSavingModalComponent } from './wh-saving-modal.component';

describe('WhSavingModalComponent', () => {
  let component: WhSavingModalComponent;
  let fixture: ComponentFixture<WhSavingModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WhSavingModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WhSavingModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
