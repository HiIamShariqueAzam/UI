import { Injectable } from '@angular/core';
import { ExperienceSummary, EnrollmentHistoryEntry, ClaimHistoryEntry, RevenueHistoryEntry, ColumnHeader, ColumnDefaults, OpportunityType } from '../constants/group-experience.constants';
import { DataTableSchema, CustomFilter, DataTableActions, TableColumn } from '../../data-table-edit-overaly/constants/data-table-edit-overlay.constants';
import  moment from 'moment';
import * as XLSX from 'xlsx';

@Injectable({
  providedIn: 'root'
})
export class GroupExperienceService {

  currentClaimBasis: 'paid' | 'incurred'; 
  public getExperienceSummaryFlat(data: any): ExperienceSummary[] {
    return this.setExperienceSummary(data);
  }

  public updateOriginalData(data: { groupExperience : any }, changedRows: ExperienceSummary[], removedRows: ExperienceSummary[]) {
    
    removedRows.forEach(row => {
      Object.keys(row).forEach(key => {
        if (key !== 'claimDate' && !key.endsWith('_original_path')) {
          const pathKey = `${key}_original_path`;
          const path = row[pathKey];
          if (path) {
            const paths = String(path).split(', ');
            paths.forEach(p => {
              this.deleteValueAtPath(data, p.trim());
            });
          }
        }
      });
    });

    changedRows.forEach(row => {
      Object.keys(row).forEach(key => {
        if (key !== 'claimDate' && !key.endsWith('_original_path')) {
          const value = row[key];
          const pathKey = `${key}_original_path`;
          const path = row[pathKey];
          if (path) {
            const paths = String(path).split(', ');
            paths.forEach(p => {
              this.setValueAtPath(data, p.trim(), value.length === 0 ? null : Number(value));
              
              const trimmedPath = p.trim();
              const parentPath = this.getParentPath(trimmedPath);
              if (parentPath && row.claimDate) {
                this.setValueAtPath(data, `${parentPath}.claimDate`, row.claimDate);
              }
            });
          }
        }
      });
    });
    
    return data.groupExperience;
  }

  private getParentPath(path: string): string | null {
    const parts = path.split('.');
    if (parts.length <= 1) {
      return null;
    }
    return parts.slice(0, -1).join('.');
  }

  private setValueAtPath(obj: any, path: string, value: any): void {
    const parts = path.split('.');
    let current = obj;

    for (let i = 0; i < parts.length - 1; i++) {
      const part = parts[i];
      const arrayMatch = part.match(/^(\w+)\[(\d+)\]$/);

      if (arrayMatch) {
        const arrayName = arrayMatch[1];
        const index = parseInt(arrayMatch[2], 10);
        current = current[arrayName][index];
      } else {
        current = current[part];
      }

      if (current === undefined || current === null) {
        return;
      }
    }

    const lastPart = parts[parts.length - 1];
    const arrayMatch = lastPart.match(/^(\w+)\[(\d+)\]$/);

    if (arrayMatch) {
      const arrayName = arrayMatch[1];
      const index = parseInt(arrayMatch[2], 10);
      current[arrayName][index] = value;
    } else {
      current[lastPart] = value;
    }
  }

  private deleteValueAtPath(obj: any, path: string): void {
    const parts = path.split('.');
    
    if (parts.length < 2) {
      return;
    }

    let current = obj;

    for (let i = 0; i < parts.length - 2; i++) {
      const part = parts[i];
      const arrayMatch = part.match(/^(\w+)\[(\d+)\]$/);

      if (arrayMatch) {
        const arrayName = arrayMatch[1];
        const index = parseInt(arrayMatch[2], 10);
        if (!current[arrayName] || !current[arrayName][index]) {
          return;
        }
        current = current[arrayName][index];
      } else {
        if (!current[part]) {
          return;
        }
        current = current[part];
      }
    }

    const parentPart = parts[parts.length - 2];
    const arrayMatch = parentPart.match(/^(\w+)\[(\d+)\]$/);

    if (arrayMatch) {
      const arrayName = arrayMatch[1];
      const index = parseInt(arrayMatch[2], 10);
      if (current[arrayName] && Array.isArray(current[arrayName]) && current[arrayName][index]) {
        current[arrayName].splice(index, 1);
      }
    } else {
      if (current[parentPart]) {
        delete current[parentPart];
      }
    }
  }

  public setExperienceSummary(data: any): ExperienceSummary[] {

    const groupExperience = data;

    const enrollmentHistory = (groupExperience?.enrollmentHistory || []) as EnrollmentHistoryEntry[];
    const claimHistory = (groupExperience?.claimHistory || []) as ClaimHistoryEntry[];
    const revenueHistory = (groupExperience?.revenueHistory || []) as RevenueHistoryEntry[];

    const subscriberCounts = this.getCounts(enrollmentHistory, 'SBSCR');
    const memberCounts = this.getCounts(enrollmentHistory, 'MEM');

    const experienceSummary = this.createExperienceSummary(subscriberCounts, memberCounts);

    this.updateExperienceSummaryWithClaims(claimHistory, experienceSummary);
    this.updateExperienceSummaryWithRevenue(revenueHistory, experienceSummary);

    return experienceSummary;
  }

  private getCounts(history: EnrollmentHistoryEntry[], basis: string): Map<string, Map<string, string>> {
    const countsMap = new Map<string, Map<string, string>>();

    history?.forEach((entry, entryIndex) => {
      if (basis === entry?.amountBasis) {
        const amounts = entry?.amounts || [];
        amounts.forEach((amountEntry, amountIndex) => {
          const claimDate = amountEntry?.claimDate as string;
          const amountValue = amountEntry?.amount;
          const summaryAmount = (amountValue == null || amountValue === '') ? '0' : String(amountValue);
          const path = `groupExperience.enrollmentHistory[${entryIndex}].amounts[${amountIndex}].amount`;

          if (countsMap.has(claimDate)) {
            const existing = countsMap.get(claimDate)!;
            const existingValue = existing.get('value')!;
            let existingAmount = (existingValue == null || existingValue === '') ? 0 : parseFloat(existingValue);
            existingAmount = isNaN(existingAmount) ? 0 : existingAmount;
            
            let newAmount = parseFloat(summaryAmount);
            newAmount = isNaN(newAmount) ? null : newAmount;
            
            const existingPath = existing.get('path')!;
            const newMap = new Map<string, string>();
            newMap.set('value', String(existingAmount + newAmount));
            newMap.set('path', `${existingPath}, ${path}`);
            countsMap.set(claimDate, newMap);
          } else {
            const newMap = new Map<string, string>();
            newMap.set('value', summaryAmount);
            newMap.set('path', path);
            countsMap.set(claimDate, newMap);
          }
        });
      }
    });

    return countsMap;
  }

  private createExperienceSummary(
    subscriberCounts: Map<string, Map<string, string>>,
    memberCounts: Map<string, Map<string, string>>
  ): ExperienceSummary[] {
    const summaryList: ExperienceSummary[] = [];

    subscriberCounts.forEach((subscriberData, date) => {
      const memberData = memberCounts.get(date);
      const summary: ExperienceSummary = {
        claimDate: date,
        subscriberCount: subscriberData.get('value'),
        subscriberCount_original_path: subscriberData.get('path'),
        memberCount: memberData?.get('value') || "0.0",
        memberCount_original_path: memberData?.get('path') || ""
      };
      summaryList.push(summary);
    });

    summaryList.sort((a, b) => {
      const dateA = a?.claimDate;
      const dateB = b?.claimDate;
      return dateB.localeCompare(dateA);
    });

    return summaryList;
  }

  private updateExperienceSummaryWithClaims(
    claimHistory: ClaimHistoryEntry[],
    experienceSummary: ExperienceSummary[]
  ): void {
    claimHistory?.forEach((claimEntry, entryIndex) => {
      const amountBasis = claimEntry?.amountBasis as string;
      const serviceType = claimEntry?.serviceType as string;
      const classifications = claimEntry?.classifications as string[];
      const amounts = claimEntry?.amounts || [];

      amounts.forEach((amount, amountIndex) => {
        const claimDate = amount?.claimDate as string;
        const claimAmount = parseFloat(String(amount?.amount));
        const path = `groupExperience.claimHistory[${entryIndex}].amounts[${amountIndex}].amount`;
        
        let dateFound = false;
        
        for (const summary of experienceSummary) {
          if (summary?.claimDate === claimDate) {
            this.updateSummary(summary, classifications, serviceType, amountBasis, claimAmount, path);
            dateFound = true;
            break;
          }
        }

        if (!dateFound) {
          const newSummary: ExperienceSummary = {
            claimDate: claimDate
          };
          this.updateSummary(newSummary, classifications, serviceType, amountBasis, claimAmount, path);
          experienceSummary.push(newSummary);
        }
      });
    });
  }

  private updateSummary(
    summary: ExperienceSummary,
    classifications: string[],
    serviceType: string,
    amountBasis: string,
    claimAmount: number,
    path: string
  ): void {
    const combinedKey = this.createCombinedKey(classifications, serviceType, amountBasis);
    const formattedClaimAmount = claimAmount.toFixed(2);
    summary[combinedKey] = formattedClaimAmount;
    summary[`${combinedKey}_original_path`] = path;
  }

  private createCombinedKey(classifications: string[], serviceType: string, amountBasis: string): string {
    if (classifications?.length === 0) {
      if ('Medical' === serviceType) {
        return 'claim_MedClaims_' + amountBasis?.toLowerCase();
      } else if ('Rx' === serviceType) {
        return 'claim_RxClaims_' + amountBasis?.toLowerCase();
      }
    }
    
    return (
      'claim_' +
      classifications?.join('_') +
      '_' +
      amountBasis?.toLowerCase()
    );
  }

  private updateExperienceSummaryWithRevenue(
    revenueHistory: RevenueHistoryEntry[],
    experienceSummary: ExperienceSummary[]
  ): void {
    revenueHistory?.forEach((revenueEntry, entryIndex) => {
      const dateBasis = revenueEntry?.dateBasis as string;
      const type = revenueEntry?.type as string;
      const amounts = revenueEntry?.amounts || [];

      amounts.forEach((amount, amountIndex) => {
        const claimDate = amount?.claimDate as string;
        const claimAmount = parseFloat(String(amount?.amount));
        const formattedClaimAmount = claimAmount.toFixed(2);
        const path = `groupExperience.revenueHistory[${entryIndex}].amounts[${amountIndex}].amount`;

        experienceSummary.forEach(summary => {
          const combinedKey = 'revenue_' + type + '_' + dateBasis?.toLowerCase();
          
          if (summary?.claimDate === claimDate) {
            summary[combinedKey] = formattedClaimAmount;
            summary[`${combinedKey}_original_path`] = path;
          }
        });
      });
    });
  }

  //
  public extractUniqueKeysFromSummary(experienceSummary: ExperienceSummary[]): Set<string> {
    const uniqueKeys = new Set<string>();
    experienceSummary.forEach((item: any) => {
      Object.keys(item).forEach((key) => {
        if (!key.endsWith('_original_path')) {
          uniqueKeys.add(key);
        }
      });
    });
    return uniqueKeys;
  }

  public getPaidKeys(uniqueKeys: Set<string>): string[] {
    return Array.from(uniqueKeys).filter((key) => key.endsWith('paid'));
  }

  public getIncurredKeys(uniqueKeys: Set<string>): string[] {
    return Array.from(uniqueKeys).filter((key) => key.endsWith('incurred'));
  }

  public getClaimKeys(keys: string[]): string[] {
    return keys.filter((key) => key.startsWith('claim'));
  }

  public getRevenueKeys(keys: string[]): string[] {
    return keys.filter((key) => key.startsWith('revenue'));
  }

  public sortClaimKeys(keys: string[]): string[] {
    return keys.sort((a, b) => {
      if (a.includes('MedClaims') && !b.includes('MedClaims')) return -1;
      if (!a.includes('MedClaims') && b.includes('MedClaims')) return 1;
      if (a.includes('RxClaims') && !b.includes('RxClaims')) return 1;
      if (!a.includes('RxClaims') && b.includes('RxClaims')) return -1;
      return 0;
    });
  }

  public transformKeyToHeader(key: string, prefix: string, suffix: string): string {
    let transformedKey = key.replace(new RegExp(`^${prefix}_`), '').replace(new RegExp(`_${suffix}$`), '');
    if (transformedKey === 'PREM') {
      return 'Total Premium';
    }
    return transformedKey;
  }

  public buildPaidColumnsData(uniqueKeys: Set<string>) {
    const paidKeys = this.getPaidKeys(uniqueKeys);
    const claimPaidKeys = this.getClaimKeys(paidKeys);
    const revenuePaidKeys = this.getRevenueKeys(paidKeys);
    
    return {
      claimPaidKeys: this.sortClaimKeys(claimPaidKeys),
      revenuePaidKeys: this.sortClaimKeys(revenuePaidKeys),
      allPaidKeys: paidKeys
    };
  }

  public buildIncurredColumnsData(uniqueKeys: Set<string>) {
    const incurredKeys = this.getIncurredKeys(uniqueKeys);
    const claimIncurredKeys = this.getClaimKeys(incurredKeys);
    const revenueIncurredKeys = this.getRevenueKeys(incurredKeys);
    
    return {
      claimIncurredKeys: this.sortClaimKeys(claimIncurredKeys),
      revenueIncurredKeys: this.sortClaimKeys(revenueIncurredKeys),
      allIncurredKeys: incurredKeys
    };
  }

  public getStaticColumnKeys(uniqueKeys: Set<string>) {
    const allKeys = Array.from(uniqueKeys);
    return {
      claimDateKeys: allKeys.filter((key) => key.includes('claimDate')),
      subscriberCountKeys: allKeys.filter((key) => key.includes('subscriberCount')),
      memberCountKeys: allKeys.filter((key) => key.includes('memberCount'))
    };
  }

  public prepareSchemaWithColumns(
    experienceSummary: ExperienceSummary[], 
    claimBasis: 'paid' | 'incurred'
  ): DataTableSchema {
    this.currentClaimBasis = claimBasis; 

    const uniqueKeys = this.extractUniqueKeysFromSummary(experienceSummary);
    const staticKeys = this.getStaticColumnKeys(uniqueKeys);
    const paidData = this.buildPaidColumnsData(uniqueKeys);
    const incurredData = this.buildIncurredColumnsData(uniqueKeys);
    const columns = this.buildColumnsArray(
      staticKeys, 
      paidData, 
      incurredData, 
      claimBasis
    );
    
    const parentHeaders = this.buildParentHeaders(
      paidData, 
      incurredData, 
      claimBasis
    );
    
    const result: DataTableSchema = {
      columns,
      parentHeaders,
      customFilters: [this.addPaidIncurredFilters()],
      actionsAllowed: [DataTableActions.Search, DataTableActions.Reset]
    };
    
    return result;
  }

  private buildColumnsArray(
    staticKeys: any, 
    paidData: any, 
    incurredData: any, 
    claimBasis: 'paid' | 'incurred'
  ) {
    

    const staticColumns = [
      ...staticKeys.claimDateKeys.map((key) => this.createColumn(key, ColumnHeader.ExpDate)),
      ...staticKeys.subscriberCountKeys.map((key) => this.createColumn(key, ColumnHeader.SubscriberCount)),
      ...staticKeys.memberCountKeys.map((key) => this.createColumn(key, ColumnHeader.MemberCount))
    ];

    const showPaid = claimBasis === 'paid' ? ColumnDefaults.ShowTrue : ColumnDefaults.ShowFalse;
    const showIncurred = claimBasis === 'incurred' ? ColumnDefaults.ShowTrue : ColumnDefaults.ShowFalse;

    const paidColumns = [
      ...paidData.claimPaidKeys.map((key) =>
        this.createColumn(key, this.transformKeyToHeader(key, 'claim', 'paid'), showPaid)
      ),
      ...paidData.revenuePaidKeys.map((key) =>
        this.createColumn(key, this.transformKeyToHeader(key, 'revenue', 'paid'), showPaid)
      )
    ];

    const incurredColumns = [
      ...incurredData.claimIncurredKeys.map((key) =>
        this.createColumn(key, this.transformKeyToHeader(key, 'claim', 'incurred'), showIncurred)
      ),
      ...incurredData.revenueIncurredKeys.map((key) =>
        this.createColumn(key, this.transformKeyToHeader(key, 'revenue', 'incurred'), showIncurred)
      )
    ];

    return [...staticColumns, ...paidColumns, ...incurredColumns];
  }

  createColumn(key: string, header: string, show: string = 'true'): TableColumn {

    const column: TableColumn = {
      header,
      name: key,
      path: key,
      type: 'text',
      minWidth: '90px',
      show
    }

    switch(key) {
      case 'claimDate': {
        column.validators = this.getClaimDateValidators();
        break;
      }

      case 'memberCount' : 
      case 'subscriberCount' : {
        column.validators = [
          {
            type: 'pattern',
            value: /^\d+$/,
            errorMessage: 'Only whole numbers are allowed'
          }
        ];
        break;
      }
      default: {
        column.validators = [
          {
            type: 'pattern',
            value: /^-?\d+(\.\d{1,2})?$/,
            errorMessage: 'Amounts up to 2 decimal places'
          }
        ];
        break;
      }
    }

    // /^\d+(\.\d{1,2})?$/
    return column;
  }

  private buildParentHeaders(
    paidData: any, 
    incurredData: any, 
    claimBasis: 'paid' | 'incurred'
  ) {
    const revenueColspan = claimBasis === 'paid' ? paidData.revenuePaidKeys.length : incurredData.revenueIncurredKeys.length;
    
    const headers = [
      { header: ColumnHeader.GroupExperience, colspan: 1 },
      { header: ColumnHeader.Enrollment, colspan: 2 },
      { 
        header: ColumnHeader.ClaimsHistory, 
        colspan: claimBasis === 'paid' ? paidData.claimPaidKeys.length : incurredData.claimIncurredKeys.length 
      },
      { 
        header: ColumnHeader.RevenueHistory, 
        colspan: revenueColspan
      }
    ];

    const filtered = headers.filter((header) => header.colspan > 0);
    return filtered;
  }


  addPaidIncurredFilters(): CustomFilter {
    const filterDetails: CustomFilter = {
      filterType: 'toggleFilter',
      onValue: 'paid',
      offValue: 'incurred',
      onText: 'Claim Basis: Paid',
      offText: 'Claim Basis: Incurred',
      icon: 'pi pi-filter-fill',
      filterPredicate: this.toggleClaimBasisColumns.bind(this),
      initialValue: this.currentClaimBasis === 'paid'
    };
    
    return filterDetails;
  }

  public toggleClaimBasisColumns(schema: any, formControl: any, claimBasis: string): void {
    const isPaid = claimBasis === 'paid';
    
    const currentSchema = schema();
    
    if (!currentSchema?.columns) {
      return;
    }

    const updatedColumns = currentSchema.columns.map((column: any) => {
      if (column.name.endsWith('_paid')) {
        return { ...column, show: isPaid ? 'true' : 'false' };
      } else if (column.name.endsWith('_incurred')) {
        return { ...column, show: isPaid ? 'false' : 'true' };
      }
      return { ...column };
    });

    // Count visible columns for parent headers
    const visibleColumns = updatedColumns.filter((col: any) => col.show === 'true');
    const claimColumns = visibleColumns.filter((col: any) => 
      col.name.startsWith('claim_') && (col.name.endsWith('_paid') || col.name.endsWith('_incurred'))
    );
    const revenueColumns = visibleColumns.filter((col: any) => 
      col.name.startsWith('revenue_') && (col.name.endsWith('_paid') || col.name.endsWith('_incurred'))
    );

    // Recalculate parent headers
    const updatedParentHeaders = [
      { header: ColumnHeader.GroupExperience, colspan: 1 },
      { header: ColumnHeader.Enrollment, colspan: 2 },
      { 
        header: ColumnHeader.ClaimsHistory, 
        colspan: claimColumns.length
      },
      { 
        header: ColumnHeader.RevenueHistory, 
        colspan: revenueColumns.length
      }
    ].filter((header) => header.colspan > 0);

    schema.set({
      ...currentSchema,
      columns: updatedColumns,
      parentHeaders: updatedParentHeaders
    });
  }

  getClaimDateValidators() {
    return [
        { type: 'required' },
        { 
          type: 'uniqueValue',
          customFn: (...args) => {
            
            const { formValue, tableData, rowData } = args[0]
            
            if (!formValue) return true;
            
            // Count occurrences excluding the current row being edited
            const count = tableData.filter(item => {
              // Exclude the current row by comparing the entire row object
              if (rowData && item.claimDate === rowData.claimDate) {
                // This might be the same row, check if all properties match
                const isSameRow = Object.keys(rowData).every(k => {
                  if (k.endsWith('_original_path')) return true;
                  return item[k] === rowData[k];
                });
                if (isSameRow) return false; // Exclude current row
              }
              return item.claimDate === formValue;
            }).length;
            
            return count === 0; // Valid only if no other rows have this date
          }, 
          errorMessage: 'This date already exists'
        }, 
        {
          type: 'dateFormat',
          customFn: (...args) => {
            const { formValue } = args[0];
            if (!formValue) return true;
            
            return moment(formValue, 'YYYY-MM-DD', true).isValid();
          },
          errorMessage: 'Date must be in YYYY-MM-DD format'
        }
      ];
  }

  private getValueFromPath(path: string, row: any): any {
    if (!path || !row) return '';
    const value = row[path];
    return value !== undefined && value !== null ? value : '';
  }

  exportGroupExperience(data: ExperienceSummary[], schema: DataTableSchema): void {
      
      let columns = schema.columns || [];
      let parentHeaders = schema.parentHeaders || [];
  
      // Filter columns based on toggle and show property (matches UI)
      columns = columns.filter(col => col.show !== 'false');
  
      // Prepare header rows for Excel
      // 1. Parent header row (merged cells)
      // 2. Column header row
      const headerRow1 = [];
      const headerRow2 = [];
      let colIndex = 0;
      let merges = [];
      parentHeaders.forEach(parent => {
        const colspan = parent.colspan || 1;
        headerRow1.push(parent.header);
        for (let i = 1; i < colspan; i++) {
          headerRow1.push(null); // For merged cells
        }
        // Mark merge range for Excel
        if (colspan > 1) {
          merges.push({ s: { r: 0, c: colIndex }, e: { r: 0, c: colIndex + colspan - 1 } });
        }
        colIndex += colspan;
      });
      columns.forEach(col => headerRow2.push(col.header || col.name));
  
      // Prepare data rows
      const exportData = data.map(row => {
        const mappedRow = {};
        columns.forEach(col => {
          // Use getValueFromPath to match UI logic (handles nested/alternate nodes)
          mappedRow[col.header || col.name] = this.getValueFromPath(col.path, row);
        });
        return mappedRow;
      });
  
      // Build worksheet data: [parent header, column header, ...data]
      const wsData = [headerRow1, headerRow2, ...exportData.map(obj => columns.map(col => obj[col.header || col.name]))];
      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(wsData);
      if (merges.length) ws['!merges'] = merges;
      ws['!cols'] = columns.map(() => ({ wch: 18 }));
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'ExperienceSummary');
      XLSX.writeFile(wb, 'experience-summary.xlsx');
    }
  
}
