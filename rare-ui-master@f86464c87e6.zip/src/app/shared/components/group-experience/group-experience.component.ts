import { Component, input, output, model, effect, inject, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { GroupExperienceService } from './service/group-experience.service';
import { OpportunityType } from './constants/group-experience.constants';
import { Drawer, DrawerModule } from 'primeng/drawer';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { DataTableEditOveralyComponent } from '../data-table-edit-overaly/data-table-edit-overaly.component';
import { ExperienceExtractionProcessComponent } from '../experience-extraction-process/experience-extraction-process.component';
import { AuthenticationService } from '../../services';
import { ConfirmDialog } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';


@Component({
  selector: 'app-group-experience',
  imports: [CommonModule, FormsModule, TableModule, DrawerModule, 
    ToggleSwitchModule, DataTableEditOveralyComponent, ExperienceExtractionProcessComponent],
  templateUrl: './group-experience.component.html',
  styleUrl: './group-experience.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GroupExperienceComponent implements OnInit {
  @ViewChild('drawerRef') drawerRef!: Drawer;   
  
  private groupExperienceService = inject(GroupExperienceService);
  private cdr = inject(ChangeDetectorRef);
  private authService = inject(AuthenticationService);

  data = input.required<any>();
  oppType = input.required<OpportunityType.RenewalLocal | OpportunityType.NewBusinessLocal>();
  isGroupExperienceEditable = input.required<boolean>();
  tableData = model();
  groupExpChanged = output<any>();
  claimsBasisChanged = output<boolean>()

  selectedClaimsBasis: 'paid' | 'incurred' = 'paid';
  isPaidSelected: boolean = true;
  flatData: any[] = [];
  schema: any;
  editDrawerVisible = false;
  uploadDrawerVisible = false;

  buttonsToShow: string[] = [];
  private initialScrollY: number = 0;

  isAdminRole = this.authService.isUserRoleAdmin(this.authService.userRole.value);

  ngOnInit() {
    // Lock scroll position on component initialization
    this.initialScrollY = window.scrollY;
    window.scrollTo({ top: this.initialScrollY, behavior: 'instant' });
  }

  private oppTypeInputEffect = effect(() => {
    this.setButtonsToShow(this.oppType());
  }, { allowSignalWrites: true });
  private inputEffect = effect(() => {
    const scrollY = window.scrollY;
    const groupExpData = this.data();
    this.tableData.set(groupExpData);
    this.selectedClaimsBasis = groupExpData?.claimsBasis?.toLowerCase() ?? 'paid';
    this.isPaidSelected = this.selectedClaimsBasis === 'paid';

    this.flatData = this.groupExperienceService.getExperienceSummaryFlat(groupExpData);
    this.schema = this.groupExperienceService.prepareSchemaWithColumns(this.flatData, this.selectedClaimsBasis);
    
    // Restore scroll position after data update
    requestAnimationFrame(() => window.scrollTo({ top: scrollY, behavior: 'instant' }));
  }, { allowSignalWrites: true });

  onClaimsBasisChange() {
    this.selectedClaimsBasis = this.isPaidSelected ? 'paid' : 'incurred';
    this.schema = this.groupExperienceService.prepareSchemaWithColumns(this.flatData, this.selectedClaimsBasis);

    this.claimsBasisChanged.emit(this.isPaidSelected);
    this.cdr.markForCheck();
  }

  getVisibleColumnsCount(): number {
    if (!this.schema?.columns) {
      return 0;
    }
    
    return this.schema.parentHeaders.reduce((acc: number, header: any) => acc + (header.colspan ?? 1), 0);
  }

  tableDataChanged(event: any) {
    this.editDrawerVisible = false
    const savedData = event.data;
    const removedRows= event.deltedRows;
    const changedRows = event.changedRows;

    this.flatData = savedData;
    const currentOriginalData = {
      groupExperience : this.tableData()
    }
    const originalFormatData = this.groupExperienceService.updateOriginalData(currentOriginalData, changedRows, removedRows);
    this.tableData.set(originalFormatData);
    this.groupExpChanged.emit(originalFormatData);
    this.cdr.markForCheck();
  }

  uploadComplete(newData) {
    this.uploadDrawerVisible = false;
    this.tableData.set(newData.groupExperience);
    this.groupExpChanged.emit(newData.groupExperience);
    this.flatData = this.groupExperienceService.getExperienceSummaryFlat(newData.groupExperience);
    this.selectedClaimsBasis = newData.groupExperience.claimsBasis.toLowerCase();
    this.isPaidSelected = this.selectedClaimsBasis === 'paid';
    this.schema = this.groupExperienceService.prepareSchemaWithColumns(this.flatData, this.selectedClaimsBasis);
    this.editDrawerVisible = true;
    this.cdr.markForCheck();
  }

  setButtonsToShow(oppType: OpportunityType.RenewalLocal | OpportunityType.NewBusinessLocal) {
    if (this.isGroupExperienceEditable()) {
      if (oppType === OpportunityType.RenewalLocal) {
        this.buttonsToShow = ['export', 'edit'];
      } else {
        this.buttonsToShow = ['export', 'edit', 'upload'];
      }
    } else {
      this.buttonsToShow = [];
    }
  }

  experienceUploadDrawerClosed(e) {
    this.drawerRef.close(e);
  }

  exportToExcel() {
    this.groupExperienceService.exportGroupExperience(this.flatData, this.schema);
  }
}
