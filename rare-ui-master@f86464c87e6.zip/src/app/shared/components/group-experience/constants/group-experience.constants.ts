export interface HistoryAmount {
  claimDate: string;
  amount: number | string;
  [key: string]: any;
}

export interface EnrollmentHistoryEntry {
  amountBasis: string;
  amounts: HistoryAmount[];
  [key: string]: any;
}

export interface ClaimHistoryEntry {
  amountBasis: string;
  serviceType: string;
  classifications: string[];
  amounts: HistoryAmount[];
  [key: string]: any;
}

export interface RevenueHistoryEntry {
  dateBasis: string;
  type: string;
  amounts: HistoryAmount[];
  [key: string]: any;
}

export interface ExperienceSummary {
  claimDate: string;
  [key: string]: any;
}

export interface GroupExperience {
  enrollmentHistory?: EnrollmentHistoryEntry[];
  claimHistory?: ClaimHistoryEntry[];
  revenueHistory?: RevenueHistoryEntry[];
  [key: string]: any;
}

export interface NestedData {
  groupExperience?: GroupExperience;
  experienceSummary?: ExperienceSummary[];
  [key: string]: any;
}

export enum ColumnHeader {
  ExpDate = 'Exp Date',
  SubscriberCount = 'Subscriber Count',
  MemberCount = 'Member Count',
  GroupExperience = 'Group Experience',
  Enrollment = 'Enrollment',
  ClaimsHistory = 'Claims History',
  RevenueHistory = 'Revenue History'
}

export enum ColumnDefaults {
  ShowTrue = 'true',
  ShowFalse = 'false'
}

export enum OpportunityType {
  RenewalLocal = 'Renewal Local',
  NewBusinessLocal = 'New Business Local'
}