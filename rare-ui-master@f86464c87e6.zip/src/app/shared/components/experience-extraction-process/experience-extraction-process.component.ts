/**
 * Experience Extraction Component
 *
 * Unified UI component that provides a comprehensive interface for extracting and processing
 * group experience data from various sources (files, direct text input). Combines file upload,
 * text extraction, and LLM-based structured data extraction in a single workflow.
 *
 * Key Features:
 * - Multi-tab interface for file upload, text input, and configuration
 * - Two-step workflow: Extract text → Process with LLM
 * - Editable extracted text before processing
 * - Customizable system prompts and JSON schemas
 * - Support for PDF and Excel file formats
 * - Real-time progress feedback and error handling
 *
 * Workflow:
 * 1. User uploads file or enters text
 * 2. (File path) Extract text with layout preservation
 * 3. User can review/edit extracted text
 * 4. Process text through LLM with custom prompt/schema
 * 5. Display structured JSON results
 *
 * @author RARE UI Team
 * @since 2026
 */
import { DOCUMENT, CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, input, output, Renderer2, OnDestroy, effect, ViewChild, HostBinding } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { GroupExperienceExtractionResult, GroupExperienceExtractionRequest, SAMPLE_TEXT } from './constants/experience-extraction.constants';
import { ExperienceExtractionProcessService } from './service/experience-extraction-process.service';
import { ButtonModule } from 'primeng/button';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

@Component({
  selector: 'app-experience-extraction-process',
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    ConfirmDialogModule
  ],
  templateUrl: './experience-extraction-process.component.html',
  styleUrl: './experience-extraction-process.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ExperienceExtractionProcessComponent implements OnDestroy {
  @HostBinding('class.overlay-mode') get isOverlayMode() {
    return this.fromOverlay();
  }

  fromOverlay = input<boolean>(false);
  isAdminRole = input<boolean>(false);
  submitJson = output<unknown>();
  drawerClosed = output<unknown>();
 
  // File upload state
  /** Currently selected file for extraction */
  selectedFile: File | null = null;

  // Extraction results
  /** Extracted text from file (editable before processing) */
  extractedText: string = '';
  /** Final structured JSON output from LLM extraction */
  extractedJson: GroupExperienceExtractionResult | null = null;

  // UI state management
  /** Loading/processing indicator for async operations */
  isProcessing: boolean = false;
  /** Current step description shown to user during processing */
  currentStep: string = '';
  /** Progress percentage for processing steps */
  progressPercent: number = 0;
  /** Error message to display in alert */
  errorMessage: string = '';
  /** Success message to display in alert */
  successMessage: string = '';
  /** Countdown timer for auto-submission */
  redirectCountdown: number = 0;
  /** Timer interval reference */
  private countdownInterval: any = null;

  /** User input for specific page numbers to extract from PDF (e.g., "1,3-5,7") */
  pageNumbers: string = '';

  // Direct text input mode
  /** Active tab: 'file' for upload, 'text' for direct input, 'config' for settings */
  inputMode: 'file' | 'text' | 'config' = 'file';
  /** User-entered text for direct extraction (bypasses file upload) */
  textInput: string = '';
  /** Pre-populated sample text demonstrating expected input format */
  sampleText: string = SAMPLE_TEXT;
  // LLM configuration and customization
  /** Default system prompt loaded from backend */
  systemPrompt: string = '';
  /** User's customized version of system prompt (can be edited) */
  customPrompt: string = '';
  /** Flag indicating if user is currently editing the prompt */
  isEditingPrompt: boolean = false;

  /** Default extraction schema loaded from backend */
  extractionSchema: any = null; // Schema is dynamic, keep as any
  /** User's customized schema as JSON string (can be edited) */
  customSchema: string = '';
  /** Flag indicating if user is currently editing the schema */
  isEditingSchema: boolean = false;

  /** Toggle for showing/hiding prompt editor panel */
  showPromptEditor: boolean = false;
  /** Toggle for showing/hiding schema editor panel */
  showSchemaEditor: boolean = false;

  private cdr = inject(ChangeDetectorRef);
  private experienceExtractionService = inject(ExperienceExtractionProcessService);
  private renderer = inject(Renderer2);
  private document = inject(DOCUMENT);
  private confirmationService = inject(ConfirmationService);

  constructor() {
    effect(() => {
      if (this.fromOverlay()) {
        this.renderer.addClass(this.document.body, 'drawer-open');
      }
    });
  }
  
  /**
   * Angular lifecycle hook - called after component initialization.
   * Loads default system prompt and extraction schema from backend.
   */
  async ngOnInit(): Promise<void> {
    await this.loadPromptAndSchema();
  }

  ngOnDestroy(): void {
    if (this.fromOverlay()) {
      this.renderer.removeClass(this.document.body, 'drawer-open');
    }
    this.clearCountdown();
  }

  /**
   * Loads default system prompt and extraction schema from backend service.
   *
   * Initializes both the default values and the custom (editable) versions.
   * Users can modify the custom versions to tune extraction behavior.
   *
   * @throws Displays error message if loading fails
   */
  async loadPromptAndSchema(): Promise<void> {
    try {
      // Load default system prompt from backend
      this.systemPrompt = await firstValueFrom(this.experienceExtractionService.getSystemPrompt()) || '';
      this.customPrompt = this.systemPrompt;

      // Load default extraction schema from backend
      this.extractionSchema = await firstValueFrom(this.experienceExtractionService.getSchema());
      this.customSchema = JSON.stringify(this.extractionSchema, null, 2);
      this.cdr.markForCheck();
    } catch (error: any) {
      console.error('Error loading prompt and schema:', error);
      this.errorMessage = 'Failed to load prompt and schema from server';
      this.cdr.markForCheck();
    }
  }

  /**
   * Toggles visibility of the system prompt editor panel.
   * Resets edit mode when collapsing the panel.
   */
  togglePromptEditor(): void {
    this.showPromptEditor = !this.showPromptEditor;
    if (!this.showPromptEditor) {
      this.isEditingPrompt = false;
    }
  }

  /**
   * Toggles visibility of the extraction schema editor panel.
   * Resets edit mode when collapsing the panel.
   */
  toggleSchemaEditor(): void {
    this.showSchemaEditor = !this.showSchemaEditor;
    if (!this.showSchemaEditor) {
      this.isEditingSchema = false;
    }
  }

  /** Enables edit mode for system prompt */
  editPrompt(): void {
    this.isEditingPrompt = true;
  }

  /**
   * Saves the customized system prompt.
   * The updated prompt will be used in subsequent extractions.
   */
  savePrompt(): void {
    this.isEditingPrompt = false;
    this.successMessage = 'Prompt updated. It will be used in the next extraction.';
  }

  /**
   * Resets custom prompt to the default system prompt.
   * Discards any unsaved changes.
   */
  resetPrompt(): void {
    this.customPrompt = this.systemPrompt;
    this.isEditingPrompt = false;
    this.successMessage = 'Prompt reset to default.';
  }

  /** Enables edit mode for extraction schema */
  editSchema(): void {
    this.isEditingSchema = true;
  }

  /**
   * Saves the customized extraction schema after validating JSON syntax.
   * The updated schema will be used in subsequent extractions.
   *
   * @throws Displays error message if JSON is invalid
   */
  saveSchema(): void {
    try {
      // Validate that custom schema is valid JSON before saving
      JSON.parse(this.customSchema);
      this.isEditingSchema = false;
      this.successMessage = 'Schema updated. It will be used in the next extraction.';
    } catch (error: any) {
      this.errorMessage = 'Invalid JSON in schema: ' + error.message;
    }
  }

  /**
   * Resets custom schema to the default extraction schema.
   * Discards any unsaved changes.
   */
  resetSchema(): void {
    this.customSchema = JSON.stringify(this.extractionSchema, null, 2);
    this.isEditingSchema = false;
    this.successMessage = 'Schema reset to default.';
  }

  /**
   * Handles file selection from file input element.
   * Clears previous results and error messages when a new file is selected.
   *
   * @param event - File input change event containing selected file
   */
  onFileSelected(event: any): void {
    const file: File = event.target.files[0];

    if (file) {
      this.selectedFile = file;
      // Reset all previous results
      this.extractedText = '';
      this.extractedJson = null;
      this.errorMessage = '';
      this.successMessage = '';
      this.currentStep = '';
      this.progressPercent = 0;
    }
  }

  /**
   * Extracts text from the selected file without LLM processing.
   *
   * This is step 1 of the two-step workflow. The extracted text is displayed
   * in an editable textarea, allowing users to review and modify it before
   * sending to the LLM for structured extraction.
   *
   * Supports:
   * - Full PDF extraction or specific page ranges
   * - Excel spreadsheet extraction with table formatting
   * - Layout preservation for both formats
   *
   * @throws Displays error if no file selected or extraction fails
   */
  async extractFileOnly(): Promise<void> {
    if (!this.selectedFile) {
      this.errorMessage = 'Please select a file first';
      this.cdr.markForCheck();
      return;
    }

    this.isProcessing = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.extractedText = '';
    this.extractedJson = null;
    this.cdr.markForCheck();

    try {
      this.progressPercent = 30;
      this.currentStep = 'Extracting text from file...';
      this.cdr.markForCheck();
      let pages: number[] | undefined = undefined;

      // Parse page numbers if user specified specific pages for PDF
      if (this.pageNumbers.trim()) {
        try {
          pages = this.parsePageNumbers(this.pageNumbers);
        } catch (error: any) {
          this.errorMessage = error.message;
          this.isProcessing = false;
          this.cdr.markForCheck();
          return;
        }
      }

      // Extract text using service (handles both PDF and Excel)
      this.extractedText = await this.experienceExtractionService.extractFromFile(this.selectedFile, pages);
      this.cdr.markForCheck();

      if (!this.extractedText || this.extractedText.trim().length === 0) {
        throw new Error('No text could be extracted from the file');
      }

      this.progressPercent = 100;
      this.successMessage = `Successfully extracted text from ${this.selectedFile.name}`;
      this.currentStep = 'Text extracted. You can now process it or download it.';
      this.cdr.markForCheck();
    } catch (error: any) {
      console.error('File extraction failed:', error);
      this.errorMessage = error.message || 'Failed to extract text from file';
      this.currentStep = 'Failed';
      this.progressPercent = 0;
      this.cdr.markForCheck();
    } finally {
      this.isProcessing = false;
      this.cdr.markForCheck();
    }
  }

  /**
   * Performs complete extraction workflow: extract text from file and process with LLM.
   *
   * This is the one-click "Extract & Process" flow that combines:
   * 1. Text extraction from PDF/Excel with layout preservation
   * 2. LLM-based structured data extraction using configured prompt/schema
   *
   * The extracted text is stored but not displayed, going directly to LLM processing.
   * Users who want to review/edit text should use extractFileOnly() instead.
   *
   * @throws Displays error if no file selected, extraction fails, or LLM processing fails
   */
  async processFile(): Promise<void> {
    if (!this.selectedFile) {
      this.errorMessage = 'Please select a file first';
      this.cdr.markForCheck();
      return;
    }

    this.isProcessing = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.extractedText = '';
    this.extractedJson = null;
    this.cdr.markForCheck();

    try {
      // Step 1: Extract text from file
      this.progressPercent = 25;
      this.currentStep = 'Extracting text from file...';
      this.cdr.markForCheck();
      let pages: number[] | undefined = undefined;

      if (this.pageNumbers.trim()) {
        try {
          pages = this.parsePageNumbers(this.pageNumbers);
        } catch (error: any) {
          this.errorMessage = error.message;
          this.isProcessing = false;
          this.cdr.markForCheck();
          return;
        }
      }
      this.extractedText = await this.experienceExtractionService.extractFromFile(this.selectedFile, pages);
      this.cdr.markForCheck();

      if (!this.extractedText || this.extractedText.trim().length === 0) {
        throw new Error('No text could be extracted from the file');
      }

      // Step 2: Send extracted text to EHAP for group experience extraction
      this.progressPercent = 60;
      this.currentStep = 'Processing with Group Experience Extractor...';
      this.cdr.markForCheck();

      const request: GroupExperienceExtractionRequest = {
        text: this.extractedText,
        temperature: 0.1,
        max_tokens: 4000
      };

      // Add custom prompt if it differs from default
      if (this.customPrompt && this.customPrompt !== this.systemPrompt) {
        request.custom_prompt = this.customPrompt;
      }

      // Add custom schema only if it differs from default (backend will use default schema if not provided)
      try {
        const parsedCustomSchema = JSON.parse(this.customSchema);
        if (JSON.stringify(parsedCustomSchema) !== JSON.stringify(this.extractionSchema)) {
          request.custom_schema = parsedCustomSchema;
        }
      } catch (error) {
        console.warn('Could not parse custom schema, using default');
      }

      const response = await firstValueFrom(this.experienceExtractionService.extractFromText(request));
      this.cdr.markForCheck();

      if (response && response.success) {
        this.extractedJson = response.data;
        this.progressPercent = 100;
        this.successMessage = `Successfully extracted and processed ${this.selectedFile.name}`;
        this.currentStep = 'Complete!';
        if (this.fromOverlay()) {
          this.startRedirectCountdown();
        }
        this.cdr.markForCheck();
      } else {
        throw new Error(response?.error || 'Failed to extract group experience data');
      }

    } catch (error: any) {
      console.error('Combined extraction failed:', error);
      this.errorMessage = error.message || 'Failed to process file';
      this.currentStep = 'Failed';
      this.progressPercent = 0;
      this.cdr.markForCheck();
    } finally {
      this.isProcessing = false;
      this.cdr.markForCheck();
    }
  }

  /**
   * Parses page number input string into array of page numbers.
   *
   * Supports flexible input formats:
   * - Individual pages: "1, 3, 5"
   * - Ranges: "1-5, 10-15"
   * - Mixed: "1, 3-5, 7, 10-12"
   *
   * Automatically removes duplicates and sorts results.
   *
   * @param input - Comma-separated string of page numbers and ranges
   * @returns Sorted array of unique page numbers
   * @throws Error if input contains invalid numbers or ranges
   */
  parsePageNumbers(input: string): number[] {
    const pages: number[] = [];
    const parts = input.split(',');

    for (const part of parts) {
      const trimmed = part.trim();
      if (!trimmed) continue;

      if (trimmed.includes('-')) {
        // Handle range (e.g., "3-7")
        const [start, end] = trimmed.split('-').map(s => parseInt(s.trim()));
        if (isNaN(start) || isNaN(end) || start < 1 || end < start) {
          throw new Error(`Invalid page range: ${trimmed}`);
        }
        for (let i = start; i <= end; i++) {
          pages.push(i);
        }
      } else {
        // Handle individual page number
        const pageNum = parseInt(trimmed);
        if (isNaN(pageNum) || pageNum < 1) {
          throw new Error(`Invalid page number: ${trimmed}`);
        }
        pages.push(pageNum);
      }
    }

    // Remove duplicates and sort
    return [...new Set(pages)].sort((a, b) => a - b);
  }

  /**
   * Downloads the extracted text as a .txt file.
   * Generates a timestamped filename based on the original file name.
   */
  downloadExtractedText(): void {
    if (!this.extractedText || !this.selectedFile) {
      this.errorMessage = 'No text to download';
      return;
    }

    const fileName = this.experienceExtractionService.getTextFileName(this.selectedFile.name);
    this.experienceExtractionService.downloadAsTextFile(this.extractedText, fileName);
    this.successMessage = `Downloaded extracted text as ${fileName}`;
  }

  /**
   * Downloads the extracted structured data as a JSON file.
   * Formats JSON with 2-space indentation for readability.
   */
  downloadJson(): void {
    if (!this.extractedJson) {
      this.errorMessage = 'No JSON data to download';
      return;
    }

    const jsonString = JSON.stringify(this.extractedJson, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    const fileName = `group_experience_${timestamp}.json`;

    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();

    // Clean up temporary DOM elements
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    this.successMessage = `Downloaded JSON as ${fileName}`;
  }

  /**
   * Clears all form data, results, and messages.
   * Resets the component to its initial state.
   */
  clearAll(): void {
    this.clearCountdown();
    this.selectedFile = null;
    this.extractedText = '';
    this.extractedJson = null;
    this.errorMessage = '';
    this.successMessage = '';
    this.isProcessing = false;
    this.currentStep = '';
    this.progressPercent = 0;
    this.pageNumbers = '';
  }

  /** Returns true if a file is selected and not currently processing */
  get canProcess(): boolean {
    return !!this.selectedFile && !this.isProcessing;
  }

  /** Returns true if extracted text is available */
  get hasExtractedText(): boolean {
    return !!this.extractedText && this.extractedText.trim().length > 0;
  }

  /** Returns true if extracted JSON data is available */
  get hasExtractedJson(): boolean {
    return !!this.extractedJson;
  }

  /** Returns true if selected file is an Excel spreadsheet */
  get isExcelFile(): boolean {
    if (!this.selectedFile) return false;
    const fileName = this.selectedFile.name.toLowerCase();
    return fileName.endsWith('.xlsx') || fileName.endsWith('.xls');
  }

  /** Returns true if selected file is a PDF document */
  get isPdfFile(): boolean {
    if (!this.selectedFile) return false;
    const fileName = this.selectedFile.name.toLowerCase();
    return fileName.endsWith('.pdf');
  }

  /** Returns true if page number input should be shown (only for PDF files) */
  get showPageNumberInput(): boolean {
    return this.isPdfFile;
  }

  /**
   * Loads the pre-defined sample text into the text input field.
   * Useful for testing and demonstration purposes.
   */
  loadSampleText(): void {
    this.textInput = this.sampleText;
    this.successMessage = 'Sample text loaded. You can edit it or extract directly.';
    setTimeout(() => this.successMessage = '', 3000);
  }

  /**
   * Processes the extracted text (from file extraction) through the LLM.
   *
   * This is step 2 of the two-step workflow. After extracting text from a file,
   * users can review and edit it, then call this method to send it to the LLM
   * for structured data extraction.
   *
   * Uses the currently configured custom prompt and schema if they differ from defaults.
   *
   * @throws Displays error if no extracted text available or LLM processing fails
   */
  async processExtractedText(): Promise<void> {
    if (!this.extractedText.trim()) {
      this.errorMessage = 'No extracted text to process!';
      this.cdr.markForCheck();
      return;
    }

    this.isProcessing = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.extractedJson = null;
    this.progressPercent = 50;
    this.currentStep = 'Processing extracted text with Group Experience Extractor...';
    this.cdr.markForCheck();

    try {
      // Build extraction request with LLM parameters
      const request: GroupExperienceExtractionRequest = {
        text: this.extractedText,
        temperature: 0.1,    // Low temperature for consistent, factual extraction
        max_tokens: 4000     // Sufficient for complex structured outputs
      };

      // Include custom prompt if user has modified it
      if (this.customPrompt && this.customPrompt !== this.systemPrompt) {
        request.custom_prompt = this.customPrompt;
      }

      // Include custom schema if user has modified it
      try {
        const parsedCustomSchema = JSON.parse(this.customSchema);
        if (JSON.stringify(parsedCustomSchema) !== JSON.stringify(this.extractionSchema)) {
          request.custom_schema = parsedCustomSchema;
        }
      } catch (error) {
        // Could not parse custom schema, using default
      }

      const response = await firstValueFrom(this.experienceExtractionService.extractFromText(request));
      this.cdr.markForCheck();

      if (response && response.success) {
        this.extractedJson = response.data;
        this.progressPercent = 100;
        this.successMessage = 'Successfully extracted group experience data from text';
        this.currentStep = 'Complete!';
        this.cdr.markForCheck();
      } else {
        throw new Error(response?.error || 'Failed to extract group experience data');
      }
    } catch (error: any) {
      console.error('Text extraction failed:', error);
      this.errorMessage = error.message || 'Failed to process text';
      this.currentStep = 'Failed';
      this.progressPercent = 0;
      this.cdr.markForCheck();
    } finally {
      this.isProcessing = false;
      this.cdr.markForCheck();
    }
  }

  async extractFromText(): Promise<void> {
    if (!this.textInput.trim()) {
      this.errorMessage = 'Please enter some text first!';
      this.cdr.markForCheck();
      return;
    }

    this.isProcessing = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.extractedJson = null;
    this.extractedText = '';
    this.progressPercent = 50;
    this.currentStep = 'Processing text with Group Experience Extractor...';
    this.cdr.markForCheck();

    try {
      const request: GroupExperienceExtractionRequest = {
        text: this.textInput,
        temperature: 0.1,
        max_tokens: 4000
      };

      // Add custom prompt if it differs from default
      if (this.customPrompt && this.customPrompt !== this.systemPrompt) {
        request.custom_prompt = this.customPrompt;
      }

      // Add custom schema only if it differs from default (backend will use default schema if not provided)
      try {
        const parsedCustomSchema = JSON.parse(this.customSchema);
        if (JSON.stringify(parsedCustomSchema) !== JSON.stringify(this.extractionSchema)) {
          request.custom_schema = parsedCustomSchema;
        }
      } catch (error) {
        // Could not parse custom schema, using default
      }

      const response = await firstValueFrom(this.experienceExtractionService.extractFromText(request));
      this.cdr.markForCheck();

      if (response && response.success) {
        this.extractedJson = response.data;
        this.extractedText = this.textInput;
        this.progressPercent = 100;
        this.successMessage = 'Successfully extracted group experience data from text';
        this.currentStep = 'Complete!';
        if (this.fromOverlay()) {
          this.startRedirectCountdown();
        }
        this.cdr.markForCheck();
      } else {
        throw new Error(response?.error || 'Failed to extract group experience data');
      }
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to process text';
      this.currentStep = 'Failed';
      this.progressPercent = 0;
      this.cdr.markForCheck();
    } finally {
      this.isProcessing = false;
      this.cdr.markForCheck();
    }
  }

  done() {
    this.clearCountdown();
    this.submitJson.emit(this.extractedJson);
  }

  /**
   * Starts a countdown timer that counts up from 0 to 5 seconds,
   * then automatically submits the extracted JSON data.
   */
  private startRedirectCountdown(): void {
    this.clearCountdown();
    this.redirectCountdown = 0;
    this.cdr.markForCheck();

    this.countdownInterval = setInterval(() => {
      this.redirectCountdown++;
      this.cdr.markForCheck();

      if (this.redirectCountdown >= 5) {
        this.clearCountdown();
        if (this.fromOverlay()) {
          this.done();
        }
      }
    }, 1000);
  }

  /**
   * Clears the countdown timer interval.
   */
  private clearCountdown(): void {
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
      this.countdownInterval = null;
    }
    this.redirectCountdown = 0;
  }

  closeCallback(e) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to close?',
      header: 'Confirmation',
      key: 'experienceExtractorClose',
      acceptButtonStyleClass: 'dialog-button-icon',
      rejectButtonStyleClass: 'dialog-button-icon',
      accept: () => {
        this.drawerClosed.emit(e);
      }
    });
  }
}
