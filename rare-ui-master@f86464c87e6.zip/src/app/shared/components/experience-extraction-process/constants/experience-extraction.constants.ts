// Interfaces for Experience Extraction

export interface GroupExperienceExtractionResult {
  // Define the expected structure of the extracted JSON result
  // Example fields (customize as needed):
  experienceMonth?: number;
  experienceYear?: number;
  claimsBasis?: string;
  coveragePeriods?: Array<{
    periodId: number;
    startDate: string;
    endDate: string;
  }>;
  enrollmentData?: Array<{
    month: string;
    members: number;
  }>;
  medicalClaimsSummary?: {
    serviceType: string;
    totalClaims: number;
  };
  largeClaimantInformation?: Array<{
    lastCoverage: string;
    topDiagnosis: string;
    code: string;
    amount: number;
  }>;
  revenueInformation?: {
    totalRevenue: number;
  };
  // Add more fields as needed based on actual schema
}

export interface GroupExperienceExtractionRequest {
  text: string;
  temperature: number;
  max_tokens: number;
  custom_prompt?: string;
  custom_schema?: any; // Can be improved if schema structure is known
}

/** Pre-populated sample text demonstrating expected input format */
export const SAMPLE_TEXT: string = `Group Experience Report - December 2024

Experience Month: 12
Experience Year: 2024
Claims Basis: Incurred

Coverage Period Information:
- Period ID: 1
- Start Date: 2024-01-01
- End Date: 2024-12-31

Enrollment Data (Monthly Average):
- January 2024: 1,250 members
- February 2024: 1,275 members
- March 2024: 1,300 members

Medical Claims Summary:
- Service Type: Medical
- Total Claims: $2,500,000

Large Claimant Information:
- Last Coverage: December 2024
- Top Diagnosis: Type 2 Diabetes (Code: E11.9) - Amount: $125,000

Revenue Information:
- Total Revenue: $3,000,000` as const;
