/**
 * Experience Extraction Service
 *
 * Unified service that combines group experience data extraction with file parsing capabilities.
 * Handles both backend LLM-based extraction and frontend file text extraction from PDF and Excel files.
 *
 * Key Features:
 * - LLM-based structured data extraction via backend EHAP service
 * - PDF text extraction with layout preservation and OCR fallback
 * - Excel spreadsheet parsing with table structure detection
 * - Advanced column boundary detection for tabular data
 * - Support for custom extraction schemas and prompts
 *
 * @author RARE UI Team
 * @since 2026
 */
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as pdfjsLib from 'pdfjs-dist';
import * as XLSX from 'xlsx';
import { OcrService } from '../../../services/ocr.service';
import { CommonService } from '../../../services/common.service';

@Injectable({
  providedIn: 'root'
})
export class ExperienceExtractionProcessService {
  /** Base URL path for EHAP backend API endpoints */
  private baseUrl = '/ehap';

  /**
   * Initializes the ExperienceExtractionService and configures PDF.js worker.
   *
   * The PDF.js worker is loaded from local assets rather than CDN to ensure:
   * - Compatibility with base href configurations
   * - Support for CDN and subdirectory deployments
   * - No external dependencies at runtime
   *
   * @param http - Angular HttpClient for making API requests
   * @param commonService - Service providing dynamic URL construction
   * @param ocrService - Service for OCR processing of scanned documents
   */
  constructor(
    private http: HttpClient,
    private commonService: CommonService,
    private ocrService: OcrService
  ) {
    // Configure PDF.js worker path dynamically based on application base href
    // This ensures the worker loads correctly regardless of deployment configuration
    const baseHref = document.getElementsByTagName('base')[0]?.href || window.location.origin;
    pdfjsLib.GlobalWorkerOptions.workerSrc = `${baseHref}assets/pdfjs/pdf.worker.min.mjs`;
  }

  // ========== LLM Extraction Methods (Backend Integration) ==========

  /**
   * Extracts structured group experience data from plain text using backend LLM service.
   *
   * Sends the provided text to the EHAP backend service which uses a Large Language Model
   * to parse and extract structured information according to the defined schema.
   *
   * @param request - Extraction request containing:
   *   - text: The raw text to extract data from
   *   - custom_prompt: (Optional) Custom system prompt to override default
   *   - custom_schema: (Optional) Custom JSON schema for extraction structure
   * @returns Observable containing extraction response with success status and extracted data
   */
  extractFromText(request: any): Observable<any> {
    return this.http.post(`${this.commonService.getRareUiUrl() + this.baseUrl}/extraction/extract`, request);
  }

  /**
   * Extracts structured data directly from a file using backend service.
   *
   * The backend handles file parsing and LLM-based extraction in a single step.
   * This is an alternative to the two-step process of frontend extraction followed by LLM processing.
   *
   * @param file - The file to extract data from (PDF or Excel)
   * @param request - (Optional) Additional extraction parameters (custom prompt/schema)
   * @returns Observable containing extraction response with success status and extracted data
   */
  extractFromFileToLLM(file: File, request?: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    if (request) {
      formData.append('request', JSON.stringify(request));
    }
    return this.http.post(`${this.commonService.getRareUiUrl() + this.baseUrl}/extraction/extractFile`, formData);
  }

  /**
   * Retrieves the default extraction schema from the backend.
   *
   * The schema defines the structure of data to be extracted, including field names,
   * types, and validation rules. Users can view and customize this schema.
   *
   * @returns Observable containing the JSON schema object
   */
  getSchema(): Observable<any> {
    return this.http.get(`${this.commonService.getRareUiUrl() + this.baseUrl}/extraction/schema`);
  }

  /**
   * Retrieves the default system prompt used by the LLM for extraction.
   *
   * The system prompt provides instructions to the LLM on how to parse and extract
   * information from the provided text. Users can customize this prompt for specific use cases.
   *
   * @returns Observable containing the system prompt as a string
   */
  getSystemPrompt(): Observable<string> {
    return this.http.get(`${this.commonService.getRareUiUrl() + this.baseUrl}/extraction/prompt`, { responseType: 'text' });
  }

  // ========== File Extraction Methods (Frontend Text Parsing) ==========

  /**
   * Main entry point for extracting text from uploaded files.
   *
   * Determines the file type and delegates to the appropriate extraction method.
   * Supports PDF files (with optional page selection) and Excel spreadsheets.
   *
   * @param file - The file to extract text from
   * @param pageNumbers - (Optional) Specific page numbers to extract from PDF files.
   *                      If not provided, all pages will be extracted.
   * @returns Promise resolving to the extracted text with preserved layout
   * @throws Error if the file type is not supported
   */
  async extractFromFile(file: File, pageNumbers?: number[]): Promise<string> {
    const fileType = this.getFileType(file);
    switch (fileType) {
      case 'pdf':
        return await this.extractFromPdf(file, pageNumbers);
      case 'excel':
        return await this.extractFromExcel(file);
      default:
        throw new Error(`Unsupported file type: ${file.type}`);
    }
  }

  /**
   * Determines the file type based on MIME type and file extension.
   *
   * Uses both MIME type and file extension for robust detection, as some browsers
   * may not provide accurate MIME types for all file formats.
   *
   * @param file - The file to identify
   * @returns The identified file type: 'pdf', 'excel', or 'unknown'
   */
  private getFileType(file: File): 'pdf' | 'excel' | 'unknown' {
    const fileName = file.name.toLowerCase();
    const fileType = file.type.toLowerCase();

    // Check for PDF files
    if (fileType === 'application/pdf' || fileName.endsWith('.pdf')) {
      return 'pdf';
    }

    // Check for Excel files (both .xlsx and legacy .xls formats)
    if (
      fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      fileType === 'application/vnd.ms-excel' ||
      fileName.endsWith('.xlsx') ||
      fileName.endsWith('.xls')
    ) {
      return 'excel';
    }

    return 'unknown';
  }

  /**
   * Extracts text from PDF files with advanced layout preservation.
   *
   * Uses PDF.js to parse the PDF and extract text while maintaining spatial relationships.
   * Implements sophisticated column detection to preserve table structures and multi-column layouts.
   * Falls back to OCR for scanned or image-based PDFs when no embedded text is found.
   *
   * Process:
   * 1. Load and parse PDF using PDF.js
   * 2. Validate and filter requested page numbers
   * 3. Extract text items with positional information
   * 4. Apply layout analysis to detect columns and tables
   * 5. If no text found, attempt OCR extraction
   *
   * @param file - The PDF file to extract text from
   * @param pageNumbers - (Optional) Specific page numbers to extract (1-indexed).
   *                      If not provided or empty, all pages will be extracted.
   * @returns Promise resolving to formatted text with preserved layout
   * @throws Error if PDF loading fails or invalid page numbers are specified
   */
  private async extractFromPdf(file: File, pageNumbers?: number[]): Promise<string> {
    try {
      // Load PDF file into memory as binary data
      const arrayBuffer = await file.arrayBuffer();

      // Initialize PDF.js document loader
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;

      // Validate and determine which pages to extract
      let pagesToExtract: number[];
      if (pageNumbers && pageNumbers.length > 0) {
        // Validate that all requested pages exist in the document
        const invalidPages = pageNumbers.filter(p => p < 1 || p > pdf.numPages);
        if (invalidPages.length > 0) {
          throw new Error(`Invalid page numbers: ${invalidPages.join(', ')}. PDF has ${pdf.numPages} pages.`);
        }
        pagesToExtract = pageNumbers;
      } else {
        // Extract all pages if none specified
        pagesToExtract = Array.from({ length: pdf.numPages }, (_, i) => i + 1);
      }

      // Initialize extraction state tracking
      let fullText = '';
      let totalTextItems = 0;  // Count of all text items found across pages
      let hasAnyText = false;   // Flag to track if any actual text content was found

      // Build document header with metadata
      fullText += `PDF Document: ${file.name}\n`;
      fullText += `Total Pages: ${pdf.numPages}\n`;
      if (pageNumbers && pageNumbers.length > 0) {
        fullText += `Extracting Pages: ${pagesToExtract.join(', ')}\n`;
      }
      fullText += `${'='.repeat(60)}\n\n`;

      // Process each page sequentially
      for (const pageNum of pagesToExtract) {
        // Load page and extract text content with positioning data
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        const viewport = page.getViewport({ scale: 1.0 });

        totalTextItems += textContent.items.length;

        fullText += `--- Page ${pageNum} ---\n\n`;

        // Check if page contains embedded text
        if (textContent.items.length === 0) {
          fullText += '(No embedded text found on this page)\n\n';
          continue;
        }

        // Apply advanced layout analysis to preserve structure
        const pageText = this.extractTextWithLayout(textContent.items, viewport);

        if (pageText && pageText.trim()) {
          hasAnyText = true;
          fullText += pageText + '\n\n';
        } else {
          fullText += '(Text items present but empty)\n\n';
        }
      }

      // Handle scanned/image-based PDFs with OCR fallback
      if (totalTextItems === 0 || !hasAnyText) {
        // Attempt OCR extraction for scanned documents
        try {
          const ocrText = await this.extractWithOcr(pdf, file.name, pagesToExtract);
          if (ocrText && ocrText.trim().length > 0) {
            return ocrText;
          }
        } catch (ocrError: any) {
          console.error('OCR extraction failed:', ocrError);
        }

        // Provide helpful message when no text can be extracted
        fullText += '\n\n' + '='.repeat(60) + '\n';
        fullText += 'WARNING: This PDF appears to be scanned or image-based.\n';
        fullText += 'No embedded text was found.\n\n';

        if (!this.ocrService.isOcrConfigured()) {
          fullText += 'OCR is not configured. To enable OCR extraction:\n';
          fullText += '1. Configure OCR service in ocr.service.ts\n';
          fullText += '2. Add your OCR API endpoint and credentials\n\n';
        }

        fullText += 'Alternative options:\n';
        fullText += '1. Use an online OCR service (e.g., Adobe Acrobat, Google Drive)\n';
        fullText += '2. Convert the PDF using OCR software before uploading\n';
        fullText += '3. Contact your administrator to enable OCR support\n';
      }
      return fullText;
    } catch (error: any) {
      console.error('PDF extraction error:', error);
      throw new Error(`Failed to extract text from PDF: ${error.message}`);
    }
  }

  /**
   * Extracts text from Excel spreadsheet files with table formatting.
   *
   * Parses Excel files (.xlsx and .xls) and converts each sheet into formatted text
   * with column alignment and visual separators. Preserves table structure by calculating
   * optimal column widths and aligning cell content.
   *
   * Features:
   * - Supports both modern (.xlsx) and legacy (.xls) formats
   * - Processes multiple sheets within a workbook
   * - Dynamic column width calculation for readability
   * - Table borders using ASCII characters
   * - Date formatting preservation
   *
   * @param file - The Excel file to extract text from
   * @returns Promise resolving to formatted text representation of all sheets
   * @throws Error if Excel parsing fails
   */
  private async extractFromExcel(file: File): Promise<string> {
    try {
      // Load Excel file into memory
      const arrayBuffer = await file.arrayBuffer();

      // Parse workbook with date preservation
      const workbook = XLSX.read(arrayBuffer, { type: 'array', cellDates: true });

      // Build document header
      let fullText = '';
      fullText += `Excel Document: ${file.name}\n`;
      fullText += `Total Sheets: ${workbook.SheetNames.length}\n`;
      fullText += `${'='.repeat(60)}\n\n`;

      // Process each sheet in the workbook
      workbook.SheetNames.forEach((sheetName, index) => {
        const worksheet = workbook.Sheets[sheetName];

        fullText += `--- Sheet ${index + 1}: ${sheetName} ---\n\n`;

        // Get sheet dimensions
        const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1');
        const numCols = range.e.c - range.s.c + 1;
        const numRows = range.e.r - range.s.r + 1;

        if (numRows === 0) {
          fullText += '(Empty sheet)\n\n';
          return;
        }

        // Convert sheet to 2D array format, preserving empty cells
        const jsonData = XLSX.utils.sheet_to_json(worksheet, {
          header: 1,          // Return array of arrays instead of objects
          defval: '',         // Use empty string for empty cells
          raw: false,         // Format values as strings
          blankrows: true     // Include blank rows in output
        });

        if (jsonData.length === 0) {
          fullText += '(Empty sheet)\n\n';
          return;
        }

        // Calculate optimal column widths for alignment
        // Scan all rows to find maximum content width per column
        const colWidths: number[] = new Array(numCols).fill(0);
        jsonData.forEach((row: any[]) => {
          for (let i = 0; i < Math.min(row.length, numCols); i++) {
            const cellValue = String(row[i] || '').trim();
            colWidths[i] = Math.max(colWidths[i], cellValue.length);
          }
        });

        // Detect if first row contains headers (starts with alphabetic characters)
        const firstRow = jsonData[0] as any[];
        const hasHeaders = firstRow && firstRow.some((cell: any) => {
          const str = String(cell || '').trim();
          return str.length > 0 && /^[A-Za-z]/.test(str);
        });

        // Format and output each row with proper column alignment
        jsonData.forEach((row: any[], rowIndex) => {
          // Ensure row has cells for all columns
          const paddedRow = [...row];
          while (paddedRow.length < numCols) {
            paddedRow.push('');
          }

          // Format each cell with padding to match column width
          const formattedCells = paddedRow.slice(0, numCols).map((cell, colIndex) => {
            const cellValue = String(cell || '').trim();
            const width = Math.max(colWidths[colIndex], 3);
            return cellValue.padEnd(width, ' ');
          });

          fullText += `${formattedCells.join(' | ')}\n`;

          // Add separator line after header row if headers detected
          if (rowIndex === 0 && hasHeaders) {
            const separator = colWidths.slice(0, numCols).map(width =>
              '-'.repeat(Math.max(width, 3))
            ).join('-+-');
            fullText += `${separator}\n`;
          }
        });

        fullText += '\n';
        fullText += `Table Structure: ${numRows} rows × ${numCols} columns\n\n`;
      });

      return fullText;
    } catch (error: any) {
      console.error('Excel extraction error:', error);
      throw new Error(`Failed to extract text from Excel: ${error.message}`);
    }
  }

  /**
   * Triggers a browser download of extracted text content as a .txt file.
   *
   * Creates a temporary blob and link element to initiate the download,
   * then cleans up resources after the download begins.
   *
   * @param content - The text content to save
   * @param fileName - The name for the downloaded file
   */
  downloadAsTextFile(content: string, fileName: string): void {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();

    // Clean up temporary elements and URLs
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  /**
   * Generates a timestamped filename for extracted text output.
   *
   * Removes the original file extension and appends a timestamp to ensure
   * unique filenames and avoid overwriting existing downloads.
   *
   * @param originalFileName - The original uploaded file name
   * @returns Generated filename in format: originalname_extracted_YYYY-MM-DDTHH-MM-SS.txt
   */
  getTextFileName(originalFileName: string): string {
    const nameWithoutExt = originalFileName.replace(/\.[^/.]+$/, '');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    return `${nameWithoutExt}_extracted_${timestamp}.txt`;
  }

  /**
   * Extracts text from a PDF page while preserving spatial layout and structure.
   *
   * This is the main orchestrator for layout-aware text extraction. It processes
   * raw PDF text items through multiple stages to detect and preserve document structure:
   * 1. Enrich items with positional metadata
   * 2. Group items into horizontal rows
   * 3. Detect column boundaries using histogram analysis
   * 4. Build formatted output with proper column alignment
   *
   * @param items - Raw text items from PDF.js containing text and transform data
   * @param viewport - PDF page viewport (currently unused but available for future enhancements)
   * @returns Formatted text string with preserved layout and column structure
   */
  private extractTextWithLayout(items: any[], viewport: any): string {
    if (!items || items.length === 0) {
      return '';
    }

    const enrichedItems = this.enrichTextItems(items);
    const rows = this.groupItemsIntoRows(enrichedItems);
    const columnBoundaries = this.detectColumnBoundariesAdvanced(rows);

    return this.buildTableOutput(rows, columnBoundaries);
  }

  /**
   * Enriches raw PDF text items with computed positional metadata.
   *
   * Extracts key information from PDF.js transform matrices and calculates derived
   * properties needed for layout analysis. The transform matrix format is:
   * [scaleX, skewY, skewX, scaleY, translateX, translateY]
   *
   * Computed properties:
   * - fontSize: Extracted from vertical scale (transform[0])
   * - x, y: Absolute position on page
   * - endX: Right edge position (x + width)
   * - width, height: Text bounding box dimensions
   *
   * @param items - Raw text items from PDF.js getTextContent()
   * @returns Array of enriched items with normalized positional data
   */
  private enrichTextItems(items: any[]): any[] {
    return items
      .filter(item => item.str && item.transform)
      .map(item => {
        // Extract font size from transform matrix
        const fontSize = Math.abs(item.transform[0]) || 12;
        // Get absolute position from transform matrix
        const x = item.transform[4];
        const y = item.transform[5];
        const width = item.width || 0;

        return {
          text: item.str.trim(),
          x: x,
          y: y,
          width: width,
          fontSize: fontSize,
          endX: x + width,
          height: item.height || fontSize
        };
      })
      .filter(item => item.text.length > 0);
  }

  /**
   * Groups text items into horizontal rows based on Y-coordinate proximity.
   *
   * Uses fuzzy matching with font-size-based tolerance to handle minor vertical
   * misalignments that occur in real PDFs. Items within the tolerance range of
   * an existing row are assigned to that row.
   *
   * Algorithm:
   * 1. For each text item, calculate tolerance based on its font size
   * 2. Search for existing row within tolerance range
   * 3. If found, add to existing row; otherwise create new row
   * 4. Sort items within each row left-to-right by X position
   *
   * The tolerance of 40% font size handles typical baseline variations while
   * preventing items from different lines being grouped together.
   *
   * @param items - Enriched text items with positional data
   * @returns Map of Y-coordinates to arrays of text items in that row
   */
  private groupItemsIntoRows(items: any[]): Map<number, any[]> {
    const rows: Map<number, any[]> = new Map();

    items.forEach(item => {
      // Calculate tolerance: 40% of font size, minimum 3 pixels
      const tolerance = Math.max(item.fontSize * 0.4, 3);

      let rowY = item.y;
      let foundRow = false;

      // Search for existing row within tolerance
      for (const existingY of rows.keys()) {
        if (Math.abs(existingY - item.y) < tolerance) {
          rowY = existingY;
          foundRow = true;
          break;
        }
      }

      // Create new row if none found within tolerance
      if (!foundRow) {
        rows.set(rowY, []);
      }

      rows.get(rowY)!.push(item);
    });

    // Sort items within each row from left to right
    rows.forEach(rowItems => {
      rowItems.sort((a, b) => a.x - b.x);
    });

    return rows;
  }

  /**
   * Detects column boundaries in tabular PDF content using histogram-based peak detection.
   *
   * This advanced algorithm identifies vertical alignment patterns by analyzing the X-coordinates
   * where text items begin across multiple rows. Column boundaries are detected as "peaks" in
   * a histogram of X-positions - locations where many text items start.
   *
   * Algorithm Steps:
   * 1. Collect all X-start positions from text items across all rows
   * 2. Build histogram with 2-pixel bins to group nearby positions
   * 3. Identify peaks (local maxima) that appear in at least 25% of rows
   * 4. Merge peaks within 8 pixels to handle minor alignment variations
   * 5. Return averaged X-coordinates representing column boundaries
   *
   * This approach handles:
   * - Multi-column layouts (2-column, 3-column, etc.)
   * - Tables with varying cell content
   * - Minor alignment inconsistencies in source PDFs
   * - Mixed single and multi-column content on same page
   *
   * @param rows - Map of Y-coordinates to arrays of text items
   * @returns Array of X-coordinates representing detected column boundaries, sorted left to right
   */
  private detectColumnBoundariesAdvanced(rows: Map<number, any[]>): number[] {
    // Collect all X-start positions and text items
    const xStarts: number[] = [];
    const allItems: any[] = [];

    rows.forEach(rowItems => {
      rowItems.forEach(item => {
        xStarts.push(item.x);
        allItems.push(item);
      });
    });

    if (xStarts.length === 0) return [];

    // Build histogram with 2-pixel bins to cluster nearby positions
    const binSize = 2;
    const histogram = new Map<number, number>();

    xStarts.forEach(x => {
      const bin = Math.round(x / binSize) * binSize;
      histogram.set(bin, (histogram.get(bin) || 0) + 1);
    });

    const sortedBins = Array.from(histogram.entries())
      .sort((a, b) => a[0] - b[0]);

    // Identify peaks (local maxima) in the histogram
    const peaks: number[] = [];
    // Require peak to appear in at least 25% of rows (min 2 rows)
    const minPeakHeight = Math.max(rows.size * 0.25, 2);

    for (let i = 0; i < sortedBins.length; i++) {
      const [bin, count] = sortedBins[i];

      const prevCount = i > 0 ? sortedBins[i - 1][1] : 0;
      const nextCount = i < sortedBins.length - 1 ? sortedBins[i + 1][1] : 0;

      // Peak must be higher than neighbors and meet minimum threshold
      if (count >= minPeakHeight && count >= prevCount && count >= nextCount) {
        peaks.push(bin);
      }
    }

    // Merge nearby peaks (within 8 pixels) to handle minor alignment variations
    const mergedPeaks: number[] = [];
    if (peaks.length > 0) {
      let currentPeak = peaks[0];
      let peakSum = peaks[0];
      let peakCount = 1;

      for (let i = 1; i < peaks.length; i++) {
        // If peak is within 8 pixels of current cluster, add to cluster
        if (peaks[i] - currentPeak < 8) {
          peakSum += peaks[i];
          peakCount++;
        } else {
          // Finalize current cluster by averaging and start new cluster
          const avgPeak = Math.round(peakSum / peakCount);
          mergedPeaks.push(avgPeak);
          currentPeak = peaks[i];
          peakSum = peaks[i];
          peakCount = 1;
        }
      }

      // Don't forget the final cluster
      if (peakCount > 0) {
        const avgPeak = Math.round(peakSum / peakCount);
        mergedPeaks.push(avgPeak);
      }
    }

    return mergedPeaks;
  }

  /**
   * Builds formatted text output with column alignment using detected boundaries.
   *
   * Assigns each text item to the appropriate column based on its X-position relative to
   * column boundaries, then formats the output with pipe separators between columns.
   *
   * Column Assignment Logic:
   * - If only one column boundary detected, items within 15 pixels are assigned to it
   * - For multiple boundaries, items are assigned to nearest column using midpoint calculation
   * - Items between columns are assigned based on which boundary they're closer to
   *
   * @param rows - Map of Y-coordinates to arrays of text items in each row
   * @param columnBoundaries - Array of X-coordinates representing column start positions
   * @returns Formatted text with columns separated by " | " delimiters
   */
  private buildTableOutput(rows: Map<number, any[]>, columnBoundaries: number[]): string {
    // Sort rows from top to bottom (PDF Y-coordinates increase downward)
    const sortedRows = Array.from(rows.entries()).sort((a, b) => b[0] - a[0]);

    // If no columns detected, just join text items with spaces
    if (columnBoundaries.length === 0) {
      return sortedRows.map(([_, rowItems]) =>
        rowItems.map(item => item.text).join(' ')
      ).join('\n');
    }

    const result: string[] = [];

    // Process each row and assign items to columns
    sortedRows.forEach(([_, rowItems]) => {
      const columnTexts: string[] = new Array(columnBoundaries.length).fill('');

      rowItems.forEach(item => {
        let columnIndex = 0;

        // Determine which column this item belongs to
        for (let i = 0; i < columnBoundaries.length; i++) {
          // Special handling for last column
          if (i === columnBoundaries.length - 1) {
            if (Math.abs(item.x - columnBoundaries[i]) < 15) {
              columnIndex = i;
            }
            break;
          }

          // Calculate midpoint between current and next boundary
          const currentBoundary = columnBoundaries[i];
          const nextBoundary = columnBoundaries[i + 1];
          const midpoint = (currentBoundary + nextBoundary) / 2;

          // Assign to column based on position relative to midpoint
          if (item.x < midpoint) {
            columnIndex = i;
            break;
          } else {
            columnIndex = i + 1;
          }
        }

        // Append text to appropriate column, adding space if column already has content
        if (columnTexts[columnIndex]) {
          columnTexts[columnIndex] += ' ' + item.text;
        } else {
          columnTexts[columnIndex] = item.text;
        }
      });

      // Format row with pipe delimiters between columns
      const rowText = columnTexts
        .map(col => col.trim())
        .filter(col => col.length > 0)
        .join(' | ');

      if (rowText) {
        result.push(rowText);
      }
    });

    return result.join('\n');
  }

  /**
   * Extracts text from scanned/image-based PDFs using Optical Character Recognition.
   *
   * When a PDF contains no embedded text (scanned documents, images), this method
   * renders each page to a canvas and uses an OCR service to extract visible text.
   * Uses 2.0x scale for better OCR accuracy on low-resolution scans.
   *
   * Process:
   * 1. Render each PDF page to an HTML5 canvas at 2x scale
   * 2. Convert canvas to base64-encoded PNG image
   * 3. Send image to OCR service for text extraction
   * 4. Apply table structure detection to OCR results
   * 5. Compile all pages into formatted text output
   *
   * @param pdf - Loaded PDF.js document object
   * @param fileName - Original filename for document header
   * @param pagesToExtract - Array of specific page numbers to extract (1-indexed). If not provided, all pages extracted.
   * @returns Promise resolving to OCR-extracted text from specified pages
   */
  private async extractWithOcr(pdf: any, fileName: string, pagesToExtract?: number[]): Promise<string> {
    let fullText = '';
    fullText += `PDF Document (OCR): ${fileName}\n`;
    fullText += `Total Pages: ${pdf.numPages}\n`;

    // Determine which pages to OCR
    const pages = pagesToExtract || Array.from({ length: pdf.numPages }, (_, i) => i + 1);
    if (pagesToExtract && pagesToExtract.length > 0) {
      fullText += `Extracting Pages: ${pagesToExtract.join(', ')}\n`;
    }
    fullText += `${'='.repeat(60)}\n\n`;

    for (const pageNum of pages) {

      try {
        const page = await pdf.getPage(pageNum);

        // Render page at 2x scale for better OCR accuracy
        const viewport = page.getViewport({ scale: 2.0 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        // Render PDF page to canvas
        await page.render({
          canvasContext: context,
          viewport: viewport
        }).promise;

        // Convert canvas to base64-encoded PNG for OCR service
        const imageData = canvas.toDataURL('image/png');

        fullText += `--- Page ${pageNum} ---\n\n`;

        // Process through OCR if service is configured
        if (this.ocrService.isOcrConfigured()) {
          try {
            let pageText = await this.ocrService.extractTextFromImage(imageData);
            if (pageText && pageText.trim()) {
              // Apply table structure detection to improve OCR output formatting
              pageText = this.detectTableStructureInOcrText(pageText);
              fullText += pageText + '\n\n';
            } else {
              fullText += '(No text extracted from this page)\n\n';
            }
          } catch (ocrError) {
            fullText += '(OCR extraction failed for this page)\n\n';
          }
        } else {
          fullText += '(OCR not configured - page rendered but not processed)\n\n';
        }

      } catch (pageError) {
        fullText += `(Failed to process page ${pageNum})\n\n`;
      }
    }

    return fullText;
  }

  /**
   * Post-processes OCR text to detect and preserve table structures.
   *
   * OCR engines often struggle with table layouts, producing text with inconsistent
   * spacing and formatting. This method applies heuristics to detect tables and
   * improve column alignment in the extracted text.
   *
   * Processing steps:
   * 1. Remove OCR artifacts (stray brackets around numbers)
   * 2. Detect existing pipe delimiters from tables
   * 3. Identify currency patterns that may span columns
   * 4. Split merged column content using pattern recognition
   * 5. Reconstruct table rows with proper pipe delimiters
   *
   * @param text - Raw text output from OCR service
   * @returns Cleaned text with improved table structure formatting
   */
  private detectTableStructureInOcrText(text: string): string {
    const lines = text.split('\n').filter(line => line.trim().length > 0);

    if (lines.length < 2) return text;

    const processedLines: string[] = [];

    for (const line of lines) {
      let processedLine = line;

      // Remove common OCR artifacts: brackets around numbers
      processedLine = processedLine.replace(/\[(\d{1,2})\]/g, '$1');
      processedLine = processedLine.replace(/(\d{4})\]/g, '$1');
      processedLine = processedLine.replace(/\[/g, '');

      const hasPipes = processedLine.includes('|');

      if (hasPipes) {
        // Line already has pipe delimiters - clean up segments
        const segments = processedLine.split('|').map(s => s.trim());
        const cleanedSegments: string[] = [];

        for (const segment of segments) {
          // Detect merged currency columns (e.g., "$100.00 $200.00")
          if (segment.match(/\$[\d,]+\.[\d]{2}\s+\$[\d,]+\.[\d]{2}/)) {
            const split = this.splitOcrLineIntoColumns(segment);
            cleanedSegments.push(split);
          } else {
            cleanedSegments.push(segment);
          }
        }

        processedLine = cleanedSegments.filter(s => s.length > 0).join(' | ');
      } else {
        // No pipes - attempt to detect and split columns
        const withPipes = this.splitOcrLineIntoColumns(processedLine);
        processedLine = withPipes;
      }

      processedLines.push(processedLine);
    }

    return processedLines.join('\n');
  }

  /**
   * Attempts to split OCR text into columns using pattern recognition.
   *
   * Detects common patterns that indicate column boundaries:
   * - Multiple consecutive spaces (likely column gaps)
   * - Currency values ($ amounts)
   * - Date patterns (MM/DD/YYYY)
   * - Number sequences
   *
   * Uses heuristics tuned for typical table layouts in business documents.
   *
   * @param line - Single line of OCR text that may contain multiple columns
   * @returns Line with detected columns separated by " | " delimiters
   */
  private splitOcrLineIntoColumns(line: string): string {
    let result = line;

    result = result.replace(/(\$[\d,]+\.[\d]{2})\s+(\$[\d,]+\.[\d]{2})/g, '$1 | $2');
    result = result.replace(/^(\d{1,2})\s+(20\d{2})\s+/g, '$1 | $2 | ');
    result = result.replace(/\|\s*(\d{1,2})\s+(20\d{2})\s+/g, '| $1 | $2 | ');
    result = result.replace(/(\d+)\s+(\$[\d,]+\.[\d]{2})/g, '$1 | $2');
    result = result.replace(/([a-zA-Z]\w*)\s+(\$[\d,]+\.[\d]{2})/g, '$1 | $2');

    return result;
  }
}
