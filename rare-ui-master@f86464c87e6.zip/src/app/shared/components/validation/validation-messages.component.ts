import { Component, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ValidationService } from '../../services/validation.service';

@Component({
    selector: 'validation-messages',
    standalone: false,
    template: `<div class="text-danger" style="width: auto;" *ngIf="errorMessage">{{errorMessage}}</div>`
})
export class ValidationMessagesComponent {
    @Input() control: FormControl;
    @Input() errors: any;
    @Input() validatorName: any;

    constructor() {
    }

    get errorMessage() {

        if (this.errors) {
            for (let propertyName in this.errors) {
                return ValidationService.getValidatorErrorMessage(propertyName);
            }
        }
        
        return null;
    }
}