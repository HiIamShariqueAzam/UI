import { Component, OnInit } from '@angular/core';
import { ErrorDialogService } from '../../services/error-dialog.service';

/**
 * Component for displaying an error dialog.
 * This dialog shows an error message and optional detailed error information.
 * It uses the `ErrorDialogService` to listen for error messages and display the dialog.
 */
@Component({
  selector: 'app-error-dialog',
  styleUrls: ['./error-dialog.component.css'],
  standalone: false,
  template: `
    <p-dialog header="Error" [(visible)]="display" [modal]="true" [blockScroll]="true" [style]="{ width: '35rem' }"
              resizable="false" draggable="false">
      <div class="dialog-content">
        <span class="message text-surface-500 dark:text-surface-400" [innerHTML]="message"></span>
        <p class="error-details">{{ detailedError }}</p>
        <div class="button-container">
          <p-button label="Close" (click)="close()" class="continue-btn"></p-button>
        </div>
      </div>
    </p-dialog>
  `,
})
export class ErrorDialogComponent implements OnInit {
  /**
   * Controls the visibility of the error dialog.
   * @type {boolean}
   */
  display: boolean = false;

  /**
   * The main error message to display in the dialog.
   * @type {string}
   */
  message: string = '';

  /**
   * Detailed error information to display in the dialog.
   * @type {string}
   */
  detailedError: string = '';

  /**
   * Constructor for the ErrorDialogComponent.
   * @param {ErrorDialogService} errorDialogService - Service for managing error dialog messages.
   */
  constructor(private errorDialogService: ErrorDialogService) {}

  /**
   * Lifecycle hook that initializes the component.
   * Subscribes to the `errorMessage$` observable from the `ErrorDialogService`
   * to receive and display error messages.
   */
  ngOnInit() {
    this.errorDialogService.errorMessage$.subscribe((message: String) => {
      const parts = message.split('Error details:');
      this.message = parts[0];
      this.detailedError = parts.length > 1 ? parts[1].trim() : '';
      this.display = true;
    });
  }

  /**
   * Closes the error dialog by setting `display` to `false`.
   */
  close() {
    this.display = false;
  }
}
