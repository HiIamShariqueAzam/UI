import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { GlobalHeaderComponent } from './global-header.component';
import { Router, NavigationEnd } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { OidcSecurityService, AuthModule } from 'angular-auth-oidc-client';
import { MessageService } from 'primeng/api';
import { Observable, BehaviorSubject } from 'rxjs';
import { AuthenticationService } from 'src/app/shared/services';
import { By } from '@angular/platform-browser';

class MockRouter {
  public ne = new NavigationEnd(0, 'http://localhost:4200/login', 'http://localhost:4200/login');
  public events = new Observable(observer => {
    observer.next(this.ne);
    observer.complete();
  });
}

class MockAuthenticationService {
  userRole: BehaviorSubject<any>;
  userRole1: BehaviorSubject<any>;

  dataRole: any;
  constructor() {
    this.userRole = new BehaviorSubject<any>(null);
    this.userRole1 = new BehaviorSubject<any>(null);
  }
  changeUserRole(data: string) {
    this.userRole.next(data);
  }
  changeUserRole1(data: string) {
    this.userRole1.next(data);
  }
}

describe('GlobalHeaderComponent', () => {
  let component: GlobalHeaderComponent;
  let fixture: ComponentFixture<GlobalHeaderComponent>;
  let router: Router;
  let authService: MockAuthenticationService;
  let authenticationService: AuthenticationService;
  let messageService: MessageService;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [GlobalHeaderComponent],
      imports: [
        AuthModule.forRoot()
      ],
      providers: [provideHttpClient(), MessageService, { provide: Router, useClass: MockRouter },
        OidcSecurityService
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    authService = new MockAuthenticationService();
    authenticationService = TestBed.get(AuthenticationService);
    messageService = TestBed.get(MessageService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the header menus', () => {
    component = new GlobalHeaderComponent(router, authenticationService, messageService);
    authenticationService.changeUserRole("ADMIN");
    fixture.detectChanges();
    authenticationService.userRole.subscribe(data => {
      authenticationService.isUserRoleAdmin("ADMIN");
      expect(component.showAdminMenu).toEqual(true);
      expect(component.showUnderwriterMenu).toEqual(true);
      expect(component.showFactorsMenu).toEqual(true);
      expect(component.showManagementReportsMenu).toEqual(true);
    });
  });

  it('should not set the header menus', () => {
    authenticationService.changeUserRole("DEN");
    authenticationService.userRole.subscribe(data => {
      authenticationService.isUserRoleAdmin("DEN");
      expect(component.showAdminMenu).toEqual(false);
    });
  });

  it('should set the Factors menus', () => {
    authenticationService.changeUserRole("ACTUARIAL");
    authenticationService.userRole.subscribe(data => {
      authenticationService.isUserRoleActuarial("ACTUARIAL");
      expect(component.showFactorsMenu).toEqual(true);
    });
  });

  it('should not set the Factors menus', () => {
    authenticationService.changeUserRole("NOT_ACTRLS");
    authenticationService.userRole.subscribe(data => {
      authenticationService.isUserRoleActuarial("NOT_ACTRLS");
      expect(component.showFactorsMenu).toEqual(false);
      expect(component.showUnderwriterMenu).toEqual(false);
      expect(component.showManagementReportsMenu).toEqual(false);
    });
  });

  it('should not set the Underwriter menus', () => {
    authenticationService.changeUserRole("UNDERWRITER");
    authenticationService.userRole.subscribe(data => {
      authenticationService.isUserRoleActuarial("UNDERWRITER");
      expect(component.showUnderwriterMenu).toEqual(true);
    });
  });

  it('should call the logout menu', () => {
    component.showMenu = true;
    spyOn(authenticationService, 'logout');
    fixture.detectChanges();
    component.ngAfterViewInit();
    fixture.detectChanges();
    const logoutButton = fixture.debugElement.query(By.css('#logoutId'));
    logoutButton.triggerEventHandler('click', null);
    expect(authenticationService.logout).toHaveBeenCalled();
  });

  it('should call showOverlay', () => {
    component.showUpArrow = false;
    component.showOverlay();
    expect(component.showUpArrow).toEqual(true);
  });
  it('should call hideOverlay', () => {
    component.showUpArrow = true;
    component.hideOverlay();
    expect(component.showUpArrow).toEqual(false);
  });
});



