import { AfterViewInit, Component, Inject, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { MessageService } from 'primeng/api';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { CommonConstants } from '../../constants/common.constants';
import { UserService } from '../../services/user.service';
import { StringUtils } from '../../utils/string-utils';

@Component({
  selector: 'app-global-header',
  templateUrl: './global-header.component.html',
  standalone: false,
})
export class GlobalHeaderComponent implements OnInit, OnDestroy {
  @Input() showMenu: boolean;
  userName: any;
  userRoleTextToDisplay: any;
  showFactorsMenu: boolean = false;
  showUserMenu: boolean = false;
  showUnderwriterMenu: boolean = false;
  showManagementReportsMenu: boolean = false;
  showAdminMenu: boolean = false;
  showActurialMenu: boolean = false;
  showSalesMenu: boolean = false;
  showUpArrow: boolean = false;
  flagTooltip: boolean = false;
  headerMenu: any[];
  disableReportFlag: boolean = false;
  showRoleManagementMenu: boolean = false;
  showRenewalMenu: boolean = false;

  private orderofOption = ['Opportunities', 'Renewals', 'Factor Maintenance', 'Reports'];
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
    private messageService: MessageService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private userService: UserService
  ) {
    this.authenticationService.userRole.subscribe((data) => {
      this.showActurialMenu = false;
      this.showUnderwriterMenu = false;
      this.showSalesMenu = false;
      this.showRoleManagementMenu = false;
      this.showRenewalMenu = false;
      this.headerMenu = [];
      if (this.authenticationService.isUserRoleAdmin(data)) {
        this.headerMenu = CommonConstants.adminMenu;
        if (this.commonService.isRenewalEnabled) {
          let quotesIndex = this.headerMenu.findIndex((menu) => menu.label == 'Quotes');
          let renewalsIndex = this.headerMenu.findIndex((menu) => menu.label == 'Renewals');
          if (quotesIndex != -1 && renewalsIndex == -1) {
            this.headerMenu.splice(quotesIndex + 1, 0, CommonConstants.adminMenuIntakeEnabled[0]);
          }
        }
        this.removeManagementReport();
        if (this.commonService.factorMigrationEnabled) {
          this.headerMenu = CommonConstants.adminMenu;
          let index = this.headerMenu.findIndex((menu) => menu.label == 'Factor Maintenance');
          if (index !== -1) {
            this.headerMenu.splice(index, 1, CommonConstants.FACTOR_MIGRATION_MENU);
          }
        }
      } else {
        if (this.authenticationService.isUserMarketSegmentSmallGroup(data) || this.authenticationService.isUserMarketSegmentLargeGroup(data)) {
          this.headerMenu = CommonConstants.salesMenu;
          this.showSalesMenu = true;
        }

        if (this.authenticationService.isUserRoleActuarial(data)) {
          let menuItems = [];
          if (this.commonService.isSmallGroupIntakeEnabled) {
            menuItems = CommonConstants.actuarialMenuIntakeEnabled;
          } else {
            menuItems = CommonConstants.actuarialMenu;
          }
          this.headerMenu = this.showSalesMenu ? this.removeMenuOnExist(this.headerMenu, menuItems) : menuItems;
          this.showActurialMenu = true;
          // ALGR-98841 - Data Migration Tool- Access for Actuarial(MED,DEN,VIS)
          if (
            this.commonService.factorMigrationEnabled &&
            StringUtils.checkArrayObjectExitsInArr(this.commonService.getAssignedUserGroup(), CommonConstants.RARE_DMT_ACCESS_FOR_ACTUARIAL)
          ) {
            this.updateAccessForFactorMigration();
          }
        }
        if (this.authenticationService.isUserRoleUnderwriter(data)) {
          let menuItems: any = CommonConstants.underwriterMenu;
          if (this.commonService.isSmallGroupIntakeEnabled) {
            menuItems = CommonConstants.underwriterMenuIntakeEnabled;
          }
          this.headerMenu = this.showActurialMenu || this.showSalesMenu ? this.removeMenuOnExist(this.headerMenu, menuItems) : menuItems;
          this.showUnderwriterMenu = true;
        }
        if (this.authenticationService.isUserRoleManagement(data)) {
          let menuItems = [];
          menuItems = !this.commonService.getManagementReportFlag()
            ? CommonConstants.oppMenuForManagementRole
            : this.commonService.isSmallGroupIntakeEnabled
              ? CommonConstants.reportMenuIntakeEnabled
              : CommonConstants.reportMenu;
          this.headerMenu =
            this.showUnderwriterMenu || this.showActurialMenu || this.showSalesMenu ? this.removeMenuOnExist(this.headerMenu, menuItems) : menuItems;
          this.headerMenu.splice(1, 0, this.headerMenu[this.headerMenu.length - 1]);
          this.headerMenu.splice(this.headerMenu.length - 1, 1);
          this.showRoleManagementMenu = true;
        }
        if (
          this.commonService.isRenewalEnabled &&
          (this.authenticationService.isUserRenewalGroup(data) || this.authenticationService.isUserRenewalBatch(data))
        ) {
          let menuItems = [];
          if (this.authenticationService.isUserRenewalGroup(data) && this.authenticationService.isUserRenewalBatch(data)) {
            menuItems = CommonConstants.adminMenuIntakeEnabled;
          } else if (this.authenticationService.isUserRenewalGroup(data)) {
            menuItems = CommonConstants.renewalGroupMenu;
          } else if (this.authenticationService.isUserRenewalBatch(data)) {
            menuItems = CommonConstants.renewalBatchMenu;
          }
          let quotesIndex = this.headerMenu.findIndex((menu) => menu.label == 'Quotes');
          if (quotesIndex != -1) {
            this.headerMenu.splice(quotesIndex + 1, 0, menuItems[0]);
          } else {
            this.headerMenu = this.removeMenuOnExist(this.headerMenu, menuItems);
          }
          this.showRenewalMenu = true;
        }
        let index = this.headerMenu.findIndex((menu) => menu.label == 'Analytics Reports');
        if (index == -1) {
          this.headerMenu.push({
            label: 'Analytics Reports',
            isSubMenu: true,
            subMenu1: 'Charts',
            subValue1: 'analytics-reports',
            subMenu2: 'Sold Report',
            subValue2: 'analytics-reports/sold-report',
            subMenu3: 'Reports',
            subValue3: 'analytics-reports/dynamic-report'
          });
        }

        if (this.commonService.factorMigrationEnabled && this.authenticationService.isUserFactorTable(data)) {
          if (!this.showActurialMenu && !this.showUnderwriterMenu && !this.showSalesMenu && !this.showRoleManagementMenu && !this.showRenewalMenu) {
            this.headerMenu = [];
          } else if (!StringUtils.checkArrayObjectExitsInArr(this.commonService.getAssignedUserGroup(), CommonConstants.RARE_DMT_ACCESS_FOR_ACTUARIAL)) {
            this.updateAccessForFactorMigration();
          }
        }
      }
      if (!this.commonService.factorExportEnabled) {
        this.deleteSubmenuForFactors(CommonConstants.SUB_MENU1, CommonConstants.SUB_VALUE1);
      }
      if (!this.commonService.factorImportEnabled) {
        this.deleteSubmenuForFactors(CommonConstants.SUB_MENU, CommonConstants.SUB_VALUE);
      }
      if (!this.commonService.experienceExtractionEnabled) {
        let experienceExtractionIndex = this.headerMenu.findIndex((menu) => menu.label == 'Experience Extraction');
        if (experienceExtractionIndex != -1) {
          this.headerMenu.splice(experienceExtractionIndex, 1);
        }
      }
    });

    this.authenticationService.userName.subscribe((data) => {
      this.userName = data;
    });

    this.authenticationService.userRoleTextToDisplay.subscribe((data) => {
      this.userRoleTextToDisplay = data;
    });
  }
  private removeManagementReport() {
    if (!this.commonService.getManagementReportFlag()) {
      let reportIndex = this.headerMenu.findIndex((menu) => menu.label == 'Reports');
      if (reportIndex != -1) {
        this.headerMenu.splice(reportIndex, 1);
      }
    }
  }

  /**
   * Method to delete the submenu for import and export based on flag
   */
  deleteSubmenuForFactors(menu, value) {
    this.headerMenu.forEach((headerMenu) => {
      if (StringUtils.isEqual(headerMenu.label, CommonConstants.FACTOR_MAINTENANCE)) {
        delete headerMenu[menu];
        delete headerMenu[value];
      }
    });
  }

  removeMenuOnExist(existMenu: any[], newMenu: any[]): any[] {
    let filterArray = null;
    if (!existMenu || existMenu.length == 0) {
      return newMenu;
    }
    if (existMenu && newMenu) {
      if (existMenu.length > 0 && newMenu.length > 0) {
        for (var outer = existMenu.length - 1; outer >= 0; outer--) {
          for (var inner = newMenu.length - 1; inner >= 0; inner--) {
            if (existMenu[outer].label === newMenu[inner].label) {
              if (existMenu[outer].isSubMenu) {
                newMenu.splice(inner, 1);
              } else {
                existMenu.splice(outer, 1);
              }
            }
          }
        }
      }
    }
    return this.menuCustomOrder(newMenu ? newMenu.concat(existMenu) : existMenu);
  }
  menuCustomOrder(menuOption): any[] {
    let headerMenu = [];
    let lastOption = null;
    menuOption.forEach((element) => {
      if (element.label === this.orderofOption[0]) {
        if (headerMenu.length > 0) {
          headerMenu.splice(0, 0, element);
        } else headerMenu.push(element);
      } else if (element.label === this.orderofOption[1]) {
        if (headerMenu.length > 1) {
          headerMenu.splice(1, 0, element);
        } else headerMenu.push(element);
      } else if (element.label === this.orderofOption[2]) {
        if (headerMenu.length > 1) {
          headerMenu.splice(2, 0, element);
        } else headerMenu.push(element);
      } else if (element.label === this.orderofOption[3]) {
        if (headerMenu.length > 1) {
          headerMenu.splice(3, 0, element);
        } else headerMenu.push(element);
      } else {
        lastOption = element;
      }
    });
    if (lastOption) headerMenu.push(lastOption);
    return headerMenu;
  }
  ngOnInit() {
    this.router.events.subscribe((e: any) => {
      this.showMenu = this.authenticationService.getShowMenu();
    });
  }

  logout() {
    this.storage.remove('isLoginAgain');
    this.authenticationService.logout(false);
    this.showFactorsMenu = false;
    this.showUserMenu = false;
  }
  navigate(pageName: string) {
    this.router.navigate(['/' + pageName]);
    const currentRouteUrl = this.router.url;
    if (StringUtils.isEqual(currentRouteUrl, '/' + pageName) && StringUtils.isEqual(pageName, 'analytics-reports/dynamic-report')) {
      this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRouteUrl]);
      });
    }
    this.messageService.clear();
    this.showUpArrow = false;
    this.storage.remove('showOpportunities');
    this.storage.remove('OppSearchQuery');
    this.storage.remove('QuoteSearchQuery');
    this.storage.remove('totalPages');
    this.storage.remove('first');
    this.storage.remove('pageIndex');
    this.storage.remove('accountName');
    this.storage.remove('status');
    this.storage.remove('state');
    this.storage.remove('lob');
    this.storage.remove('cursor');
    this.storage.remove('fundingType');
    this.storage.remove('underwriterName');
    this.storage.remove('opportunityID');
    this.storage.remove('quoteHeaderID');
    this.storage.remove('fromdate');
    this.storage.remove('todate');
    this.storage.remove('oppShowOpportunities');
    this.storage.remove('oppTotalPages');
    this.storage.remove('oppFirst');
    this.storage.remove('oppPageIndex');
    this.storage.remove('oppSearchQuery');
    this.storage.remove('oppGroupName');
    this.storage.remove('oppState');
    this.storage.remove('oppOpportunityID');
    this.storage.remove('oppMarketSegment');
    this.storage.remove('oppPageLimit');
    this.storage.remove('oppCursor');
    this.storage.remove('oppMultiSortMeta');
    this.storage.remove('showRenewal');
    this.storage.remove('batchtotalPages');
    this.storage.remove('batchfirst');
    this.storage.remove('batchpageIndex');
    this.storage.remove('batchSearchQuery');
    this.storage.remove('batchbatchName');
    this.storage.remove('batchcreatedBy');
    this.storage.remove('batchfromdate');
    this.storage.remove('batchtodate');
    this.storage.remove('batchpageLimit');
    this.storage.remove('batchcursor');
    this.storage.remove('multiSortMeta');
  }
  navigateHome() {
    this.router.navigate(['/']);
  }
  login() {
    this.userService.setUserGlobalData(this.commonService.getAssignedUserGroup());
  }
  showOverlay() {
    this.messageService.clear();
    this.messageService.add({ key: 'overlay', severity: '', life: 1000000 });
    this.showUpArrow = true;
    var eles = document.getElementsByClassName('border-grey-none');
    if (eles.length > 0) {
      eles[0].className = 'border-grey';
    }
  }
  hideOverlay() {
    var overlayClassEle = document.getElementsByClassName('overlayClass');
    overlayClassEle[0].setAttribute('style', 'visibility:hidden;');
    this.messageService.clear();
    this.showUpArrow = false;
    var eles = document.getElementsByClassName('border-grey');
    if (eles.length > 0) {
      eles[0].className = 'border-grey-none';
    }
  }
  ngOnDestroy() {
    this.messageService.clear();
    this.showUpArrow = false;
    console.log('Component destroyed');
  }
  showTooltip() {
    this.flagTooltip = true;
  }
  hideTooltip() {
    this.flagTooltip = false;
  }
  getDisplayReportFlag(menuOption: any): boolean {
    if (menuOption === 'Reports') {
      return this.disableReportFlag;
    } else {
      return true;
    }
  }
  stringConversion(value) {
    return StringUtils.convertToString(value);
  }
  updateHeaderMenu(factorMigartion) {
    const factorMigration = 'factor-migration';
    this.headerMenu.forEach((menu) => {
      if (StringUtils.isEqualIgnoreCase(menu.label, factorMigartion) && menu.isSubMenu && !StringUtils.isObjectEmpty(menu)) {
        let lastMenuItem = Object.keys(menu)[Object.keys(menu)?.length - 1];
        if (lastMenuItem && !menu[lastMenuItem]?.includes(factorMigration)) {
          const lastIndex = Number.isInteger(parseInt(lastMenuItem.slice(-1))) ? parseInt(lastMenuItem.slice(-1)) + 1 : 1;
          const submenu = { [`subMenu${lastIndex}`]: 'Data Migration', [`subValue${lastIndex}`]: factorMigration };
          menu = Object.assign(menu, submenu);
        }
      }
    });
  }
  updateAccessForFactorMigration() {
    const factorMigartion = this.orderofOption[2];
    const index = this.headerMenu.findIndex((menu) => menu.label == factorMigartion);
    if (index >= 0) {
      this.updateHeaderMenu(factorMigartion);
    } else {
      this.headerMenu.push(CommonConstants.FACTOR_MIGRATION_ROLE_MENU);
    }
  }
}
