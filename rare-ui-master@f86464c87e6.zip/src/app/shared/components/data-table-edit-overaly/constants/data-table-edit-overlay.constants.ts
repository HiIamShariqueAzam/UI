export type ColumnType = 'text' | 'number' | 'readonlyText' | 'date' | 'dropdown' | 'multiDropdown';

export type ValidatorType = 'required' | 'max' | 'maxLength' | 'pattern' | string;

export interface ColumnValidator {
  type: ValidatorType;
  value?: number | string | RegExp;
  customFn?: (...args: any[]) => boolean;
  errorMessage?: string;
}

export interface DropdownOption {
  label: string;
  value: any;
}

export interface TableColumn {
  header: string;
  name: string;
  path?: string;
  type: ColumnType;
  minWidth?: string;
  maxWidth?: string;
  show?: string | boolean;
  visible?: boolean;
  options?: DropdownOption[];
  validators?: ColumnValidator[];
  placeholder?: string;
  filter?: boolean;
  maxSelectedLabels?: number;
}

export interface ParentHeader {
  header: string;
  colspan: number;
}

export type FilterType = 'toggleFilter';

export interface CustomFilter {
  filterType: FilterType;
  onValue: string;
  offValue: string;
  onText: string;
  offText: string;
  icon: string;
  filterPredicate: (schema: any, formControl: any, value: string) => void;
  initialValue?: boolean;
}

export type AllowedAction = DataTableActions.Delete | DataTableActions.Search | DataTableActions.Add | DataTableActions.Reset;

export enum DataTableActions {
    Delete = 'delete',
    Search = 'search',
    Add = 'add',
    Reset = 'reset'
}

export interface DataTableSchema {
  columns: TableColumn[];
  parentHeaders: ParentHeader[];
  customFilters?: CustomFilter[];
  actionsAllowed?: AllowedAction[];
}
