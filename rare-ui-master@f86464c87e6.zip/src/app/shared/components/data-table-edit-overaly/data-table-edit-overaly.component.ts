import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, effect, Injector, input, linkedSignal, model, OnInit, output, QueryList, untracked, ViewChild, ViewChildren, Renderer2, DOCUMENT, OnDestroy } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule, FormControl } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { MultiSelectModule } from 'primeng/multiselect';
import { TooltipModule } from 'primeng/tooltip';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { ButtonGroupModule } from 'primeng/buttongroup';
import { CheckboxModule } from 'primeng/checkbox';
import { SelectButtonModule } from 'primeng/selectbutton';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { Table } from 'primeng/table';
import { filter } from 'rxjs';
import { DataTableActions, DataTableSchema } from './constants/data-table-edit-overlay.constants';

@Component({
  selector: 'app-data-table-edit-overaly',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    TableModule,
    ButtonModule,
    InputTextModule,
    DatePickerModule,
    SelectModule,
    MultiSelectModule,
    TooltipModule,
    IconFieldModule,
    InputIconModule,
    ButtonGroupModule,
    CheckboxModule,
    SelectButtonModule,
    ToggleButtonModule
  ],
  templateUrl: './data-table-edit-overaly.component.html',
  styleUrl: './data-table-edit-overaly.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DataTableEditOveralyComponent implements OnDestroy {
  @ViewChild('dt') table!: Table;

  protected readonly DataTableActions = DataTableActions;

  private fb = inject(FormBuilder);
  private cdr = inject(ChangeDetectorRef);
  private renderer = inject(Renderer2);
  private document = inject(DOCUMENT);

  tableData = input.required<unknown[]>();
  tableSchema = input.required<DataTableSchema>();
  dataSaved = output<unknown>();

  data = linkedSignal(() => this.tableData());
  schema = linkedSignal(() => this.tableSchema());

  constructor() {
    this.renderer.addClass(this.document.body, 'drawer-open');
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'drawer-open');
  }

  private originalData: unknown[] = [];
  private schemaEffect = effect(() => {
    const schemaDetails = this.schema();
    this.initializeForm(schemaDetails);
    this.cdr.markForCheck();
  });

  globalSearchValue = model<string>('');
  allSelected = model<boolean | null>(false);
  private allSelectedEffect = effect(() => {
    const value = this.allSelected();
    if (value !== null) {
      this.onSelectAllChange();
    }
  });

  tableForm: FormGroup = this.fb.group({
    rows: this.fb.array([])
  });
  ;
  columnFiltersForm: FormGroup = this.fb.group({});

  columns: any[] = [];
  clonedRows: { [s: string]: any } = {};
  editingRowIndices: Set<number> = new Set();
  newlyAddedRowIndices: Set<number> = new Set();
  editedRowIndices: Set<number> = new Set();
  deletedRows: any[] = [];

  private checkboxCache = {
    invalidRows: {
      count: 0,
      invalidated: true
    },
    selectedRows: {
      count: 0,
      indices: [] as number[],
      invalidated: true
    }
  };

  selectedMode: string = 'both';
  showInvalidRows: boolean = false;
  customFiltersState: Map<number, boolean> = new Map();

  _blockCheckboxValueDetection = false;

  private initializeForm(schema: any): void {
    if (!schema) {
      return;
    }

    let tableConfig = schema;

    if (!tableConfig.columns) {
      console.warn('No columns found in table config');
      return;
    }

    this.columns = [...tableConfig.columns.filter((col: any) => {
      const shouldShow = col.show !== false && col.show !== 'false';
      return shouldShow;
    })];

    // Initialize column filters form
    this.initializeColumnFilters();

    // Clear existing rows
    while (this.rows.length) {
      this.rows.removeAt(0);
    }

    const rowsData = this.data();
    if (rowsData && rowsData.length > 0) {
      this.originalData = JSON.parse(JSON.stringify(rowsData));
      rowsData.forEach((rowData: any, index: any) => {
        this.addRow(rowData, index);
      });
    }

    // Force change detection after columns are updated
    this.cdr.markForCheck();
  }

  get rows(): FormArray {
    return this.tableForm.get('rows') as FormArray;
  }

  private getNestedValue(obj: any, path: string): any {
    if (!path) return null;
    return path.split('.').reduce((current, prop) => current?.[prop], obj);
  }

  private createRowFormGroup(rowData: any, index: number): FormGroup {
    const group: any = {
      selected: [false]
    };

    this.columns.forEach(column => {
      const validators = this.getValidators(column.validators || [], rowData);
      const value = rowData ? this.getNestedValue(rowData, column.path || column.name) : null;
      group[column.name] = new FormControl(value, validators);
    });

    const formGroup = this.fb.group(group);

    // Subscribe to selected checkbox changes with debouncing for better performance
    formGroup.get('selected')?.valueChanges.pipe(
      filter(() => !this._blockCheckboxValueDetection)
    ).subscribe((isSelected: boolean) => {
      this.onRowSelectionChange(index, isSelected);
    });

    // Subscribe to form validation state changes to update invalid row count
    formGroup.statusChanges.subscribe(() => {
      this.checkboxCache.invalidRows.invalidated = true;
    });

    return formGroup;
  }

  private getValidators(validatorConfigs: any[], rowData: any): any[] {
    const validators: any[] = [];

    validatorConfigs.forEach(config => {

      switch (config.type) {
        case 'required':
          validators.push(Validators.required);
          break;
        case 'max':
          validators.push(Validators.max(config.value));
          break;
        case 'maxLength':
          validators.push(Validators.maxLength(config.value));
          break;
        case 'pattern':
          validators.push(Validators.pattern(config.value));
          break;
        default: 
          if (config.customFn) {
            validators.push((control: any) => {
              const formValue = control.value;
              const tableData = this.data();
              const schema = this.schema();
              const isValid = config.customFn({ formValue: formValue, tableData: tableData, schema: schema, rowData: rowData });

              return isValid ? null : { [config.type]: true };
            });
          }
      }
    });

    return validators;
  }

  addRow(rowData: any, index: number): void {
    if (!this.columns.length) {
      console.warn('Cannot add row: columns not initialized');
      return;
    }
    this.rows.push(this.createRowFormGroup(rowData, index));
    this.checkboxCache.invalidRows.invalidated = true;
    this.checkboxCache.selectedRows.invalidated = true;
  }

  addNewRowAtTop(): void {
    if (!this.columns.length) {
      console.warn('Cannot add row: columns not initialized');
      return;
    }
    // Insert empty row at the beginning
    this.rows.insert(0, this.createRowFormGroup({}, 0));

    // Update editing indices - shift all existing indices by 1
    const updatedIndices = new Set<number>();
    this.editingRowIndices.forEach(index => {
      updatedIndices.add(index + 1);
    });
    this.editingRowIndices = updatedIndices;

    // Update newly added row indices - shift all existing indices by 1
    const updatedNewlyAddedIndices = new Set<number>();
    this.newlyAddedRowIndices.forEach(index => {
      updatedNewlyAddedIndices.add(index + 1);
    });
    this.newlyAddedRowIndices = updatedNewlyAddedIndices;

    // Update edited row indices - shift all existing indices by 1
    const updatedEditedIndices = new Set<number>();
    this.editedRowIndices.forEach(index => {
      updatedEditedIndices.add(index + 1);
    });
    this.editedRowIndices = updatedEditedIndices;

    // Update cloned rows with new indices
    const updatedClonedRows: { [s: string]: any } = {};
    Object.keys(this.clonedRows).forEach(key => {
      const oldIndex = parseInt(key);
      updatedClonedRows[oldIndex + 1] = this.clonedRows[key];
    });
    this.clonedRows = updatedClonedRows;

    // Mark this row as newly added
    this.newlyAddedRowIndices.add(0);

    // Set the new row (index 0) to editing mode
    const newRowForm = this.rows.at(0) as FormGroup;
    this.onRowEditInit(newRowForm, 0);
  }

  removeRow(index: number): void {
    this.rows.removeAt(index);
    this.checkboxCache.invalidRows.invalidated = true;
    this.checkboxCache.selectedRows.invalidated = true;
  }

  getRowFormGroup(index: number): FormGroup {
    return this.rows.at(index) as FormGroup;
  }

  getDropdownLabel(options: any[], value: any): string {
    if (!options || !value) return '';
    const option = options.find(opt => opt.value === value);
    return option ? option.label : value;
  }

  getMultiDropdownLabels(options: any[], values: any[]): string {
    if (!options || !values || !Array.isArray(values)) return '';
    const labels = values.map(val => {
      const option = options.find(opt => opt.value === val);
      return option ? option.label : val;
    });
    return labels.join(', ');
  }

  onRowEditInit(rowForm: FormGroup, index: number): void {
    this.editingRowIndices.add(index);
    this.clonedRows[index] = { ...rowForm.value };
    this.cdr.markForCheck();
  }

  onRowEditSave(rowForm: FormGroup, index: number): void {
    if (rowForm.valid) {
      const isNewRow = this.newlyAddedRowIndices.has(index);
      if (!isNewRow) {
        this.editedRowIndices.add(index);
      }
      delete this.clonedRows[index];
      this.editingRowIndices.delete(index);
      this.checkboxCache.invalidRows.invalidated = true;
      this.cdr.markForCheck();
    }
  }

  onRowEditCancel(rowForm: FormGroup, index: number): void {
    const isNewlyAdded = this.newlyAddedRowIndices.has(index);
    const clonedData = this.clonedRows[index];

    if (isNewlyAdded && clonedData) {

      this.rows.removeAt(index);
      delete this.clonedRows[index];
      this.editingRowIndices.delete(index);
      this.newlyAddedRowIndices.delete(index);
      this.checkboxCache.invalidRows.invalidated = true;
      this.checkboxCache.selectedRows.invalidated = true;
      this.cdr.markForCheck();
      return;

    }

    if (this.clonedRows[index]) {
      rowForm.patchValue(this.clonedRows[index]);
      delete this.clonedRows[index];
    }
    this.editingRowIndices.delete(index);
    this.cdr.markForCheck();
  }

  isEditing(index: number): boolean {
    return this.editingRowIndices.has(index);
  }

  getFilterFields(): string[] {
    return this.columns.map(col => `value.${col.name}`);
  }

  clearGlobalSearch(table: any): void {
    this.globalSearchValue.set('');
    table.filterGlobal('', 'contains');
    this.cdr.markForCheck();
  }

  private initializeColumnFilters(): void {
    const filtersGroup: any = {};

    this.columns.forEach(column => {
      if (['text', 'readonlyText', 'date', 'dropdown', 'multiDropdown'].includes(column.type)) {
        filtersGroup[column.name] = [null];
      }
    });

    this.columnFiltersForm = this.fb.group(filtersGroup);
  }

  getFilterControl(columnName: string) {
    return this.columnFiltersForm.get(columnName);
  }

  clearAllFilters(table: any): void {
    // Clear PrimeNG table filters
    table.clear();

    // Reset the column filters form
    this.columnFiltersForm.reset();

    // Mark for check to update UI
    this.cdr.markForCheck();
  }

  onSelectAllChange(): void {
    const value = this.allSelected();
    if (value !== null) {
      this._blockCheckboxValueDetection = true;

      // Batch update without triggering individual change detection
      const rowsArray = this.rows.controls;
      const length = rowsArray.length;

      for (let i = 0; i < length; i++) {
        rowsArray[i].get('selected')?.setValue(value, { emitEvent: false });
      }

      this._blockCheckboxValueDetection = false;

      // Update cached values directly for immediate accuracy
      if (value) {
        this.checkboxCache.selectedRows.count = length;
        const indices = new Array(length);
        for (let i = 0; i < length; i++) indices[i] = i;
        this.checkboxCache.selectedRows.indices = indices;
      } else {
        this.checkboxCache.selectedRows.count = 0;
        this.checkboxCache.selectedRows.indices = [];
      }
      this.checkboxCache.selectedRows.invalidated = false;

      // Single change detection cycle
      this.cdr.markForCheck();
    }
  }

  onRowSelectionChange(changedIndex?: number, isSelected?: boolean): void {
    const length = this.rows.controls.length;

    //Memoized calculation based on index passed
    if (changedIndex !== undefined && isSelected !== undefined) {
      if (isSelected) {

        this.checkboxCache.selectedRows.count++;

        if (!this.checkboxCache.selectedRows.indices.includes(changedIndex)) {
          this.checkboxCache.selectedRows.indices.push(changedIndex);
        }
      } else {

        this.checkboxCache.selectedRows.count = Math.max(0, this.checkboxCache.selectedRows.count - 1);
        const indexPos = this.checkboxCache.selectedRows.indices.indexOf(changedIndex);
        if (indexPos !== -1) {
          this.checkboxCache.selectedRows.indices.splice(indexPos, 1);
        }
      }
      this.checkboxCache.selectedRows.invalidated = false;
    } else {
      // Full recalculation
      const controls = this.rows.controls;
      let selectedCount = 0;
      const selectedIndices: number[] = [];

      for (let i = 0; i < length; i++) {
        if (controls[i].get('selected')?.value) {
          selectedCount++;
          selectedIndices.push(i);
        }
      }

      this.checkboxCache.selectedRows.count = selectedCount;
      this.checkboxCache.selectedRows.indices = selectedIndices;
      this.checkboxCache.selectedRows.invalidated = false;
    }

    const selectedCount = this.checkboxCache.selectedRows.count;

    untracked(() => {
      if (selectedCount === 0) {
        this.allSelected.set(false);
      } else if (selectedCount === length) {
        this.allSelected.set(true);
      } else {
        this.allSelected.set(null);
      }
    });

    this.cdr.markForCheck();
  }

  deleteSelectedRows(): void {
    // Use cached selected indices if available, otherwise calculate
    let indicesToRemove: number[];

    if (!this.checkboxCache.selectedRows.invalidated && this.checkboxCache.selectedRows.indices.length > 0) {
      // Use cached indices for better performance
      indicesToRemove = [...this.checkboxCache.selectedRows.indices];
    } else {
      // Fallback: calculate indices
      indicesToRemove = [];
      const controls = this.rows.controls;
      for (let i = 0; i < controls.length; i++) {
        if (controls[i].get('selected')?.value) {
          indicesToRemove.push(i);
        }
      }
    }

    if (indicesToRemove.length === 0) return;

    const currentData = this.data();
    const rowsToDelete: any[] = [];

    // Collect rows to delete
    for (const index of indicesToRemove) {
      rowsToDelete.push(currentData[index]);
    }

    // Store deleted rows for reset functionality
    this.deletedRows.push(...rowsToDelete);

    // Create new data array without deleted rows
    const newData = currentData.filter((_, i) => !indicesToRemove.includes(i));
    this.data.set(newData);

    // Remove rows from FormArray in reverse order to maintain correct indices
    for (let i = indicesToRemove.length - 1; i >= 0; i--) {
      const index = indicesToRemove[i];
      this.rows.removeAt(index);

      // Clean up editing state
      if (this.editingRowIndices.has(index)) {
        this.editingRowIndices.delete(index);
        delete this.clonedRows[index];
      }
    }

    // Invalidate caches after deletion
    this.checkboxCache.invalidRows.invalidated = true;
    this.checkboxCache.selectedRows.invalidated = true;

    // Reset select all
    this.allSelected.set(false);

    this.table.reset();

    this.cdr.markForCheck();
  }

  getSelectedCount(): number {
    // Use cached value if available
    if (!this.checkboxCache.selectedRows.invalidated) {
      return this.checkboxCache.selectedRows.count;
    }

    // Calculate and checkboxCache
    let count = 0;
    const selectedIndices: number[] = [];
    const controls = this.rows.controls;

    for (let i = 0; i < controls.length; i++) {
      if (controls[i].get('selected')?.value) {
        count++;
        selectedIndices.push(i);
      }
    }

    this.checkboxCache.selectedRows.count = count;
    this.checkboxCache.selectedRows.indices = selectedIndices;
    this.checkboxCache.selectedRows.invalidated = false;

    return count;
  }

  getInvalidRowsCount(): number {
    // Use cached value if available
    if (!this.checkboxCache.invalidRows.invalidated) {
      if (this.checkboxCache.invalidRows.count === 0) {
        this.showInvalidRows = false;
      }
      return this.checkboxCache.invalidRows.count;
    }

    let count = 0;
    const controls = this.rows.controls;
    for (let i = 0; i < controls.length; i++) {
      if (controls[i].invalid) {
        count++;
      }
    }

    this.checkboxCache.invalidRows.count = count;
    this.checkboxCache.invalidRows.invalidated = false;
    if (count === 0) {
      this.showInvalidRows = false;
    }
    return count;
  }

  isRowInvalid(index: number): boolean {
    return this.rows.at(index).invalid;
  }

  getCustomFilters(): any[] {
    const schemaData = this.schema() as any;
    return schemaData?.customFilters || [];
  }

  toggleCustomFilter(filterIndex: number): void {
    const currentState = this.customFiltersState.get(filterIndex) ?? (this.getCustomFilters()[filterIndex]?.initialValue) ?? false;
    const newState = !currentState;
    this.customFiltersState.set(filterIndex, newState);

    const filters = this.getCustomFilters();
    const filter = filters[filterIndex];

    if (filter?.filterPredicate) {
      const toggleValue = newState ? filter.onValue : filter.offValue;
      filter.filterPredicate(this.schema, this.tableForm, toggleValue);
    }

    this.cdr.markForCheck();
  }

  getCustomFilterState(filterIndex: number): boolean {
    return this.customFiltersState.get(filterIndex) ?? (this.getCustomFilters()[filterIndex]?.initialValue) ?? false;
  }

  getCustomFilterLabel(filter: any, filterIndex: number): string {
    const isActive = this.getCustomFilterState(filterIndex);
    return isActive ? (filter.onText || 'On') : (filter.offText || 'Off');
  }

  getCustomFilterIcon(filter: any): string {
    return filter.icon || 'pi pi-filter';
  }

  saveChanges(): void {
    const updatedData = this.data().map((row: any, index: number) => {
      const formGroup = this.rows.at(index) as FormGroup;
      const formValues = formGroup.value;

      const updatedRow = { ...row };

      this.columns.forEach(column => {
        const fieldName = column.name;
        if (formValues.hasOwnProperty(fieldName)) {
          this.setNestedValue(updatedRow, column.path || column.name, formValues[fieldName]);
        }
      });

      return updatedRow;
    });

    const changedRows: any[] = [];
    
    updatedData.forEach((row: any, index: number) => {
      // Include newly added rows
      if (this.newlyAddedRowIndices.has(index)) {
        changedRows.push(row);
        return;
      }
      
      // Include rows that were marked as edited
      if (this.editedRowIndices.has(index)) {
        changedRows.push(row);
        return;
      }
      
      // Include rows currently being edited
      if (this.editingRowIndices.has(index)) {
        changedRows.push(row);
        return;
      }
      
      // Compare with original data to catch any other changes
      if (index < this.originalData.length) {
        const originalRow = this.originalData[index];
        const formGroup = this.rows.at(index) as FormGroup;
        const formValues = formGroup.value;
        
        let hasChanges = false;
        for (const column of this.columns) {
          const fieldName = column.name;
          const originalValue = this.getNestedValue(originalRow, column.path || column.name);
          const currentValue = formValues[fieldName];
          
          if (!this.areValuesEqual(originalValue, currentValue)) {
            hasChanges = true;
            break;
          }
        }
        
        if (hasChanges) {
          changedRows.push(row);
        }
      }
    });

    this.data.set(updatedData);
    this.originalData = JSON.parse(JSON.stringify(updatedData));
    this.newlyAddedRowIndices.clear();
    this.editedRowIndices.clear();
    this.dataSaved.emit({
      data: updatedData,
      deltedRows: this.deletedRows,
      changedRows: changedRows
    });
    this.cdr.markForCheck();
  }

  resetChanges(): void {
    const originalDataCopy = JSON.parse(JSON.stringify(this.originalData));
    this.data.set(originalDataCopy);

    // Clear FormArray
    while (this.rows.length) {
      this.rows.removeAt(0);
    }

    // Restore all original rows
    originalDataCopy.forEach((rowData: any, index: number) => {
      this.addRow(rowData, index);
    });

    // Clear deleted rows tracking
    this.deletedRows = [];

    // Clear editing state
    this.editingRowIndices.clear();
    this.newlyAddedRowIndices.clear();
    this.editedRowIndices.clear();
    this.clonedRows = {};

    // Invalidate caches
    this.checkboxCache.invalidRows.invalidated = true;
    this.checkboxCache.selectedRows.invalidated = true;
    this.allSelected.set(false);

    this.cdr.markForCheck();
  }

  getFieldError(rowIndex: number, fieldName: string, validators: any[]): string | null {
    const rowFormGroup = this.rows.at(rowIndex) as FormGroup;
    const control = rowFormGroup.get(fieldName);

    if (!control || !control.errors || (!control.touched && !control.dirty)) {
      return null;
    }

    const errors = control.errors;

    // Check for standard validation errors
    if (errors['required']) {
      return 'This field is required';
    }

    if (errors['max']) {
      return `Value must not exceed ${errors['max'].max}`;
    }

    if (errors['maxLength']) {
      return `Maximum length is ${errors['maxLength'].requiredLength}`;
    }

    if (errors['pattern']) {
      const validatorConfig = validators?.find(v => v.type === 'pattern');
      if (validatorConfig && validatorConfig.errorMessage) {
        return validatorConfig.errorMessage;
      }

      return 'Pattern requirement does not match';
    }

    // Check for custom validation errors
    const errorKeys = Object.keys(errors);
    for (const errorKey of errorKeys) {
      // Find the validator config with matching type
      const validatorConfig = validators?.find(v => v.type === errorKey);
      if (validatorConfig && validatorConfig.errorMessage) {
        return validatorConfig.errorMessage;
      }
    }

    // Default error message for unknown errors
    return 'Invalid value';
  }

  private areValuesEqual(val1: any, val2: any): boolean {
    // Handle null/undefined cases
    if (val1 === val2) return true;
    if (val1 == null && val2 == null) return true;
    if (val1 == null || val2 == null) return false;
    
    // Handle empty string vs null/undefined
    if ((val1 === '' && val2 == null) || (val2 === '' && val1 == null)) return true;
    
    // Convert to string for comparison to handle type differences
    return String(val1) === String(val2);
  }

  private setNestedValue(obj: any, path: string, value: any): void {
    if (!path) return;
    const keys = path.split('.');
    let current = obj;

    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) {
        current[keys[i]] = {};
      }
      current = current[keys[i]];
    }

    current[keys[keys.length - 1]] = value;
  }

  isActionAllowed(action: DataTableActions): boolean {
    const schemaData = this.schema();
    return schemaData.actionsAllowed.includes(action);
  }
}
