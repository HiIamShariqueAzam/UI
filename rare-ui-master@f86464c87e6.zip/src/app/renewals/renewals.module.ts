import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchBatchComponent } from './batch/search-batch';
import {FormsModule,ReactiveFormsModule } from '@angular/forms';
import { CreateBatchComponent } from './batch/create-batch';
import { FileUploadModule } from 'primeng/fileupload';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CheckboxModule } from 'primeng/checkbox';
import { MultiSelectModule } from 'primeng/multiselect';
import { GroupComponent } from './group';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { DialogModule } from 'primeng/dialog';
import { TooltipModule } from 'primeng/tooltip';
import { RouterModule } from '@angular/router';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import {
  CreateBatchSuppHealthComponent
} from "./batch/supplemental-health/create-batch-supp-health/create-batch-supp-health.component";
import { SharedModule } from '../shared/shared.module';
import { AutorunTabComponent } from './batch/autorun-tab/autorun-tab.component';
import { SearchOverlaysComponent } from './batch/search-overlays/search-overlays.component';
import { QuoteOptionsTabComponent } from './batch/quote-options-tab/quote-options-tab.component';
import { TieringComponent } from './batch/tiering/tiering.component';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

@NgModule({
    declarations: [GroupComponent, SearchBatchComponent, CreateBatchComponent, CreateBatchSuppHealthComponent,AutorunTabComponent, SearchOverlaysComponent, QuoteOptionsTabComponent, TieringComponent],
    imports: [
        CommonModule,
        SharedModule,
        TableModule,
        ReactiveFormsModule,
        FormsModule,
        DialogModule,
        CommonModule, TableModule, ButtonModule, ReactiveFormsModule, RadioButtonModule, FlexLayoutModule,
        AutoCompleteModule, CheckboxModule, FormsModule, MultiSelectModule, ButtonModule, FileUploadModule, ProgressSpinnerModule,
        TooltipModule,
        SharedModule,
        DatePickerModule,
        SelectModule,
        ConfirmDialogModule,
        RouterModule.forChild([
            { path: '', component: GroupComponent, pathMatch: 'full' },
            { path: 'batch', component: SearchBatchComponent, pathMatch: 'full' },
            { path: 'batch/create-batch', component: CreateBatchComponent, pathMatch: 'full' },
            { path: 'batch/create-batch-supp-health', component: CreateBatchSuppHealthComponent, pathMatch: 'full' }
        ])
    ],
    exports: [
        GroupComponent,
        SearchBatchComponent,
        CreateBatchComponent
    ],
    providers: [ConfirmationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class RenewalsModule { }
