export class RenewalsConstants {

  public static RENEWAL_BATCH_COLUMNS = [
    {
      "header": "Source System",
      "field": "sourceSystem"
    },
    {
      "header": "Group Number",
      "field": "groupNumber"
    },
    {
      "header": "Group Name",
      "field": "groupName"
    },
    {
      "header": "State",
      "field": "state"
    },
    {
      "header": "Renewal Date",
      "field": "renewalDate"
    },
    {
      "header": "LOBs - FA Type",
      "field": "lob"
    },
    {
      "header": "Market Segment",
      "field": "marketSegment"
    },
    {
      "header": "MBU",
      "field": "mbu"
    },
    {
      "header": "Subs Count",
      "field": "subscriberCount"
    },
    {
      "header": "SSL",
      "field": "sslLevel"
    },
    {
      "header": "ASL",
      "field": "aslLevel"
    },
    {
      "header": "Group Refund",
      "field": "refundPct"
    },
    {
      "header": "Comm Value",
      "field": "commissionValue"
    },
    {
      "header": "Comm Type",
      "field": "commissionType"
    },
    {
      "header": "Renewal Opportunity ID",
      "field": "opportunityID"
    },
    {
      "header": "Renewal Quote ID",
      "field": "quoteHeaderID"
    },
    {
      "header": "File Upload Status",
      "field": "uploadStatus"
    },
    {
      "header": "Submission Status",
      "field": "submissionStatus"
    },
    {
      "header": "Renewal Quote Status",
      "field": "quoteRenewalStatus"
    },
  ];

  public static RENEWAL_BATCH_COLUMNS_NEW_BATCH = [
    {
      "header": "Source System",
      "field": "sourceSystem"
    },
    {
      "header": "Group Number",
      "field": "groupNumber"
    },
    {
      "header": "Group Name",
      "field": "groupName"
    },
    {
      "header": "State",
      "field": "state"
    },
    {
      "header": "Renewal Date",
      "field": "renewalDate"
    },
    {
      "header": "LOBs - FA Type",
      "field": "lob"
    },
    {
      "header": "Market Segment",
      "field": "marketSegment"
    },
    {
      "header": "MBU",
      "field": "mbu"
    },
    {
      "header": "Subs Count",
      "field": "subscriberCount"
    },
  ];

  //bulkTableColsBefore
  public static QUOTE_OPTIONS_COLUMNS = {
    headers: [
      { "header": "", "colspan": 4 },
      { "header": "SG Quote Options", "colspan": 3 },
      { "header": "LG Quote Options", "colspan": 2 },
      { "header": "", "colspan": 1 }
    ],
    subHeaders: [
      { 'header': 'Group Number', 'field': 'groupNumber' },
      { 'header': 'Group Name', 'field': 'groupName' },
      { "header": "LOBs - FA Type", "field": "lob" },
      { "header": "Renewal Market Segment", "field": "marketSegment" },
      { "header": "ABF", "field": "SGABF", "isEnabled": true, "type":"checkBox", "isSelected": false, "marketSegment": "SG" },
      { "header": "ACA", "field": "SGACA", "isEnabled": true, "type":"checkBox", "isSelected": false, "marketSegment": "SG" },
      { "header": "MEWA", "field": "SGMEWA", "isEnabled": true, "type":"checkBox", "isSelected": false, "marketSegment": "SG" },
      { "header": "FI", "field": "LGFI", "isEnabled": true, "type":"checkBox", "isSelected": false, "marketSegment": "LG" },
      { "header": "ABF", "field": "LGABF", "isEnabled": true, "type":"checkBox", "isSelected": false, "marketSegment": "LG" },
      { "header": "ALT Quote Submission Status", "field": "marketSegment" }
    ]
  };

  public static QUOTE_OPTIONS_COLUMNS_FOR_VISION_DENTAL = {
    headers: [
      { "header": "", "colspan": 4 },
      { "header": "SG Quote Options", "colspan": 1 },
      { "header": "LG Quote Options", "colspan": 1 },
      { "header": "", "colspan": 1 }
    ],
    subHeaders: [
      { 'header': 'Group Number', 'field': 'groupNumber' },
      { 'header': 'Group Name', 'field': 'groupName' },
      { "header": "LOBs - FA Type", "field": "lob" },
      { "header": "Renewal Market Segment", "field": "marketSegment" },
      { "header": "FI", "field": "SGFI", "isEnabled": true, "type": "checkBox", "isSelected": false, "marketSegment": "SG" },
      { "header": "FI", "field": "LGFI", "isEnabled": true, "type": "checkBox", "isSelected": false, "marketSegment": "LG" },
      { "header": "ALT Quote Submission Status", "field": "marketSegment" }
    ]
  };

  //bulkTableColsAfter
  public static BULK_TABLE_COLUMNS_AFTER = [
    { 'header': 'PY Rolling 12 LR', 'field': 'pyLossRatio' },
    { 'header': 'CY Contract SSL LR', 'field': 'cyContractSpecificStopLossRatio' },
    { 'header': 'PY Contract SSL LR', 'field': 'pycontractSpecificStopLossRatio' },
    { 'header': 'Claimants Over Spec Threshold', 'field': 'clmntsOverSpecThrshld' },
    { 'header': 'PY Contract Max Clms Fund LR', 'field': 'pyCntrctMaxClmFndLr' },
    { 'header': 'Man Only Suggested Increase', 'field': 'manualOnlySugstdIncrease' },
    { 'header': 'Clms Only Suggested Increase', 'field': 'clmOnlySugstdIncrease' },
    { 'header': 'Admin Fee Increase', 'field': 'adminFeeIncrease' },
    { 'header': 'SSL Increase', 'field': 'sslIncrease' },
    { 'header': 'ASL Increase', 'field': 'aslIncrease' },
    { 'header': 'Terminal Liability Increase', 'field': 'tlIncrease' },
    { 'header': 'Max Clm Fund Increase', 'field': 'maxClmFndIncrease' }
  ];
  //bulkTableColsBefore
  public static BULK_TABLE_COLUMNS_BEFORE = [
    { 'header': 'Group Number', 'field': 'groupNumber' },
    { 'header': 'Group Name', 'field': 'groupName' },
    { 'header': 'Release Status', 'field': 'Release Status' },
    { 'header': 'Subs', 'field': 'totalSubsribers' },
    { 'header': 'Mems', 'field': 'totalMembers' },
    { 'header': 'Rolling 12 LR', 'field': 'lossRatio' },
    { 'header': 'CY Tot Clms Over SSL', 'field': 'cyTotalClmsOverSsl' },
    { 'header': 'CY Contract Max Clms Fund LR', 'field': 'cyCntrctMaxClmFndLr' },
    { 'header': 'CY Surplus/ Deficit', 'field': 'cySurplusOrDeficit' },
    { 'header': 'Prem Comp RA%', 'field': 'mpcRateAction' },
    { 'header': 'Blended Suggested Increase', 'field': 'blendedIncrease' },
    { 'header': 'Formula Tiered RA%', 'field': 'formulaTieredRateActionPercent' },
    { 'header': 'UW Tiered RA%', 'field': 'uwTieredRateActionPercent' },
    { 'header': 'Renewal Premium', 'field': 'renewalMonthlyGrandTotal' },
    { 'header': 'Current to Renewal RA%', 'field': 'renewalIncreasePercentage' },
    { 'header': 'Renewal to Quoted RA%', 'field': 'diffToRenewalRatePercentage' },
    { 'header': 'Proposed Increase', 'field': 'adjustedRateActionPercent' },
    { 'header': 'WH Sav %', 'field': 'renewalWHAPercent' },
    { 'header': 'Proposed Admin Fee Increase', 'field': 'asoAdminFee' },
    { 'header': 'Proposed SSL Increase', 'field': 'sslPremium' },
    { 'header': 'Proposed ASL Increase', 'field': 'aslPremium' },
    { 'header': 'Proposed TL Increase', 'field': 'terminalLiability' },
    { 'header': 'UW note to sales', 'field': 'uwNotesToSales' },
    { 'header': 'UW note to self', 'field': 'uwComments' },
    { 'header': 'Proposed Max Clm Fund Increase', 'field': 'maxPaidClaim' }
  ];

  public static AUTORUN_TABLE_COLUMNS_BEFORE = [
    { 'header': 'Group Number', 'field': 'groupNumber' },
    { 'header': 'Group Name', 'field': 'groupName' },
    { 'header': 'Claims As of Date', 'field': 'claimsAsOfDate' },
    { 'header': 'Subs', 'field': 'totalSubsribers' },
    { 'header': 'Mems', 'field': 'totalMembers' },
    { 'header': 'Rolling 12 LR', 'field': 'lossRatio' },
    { 'header': 'CY Tot Clms Over SSL', 'field': 'cyTotalClmsOverSsl' },
    { 'header': 'CY Contract Max Clms Fund LR', 'field': 'cyCntrctMaxClmFndLr' },
    { 'header': 'CY Surplus/ Deficit', 'field': 'cySurplusOrDeficit' },
    { 'header': 'Prem Comp RA%', 'field': 'mpcRateAction' },
    { 'header': 'Blended Suggested Increase', 'field': 'blendedIncrease' },
    { 'header': 'Proposed Increase', 'field': 'adjustedRateActionPercent' },
    { 'header': 'WH Sav %', 'field': 'renewalWHAPercent' },
    { 'header': 'Proposed Admin Fee Increase', 'field': 'asoAdminFee' },
    { 'header': 'Proposed SSL Increase', 'field': 'sslPremium' },
    { 'header': 'Proposed ASL Increase', 'field': 'aslPremium' },
    { 'header': 'Proposed TL Increase', 'field': 'terminalLiability' },
    { 'header': 'Proposed Max Clm Fund Increase', 'field': 'maxPaidClaim' }
  ];

  public static FI_BULK_TABLE_COLUMNS = [
    { 'header': 'Group Number', 'field': 'groupNumber' },
    { 'header': 'Group Name', 'field': 'groupName' },
    { 'header': 'Release Status', 'field': 'Release Status' },
    { 'header': 'Subs', 'field': 'totalSubsribers' },
    { 'header': 'Mems', 'field': 'totalMembers' },
    { 'header': 'Rolling 12 LR', 'field': 'lossRatio' },
    { 'header': 'Prem Comp RA%', 'field': 'mpcRateAction' },
    { 'header': 'Blended Suggested Increase', 'field': 'blendedIncrease' },
    { 'header': 'Formula Tiered RA%', 'field': 'formulaTieredRateActionPercent' },
    { 'header': 'UW Tiered RA%', 'field': 'uwTieredRateActionPercent' },
    { 'header': 'Proposed Increase', 'field': 'adjustedRateActionPercent' },    
    { 'header': 'WH Sav %', 'field': 'renewalWHAPercent' },
    { 'header': 'UW note to sales', 'field': 'uwNotesToSales' },
    { 'header': 'UW note to self', 'field': 'uwComments' },
    { 'header': 'PY Rolling 12 LR', 'field': 'pyLossRatio' },
    { 'header': 'Man Only Suggested Increase', 'field': 'manualOnlySugstdIncrease' },
    { 'header': 'Clms Only Suggested Increase', 'field': 'clmOnlySugstdIncrease' },
    { 'header': 'Claimants Over Threshold', 'field': 'clmntsOverThrshld' }
  ];

    public static MEWA_BULK_TABLE_COLUMNS = [
    { 'header': 'Group Number', 'field': 'groupNumber' },
    { 'header': 'Group Name', 'field': 'groupName' },
    { 'header': 'Release Status', 'field': 'Release Status' },
    { 'header': 'Subs', 'field': 'totalSubsribers' },
    { 'header': 'Mems', 'field': 'totalMembers' },  
    { 'header': 'Current Risk Factor', 'field': 'currentRiskFactor' },
    { 'header': 'Tiered Risk Factor', 'field': 'riskFactor' },
    { 'header': 'UW Risk Adjustment Factor', 'field': 'uwAdjustmentFactor' },  
    { 'header': 'WH Sav %', 'field': 'wholeHealthAdjustmentFactor' },
    { 'header': 'Final Risk Factor', 'field': 'finalRiskFactor' },
    { 'header': 'WHS Reduction', 'field': 'whsReduction' },
    { 'header': 'UW note to sales', 'field': 'uwNotesToSales' },
    { 'header': 'UW note to self', 'field': 'uwComments' }
  ];

  public static FI_AUTORUN_TABLE_COLUMNS = [
    { 'header': 'Group Number', 'field': 'groupNumber' },
    { 'header': 'Group Name', 'field': 'groupName' },
    { 'header': 'Claims As of Date', 'field': 'claimsAsOfDate' },
    { 'header': 'Subs', 'field': 'totalSubsribers' },
    { 'header': 'Mems', 'field': 'totalMembers' },
    { 'header': 'Rolling 12 LR', 'field': 'lossRatio' },
    { 'header': 'Prem Comp RA%', 'field': 'mpcRateAction' },
    { 'header': 'Blended Suggested Increase', 'field': 'blendedIncrease' },
    { 'header': 'Proposed Increase', 'field': 'adjustedRateActionPercent' },
    { 'header': 'WH Sav %', 'field': 'renewalWHAPercent' },
    { 'header': 'PY Rolling 12 LR', 'field': 'pyLossRatio' },
    { 'header': 'Man Only Suggested Increase', 'field': 'manualOnlySugstdIncrease' },
    { 'header': 'Clms Only Suggested Increase', 'field': 'clmOnlySugstdIncrease' },
    { 'header': 'Claimants Over Threshold', 'field': 'clmntsOverThrshld' }
  ];

  public static SUPP_HEALTH_BULK_TABLE_COLUMNS = [
    { 'header': 'Group Number', 'field': 'groupNumber' },
    { 'header': 'Group Name', 'field': 'groupName' },
    { 'header': 'Release Status', 'field': 'status' },
    { 'header': 'Subs', 'field': 'totalSubsribers' },
    { 'header': 'Mems', 'field': 'totalMembers' },
    { 'header': 'Guarantee Eff Dt', 'field': 'rateGuaranteeStartDate' },
    { 'header': 'Guarantee Months', 'field': 'rateGuaranteeMonths' },
    { 'header': 'In Guarantee', 'field': 'inRateGuarantee' },
    { 'header': 'Suggested Increase', 'field': 'suppHealthOverallSuggestedIncrease' },
    { 'header': 'Proposed Increase', 'field': 'suppHealthOverallProposedIncrease' },
    { 'header': 'RA - Adj - Accident', 'field': 'accidentAdjustments' },
    { 'header': 'RA - Adj - Hosp Indem', 'field': 'hospitalIndemnityAdjustments' },
    { 'header': 'RA - Adj - Crit Illness', 'field': 'criticalIllnessAdjustments' },
    { 'header': 'UW note to sales', 'field': 'uwNotesToSales' },
    { 'header': 'UW note to self', 'field': 'uwComments' },
    { 'header': 'Suggested Increase - Accident', 'field': 'accidentAdjustments' },
    { 'header': 'Suggested Increase - Hosp Indem', 'field': 'hospitalIndemnityAdjustments' },
    { 'header': 'Suggested Increase - Crit Illness', 'field': 'criticalIllnessAdjustments' }
  ];
  public static SUPP_HEALTH_BULK_EDITABLE_COLUMNS = [
    "Proposed Increase",
    "RA - Adj - Accident",
    "RA - Adj - Hosp Indem",
    "RA - Adj - Crit Illness",
    "UW note to sales",
    "UW note to self"
  ];
  public static VIS_DEN_BULK_TABLE_COLUMNS = [
    { 'header': 'Group Number', 'field': 'groupNumber' },
    { 'header': 'Group Name', 'field': 'groupName' },
    { 'header': 'Release Status', 'field': 'status' },
    { 'header': 'Subs', 'field': 'totalSubsribers' },
    { 'header': 'Mems', 'field': 'totalMembers' },
    { 'header': 'Guarantee Eff Dt', 'field': 'rateGuaranteeStartDate' },
    { 'header': 'Guarantee Months', 'field': 'rateGuaranteeMonths' },
    { 'header': 'In Guarantee', 'field': 'inRateGuarantee' },
    { 'header': 'Loss Ratio', 'field': 'lossRatio' },
    { 'header': 'Suggested Increase', 'field': 'overallSuggestedIncrease' },
    { 'header': 'Proposed Increase', 'field': 'overallProposedIncrease' },
    { 'header': 'RA - Adj - Plan 1', 'field': 'adjPlan1' },
    { 'header': 'RA - Adj - Plan 2', 'field': 'adjPlan2' },
    { 'header': 'RA - Adj - Plan 3', 'field': 'adjPlan3' },
    { 'header': 'RA - Adj - Plan 4', 'field': 'adjPlan4' },
    { 'header': 'RA - Adj - Plan 5', 'field': 'adjPlan5' },
    { 'header': 'RA - Adj - Plan 6', 'field': 'adjPlan6' },
    { 'header': 'UW note to sales', 'field': 'uwNotesToSales' },
    { 'header': 'UW note to self', 'field': 'uwComments' },
    { 'header': 'Suggested Increase - Plan 1', 'field': 'suggestedIncreasePlan1' },
    { 'header': 'Suggested Increase - Plan 2', 'field': 'suggestedIncreasePlan2' },
    { 'header': 'Suggested Increase - Plan 3', 'field': 'suggestedIncreasePlan3' },
    { 'header': 'Suggested Increase - Plan 4', 'field': 'suggestedIncreasePlan4' },
    { 'header': 'Suggested Increase - Plan 5', 'field': 'suggestedIncreasePlan5' },
    { 'header': 'Suggested Increase - Plan 6', 'field': 'suggestedIncreasePlan6' }
  ];
  public static VIS_DEN_BULK_EDITABLE_COLUMNS = [
    "Proposed Increase",
    "RA - Adj - Plan 1",
    "RA - Adj - Plan 2",
    "RA - Adj - Plan 3",
    "RA - Adj - Plan 4",
    "RA - Adj - Plan 5",
    "RA - Adj - Plan 6",
    "UW note to sales",
    "UW note to self"
  ];
  public static COMPLIANCE_CHECK_MSG: string = "Compliance Failed for ";
  public static DELETE_CONFIRMATION_MSG = "Do you want to unlink the selected groups?";
  public static BULK = "BULK";
  public static BATCH = "BATCH";
  public static HAS_DELETED_GROUPS = "hasDeletedGroups";
  public static DELETE_SUCCESS_MSG = "The selected group(s) are deleted from Batch.";
  public static RESTORE_SUCCESS_MSG = "Restored all deleted groups successfully.";
  public static AUTO_RUN_BATCH = 'autoRunBatch';
  public static FAILED_TIERING_MSG = 'An error occurred during tiering. Rate Action is not calculated for this group'
  public static BATCH_SUBMIT_OPTIONS = [
    {
      "label": "Original Quotes",
      "value": "ORIGNAL_QUOTES"
    },
    {
      "label": "Alternate Quotes",
      "value": "ALTERNATE_QUOTES"
    },
    {
      "label": "Opp Creation",
      "value": "OPP_CREATION"
    },
    // {
    //   "label": "Opp Creation – New Exp",
    //   "value": "OPP_CREATION_New_Exp"
    // },
   
  ];
  public static BATCH_SUBMIT_OPTIONS_SUPP_HEALTH = [
    {
      "label": "Original Quotes",
      "value": "ORIGNAL_QUOTES"
    },
    {
      "label": "Opp Creation",
      "value": "OPP_CREATION"
    }
  ];

  public static alternateQuotes = [
    {
      "marketSegment": "LG",
      "fundingOptions": {
        "FI": {
          "quoteHeaderID": "QT4884831092796527",
          "quoteRenewalStatus": "Pending Review",
          "submissionStatus": "Queued for Rating",
          "isSelected": true,
          "isEnabled": false,
          "isSubmitted": true,
          "isQueuedForDataGathering": true,
          "isRequestCreated": true,
          "isSubmittedToGateWay": false
        }
      }
    },
    {
      "marketSegment": "SG",
      "fundingOptions": {
        "ACA": {
          "quoteRenewalStatus": "Not Submitted",
          "submissionStatus": "Success",
          "isSelected": true,
          "isEnabled": false,
          "isSubmitted": true,
          "isQueuedForDataGathering": true,
          "isRequestCreated": true,
          "isSubmittedToGateWay": true
        }
      }
    }
  ];
}

export class getFIFieldHeader {
  public static headers = [
      {
        label: 'Claims of date',
        field: 'claimsAsOfDate',
        formatType: 'string',
      },
      {
        label: 'Census - Subs',
        field: 'censusSubscriberCount',
        formatType: 'number'
      },
      {
        label: 'Census - Mems',
        field: 'censusMemberCount',
        formatType: 'number'
      },
      {
        label: 'Loss Ratio',
        field: 'lossRatio',
        formatType: 'percent'
      },
      {
        label: 'Formula Increase',
        field: 'formulaIncrease',
        formatType: 'percent'
      },
      {
        label: 'No of Large Claims',
        field: 'numberOfLargeClaims',
        formatType: 'number'
      },
      {
        label: 'Total Large Claims',
        field: 'totalLargeClaims',
        formatType: 'flat-dollar'
      },
      {
        label: 'Claims over Threshold',
        field: 'claimsOverThreshold',
        formatType: 'flat-dollar'
      },
      {
        label: 'Manual Increase',
        field: 'manualIncrease',
        formatType: 'percent',
      },
      {
        label: 'Claims Only Increase',
        field: 'claimsOnlyIncrease',
        formatType: 'percent',
      }
    ];
  }

export class getABFFieldHeader  {
  public static headers = [
    {
      label: 'Claims of date',
      field: 'claimsAsOfDate',
      formatType: 'string',
    },
    {
      label: 'Census - Subs',
      field: 'censusSubscriberCount',
      formatType: 'number'
    },
    {
      label: 'Census - Mems',
      field: 'censusMemberCount',
      formatType: 'number'
    },
    {
      label: 'Loss Ratio',
      field: 'lossRatio',
      formatType: 'percent'
    },
    {
      label: 'Formula Increase',
      field: 'formulaIncrease',
      formatType: 'percent'
    },
    {
      label: 'No of Large Claims',
      field: 'numberOfLargeClaims',
      formatType: 'number'
    },
    {
      label: 'Total Large Claims',
      field: 'totalLargeClaims',
      formatType: 'flat-dollar'
    },
    {
      label: 'Total over SSL',
      field: 'totalOverSsl',
      formatType: 'flat-dollar'
    },
    {
      label: 'Manual Increase',
      field: 'manualIncrease',
      formatType: 'percent',
    },
    {
      label: 'Claims Only Increase',
      field: 'claimsOnlyIncrease',
      formatType: 'percent',
    },
    {
      label: 'Surplus/Deficit',
      field: 'surplusOrDeficit',
      formatType: 'flat-dollar'
    },
    {
      label: 'CY Contract SSL Loss Ratio', 
      field: 'cyContractSslLossRatio',
      formatType: 'percent',
    },
    {
      label: 'CY Contract Max Claims Fund LR',
      field: 'cyContractMaxClaimsFundLossRatio',
      formatType: 'percent',
    }
  ]
}