import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { RenewalsConstants } from '../renewals-constants';

@Injectable({
  providedIn: 'root'
})
export class RenewalsService {

  constructor(private http: HttpClient,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,) { }

  // specialty renewal upload
  uploadSpecialtyBatch(file, batchName) {
    let formData: FormData = new FormData();
    formData.append("file", file);
    let rareUiRequest: any = this.commonService.getRareUiRequestForSpecialtyUpload(batchName);
    formData.append("request", JSON.stringify(rareUiRequest));
    let headers = this.commonService.setRequestHeaders();
    return this.http.post(this.commonService.getRareUiUrl() + "/renewal/file/upload", formData, { headers: headers, observe: 'response' }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));

  }

  // specialty renewal upload
  uploadImportFileBatch(file, batchID, lob, fundingType, marketSegment) {
    let formData: FormData = new FormData();
    formData.append("file", file);
    let rareUiRequest: any = this.commonService.getRareUiRequestForImportFileUpload(batchID);
    formData.append("request", JSON.stringify(rareUiRequest));
    formData.append("lob", lob);
    formData.append("fundingType", fundingType);
    formData.append("marketSegment", marketSegment);
    let headers = this.commonService.setRequestHeaders();
    return this.http.post(this.commonService.getRareUiUrl() + "/bulk-adjustment/file/validate-upload", formData, { headers: headers, observe: 'response' }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  getBulkAdjExportExcelData(transarr) {
    let headers = this.commonService.setRequestHeaders();
    let metadata = {
      "userid": this.authenticationService.getUserID(),
      "username": this.authenticationService.getUserName(),
      "targetSystem": "RATING_ENGINE",
      "sourceSystem": "COM2",
      "metaTransID": "abc"
    }
    transarr["metadata"] = metadata
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/ui/bulkRenewalAdjustmentTemplate/download", transarr, { headers: headers });
  }

  getBulkAdjExcelData(transarr) {
    let headers = this.commonService.setRequestHeaders();
    let metadata = {
      "userid": this.authenticationService.getUserID(),
      "username": this.authenticationService.getUserName(),
      "targetSystem": "RATING_ENGINE",
      "sourceSystem": "COM2",
      "metaTransID": "abc"
    }
    transarr["metadata"] = metadata
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/ui/bulkRenewalAdjustment/download", transarr, { headers: headers });
  }

  getCTBulkAdjExcelData(transarr) {
    let headers = this.commonService.setRequestHeaders();
    let metadata = {
      "userid": this.authenticationService.getUserID(),
      "username": this.authenticationService.getUserName(),
      "targetSystem": "RATING_ENGINE",
      "sourceSystem": "COM2",
      "metaTransID": "abc"
    }
    transarr["metadata"] = metadata
    return this.http.post<any>(this.commonService.getRareUiUrl() + "/ui/CTbulkRenewalAdjustment/download", transarr, { headers: headers });
  }

  // saving renewal details fetched from data-mart
  saveRenewalDetails(renewalBatchData: any): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    let requestData = this.commonService.getRareUiRequest(renewalBatchData);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/renewal/batch/save', requestData, { headers: header }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  // Submitting Renewal Batch fetched from data-mart
  submitRenewalBatch(renewalBatchData: any): Observable<any> {
    const headers = this.commonService.setRequestHeaders();
    let requestData = this.commonService.getRareUiRequest(renewalBatchData);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/renewal/batch/submit', requestData, { headers: headers }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  // call tiering API for LG, Vision and Dental to calculate rates based on the details
  callTieringAPIForLGVisDen(renewalBatchData: any): Observable<any> {
    const headers = this.commonService.setRequestHeaders().set('meta-senderapp', 'RARE-UI').set('batchID', renewalBatchData?.renewalBatch?.id ?? '');
    let requestData = this.commonService.getTieringRequestForLGVisDen(renewalBatchData);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/renewal/tiering/tier', requestData, { headers: headers }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  // Fetching Saved renewal details based on Batch ID
  fetchRenewalDetailsByBatch(batchID: string, batchStatus: string): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + `/renewal/batch/${batchID}?batchStatus=` + batchStatus, { headers: header }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  // fetch renewal details fetched from data-mart
  fetchRenewalDetailsFromDatamart(file: any, data: any): Observable<any> {
    let formData: FormData = new FormData();
    if(file) {
    formData.append("file", file);
    }
    const header = this.commonService.setRequestHeaders();
    let requestData = this.commonService.getRareUiRequest(data);
    formData.append("request", JSON.stringify(requestData));
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/renewal/fetch', formData, { headers: header }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  // Save bulk adjustment to calculate rates based on rate action changes - Need to add url once the API is developed
  bulkAdjustmentAction(data: any, action: string) {
    const header = new HttpHeaders().set('meta-senderapp', 'RARE-UI')
      .set('userid', CommonUtil.getUserIDHeader(this.authenticationService))
      .set('username', CommonUtil.getUserNameHeader(this.authenticationService))
      .set('emailId', this.authenticationService.getUserEmail())
      .set('role', this.authenticationService.getUserRole());
    let rareRequest = this.commonService.getRareUiRequest(data);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/renewal/batch/' + action, rareRequest, { headers: header, observe: 'response' });
  }

  autoRunConvertAction(data: any, batchID: string) {
    const header = new HttpHeaders().set('meta-senderapp', 'RARE-UI')
      .set('meta-transid', 'abc')
      .set('batchID', batchID)
      .set('userid', this.authenticationService.getUserID())
      .set('username', this.authenticationService.getUserName())
    let rareRequest = this.commonService.constructChartFilterRequest(data);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/autorun/convert', rareRequest, { headers: header, observe: 'response' });
  }

  bulkAutoRunConvertAction(data: any, batchID: string) {
    const header = new HttpHeaders().set('meta-senderapp', 'RARE-UI')
      .set('meta-transid', 'abc')
      .set('batchID', batchID)
      .set('userid', this.authenticationService.getUserID())
      .set('username', this.authenticationService.getUserName())
    let rareRequest = this.commonService.constructChartFilterRequest(data);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/autorun/bulk/convert', rareRequest, { headers: header, observe: 'response' });
  }

  fetchBulkAdjustmentDetails(batchID: string): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    const params = new HttpParams().set('batchID', batchID);
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/bulk-adjustment/fetch-details', { headers: header, params: params });
  }

  fetchAutoRunBatchDetails(batchID: string): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    const params = new HttpParams().set('batchID', batchID);
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/autorun/fetch-details', { headers: header, params: params });
  }

  // Http client method to delete renewal groups which are already saved
  deleteRenewalGroups(deleteInfo: any) {
    const header = this.commonService.setRequestHeaders();
    return this.http.delete(this.commonService.getRareUiUrl() + '/renewal/delete-renewal-groups', { headers: header, body: deleteInfo });
  }

  restoreRenewalGroups(deleteInfo: any) {
    const header = this.commonService.setRequestHeaders();
    return this.http.delete(this.commonService.getRareUiUrl() + '/renewal/restore-renewal-groups', { headers: header, body: deleteInfo });
  }

  fetchBulkExhibitsZipDownloadLink(data, batchID: string) {
    const headers = new HttpHeaders().set('batchID', batchID).set('userid', this.authenticationService.getUserID())
      .set('username', this.authenticationService.getUserName()).set('emailId', this.authenticationService.getUserEmail()).set('role', this.authenticationService.getUserRole());
    let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/renewal/batch/fetch/exhibits/zip', requestData, { headers: headers }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));

  }

  getBatchesByQuery(queryString, pageLimit, cursor) {
    let headers = this.commonService.setRequestHeaders();
    this.storage.set('batchSearchQuery', queryString);
    if (pageLimit)
      this.storage.set('batchpageLimit', pageLimit);
    if (cursor)
      this.storage.set('batchcursor', cursor);
    if (pageLimit && cursor)
      return this.http.get<any>(this.commonService.getRareUiUrl() + "/renewal/batchFilter?cursor=" + encodeURIComponent(JSON.stringify(cursor)) + "&pageLimit=" + pageLimit + "&searchQuery=" + encodeURIComponent(queryString), { headers: headers });
    else if (pageLimit)
      return this.http.get<any>(this.commonService.getRareUiUrl() + "/renewal/batchFilter?pageLimit=" + pageLimit + "&searchQuery=" + encodeURIComponent(queryString), { headers: headers });
    else
      return this.http.get<any>(this.commonService.getRareUiUrl() + "/renewal/batchFilter?searchQuery=" + encodeURIComponent(queryString), { headers: headers });
  }

  /*batch search service*/
  getBatchData(form: FormGroup, pageLimit: number, cursor: any, sortMetaData: any): Observable<any> {
    let queryObject = {};
    let dateArray = <any>[];
    let flagFromdate: boolean = false;
    let flagTodate: boolean = false;
    Object.keys(form.controls).forEach(key => {
      if (form.value[key] != "" && form.value[key] != null) {
        if (key == "fromdate" || key == "todate") {
          let day = form.value[key].getDate();
          let month = form.value[key].getMonth() + 1;
          let year = form.value[key].getFullYear();
          let date = year + '-' + month + '-' + day;
          dateArray.push(date);
        }
        else {
          let keyValue = form.value[key];
          if (key === "batchName") {
            keyValue = { "$regex": ".*" + this.commonService.escapeRegExp(keyValue.trim()) + ".*" };
          }
          if (key === "createdBy") {
            keyValue = { "$regex": ".*" + this.commonService.escapeRegExp(keyValue.trim()) + ".*" };
          }
          if (key === "lobs") {
            keyValue = { "$in": form.get("lobs").value };
          }
          queryObject[key] = keyValue;
        }
      }
      else {
        if (key === "fromdate") {
          flagFromdate = true;
        }
        else if (key === "todate") {
          flagTodate = true;
        }
      }
      if (StringUtils.isEqual(key, CommonConstants.QUOTE_REASON)) {
        queryObject[key] =
          form.value[key] === true
            ? CommonConstants.TEST
            : CommonConstants.REAL;
      }
      if (StringUtils.isEqual(key, CommonConstants.BATCH_ORIGIN)) {
        if (form.value[key]) {
          queryObject[key] = RenewalsConstants.AUTO_RUN_BATCH;
        }
      }

    });
    if (dateArray.length) {
      let key = "createdTimestamp";
      let value1;
      if (dateArray.length === 2) {
        value1 = { "$gte": dateArray[0] + " 00:00:00", "$lte": dateArray[1] + " 23:59:59" };
      }
      else {
        if (flagFromdate) {
          value1 = { "$lte": dateArray[0] + " 23:59:59" };
        }
        if (flagTodate) {
          value1 = { "$gte": dateArray[0] + " 00:00:00" };
        }
      }
      queryObject[key] = value1;
    }
    let queryString = JSON.stringify(queryObject);
    this.storage.set('batchSearchQuery', queryString);
    let urlComponents = "?searchQuery=" + encodeURIComponent(queryString);

    if (pageLimit) {
      this.storage.set('batchpageLimit', pageLimit);
      urlComponents = urlComponents + "&pageLimit=" + pageLimit;
    }
    if (cursor) {
      this.storage.set('batchcursor', cursor);
      urlComponents = urlComponents + "&cursor=" + encodeURIComponent(JSON.stringify(cursor));
    }
    if (sortMetaData) {
      urlComponents = urlComponents + "&sortMetaData=" + encodeURIComponent(sortMetaData);
    }
    let headers = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + "/renewal/batchFilter" + urlComponents, { headers: headers });
  }

  getRenewals(WGCnumber: any, quoteReason: any) {
    let reqHeaders = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/renewals/process?wgs-case-number=' + WGCnumber + '&quoteReason=' + quoteReason, { headers: reqHeaders })
  }
  getSourceSystemForRenewals() {
    let reqHeaders = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/ui/renewal/system-source-codes', { headers: reqHeaders })
  }

  getLobsForRenewalCreateBatch() {
    let reqHeaders = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/ui/renewal/lobs', { headers: reqHeaders })
  }

  downloadRenewalBatchDetails(data: any): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post(this.commonService.getRareUiUrl() + '/renewal/download/renewal-groups-search-results', requestData, { headers: header }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  downloadOveragedDepedents(data: any): Observable<any> {
    const header = this.commonService.setRequestHeaders().set('meta-senderapp', 'RARE-UI').set('batchID', data?.batchID ?? '').set('batchName', data?.batchName ?? '');
    let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post(this.commonService.getRareUiUrl() + '/renewal/overaged/dependents/download',
      requestData, { headers: header }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  getTieringInput(data: any): Observable<any> {
    const header = this.commonService.setRequestHeaders().set('meta-senderapp', 'RARE-UI');
    // let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post(this.commonService.getRareUiUrl() + '/renewal/tiering/getTieringInput', data, { headers: header }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }

  rePullTier(data: any): Observable<any> {
    const headers = this.commonService.setRequestHeaders().set('meta-senderapp', 'RARE-UI').set('batchID', data?.batchID ?? '');
    // let requestData = this.commonService.getRareUiRequest(data);
    return this.http.post(this.commonService.getRareUiUrl() + '/renewal/tiering/tier', data, { headers: headers }).pipe(catchError(err => {
      return throwError(err.error.exceptions);
    }));
  }  

  generatePrintExhibit(batchID, data) {
    let headers = this.commonService.setBatchHeaders(batchID);
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/renewal/tiering/botsheet/download', data,{headers: headers});
  }
}
