import { CommonConstants } from "../shared/constants/common.constants";
import { BATCH_ORIGIN, QUOTE_ORIGIN } from "../shared/models/renewal-batch-details";
import { StringUtils } from "../shared/utils/string-utils";

/** *****************************************************************************
 * Copyright (c) Anthem. All rights reserved.
 * Use is subject to license terms.
 * RenewalsUtil class to support common functionalities Renewals modules.
 * Need to create new common shared module and move this to shared module.
 *
 ***********************************************************************************/
export class RenewalsUtil {
    /**
     * Function to update batch request data for save and submit batch
     * Add quoteReason as TEST of TEST checkbox is selected in UI.
     * If not selected defaults to REAL
     * @param renewalBatchWrapper
     * @param batchName
     * @param batchStatus
     * @param fileUploadStatus
     * @param quoteReason
     * @param isAutoRunBatch
     * @returns
     */
    public static buildRenewalWrapper(
        renewalBatchWrapper,
        batchName,
        batchStatus,
        fileUploadStatus,
        quoteReason,
        isAutoRunBatch,
        associationCodes
    ) {
        let finalQuoteReason;
        switch (quoteReason) {
            case true:
                finalQuoteReason = CommonConstants.TEST;
                break;
            default:
                finalQuoteReason = CommonConstants.REAL;
        }
        return {
            ...renewalBatchWrapper.renewalBatch,
            batchName: batchName,
            batchStatus,
            fileUploadStatus: fileUploadStatus,
            quoteReason: finalQuoteReason,
            // If Auto Run Batch is selected, set the batchOrigin to AUTO_RUN else default USER_BATCH
            batchOrigin: isAutoRunBatch ? BATCH_ORIGIN.AUTO_RUN_BATCH : BATCH_ORIGIN.USER_BATCH,
            associationCodes
        };
    }

    /**
     * Function to Add/Remove Original Group Number Header for Renewal Batch
     * @param quoteReason
     * @param renewalBatchColumns
     */
    public static updateRenewalBatchColumns(quoteReason, renewalBatchColumns) {
        let originalGroupData = {
            showOriginalGroupNumber: false,
            batchColumns: renewalBatchColumns,
        };
        quoteReason = quoteReason ? CommonConstants.TEST : CommonConstants.REAL;
        let originlGroupNumberColumn = renewalBatchColumns.find(
            (renewalBatchColumn) =>
                StringUtils.isEqual(
                    renewalBatchColumn.header,
                    CommonConstants.ORIGINAL_GROUP_NUMBER_LABEL
                )
        );

        if (
            StringUtils.isEqual(quoteReason, CommonConstants.REAL) &&
            originlGroupNumberColumn
        ) {
            originalGroupData.batchColumns = renewalBatchColumns.filter(
                (columns) =>
                    columns.header != CommonConstants.ORIGINAL_GROUP_NUMBER_LABEL
            );
        } else if (StringUtils.isEqual(quoteReason, CommonConstants.TEST)) {
            if (!originlGroupNumberColumn) {
                renewalBatchColumns.splice(1, 0, {
                    header: CommonConstants.ORIGINAL_GROUP_NUMBER_LABEL,
                    field: CommonConstants.ORIGINAL_GROUP_NUMBER_KEY,
                });
            }
            originalGroupData.showOriginalGroupNumber = true;
        }
        return originalGroupData;
    }

    /**
     * Function to update validation errors for asl and group refund.
     * @param renewalBatchWrapper
     * @param category
     * @param groupNumber
     * @param overRideDetails
     * @returns
     */
    public static updateOverRideDetails(renewalBatchWrapper, category, groupNumber, overRideDetails) {
        renewalBatchWrapper.renewalBatchDetails.forEach((batchDetail) => {
            if (StringUtils.isEqual('REFUND_PCT', category)) {
                if (overRideDetails['refundPctErrors']?.length == 0) {
                    overRideDetails['refundPctErrors'].push({
                        groupNumber: groupNumber
                    });
                }
                overRideDetails['refundPctErrors']?.forEach(refundPctError => {
                    if (refundPctError.groupNumber != groupNumber) {
                        overRideDetails['refundPctErrors'].push({
                            groupNumber: groupNumber
                        });
                    }
                });
            } else if (StringUtils.isEqual('ASL', category)) {
                if (overRideDetails['aslErrors']?.length == 0) {
                    overRideDetails['aslErrors'].push({
                        groupNumber: groupNumber
                    });
                }
                overRideDetails['aslErrors']?.forEach(aslError => {
                    if (aslError.groupNumber != groupNumber) {
                        overRideDetails['aslErrors'].push({
                            groupNumber: groupNumber
                        });
                    }
                });
            }
        });
        return overRideDetails;
    }

    /**
     * Short term fix
     * Checks if MBU is in the list of National MBUs
     * Return true/false if present in the keys.
     * @param mbu
     * @param mbuList
     */
    public static isMBUNational(mbu, mbuList) {
        const mbuSubstring = mbu ? mbu.substring(0, mbu.length - 2) : mbu;
        return mbuSubstring in mbuList;
    }

    /**
* This checks the local storage for status reason and remove if exist
*/
    public static checkDeclineReasonLocalStorage(renewalBatchWrapper: any) {
        if (renewalBatchWrapper.renewalBatchDetails.length > 0) {
            renewalBatchWrapper.renewalBatchDetails.forEach(batchDetail => {
                if (batchDetail.included) {
                    let statusReasonKey = `statusReasons_${batchDetail.quoteHeaderID}_${batchDetail.lob}_${batchDetail.fundingType}`;
                    if (!StringUtils.isEmpty(localStorage.getItem(statusReasonKey))) {
                        localStorage.removeItem(statusReasonKey);
                    }
                }
            });
        }
    }

    /**
     * Checks if provided column is commission and if lobs do not include Medical
     * @param column
     * @param renewalBatchWrapper
     */
    public static hideCommissionColumns(column: string, renewalBatchWrapper: any) {
        return CommonConstants.COMMISSION_COLUMNS.includes(column) && !renewalBatchWrapper?.renewalBatchDetails.some(batchDetail => StringUtils.isEqualIgnoreCase(CommonConstants.Medical, batchDetail.lob));
    }
}
