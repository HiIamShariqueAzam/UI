
import { Component, OnInit, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { WebStorageService, SESSION_STORAGE } from 'ngx-webstorage-service';
import { DatePipe } from '@angular/common';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { RenewalForm } from 'src/app/shared/models/renewalDetails';
import { RenewalsService } from '../../services/renewals.service';
import { SearchConstants } from 'src/app/quotes/quote-search/constants';
import { QUOTE_ORIGIN } from 'src/app/shared/models/renewal-batch-details';
@Component({
  selector: "app-search-batch",
  templateUrl: "./search-batch.component.html",
  styleUrls: ["./search-batch.component.css"],
  standalone: false,
})
export class SearchBatchComponent implements OnInit {
  renewal_form: FormGroup<RenewalForm>;
  showOpportunities: boolean = false;
  showRenewal: boolean = false;
  nextButtonClicked: boolean;
  prevButtonClicked: boolean;
  nextCursor: any;
  prevCursor: any;
  selectedPageSize: any;
  isSearched: boolean = false;
  isEmpty: boolean = false;
  rowData: any[];
  totalPages;
  onRowSelect: any;
  selectedOpportunity: any;
  multiSortMeta = [
    {
      field: "batchName",
      order: 1,
    },
    {
      field: "createdBy",
      order: 1,
    },
    {
      field: "createdTimestamp",
      order: 1,
    },
    {
      field: "batchStatus",
      order: 1,
    },
    {
      field: "quoteReason",
      order: 1,
    }
  ];
  rows: any;
  renewalSubmit: any;
  showNextButton: boolean = false;
  showPrevButton: boolean = false;
  pageIndex = 1;
  first = 0;
  isAdminUser: boolean = false;
  isRenewalBatchUser: boolean = false;
  availableLOB: any[];
  lobMultiSelect: any;
  selectedLOB: any;

  constructor(
    private http: HttpClient,
    public datepipe: DatePipe,
    private router: Router,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private fb: FormBuilder,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    public renewalsService: RenewalsService
  ) {}

  rowsPerPage: any[];
  validateDate(dateFrom: string, dateTo: string) {
    return (formGroup: FormGroup) => {
      const datefrom = formGroup.controls[dateFrom];
      const dateto = formGroup.controls[dateTo];
      if (new Date(datefrom.value) > new Date(dateto.value)) {
        datefrom.setErrors({ invalidFromDate: true });
      } else {
        if (datefrom.hasError("required")) {
          datefrom.setErrors(null);
          datefrom.setErrors({ required: true });
        } else {
          datefrom.setErrors(null);
        }
      }
    };
  }
  onGoToPage(rowData?) {
    if(this.isLobSuppHealth(rowData?.lobs)){
      this.router.navigate(["group/batch/create-batch-supp-health"], {
        queryParams: {
          batchId: rowData.id,
          batchStatus: rowData.batchStatus,
          batchName: rowData.batchName,
          headerName: "Renewal Batch",
          fileUploadStatus: rowData.fileUploadStatus,
          quoteReason: rowData.quoteReason,
          ...(rowData.batchOrigin ? { batchOrigin: QUOTE_ORIGIN.AUTO_RUN_BATCH } : {})
        },
      })
    } else {
      rowData
        ? this.router.navigate(["group/batch/create-batch"], {
          queryParams: {
            batchId: rowData.id,
            batchStatus: rowData.batchStatus,
            batchName: rowData.batchName,
            headerName: "Renewal Batch",
            fileUploadStatus: rowData.fileUploadStatus,
            quoteReason: rowData.quoteReason,
            ...(rowData.batchOrigin ? { batchOrigin: QUOTE_ORIGIN.AUTO_RUN_BATCH } : {})
          },
        })
        : this.router.navigate(["group/batch/create-batch"], {
          queryParams: { headerName: "Create Batch Renewal" },
        });
    }
  }
  paginate(event) {
    this.pageIndex = event.first / event.rows + 1;
    this.storage.set("batchfirst", event.first);
    this.storage.set("batchpageIndex", this.pageIndex);
  }

  isLobSuppHealth(lobs){
    if(lobs){
      const findIndex = lobs.findIndex(lob => lob === "Supp Health");
      return findIndex !== -1;
    } else {
      return false;
    }
  }

  ngOnInit() {
    this.isAdminUser = CommonUtil.userHasAdminRole(this.authenticationService.userRole["_value"]);
    this.isRenewalBatchUser = CommonUtil.userHasRenewalBatchRole(this.authenticationService.userRole["_value"]);
    this.renewal_form = this.fb.group(
      {
        batchName: [""],
        createdBy: [""],
        fromdate: [""],
        todate: [""],
        lobs: [""],
        quoteReason: [''],
        batchOrigin: ['']
      },
      {
        validator: this.validateDate("fromdate", "todate"),
      }
    );
    this.rowsPerPage = [
      { label: "10", value: 10 },
      { label: "20", value: 20 },
      { label: "30", value: 30 },
    ];
    this.selectedPageSize = this.rowsPerPage[0];
    if (this.storage.get("showRenewal") === "true") {
      this.showRenewal = this.storage.get("showRenewal");
      if (this.storage.get("batchSearchQuery")) {
        this.getRowData(
          this.storage.get("batchSearchQuery"),
          this.storage.get("batchpageLimit"),
          this.storage.get("batchcursor")
        );
        this.setFormValue();
      } else this.showRenewal = false;
      this.totalPages = this.storage.get("batchtotalPages");
      if (this.storage.get("batchfirst") && this.totalPages > 1) {
        this.first = this.storage.get("batchfirst");
        this.pageIndex = this.storage.get("batchpageIndex");
      } else {
        this.first = 0;
        this.pageIndex = 1;
      }
    } else {
      this.showRenewal = false;
      this.rowData = [];
      this.totalPages = 0;
      this.first = 0;
    }
    this.multiSortMeta = this.storage.get("multiSortMeta");
    this.lobMultiSelect = document.querySelector('.ui-multiselect');
    if (this.lobMultiSelect != null) {
      this.lobMultiSelect.setAttribute('tabindex', -1);
    }
    this.availableLOB = SearchConstants.LOB_LIST;
  }
  setFormValue() {
    this.renewal_form.setValue({
      batchName: this.storage.get("batchbatchName") || "",
      createdBy: this.storage.get("batchcreatedBy") || "",
      fromdate: this.storage.get("batchfromdate")
        ? new Date(this.storage.get("batchfromdate"))
        : null,
      todate: this.storage.get("batchtodate")
        ? new Date(this.storage.get("batchtodate"))
        : null,
      lobs: this.storage.get('lobs') || "",
      quoteReason: this.storage.get('quoteReason'),
      batchOrigin: this.storage.get('batchOrigin')
    });
    if (this.storage.get('lobs')) {
      this.selectedLOB = this.isJson(this.storage.get('lobs'));
    }
    if (this.storage.get("batchpageLimit")){
      this.selectedPageSize = {
        label: "" + this.storage.get("batchpageLimit") + "",
        value: this.storage.get("batchpageLimit"),
      };
    }
  }
  isJson(str) {
    if (typeof str === 'string') {
      let storeItem = [];
      storeItem.push(str)
      return storeItem;
    }
    else {
      return str;
    }
  }
  getRowData(query, pageLimit, cursor) {
    this.renewalsService.getBatchesByQuery(query, pageLimit, cursor).subscribe(
      (response) => {
        if (response.renewalBatches.length) {
          this.showRenewal = true;
          this.showNextButton = response.hasNextCursor;
          this.showPrevButton = response.hasPrevCursor;
          this.nextCursor = response.nextCursor;
          this.prevCursor = response.prevCursor;
          this.rowData = response.renewalBatches;
        } else {
          this.showRenewal = false;
          this.storage.set("showRenewal", "false");
          this.isEmpty = true;
        }
      },
      (error) => {
        this.showRenewal = false;
        this.storage.set("showRenewal", "false");
      }
    );
  }
  get f() {
    return this.renewal_form.controls;
  }
  formSubmitted: boolean = false;
  selcetedFromDate: any;
  selectedToDate: any;
  showEmptyFromDate: boolean = false;
  searchClicked(isRefresh?: boolean) {
    this.isPopupVisible = false;
    let flagFocus = false;
    this.isSearched = true;
    this.isEmpty = false;
    let pageLimit = 10;
    let cursor: any;
    let sortMetaData: any = null;

    if (this.selectedPageSize) pageLimit = this.selectedPageSize.value;

    if (this.nextButtonClicked) {
      cursor = this.nextCursor;
    }

    if (this.prevButtonClicked) {
      cursor = this.prevCursor;
    }
    if (this.multiSortMeta != undefined) {
      sortMetaData = JSON.stringify(this.multiSortMeta);
    }
    let form = this.renewal_form;
    if (
      form.get("fromdate").value !== "" &&
      (form.get("todate").value === "" || form.get("todate").value === null)
    ) {
      form.get("todate").setValue("");
    }

    /*If Fromdate has no value*/
    if (
      (form.get("fromdate").value === "" ||
        form.get("fromdate").value === null) &&
      form.get("todate").value !== "" &&
      form.get("todate").value !== null
    ) {
      this.showEmptyFromDate = true;
    } else {
      this.showEmptyFromDate = false;
    }
    this.formSubmitted = true;
    if (this.renewal_form.invalid) {
      this.isEmpty = true;
      return;
    } else {
      if (!this.showEmptyFromDate) {
        this.showRenewal = false;
        this.rowData = [];
        this.totalPages = 0;
        this.getBatches(form, pageLimit, cursor, sortMetaData, isRefresh);
      } else {
        this.showRenewal = false;
        this.isSearched = false;
        this.storage.set("showRenewal", "false");
      }
    }
  }
  saveMultiSortMeta(event) {
    this.multiSortMeta = event.multisortmeta;
  }
  clickedFromDate() {
    let element: HTMLElement = document.querySelectorAll(
      ".fromdate .p-inputtext"
    )[0] as HTMLElement;
    this.selcetedFromDate = element;
    if (typeof element != "undefined") {
      element.click();
    }
    if (document.querySelector(".fromDateCalendar"))
      (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src =
        "./assets/calendar-blue.svg";
    (<HTMLImageElement>document.querySelector(".toDateCalendar")).src =
      "./assets/calendar.svg";
  }
  focusFromDateEle() {
    if (this.selcetedFromDate) {
      this.selcetedFromDate.focus();
    }
  }
  focusToDateEle() {
    if (this.selectedToDate) {
      this.selectedToDate.focus();
    }
  }
  clickedToDate() {
    let element: HTMLElement = document.querySelectorAll(
      ".todate .p-inputtext"
    )[0] as HTMLElement;
    this.selectedToDate = element;
    if (typeof element != "undefined") {
      element.click();
    }
    if (document.querySelector(".toDateCalendar"))
      (<HTMLImageElement>document.querySelector(".toDateCalendar")).src =
        "./assets/calendar-blue.svg";
    (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src =
      "./assets/calendar.svg";
  }
  hasReadOnly() {
    return this.commonService.hasReadOnlyRole();
  }
  nextClicked() {
    if (this.showNextButton) {
      this.isPopupVisible = false;
      this.nextButtonClicked = true;
      this.searchClicked();
      this.nextButtonClicked = false;
    }
  }
  cols = [
    {
      header: "Batch Name",
      field: "batchName",
    },
    {
      header: "LOBs - FA Type",
      field: "lobs",
    },
    {
      header: "Uploaded/Created By",
      field: "createdBy",
    },
    {
      header: "File Upload Status",
      field: "FileUploadStatus",
    },
    {
      header: "Uploaded/Created Date",
      field: "createdTimestamp",
    },
    {
      header: "Batch Status",
      field: "batchStatus",
    },
  ];

  errorResponse: any;
  isPopupVisible: boolean = false;
  errorPopup(rowData) {
    if (rowData.fileUploadStatus != "Success") {
      this.errorResponse = rowData.errorList;
    }
    this.isPopupVisible = true;
  }
  prevClicked() {
    if (this.showPrevButton) {
      this.isPopupVisible = false;
      this.prevButtonClicked = true;
      this.searchClicked();
      this.prevButtonClicked = false;
    }
  }
  resetClicked() {
    this.isPopupVisible = false;
    this.renewal_form.reset();
    this.showRenewal = false;
    this.rowData = [];
    this.responseData = [];
    this.isEmpty = false;
    this.isSearched = false;
    this.totalPages = 0;
    this.multiSortMeta = null;
    this.showEmptyFromDate = false;
    this.storage.remove("showRenewal");
    this.storage.remove("batchtotalPages");
    this.storage.remove("batchfirst");
    this.storage.remove("batchpageIndex");
    this.storage.remove("batchSearchQuery");
    this.storage.remove("batchbatchName");
    this.storage.remove("batchcreatedBy");
    this.storage.remove("batchfromdate");
    this.storage.remove("batchtodate");
    this.storage.remove("batchpageLimit");
    this.storage.remove("batchcursor");
    this.storage.remove("multiSortMeta");
    this.storage.remove('quoteReason');
    this.storage.remove('batchOrigin');
  }
  responseData = [];

  /**
   * Return a custom width for specific columns
   * @param column
   */
  getStyle(column) {
    let style = {
      width : "",
    };
    switch(column.field) {
      case "lobs": {
        style.width = "150px";
        break;
      }
      case "FileUploadStatus": {
        style.width = "150px";
        break;
      }
      case "createdTimestamp": {
        style.width = "180px";
        break;
      }
      case "batchStatus": {
        style.width = "180px";
        break;
      }
      default: {
        break;
      }
    }
    return style;
  }

  getBatches(form, pageLimit, cursor, sortMetaData, isRefresh?: boolean) {
    this.renewalSubmit = this.renewalsService
      .getBatchData(form, pageLimit, cursor, sortMetaData)
      .subscribe(
        (response) => {
          if (response.renewalBatches.length) {
            this.showRenewal = true;
            this.showNextButton = response.hasNextCursor;
            this.showPrevButton = response.hasPrevCursor;
            this.nextCursor = response.nextCursor;
            this.prevCursor = response.prevCursor;
            this.rowData = response.renewalBatches;
            this.totalPages = Math.ceil(this.rowData.length / 10);
            this.first = 0;
            this.pageIndex = 1;
            this.storage.set("batchfirst", 0);
            this.storage.set("showRenewal", "true");
            this.storage.set("batchtotalPages", this.totalPages);
            this.storage.set("batchpageIndex", 1);
            this.storage.set(
              "batchbatchName",
              this.renewal_form.controls.batchName.value
            );
            this.storage.set(
              "batchcreatedBy",
              this.renewal_form.controls.createdBy.value
            );
            this.storage.set(
              "batchfromdate",
              this.renewal_form.controls.fromdate.value
            );
            this.storage.set(
              "batchtodate",
              this.renewal_form.controls.todate.value
            );
            this.storage.set(
              "lobs",
              this.renewal_form.controls.lobs.value
            );
            this.storage.set(
              "quoteReason",
              this.renewal_form.controls.quoteReason.value
            );
            this.storage.set('batchOrigin', this.renewal_form.controls.batchOrigin.value);
            if (isRefresh) this.storage.remove("batchcursor");
          } else {
            this.showRenewal = false;
            this.storage.set("showRenewal", "false");
            this.isEmpty = true;
          }
        },
        (error) => {
          this.showRenewal = false;
          this.storage.set("showRenewal", "false");
        }
      );
  }
  displayMultiSelectOptionsPanel() {
    if (this.lobMultiSelect) {
      this.lobMultiSelect.focus();
    }
  }
  getLobList(lobList) {
    lobList = CommonUtil.getSortedList(lobList);
    if (lobList && lobList.length > 1) {
      return lobList.join(", ");
    }
    return lobList;
  }
}
