import { DatePipe, formatCurrency, formatPercent, getCurrencySymbol } from "@angular/common";
import {
  AfterViewChecked,
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  Inject,
  LOCALE_ID,
  OnInit,
  ViewChild
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { MultiSelect } from "primeng/multiselect";
import { CommonQuoteService } from "../../../../quotes/services/common-quote.service";
import { UnderwriterAdjustmentService } from "../../../../quotes/uw-adjustment/medical/uw-adjustment.service";
import {
  BulkAdjustmentsSuppHealthService
} from "../../../../quotes/uw-adjustment/supplemental-health/bulk-adjustments-supp-health.service";
import {
  UWAdjustmentChangeSetSuppHealthService
} from "../../../../quotes/uw-adjustment/supplemental-health/uw-adjust-changeset-supp-health.service";
import {
  UnderwriterAdjustmentSuppHealthService
} from "../../../../quotes/uw-adjustment/supplemental-health/uw-adjustment-supp-health.service";
import { CommonConstants } from "../../../../shared/constants/common.constants";
import { BatchSaveGroup, BatchSearchForm, DownloadForm } from "../../../../shared/models/batchDetails";
import {
  AlertType,
  BatchQuoteStatusEmitStatus,
  BatchSSEProcess,
  NonChangeableRenewalStatuses,
  QuoteRenewalStatus,
  QuoteSubmissionStatus,
  ReleaseSteps,
  RenewalBatchDetails,
  RenewalBatchWrapper,
  SubmissionStatus,
  BATCH_ORIGIN
} from "../../../../shared/models/renewal-batch-details";
import { AuthenticationService, CommonService, PrintExhibitService } from "../../../../shared/services";
import { ValidationService } from "../../../../shared/services/validation.service";
import { CalculatorUtils } from "../../../../shared/utils/calculator-utils";
import { CommonUtil } from "../../../../shared/utils/common-util";
import { StringUtils } from "../../../../shared/utils/string-utils";
import { RenewalsConstants } from "../../../renewals-constants";
import { RenewalsUtil } from "../../../renewals-util";
import { RenewalsService } from "../../../services/renewals.service";
import { CreateBatchUtil } from "../../create-batch/create-batch-util";
import { CreateBatchUtilSuppHealth } from "./create-batch-util-supp-health";
import { ValidationUtils } from "src/app/shared/utils/validation-utils";

@Component({
  selector: 'app-create-batch-supp-health',
  templateUrl: './create-batch-supp-health.component.html',
  styleUrls: ['../../shared-batch-styles.css', './create-batch-supp-health.component.css'],
  standalone: false,
})
export class CreateBatchSuppHealthComponent
  implements OnInit, AfterViewInit, AfterViewChecked {
  @ViewChild("renwalParentDiv") parentDiv: ElementRef;
  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  disableBulkAdj: boolean = true;
  hideFooterBtn: boolean = false;
  showFileError: boolean = false;
  selectedGroupsFromQuery: string[] = [];
  file: File;
  batchSearchForm: FormGroup<BatchSearchForm>;
  batchSaveGroup: FormGroup<BatchSaveGroup>;
  batchSaveGroupSubmitted: boolean = false;
  formSubmitted: boolean = false;
  checkAllDetails: boolean = false;
  checkAllBulkDetails: boolean = false;
  lob_FT = [];
  associationCodes = []
  multiselectEle: any;
  availableStates: any[];
  showLoader: boolean = false;
  batchStatus: string;
  availableLOBs: any[];
  availableMarketSegs: any[];
  searchResults: any[] = [];
  checkAllDetailsOverlay: boolean = false;
  private includedMapToRestore: Map<string, boolean> | null = null;
  availableFTs: any[];
  availableMBS: any[];
  availableRenewalMonths: any[];
  loader_visible: boolean = false;
  showExhibitsZipDownloadLink: boolean = false;
  receivedCurrentExhibitEvents = [];
  currentExhibitLinkProcessId: string = null;
  fileUploadStatus: any;
  lastSearchResults:any[] = [];
  lastSearchCriteria:any = null;
  completedBatchRequests = [];
  receivedBatchEvents = [];
  alert = {
    show: false,
    message: "",
    type: "",
    cssClass: "",
    header: "",
    headerVisibility: true,
    isSearch: false
  };
  renewalBatchWrapper: RenewalBatchWrapper = {
    renewalBatch: {},
    renewalBatchDetails: [],
    failedGrpNbrsInSearch: [],
  };
  createOpportunityURL: string = '/opportunity/create-opportunity-new';
  viewMode: boolean = false;
  headerName: string;
  detailsByFileUpload: boolean;
  selectedMode: string = '';
  tableDataExist: boolean;
  isFIRewewal: boolean = false;
  isFIRewewalSearch: boolean = false;
  isDirty = false;
  onMouseFocus(event) {
    this.multiSelect.show();
    event.stopPropagation();
  }

  first = 0;
  disableFundingType = false;
  searchBatchTab: boolean = true;
  activeTab = "BATCH";
  expandClicked = false;
  uwSalesNoteIconClicked = false;
  uwSelfNoteIconClicked = false;
  rateActionAdjustmentIconClicked = false;
  showTab = false;

  sortableColList = [
    "Release Status",
    "UW note to sales",
    "UW note to self",
    "RA - Adj - Accident",
    "RA - Adj - Hosp Indem",
    "RA - Adj - Crit Illness"
  ];
  bulkEditColumn = [
    ...RenewalsConstants.SUPP_HEALTH_BULK_EDITABLE_COLUMNS
  ];
  bulkTableCols = [...RenewalsConstants.BULK_TABLE_COLUMNS_BEFORE];

  bulkViewTableData = [];
  bulkAdjData = [];
  selectstate: any;
  selectedLOB: any;
  selectmonths: any;
  selectedYear: any;
  selectedRenewalMonthYear:any;
  fieldToPercentConvert = [];

  fieldToConcatPrcnt = [
    "adjustedRateActionPercent",
    "suppHealthOverallSuggestedIncrease",
    "suppHealthOverallProposedIncrease"
  ];
  readonly BATCH_INFO_SMALL_TH: string[] = ['Source System', 'Group Number', 'Market Segment', 'Group Refund', 'Comm Value'];

  expTotalRateActionPercent;
  uwTotalRateActionPercent;
  currentPlanTotPrem = 0;
  renewalPlanTotPrem = 0;
  adjustedPlanTotprem = 0;
  valueChanged = "";
  changedKey = "";
  cmplnFldCodes = [];
  overRideDetails: any;
  private static BATCH_EXHIBITS_BASE_PATH = "/data/batch/exhibits/";

  isAdminUser: boolean = false;
  isUserReadOnly: boolean = false;
  quoteReason: boolean = false;
  isAutoRunBatch: boolean = false;
  showOriginalGroupNumber: boolean = false;
  hideTestBatch: boolean = false;
  renewalBatchColumns = RenewalsConstants.RENEWAL_BATCH_COLUMNS;
  renewalBatchColumnsNewBatch = RenewalsConstants.RENEWAL_BATCH_COLUMNS_NEW_BATCH;
  isSaveFlow = false;
  isSaveDataExist = false;
  selectedMbs: any;
  renewalMonthsFromResponse: any[] = []
  statesFromResponse: any[] = []
  marketSegmentsFromResponse: any[] = []
  hasDeletedGroupsInBatch: boolean = false;
  hasDeletedGroupsInBulk: boolean = false;
  showDeleteInBulkTab: boolean = false;
  batchSearch: any;
  isSearchChanged: boolean = false;
  groupNumbersFile: any;
  private eventSources: EventSource[] = [];
  enabledBatchGroupDownload: boolean;
  batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS_SUPP_HEALTH;
  selectedSubmitOptions: any = [];
  invalidGroupsTooltipMsg: string = '';
  
  constructor(
    private commonService: CommonService,
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private cdRef: ChangeDetectorRef,
    private uwChangeSetService: UWAdjustmentChangeSetSuppHealthService,
    private uwAdjService: UnderwriterAdjustmentSuppHealthService,
    private peService: PrintExhibitService,
    private Ref: ElementRef,
    public datepipe: DatePipe,
    public renewalsService: RenewalsService,
    public bulkAdjustmentsSuppHealthService: BulkAdjustmentsSuppHealthService,
    @Inject(LOCALE_ID) private locale: string,
    private commonQuoteService: CommonQuoteService
  ) { }
  availableVersions: any[];
  availabelSystems: any[];
  selectedVersion: any;
  selectedSystem: any;
  download_form: FormGroup<DownloadForm>;
  fundTypeFromDetails: string = '';
  isFIselectedDropdown: string;
  mbuList: any;
  availableDatasourcesForBatchScreenSearchOverlay: any[];
  selectedDatasourceForBatchScreenSearchOverlay: any;
  enableSendToOppForSuppHealth: boolean = false;
  lobFundingTypeMapForSendToOpp = this.commonService.getEnableSendToOppMap();
  includeTestQuotesSelected: boolean = false;

  ngOnInit() {
    this.commonService.getNationalMbu().subscribe(response => {
      this.mbuList = response;
    });
    this.selectedSubmitOptions = ['ORIGNAL_QUOTES'];
    this.disableFundingType = this.commonService.fiRenewalEnabled;
    this.renewalsService.getSourceSystemForRenewals()
      .subscribe(systems => {
        this.availabelSystems = systems?.sourceSystemCodes;
      })
    this.selectedSystem = ["808"]
    const myDropdown =
      this.Ref.nativeElement.querySelector("downloadMouseHover");
    if (myDropdown) {
      myDropdown.click();
    }
    this.availableVersions = [
      { label: "V1", value: "NON_CT_STATE" },
      { label: "V2", value: "CT_STATE" },
    ];
    this.selectedVersion = ["NON_CT_STATE", "CT_STATE"];
    this.batchSaveGroup = this.fb.group({
      batchName: ["", [Validators.minLength(3), Validators.required]],
      quoteReason: [""],
      isAutoRunBatch: [""],
    });
    this.download_form = this.fb.group({
      downloadOptions: [""],
    });
    this.availableDatasourcesForBatchScreenSearchOverlay = this.commonService.getDatasourcesForBatchScreenSearchOverlay() || [];
    if (!this.batchSearchForm) {
      this.batchSearchForm = this.fb.group({
        groupName: ["", { validators: [Validators.minLength(3)] }],
        groupNumber: ["", { validators: [Validators.minLength(3)] }],
        states: ["", { validators: [Validators.required] }],
        lob: [null, { validators: [Validators.required] }],
        marketSegments: [""],
        fundingTypes: "",
        mbs: ["Key"],
        association: ["Key"],
        renewalMonths: ["", { validators: [Validators.required] }],
        renewalYears: [''],
        renewalMonthYear: [''],
        system: ["808"],
        dataSource: [this.availableDatasourcesForBatchScreenSearchOverlay[0] || ''],
        includeTestQuotes: [''],
      });
    }
    this.route.queryParams.subscribe((params) => {
      // Parse selectedGroups from query params if present
      if (params["selectedGroups"]) {
        this.selectedGroupsFromQuery = params["selectedGroups"].split(",").filter(Boolean);
      } else {
        this.selectedGroupsFromQuery = [];
      }
      if (params["batchId"] && params["batchStatus"]) {
        this.viewMode = true;
        this.renewalBatchWrapper.renewalBatch["id"] = params["batchId"];
        this.renewalBatchWrapper.renewalBatch["batchStatus"] =
          params["batchStatus"];
        this.renewalBatchWrapper.renewalBatch["batchName"] =
          params["batchName"];
        this.fileUploadStatus = params["fileUploadStatus"];
        if (this.renewalBatchWrapper.renewalBatch['batchName']) {
          this.selectedMode = null;
        }
        this.fetchRenewalDetailsByBatch();
      }
      this.headerName = params["headerName"];
      if (params['submissionRedirected']) {
        let alertMsg;
        if (params["description"] && params["description"] == "No Records Found") {
          alertMsg = "No Renewal Groups found.";
          this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
          return;
        }
        alertMsg = "Renewal Batch Submission initiated Successfully.";
        this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
      }
    });

    if (Object.keys(this.renewalBatchWrapper.renewalBatch).length === 0) {
      this.searchBatchTab = true;
    } else {
      this.searchBatchTab = true;
    }

    this.availableStates = this.commonService.getStateList();
    this.availableMarketSegs = CommonConstants.MARKET_SEGEMENT_LIST;

    //Get lobs configured for Create Renewal Batch
    this.renewalsService.getLobsForRenewalCreateBatch().subscribe(lobs => {
      this.availableLOBs = lobs;
      if (this.availableLOBs && this.availableLOBs.length === 1) {
        this.selectedLOB = this.availableLOBs[0];
      }
    });

    this.availableFTs = CommonConstants.FUNDING_TYPE_LIST;
    this.availableMBS = CommonConstants.MBS_LIST;
    this.availableRenewalMonths = CommonConstants.MONTHS_LIST;
    if(this.renewalBatchWrapper?.renewalBatch?.id) {
      this.selectedMbs = [];
    } else {
    this.selectedMbs = ['Key'];
    }
    this.batchSaveGroup
      .get("batchName")
      .setValue(this.renewalBatchWrapper.renewalBatch["batchName"] || "");
    let userRole = this.authenticationService.userRole["_value"];
    this.isAdminUser = CommonUtil.userHasAdminRole(userRole);
    this.isUserReadOnly = this.authenticationService.isUserReadOnly(userRole);
    this.enabledBatchGroupDownload = this.commonService.getEnabledBatchGroupDownload();
    if(this.availableDatasourcesForBatchScreenSearchOverlay && this.availableDatasourcesForBatchScreenSearchOverlay.length > 0) {
      this.selectedDatasourceForBatchScreenSearchOverlay = this.availableDatasourcesForBatchScreenSearchOverlay[0];
    }
    this.enableSendToOppForSuppHealth = !!( this.lobFundingTypeMapForSendToOpp && this.lobFundingTypeMapForSendToOpp[CommonConstants.SuppHealth] && Array.isArray(this.lobFundingTypeMapForSendToOpp[CommonConstants.SuppHealth]) && this.lobFundingTypeMapForSendToOpp[CommonConstants.SuppHealth].length > 0);
    this.showSubmitOptions();
  }
  showSubmitOptions() {
    if(this.enableSendToOppForSuppHealth){
     this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS_SUPP_HEALTH;
    }
  else{
    this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS_SUPP_HEALTH.filter((option: { label: string; value: string;}) => option.value === 'ORIGNAL_QUOTES');
  }
}
  getDisableMkgSegment(enableOrDisableflag) {
    this.availableMarketSegs.forEach((mktSeg) => {
      if (StringUtils.isEqual(mktSeg.value, CommonConstants.SG)) {
        mktSeg.disabled = enableOrDisableflag;
      }
    })
  }
  getDisableFundingType(enableOrDisableflag) {
    this.availableFTs.forEach(fundingType => {
      if (StringUtils.isEqual(fundingType.value, CommonConstants.FI)) {
        fundingType.disabled = enableOrDisableflag;
      }
    })
  }

  openSearchModeAndRestore() {
    this.selectedMode = 'search';

    if (this.lastSearchResults && this.lastSearchResults.length > 0) {
      this.searchResults = JSON.parse(JSON.stringify(this.lastSearchResults));
    }

    if (this.lastSearchCriteria) {
      this.batchSearchForm.patchValue(this.lastSearchCriteria);
      this.selectedLOB = this.lastSearchCriteria.lob;
      this.selectstate = this.lastSearchCriteria.states;
      this.selectmonths = this.lastSearchCriteria.renewalMonths;
      this.selectedYear = this.lastSearchCriteria.renewalYears;
      this.selectedMbs = this.lastSearchCriteria.mbs;
      this.selectedDatasourceForBatchScreenSearchOverlay = this.lastSearchCriteria.dataSource;
      this.selectedRenewalMonthYear=this.getRenewalMonthYears(this.selectmonths, this.selectedYear);
      this.includeTestQuotesSelected = this.lastSearchCriteria.includeTestQuotes;
      if (this.renewalBatchWrapper?.renewalBatchDetails?.length) {
        const uniqueSegments = Array.from(
          new Set(this.renewalBatchWrapper.renewalBatchDetails.map(g => g.marketSegment).filter(Boolean))
        );
        if (uniqueSegments.length) {
          this.batchSearchForm.patchValue({ marketSegments: uniqueSegments });
        }
      }
    } else if (
      this.renewalBatchWrapper?.renewalBatch?.batchStatus === this.submissionStatus.SUBMITTED ||
      this.renewalBatchWrapper?.renewalBatch?.batchStatus === this.submissionStatus.NOT_SUBMITTED
    ) {
      const group = this.renewalBatchWrapper?.renewalBatchDetails?.[0];
      if (group) {
        this.batchSearchForm.patchValue({
          states: group.state ? [group.state] : [],
          lob: group.lob || '',
          marketSegments: this.renewalBatchWrapper?.renewalBatchDetails
            ? Array.from(new Set(this.renewalBatchWrapper.renewalBatchDetails.map(g => g.marketSegment).filter(Boolean)))
            : [],
          fundingTypes: group.fundingType || '',
        });
      }
    }
  }

getRenewalMonthYears(months: number[], year: number) {
  if (Array.isArray(months) && months.length > 0 && year) {
    return months.map(month => new Date(year, month - 1, 1));
  }
  return [];
}

  hideFundingType() {
    const isMedicalLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.Medical);
    const isDentalLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.Dental);
    const isVisionLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.Vision);
    const isSuppHealthLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.SuppHealth);
    this.availableFTs.forEach(fundingType => {
      fundingType.hide = false;
      if ((isDentalLob || isVisionLob || isSuppHealthLob) &&
        (StringUtils.isEqual(fundingType.value, CommonConstants.ASO) ||
          StringUtils.isEqual(fundingType.value, CommonConstants.MEWA))) {
        fundingType.hide = true;
      }
      if (isMedicalLob &&
        (StringUtils.isEqual(fundingType.value, CommonConstants.ASO) ||
          StringUtils.isEqual(fundingType.value, CommonConstants.MEWA))) {
        fundingType.hide = false;
      }
    })
  }

  showFundingType() {
    this.availableFTs.forEach(fundingType => {
      fundingType.hide = false;
    })
  }

  ngAfterViewInit() {
    this.multiselectEle = document.querySelector(".p-multiselect") as any;
    if (this.multiselectEle) {
      this.multiselectEle.setAttribute("tabindex", -1);
    }
  }

  ngAfterViewChecked() {
    let hideFooterBtn = this.isShownFooterBtn();
    if (hideFooterBtn != this.hideFooterBtn) {
      this.hideFooterBtn = hideFooterBtn;
      this.cdRef.detectChanges();
    }
  }
  isShownFooterBtn() {
    return (
      this.parentDiv &&
      this.parentDiv.nativeElement.offsetHeight > window.innerHeight + 1
    );
  }

  get f() {
    return this.batchSearchForm.controls;
  }

  public get submissionStatus(): typeof SubmissionStatus {
    return SubmissionStatus;
  }

  public get batchQuoteStatusEmitStatus(): typeof BatchQuoteStatusEmitStatus {
    return BatchQuoteStatusEmitStatus;
  }

  public get groupSubmissionStatus(): typeof QuoteSubmissionStatus {
    return QuoteSubmissionStatus;
  }

  public get sseProcess(): typeof BatchSSEProcess {
    return BatchSSEProcess;
  }

  public get quoteRenewalStatus(): typeof QuoteRenewalStatus {
    return QuoteRenewalStatus;
  }

  public get releaseSteps(): typeof ReleaseSteps {
    return ReleaseSteps;
  }

  setDefaultFormValue() {
    this.batchSearchForm.patchValue({
      lob: "",
      fundingTypes: "ABF",
      mbs: ["Key"],
      groupName: "",
      groupNumber: "",
      states: [],
      marketSegments: [],
      renewalMonths: [],
      renewalYears: [],
      renewalMonthYear: "",
      system: ["808"],
      dataSource: this.availableDatasourcesForBatchScreenSearchOverlay[0] || "",
      includeTestQuotes: ""
    });
  }
  fileName: string = "";
  myUploader(event) {
    this.file = undefined;
    this.file = event.files[0];
    this.showFileError = false;
    this.fileName = event.files[0].name;
  }
  removeFile() {
    this.file = undefined;
    this.fileName = "";
  }

  disableUploadBtn() {
    if (this.file == undefined || this.file == null) {
      return true;
    } else {
      return false;
    }
  }

  onFileUpload() {
    this.batchSaveGroupSubmitted = true;
    if (this.selectedMode == "fileUpload" && this.batchSaveGroup.invalid) {
      return;
    } else {
      this.showLoader = true;
      this.first = 0;
      this.errorExist = false;
      this.isPopupVisible = false;
      this.renewalsService
        .uploadSpecialtyBatch(this.file, this.batchSaveGroup.value.batchName)
        .subscribe(
          (response) => {
            var source = this.commonService.listenForStream(
              response.body["processId"]
            );
            source.addEventListener(
              "RENEWAL_BATCH_SUMMARY",
              (event: any) => { }
            );
            source.addEventListener("RENEWAL_SUMMARY", (event: any) => { });
            source.addEventListener(
              "RENEWAL_BATCH_SUMMARY_STATUS_COMPLETE",
              (event: any) => {
                source.close();
                if (event && event.data) {
                  let data = JSON.parse(event.data);
                  this.renewalBatchWrapper = data.payload || {};
                  if (this.renewalBatchWrapper.renewalBatchDetails.length) {
                    this.fileUploadStatus =
                      this.renewalBatchWrapper.renewalBatch.fileUploadStatus;
                    if (
                      this.renewalBatchWrapper.renewalBatch.fileUploadStatus ==
                      "Success"
                    ) {
                      let alertMsg = "File uploaded successfully.";
                      this.setAlertVisibility(
                        true,
                        AlertType.SUCCESS,
                        alertMsg
                      );
                    } else {
                      this.errorExist = true;
                      this.errorList =
                        this.renewalBatchWrapper.renewalBatch.errorList;
                      let alertMsg = "Errors found during file Upload";
                      this.setAlertVisibility(
                        true,
                        AlertType.WARNING,
                        alertMsg
                      );
                    }
                    window.scroll(0, 0);
                  }
                  this.detailsByFileUpload = true;
                  this.showLoader = false;
                }
              }
            );
            source.addEventListener("FAILED", (event: any) => {
              this.errorExist = true;
              source.close();
              this.showLoader = false;
              let eventdata = JSON.parse(event.data);
              let obj = JSON.parse(eventdata.message);
              this.errorList = obj.rareError[0].debugMessages[1].response;
              let alertMsg = "Errors found during file Upload";
              this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
            });
          },
          (error) => {
            this.errorExist = false;
            this.isPopupVisible = false;
            if (error.exceptions[0].message == "Batch Name is Already Used") {
              this.setAlertVisibility(
                true,
                AlertType.ERROR,
                "Batch Name is Already Used !"
              );
            } else {
              this.setAlertVisibility(
                true,
                AlertType.ERROR,
                "Something went wrong !"
              );
            }
            this.showLoader = false;
          }
        );
      this.searchResults = [];
    }
  }
  errorList: any;
  errorExist: boolean = false;
  errorResponse: any;
  isPopupVisible: boolean = false;
  public aslFormartValidationPattern = "^([0-1]?(\\.\\d{1,2}?)?|[2])$";
  public refundPCTFormartValidationPattern = "^([0]?(\\.\\d{1,3}|[1])?)?$";

  errorPopup() {
    this.isPopupVisible = false;
    this.errorResponse = this.errorList;
    this.isPopupVisible = true;
  }

  openOpp(groupDetail) {
    const url = this.createOpportunityURL;
    if (url) {
      const pathToNavigate = this.createOpportunityURL;
      const url = this.router.serializeUrl(
        this.router.createUrlTree([pathToNavigate], {
          queryParams: {
            opportunityID: groupDetail['opportunityID']
          }
        })
      );
      localStorage.setItem('quoteHeaderID', groupDetail['quoteHeaderID']);
      localStorage.setItem('opportunityID', groupDetail['opportunityID']);
      localStorage.setItem('isLoginAgain', 'true');
      localStorage.setItem('assignedUserRoles', this.authenticationService.getUserRole());
      localStorage.setItem('assignedUserRolesTextToDisplay', this.authenticationService.getUserRoleTextToDisplay());
      localStorage.setItem('sendToOpp', 'true');
      localStorage.setItem('assignedUserLobs', this.authenticationService.getUserLob());
      localStorage.setItem('assignedUserStates', this.authenticationService.getUserState());
      localStorage.setItem('disableAll', 'false');
      window.open(url, '_blank');
    } else {
      alert("Opportunity Details doesn't exist");
    }
  }

  openQuote(groupDetail: any) {
    this.lob_FT = [];
    this.commonService.logUserOpeningQuoteEvent(
      groupDetail["ratingTransID"],
      groupDetail["opportunityID"],
      groupDetail["quoteHeaderID"],
      groupDetail["lob"],
      groupDetail["fundingType"],
      groupDetail["marketSegment"],
      groupDetail["batchOrigin"],
      "Renewal-Batch"
    );
    this.commonQuoteService
      .getOpportunitesByOppID(groupDetail["opportunityID"], groupDetail["lob"])
      .subscribe(
        (response) => {
          if (response != null) {
            for (var opp of response.opportunities) {
              if (opp && opp.quoteHeaderID === groupDetail["quoteHeaderID"]) {
                let data =
                  opp.lob == "Medical" &&
                    opp.opportunityType == "Renewal Local" &&
                    opp.quotingType == "ACA"
                    ? opp.lob + "-" + opp.quotingType
                    : opp.lob + "-" + opp.fundingType;
                if (!this.lob_FT.find((x) => x === data)) {
                  this.lob_FT.push(data);
                }
              }
            }
            this.lob_FT = this.lob_FT.sort(function (a, b) {
              return a > b ? 1 : a < b ? -1 : 0;
            });
            let quote;
            if (response.opportunities)
              quote = response.opportunities.find(
                (data) =>
                  data.opportunityID == groupDetail["opportunityID"] &&
                  data.quoteHeaderID == groupDetail["quoteHeaderID"] &&
                  data.lob == groupDetail["lob"] &&
                  (!data.quotingType || data.quotingType === "POOL")
              );
            if (quote && quote["ratingTransID"]) {
              const pathToNavigate = this.identifyUWPath(groupDetail["lob"]);
              const url = this.router.serializeUrl(
                this.router.createUrlTree([pathToNavigate], {
                  queryParams: {
                    quoteHeaderID: groupDetail["quoteHeaderID"],
                    opportunityID: groupDetail["opportunityID"],
                    ratingTransID: quote["ratingTransID"],
                    lob: groupDetail["lob"],
                    fundingType: groupDetail["fundingType"],
                    availableTabs: this.lob_FT,
                    insertedTimestamp: quote["insertedTimestamp"],
                    quoteOrigin: groupDetail["batchOrigin"],
                    isLoginAgain: true,
                    disableAll: false,
                  },
                })
              );
              if (/Edge/.test(navigator.userAgent)) {
                if (localStorage.getItem("isLoginAgain"))
                  this.commonService.removeHistoryLocalStorage();
              }
              localStorage.setItem(
                "quoteHeaderID",
                groupDetail["quoteHeaderID"]
              );
              localStorage.setItem(
                "opportunityID",
                groupDetail["opportunityID"]
              );
              localStorage.setItem("ratingTransID", quote["ratingTransID"]);
              localStorage.setItem("lob", groupDetail["lob"]);
              localStorage.setItem("fundingType", groupDetail["fundingType"]);
              localStorage.setItem("quoteOrigin", groupDetail["batchOrigin"]);
              localStorage.setItem(
                "insertedTimestamp",
                quote["insertedTimestamp"]
              );
              localStorage.setItem(
                "availableTabs",
                this.lob_FT.map((x) => x).join(",")
              );
              localStorage.setItem("isLoginAgain", "true");
              localStorage.setItem(
                "assignedUserRoles",
                this.authenticationService.getUserRole()
              );
              localStorage.setItem(
                "assignedUserRolesTextToDisplay",
                this.authenticationService.getUserRoleTextToDisplay()
              );
              localStorage.setItem(
                "assignedUserLobs",
                this.authenticationService.getUserLob()
              );
              localStorage.setItem(
                "assignedUserStates",
                this.authenticationService.getUserState()
              );
              localStorage.setItem("disableAll", "false");
              window.open(url, "_blank");
            } else {
              alert("Quote Details doesn't exist");
            }
          }
        },
        (error) => {
          console.error(error);
        }
      );
  }

  private identifyUWPath(lob: string): string {
    var path = "";
    switch (lob) {
      case "Medical":
        path = "/quote/uw-rate";
        break;
      case "Vision":
        path = "/quote/uw-rate-vision";
        break;
      case "Dental":
        path = "/quote/uw-rate-dental";
        break;
      default:
        break;
    }
    return path;
  }

  private showTabs() {
    this.showTab =
      !!(
        this.renewalBatchWrapper &&
        this.renewalBatchWrapper.renewalBatchDetails &&
        this.renewalBatchWrapper.renewalBatchDetails.find(
          (detail) =>
            detail['lob'] == 'Medical' ||
            (detail['lob'] == 'Medical' && detail['fundingType'] == 'ABF') ||
            (detail['lob'] == 'Medical' && detail['fundingType'] == 'FI') ||
            (detail['lob'] == 'Supp Health' && detail['fundingType'] == 'ABF') ||
            detail['lob'] == 'Supp Health'
        )
      );
  }
  enableBulkAdjTab() {
    this.bulkAdjustmentsSuppHealthService.showSuppHealthBulkAdjustmentScreen().subscribe(response => {
      if (response) {
        this.disableBulkAdj =
          this.renewalBatchWrapper.renewalBatchDetails.findIndex(
            (detail) =>
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.PENDING ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.RELEASED ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.SOLD ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.SOLD_MODIFIED ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.MODIFIED ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.PRESOLD ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.FAIL ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.PENDING_EXHIBIT ||
              detail["quoteRenewalStatus"] == QuoteRenewalStatus.DECLINED
          ) == -1;
      } else {
        this.disableBulkAdj = true;
      }
    });
  }

  checkAllRenewals(event) {
    this.renewalBatchWrapper.renewalBatchDetails.forEach((renewal) => {
      (renewal["included"] as boolean) = event.checked as boolean;
    });
  }
  checkBulkDetails(event) {
    this.bulkViewTableData.forEach((renewal) => {
      (renewal["included"] as boolean) = event.checked as boolean;
    });
  }

  checkEmptyBulkViewTableData() {
    let checkAllDetails = this.bulkViewTableData.filter(
      (renewal) => renewal["included"]
    );
    return !checkAllDetails.length;
  }

  transIDArray = [];
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  download() {
    let stateList = this.download_form.get("downloadOptions").value;
    this.renewalBatchWrapper.renewalBatchDetails.forEach((x) => {
      this.bulkViewTableData.forEach((renewal) => {
        if (renewal["included"] == true) {
          if (
            renewal["quoteHeaderID"] != undefined &&
            renewal["ratingTransID"] &&
            x["quoteHeaderID"] == renewal["quoteHeaderID"]
          ) {
            this.transIDArray.push(renewal["ratingTransID"]);
          }
        }
      });
    });
    if (this.transIDArray.length != 0 && stateList.includes("NON_CT_STATE")) {
      const data = {
        data: {
          transIDs: this.transIDArray,
          batchName: this.renewalBatchWrapper.renewalBatch.batchName,
          fundingType: this.isFIBulkAdj ? 'FI' : 'ABF'
        },
      };
      this.renewalsService.getBulkAdjExcelData(data).subscribe(
        (x) => {
          if (x["processId"] != null && x["processId"] != undefined) {
            this.processId = x["processId"];
            this.showProgress = true;
            this.progressPercent = 1;
            this.progressStyle = "progress-bar-warning";
            var source = this.commonService.listenForStream(this.processId);
            source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
              this.progressStyle = "";
              let eventData = JSON.parse(event.data);
              var percent = Math.floor(
                (eventData.currentEvent / eventData.totalEvents) * 100
              );
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            });
            source.addEventListener("SEND_EXHIBIT_TO_UI", (message: any) => {
              source.close();
              let eventData = JSON.parse(message.data);
              this.progressStyle = "progress-bar-success";
              this.progressPercent = 100;
              this.progressMessage = eventData.message;
              CommonService.exportFilename =
                (eventData.metaData.fileName
                  ? eventData.metaData.fileName
                  : "sheet");
              let fileName = this.commonService.getExportFilename();
              let contentData = eventData.payload.contentData;
              const arrayBuffer =
                this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
              setTimeout(() => {
                this.showProgress = false;
              }, this.commonService.getProgressBarTimeOut());
            });
            source.addEventListener("FAILED", (message: any) => {
              source.close();
              console.error("Received event : ", JSON.stringify(message.data));
              this.progressPercent = 90;
              this.progressStyle = "progress-bar-danger";
              this.progressMessage = "Error in getting response for download";
              this.hideProgressBar();
            });
            source.addEventListener("error", (message: any) => {
              source.close();
              console.error(
                "Received error event, with ready status :" + source.readyState
              );
              if (source.readyState == EventSource.CLOSED) {
                this.progressPercent = 90;
                this.progressStyle = "progress-bar-danger";
                this.progressMessage =
                  "Failed to fetch progress because of communication failure";
                this.hideProgressBar();
              }
            });
          }
        },
        (error) => {
          var promise = new Promise<any>((resolve) => {
            setTimeout(() => {
              resolve(false);
            }, 10000);
          });
          promise.then((res) => { });
        }
      );
    }
    if (this.transIDArray.length != 0 && stateList.includes("CT_STATE")) {
      const data = {
        data: {
          transIDs: this.transIDArray,
          batchName: this.renewalBatchWrapper.renewalBatch.batchName,
          fundingType: this.isFIBulkAdj ? 'FI' : 'ABF'
        },
      };
      this.renewalsService.getCTBulkAdjExcelData(data).subscribe((x) => {
        if (x["processId"] != null && x["processId"] != undefined) {
          this.processId = x["processId"];
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = "progress-bar-warning";
          var source = this.commonService.listenForStream(this.processId);
          source.addEventListener(
            "Bulk_Adjustment_V2_DETAILS_STATUS",
            (event: any) => {
              this.progressStyle = "";
              let eventData = JSON.parse(event.data);
              var percent = Math.floor(
                (eventData.currentEvent / eventData.totalEvents) * 100
              );
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            }
          );
          source.addEventListener(
            "BULK_ADJ_V2_DETAILS_FETCH_COMPLETE",
            (event: any) => {
              this.progressStyle = "";
              let eventData = JSON.parse(event.data);
              var percent = Math.floor(
                (eventData.currentEvent / eventData.totalEvents) * 100
              );
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            }
          );
          source.addEventListener("SEND_BULK_ADJ_V2_TO_UI", (message: any) => {
            let eventData = JSON.parse(message.data);
            this.progressStyle = "";
            this.progressPercent = 90;
            this.progressMessage = eventData.message;
            CommonService.exportFilename =
              (eventData.metaData.fileName
                ? eventData.metaData.fileName
                : "sheet");
            let fileName = this.commonService.getExportFilename();
            let contentData = eventData.payload.contentData;
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
            this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            setTimeout(() => {
              this.showProgress = false;
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener(
            "BULK_ADJ_V2_DOWNLOAD_COMPLETE",
            (event: any) => {
              source.close();
              this.progressStyle = "progress-bar-success";
              this.progressPercent = 100;
              let eventData = JSON.parse(event.data);
              this.progressMessage = eventData.message;
            }
          );
          source.addEventListener("FAILED", (message: any) => {
            source.close();
            console.error("Received event : ", JSON.stringify(message.data));
            this.progressPercent = 90;
            this.progressStyle = "progress-bar-danger";
            this.progressMessage = "Error in getting response for download";
            this.hideProgressBar();
          });
          source.addEventListener("error", (message: any) => {
            source.close();
            console.error(
              "Received error event, with ready status :" + source.readyState
            );
            if (source.readyState == EventSource.CLOSED) {
              this.progressPercent = 90;
              this.progressStyle = "progress-bar-danger";
              this.progressMessage =
                "Failed to fetch progress because of communication failure";
              this.hideProgressBar();
            }
          });
        }
      });
    }
    this.transIDArray = [];
  }
  checkEmptyRenewalBatchDetails() {
    let checkAllDetails = this.renewalBatchWrapper.renewalBatchDetails.filter(
      (renewal) => renewal["included"]
    );
    return !checkAllDetails.length;
  }

  checkRenewalBatchDetailsSelected() {
    return this.renewalBatchWrapper.renewalBatchDetails.filter((renewal) => renewal['included']).length == 0;
  }

  onAddToBatch(selectedGroups: any[]) {
    const checkedGroups = (selectedGroups || []).filter(g => g.included);
    const existingGroupNumbers = this.renewalBatchWrapper.renewalBatchDetails.map(
      (g) => String(g.originalGroupNumber || g.groupNumber)
    );

    // --- Enforce single LOB in batch ---
    if (this.renewalBatchWrapper.renewalBatchDetails.length > 0) {
      const existingLob = this.renewalBatchWrapper.renewalBatchDetails[0].lob;
      const invalidLob = checkedGroups.find(g => g.lob !== existingLob);
      if (invalidLob) {
        // Set alert for overlay (isSearch: true)
        this.alert = {
          show: true,
          type: 'warning',
          message: `A Renewal Batch is allowed to have a single LOB. Only "${existingLob}" groups can be added to this batch.`,
          cssClass: 'alert-warning',
          header: 'warning',
          headerVisibility: true,
          isSearch: true
        };
        // Optionally, auto-hide after a few seconds
        setTimeout(() => {
          this.alert = { ...this.alert, show: false };
        }, 5000);
        return;
      }

      const existingFundingType = this.renewalBatchWrapper.renewalBatchDetails[0].fundingType;
      const invalidFundingType = checkedGroups.find(g => g.fundingType !== existingFundingType);
      if (invalidFundingType) {
        this.alert = {
          show: true,
          type: 'warning',
          message: `A Renewal Batch is allowed to have a single Funding Type. Only "${existingFundingType}" groups can be added to this batch.`,
          cssClass: 'alert-warning',
          header: 'warning',
          headerVisibility: true,
          isSearch: true
        };
        setTimeout(() => {
          this.alert = { ...this.alert, show: false };
        }, 5000);
        return;
      }
    }

    const newGroups = checkedGroups.filter(
      (group) =>
        !existingGroupNumbers.includes(String(group.originalGroupNumber || group.groupNumber))
    );
    if (!checkedGroups.length) {
      this.setAlertVisibility(true, 'warning', 'Please select at least one group to add.');
      this.hideAlertVisibility();
      return;
    }
    this.renewalBatchWrapper.renewalBatchDetails = [
      ...this.renewalBatchWrapper.renewalBatchDetails,
      ...newGroups,
    ];
    this.verifyCheckAllDetails();
    this.showTabs();

    // Switch to Batch Info tab and close overlay
    // this.selectedMode = null;
    // this.activeTab = 'BATCH';
    // this.searchResults = [];
    this.checkAllDetailsOverlay = false;
    if (this.lastSearchResults && this.lastSearchResults.length > 0) {
      this.searchResults = JSON.parse(JSON.stringify(this.lastSearchResults));
      if (this.lastSearchCriteria) {
        this.batchSearchForm.patchValue(this.lastSearchCriteria);
      }
    }

    if (newGroups.length > 0) {
      this.setAlertVisibility(true, 'success', `${newGroups.length} group(s) added to batch.`, undefined, true);
    } else {
      this.setAlertVisibility(true, 'warning', 'Selected groups are already in the batch.', undefined, true);
    }
    this.hideAlertVisibility();
  }

  processRenewalBatchSaveResponse(response: any) {
    let alertMsg: string;
    this.renewalBatchWrapper = response;
    if (this.renewalBatchWrapper.renewalBatchDetails.length) {
      alertMsg = "Renewal Batch Saved Successfully.";
      this.isSaveFlow = true;
      this.detailsByFileUpload =
        this.renewalBatchWrapper.renewalBatchDetails[0].uploadStatus !=
        undefined;
      this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
      this.first = 0;
      window.scroll(0, 0);
      let originalGroupData = RenewalsUtil.updateRenewalBatchColumns(
        this.quoteReason,
        this.renewalBatchColumns
      );
      this.showOriginalGroupNumber = originalGroupData.showOriginalGroupNumber;
      this.renewalBatchColumns = originalGroupData.batchColumns;
    } else {
      alertMsg = "No details associated with Batch!";
      this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
      this.first = 0;
      return;
    }
  }

  saveRenewalBatchDetails() {
    let alertMsg;
    this.errorExist = false;
    this.isPopupVisible = false;
    this.batchSaveGroupSubmitted = true;
    this.removeAlertMsg();
    if (this.validateRenewalBatchDetails()) {
      return;
    }
    this.setLoaderVisibility(true);
    let renewalBatchWrapper = JSON.parse(
      JSON.stringify(this.renewalBatchWrapper)
    );
    renewalBatchWrapper.renewalBatch = RenewalsUtil.buildRenewalWrapper(
      renewalBatchWrapper,
      this.batchSaveGroup.value.batchName.trim(),
      this.renewalBatchWrapper?.renewalBatch?.batchStatus ? this.renewalBatchWrapper.renewalBatch.batchStatus : SubmissionStatus.NOT_SUBMITTED,
      this.fileUploadStatus,
      this.quoteReason,
      this.isAutoRunBatch,
      this.associationCodes
    );
    renewalBatchWrapper.renewalBatch.actionPerformed = 'save';
    this.updateOverRidesToBatchDetails(renewalBatchWrapper);
    this.setBatchOriginInRenewalBatchDetails(renewalBatchWrapper, this.isAutoRunBatch);
    this.renewalsService.saveRenewalDetails(renewalBatchWrapper).subscribe(
      (response) => {
        this.setLoaderVisibility(false);
        if (response) {
          this.processRenewalBatchSaveResponse(response);
        } else {
          alertMsg = "Something Went wrong !";
          this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
        }
      },
      (error) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(
          true,
          AlertType.WARNING,
          error.exceptions[0].message
        );
      }
    );
  }

  setBatchOriginInRenewalBatchDetails(renewalBatchWrapper: any, isAutoRunBatch: boolean) {
    const batchOriginValue = isAutoRunBatch ? BATCH_ORIGIN.AUTO_RUN_BATCH : BATCH_ORIGIN.USER_BATCH;
    renewalBatchWrapper.renewalBatchDetails.forEach((detail: any) => {
      detail.batchOrigin = batchOriginValue;
    });
  }

  isDummyEvent(payload: any) {
    return payload && payload.dummyEvent && payload.dummyEvent == "true";
  }

  processRenewalBatchSubmissionEvent(event: any, batchName: string) {
    if (event && event.data) {
      let eventData = JSON.parse(event.data);
      let payload = eventData.payload;
      if (this.isDummyEvent(payload)) {
        return;
      }
      let eventName = eventData.eventName;
      if (
        !this.receivedBatchEvents.includes(
          batchName +
          this.sseProcess.SUBMISSION +
          eventName +
          payload.uniqueRecordID
        )
      ) {
        this.renewalBatchWrapper.renewalBatchDetails.forEach(
          (renewalBatchDetails) => {
            let batchDetail = renewalBatchDetails as RenewalBatchDetails;
            if (
              batchDetail.batchID == payload.batchID &&
              batchDetail.groupNumber == payload.groupNumber &&
              batchDetail.opportunityID == payload.opportunityID &&
              batchDetail.quoteHeaderID == payload.quoteHeaderID &&
              batchDetail.lob == payload.lob &&
              batchDetail.fundingType == payload.fundingType
            ) {
              batchDetail.submissionErrors = payload.submissionErrors;
              batchDetail.specialtyErrors = payload.specialtyErrors;
              batchDetail.submissionFailCheckPoint =
                payload.submissionFailCheckPoint;
              batchDetail.submissionStatus = payload.submissionStatus;
              batchDetail.opportunityID = payload.opportunityID;
              batchDetail.quoteHeaderID = payload.quoteHeaderID;
              batchDetail.isSubmitted = payload.isSubmitted;
              batchDetail.isUnifiedPayloadSubmission = payload.isUnifiedPayloadSubmission;
              batchDetail.isQueuedForDataGathering =
                payload.isQueuedForDataGathering;
              batchDetail.isRequestCreated = payload.isRequestCreated;
              batchDetail.isSubmittedToGateWay = payload.isSubmittedToGateWay;
              batchDetail.isSpecialtySubmittedToGateWay =
                payload.isSpecialtySubmittedToGateWay;
              batchDetail.specialtySubmittedStatus =
                payload.specialtySubmittedStatus;
            }
          }
        );
        this.receivedBatchEvents.push(
          batchName +
          this.sseProcess.SUBMISSION +
          eventName +
          payload.uniqueRecordID
        );
      }
    }
  }

  processBatchClosure(batchName: string, sseProcess: string) {
    this.receivedBatchEvents = this.receivedBatchEvents.filter(
      (receivedBatchEvent) =>
        !receivedBatchEvent.startsWith(batchName + sseProcess)
    );
    this.completedBatchRequests = this.completedBatchRequests.filter(
      (cmpltBatchReq) => !cmpltBatchReq.startsWith(batchName + sseProcess)
    );
  }

  submitRenewalBatchDetails() {
    let alertMsg;
    this.errorExist = false;
    this.isPopupVisible = false;
    this.batchSaveGroupSubmitted = true;
    this.removeAlertMsg();
    let batchName = this.batchSaveGroup.value.batchName;
    if (this.validateRenewalBatchDetails()) {
      return;
    }
    this.setLoaderVisibility(true);
    let renewalBatchWrapper = JSON.parse(
      JSON.stringify(this.renewalBatchWrapper)
    );
    // Only for already submitted batches (batch id != null), filter included === true
    let detailsToSubmit = renewalBatchWrapper.renewalBatchDetails;
    if (renewalBatchWrapper.renewalBatch && renewalBatchWrapper.renewalBatch.id != null) {
      detailsToSubmit = renewalBatchWrapper.renewalBatchDetails.filter(
        detail => detail.included === true
      );
    }
    // After submission, only keep checkboxes checked for submitted items
    const submittedIds = new Set(detailsToSubmit.map(d => d.groupNumber));
    if (renewalBatchWrapper.renewalBatch && !StringUtils.isEmpty(renewalBatchWrapper.renewalBatch.id)) {
      (this.renewalBatchWrapper.renewalBatchDetails as any[]).forEach((detail: any) => {
        detail.included = submittedIds.has(detail.groupNumber);
      });
    }
    // Use detailsToSubmit for submission, keep UI state untouched
    renewalBatchWrapper.renewalBatchDetails = detailsToSubmit;
    // Recalculate header checkbox after submission
    this.verifyCheckAllDetails();
    renewalBatchWrapper.renewalBatch = RenewalsUtil.buildRenewalWrapper(
      renewalBatchWrapper,
      batchName.trim(),
      SubmissionStatus.SUBMITTED,
      this.fileUploadStatus,
      this.quoteReason,
      this.isAutoRunBatch,
      this.associationCodes,
    );
    renewalBatchWrapper.renewalBatch.actionPerformed = 'submit';
    this.updateOverRidesToBatchDetails(renewalBatchWrapper);
    RenewalsUtil.checkDeclineReasonLocalStorage(renewalBatchWrapper);
    this.setBatchOriginInRenewalBatchDetails(renewalBatchWrapper, this.isAutoRunBatch);
    renewalBatchWrapper.renewalBatchDetails.forEach((detail) => {
      detail.userSubmitActions = this.selectedSubmitOptions;
    });
    this.renewalsService.submitRenewalBatch(renewalBatchWrapper).subscribe(
      (response) => {
        this.setLoaderVisibility(false);
        if (response) {
          this.processRenewalBatchSaveResponse(response);
          // After successful submission, update checkboxes: only submitted items remain checked
          const submittedIds = new Set(detailsToSubmit.map(d => d.id));
          if (renewalBatchWrapper.renewalBatch && !StringUtils.isEmpty(renewalBatchWrapper.renewalBatch.id)) {
            (this.renewalBatchWrapper.renewalBatchDetails as any[]).forEach((detail: any) => {
              detail.included = submittedIds.has(detail.id);
            });
          }
          this.showTabs();
          if (
            response["description"] &&
            response["description"] == "No Records Found"
          ) {
            alertMsg = "No Renewal Groups found.";
            this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
            return;
          }
          alertMsg = "Renewal Batch Submission initiated Successfully.";
          this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
          this.first = 0;
          window.scroll(0, 0);
          var source = this.commonService.listenForStream(
            response["description"]
          );
          this.listenRenewalBatchSubmissionEvents(source, batchName);
          var quoteStatusSource = this.commonService.listenForStream(
            this.renewalBatchWrapper.renewalBatch.statusEmitterID
          );
          this.listenRenewalBatchQuoteStatusEvents(
            quoteStatusSource,
            batchName
          );
        } else {
          alertMsg = "Something Went wrong !";
          this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
        }
      },
      (error) => {
        this.showTab = false;
        console.log(error);
        this.setLoaderVisibility(false);
        this.setAlertVisibility(
          true,
          AlertType.WARNING,
          error ? (error.exceptions[0] ? error.exceptions[0].message : "") : ""
        );
      }
    );
  }

  ngOnDestroy() {
    // Close all EventSource instances
    this.eventSources.forEach(source => source.close());
  }

  listenRenewalBatchSubmissionEvents(source: EventSource, batchName: string) {
    this.eventSources.push(source); // Store the EventSource reference
    source.addEventListener("BATCH_RENEWAL_REQUEST_SUBMITTED", (event: any) => {
      this.processRenewalBatchSubmissionEvent(event, batchName);
    });
    source.addEventListener("BATCH_RENEWAL_REQUEST_QUEUED", (event: any) => {
      this.processRenewalBatchSubmissionEvent(event, batchName);
    });
    source.addEventListener(
      "BATCH_RENEWAL_REQUEST_PAYLOAD_CREATION",
      (event: any) => {
        this.processRenewalBatchSubmissionEvent(event, batchName);
      }
    );
    source.addEventListener(
      "BATCH_RENEWAL_REQUEST_GATEWAY_SUBMISSION",
      (event: any) => {
        this.processRenewalBatchSubmissionEvent(event, batchName);
      }
    );
    source.addEventListener(
      "BATCH_RENEWAL_REQUEST_SPECIALTY_SUBMISSION",
      (event: any) => {
        this.processRenewalBatchSubmissionEvent(event, batchName);
      }
    );
    source.addEventListener(
      "BATCH_RENEWAL_ADJUST_REQUEST_SINGLE_COMPLETE",
      (event: any) => {
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          var completedBatchRequestId =
            batchName +
            this.sseProcess.SUBMISSION +
            eventData.eventName +
            payload.uniqueRecordID;

          if (!this.completedBatchRequests.includes(completedBatchRequestId)) {
            this.completedBatchRequests.push(completedBatchRequestId);
          }
        }
      }
    );
    source.addEventListener(
      "BATCH_RENEWAL_PROCESS_COMPLETION_TRIGGER",
      (event: any) => {
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          var payloadBatchStatus = payload.batchStatus;
          this.renewalBatchWrapper.renewalBatch["batchStatus"] =
            payloadBatchStatus;
          this.setAlertVisibility(false);
          this.processBatchClosure(batchName, this.sseProcess.SUBMISSION);
        }
      }
    );
    source.addEventListener("BATCH_RENEWAL_PROCESS_COMPLETE", (event: any) => {
      source.close();
      this.processBatchClosure(batchName, this.sseProcess.SUBMISSION);
    });
    source.addEventListener("NO_EVENTS", (event: any) => {
      source.close();
      this.processBatchClosure(batchName, this.sseProcess.SUBMISSION);
    });
    source.addEventListener("FAILED", (event: any) => {
      source.close();
      this.processBatchClosure(batchName, this.sseProcess.SUBMISSION);
    });
  }

  listenRenewalBatchQuoteStatusEvents(source: EventSource, batchName: string) {
    this.eventSources.push(source); // Store the EventSource reference
    source.addEventListener("BATCH_QUOTE_STATUS_RECEIVED", (event: any) => {
      this.processRenewalBatchQuoteStatusEvent(event, batchName);
    });
    source.addEventListener(
      "BATCH_QUOTE_STATUS_TRACKING_COMPLETION_TRIGGER",
      (event: any) => {
        this.renewalBatchWrapper.renewalBatch.batchQuoteStatusEmitStatus =
          BatchQuoteStatusEmitStatus.COMPLETED;
      }
    );
    source.addEventListener(
      "BATCH_QUOTE_STATUS_TRACKING_COMPLETE",
      (event: any) => {
        source.close();
        this.processBatchClosure(
          batchName,
          this.sseProcess.QUOTESTATUSRETRIEVAL
        );
      }
    );
    source.addEventListener("NO_EVENTS", (event: any) => {
      source.close();
      this.processBatchClosure(batchName, this.sseProcess.QUOTESTATUSRETRIEVAL);
    });
  }

  processRenewalBatchQuoteStatusEvent(event: any, batchName: string) {
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      var payload = eventData.payload;
      this.renewalBatchWrapper.renewalBatchDetails.forEach((bd) => {
        var batchDetail = bd as RenewalBatchDetails;
        if (
          batchDetail.batchID == payload.batchID &&
          batchDetail.groupNumber == payload.groupNbr &&
          batchDetail.opportunityID == payload.opportunityID &&
          batchDetail.quoteHeaderID == payload.quoteHeaderID &&
          batchDetail.lob == payload.lob &&
          batchDetail.fundingType == payload.fundingType &&
          batchDetail.isSSEQuoteStatusReceived == false &&
          this.isNewStatusEvent(
            batchDetail.submittedTimestamp,
            payload.statusEmittedTimestamp
          )
        ) {
          batchDetail.quoteRenewalStatus = payload.status;
          batchDetail.isSSEQuoteStatusReceived =
            payload.isSSEQuoteStatusReceived;
          batchDetail.submittedTimestamp = payload.submittedTimestamp;
          batchDetail.quoteErrors = payload.errors;
          batchDetail.currentQuoteStatusBatchID = payload.batchID;
          batchDetail.currentQuoteStatusBatchName = payload.batchName;
        }
      });
      if (this.showTab) {
        this.enableBulkAdjTab();
      }
    }
  }

  isNewStatusEvent(submittedTimestamp: any, statusEmittedTimestamp: any) {
    if (submittedTimestamp == undefined) {
      return true;
    }
    var date1 = new Date(submittedTimestamp);
    var date2 = new Date(statusEmittedTimestamp);
    return date2 > date1;
  }

  validateRenewalBatchDetails(): boolean {
    let alertMsg;
    if (this.batchSaveGroup.invalid) {
      return true;
    }
    if (!this.renewalBatchWrapper.renewalBatchDetails.length) {
      alertMsg = "No details associated with Batch!";
      this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
      return true;
    }
    if (
      this.overRideDetails &&
      this.overRideDetails?.aslErrors?.length > 0 &&
      this.overRideDetails?.refundPctErrors?.length > 0
    ) {
      alertMsg = "Please enter valid values for ASL & Group refund.";
      this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
      return true;
    } else if (
      this.overRideDetails &&
      this.overRideDetails?.refundPctErrors?.length > 0
    ) {
      alertMsg = "Please enter a valid value for Group refund.";
      this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
      return true;
    } else if (
      this.overRideDetails &&
      this.overRideDetails?.aslErrors?.length > 0
    ) {
      alertMsg = "Please enter a valid value for ASL.";
      this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
      return true;
    }
  }
  getFTSelection(optionlabel, fundTypeFromDetails) {
    if (!StringUtils.isEmpty(fundTypeFromDetails)) {
      return true ? StringUtils.isEqual(optionlabel, fundTypeFromDetails) : false
    }
    else {
      return true ? StringUtils.isEqual(optionlabel, CommonConstants.ABF) : false
    }
  }

  fetchRenewalDetailsByBatch() {
    this.hasDeletedGroupsInBatch = false;
    this.errorExist = false;
    this.isPopupVisible = false;
    this.showLoader = true;
    let batchID = this.renewalBatchWrapper.renewalBatch["id"];
    let batchStatus = this.renewalBatchWrapper.renewalBatch["batchStatus"];
    this.renewalBatchWrapper.renewalBatch["batchStatus"] =
      this.submissionStatus.LOADING;
    this.renewalsService
      .fetchRenewalDetailsByBatch(batchID, batchStatus)
      .subscribe(
        (data) => {
          if (data.renewalBatchDetails[0]?.fundingType) {
            this.fundTypeFromDetails = data.renewalBatchDetails[0]?.fundingType;
            this.batchSearchForm.patchValue({
              fundingTypes: data.renewalBatchDetails[0]?.fundingType
            });
          }
          if (StringUtils.isEqual(CommonConstants.FI, this.fundTypeFromDetails)) {
            this.isFIselectedDropdown = this.fundTypeFromDetails
            this.getDisableMkgSegment(true);
          }
          this.renewalBatchWrapper.renewalBatch = data.renewalBatch;
          this.hasDeletedGroupsInBatch = this.renewalBatchWrapper.renewalBatch[RenewalsConstants.HAS_DELETED_GROUPS] == "true" ? true : false;
          this.quoteReason =
            this.renewalBatchWrapper.renewalBatch.quoteReason &&
            StringUtils.isEqual(
              this.renewalBatchWrapper.renewalBatch.quoteReason,
              CommonConstants.TEST
            );
          let originalGroupData = RenewalsUtil.updateRenewalBatchColumns(
            this.quoteReason,
            this.renewalBatchColumns
          );
          this.showOriginalGroupNumber =
            originalGroupData.showOriginalGroupNumber;
          this.renewalBatchColumns = originalGroupData.batchColumns;
          this.renewalBatchWrapper.renewalBatchDetails =
            data.renewalBatchDetails as [];
          if (this.renewalBatchWrapper.renewalBatchDetails.length > 0) {
            this.renewalBatchWrapper.renewalBatchDetails.forEach((batchDetails: RenewalBatchDetails) => {
              this.renewalMonthsFromResponse.push(batchDetails?.renewalDate.split('-')[1].toString());
              this.statesFromResponse.push(batchDetails?.state)
              this.marketSegmentsFromResponse.push(batchDetails?.marketSegment)
            })
            this.selectmonths = [...new Set(this.renewalMonthsFromResponse)]
            this.selectstate = [...new Set(this.statesFromResponse)]
            this.batchSearchForm.patchValue({
              marketSegments: [...new Set(this.marketSegmentsFromResponse)]
            })
            this.selectedLOB = this.renewalBatchWrapper.renewalBatchDetails[0].lob;
            this.isSaveDataExist = true;
            this.tableDataExist = true;
            this.first = 0;
            this.detailsByFileUpload =
              this.renewalBatchWrapper.renewalBatchDetails[0].uploadStatus !=
              undefined;
            this.isFIRewewal = this.renewalBatchWrapper.renewalBatchDetails[0].fundingType == 'FI';
            this.checkAllDetails = false;
            if (this.selectedGroupsFromQuery && this.selectedGroupsFromQuery.length > 0) {
              (this.renewalBatchWrapper.renewalBatchDetails as RenewalBatchDetails[]).forEach((renewal) => {
                renewal.included = this.selectedGroupsFromQuery.includes(renewal.groupNumber);
              });
            } else {
              (this.renewalBatchWrapper.renewalBatchDetails as RenewalBatchDetails[]).forEach((renewal) => {
                (renewal['included'] as boolean) = false;
              });
            }
            // Restore included state if needed
            if (this.includedMapToRestore) {
              (this.renewalBatchWrapper?.renewalBatchDetails || []).forEach(g => {
                g.included = this.includedMapToRestore?.get(g.groupNumber) || false;
              });
              this.includedMapToRestore = null;
            }
            this.verifyCheckAllDetails();
            this.showTabs();
            if (this.showTab) {
              this.enableBulkAdjTab();
            }
            if (
              this.renewalBatchWrapper.renewalBatch &&
              this.renewalBatchWrapper.renewalBatch.submissionProcessID !=
              undefined &&
              this.renewalBatchWrapper.renewalBatch.batchStatus ==
              SubmissionStatus.SUBMITTED
            ) {
              let source = this.commonService.listenForStreamTrackAndFail(
                this.renewalBatchWrapper.renewalBatch.submissionProcessID
              );
              this.listenRenewalBatchSubmissionEvents(
                source,
                this.renewalBatchWrapper.renewalBatch.batchName
              );
            }
            if (
              this.renewalBatchWrapper.renewalBatch &&
              this.renewalBatchWrapper.renewalBatch.statusEmitterID !=
              undefined &&
              this.renewalBatchWrapper.renewalBatch
                .batchQuoteStatusEmitStatus ==
              BatchQuoteStatusEmitStatus.STARTED
            ) {
              let source = this.commonService.listenForStreamTrackAndFail(
                this.renewalBatchWrapper.renewalBatch.statusEmitterID
              );
              this.listenRenewalBatchQuoteStatusEvents(
                source,
                this.renewalBatchWrapper.renewalBatch.batchName
              );
            }
          } else {
            this.tableDataExist =
              this.renewalBatchWrapper.renewalBatchDetails.length > 0 || false;
          }
          this.showLoader = false;
          window.scroll(0, 0);
        },
        (error) => {
          this.showLoader = false;
          this.setAlertVisibility(
            true,
            AlertType.ERROR,
            error.exceptions[0].message
          );
        }
      );
  }

  renderQuoteErrors(quoteErrors: any) {
    var displayableErrors: string;
    if (quoteErrors && quoteErrors.errorList) {
      let errMsgs = [];
      for (let error of quoteErrors.errorList) {
        if (!errMsgs.includes(error.msg)) {
          errMsgs.push(error.msg);
          if (displayableErrors)
            displayableErrors = displayableErrors + " , " + error.msg;
          else displayableErrors = error.msg;
        }
      }
    }
    return displayableErrors;
  }

  hasSgRole() {
    return this.commonService.hasSgRole();
  }

  hasLgRole() {
    return this.commonService.hasLgRole();
  }

  displayOptionsPannel() {
    this.isSearchChanged = true;
    this.showProgress = false;
    if (this.multiselectEle) {
      this.multiselectEle.focus();
    }
    if (this.batchSearchForm.value.marketSegments.includes('SG')) {
      this.getDisableFundingType(true);
    }
    else {
      this.getDisableFundingType(false);
    }
    this.onMBSOtionsSelected()
  }
  onOptionsSelected = (event) => {
    this.isSearchChanged = true;
    this.isFIselectedDropdown = event.target.value;
    if (StringUtils.isEqual(event.target.value, CommonConstants.FI)) {
      this.getDisableMkgSegment(true);
    }
    else {
      this.getDisableMkgSegment(false);
    }
    if (event.target.value == 'ABF') {
      this.setAlertVisibility(false)
    }
    this.onMBSOtionsSelected()
  }
  onMBSOtionsSelected() {
    this.isSearchChanged = true;
    if (this.isFIselectedDropdown && this.selectedMbs.includes('Non-Key') && this.selectedMbs?.length > 1 && (this.selectmonths?.length > 1 || this.selectstate?.length > 1)) {
      this.setAlertVisibility(
        true,
        AlertType.WARNING,
        'Limiting your search to 1 State and 1 Renewal month will yield better search performance and a simpler user experience.'
      );
    }
    else {
      this.setAlertVisibility(false);
    }
  }
  searchClicked() {
    if ((this.renewalBatchWrapper.renewalBatchDetails.length > 0 && ((this.renewalBatchWrapper.renewalBatchDetails[0].fundingType == 'FI' && this.batchSearchForm.value.fundingTypes == 'ABF') || (this.renewalBatchWrapper.renewalBatchDetails[0].fundingType != 'FI' && this.batchSearchForm.value.fundingTypes == 'FI'))) && (this.isSaveDataExist || this.isSaveFlow)) {
      this.setAlertVisibility(
        true,
        AlertType.WARNING,
        'A Renewal Batch is allowed to have single funding type. Please adjust the search criteria for funding type.'
      );
      this.showLoader = false;
      this.hideAlertVisibility();
      return;
    } else if (this.renewalBatchWrapper.renewalBatchDetails.length > 0 && (!StringUtils.isEqualIgnoreCase(this.renewalBatchWrapper?.renewalBatchDetails[0]?.lob, this.batchSearchForm?.value?.lob)) && (this.isSaveDataExist || this.isSaveFlow)) {
      this.setAlertVisibility(
        true,
        AlertType.WARNING,
        'A Renewal Batch is allowed to have single LOB. Please adjust the search criteria for LOB.'
      );
      this.showLoader = false;
      this.hideAlertVisibility();
      return;
    }
    this.isFIRewewalSearch = StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.FI) && StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Medical);
    this.errorExist = false;
    this.isPopupVisible = false;
    this.formSubmitted = true;
    this.removeAlertMsg();
    if (this.batchSearchForm.invalid) {
      this.searchResults = [];
      return;
    } else {
      this.showLoader = true;
      this.batchSearch = this.getBatchSearchRequest(this.isFIRewewalSearch);
      this.first = 0;
      if (this.batchSearch.marketSegments.length < 1) {
        this.batchSearch.marketSegments = ['LG', 'SG'];
      }
      this.renewalsService
        .fetchRenewalDetailsFromDatamart(this.groupNumbersFile,this.batchSearch)
        .subscribe(
          (res) => {
            if (res) {
              let renewalBatchWrapper: RenewalBatchWrapper = res;
              this.searchResults = res?.renewalBatchDetails || [];
              this.lastSearchResults = JSON.parse(JSON.stringify(this.searchResults));
              this.lastSearchCriteria = JSON.parse(JSON.stringify(this.batchSearchForm.value));
              if (!this.renewalBatchWrapper?.renewalBatch?.id) {
                // New batch: update main table and merge
                this.filterDuplicateRenewalDetails(renewalBatchWrapper.renewalBatchDetails);
              }
              if (
                renewalBatchWrapper &&
                renewalBatchWrapper.renewalBatch &&
                renewalBatchWrapper.renewalBatch.errorList &&
                renewalBatchWrapper.renewalBatch.errorList.length > 0
              ) {
                this.setAlertVisibility(
                  true,
                  AlertType.ERROR,
                  renewalBatchWrapper.renewalBatch.errorList.join(", "),
                  false
                );
              }
              let invalidGroups = 'The following groups were not found:'
              if (renewalBatchWrapper?.failedGrpNbrsInSearch && renewalBatchWrapper?.failedGrpNbrsInSearch.length > 0) {
                let failedGrpNbrsInSearch = [...new Set(renewalBatchWrapper?.failedGrpNbrsInSearch)];
                let invalidGroupsMsg = invalidGroups + ' ' + failedGrpNbrsInSearch.join(', ');
                if (invalidGroupsMsg.length > 150) {
                  invalidGroupsMsg = invalidGroupsMsg.substring(0, 150) + '...';
                  this.invalidGroupsTooltipMsg = invalidGroups + ' ' + failedGrpNbrsInSearch.join(', ');
                }

                this.errorExist = true;
                this.setAlertVisibility(true, AlertType.ERROR, invalidGroupsMsg,
                  undefined,
                  true
                );
              }
              setTimeout(() => {
                this.setAlertVisibility(false);
              }, 10000);
              this.tableDataExist =
                this.renewalBatchWrapper.renewalBatchDetails.length > 0;
              if (this.tableDataExist) {
                let originalGroupData = RenewalsUtil.updateRenewalBatchColumns(
                  false,
                  this.renewalBatchColumns
                );
                this.showOriginalGroupNumber = false;
                this.renewalBatchColumns = originalGroupData.batchColumns;
              }
              this.formSubmitted = false;
              setTimeout(() => {
                this.showLoader = false;
              }, 500);
            } else {
              this.errorExist = true;
              let alertMsg = 'Please contact RARE Support Team';
              this.setAlertVisibility(true, AlertType.ERROR, 'Something went wrong !' + ' ' + alertMsg, undefined,
              true);
              this.showLoader = false;
            }
          },
          (error) => {
            this.errorExist = true;
            let alertMsg = '- Please contact RARE Support Team';
            this.setAlertVisibility(true, AlertType.ERROR, error.exceptions[0].message + ' ' + alertMsg,
            undefined,
            true
          );
            this.showLoader = false;
          }
        );
      this.batchSearch.marketSegments = [];
    }
    this.isSearchChanged = false;
  }

  getBatchSearchRequest(isFIRewewalSearch: boolean) {
    const req: any = {
      groupName: this.batchSearchForm.value.groupName,
      groupNumber: this.batchSearchForm.value.groupNumber,
      states: this.batchSearchForm.value.states || [],
      lob: this.batchSearchForm.value.lob || [],
      marketSegments: this.batchSearchForm.value.marketSegments || [],
      fundingTypes: this.batchSearchForm.value.fundingTypes || '',
      mbs: isFIRewewalSearch ? this.batchSearchForm.value.mbs : [],
      renewalMonths: this.batchSearchForm.value.renewalMonths || [],
      sourceSystemCodes: this.batchSearchForm.value.system || []
    };
    if (this.availableDatasourcesForBatchScreenSearchOverlay && this.availableDatasourcesForBatchScreenSearchOverlay.length > 0) {
      req.dataSource = this.batchSearchForm.value.dataSource || [];
      if(req.dataSource == "Rare (Original Quote)") {
        req.dataSource = "Rare";
      }
      if(this.batchSearchForm.value.dataSource !== this.availableDatasourcesForBatchScreenSearchOverlay[0] ){
         if ([CommonConstants.MEWA, CommonConstants.ACA].includes(req.fundingTypes)) {
          req.quotingType = req.fundingTypes;
          req.fundingTypes = "";
        }
        req.renewalYears = this.batchSearchForm.value.renewalYears || [];
        req.includeTestQuotes = this.batchSearchForm.value.includeTestQuotes || false;
        req.sourceSystemCodes = [];
        req.mbs = [];
      }
    }
    return req;
  }

  filterDuplicateRenewalDetails(renewalBatchDetails: RenewalBatchDetails[]) {
    this.renewalBatchWrapper.renewalBatchDetails =
      this.renewalBatchWrapper.renewalBatchDetails.filter(
        (renewal: RenewalBatchDetails) => renewal["batchID"]
      );
    if (this.renewalBatchWrapper.renewalBatchDetails.length > 0) {
      this.isFIRewewal = this.renewalBatchWrapper.renewalBatchDetails[0].fundingType == 'FI' ? true : false;
      const filteredRenewalBatchDetails = renewalBatchDetails.filter(
        (renewal: RenewalBatchDetails) => {
          return (
            this.renewalBatchWrapper.renewalBatchDetails.findIndex(
              (existingRenewal: RenewalBatchDetails) =>
                (existingRenewal.originalGroupNumber
                  ? existingRenewal.originalGroupNumber
                  : existingRenewal.groupNumber) ===
                (renewal.originalGroupNumber
                  ? renewal.originalGroupNumber
                  : renewal.groupNumber)
            ) === -1
          );
        }
      );
      this.renewalBatchWrapper.renewalBatchDetails = [
        ...this.renewalBatchWrapper.renewalBatchDetails,
        ...filteredRenewalBatchDetails,
      ];
      this.renewalBatchWrapper.renewalBatchDetails.sort((first, second) => {
        return first["groupName"].localeCompare(second["groupName"]);
      });
    } else {
      this.renewalBatchWrapper.renewalBatchDetails = renewalBatchDetails;
    }
    this.verifyCheckAllDetails();
  }
  enableFTAandMrketSegs() {
    this.availableMarketSegs.forEach(mktseg => {
      mktseg.disabled = false;
    })
    this.availableFTs.forEach(fundingType => {
      fundingType.disabled = false;
    })
  }
  resetClicked() {
  this.formSubmitted = false;
  this.enableFTAandMrketSegs();
  this.setDefaultFormValue();
  this.showFundingType();
  this.first = 0;

  // Always clear searchResults when opening overlay for search
  if (this.selectedMode === 'search') {
    this.searchResults = [];
  }

  let filteredRenewalBatchDetails =
    this.renewalBatchWrapper.renewalBatchDetails.filter(
      (renewal: RenewalBatchDetails) => renewal.batchID
    );
  if (filteredRenewalBatchDetails.length) {
    this.renewalBatchWrapper.renewalBatchDetails =
      filteredRenewalBatchDetails;
  } else {
    this.renewalBatchWrapper.renewalBatchDetails = [];
    this.detailsByFileUpload = undefined;
    this.file = undefined;
  }
}

  setAlertVisibility(
    visibility: boolean,
    type = "",
    message: string = "",
    headervisibility?: boolean,
    isSearchAlert: boolean = false
  ) {
    window.scroll(0, 0);
    this.alert.show = visibility;
    this.alert.type = type || "";
    this.alert.message = message;
    this.alert.cssClass =
      type === AlertType.ERROR ? "alert-danger" : `alert-${type}`;
    this.alert.header = type === AlertType.ERROR ? "failed" : type;
    this.alert.isSearch = isSearchAlert;
    if (headervisibility != undefined) {
      this.alert.headerVisibility = headervisibility;
    }
  }

  setLoaderVisibility(visibility: boolean) {
    window.scroll(0, 0);
    this.loader_visible = visibility;
  }

  removeAlertMsg() {
    this.alert = {
      show: false,
      message: "",
      type: "",
      cssClass: "",
      header: "",
      headerVisibility: true,
      isSearch: false
    };
  }

  goToBatchSearch(): void {
    this.router.navigate(["/group/batch"]);
    this.enableFTAandMrketSegs();
  }

  verifyCheckAllDetails() {
    this.checkAllDetails =
      this.renewalBatchWrapper.renewalBatchDetails.filter(
        (detail) => !detail["included"]
      ).length <= 0;
  }
  verifyCheckAllDetailsOverlay() {
    this.checkAllDetailsOverlay = this.searchResults.length > 0 && this.searchResults.every((detail) => detail['included']);
  }
  checkAllRenewalsOverlay = (event: any) => {
    this.searchResults.forEach(item => {
      item.included = this.checkAllDetailsOverlay;
    });
  }

  closeOverlay(){
    this.selectedMode = null;
  }

  
  verifyAllBulkDataDetails() {
    this.checkAllBulkDetails =
      this.bulkViewTableData.filter((detail) => !detail["included"]).length <=
      0;
  }

  setActiveTab(tab: string, isDeleteOrRestoreFlow?: boolean) {
    this.activeTab = tab;
    if (tab == "BULK") {
      this.hideTestBatch = true;
      this.retriveBulkAdjDetails(isDeleteOrRestoreFlow);
    } else if (tab == "BATCH") {
      this.hideTestBatch = false;
      this.expandClicked = false;
      this.uwSalesNoteIconClicked = false;
      if (!isDeleteOrRestoreFlow)
        this.setAlertVisibility(false);
      this.includedMapToRestore = new Map(
        (this.renewalBatchWrapper?.renewalBatchDetails || []).map(g => [g.groupNumber, g.included])
      );
      const hasUnsavedGroups = (this.renewalBatchWrapper?.renewalBatchDetails || []).some(g => !g.batchID && !g.id);
      if ((isDeleteOrRestoreFlow !== false && this.renewalBatchWrapper?.renewalBatch?.id) ||
        (this.renewalBatchWrapper?.renewalBatch?.id &&
          this.renewalBatchWrapper?.renewalBatch?.batchStatus !== this.submissionStatus.NOT_SUBMITTED)) {
        if (!hasUnsavedGroups) {
          this.fetchRenewalDetailsByBatch();
        }
      } else {
        (this.renewalBatchWrapper?.renewalBatchDetails || []).forEach(g => {
          g.included = this.includedMapToRestore?.get(g.groupNumber) || false;
        });
        this.includedMapToRestore = null;
      }
    }
  }

  bulkTableExpand() {
    this.expandClicked = !this.expandClicked;
    if (this.expandClicked) {
      this.bulkTableCols.push(...RenewalsConstants.BULK_TABLE_COLUMNS_AFTER);
    } else {
      this.bulkTableCols = [...RenewalsConstants.BULK_TABLE_COLUMNS_BEFORE];
    }
  }

  onAdjustment(action: string) {
    if (!this.isDirty && !StringUtils.isEqualIgnoreCase(action, CommonConstants.releaseAction)) {
      let warningMsg = "No Adjustments to Save";
      this.setAlertVisibility(true, AlertType.WARNING, warningMsg);
      return;
    }
    if (this.tableHasInvalidInput()) {
      this.setAlertVisibility(
        true,
        AlertType.WARNING,
        "Please fix Invalid value entered in proposed section."
      );
      return;
    }
    let data = {};
    data["errors"] = "";
    this.constructBulkAdjActionRequest(data, action);
    if (
      data &&
      data["bulkAdjustmentDetails"] &&
      data["bulkAdjustmentDetails"].length < 1
    ) {
      let warningMsg = "No Adjustments to Save";
      if (action != "adjust") {
        warningMsg = "No Eligible groups to " + action + ".";
      }
      this.setAlertVisibility(true, AlertType.WARNING, warningMsg);
      return;
    } else {
      
    }
    data["batchID"] = this.renewalBatchWrapper.renewalBatch["id"];
    data["batchName"] = this.renewalBatchWrapper.renewalBatch["batchName"];
    this.setAlertVisibility(false);
    this.setLoaderVisibility(true);
    this.renewalsService.bulkAdjustmentAction(data, action).subscribe(
      (response) => {
        if (action == "adjust") {
          let alertMsg = "Changes are saved successfully.";
          this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
        }
        this.setLoaderVisibility(false);
        if (
          response &&
          response.body &&
          response.body["description"] &&
          !response.body["description"].startsWith("No Data found")
        ) {
          this.renewalBatchWrapper.renewalBatch["adjustmentStatus"] =
            "In Progress";
          this.listenToBulkAdjEvents(response.body["description"], action);
          if (action == "release") {
            let alertMsg = "Rates released successfully.";
            this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
            this.renewalBatchWrapper.renewalBatch[
              "recentReleaseProcessStatus"
            ] = "In Progress";
            var eventSource = this.commonService.listenForStream(
              response.body["description"] + "REL"
            );
            this.listenToBulkReleaseEvents(eventSource);
          }
        } else {
          this.setAlertVisibility(
            true,
            AlertType.WARNING,
            "No Adjustments to " + action
          );
        }
      },
      (error) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(
          true,
          AlertType.WARNING,
          "Bulk adjustment " + action + " Failed !"
        );
      }
    );
  }

  private tableHasInvalidInput() {
    return this.bulkViewTableData.find((rowData) => rowData["invalidinput"] == true);
  }

  private validateAdjAction(action: string, data: {}) {
    for (let bulkAdjustmentDetails of data["bulkAdjustmentDetails"]) {
      let changedData = bulkAdjustmentDetails["uw-request"]["uwAdjustment"];
      if ("release" == action && changedData?.included
        && (!changedData.uwNotesToSales || changedData.uwNotesToSales.trim() == "")) {
        data["errors"] = data["errors"].concat("Please enter UW notes to sales for all the selected groups.");
        break;
      }
    }
  }

  private listenToBulkAdjEvents(processID: string, action: string): void {
    var eventSource = this.commonService.listenForStream(processID);

    eventSource.addEventListener(
      "BATCH_RENEWAL_ADJUST_REQUEST_SUBMITTED",
      (event: any) => {
        this.mapEventStreamResponse(event, "SUBMITTED");
      }
    );
    eventSource.addEventListener(
      "BATCH_RENEWAL_ADJUST_REQUEST_QUEUED",
      (event: any) => {
        this.mapEventStreamResponse(event, "QUEUED");
      }
    );

    eventSource.addEventListener(
      "BATCH_RENEWAL_ADJUST_REQUEST_SINGLE_COMPLETE",
      (event: any) => {
        if (event && event.data && action == "adjust") {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;

          this.setAdjustmentStatus(eventData, "SINGLE_COMPLETE");
        }
      }
    );

    eventSource.addEventListener(
      "BATCH_RENEWAL_ADJUST_PROCESS_COMPLETION_TRIGGER",
      (event: any) => {
        eventSource.close();
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
        }
        var promise = new Promise<any>((resolve) => {
          setTimeout(() => {
            resolve(false);
          }, 9000);
        });

        this.renewalBatchWrapper.renewalBatch["recentReleaseProcessStatus"] = "SUCCESS";
        this.renewalBatchWrapper.renewalBatch["adjustmentStatus"] = "SUCCESS";
        promise.then((res) => {
          this.bulkViewTableData.forEach((data) => {
            if (data["adjustmentStatus"] == "SUCCESS")
              data["adjustmentStatus"] = "";
          });
        });
      }
    );
  }

  private listenToBulkReleaseEvents(eventSource: any): void {
    eventSource.addEventListener(
      "BATCH_RELEASE_UPDATEUI_TASK",
      (event: any) => {
        this.processBulkReleaseEvents(event);
      }
    );

    eventSource.addEventListener(
      "BATCH_RELEASE_PROCESS_COMPLETION_TRIGGER",
      (event: any) => {
        eventSource.close();
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          this.receivedBatchEvents = this.receivedBatchEvents.filter(
            (e) => !e.startsWith(eventData.processId)
          );
          this.renewalBatchWrapper.renewalBatch["recentReleaseProcessStatus"] =
            payload.recentReleaseProcessStatus;

          this.bulkViewTableData.forEach((bulkdata) => {
            bulkdata["adjustmentStatus"] = "SUCCESS";
          })
        }
      }
    );
  }

  checkIfAdjustmentActionInProgress() {
    //Add Decline, if implemented
    return (
      this.renewalBatchWrapper?.renewalBatch["adjustmentStatus"] ==
      "In Progress" ||
      this.renewalBatchWrapper.renewalBatch["recentReleaseProcessStatus"] ==
      "In Progress" ||
      this.isUserReadOnly
    );
  }

  private mapEventStreamResponse(event: any, adjStatus: string) {
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      let group = this.setAdjustmentStatus(eventData, adjStatus);
      if (group) {
        if (group["saveActionStatus"] == "Success") {
          let index = this.bulkAdjData.findIndex(
            (data) =>
              data["opportunityID"] == group["opportunityID"] &&
              data["quoteHeaderID"] == group["quoteHeaderID"] &&
              data["ratingTransID"] == group["ratingTransID"]
          );
          if (index != -1) {
            this.bulkAdjData[index]["adjustedRateActionPercent"] =
              group["adjustedRateActionPercent"];
            this.bulkAdjData[index]["renewalWHAPercent"] =
              group["renewalWHAPercent"];
            this.bulkAdjData[index]["asoAdminFee"] = group["asoAdminFee"];
            this.bulkAdjData[index]["sslPremium"] = group["sslPremium"];
            this.bulkAdjData[index]["aslPremium"] = group["aslPremium"];
            this.bulkAdjData[index]["maxPaidClaim"] = group["maxPaidClaim"];
            this.bulkAdjData[index]["terminalLiability"] =
              group["terminalLiability"];
            this.bulkAdjData[index]["uwNotesToSales"] = group["uwNotesToSales"];
          }
        }
      }
    }
  }

  private processBulkReleaseEvents(event: any) {

    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      let payload = eventData["payload"];
      if (this.isDummyEvent(payload)) {
        return;
      }
      let index = this.bulkViewTableData.findIndex(
        (data) =>
          data["opportunityID"] == payload["opportunityID"] &&
          data["quoteHeaderID"] == payload["quoteHeaderID"] &&
          data["ratingTransID"] == payload["ratingTransID"]
      );
      if (index != -1) {
        let releaseProcessDetails = payload["releaseProcessDetails"];
        if (
          this.receivedBatchEvents.includes(
            eventData.processId +
            payload["ratingTransID"] +
            releaseProcessDetails.eventName
          )
        ) {
          return;
        }
        this.receivedBatchEvents.push(
          eventData.processId +
          payload["ratingTransID"] +
          releaseProcessDetails.eventName
        );
        let eventName = releaseProcessDetails.eventName;
        let suppHealthReleaseProcessDetails =
          releaseProcessDetails.suppHealthReleaseProcessDetails;
        if (!this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"]) {
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"] = {};
        }
        if (eventName == "BATCH_RELEASE_CLEAN_DATA") {
          this.bulkViewTableData[index]["releaseStatus"] =
            releaseProcessDetails["releaseStatus"];
          this.bulkViewTableData[index]["releaseProcessErrors"] =
            releaseProcessDetails["releaseProcessErrors"];
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"] =
            suppHealthReleaseProcessDetails;
        } else if (eventName == "BATCH_RELEASE_SUPP_HEALTH_ADJUST") {
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "isAdjustTaskDone"
          ] = suppHealthReleaseProcessDetails["isAdjustTaskDone"];
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "adjustmentStatus"
          ] = suppHealthReleaseProcessDetails["adjustmentStatus"];
        } else if (eventName == "BATCH_RELEASE_SUPP_HEALTH_SUBMIT_RESPONSE_EXTERNAL") {
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "isResponseExtSubmitTaskDone"
          ] = suppHealthReleaseProcessDetails["isResponseExtSubmitTaskDone"];
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "responseExtSubmissionStatus"
          ] = suppHealthReleaseProcessDetails["responseExtSubmissionStatus"];
        } else if (eventName == "BATCH_RELEASE_SUPP_HEALTH_GENERATE_EXHIBIT") {
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "isExhibitGenerationTaskDone"
          ] = suppHealthReleaseProcessDetails["isExhibitGenerationTaskDone"];
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "exhibitGenerationStatus"
          ] = suppHealthReleaseProcessDetails["exhibitGenerationStatus"];
        } else if (eventName == "BATCH_RELEASE_SUPP_HEALTH_GENERATE_FINAL_RESPONSE") {
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "isResponseGenerationTaskDone"
          ] = suppHealthReleaseProcessDetails["isResponseGenerationTaskDone"];
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "responseGenerationStatus"
          ] = suppHealthReleaseProcessDetails["responseGenerationStatus"];
        } else if (eventName == "BATCH_RELEASE_SUPP_HEALTH_UPDATE_STATUS") {
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "isStatusUpdateTaskDone"
          ] = suppHealthReleaseProcessDetails["isStatusUpdateTaskDone"];
          this.bulkViewTableData[index]["suppHealthReleaseProcessDetails"][
            "statusUpdateStatus"
          ] = suppHealthReleaseProcessDetails["statusUpdateStatus"];
        } else if (eventName == "BATCH_RELEASE_PROCESS_SINGLE_COMPLETE") {
          this.bulkViewTableData[index]["releaseStatus"] =
            releaseProcessDetails["releaseStatus"];
          this.flushGrdRlMsgOnRelease(
            releaseProcessDetails["releaseStatus"],
            this.bulkViewTableData[index]
          );

          this.renewalBatchWrapper.renewalBatch["recentReleaseProcessStatus"] = "SUCCESS";
          this.renewalBatchWrapper.renewalBatch["adjustmentStatus"] =
            "SUCCESS";

          this.setAdjustmentStatus(eventData, "SINGLE_COMPLETE");
          this.bulkViewTableData[index]["releaseProcessErrors"] =
            releaseProcessDetails["releaseProcessErrors"];
        }
      }
    }
  }

  private flushGrdRlMsgOnRelease(
    releaseStatus: string,
    bulkViewData: any
  ): void {
    if (releaseStatus == "Success") {
      bulkViewData["errorMsg"] = "";
    }
  }

  getReleaseProcessTabletclass(
    lobReleaseProcessNode: string,
    tabletIsDoneNode: string,
    tabletEventNode: string,
    bulkdata: any
  ) {
    if (bulkdata[lobReleaseProcessNode]) {
      if (bulkdata[lobReleaseProcessNode][tabletIsDoneNode] == true) {
        if (bulkdata[lobReleaseProcessNode][tabletEventNode] == "Success") {
          return "renewalGrpsbmsnSuccess";
        } else if (
          bulkdata[lobReleaseProcessNode][tabletEventNode] &&
          bulkdata[lobReleaseProcessNode][tabletEventNode].startsWith("Failed")
        ) {
          return "renewalGrpsbmsnFailed";
        } else {
          return "";
        }
      } else if (bulkdata[lobReleaseProcessNode][tabletEventNode] == "NA") {
        return "renewalGrpsbmsnNA";
      }
    }
    return "";
  }

  setbgColor(header: string, bulkdata: any) {
    if (
      header == "Release Status" &&
      ["Success", "Failed"].includes(bulkdata.releaseStatus)
    ) {
      if (bulkdata.releaseProcessErrors) {
        return "bg-alert-danger";
      } else {
        return "bg-alert-success";
      }
    }
    return "";
  }

  getReleaseProcessTabletToolTip(
    lobReleaseProcessNode: string,
    tabletIsDoneNode: string,
    tabletStatusNode: string,
    step: string,
    bulkdata: any
  ) {
    if (
      bulkdata[lobReleaseProcessNode] &&
      bulkdata[lobReleaseProcessNode][tabletIsDoneNode]
    ) {
      if (
        bulkdata[lobReleaseProcessNode][tabletStatusNode] != "Success" ||
        (this.bulkViewTableData["releaseFailCheckPoint"] &&
          this.bulkViewTableData["releaseFailCheckPoint"] == step)
      ) {
        return bulkdata[lobReleaseProcessNode][tabletStatusNode];
      } else {
        return "";
      }
    }
    return "";
  }

  private setAdjustmentStatus(eventData: any, status: string) {
    let foundGroup = this.bulkViewTableData.find(
      (data) =>
        data["opportunityID"] == eventData["payload"]["opportunityID"] &&
        data["quoteHeaderID"] == eventData["payload"]["quoteHeaderID"] &&
        data["ratingTransID"] == eventData["payload"]["ratingTransID"]
    );
    if (foundGroup) {
      if (
        status == "SINGLE_COMPLETE" &&
        eventData["payload"] &&
        (eventData["payload"]["mpcRateAction"] ||
          eventData["payload"]["mpcRateAction"] == 0)
      ) {
        foundGroup["mpcRateAction"] =
          eventData["payload"]["mpcRateAction"] || 0;
      }

      if (eventData["payload"] && eventData["payload"]["status"]) {
        foundGroup["saveActionStatus"] = eventData["payload"]["status"];
      }
      if (eventData["payload"]["errorMsg"]) {
        foundGroup["adjustmentStatus"] =
          foundGroup["saveActionStatus"] == "Failed" ? "FAILED" : "";
        foundGroup["errorMsg"] = eventData["payload"]["errorMsg"];
        return foundGroup;
      }
      if (status == "SINGLE_COMPLETE") {
        foundGroup["adjustmentStatus"] = "SUCCESS";
        return foundGroup;
      }

      foundGroup["adjustmentStatus"] = status;
      return foundGroup;
    }
  }

  private constructBulkAdjActionRequest(data: {}, action: string) {
    data["bulkAdjustmentDetails"] = [];
    this.bulkAdjData.forEach((bulkdata) => {
      let requestData = {};
      let changedData = this.bulkViewTableData.find(
        (viewdata) => viewdata["groupNumber"] == bulkdata["groupNumber"]
      );
      let changedDataIndex = this.bulkViewTableData.findIndex(
        (viewdata) => viewdata["groupNumber"] == bulkdata["groupNumber"]
      );
      if (changedData && bulkdata) {
        let changeSet = this.uwChangeSetService.constructBulkChangeSet(bulkdata, changedData);
        if ((action != "adjust" && changedData.included) || (action == "adjust" && null != changeSet)) {
          let adjustStatus = action != "adjust" ? "" : "SUBMITTED";
          this.bulkViewTableData[changedDataIndex]["adjustmentStatus"] = adjustStatus;
          this.bulkViewTableData[changedDataIndex]["errorMsg"] = "";
          if (null != changeSet) {
            requestData["uw-action-changeset"] = changeSet;
          }
          requestData["uw-request"] = CreateBatchUtilSuppHealth.constructUWRequest(changedData, action, this.isFIBulkAdj);
          requestData["groupNumber"] = bulkdata["groupNumber"];
          data["bulkAdjustmentDetails"].push(requestData);
        }
      }
    });
  }

  retriveBulkAdjDetails(isDeleteOrRestoreFlow?: boolean) {
    this.expandClicked = false;
    this.uwSalesNoteIconClicked = false;
    this.uwSelfNoteIconClicked = false;
    this.bulkViewTableData = [];
    this.bulkAdjData = [];
    this.expTotalRateActionPercent = "";
    this.uwTotalRateActionPercent = "";
    this.currentPlanTotPrem = 0;
    this.renewalPlanTotPrem = 0;
    this.adjustedPlanTotprem = 0;
    this.showLoader = true;
    this.renewalsService
      .fetchBulkAdjustmentDetails(this.renewalBatchWrapper.renewalBatch["id"])
      .subscribe(
        (data) => {
          if (data["processId"])
            this.listenToBulkAdjDetailsEvents(data["processId"], isDeleteOrRestoreFlow);
        },
        (error) => {
          this.showLoader = false;
          console.error("error retriveBulkAdjDetails ", error);
        }
      );
  }
  isFIBulkAdj: boolean = false;
  private listenToBulkAdjDetailsEvents(processID: string, isDeleteOrRestoreFlow?: boolean) {
    this.hasDeletedGroupsInBulk = false;
    var eventSource = this.commonService.listenForStream(processID);
    eventSource.addEventListener("BULK_DETAILS_STATUS", (event: any) => { });
    eventSource.addEventListener("BULK_ADJ_DETAILS_FETCH", (event: any) => {
      if (event.data) {
        var eventData = JSON.parse(event.data);
        var bulkAdjdetails = eventData["payload"]["bulkAdjDetails"];
        this.hasDeletedGroupsInBulk = eventData["payload"][RenewalsConstants.HAS_DELETED_GROUPS] == "true" ? true : false;
        this.calculateProposedIncreaseAfterFetch(bulkAdjdetails);
        this.calculateSuggestedIncreaseAfterFetch(bulkAdjdetails);
        this.loadProductAdjustments(bulkAdjdetails);
        this.bulkViewTableData.push(...bulkAdjdetails);
        this.isFIBulkAdj = StringUtils.isEqual(this.bulkViewTableData[0].fundingType, 'FI')
        this.bulkTableCols = [...RenewalsConstants.SUPP_HEALTH_BULK_TABLE_COLUMNS];
        this.bulkAdjData = CreateBatchUtilSuppHealth.constructBulkAdjDataForComparsion(bulkAdjdetails, this.bulkAdjData);
        if (this.checkBulkAdjDataExists()) {
          this.showLoader = false;
          if (isDeleteOrRestoreFlow) {
            this.disableBulkAdj = false;
          }
        }
      }
    });
    eventSource.addEventListener(
      "BULK_ADJ_DETAILS_FETCH_COMPLETE",
      (event: any) => {
        eventSource.close();
        if (this.checkBulkAdjDataExists()) {
          this.bulkViewTableData.sort((first, second) => {
            return first["groupName"].localeCompare(second["groupName"]);
          });
          this.calculateTotalRateActionPercent();
          this.setAlertVisibility(
            true,
            AlertType.SUCCESS,
            "Bulk adjustment details loaded successfully"
          );
          this.verifyAllBulkDataDetails();
          if (event.data) {
            var eventData = JSON.parse(event.data);
            var adjustmentProcessID =
              eventData["payload"]["adjustmentProcessID"];
            var releaseProcessID = eventData["payload"]["releaseProcessID"];
            var exhibitFetchProcessID =
              eventData["payload"]["exhibitFetchProcessID"];
            var exhibitFetchStatus = eventData["payload"]["exhibitFetchStatus"];
            if (adjustmentProcessID)
              this.commonService.listenForStream(adjustmentProcessID);
            if (releaseProcessID) {
              var relEventSource =
                this.commonService.listenForStreamTrackAndFail(
                  releaseProcessID
                );
              this.listenToBulkReleaseEvents(relEventSource);
            }
            if (exhibitFetchProcessID && null != exhibitFetchProcessID) {
              this.currentExhibitLinkProcessId = exhibitFetchProcessID;
              this.renewalBatchWrapper.renewalBatch[
                "recentExhibitsFetchStatus"
              ] = status;
              if ("In Progress" == exhibitFetchStatus) {
                var exhibitFetchEventSource =
                  this.commonService.listenForStreamTrackAndFail(
                    exhibitFetchProcessID
                  );
                this.listenRenewalExhibitFetchLinkEvents(
                  exhibitFetchEventSource,
                  exhibitFetchProcessID
                );
              } else {
                this.downloadPrintExhibitsZip(true);
              }
            }
          }
        } else {
          this.showLoader = false;
          if (isDeleteOrRestoreFlow) {
            this.tableDataExist = false;
            this.hasDeletedGroupsInBulk = true;
          } else {
            this.setAlertVisibility(
              true,
              AlertType.ERROR,
              "Error occured while fetching Bulk adjustment details"
            );
          }
        }
      }
    );
    eventSource.addEventListener("FAILED", (event: any) => {
      eventSource.close();
    });
  }

  private checkBulkAdjDataExists(): boolean {
    return this.bulkViewTableData && this.bulkViewTableData.length > 0;
  }

  private calculateTotalRateActionPercent() {
    this.expTotalRateActionPercent = this.uwAdjService.totalRateActionCalc(
      this.currentPlanTotPrem,
      this.renewalPlanTotPrem
    );
    this.uwTotalRateActionPercent = this.uwAdjService.totalRateActionCalc(
      this.currentPlanTotPrem,
      this.adjustedPlanTotprem
    );
  }

  private calculateRateActionGrndTotal(bulkAdjdetails: any) {
    let calc = UnderwriterAdjustmentService.summingPlanTotprem(bulkAdjdetails);
    if (calc) {
      this.currentPlanTotPrem =
        this.currentPlanTotPrem + calc["currentPlanTotPrem"];
      this.renewalPlanTotPrem =
        this.renewalPlanTotPrem + calc["renewalPlanTotPrem"];
      this.adjustedPlanTotprem =
        this.adjustedPlanTotprem + calc["adjustedRenewalPlanTotPrem"];
    }
  }

  assignChangedValue(rowData, key) {
    if (this.changedKey == key && !this.isRateActionAdjColumnProperty(key)) {
      rowData[key] = this.valueChanged;
      this.valueChanged = "";
      this.cmplnFldCodes = CreateBatchUtil.setorRevertGuardRailMsg(rowData, this.cmplnFldCodes, this.bulkAdjData);
      this.changedKey = "";
    }
  }

  onRateActionChange(key, rowData, event, ratingPlanId) {
    this.isDirty = true;
    let enterdValue = event.replace("%", "").replace(",", "");
    this.valueChanged = enterdValue;
    this.changedKey = key;
    if (key === 'suppHealthOverallProposedIncrease') {
      this.updateAllAdjustmentsToProposedIncrease(rowData, event);
    }
    if (
      (enterdValue == "" && key !== "renewalWHAPercent") ||
      isNaN(enterdValue)
    ) {
      rowData["invalidinput"] = true;
      this.updateRateActionAdjustment(rowData, key, ratingPlanId, enterdValue);
      rowData["suppHealthOverallProposedIncrease"] = this.calculateProposedIncrease(rowData);
      return;
    } else {
      rowData["invalidinput"] = false;
    }
    if (rowData["status"]) {
      if (key == "adjustedRateActionPercent" || key === "renewalWHAPercent") {
        let calcProposedIncrease =
          key === "renewalWHAPercent"
            ? rowData["adjustedRateActionPercent"] - enterdValue
            : this.getRateActionPercent(rowData, enterdValue);
        if (
          (rowData[key] || key === "renewalWHAPercent") &&
          CreateBatchUtil.checkExpFactorsPresent(rowData)
        ) {
          let expAdjFactor = this.uwAdjService.callRateActionForBulk(
            calcProposedIncrease,
            rowData["data"]["factors"]["experienceFactors"][
            "currentComponentTotal"
            ]["totalPremium"],
            rowData["data"]["factors"],
            rowData["data"]["factors"]["experienceFactors"][
            "experienceAdjustmentFactor"
            ], rowData["data"]['medicalAlternateTier']
          );
          rowData["totalQlAdj"] = expAdjFactor;
          this.calculateRateActionPercent(rowData, expAdjFactor, enterdValue);
        }
      } else if (
        (key == "asoAdminFee" ||
          key == "sslPremium" ||
          key == "aslPremium" ||
          key == "terminalLiability" ||
          key == "maxPaidClaim") &&
        rowData[key]
      ) {
        if (!rowData["totalQlAdj"] && CreateBatchUtil.checkExpFactorsPresent(rowData)) {
          rowData["totalQlAdj"] = this.uwAdjService.calculateRateActionFactor(
            this.getRateActionPercent(
              rowData,
              rowData["adjustedRateActionPercent"] ||
              rowData["blendedIncrease"] * 100
            ),
            rowData["data"]["factors"]["experienceFactors"][
            "currentComponentTotal"
            ]["totalPremium"],
            rowData["data"]["factors"]["experienceFactors"][
            "expComponentTotal"
            ]["totalPremium"],
            rowData["data"]["factors"]["experienceFactors"][
            "experienceAdjustmentFactor"
            ]
          );
        }
        if (!rowData["calculatedIntialCompRates"]) {
          let quoteDetail = {
            medical: { currentPlans: rowData["currentPlans"] },
            uwAdjustment: {
              abfRateActionAdjustment: {
                totalQlAdj: rowData["totalQlAdj"],
                abfRateActionPercent:
                  rowData["adjustedRateActionPercent"] ||
                  rowData["blendedIncrease"] * 100,
              },
              outputTier: rowData["data"]["medicalOutputTier"],
              tierRatioCalculationType:
                rowData["data"]["factors"]["tierRatioCalculationType"],
            },
            factors: rowData["data"]["factors"],
          };
          rowData["quoteDetail"] = quoteDetail;
          let calculatedCompRates =
            this.uwAdjService.calculateQtLvlAdjAndComponentRates(
              rowData["data"]["proposedPlans"],
              quoteDetail
            );
          rowData["calculatedIntialCompRates"] = JSON.parse(
            JSON.stringify(calculatedCompRates)
          );
          let abfRateActionAdjustments = {
            abfRateActionPercent:
              rowData["adjustedRateActionPercent"] ||
              rowData["blendedIncrease"] * 100,
            totalQlAdj: rowData["totalQlAdj"],
            asoAdminFee:
              key == "asoAdminFee" ? enterdValue : rowData["asoAdminFee"],
            sslPremium:
              key == "sslPremium" ? enterdValue : rowData["sslPremium"],
            aslPremium:
              key == "aslPremium" ? enterdValue : rowData["aslPremium"],
            terminalLiability:
              key == "terminalLiability"
                ? enterdValue
                : rowData["terminalLiability"],
            maxPaidClaim:
              key == "maxPaidClaim" ? enterdValue : rowData["maxPaidClaim"],
          };
          rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"] =
            abfRateActionAdjustments;
          this.uwAdjService.calculateComponentAdjFactors(
            rowData["data"]["factors"],
            calculatedCompRates,
            calculatedCompRates,
            abfRateActionAdjustments
          );
          rowData["calculatedCompRates"] = calculatedCompRates;
          rowData["adjustedRateActionPercent"] =
            abfRateActionAdjustments["abfRateActionPercent"];
        }

        if (
          rowData[key] &&
          rowData["data"] &&
          rowData["data"]["factors"]["experienceFactors"] &&
          rowData["data"]["factors"]["experienceFactors"] &&
          rowData["data"]["factors"]["experienceFactors"][
          "currentComponentTotal"
          ] &&
          rowData["data"]["factors"]["experienceFactors"][
          "currentComponentTotal"
          ][key]
        ) {
          let adjFactor = this.uwAdjService.calculateRateActionFactor(
            enterdValue,
            rowData["data"]["factors"]["experienceFactors"][
            "currentComponentTotal"
            ][key],
            rowData["calculatedIntialCompRates"][
            this.uwAdjService.getKey(key, false)
            ],
            1
          );
          rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
            key
          ] = enterdValue;
          rowData["calculatedCompRates"][this.uwAdjService.getKey(key, true)] =
            adjFactor;
          rowData["calculatedCompRates"] =
            this.uwAdjService.calculateQtLvlAdjAndComponentRates(
              rowData["data"]["proposedPlans"],
              rowData["quoteDetail"],
              rowData["calculatedCompRates"]
            );
          this.uwAdjService.calculateComponentPercentage(
            rowData["data"]["factors"]["experienceFactors"][
            "currentComponentTotal"
            ],
            rowData["calculatedCompRates"]
          );
          rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
            key
          ] = enterdValue;
          this.uwAdjService.calculateComponentAdjFactors(
            rowData["data"]["factors"],
            rowData["calculatedCompRates"],
            rowData["calculatedIntialCompRates"],
            rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"]
          );
          rowData["maxPaidClaim"] =
            rowData["calculatedCompRates"]["maxPaidClaimCompPercent"];
          if (!rowData["asoAdminFee"]) {
            rowData["asoAdminFee"] =
              rowData["calculatedCompRates"]["asoAdminCompPercent"];
          }
          if (!rowData["sslPremium"]) {
            rowData["sslPremium"] =
              rowData["calculatedCompRates"]["sslPremCompPercent"];
          }
          if (!rowData["aslPremium"]) {
            rowData["aslPremium"] =
              rowData["calculatedCompRates"]["aslPremCompPercent"];
          }
          if (!rowData["terminalLiability"]) {
            rowData["terminalLiability"] =
              rowData["calculatedCompRates"]["terminalLiabilityCompPercent"];
          }
        }
      }
      if (this.isRateActionAdjColumnProperty(key)) {
        this.updateRateActionAdjustment(rowData, key, ratingPlanId, enterdValue);
        rowData["suppHealthOverallProposedIncrease"] = this.calculateProposedIncrease(rowData);
      }
      if (rowData["data"]["proposedPlans"]) {
        this.invokeRatesCalAndCheckGuardRails(rowData);
        if (key == "adjustedRateActionPercent" || key == "renewalWHAPercent") {
          this.adjustedPlanTotprem =
            UnderwriterAdjustmentService.calculateUWGrandTotal(
              rowData,
              this.bulkViewTableData
            );
          this.uwTotalRateActionPercent = this.uwAdjService.totalRateActionCalc(
            this.currentPlanTotPrem,
            this.adjustedPlanTotprem
          );
        }
      }
    }
  }

  updateRateActionAdjustment(rowData, key, ratingPlanId, newValue) {
    const propertyName = 'ratingPlanID';
    let adjustment = this.findProductByPropertyInAdjustments(propertyName, ratingPlanId, rowData)
    if (adjustment) {
      adjustment['proposedRateActionAdjustment'] = Number(newValue);
      this.updateProductAdjustmentsSet(rowData, key, adjustment);
    }
  }

  /**
   *  This maintains a set of changes under rowData.productAdjustments
   *  that is sent with the changeSet on save bulk adjustments
   * @param rowData
   * @param key
   * @param newAdjustment
   */
  updateProductAdjustmentsSet(rowData, key, newAdjustment) {
    const productAdjustment = {
      adjustmentType: key,
      planName: newAdjustment.planName,
      ratingPlanID: newAdjustment.ratingPlanID,
      suggestedRateActionAdjustment: newAdjustment.suggestedRateActionAdjustment,
      uwAdjustmentFactor: newAdjustment.proposedRateActionAdjustment
    }

    if (!rowData.productAdjustments) {
      rowData.productAdjustments = [];
    }

    const adjustmentIndex = rowData.productAdjustments.findIndex(adjustment => adjustment.ratingPlanID === productAdjustment.ratingPlanID);

    if (adjustmentIndex !== -1) {
      rowData.productAdjustments[adjustmentIndex] = productAdjustment;
    } else {
      rowData.productAdjustments.push(productAdjustment);
    }
  }

  findProductByPropertyInAdjustments(propertyName, value, rowData) {
    const accidentAdjustments = rowData.accidentAdjustments;
    const hospitalIndemnityAdjustments = rowData.hospitalIndemnityAdjustments;
    const criticalIllnessAdjustments = rowData.criticalIllnessAdjustments;

    let accidentAdjustment = this.findAdjustmentByPropertyValue(accidentAdjustments, propertyName, value);
    if (accidentAdjustment) {
      return accidentAdjustment;
    }

    let hospitalIndemnityAdjustment = this.findAdjustmentByPropertyValue(hospitalIndemnityAdjustments, propertyName, value);
    if (hospitalIndemnityAdjustment) {
      return hospitalIndemnityAdjustment;
    }

    let criticalIllnessAdjustment = this.findAdjustmentByPropertyValue(criticalIllnessAdjustments, propertyName, value);
    if (criticalIllnessAdjustment) {
      return criticalIllnessAdjustment;
    }
  }

  findAdjustmentByPropertyValue(adjustments: any[], property: string, value: string) {
    if (!adjustments) {
      return null;
    }
    return adjustments.find((adjustment) => adjustment[property] === value);
  }

  private getRateActionPercent(rowData, enterdValue) {
    let renewalHWPercent = rowData["renewalWHAPercent"];
    return renewalHWPercent ? enterdValue - renewalHWPercent : enterdValue;
  }

  private calculateRateActionPercent(
    rowData: any,
    expAdjFactor: number,
    enterdValue
  ) {
    if (
      rowData["data"] &&
      rowData["data"]["proposedPlans"] &&
      rowData["data"]["proposedPlans"].length > 0 &&
      rowData["currentPlans"] &&
      rowData["currentPlans"].length > 0
    ) {
      let quoteDetail = {
        medical: { currentPlans: rowData["currentPlans"] },
        uwAdjustment: {
          abfRateActionAdjustment: {
            totalQlAdj: expAdjFactor,
            abfRateActionPercent: enterdValue,
          },
          outputTier: rowData["data"]["medicalAlternateTier"],
          tierRatioCalculationType:
            rowData["data"]["factors"]["tierRatioCalculationType"],
        },
        factors: rowData["data"]["factors"],
        medicalOutputTier: rowData["data"]["medicalOutputTier"]
      };
      rowData["quoteDetail"] = quoteDetail;
      if (!this.isFIBulkAdj) {
        let calculatedCompRates =
          this.uwAdjService.calculateQtLvlAdjAndComponentRates(
            rowData["data"]["proposedPlans"],
            quoteDetail
          );
        this.uwAdjService.calculateComponentPercentage(
          rowData["data"]["factors"]["experienceFactors"][
          "currentComponentTotal"
          ],
          calculatedCompRates
        );
        rowData["calculatedIntialCompRates"] = JSON.parse(
          JSON.stringify(calculatedCompRates)
        );
        rowData["calculatedCompRates"] = calculatedCompRates;
        rowData = CreateBatchUtil.setCalculatedRateActionPercent(rowData, calculatedCompRates);
        this.uwAdjService.calculateComponentAdjFactors(
          rowData["data"]["factors"],
          calculatedCompRates,
          calculatedCompRates,
          rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"]
        );
      }
    }
  }

  formatNumbers(value, field) {
    if (field === CommonConstants.IN_RATE_GUARANTEE) {
      return value == true ? 'Yes' : 'No'
    }

    if (
      this.fieldToPercentConvert.includes(field) &&
      (value || value == 0) &&
      !isNaN(value)
    )
      return formatPercent(value, this.locale, "1.0-4");

    if (
      this.fieldToConcatPrcnt.includes(field) &&
      !this.isEmptyValue(value) &&
      (value || value == 0) &&
      !isNaN(value)
    )
      return formatPercent(value / 100, this.locale, "1.0-4");

    if (field == "cyTotalClmsOverSsl" || field == "cySurplusOrDeficit")
      return value == null
        ? value
        : formatCurrency(
          Math.abs(value),
          this.locale,
          getCurrencySymbol("USD", "wide")
        );

    return value;
  }

  getRateActionAdjustment(suppHealthProductAdjustments) {
    return suppHealthProductAdjustments.proposedRateActionAdjustment;
  }

  checkValidNumber(key, value, disabled: boolean) {
    if (disabled) {
      return "";
    }
    if (key === "renewalWHAPercent") {
      return isNaN(value) && !(value === "" || typeof value == "undefined")
        ? "redContent"
        : "";
    }
    if (value === "") return "redContent";
    if (isNaN(value)) return "redContent";
  }

  checkAdjustmentValidNumber(key, index, value, disabled: boolean) {
    if (disabled) {
      return "";
    }
    if (value[index].proposedRateActionAdjustment === "0"
      || isNaN(value[index].proposedRateActionAdjustment)
      || StringUtils.isEmpty(value[index].proposedRateActionAdjustment)) {
      return "redContent";
    }
  }

  getClassForValues(field: string, value: number) {
    if (field == "cyTotalClmsOverSsl" || field == "cySurplusOrDeficit") {
      return value < 0 ? "lesser" : "";
    }
  }

  isBatchInfoSmallTableHeader = (header: string) => {
    return this.BATCH_INFO_SMALL_TH.includes(header);
  }

  getToolTipHeaderValue() {
    return this.isFIBulkAdj ? "Incurred" : "Paid"
  }
  getToolTipValue(field: string, bulkData: any) {
    if (field == "cyTotalClmsOverSsl")
      return bulkData["sslDeductable"]
        ? formatCurrency(
          bulkData["sslDeductable"],
          this.locale,
          getCurrencySymbol("USD", "wide"),
          "",
          "2.0"
        )
        : "";
    if (field == "cyCntrctMaxClmFndLr")
      return bulkData["aggSLCorridor"]
        ? formatPercent(bulkData["aggSLCorridor"], this.locale, "1.0-4")
        : "";
    if (field == "cySurplusOrDeficit")
      return bulkData["surplusRefund"]
        ? formatPercent(bulkData["surplusRefund"], this.locale, "1.0-4")
        : "";
  }

  grpNameAndNumberValidation = () => {
    const groupNameValue = this.batchSearchForm.get('groupName').value as string;
    const groupNumberValue = this.batchSearchForm.get('groupNumber').value as string;
    if(groupNameValue.length !== 0 || groupNumberValue.length !== 0) {
      this.groupNumbersFile = null;
    }
    if (this.groupNumbersFile || groupNameValue.length !== 0 || groupNumberValue.length !== 0) {
      let states = [];
      let months = [];
      this.commonService.getStateList().forEach((val: any) => {
        states.push(val.value);
      });
      this.selectstate = states;
      this.availableRenewalMonths.forEach((val: any) => {
        months.push(val.value);
      });
      this.selectmonths = months;
    } else if (groupNameValue.length === 0 && groupNumberValue.length === 0 && !this.groupNumbersFile) {
      this.selectstate = [];
      this.selectmonths = [];
    }
  }

  disableRateActionInput(bulkdata: any): boolean {
    return (
      bulkdata["status"] === QuoteRenewalStatus.AWAITING_RISK_SCORE ||
      bulkdata["status"] === QuoteRenewalStatus.AWAITING_P2A_DATA ||
      bulkdata["status"] === QuoteRenewalStatus.RECEIVED ||
      bulkdata["status"] === QuoteRenewalStatus.PROCESSING ||
      bulkdata["status"] === QuoteRenewalStatus.FAIL ||
      bulkdata["adjustmentStatus"] == "SUBMITTED" ||
      bulkdata["status"] == QuoteRenewalStatus.FAILED_TO_GATEWAY ||
      bulkdata["status"] == QuoteRenewalStatus.SENT_TO_RARE ||
      bulkdata["adjustmentStatus"] == "QUEUED"
    );
  }
  trackByFunction = (_index: number, item: any): string => {
    // Stable key independent of index — matches the canonical row identity used in bulkViewTableDataMap
    return `${item.groupNumber}_${item.opportunityID}_${item.quoteHeaderID}_${item.ratingTransID}`;
  };
  getSubmissionToopTipStatus(groupDetail: any, submissionFailCheckPoint: any): string {
    if (groupDetail) {
      if (!StringUtils.isEmpty(submissionFailCheckPoint)) {
        if (StringUtils.isEqualIgnoreCase(
          submissionFailCheckPoint, groupDetail.submissionFailCheckPoint) &&
          StringUtils.isEqualIgnoreCase(groupDetail.submissionStatus, QuoteSubmissionStatus.FAILED)) {
          return (
            groupDetail.submissionErrors ||
            "Something went wrong !!!"
          );
        }
      }
      else if (StringUtils.isEqualIgnoreCase(groupDetail.specialtySubmittedStatus, QuoteSubmissionStatus.FAILED)) {
        return (
          groupDetail.specialtyErrors ||
          "Something went wrong !!!"
        );
      }
    }
    return "";
  }

  deleteSelectedGroups(): void {
    let userConfirmation = confirm(RenewalsConstants.DELETE_CONFIRMATION_MSG);
    if (userConfirmation) {
      let deletedGroups = this.renewalBatchWrapper.renewalBatchDetails.filter(
        (group) => group["included"]
      );
      if (deletedGroups && deletedGroups.length > 0) {
        this.hasDeletedGroupsInBatch = true;
        var groupIds: string[] = [];
        var grouNbrList: string[] = [];

        for (let index = 0; index < deletedGroups.length; index++) {
          if (deletedGroups[index]["id"])
            groupIds.push(deletedGroups[index]["id"]);

          if (deletedGroups[index]["submissionStatus"]) {
            grouNbrList.push(deletedGroups[index]["groupNumber"]);
          }
        }
        if (groupIds && groupIds.length > 0) {
          this.constructDeleteInfoAndinvokeDelete(groupIds, grouNbrList, RenewalsConstants.BATCH);
        }
        this.renewalBatchWrapper.renewalBatchDetails =
          this.renewalBatchWrapper.renewalBatchDetails.filter(
            (group) => !group["included"]
          );
        this.searchResults = this.searchResults.filter((group) => !group['included']);
        if (this.renewalBatchWrapper.renewalBatchDetails.length < 1) {
          this.checkAllDetails = false;
          this.disableBulkAdj = true;
        }
      }
    }
  }

  private invokeRatesCalAndCheckGuardRails(rowData: any): void {
    this.cmplnFldCodes = [];
    let proposedPlan = rowData.data.proposedPlans;
    for (let plan of proposedPlan) {
      if (this.isFIBulkAdj) {
        this.uwAdjService.getFiAdjusments(
          plan,
          rowData["quoteDetail"]
        );
      }
      else {
        this.uwAdjService.getAbfExperienceAdjusments(
          plan,
          rowData["quoteDetail"],
          rowData["calculatedCompRates"]);
      }
      if (
        plan.failedGuardRails &&
        plan.failedGuardRails.includes("factors.abfFactors.excessOfLimit")
      )
        this.cmplnFldCodes.push(plan.contractCode);
    }
  }

  disableDeleteOption() {
    for (let grp of this.renewalBatchWrapper.renewalBatchDetails) {
      if (
        grp["included"] &&
        grp["batchID"] &&
        grp["currentQuoteStatusBatchID"] &&
        grp["batchID"] != grp["currentQuoteStatusBatchID"] &&
        grp["submissionStatus"] &&
        grp["submissionStatus"] != this.groupSubmissionStatus.FAILED
      ) {
        return true;
      }
    }
  }
  isEmptyValue(value) {
    return value === null || value === undefined || value === "";
  }


  deleteGrpsFromBulkTab() {
    let userConfirmation = confirm(RenewalsConstants.DELETE_CONFIRMATION_MSG);
    if (userConfirmation) {
      let deletedGroupNbrList = this.bulkViewTableData
        .filter((group) => group["included"])
        .map((ele) => ele["groupNumber"]);
      let groupsWithId = this.bulkViewTableData.filter(
        (e) => deletedGroupNbrList.includes(e["groupNumber"])
      );
      var groupIds: string[] = [];

      for (let grp of groupsWithId) {
        if (grp["renewalBatchDetailID"]) {
          groupIds.push(grp["renewalBatchDetailID"]);
        }
      }
      if (groupIds && groupIds.length > 0) {
        this.hasDeletedGroupsInBulk = true;
        this.constructDeleteInfoAndinvokeDelete(groupIds, deletedGroupNbrList, RenewalsConstants.BULK);
      }
      this.bulkViewTableData = this.bulkViewTableData.filter(
        (grp) => !grp["included"]
      );
      this.resetTotalRateActionData();
      if (this.bulkViewTableData.length < 1) {
        this.checkAllBulkDetails = false;
        this.disableBulkAdj = true;
      } else {
        this.calculateRateActionGrndTotal(this.bulkViewTableData);
        this.calculateTotalRateActionPercent();
      }
    }
  }

  private constructDeleteInfoAndinvokeDelete(
    groupIds: string[],
    grouNbrList: string[],
    tab: string
  ) {
    let deleteInfo = {
      batchID: this.renewalBatchWrapper.renewalBatch.id,
      renewalGroupIdList: groupIds,
      renewalGroupNbrList: grouNbrList,
    };
    this.setLoaderVisibility(true);
    this.renewalsService.deleteRenewalGroups(deleteInfo).subscribe(
      (res) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(true, AlertType.SUCCESS, RenewalsConstants.DELETE_SUCCESS_MSG);
        this.hideAlertVisibility();
        this.renewalBatchWrapper.renewalBatch[RenewalsConstants.HAS_DELETED_GROUPS] = true;
      },
      (error) => {
        this.setLoaderVisibility(false);
        console.error("Error while deleting grps ", error);
      }
    );
  }

  resetTotalRateActionData() {
    this.uwTotalRateActionPercent = this.expTotalRateActionPercent = "";
    this.currentPlanTotPrem =
      this.renewalPlanTotPrem =
      this.adjustedPlanTotprem =
      0;
  }

  overRideDetailsChanged(
    event: any,
    groupNumber: any,
    oldValue: any,
    category: string
  ) {
    if (
      StringUtils.isEqual("SSL", category) ||
      (StringUtils.isEqual("REFUND_PCT", category) &&
        ValidationService.validateRefundPCTDecimalNumber(
          event.target.value ? parseFloat(event.target.value) : 0
        )) ||
      (StringUtils.isEqual("ASL", category) &&
        ValidationService.validateASLDecimalNumber(
          event.target.value ? parseFloat(event.target.value) : 0
        ))
    ) {
      if (!this.overRideDetails) this.overRideDetails = {};
      if (category) {
        var newValue = event.target.value
          ? parseFloat(event.target.value)
          : null;
        if (newValue != oldValue) {
          if (!this.overRideDetails[category]) {
            this.overRideDetails[category] = {};
            this.overRideDetails[category][groupNumber] = {
              oldValue: oldValue,
              newValue: newValue,
            };
          } else {
            let grpNbrDetails = this.overRideDetails[category][groupNumber];
            if (!grpNbrDetails) {
              this.overRideDetails[category][groupNumber] = {
                oldValue: oldValue,
                newValue: newValue,
              };
            } else {
              this.overRideDetails[category][groupNumber]["newValue"] =
                newValue;
            }
          }
        } else if (
          newValue == oldValue &&
          this.overRideDetails[category] &&
          this.overRideDetails[category][groupNumber]
        ) {
          delete this.overRideDetails[category][groupNumber];
        }
      }
      if (
        StringUtils.isEqual("REFUND_PCT", category) &&
        this.overRideDetails["aslErrors"] &&
        this.overRideDetails["refundPctErrors"].length > 0
      ) {
        this.overRideDetails["refundPctErrors"] = this.overRideDetails[
          "refundPctErrors"
        ].filter((refundPctError) => refundPctError.groupNumber != groupNumber);
      } else if (
        StringUtils.isEqual("ASL", category) &&
        this.overRideDetails["aslErrors"] &&
        this.overRideDetails["aslErrors"].length > 0
      ) {
        this.overRideDetails["aslErrors"] = this.overRideDetails[
          "aslErrors"
        ].filter((aslError) => aslError.groupNumber != groupNumber);
      }
    } else {
      if (!this.overRideDetails) {
        this.overRideDetails = {
          aslErrors: [],
          refundPctErrors: [],
        };
      } else {
        if (this.overRideDetails && !this.overRideDetails.aslErrors) {
          this.overRideDetails["aslErrors"] = [];
        }
        if (this.overRideDetails && !this.overRideDetails.refundPctErrors) {
          this.overRideDetails["refundPctErrors"] = [];
        }
      }
      this.overRideDetails = RenewalsUtil.updateOverRideDetails(
        this.renewalBatchWrapper,
        category,
        groupNumber,
        this.overRideDetails
      );
    }
  }

  updateOverRidesToBatchDetails(renewalBatchWrapper: any) {
    if (this.overRideDetails) {
      if (this.overRideDetails.SSL) {
        //Updating SSL overrides
        renewalBatchWrapper.renewalBatchDetails.forEach((batchDetail) => {
          var grpNbr = batchDetail["groupNumber"];
          if (this.overRideDetails.SSL[grpNbr]) {
            batchDetail["sslLevel"] =
              this.overRideDetails.SSL[grpNbr]["newValue"];
          }
        });
      }

      if (this.overRideDetails.REFUND_PCT) {
        //Updating REFUND_PCT overrides
        renewalBatchWrapper.renewalBatchDetails.forEach((batchDetail) => {
          var grpNbr = batchDetail["groupNumber"];
          if (this.overRideDetails.REFUND_PCT[grpNbr]) {
            batchDetail["refundPct"] =
              this.overRideDetails.REFUND_PCT[grpNbr]["newValue"];
          }
        });
      }

      if (this.overRideDetails.ASL) {
        //Updating ASL overrides
        renewalBatchWrapper.renewalBatchDetails.forEach((batchDetail) => {
          var grpNbr = batchDetail["groupNumber"];
          if (this.overRideDetails.ASL[grpNbr]) {
            batchDetail["aslLevel"] =
              this.overRideDetails.ASL[grpNbr]["newValue"];
          }
        });
      }
    }
  }

  getExhibitDownloadLink() {
    this.setAlertVisibility(false);
    let selectedBulkviewData = this.bulkViewTableData.filter(
      (renewal) => renewal["included"]
    );
    let data = {};
    data["opportunityList"] = [];
    selectedBulkviewData.forEach((viewData) => {
      let opportunity = {
        opportunityID: viewData["opportunityID"],
        quoteHeaderID: viewData["quoteHeaderID"],
        fundingType: viewData["fundingType"],
        lob: viewData["lob"],
        ratingTransID: viewData["ratingTransID"],
        accountName: viewData["groupName"],
        metaTransId: viewData["metaTransID"],
        batchOrigin: this.renewalBatchWrapper?.renewalBatch?.batchOrigin,
        quoteOrigin: viewData['quoteOrigin'] ? viewData['quoteOrigin'] : this.renewalBatchWrapper?.renewalBatch?.quoteOrigin,
      };
      data["opportunityList"].push(opportunity);
    });
    this.showExhibitsZipDownloadLink = false;
    this.renewalsService
      .fetchBulkExhibitsZipDownloadLink(
        data,
        this.renewalBatchWrapper.renewalBatch["id"]
      )
      .subscribe(
        (response) => {
          if (
            response &&
            response["description"] &&
            !response["description"].startsWith("No Data found")
          ) {
            var eventSource = this.commonService.listenForStream(
              response["description"]
            );
            this.listenRenewalExhibitFetchLinkEvents(
              eventSource,
              response["description"]
            );
          } else {
            this.setAlertVisibility(
              true,
              AlertType.WARNING,
              "No Data found to Fetch Exhibits Download Link",
              false
            );
          }
        },
        (error) => {
          this.setLoaderVisibility(false);
          this.setAlertVisibility(
            true,
            AlertType.WARNING,
            error.exceptions[0].message
          );
        }
      );
  }

  private listenRenewalExhibitFetchLinkEvents(
    eventSource: any,
    sseProcessID: string
  ) {
    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = "progress-bar-warning";
    eventSource.addEventListener(
      "BATCH_FETCH_EXHIBITS_UPDATEUI_TASK",
      (event: any) => {
        if (event && event.data) {
          var data = JSON.parse(event.data);
          var payload = data.payload;
          if (
            !this.receivedCurrentExhibitEvents.includes(
              data.processId + payload.groupNumber
            )
          ) {
            this.receivedCurrentExhibitEvents.push(
              data.processId + payload.groupNumber
            );
            this.progressStyle = "";
            var percent = Math.floor(
              (this.receivedCurrentExhibitEvents.length /
                payload.totalExhibits) *
              100
            );
            this.progressPercent = percent;
            this.progressMessage =
              "Processed " +
              payload.groupNumber +
              ". [" +
              this.progressPercent +
              "% complete.]";
          }
        }
      }
    );
    eventSource.addEventListener(
      "BATCH_FETCH_EXHIBITS_PROCESS_COMPLETION_TRIGGER",
      (event: any) => {
        eventSource.close();
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          this.renewalBatchWrapper.renewalBatch["recentExhibitsFetchStatus"] =
            status;
          this.processExhibitFetchUpdates(
            payload.recentExhibitsFetchStatus,
            sseProcessID
          );
          this.receivedCurrentExhibitEvents = [];
          setTimeout(() => {
            this.showProgress = false;
          }, this.commonService.getProgressBarTimeOut());
        }
      }
    );
  }

  private processExhibitFetchUpdates(status: string, sseProcessID: string) {
    //Excluded 'Zipping Failed' status
    if (status && ["Success", "Partial", "Failed"].includes(status)) {
      this.currentExhibitLinkProcessId = sseProcessID;
      this.progressStyle = "progress-bar-success";
      this.progressPercent = 100;
      this.progressMessage =
        "Exhibits Link Fetch Process completed successfully.";
      this.showExhibitsZipDownloadLink = true;
      this.setAlertVisibility(
        true,
        AlertType.SUCCESS,
        "Exhibits Link Fetch Process completed successfully."
      );
    } else {
      console.error("Received Exhibit Status :" + status);
      this.progressPercent = 90;
      this.progressStyle = "progress-bar-danger";
      this.progressMessage = "Received Exhibit Status :" + status;
      this.showExhibitsZipDownloadLink = false;
      this.setAlertVisibility(true, AlertType.ERROR, status);
      this.hideProgressBar();
    }
  }

  downloadPrintExhibitsZip(isOnloadFlow: boolean) {
    this.setAlertVisibility(false);
    if (
      !this.currentExhibitLinkProcessId ||
      null == this.currentExhibitLinkProcessId
    ) {
      this.showExhibitsZipDownloadLink = false;
      this.setAlertVisibility(
        true,
        AlertType.WARNING,
        "Recent Exhibits Fetch Process Failed. Please retry, if desired.",
        false
      );
      return;
    }
    let fileName =
      this.renewalBatchWrapper.renewalBatch["id"] +
      "-" +
      this.currentExhibitLinkProcessId +
      ".zip";
    this.commonService
      .fileDownload(CreateBatchSuppHealthComponent.BATCH_EXHIBITS_BASE_PATH, fileName)
      .subscribe(
        (response) => {
          if (isOnloadFlow) {
            this.showExhibitsZipDownloadLink = true;
            return;
          }
          if (response) {
            fileName =
              this.renewalBatchWrapper.renewalBatch["id"] +
              "-" +
              this.datepipe.transform(new Date(), "yyyy-MM-dd'T'hh_mm_ssa") +
              ".zip";
            this.peService.createAndDownloadBlobFile(response, fileName);
            this.setAlertVisibility(
              true,
              AlertType.SUCCESS,
              "Exhibits Zip Downloaded Successfully."
            );
          } else {
            this.setAlertVisibility(
              true,
              AlertType.ERROR,
              "Exhibits Zip Download Failed."
            );
          }
        },
        (errorResponse) => {
          if (
            errorResponse &&
            errorResponse.error &&
            errorResponse.error instanceof Blob
          ) {
            const reader: FileReader = new FileReader();
            reader.readAsText(errorResponse.error);
            reader.onload = (e) => {
              var errMsg = JSON.parse(
                JSON.parse(JSON.stringify(e.target.result))
              );
              if (
                errMsg &&
                errMsg.exceptions &&
                errMsg.exceptions.exceptions[0] &&
                errMsg.exceptions.exceptions[0].type ==
                "java.io.FileNotFoundException"
              ) {
                this.showExhibitsZipDownloadLink = false;
                this.setAlertVisibility(
                  true,
                  AlertType.WARNING,
                  "The bulk download exhibit link has expired. Please re-create, if desired.",
                  false
                );
                return;
              }
              if (isOnloadFlow) {
                this.showExhibitsZipDownloadLink = true;
                return;
              }
            };
          } else if (isOnloadFlow) {
            this.showExhibitsZipDownloadLink = true;
            return;
          }
          if (!isOnloadFlow) {
            this.setAlertVisibility(
              true,
              AlertType.ERROR,
              "Exhibits Zip Download Failed."
            );
          }
        });
  }
  onUwNoteToSaleEvent(event, bulkdata, i) {
    this.isDirty = true;
    let index = this.bulkViewTableData.findIndex(x => x == bulkdata);
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value)
      this.bulkViewTableData[index].uwNotesToSales = ASCII;
    }
    else {
      this.bulkViewTableData[index].uwNotesToSales = "";
    }
  }
  onUwNoteToSelfEvent(event, bulkdata, i) {
    this.isDirty = true;
    let index = this.bulkViewTableData.findIndex(x => x == bulkdata);
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value)
      this.bulkViewTableData[index].uwComments = ASCII;
    }
    else {
      this.bulkViewTableData[index].uwComments = "";
    }
  }
  onLobSelected =() => {
    this.isSearchChanged = true;
    this.onDataSourceSelected();
    this.hideFundingType();
    if (Object.keys(this.renewalBatchWrapper.renewalBatch).length > 0) {
      const isNonMedical = StringUtils.isEqual(this.selectedLOB, CommonConstants.Vision) || StringUtils.isEqual(this.selectedLOB, CommonConstants.Dental) || StringUtils.isEqual(this.selectedLOB, CommonConstants.SuppHealth)
      this.batchSearchForm.controls.fundingTypes.setValue(isNonMedical ? CommonConstants.FI : CommonConstants.ABF);
      if (!isNonMedical) {
        this.isFIselectedDropdown = CommonConstants.ABF;
      }
    }
    if (StringUtils.isEqual(this.selectedLOB, 'Vision') || StringUtils.isEqual(this.selectedLOB, 'Dental') || StringUtils.isEqual(this.selectedLOB, 'Supp Health')) {
      this.batchSearchForm.controls.fundingTypes.setValue(CommonConstants.FI);
      const marketSegments = this.batchSearchForm.value.marketSegments;
      if (Array.isArray(marketSegments) && marketSegments.includes(CommonConstants.LG) && marketSegments.includes(CommonConstants.SG)) {
        this.batchSearchForm.patchValue({
          marketSegments: [CommonConstants.LG]
        });
      }
      else if (Array.isArray(marketSegments) && marketSegments.includes(CommonConstants.SG)) {
        this.batchSearchForm.patchValue({
          marketSegments: []
        });
      }
      this.getDisableMkgSegment(true);
    } else {
      this.batchSearchForm.controls.fundingTypes.setValue(CommonConstants.ABF);
      this.isFIselectedDropdown = CommonConstants.ABF;
      this.getDisableMkgSegment(false);
    }
  }
  onDataSourceSelected = () => {
    this.isSearchChanged = true;
    this.selectedDatasourceForBatchScreenSearchOverlay = this.availableDatasourcesForBatchScreenSearchOverlay[0];
    this.batchSearchForm.controls.dataSource.patchValue(this.selectedDatasourceForBatchScreenSearchOverlay);
 }


  /**
   * Determines if column is supp health rate action adjustment
   * @param columnName
   */
  isRateActionAdjColumn(columnName) {
    return CommonConstants.SUPP_HEALTH_RA_ADJ_COLUMNS.includes(columnName);
  }

  isRateActionAdjColumnProperty(columnProperty) {
    return CommonConstants.SUPP_HEALTH_RA_ADJ_COLUMN_PROPERTIES.includes(columnProperty);
  }

  /**
   * Check if a rate action adj column is clicked based on column name given
   * @param columnName
   */
  isRateActionAdjColumnClicked(columnName) {
    if (this.isRateActionAdjColumn(columnName)) {
      return this.rateActionAdjustmentIconClicked;
    } else {
      return false;
    }
  }

  getSuppHealthProductAdjustments(columnName, bulkData) {
    switch (columnName) {
      case CommonConstants.ACCIDENT_COLUMN:
      case CommonConstants.SUGGESTED_INCR_ACCIDENT_COLUMN:
        return bulkData.accidentAdjustments;
      case CommonConstants.HOSPITAL_COLUMN:
      case CommonConstants.SUGGESTED_INCR_HOSP_INDEM_COLUMN:
        return bulkData.hospitalIndemnityAdjustments;
      case CommonConstants.CRITICAL_ILLNESS_COLUMN:
      case CommonConstants.SUGGESTED_INCR_CRIT_ILLNESS_COLUMN:
        return bulkData.criticalIllnessAdjustments;
      default:
        return [];
    }
  }

  /**
   * Format plan name by removing their supp health prefixes
   * @param bulkData
   * @param planName
   */
  truncatePlanName(planName) {
    let truncatedPlanName = planName.toUpperCase();
    truncatedPlanName = truncatedPlanName.replace(CommonConstants.PRODUCT_TYPE_ACCIDENT, CommonConstants.EMPTY_STRING);
    truncatedPlanName = truncatedPlanName.replace(CommonConstants.PRODUCT_TYPE_CRITICAL_ILLNESS, CommonConstants.EMPTY_STRING);
    truncatedPlanName = truncatedPlanName.replace(CommonConstants.PRODUCT_TYPE_HOSPITAL_IDEMNITY, CommonConstants.EMPTY_STRING);
    return truncatedPlanName;
  }

  isSuggestedIncreaseColumn(columnName) {
    return CommonConstants.SUGGESTED_INCR_COLUMNS.includes(columnName);
  }

  calculateProposedIncreaseAfterFetch(bulkAdjustments: any[]) {
    bulkAdjustments.forEach(bulkAdjustment => {
      bulkAdjustment.suppHealthOverallProposedIncrease = this.calculateProposedIncrease(bulkAdjustment);
    })
  }

  calculateSuggestedIncreaseAfterFetch(bulkAdjustments: any[]) {
    bulkAdjustments.forEach(bulkAdjustment => {
      bulkAdjustment.suppHealthOverallSuggestedIncrease = this.calculateSuggestedIncrease(bulkAdjustment);
    })
  }

  loadProductAdjustments(bulkAdjustments: any[]) {
    bulkAdjustments?.forEach(bulkAdjustment => {
      let productAdjustments = [];
      if (bulkAdjustment.accidentAdjustments) {
        bulkAdjustment.accidentAdjustments.forEach(accidentAdjustment => {
          if (accidentAdjustment.proposedRateActionAdjustment !== 1) {
            productAdjustments.push(this.loadProductAdjustment(accidentAdjustment, "accidentAdjustments"));
          }
        })
      }

      if (bulkAdjustment.criticalIllnessAdjustments) {
        bulkAdjustment.criticalIllnessAdjustments.forEach(criticalIllnessAdjustment => {
          if (criticalIllnessAdjustment.proposedRateActionAdjustment !== 1) {
            productAdjustments.push(this.loadProductAdjustment(criticalIllnessAdjustment, "criticalIllnessAdjustments"));
          }
        })
      }

      if (bulkAdjustment.hospitalIndemnityAdjustments) {
        bulkAdjustment.hospitalIndemnityAdjustments.forEach(hospitalIndemnityAdjustment => {
          if (hospitalIndemnityAdjustment.proposedRateActionAdjustment !== 1) {
            productAdjustments.push(this.loadProductAdjustment(hospitalIndemnityAdjustment, "hospitalIndemnityAdjustments"));
          }
        })
        bulkAdjustment.productAdjustments = productAdjustments;
      }

      bulkAdjustment.multiRate = this.groupHasMultiRatesPlan(bulkAdjustment);
    })
  }

  loadProductAdjustment(adjustment, key: string) {
    return {
      adjustmentType: key,
      planName: adjustment.planName,
      ratingPlanID: adjustment.ratingPlanID,
      suggestedRateActionAdjustment: adjustment.suggestedRateActionAdjustment,
      uwAdjustmentFactor: adjustment.proposedRateActionAdjustment
    }
  }

  calculateProposedIncrease(bulkData) {
    const currentPlansTotal = this.calculateCurrentPlansTotal(bulkData);
    const adjustedPlansTotal = this.calculateAdjustedPlansTotal(bulkData, false);

    return this.roundFourDecimals(CalculatorUtils.calculateTotalIncreasePercentage(currentPlansTotal, adjustedPlansTotal));
  }

  calculateSuggestedIncrease(bulkData) {
    const currentPlansTotal = this.calculateCurrentPlansTotal(bulkData);
    const adjustedPlansTotal = this.calculateAdjustedPlansTotal(bulkData, true);

    return this.roundFourDecimals(CalculatorUtils.calculateTotalIncreasePercentage(currentPlansTotal, adjustedPlansTotal));
  }

  calculateCurrentPlansTotal(bulkData: any): number {
    let currentPlansTotal = 0;
    bulkData.currentPlans?.forEach(currentPlan => {
      if (currentPlan.rateInfo.TIERED && currentPlan.rateInfo.TIERED.TOT.ACTIVE) {
        currentPlansTotal += this.getCurrentRatesSingle(currentPlan, bulkData, 1);
      } else if (currentPlan.rateInfo.AGETIERED && currentPlan.rateInfo.AGETIERED.TOT.ACTIVE) {
        currentPlansTotal += this.getCurrentRatesAgeBanded(currentPlan, bulkData, 1);
      }
    });
    return currentPlansTotal;
  }

  getCurrentRatesSingle(currentPlan: any, bulkData: any, adjustment: any): number {
    const proposedPlan = bulkData.data.proposedPlans.find(proposedPlan => proposedPlan.contractCode === currentPlan.contractCode);
    const mcpPlan = bulkData?.suppHealthPremiumComparison?.planComparison.find(mcp => mcp.quoteRatingPlanID === proposedPlan?.ratingPlanID);

    if (StringUtils.isEqualIgnoreCase(mcpPlan.isCurrentPlanRatesEdited, CommonConstants.YES)) {
      return mcpPlan?.currentRates.ratesT1 * (Number(adjustment));
    }
    return (currentPlan.rateInfo.TIERED.TOT.ACTIVE?.EE?.rate ?? 0) * (Number(adjustment));
  }

  getCurrentRatesAgeBanded(currentPlan: any, bulkData: any, adjustment: any): number {
    const proposedPlan = bulkData.data.proposedPlans.find(proposedPlan => proposedPlan.contractCode === currentPlan.contractCode);
    const mcpPlan = bulkData?.suppHealthPremiumComparison?.planComparison.find(mcp => mcp.quoteRatingPlanID === proposedPlan?.ratingPlanID);

    let ageTieredTotalCurrent = 0;
    let ageBands = StringUtils.isEqualIgnoreCase(mcpPlan.isCurrentPlanRatesEdited, CommonConstants.YES) ?
      mcpPlan?.ageBandCurrentRates : currentPlan.rateInfo.AGETIERED.TOT.ACTIVE;

    for (const key in ageBands) {
      ageTieredTotalCurrent += ((ageBands[key].ratesT1 ? ageBands[key]?.ratesT1 ?? 0 : ageBands[key].rate?.EE?.rate ?? 0) * (Number(adjustment)));
    }
    return ageTieredTotalCurrent;
  }

  /**
   *
   * @param bulkData
   * @param useSuggestedIncrease use true for using suggested increase factors in calculation
   */
  calculateAdjustedPlansTotal(bulkData, useSuggestedIncrease: boolean): number {
    const currentPlans = bulkData.currentPlans;
    const rateAdjustmentKey = useSuggestedIncrease ? 'suggestedRateActionAdjustment' : 'proposedRateActionAdjustment';
    let adjustedPlansTotal = 0;
    currentPlans?.forEach(currentPlan => {
      const adjustedPlan = this.findProductByPropertyInAdjustments('planName', currentPlan.planName, bulkData);
      let adjustment: number = adjustedPlan && !isNaN(adjustedPlan[rateAdjustmentKey])
        ? Number(adjustedPlan[rateAdjustmentKey]) : 1;

      if (currentPlan.rateInfo.TIERED && currentPlan.rateInfo.TIERED.TOT.ACTIVE) {
        adjustedPlansTotal += this.getCurrentRatesSingle(currentPlan, bulkData, adjustment);
      } else if (currentPlan.rateInfo.AGETIERED && currentPlan.rateInfo.AGETIERED.TOT.ACTIVE) {
        adjustedPlansTotal += this.getCurrentRatesAgeBanded(currentPlan, bulkData, adjustment);
      }
    });
    return adjustedPlansTotal;
  }

  updateAllAdjustmentsToProposedIncrease(rowData, value) {
    const factorValue = CalculatorUtils.convertPercentageToFactor(value.replace('%', ''))
    const accidentAdjustments = rowData.accidentAdjustments;
    const hospitalIndemnityAdjustments = rowData.hospitalIndemnityAdjustments;
    const criticalIllnessAdjustments = rowData.criticalIllnessAdjustments;

    this.updateAdjustmentsToProposedIncrease(accidentAdjustments, factorValue);
    this.updateAdjustmentsToProposedIncrease(hospitalIndemnityAdjustments, factorValue);
    this.updateAdjustmentsToProposedIncrease(criticalIllnessAdjustments, factorValue);

    accidentAdjustments.forEach((accidentAdjustment: {}) => {
      this.updateProductAdjustmentsSet(rowData, "accidentAdjustments", accidentAdjustment);
    })

    hospitalIndemnityAdjustments.forEach((hospitalIndemnityAdjustment: {}) => {
      this.updateProductAdjustmentsSet(rowData, "hospitalIndemnityAdjustments", hospitalIndemnityAdjustment);
    })

    criticalIllnessAdjustments.forEach((criticalIllnessAdjustment: {}) => {
      this.updateProductAdjustmentsSet(rowData, "criticalIllnessAdjustments", criticalIllnessAdjustment);
    })
  }

  updateAdjustmentsToProposedIncrease(adjustments: any[], value) {
    adjustments.forEach((adjustment) => {
      adjustment.proposedRateActionAdjustment = value;
    })
  }

  roundFourDecimals(value) {
    if (value) {
      return Math.round(value * 10000) / 10000
    }
    return 0;
  }

  protected readonly CalculatorUtils = CalculatorUtils;

  getGuaranteeEffEndDt(startDateString, rateGuaranteeMonths) {
    if (startDateString && rateGuaranteeMonths) {
      const rateGuaranteeEndDt = new Date(startDateString);
      // Add number of month to start date
      rateGuaranteeEndDt.setMonth(rateGuaranteeEndDt.getMonth() + rateGuaranteeMonths);
      // substract 1 day form rateGuaranteeEndDt
      const rateGuaranteeEndDtObj = new Date(rateGuaranteeEndDt);
      rateGuaranteeEndDtObj.setDate(rateGuaranteeEndDtObj.getDate() - 1)
      const formattedEndDate = rateGuaranteeEndDtObj.toISOString().split('T')[0]; // convert date to mm/dd/yyyy
      return 'Guarantee End Dt: '.concat(this.datepipe.transform(formattedEndDate, "MM/dd/yyyy"));
    }
  }

  omit_special_char(event) {
    let key;
    key = event.charCode;
    return ((key > 64 && key < 91) || (key > 96 && key < 123) || key == 8 || key == 32 || (key >= 48 && key <= 57));
  }
  pasteEmitter(event) {
    this.grpNameAndNumberValidation();
    this.batchSearchForm.patchValue({
      groupNumber: event.target?.value,
    });
    event.preventDefault();
  }

  /**
   * Checks if group has a multiRate plan
   * @param bulkAdjDetail
   */
  groupHasMultiRatesPlan(bulkAdjDetail) {
    let checkMultiRate = false;
    if (bulkAdjDetail?.data?.proposedPlans) {
      checkMultiRate = bulkAdjDetail.data?.proposedPlans.some(plan => StringUtils.isEqual(plan.multiRate, CommonConstants.YES));
    }
    return checkMultiRate;
  }

  protected readonly RenewalsUtil = RenewalsUtil;
  protected readonly CommonConstants = CommonConstants;
  protected readonly Object = Object;
  protected readonly NonChangeableRenewalStatuses = NonChangeableRenewalStatuses;

  isRenewalRestoreEnabled() {
    return this.commonService.hasRenewalRestoreRole();
  }
  restoreGroups(page) {
    let restoreInfo = {
      batchID: this.renewalBatchWrapper.renewalBatch.id,
    };
    this.renewalsService.restoreRenewalGroups(restoreInfo).subscribe(
      (res: any) => {
        this.setLoaderVisibility(false);
        if (res && res?.exceptions) {
          let errorMsg = res?.description;
          this.setAlertVisibility(true, AlertType.WARNING, errorMsg);
        } else {
          this.setAlertVisibility(true, AlertType.SUCCESS, RenewalsConstants.RESTORE_SUCCESS_MSG);
        }
        this.setActiveTab(page, true);
      },
      (error) => {
        this.setLoaderVisibility(false);
        console.error("Error while restoring grps ", error);
      })
  }

  downloadBatch() {
    let data = {};
    if(!this.enabledBatchGroupDownload) {
    if (this.isSearchChanged) {
      this.searchClicked();
    } else {
      this.isFIRewewalSearch = StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.FI) && StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Medical);
      this.batchSearch = this.getBatchSearchRequest(this.isFIRewewalSearch);
      if (this.batchSearch.marketSegments.length < 1) {
        this.batchSearch.marketSegments = ['LG', 'SG'];
      }
    }
    if (this.batchSearch.marketSegments.length === 0) {
      this.batchSearch.marketSegments = this.batchSearchForm.value.marketSegments
    }
  } else {
    data['batchID'] = this.renewalBatchWrapper.renewalBatch['id'] ? this.renewalBatchWrapper.renewalBatch['id'] : '';
  }
    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = "progress-bar-warning";
    this.setLoaderVisibility(true);
    this.renewalsService
      .downloadRenewalBatchDetails(this.enabledBatchGroupDownload ? data : this.batchSearch)
      .subscribe((res) => {
        if (res && res?.processId) {
          this.setLoaderVisibility(false);
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = "progress-bar-warning";
          var source = this.commonService.listenForStream(res?.processId);
          source.addEventListener("PE_GENERATION_STATUS", (event: any) => {
            this.progressStyle = "";
            let eventData = JSON.parse(event.data);
            var percent = Math.floor(
              (eventData.currentEvent / eventData.totalEvents) * 100
            );
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
          });
          source.addEventListener("SEND_EXHIBIT_TO_UI", (message: any) => {
            this.handleFileDownload(source, message);
          });
          source.addEventListener("PE_GENERATION_STATUS_COMPLETE", (message: any) => {
            this.handleFileDownload(source, message);
          });
          source.addEventListener("FAILED", (message: any) => {
            source.close();
            console.error("Received event : ", JSON.stringify(message.data));
            this.progressPercent = 90;
            this.progressStyle = "progress-bar-danger";
            this.progressMessage = "Error in getting response for download";
            this.hideProgressBar();
          });
          source.addEventListener("error", (message: any) => {
            source.close();
            console.error(
              "Received error event, with ready status :" + source.readyState
            );
            if (source.readyState == EventSource.CLOSED) {
              this.progressPercent = 90;
              this.progressStyle = "progress-bar-danger";
              this.progressMessage =
                "Failed to fetch progress because of communication failure";
              this.hideProgressBar();
            }
          });
        }
      },
        (error) => {
          this.setLoaderVisibility(false);
          this.progressPercent = 90;
          this.progressStyle = 'progress-bar-danger';
          this.progressMessage = 'Error in getting response for download';
          this.hideProgressBar();
        }
      );
  }

  handleFileDownload(source, message) {
    source.close();
    let eventData = JSON.parse(message.data);
    this.progressStyle = "progress-bar-success";
    this.progressPercent = 100;
    this.progressMessage = eventData.message;
    if (this.progressMessage.includes(CommonConstants.EMPTY_RECORD)) {
      this.progressPercent = 90;
      this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
      this.progressMessage = CommonConstants.NO_RESULTS_FOUND;
      setTimeout(() => {
        this.showProgress = false;
      }, this.commonService.getProgressBarTimeOut());
    }
    else {
      CommonService.exportFilename =
        (eventData.metaData.fileName
          ? eventData.metaData.fileName
          : "sheet");
      let fileName = this.commonService.getExportFilename();
      let contentData = eventData.payload.contentData;
      const arrayBuffer =
        this.peService.base64ToArrayBuffer(contentData);
      this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
      setTimeout(() => {
        this.showProgress = false;
      }, this.commonService.getProgressBarTimeOut());
    }
  }

  checkQuoteStatus(groupDetail) {
    return !groupDetail.opportunityID || !groupDetail.quoteHeaderID || groupDetail?.submissionStatus != this.groupSubmissionStatus.SUCCESS || !groupDetail?.quoteRenewalStatus || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_RISK_SCORE || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_P2A_DATA || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.RECEIVED || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.PROCESSING;
  }

  checkBulkQuoteStatus(groupNumber: string) {
    let groupDetail = this.renewalBatchWrapper?.renewalBatchDetails.find((batchDetail) => batchDetail["groupNumber"] === groupNumber);
    return this.checkQuoteStatus(groupDetail);
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
    }, this.commonService.getProgressBarTimeOut());
  }

  checkFirstCharNotToBeSpecialChar(event) {
    ValidationUtils.doNotAllowFirstCharacterToBeSpecialCharacter(event)
  }

  hideAlertVisibility() {
    setTimeout(() => {
      this.setAlertVisibility(false);
    }, this.commonService.getProgressBarTimeOut());
  }
  
  getUploadFileName(event: any) {
    this.groupNumbersFile = event;
    this.batchSearchForm.controls.fundingTypes.setValue('ALL');
    this.batchSearchForm.controls.groupNumber.setValue(null);
    this.setAlertVisibility(true, AlertType.SUCCESS, this.groupNumbersFile.name + ' uploaded successfully. Click on "Search" to find the groups.',
      undefined,
      true
    );
    this.hideAlertVisibility();
  }
    showSendToOppBasedOnConfig() {
    return (
      this.lobFundingTypeMapForSendToOpp &&
      Object.keys(this.lobFundingTypeMapForSendToOpp).includes(this.selectedLOB) &&
      this.lobFundingTypeMapForSendToOpp[this.selectedLOB.toString()].includes(this.isFIselectedDropdown ? this.isFIselectedDropdown : this.fundTypeFromDetails)
    );
  }
}