import { QuoteRenewalStatus } from "../../../../shared/models/renewal-batch-details";
import { RenewalsConstants } from "../../../renewals-constants";
import { CalculatorUtils } from "../../../../shared/utils/calculator-utils";

export class CreateBatchUtilSuppHealth {

  public static constructUWRequest(quoteData: any, action: string, isFIBulkAdj: boolean): {} {

    let uwRequestData = {};
    uwRequestData["opportunity"] = {
      opportunityID: quoteData["opportunityID"],
      quoteHeaderID: quoteData["quoteHeaderID"],
      accountName: quoteData["groupName"],
      fundingType: quoteData["fundingType"],
      lob: quoteData["lob"],
      ratingTransID: quoteData["ratingTransID"],
      insertedTimeStamp: quoteData["insertedTimeStamp"],
      metaTransId: quoteData["metaTransID"],
      quotingType: quoteData["quotingType"],
    };
    uwRequestData["uwAdjustment"] = {
      abfRateActionAdjustment: {},
      outputTier: quoteData["data"]
        ? quoteData["data"]["medicalAlternateTier"]
        : null,
      suppHealth: true,
      status: quoteData["status"],
      action: action.toUpperCase(),
      included: quoteData.included,
      uwNotesToSales: quoteData["uwNotesToSales"],
      uwComments: quoteData["uwComments"],
      tierRatioCalculationType:
        quoteData["data"] && quoteData["data"]["factors"]
          ? quoteData["data"]["factors"]["tierRatioCalculationType"]
          : null,
      suppHealthOverallProposedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['suppHealthOverallProposedIncrease'])),
      suppHealthOverallSuggestedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['suppHealthOverallSuggestedIncrease'])),
      productAdjustments: quoteData['productAdjustments'] ?? []
    };
    if (!isFIBulkAdj) {
      uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]["componentRateAction"] = {
        asoAdminFee: quoteData["asoAdminFee"],
        sslPremium: quoteData["sslPremium"],
        aslPremium: quoteData["aslPremium"],
        terminalLiability: quoteData["terminalLiability"],
        maxPaidClaim: quoteData["maxPaidClaim"],
      }
    }
    else {
      if (quoteData['isFlatRateApplied'] != null && quoteData['isFlatRateApplied'] != undefined) {
        uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]['isFlatRateApplied'] = quoteData['isFlatRateApplied'];
      }
      else {
        uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]['isFlatRateApplied'] = false;
      }
    }
    uwRequestData["quoteReason"] = "REAL";
    if (quoteData["renewalWHAPercent"]) {
      uwRequestData["uwAdjustment"]["abfRateActionAdjustment"][
        "renewalWHAPercent"
      ] = quoteData["renewalWHAPercent"];
    }

    if (quoteData["suppHealthReleaseProcessDetails"]) {
      let releaseProcessDetails = {};
      releaseProcessDetails["suppHealthReleaseProcessDetails"] = quoteData["suppHealthReleaseProcessDetails"];
      if (quoteData["releaseStatus"])
        releaseProcessDetails["releaseStatus"] = quoteData["releaseStatus"];

      uwRequestData["releaseProcessDetails"] = releaseProcessDetails;
    }
    return uwRequestData;
  }

  public static setOnLoadErrorMsgOnRevert(rowData: any, bulkAdjData): any {
    let foundGrp = bulkAdjData.find(
      (grp) =>
        grp["ratingTransID"] == rowData["ratingTransID"] &&
        rowData["adjustedRateActionPercent"] ==
        grp["adjustedRateActionPercent"] &&
        rowData["asoAdminFee"] == grp["asoAdminFee"] &&
        rowData["sslPremium"] == grp["sslPremium"] &&
        rowData["aslPremium"] == grp["aslPremium"] &&
        rowData["terminalLiability"] == grp["terminalLiability"] &&
        rowData["maxPaidClaim"] == grp["maxPaidClaim"]
    );
    return foundGrp;
  }

  public static setCalculatedRateActionPercent(
    rowData: any,
    calculatedCompRates: any
  ): any {

    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "asoAdminFee"
    ] = calculatedCompRates["asoAdminCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "sslPremium"
    ] = calculatedCompRates["sslPremCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "aslPremium"
    ] = calculatedCompRates["aslPremCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "terminalLiability"
    ] = calculatedCompRates["terminalLiabilityCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "maxPaidClaim"
    ] = calculatedCompRates["maxPaidClaimCompPercent"];
    rowData["asoAdminFee"] = calculatedCompRates["asoAdminCompPercent"];
    rowData["sslPremium"] = calculatedCompRates["sslPremCompPercent"];
    rowData["aslPremium"] = calculatedCompRates["aslPremCompPercent"];
    rowData["terminalLiability"] =
      calculatedCompRates["terminalLiabilityCompPercent"];
    rowData["maxPaidClaim"] = calculatedCompRates["maxPaidClaimCompPercent"];

    return rowData;
  }

  public static checkExpFactorsPresent(rowData): boolean {
    return (
      rowData["data"] &&
      rowData["data"]["factors"] &&
      rowData["data"]["factors"]["experienceFactors"] &&
      rowData["data"]["factors"]["experienceFactors"][
      "experienceAdjustmentFactor"
      ] &&
      rowData["data"]["factors"]["experienceFactors"]["currentComponentTotal"][
      "totalPremium"
      ] &&
      rowData["data"]["factors"]["experienceFactors"]["expComponentTotal"][
      "totalPremium"
      ]
    );
  }

  public static constructBulkAdjDataForComparsion(bulkAdjdetails: [], bulkAdjData): [] {
    bulkAdjdetails.forEach((data) => {
      if (
        data["status"] &&
        data["status"] != QuoteRenewalStatus.AWAITING_P2A_DATA &&
        data["status"] != QuoteRenewalStatus.AWAITING_RISK_SCORE &&
        data["status"] != QuoteRenewalStatus.PROCESSING &&
        data["status"] != QuoteRenewalStatus.RECEIVED &&
        data["status"] != QuoteRenewalStatus.FAIL
      ) {
        bulkAdjData.push({
          opportunityID: data["opportunityID"],
          quoteHeaderID: data["quoteHeaderID"],
          ratingTransID: data["ratingTransID"],
          adjustedRateActionPercent: data["adjustedRateActionPercent"],
          renewalWHAPercent: data["renewalWHAPercent"],
          asoAdminFee: data["asoAdminFee"],
          sslPremium: data["sslPremium"],
          aslPremium: data["aslPremium"],
          terminalLiability: data["terminalLiability"],
          maxPaidClaim: data["maxPaidClaim"],
          status: data["status"],
          groupNumber: data["groupNumber"],
          quotingType: data["quotingType"],
          errorMsg: data["errorMsg"],
          uwNotesToSales: data["uwNotesToSales"],
          uwComments: data["uwComments"],
          suppHealthOverallProposedIncrease: data["suppHealthOverallProposedIncrease"],
          suppHealthOverallSuggestedIncrease: data["suppHealthOverallSuggestedIncrease"],
          accidentAdjustments: data["accidentAdjustments"] ? JSON.parse(JSON.stringify(data["accidentAdjustments"])) : [],
          hospitalIndemnityAdjustments: data["hospitalIndemnityAdjustments"] ? JSON.parse(JSON.stringify(data["hospitalIndemnityAdjustments"])) : [],
          criticalIllnessAdjustments: data["criticalIllnessAdjustments"] ? JSON.parse(JSON.stringify(data["criticalIllnessAdjustments"])) : [],
          productAdjustments: data["productAdjustments"]
        });
      }
    });
    return bulkAdjData;
  }

  public static setorRevertGuardRailMsg(rowData: any, cmplnFldCodes, bulkAdjData) {
    let foundGrp = CreateBatchUtilSuppHealth.setOnLoadErrorMsgOnRevert(rowData, bulkAdjData);
    if (foundGrp) {
      rowData["errorMsg"] = foundGrp["errorMsg"];
      return;
    } else if (cmplnFldCodes.length > 0) {
      rowData["errorMsg"] = RenewalsConstants.COMPLIANCE_CHECK_MSG.concat(
        cmplnFldCodes.join(" ,")
      );
      cmplnFldCodes = [];
    } else {
      rowData["errorMsg"] = "";
    }
    return cmplnFldCodes;
  }
}
