import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateBatchSuppHealthComponent } from './create-batch-supp-health.component';

describe('CreateBatchSuppHealthComponent', () => {
  let component: CreateBatchSuppHealthComponent;
  let fixture: ComponentFixture<CreateBatchSuppHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateBatchSuppHealthComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateBatchSuppHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
