import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { RenewalsConstants } from '../../renewals-constants';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { QuoteRenewalStatus, QuoteSubmissionStatus } from 'src/app/shared/models/renewal-batch-details';
import { CommonConstants } from '../../../shared/constants/common.constants';
import { StringUtils } from '../../../shared/utils/string-utils';
import { CommonUtil } from '../../../shared/utils/common-util';
import { CommonService } from 'src/app/shared/services';

@Component({
  selector: 'app-quote-options-tab',
  templateUrl: './quote-options-tab.component.html',
  styleUrl: './quote-options-tab.component.css',
  providers: [NgbModalConfig, NgbModal],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QuoteOptionsTabComponent implements OnInit, OnChanges {
  @ViewChild('renwalParentDiv') parentDiv: ElementRef;
  @Input() quoteOptionsData: any;
  quoteOptTableCols: any;
  quoteTableColsforMedical = RenewalsConstants.QUOTE_OPTIONS_COLUMNS;
  quoteTableColsforVisDen = RenewalsConstants.QUOTE_OPTIONS_COLUMNS_FOR_VISION_DENTAL;
  @Output() openQuoteClicked = new EventEmitter<any>();
  @Output() commissionDataChanged = new EventEmitter<any>();

  first = 0;

  commissionOptions = CommonConstants.COMMISSION_OPTIONS;
  headerCommValue: string = '';
  headerCommType: string = '';
  headerLGCommValue: string = '';
  headerLGCommType: string = '';
  showCommissionOverrideDialog: boolean = false;
  pendingHeaderCommValue: string = '';
  pendingHeaderCommType: string = '';
  pendingHeaderLGCommValue: string = '';
  pendingHeaderLGCommType: string = '';

  constructor(
    private commonService: CommonService,
    private cdRef: ChangeDetectorRef
 ){}

  // Commission validation pattern - same as in create-batch component
  public commissionFormatValidationPattern = '^[0-9]*.?[0-9]*$';

  ngOnInit() {
    this.getQuoteOptionTableCols();
     this.initializeCommissionProperties();
  }

  getQuoteOptionTableCols() {
    if (this.quoteOptionsData.length > 0 && StringUtils.isEqual(this.quoteOptionsData[0].lob, CommonConstants.Medical)) {
      this.quoteOptTableCols = this.quoteTableColsforMedical;
      this.checkAllValidation();
    } else if (
      this.quoteOptionsData.length > 0 &&
      (StringUtils.isEqual(this.quoteOptionsData[0].lob, CommonConstants.Vision) || StringUtils.isEqual(this.quoteOptionsData[0].lob, CommonConstants.Dental))
    ) {
      this.quoteOptTableCols = this.quoteTableColsforVisDen;
      this.checkAllValidationForVisDen();
    }
  }

   initializeCommissionProperties() {
    // Initialize commission properties for ABF funding options in SG and LG alternates for ACA batches
    if (this.quoteOptionsData.length > 0 && this.quoteOptionsData[0]?.fundingType === 'ACA') {
      this.quoteOptionsData.forEach((quoteOption) => {
        quoteOption.alternateQuotes?.forEach((alternateQuote) => {
          if ((alternateQuote.marketSegment === 'SG' || alternateQuote.marketSegment === 'LG') &&
              alternateQuote.fundingOptions?.ABF) {
            // Ensure isSelected property exists
            if (!alternateQuote.fundingOptions.ABF.hasOwnProperty('isSelected')) {
              alternateQuote.fundingOptions.ABF.isSelected = false;
            }
            // Initialize commission properties
            if (!alternateQuote.fundingOptions.ABF.hasOwnProperty('commissionValue')) {
              alternateQuote.fundingOptions.ABF.commissionValue = this.commonService.getDefaultCommissionValue();;
            }
            if (!alternateQuote.fundingOptions.ABF.hasOwnProperty('commissionType')) {
              alternateQuote.fundingOptions.ABF.commissionType = this.commonService.getDefaultCommissionType();;
            }
          }
        });
      });
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['quoteOptionsData'] && !changes['quoteOptionsData'].firstChange) {
      this.getQuoteOptionTableCols();
      this.initializeCommissionProperties();
    }
  }

  verifyCheckAllFundingType(column) {
    this.quoteOptionsData.forEach((quoteOption) => {
      quoteOption.alternateQuotes?.forEach((alternateQuote) => {
        if (alternateQuote.marketSegment === column.marketSegment) {
          if (alternateQuote.fundingOptions?.[column.header]) {
            alternateQuote.fundingOptions[column.header].isSelected = column.isSelected;
          }
        }
      });
    });
    this.cdRef.markForCheck();
  }

  checkAllValidation() {
    const updateSubHeader = (marketSegment: string, fundingType: string, field: string, property: 'isSelected' | 'isEnabled') => {
      const isValid = this.quoteOptionsData.every((quoteOption) => {
        return quoteOption.alternateQuotes?.some((alternateQuote) => {
          return alternateQuote.marketSegment === marketSegment && alternateQuote.fundingOptions?.[fundingType]?.[property] === true;
        });
      });

      const subHeader = this.quoteOptTableCols.subHeaders.find((header) => header.field === field);
      if (subHeader) {
        subHeader[property] = isValid;
      }
    };

    // Update 'included' property
    updateSubHeader('SG', 'ABF', 'SGABF', 'isSelected');
    updateSubHeader('SG', 'ACA', 'SGACA', 'isSelected');
    updateSubHeader('SG', 'MEWA', 'SGMEWA', 'isSelected');
    updateSubHeader('LG', 'FI', 'LGFI', 'isSelected');
    updateSubHeader('LG', 'ABF', 'LGABF', 'isSelected');

    // Update 'enabled' property
    updateSubHeader('SG', 'ABF', 'SGABF', 'isEnabled');
    updateSubHeader('SG', 'ACA', 'SGACA', 'isEnabled');
    updateSubHeader('SG', 'MEWA', 'SGMEWA', 'isEnabled');
    updateSubHeader('LG', 'FI', 'LGFI', 'isEnabled');
    updateSubHeader('LG', 'ABF', 'LGABF', 'isEnabled');
    this.cdRef.markForCheck();
  }

  checkAllValidationForVisDen() {
    const updateSubHeader = (marketSegment: string, fundingType: string, field: string, property: 'isSelected' | 'isEnabled') => {
      const isValid = this.quoteOptionsData.every((quoteOption) => {
        return quoteOption.alternateQuotes?.some((alternateQuote) => {
          return alternateQuote.marketSegment === marketSegment && alternateQuote.fundingOptions?.[fundingType]?.[property] === true;
        });
      });

      const subHeader = this.quoteOptTableCols.subHeaders.find((header) => header.field === field);
      if (subHeader) {
        subHeader[property] = isValid;
      }
    };

    // Update 'included' property
    updateSubHeader('SG', 'FI', 'SGFI', 'isSelected');
    updateSubHeader('LG', 'FI', 'LGFI', 'isSelected');

    // Update 'enabled' property
    updateSubHeader('SG', 'FI', 'SGFI', 'isEnabled');
    updateSubHeader('LG', 'FI', 'LGFI', 'isEnabled');
    this.cdRef.markForCheck();
  }

  checkQuoteLinkStatus(groupDetail) {
    return (
      !groupDetail.opportunityID ||
      !groupDetail.quoteHeaderID ||
      groupDetail?.submissionStatus != this.groupSubmissionStatus.SUCCESS ||
      !groupDetail?.quoteRenewalStatus ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_RISK_SCORE ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_P2A_DATA ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.RECEIVED ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.PROCESSING
    );
  }

  checkAltQuoteLinkStatus(groupDetail: any, fundingOption: any) {
    const isSubmissionInProgress = this.isAltQuoteSubmissionInProgress(fundingOption);
    return (
      !groupDetail.opportunityID ||
      !groupDetail.quoteHeaderID ||
      (!isSubmissionInProgress && !fundingOption?.ratingTransID) ||
      fundingOption?.submissionStatus != this.groupSubmissionStatus.SUCCESS ||
      !fundingOption?.quoteRenewalStatus ||
      fundingOption?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_RISK_SCORE ||
      fundingOption?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_P2A_DATA ||
      fundingOption?.quoteRenewalStatus === this.quoteRenewalStatus.RECEIVED ||
      fundingOption?.quoteRenewalStatus === this.quoteRenewalStatus.PROCESSING ||
      fundingOption?.isSubmittedToGateWay === false
    );
  }

  public get groupSubmissionStatus(): typeof QuoteSubmissionStatus {
    return QuoteSubmissionStatus;
  }

  public get quoteRenewalStatus(): typeof QuoteRenewalStatus {
    return QuoteRenewalStatus;
  }

  getObjectKeys(obj: any): string[] {
    return Object.keys(obj);
  }

  private isAltQuoteSubmissionInProgress(fundingOption: any): boolean {
    return fundingOption?.isSubmitted === true && fundingOption?.isSSEQuoteStatusReceived === false;
  }

  private shouldShowAltQuoteBars(fundingOption: any): boolean {
    const isSubmissionInProgress = this.isAltQuoteSubmissionInProgress(fundingOption);
    const hasFailed = fundingOption?.submissionStatus?.startsWith(CommonConstants.Failed) || !!fundingOption?.submissionErrors;
    const hasBeenSubmitted = fundingOption?.isSubmitted === true;
    const gatewayReachedButNoTransID = fundingOption?.isSubmittedToGateWay === true && !fundingOption?.ratingTransID;
    return isSubmissionInProgress || ((hasBeenSubmitted && !gatewayReachedButNoTransID) || hasFailed);
  }

  getReleaseProcessTabletclass(altQuote, fundingOptionKey, tabletEventNode, status) {
    if (!this.shouldShowAltQuoteBars(altQuote?.fundingOptions[fundingOptionKey])) {
      return '';
    }
    if (altQuote?.fundingOptions[fundingOptionKey][tabletEventNode]) {
      return 'renewalAltSubmissionStatusSuccess';
    } else if (
      altQuote?.fundingOptions[fundingOptionKey]?.submissionStatus?.startsWith('Failed') &&
      status === altQuote?.fundingOptions[fundingOptionKey]?.submissionFailCheckPoint
    ) {
      return 'renewalGrpsbmsnFailed';
    } else {
      return '';
    }
  }

  getErrorTabletToolTip(altQuote, fundingOptionKey, status) {
    if (
      altQuote?.fundingOptions[fundingOptionKey]?.submissionStatus?.startsWith('Failed') &&
      status === altQuote?.fundingOptions[fundingOptionKey]?.submissionFailCheckPoint &&
      altQuote?.fundingOptions[fundingOptionKey]?.submissionErrors
    ) {
      return altQuote?.fundingOptions[fundingOptionKey]?.submissionErrors;
    } else {
      return '';
    }
  }

  openAltQuote(groupDetail: any, fundingOption: any, fundingType: string, marketSegment: string) {
    groupDetail = JSON.parse(JSON.stringify(groupDetail));
    groupDetail['quoteHeaderID'] = fundingOption.quoteHeaderID ? fundingOption.quoteHeaderID : groupDetail['quoteHeaderID'];
    groupDetail['quotingType'] = StringUtils.isEqualIgnoreCase(CommonConstants.ACA, fundingType) ? CommonConstants.ACA : StringUtils.isEqualIgnoreCase(CommonConstants.MEWA, fundingType) ? CommonConstants.MEWA : groupDetail['quotingType'];
    groupDetail['fundingType'] = fundingType && StringUtils.isEqualIgnoreCase(CommonConstants.ACA, fundingType) ? CommonConstants.FI : fundingType && StringUtils.isEqualIgnoreCase(CommonConstants.MEWA, fundingType) ? CommonConstants.ASO : fundingType;
    groupDetail['marketSegment'] = marketSegment ? marketSegment : groupDetail['marketSegment'];
    groupDetail['ratingTransID'] = fundingOption.ratingTransID ? fundingOption.ratingTransID : groupDetail['ratingTransID'];
    this.openQuoteClicked.emit(groupDetail);
  }

  checkIsLOBVisionOrDental() {
    const isVisionLob = StringUtils.isEqual(this.quoteOptionsData[0]?.lob, CommonConstants.Vision);
    const isDentalLob = StringUtils.isEqual(this.quoteOptionsData[0]?.lob, CommonConstants.Dental);

    return isVisionLob || isDentalLob;
  }

  hasAlternateQuoteWithMarketSegmentLG(groupDetail: any): boolean {
    return groupDetail?.alternateQuotes?.some((alternateQuote: any) => alternateQuote?.marketSegment === 'LG');
  }

  hasAlternateQuoteWithMarketSegmentSG(groupDetail: any): boolean {
    return groupDetail?.alternateQuotes?.some((alternateQuote: any) => alternateQuote?.marketSegment === 'SG');
  }

  getRenewalStatus(altQuote, fundingOptionKey) {
    const fundingOption = altQuote?.fundingOptions?.[fundingOptionKey];
    if (!this.shouldShowAltQuoteBars(fundingOption)) {
      return '';
    }
    return fundingOption?.['quoteRenewalStatus'] ?? '';
  }

  getRenewalTabletclass(altQuote, fundingOptionKey) {
    const fundingOption = altQuote?.fundingOptions?.[fundingOptionKey];
    if (!this.shouldShowAltQuoteBars(fundingOption)) {
      return 'renewalStatusCircleBlank';
    }
    const status = fundingOption?.['quoteRenewalStatus'];
    if (status) {
      if (quoteRenewalSuccessStatus.includes(status)) {
        return 'renewalStatusCircleSuccess';
      } else if (status === 'Failed') {
        return 'renewalStatusCircleFailed';
      } else if (quoteRenewalOtherStatus.includes(status)) {
        return 'renewalStatusCircleOther';
      } else {
        return 'renewalStatusCircleBlank';
      }
    } else {
      return 'renewalStatusCircleBlank';
    }

  }

  getRenewalStatusTabletTooltip(altQuote, fundingOptionKey) {
    const fundingOptionDetails = altQuote?.fundingOptions[fundingOptionKey];
    if (!this.shouldShowAltQuoteBars(fundingOptionDetails)) {
      return '';
    }

    const batchId = this.quoteOptionsData[0].batchID;
    let tooltipText = ``;
    if(fundingOptionDetails['quoteErrors']?.errorList?.length) {
      fundingOptionDetails['quoteErrors']?.errorList?.forEach((error) => {
        tooltipText = tooltipText + `${error.msg}\n`;
      });
    }

    if(fundingOptionDetails['quoteRenewalStatus'] && fundingOptionDetails['currentQuoteStatusBatchID'] && batchId !== fundingOptionDetails['currentQuoteStatusBatchID']) {
      tooltipText = tooltipText + `Quote status is from a different batch submission ${fundingOptionDetails['currentQuoteStatusBatchID']},
        Batch Name: ${fundingOptionDetails['currentQuoteStatusBatchName']}`;
    }

    return tooltipText
  }

  getRenewalQuoteStatusTooltipClass(altQuote, fundingOptionKey) {
    const status = altQuote.fundingOptions?.[fundingOptionKey]?.['quoteRenewalStatus'];
    if (status === 'Failed') {
      return 'tooltipfontErrMsg';
    } else {
      return 'tooltipfontInfoMsg';
    }
  }

  checkAltQuoteLinkStatusForVisDen(groupDetail: any, fundingOption: any) {
    const isSubmissionInProgress = this.isAltQuoteSubmissionInProgress(fundingOption);
    return (!groupDetail.opportunityID ||
      !groupDetail.quoteHeaderID ||
      (!isSubmissionInProgress && !fundingOption?.ratingTransID) ||
      fundingOption?.submissionStatus != this.groupSubmissionStatus.SUCCESS || fundingOption?.isSubmittedToGateWay === false || fundingOption?.isSSEQuoteStatusReceived == false);
  }

  onHeaderCommissionValueBlur() {
    if (!this.headerCommValue || this.headerCommValue.trim() === '') {
      return;
    }

    // Store pending value and show confirmation dialog
    this.pendingHeaderCommValue = this.headerCommValue;
    this.showCommissionOverrideDialog = true;
    this.cdRef.markForCheck();
  }

  onHeaderCommissionTypeChange() {
    if (!this.headerCommType) {
      return;
    }

    // Store pending type and show confirmation dialog
    this.pendingHeaderCommType = this.headerCommType;
    this.showCommissionOverrideDialog = true;
    this.cdRef.markForCheck();
  }

  checkIfGroupsHaveDifferentCommissions(field: 'value' | 'type'): boolean {
    const abfSelectedGroups = this.quoteOptionsData.filter((quoteOption) => {
      return quoteOption.alternateQuotes?.some((alternateQuote) => {
        return alternateQuote.marketSegment === 'SG' &&
               alternateQuote.fundingOptions?.ABF?.isEnabled &&
               alternateQuote.fundingOptions?.ABF?.isSelected;
      });
    });

    if (abfSelectedGroups.length === 0) {
      return false;
    }

    const commissionValues = new Set<string>();
    abfSelectedGroups.forEach((quoteOption) => {
      quoteOption.alternateQuotes?.forEach((alternateQuote) => {
        if (alternateQuote.marketSegment === 'SG' && alternateQuote.fundingOptions?.ABF) {
          const value = field === 'value'
            ? alternateQuote.fundingOptions.ABF.commissionValue
            : alternateQuote.fundingOptions.ABF.commissionType;
          if (value) {
            commissionValues.add(value);
          }
        }
      });
    });

    return commissionValues.size > 1;
  }

  applyHeaderCommissionToAllGroups() {
    this.quoteOptionsData.forEach((quoteOption) => {
      quoteOption.alternateQuotes?.forEach((alternateQuote) => {
        if (alternateQuote.marketSegment === 'SG' &&
            alternateQuote.fundingOptions?.ABF?.isEnabled &&
            alternateQuote.fundingOptions?.ABF?.isSelected) {

          if (this.pendingHeaderCommValue) {
            alternateQuote.fundingOptions.ABF.commissionValue = this.pendingHeaderCommValue;
          }
          if (this.pendingHeaderCommType) {
            alternateQuote.fundingOptions.ABF.commissionType = this.pendingHeaderCommType;
          }
        }
      });
    });

    this.headerCommValue = '';
    this.headerCommType = '';
    this.pendingHeaderCommValue = '';
    this.pendingHeaderCommType = '';
    this.cdRef.markForCheck();
  }

  onHeaderLGCommissionValueBlur() {
    if (!this.headerLGCommValue || this.headerLGCommValue.trim() === '') {
      return;
    }

    // Store pending value and show confirmation dialog
    this.pendingHeaderLGCommValue = this.headerLGCommValue;
    this.showCommissionOverrideDialog = true;
    this.cdRef.markForCheck();
  }

  onHeaderLGCommissionTypeChange() {
    if (!this.headerLGCommType) {
      return;
    }

    // Store pending type and show confirmation dialog
    this.pendingHeaderLGCommType = this.headerLGCommType;
    this.showCommissionOverrideDialog = true;
    this.cdRef.markForCheck();
  }

  checkIfLGGroupsHaveDifferentCommissions(field: 'value' | 'type'): boolean {
    const abfSelectedGroups = this.quoteOptionsData.filter((quoteOption) => {
      return quoteOption.alternateQuotes?.some((alternateQuote) => {
        return alternateQuote.marketSegment === 'LG' &&
               alternateQuote.fundingOptions?.ABF?.isEnabled &&
               alternateQuote.fundingOptions?.ABF?.isSelected;
      });
    });

    if (abfSelectedGroups.length === 0) {
      return false;
    }

    const commissionValues = new Set<string>();
    abfSelectedGroups.forEach((quoteOption) => {
      quoteOption.alternateQuotes?.forEach((alternateQuote) => {
        if (alternateQuote.marketSegment === 'LG' && alternateQuote.fundingOptions?.ABF) {
          const value = field === 'value'
            ? alternateQuote.fundingOptions.ABF.commissionValue
            : alternateQuote.fundingOptions.ABF.commissionType;
          if (value) {
            commissionValues.add(value);
          }
        }
      });
    });

    return commissionValues.size > 1;
  }

  applyHeaderLGCommissionToAllGroups() {
    this.quoteOptionsData.forEach((quoteOption) => {
      quoteOption.alternateQuotes?.forEach((alternateQuote) => {
        if (alternateQuote.marketSegment === 'LG' &&
            alternateQuote.fundingOptions?.ABF?.isEnabled &&
            alternateQuote.fundingOptions?.ABF?.isSelected) {
          if (this.pendingHeaderLGCommValue) {
            alternateQuote.fundingOptions.ABF.commissionValue = this.pendingHeaderLGCommValue;
          }
          if (this.pendingHeaderLGCommType) {
            alternateQuote.fundingOptions.ABF.commissionType = this.pendingHeaderLGCommType;
          }
        }
      });
    });

    this.headerLGCommValue = '';
    this.headerLGCommType = '';
    this.pendingHeaderLGCommValue = '';
    this.pendingHeaderLGCommType = '';
    this.cdRef.markForCheck();
  }

  closeCommissionOverrideDialog() {
    this.showCommissionOverrideDialog = false;
    // Clear all pending values when dialog is closed without confirmation
    this.pendingHeaderCommValue = '';
    this.pendingHeaderCommType = '';
    this.pendingHeaderLGCommValue = '';
    this.pendingHeaderLGCommType = '';
    this.cdRef.markForCheck();
  }

  confirmCommissionOverride() {
    // Apply SG commission values if they exist
    if (this.pendingHeaderCommValue || this.pendingHeaderCommType) {
      this.applyHeaderCommissionToAllGroups();
    }

    // Apply LG commission values if they exist
    if (this.pendingHeaderLGCommValue || this.pendingHeaderLGCommType) {
      this.applyHeaderLGCommissionToAllGroups();
    }

    // Emit the updated data to parent component
    this.commissionDataChanged.emit(this.quoteOptionsData);

    this.showCommissionOverrideDialog = false;
    this.cdRef.markForCheck();
  }

  isValidCommissionValue(event) {
    return CommonUtil.isNumberWithGivenDecimalPlaces(event, 2);
  }
}

const quoteRenewalSuccessStatus = [
  QuoteRenewalStatus.PENDING, QuoteRenewalStatus.RELEASED,
  QuoteRenewalStatus.DECLINED, QuoteRenewalStatus.MODIFIED, QuoteRenewalStatus.PRESOLD,
  QuoteRenewalStatus.SOLD, QuoteRenewalStatus.SOLD_MODIFIED, QuoteRenewalStatus.LOST,
  QuoteRenewalStatus.MISSING_INFO, QuoteRenewalStatus.IN_ANALYSIS, QuoteRenewalStatus.TRANSFER,
  QuoteRenewalStatus.PENDING_EXHIBIT, QuoteRenewalStatus.CLOSE
];

const quoteRenewalOtherStatus = [
  QuoteRenewalStatus.PROCESSING, QuoteRenewalStatus.RECEIVED
];
