import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteOptionsTabComponent } from './quote-options-tab.component';

describe('QuoteOptionsTabComponent', () => {
  let component: QuoteOptionsTabComponent;
  let fixture: ComponentFixture<QuoteOptionsTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuoteOptionsTabComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuoteOptionsTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
