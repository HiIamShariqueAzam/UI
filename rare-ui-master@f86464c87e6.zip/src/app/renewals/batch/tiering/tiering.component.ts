import { Component, Input, Output, EventEmitter } from '@angular/core';
import { RenewalBatchWrapper } from 'src/app/shared/models/renewal-batch-details';
import { CommonService } from 'src/app/shared/services';
import { RenewalsService } from '../../services/renewals.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: 'app-tiering',
  templateUrl: './tiering.component.html',
  styleUrls: ['./tiering.component.css'],
  standalone: false
})
export class TieringComponent {

  date: Date | null = null;
  @Input() renewalBatchWrapper: RenewalBatchWrapper = {
    renewalBatch: {},
    renewalBatchDetails: [],
    failedGrpNbrsInSearch: []
  };
  tieredData: any;
  isMewa: boolean = false;
  isTierDataAvailable: boolean = true;
  @Input() tierLoader: boolean = false;
  @Output() snapMonthYearChanged = new EventEmitter<string>();
  @Output() downloadBotData = new EventEmitter<string>();
  selectedSnapMonthYear: string | null = null;

  constructor(
    private commonService: CommonService,
    public renewalsService: RenewalsService
  ) { }

  ngOnInit() {
    //this.renewalBatchWrapper.renewalBatchDetails[0]?.renewalDate
    let data = {
      "lob": this.renewalBatchWrapper.renewalBatchDetails[0]?.lob,
      "renewalDate": this.renewalBatchWrapper.renewalBatchDetails[0]?.renewalDate,
      "fundingType": this.renewalBatchWrapper.renewalBatchDetails[0]?.fundingType,
      "marketSegment": this.renewalBatchWrapper.renewalBatchDetails[0]?.marketSegment,
      "state": this.renewalBatchWrapper.renewalBatchDetails[0]?.state,
    };
       
    this.isMewa = this.renewalBatchWrapper.renewalBatchDetails[0]?.fundingType === CommonConstants.MEWA;
    this.tierLoader = true;
    this.renewalsService.getTieringInput(data).subscribe(data => {
      this.tierLoader = false;
      if (data) {
        this.isTierDataAvailable = true;
        this.tieredData = data;
        
        // Always initialize to ensure all properties exist for ngModel binding 
        this.initTieringInputDefaults();
        
        this.selectedSnapMonthYear = this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput?.selectedSnapMonthYear 
          ? this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput?.selectedSnapMonthYear 
          : this.tieredData?.snapMonthYearsFromDataMart[0];
        
        if(this.selectedSnapMonthYear){
          this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput.selectedSnapMonthYear = this.selectedSnapMonthYear;
        }
        this.snapMonthYearChanged.emit(this.selectedSnapMonthYear);
      } else {
        this.isTierDataAvailable = false;
        console.warn('No tiering data received. Please check your input or try again later.');
      }
    }, (error) => {
      this.tierLoader = false;
      this.isTierDataAvailable = false;
      console.error("error getTieringInput ", error);
    });
  }

  onSnapMonthYearChange(event: any) {
    // Update the selected value in renewalBatchWrapper
    if (this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput) {
      this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput.selectedSnapMonthYear = event.value;
    }
    this.selectedSnapMonthYear = event.value;
    this.snapMonthYearChanged.emit(event.value);
  }

  get snapMonthYearDropdownOptions() {
    // Format options for p-dropdown using snapMonthYearsFromDataMart in YYYYMM format
    return this.tieredData?.snapMonthYearsFromDataMart.map((m: string) => {
      // m is in "YYYYMM" format
      const year = m.substring(0, 4);
      const month = m.substring(4, 6);
      return {
        label: `${month}/${year}`,
        value: m
      };
    });
  }

  initTieringInputDefaults() {
    // Ensure tieringInfo structure exists
    if (!this.renewalBatchWrapper.renewalBatch.tieringInfo) {
      this.renewalBatchWrapper.renewalBatch.tieringInfo = {};
    }
    if (!this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput) {
      this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput = {};
    }
    
    const ti = this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput;
    
    // Initialize common fields
    ti.manualPremiumAdj = ti.manualPremiumAdj ?? '';
    ti.selectedSnapMonthYear = ti.selectedSnapMonthYear ?? '';
    
    // Initialize formulaInput
    if (!ti.formulaInput) {
      ti.formulaInput = {};
    }
    ti.formulaInput.overallRateIncrease = ti.formulaInput.overallRateIncrease ?? '';
    ti.formulaInput.minIncrease = ti.formulaInput.minIncrease ?? '';
    ti.formulaInput.maxIncrease = ti.formulaInput.maxIncrease ?? '';
    
    // Initialize based on funding type
    if (this.isMewa) {
      if (!ti.riskFactorInput) {
        ti.riskFactorInput = {};
      }
      ti.riskFactorInput.averageBlockRiskFactor = ti.riskFactorInput.averageBlockRiskFactor ?? '';
      ti.riskFactorInput.maxRiskFactor = ti.riskFactorInput.maxRiskFactor ?? '';
      ti.riskFactorInput.minRiskFactor = ti.riskFactorInput.minRiskFactor ?? '';
      ti.riskFactorInput.maxAnnualRiskFactorIncrease = ti.riskFactorInput.maxAnnualRiskFactorIncrease ?? '';
      ti.riskFactorInput.maxAnnualRiskFactorDecrease = ti.riskFactorInput.maxAnnualRiskFactorDecrease ?? '';
      ti.riskFactorInput.prorateRFIncIndicator = ti.riskFactorInput.prorateRFIncIndicator ?? '';
      
      // Remove uwTieredInput for MEWA
      if (ti.uwTieredInput) {
        delete ti.uwTieredInput;
      }
    } else {
      // Initialize uwTieredInput for FI
      if (!ti.uwTieredInput) {
        ti.uwTieredInput = {};
      }
      ti.uwTieredInput.overallRateIncrease = ti.uwTieredInput.overallRateIncrease ?? '';
      ti.uwTieredInput.minIncrease = ti.uwTieredInput.minIncrease ?? '';
      ti.uwTieredInput.maxIncrease = ti.uwTieredInput.maxIncrease ?? '';
      
      // Remove riskFactorInput for FI
      if (ti.riskFactorInput) {
        delete ti.riskFactorInput;
      }
    }
  }

  downloadPrintExhibits(){
    this.downloadBotData.emit();
  }

  formatPercentage(value: number): number {
    if (!value && value !== 0) return 0;
    const percentage = value * 100;
    return parseFloat(percentage.toFixed(2));
  }
}
