import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TieringComponent } from './tiering.component';

describe('TieringComponent', () => {
  let component: TieringComponent;
  let fixture: ComponentFixture<TieringComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TieringComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TieringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
