import { DatePipe, formatCurrency, formatPercent, getCurrencySymbol } from '@angular/common';
import { BehaviorSubject, Observable } from 'rxjs';
import {
  AfterViewChecked,
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  Inject,
  LOCALE_ID,
  NgZone,
  OnDestroy,
  OnInit,
  ViewChild,
  inject
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { MultiSelect } from 'primeng/multiselect';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { UWAdjustmentChangeSetService } from 'src/app/quotes/uw-adjustment/medical/uw-adjust-changeset.service';
import { UnderwriterAdjustmentService } from 'src/app/quotes/uw-adjustment/medical/uw-adjustment.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { BatchSaveGroup, BatchSearchForm, DownloadForm } from 'src/app/shared/models/batchDetails';
import { AuthenticationService, CommonService, PrintExhibitService } from 'src/app/shared/services';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';
import { CalculatorUtils } from 'src/app/shared/utils/calculator-utils';
import { ValidationUtils } from 'src/app/shared/utils/validation-utils';
import {
  AlertType,
  BATCH_ORIGIN,
  BatchQuoteStatusEmitStatus,
  NonChangeableRenewalStatuses,
  BatchSSEProcess,
  ConvertBulkStatus,
  QUOTE_ORIGIN,
  QuoteRenewalStatus,
  QuoteSubmissionStatus,
  ReleaseSteps,
  RenewalBatchDetails,
  RenewalBatchWrapper,
  SubmissionStatus
} from '../../../shared/models/renewal-batch-details';
import { RenewalsConstants } from '../../renewals-constants';
import { RenewalsUtil } from '../../renewals-util';
import { RenewalsService } from '../../services/renewals.service';
import { CreateBatchUtil } from './create-batch-util';
import * as XLSX from 'xlsx';
import { ExpGrandTotalCalcService } from 'src/app/quotes/uw-adjustment/medical/exp-grand-total-calc.service';
import { MedicalPremiumComparison } from 'src/app/shared/models';
import { ConfirmationService } from 'primeng/api';
import { Menu } from 'primeng/menu';

@Component({
  selector: 'app-create-batch',
  templateUrl: './create-batch.component.html',
  styleUrls: ['../shared-batch-styles.css', './create-batch.component.css','./styles/create-batch-file-upload.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateBatchComponent implements OnInit, AfterViewInit, AfterViewChecked, OnDestroy {
  @ViewChild('renwalParentDiv') parentDiv: ElementRef;
  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  @ViewChild('batchDownload') batchDownload: MultiSelect;
  
  disbleBulkAdj: boolean = true;
  hideFooterBtn: boolean = false;
  showFileError: boolean = false;
  isTieringInputEnabled: boolean = false;
  disableTieringInput: boolean = false;
  file: File;
  isFundingTypeChangeByUser = false;
  batchSearchForm: FormGroup<BatchSearchForm>;
  batchSaveGroup: FormGroup<BatchSaveGroup>;
  batchSaveGroupSubmitted: boolean = false;
  formSubmitted: boolean = false;
  checkAllDetails: boolean = false;
  checkAllDetailsOverlay: boolean = false;
  checkAllBulkDetails: boolean = false;
  checkAllAutoRunDetails: boolean = false;
  lob_FT = [];
  multiselectEle: any;
  availableStates: any[];
  showLoader: boolean = false;
  displayALTMrktSubmissionWarn: boolean = false;
  batchStatus: string;
  availableLOBs: any[];
  availableMarketSegs: any[];
  searchResults: any[] = [];
  availableFTs: any[] = CommonConstants.FUNDING_TYPE_LIST;
  availableMBS: any[] = CommonConstants.MBS_LIST;
  availableRenewalMonths: any[] = CommonConstants.MONTHS_LIST;
  loader_visible: boolean = false;
  showExhibitsZipDownloadLink: boolean = false;
  receivedCurrentExhibitEvents = [];
  currentExhibitLinkProcessId: string = null;
  fileUploadStatus: any;
  completedBatchRequests = [];
  lastSearchResults:any[] = [];
  lastSearchCriteria:any = null;
  receivedBatchEvents = new Set<string>();
  receivedAlternateBatchEvents = new Set<string>();
  receivedAlternateQuoteEvents = [];
  private batchDetailsMap: Map<string, RenewalBatchDetails> = new Map();
  private alternateBatchDetailsMap: Map<string, RenewalBatchDetails> = new Map();
  private autoRunDetailsMap: Map<string, any> = new Map();
  private changeDetectionScheduled = false;
  private lastRender = 0;
  private _cachedVisibleColumns: Set<string> = new Set();
  private _visibleColumnsDirty = true;
  allGroupsCrossSelled: boolean = false;
  isCrossSellingEnabled = this.commonService.getCrossSellingEnabled();
  isTieringEnabled = this.commonService.getTieringEnabled();
  alert = {
    show: false,
    message: '',
    type: '',
    cssClass: '',
    header: '',
    headerVisibility: true,
    isSearch: false
  };
  renewalBatchWrapper: RenewalBatchWrapper = {
    renewalBatch: {},
    renewalBatchDetails: [],
    failedGrpNbrsInSearch: [],
  };
  private renewalBatchDetailsSubject = new BehaviorSubject<RenewalBatchDetails[]>([]);
  renewalBatchDetails$: Observable<RenewalBatchDetails[]> = this.renewalBatchDetailsSubject.asObservable();
  isLoadingXX = true;
  
  createOpportunityURL: string = '/opportunity/create-opportunity-new';
  viewMode: boolean = false;
  headerName: string;
  detailsByFileUpload: boolean;
  selectedMode: any;
  tableDataExist: boolean;
  isFIRewewal: boolean = false;
  isFIRewewalSearch: boolean = false;
  isSuppHealthSearch: boolean = false;

  onMouseFocus(event: any) {
    this.multiSelect.show();
    if (event?.stopPropagation) {
      event.stopPropagation();
    }
  }

  mewaDownloadVersionOptions: string[] = ['Batch Info', 'Overaged Dependent'];
  selectedMewaDownloadType: string[] = [];

  onBatchDownloadMouseFocus(event: any) {
    if (this.showMewaDownloadMenu) {
      this.batchDownload?.show();
    }
    if (event?.stopPropagation) {
      event.stopPropagation();
    }
  }

  first = 0;
  disableFundingType = false;
  searchBatchTab: boolean = true;
  activeTab = 'BATCH';
  expandClicked = false;
  uwSalesNoteIconClicked = false;
  uwSelfNoteIconClicked = false;
  rateActionAdjustmentIconClicked = false;
  showTab = false;
  groupNumberClicked = false;
  arrowIndex: number;
  isTooltipVisible = false;
  sortableColList = ['Release Status', 'UW note to sales', 'UW note to self', 'Proposed Max Clm Fund Increase'];
  bulkEditColumn = [
    'Proposed Increase',
    'Current Risk Factor',
    'Tiered Risk Factor',
    'UW Risk Adjustment Factor',
    'WH Sav %',
    'Proposed Admin Fee Increase',
    'Proposed SSL Increase',
    'Proposed ASL Increase',
    'Proposed TL Increase',
    'UW note to sales',
    'UW note to self'
  ];
  nonEditableBulkAdjColumnsForABFALT = [
      'Proposed Admin Fee Increase',
      'Proposed SSL Increase',
      'Proposed ASL Increase',
      'Proposed TL Increase'
    ];

  bulkEditVisDenColumn = [
    ...RenewalsConstants.VIS_DEN_BULK_EDITABLE_COLUMNS
  ];
  bulkTableCols = [...RenewalsConstants.BULK_TABLE_COLUMNS_BEFORE];

  bulkTableDenVisCols = [...RenewalsConstants.VIS_DEN_BULK_TABLE_COLUMNS];

  bulkViewTableData = [];
  bulkAdjData = [];
  private bulkViewTableDataMap = new Map<string, any>();
  private bulkAdjDataMap = new Map<string, any>();
  selectstate: any;
  selectedLOB: any;
  selectmonths: any;
  selectedYear: any;
  selectedRenewalMonthYear:any;
  fieldToPercentConvert = [
    'lossRatio',
    'pyLossRatio',
    'blendedIncrease',
    'pyCntrctMaxClmFndLr',
    'cyCntrctMaxClmFndLr',
    'adminFeeIncrease',
    'sslIncrease',
    'aslIncrease',
    'tlIncrease',
    'maxClmFndIncrease',
    'manualOnlySugstdIncrease',
    'clmOnlySugstdIncrease',
    'cyContractSpecificStopLossRatio',
    'pycontractSpecificStopLossRatio',
    'mpcRateAction',
    'renewalIncreasePercentage',
    'diffToRenewalRatePercentage'
  ];
  fieldToConcatPrcnt = ['formulaTieredRateActionPercent', 'uwTieredRateActionPercent', 'adjustedRateActionPercent', 'renewalWHAPercent', 'wholeHealthAdjustmentFactor', 'asoAdminFee', 'sslPremium', 'aslPremium', 'terminalLiability', 'maxPaidClaim', 'overallSuggestedIncrease', 'overallProposedIncrease'];
  readonly BATCH_INFO_SMALL_TH: string[] = ['Source System', 'Group Number', 'Market Segment', 'Group Refund', 'Comm Value'];
  readonly editableFieldsMapping = {
    ASL: 'ASL_OVERRIDDEN',
    REFUND_PCT: 'GROUP_REFUND_OVERRIDDEN',
    SSL: 'SSL_OVERRIDDEN'
  };
  expTotalRateActionPercent;
  uwTotalRateActionPercent;
  formulaTotalRateActionPercent;
  uwTieredRateAction;
  currentPlanTotPrem = 0;
  renewalPlanTotPrem = 0;
  adjustedPlanTotprem = 0;
  valueChanged = '';
  changedKey = '';
  cmplnFldCodes = [];
  overRideDetails: any;
  private static BATCH_EXHIBITS_BASE_PATH = '/data/batch/exhibits/';
  hasDeletedGroupsInBatch: boolean = false;
  hasDeletedGroupsInBulk: boolean = false;

  isAdminUser: boolean = false;
  isRenewalBatchUser: boolean = false;
  isUserReadOnly: boolean = false;
  quoteReason: boolean = false;
  isAutoRunBatch: boolean = false;
  showOriginalGroupNumber: boolean = false;
  hideTestBatch: boolean = false;
  renewalBatchColumns = RenewalsConstants.RENEWAL_BATCH_COLUMNS;
  renewalBatchColumnsNewBatch = RenewalsConstants.RENEWAL_BATCH_COLUMNS_NEW_BATCH;
  
  trackByGroupDetail = (_index: number, item: any) =>
    `${item.batchID}_${item.groupNumber}_${item.lob}_${item.fundingType}`;

  private repeatingGroupsSet = new Set<string>();
  
  isSaveFlow = false;
  isSaveDataExist = false;
  selectedMbs: any;
  selectedAssociation: any[] = [];
  selectedAssociationCodes: any[] = [];
  filteredAssociation: any[] = [];
  renewalMonthsFromResponse: any[] = [];
  statesFromResponse: any[] = [];
  marketSegmentsFromResponse: any[] = [];
  quoteDetail: any;
  uwAdjustment = {};
  whAdjustmentsDetails: any;
  quoteAdjustments: any;
  allPlansLoaded: any;
  uwAdjustmentFetchObject: any;
  fileName: string = '';
  commissionOptions = CommonConstants.COMMISSION_OPTIONS;
  autoRunQuoteConvertToSave = CommonConstants.AUTORUN_QUOTE_CONVERT_QUOTE_TO_SAVE;
  commissionFields = [CommonConstants.COMMISSION, CommonConstants.COMMISSION_TYPE];
  listOfGroupsWithOverrides = [];
  showDeleteInBulkTab: boolean = false;
  showPlusIconForGroupMerge = false;
  isSearchChanged: boolean = false;
  private eventSources: EventSource[] = [];
  private includedMapToRestore: Map<string, boolean> | null = null;
  private isSelectedAltsGroupsToRestore = null;
  private tieringInputToRestore = null;
  lobFundingTypeMapForSendToOpp = this.commonService.getEnableSendToOppMap();
  tieringConfig = this.commonService.getTieringConfig();
  repeatingGroupsToHighlight = [];
  autoRunBatchTableData = [];
  isAlreadyConverted: boolean = false;
  isNotConverted: boolean = false;
  setMsgForFailedConverts: string = '';
  addFailedConvertGroups = [];
  fundingTypeCheck: boolean = true;
  enabledBatchGroupDownload: boolean;
  groupNumbersFile: any;
  isFailedGroups: boolean = false;
  isFailedAndAlreadyConverted: boolean = false;
  batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS;
  enableQuoteOptions: boolean = false;
  invalidGroupsTooltipMsg: string = '';
  specialtyLobsEnabledForBatchSubmission: any[] = [];
  disableTierDropdownOption: boolean = false;
  tierLoader: boolean = false;
  showTierDropdown = false;
  hideDropdownTimeout: any;
  bulkAdjForVisDenEnabled: boolean = false;
  disableVisionDentalLgBatchSubmit: boolean = false;
  initialCheckForTieringRepullInprogress = true;
  mewaOriginalQuoteEnabled = this.commonService.getMEWAOriginalQuoteEnabled();
  isDentaltieringEnabled = this.commonService.getEnabledTieringDentalLGBatch();
  isVisiontieringEnabled = this.commonService.getEnabledTieringVisionLGBatch();
  customTierRatioTypeRateActionFixEnabled: boolean = this.commonService.getCustomTierRatioTypeRateActionFixEnabled();
  acaToAbfHeaders = [
    'Renewal Premium',
    'Current to Renewal RA%',
    'Renewal to Quoted RA%'
  ]

  hasCensusPrivilege: boolean = false;

  get showMewaDownloadMenu(): boolean {
    const hasDatamartGroups = this.renewalBatchWrapper?.renewalBatchDetails.some((group: any) => group.source !== 'RARE')
    
    return this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType === 'MEWA' 
      && this.hasCensusPrivilege
      && hasDatamartGroups;
  }

  readonly quoteOptionsElgibleStates = this.commonService.getQuoteOptionStatesMap();
  private confirmationService = inject(ConfirmationService);

  constructor(
    private commonService: CommonService,
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private cdRef: ChangeDetectorRef,
    private uwChangeSetService: UWAdjustmentChangeSetService,
    private uwAdjService: UnderwriterAdjustmentService,
    private expGrandTotalCalcService: ExpGrandTotalCalcService,
    private peService: PrintExhibitService,
    private Ref: ElementRef,
    public datepipe: DatePipe,
    public renewalsService: RenewalsService,
    @Inject(LOCALE_ID) private locale: string,
    private commonQuoteService: CommonQuoteService,
    private authService: AuthenticationService,
    private ngZone: NgZone
  ) {

    this.hasCensusPrivilege =  this.authService.isCensusPrivilegedUser(this.commonService.getAssignedUserGroup());
  
  }
  availableVersions: any[];
  availabelSystems: any[];
  selectedVersion: any;
  selectedSystem: any;
  download_form: FormGroup<DownloadForm>;
  fundTypeFromDetails: string = '';
  isFIselectedDropdown: string;
  isFundingTypeSelectedFirst = false;
  mbuList: any;
  associationList: any;

  transIDArray = [];
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  batchSearch: any;
  isConvert: boolean = false;
  quoteOptionsData: any;
  private quoteOptionsDataMap: Map<string, any[]> = new Map();
  selectedSubmitOptions: any = [];
  deletedGroups: any[] = [];
  selectedTierAction: any;
  isDirty = false;
  batchStatusObj: { status: string, tooltip: string | null } = { status: '', tooltip: null };
  bulkViewTableDataWithErrors = [];
  filterError: boolean = false;
  bulkUploadImportConfig = this.commonService.getBulkUploadImportConfig();
  isImportExportEnabled: boolean = false;
  showImportedProgress: boolean = false;
  availableDatasourcesForBatchScreenSearchOverlay: any[];
  selectedDatasourceForBatchScreenSearchOverlay: any;
  enableSendToOppForSuppHealth: boolean = false;
   enableSendToOppForVision: boolean = false;
    enableSendToOppForDental: boolean = false;
  includeTestQuotesSelected: boolean = false;
  showMissingGroupsAccordion: boolean = false;
  missingGroupNumbers: any[] = [];
  isMissingGroupsAccordionExpanded: boolean = false;
  errorMsgforFailedTiering: string = '';
  showValidationErrorDialog: boolean = false;
  validationErrors: any[] = [];
  pendingFileUpload: any = null;
  failedTieringGroups: string[] = [];
  batchDetailsPayload = [];
  lossRationVisionViewOnBulkScreenEnabled: boolean = false;

  ngOnInit() {
    this.commonService.getNationalMbu().subscribe((response) => {
      this.mbuList = response;
      this.cdRef.markForCheck();
    });

    this.specialtyLobsEnabledForBatchSubmission = this.commonService.getSpecialtyLobsEnabledForBatchSubmission();

    this.commonService.getAssociationList().subscribe((response) => {
      this.associationList = response;
      this.cdRef.markForCheck();
    });

    this.disableFundingType = this.commonService.fiRenewalEnabled;
    this.availableDatasourcesForBatchScreenSearchOverlay = this.commonService.getDatasourcesForBatchScreenSearchOverlay() || [];
    this.renewalsService.getSourceSystemForRenewals().subscribe((systems) => {
      this.availabelSystems = systems?.sourceSystemCodes;
      this.cdRef.markForCheck();
    });
    this.selectedSystem = ['808'];
    const myDropdown = this.Ref.nativeElement.querySelector('downloadMouseHover');
    if (myDropdown) {
      myDropdown.click();
    }
    this.availableVersions = [
      { label: 'V1', value: 'NON_CT_STATE' },
      { label: 'V2', value: 'CT_STATE' }
    ];
    this.selectedVersion = [];
    this.batchSaveGroup = this.fb.group({
      batchName: ['', [Validators.minLength(3), Validators.required]],
      quoteReason: [''],
      isAutoRunBatch: ['']
    });
    this.download_form = this.fb.group({
      downloadOptions: ['']
    });
    this.batchSearchForm = this.fb.group({
      groupName: ['', { validators: [Validators.minLength(3)] }],
      groupNumber: ['', { validators: [Validators.minLength(3)] }],
      states: ['', { validators: [Validators.required] }],
      lob: [null, { validators: [Validators.required] }],
      marketSegments: [''],
      fundingTypes: '',
      mbs: ['Key'],
      association: [[]],
      renewalMonths: ['', { validators: [Validators.required] }],
      renewalYears: [''],
      renewalMonthYear: [''],
      system: ['808'],
      dataSource: [this.availableDatasourcesForBatchScreenSearchOverlay[0] || ''],
      includeTestQuotes: ['']
    });
    this.route.queryParams.subscribe((params) => {
      if (params['batchId'] && params['batchStatus']) {
        this.viewMode = true;
        this.renewalBatchWrapper.renewalBatch['id'] = params['batchId'];
        this.renewalBatchWrapper.renewalBatch['batchStatus'] = params['batchStatus'];
        this.renewalBatchWrapper.renewalBatch['batchName'] = params['batchName'];
        this.fileUploadStatus = params['fileUploadStatus'];
        if (this.renewalBatchWrapper.renewalBatch['batchName']) {
          this.selectedMode = null;
        }
        this.fetchRenewalDetailsByBatch();
      }
      this.headerName = params['headerName'];
      this.cdRef.markForCheck();
    });

    if (Object.keys(this.renewalBatchWrapper.renewalBatch).length === 0) {
      this.searchBatchTab = true;
    } else {
      this.searchBatchTab = true;
    }

    this.availableStates = this.commonService.getStateList();
    this.availableMarketSegs = CommonConstants.MARKET_SEGEMENT_LIST;

    //Get lobs configured for Create Renewal Batch
    this.renewalsService.getLobsForRenewalCreateBatch().subscribe((lobs) => {
      this.availableLOBs = lobs;
      if (this.availableLOBs && this.availableLOBs.length === 1) {
        this.selectedLOB = this.availableLOBs[0];
      }
      this.cdRef.markForCheck();
    });
    if(this.renewalBatchWrapper?.renewalBatch?.id) {
      this.selectedMbs = [];
    } else {
    this.selectedMbs = ['Key'];
    }
    this.batchSaveGroup.get('batchName').setValue(this.renewalBatchWrapper.renewalBatch['batchName'] || '');
    let userRole = this.authenticationService.userRole['_value'];
    this.isAdminUser = CommonUtil.userHasAdminRole(userRole);
    this.isRenewalBatchUser = CommonUtil.userHasRenewalBatchRole(userRole);
    this.isUserReadOnly = this.authenticationService.isUserReadOnly(userRole);

    this.listOfGroupsWithOverrides = [];
    this.enabledBatchGroupDownload = this.commonService.getEnabledBatchGroupDownload();
    let originalGroupData = RenewalsUtil.updateRenewalBatchColumns(this.quoteReason, this.renewalBatchColumns);
    this.showOriginalGroupNumber = originalGroupData.showOriginalGroupNumber;
    this.renewalBatchColumns = originalGroupData.batchColumns;
    this._visibleColumnsDirty = true;
    this.bulkAdjForVisDenEnabled = this.commonService.getenabledBulkAdjVisDen();
    if(this.availableDatasourcesForBatchScreenSearchOverlay && this.availableDatasourcesForBatchScreenSearchOverlay.length > 0) {
      this.selectedDatasourceForBatchScreenSearchOverlay = this.availableDatasourcesForBatchScreenSearchOverlay[0];
    }
    this.enableSendToOppForSuppHealth = !!( this.lobFundingTypeMapForSendToOpp && this.lobFundingTypeMapForSendToOpp[CommonConstants.SuppHealth] && Array.isArray(this.lobFundingTypeMapForSendToOpp[CommonConstants.SuppHealth]) && this.lobFundingTypeMapForSendToOpp[CommonConstants.SuppHealth].length > 0);
    this.enableSendToOppForVision = !!( this.lobFundingTypeMapForSendToOpp && this.lobFundingTypeMapForSendToOpp[CommonConstants.Vision] && Array.isArray(this.lobFundingTypeMapForSendToOpp[CommonConstants.Vision]) && this.lobFundingTypeMapForSendToOpp[CommonConstants.Vision].length > 0);
    this.enableSendToOppForDental = !!( this.lobFundingTypeMapForSendToOpp && this.lobFundingTypeMapForSendToOpp[CommonConstants.Dental] && Array.isArray(this.lobFundingTypeMapForSendToOpp[CommonConstants.Dental]) && this.lobFundingTypeMapForSendToOpp[CommonConstants.Dental].length > 0);

    this.lossRationVisionViewOnBulkScreenEnabled = this.commonService.getLossRationVisionViewOnBulkScreenEnabled();
  }
  setIndex(index: any) {
    if (this.arrowIndex === index) {
      this.arrowIndex = null;
      this.groupNumberClicked = false;
    } else {
      this.arrowIndex = index;
      this.groupNumberClicked = true;
    }
  }

  ////////

  updateAllAdjustmentsToProposedIncrease(rowData, value) {
    const factorValue = CalculatorUtils.convertPercentageToFactor(value.replace('%', ''));
    // Use vision or dental product adjustments dynamically
    const adjustments = rowData.visionProductAdjustments || rowData.dentalProductAdjustments || [];

    adjustments.forEach((adjustment, idx) => {
      this.updateAdjustmentsToProposedIncrease([adjustment], factorValue);
      this.updateProductAdjustmentsSet(rowData, `adjPlan${idx + 1}`, adjustment);
    });
  }

  updateAdjustmentsToProposedIncrease(adjustments: any[], value) {
    adjustments.forEach((adjustment) => {
      adjustment.proposedRateActionAdjustment = value;
    })
  }

  updateProductAdjustmentsSet(rowData, key, newAdjustment) {
    const productAdjustment = {
      adjustmentType: key,
      planName: newAdjustment.planName,
      ratingPlanID: newAdjustment.ratingPlanID,
      suggestedRateActionAdjustment: newAdjustment.suggestedRateActionAdjustment,
      uwAdjustmentFactor: newAdjustment.proposedRateActionAdjustment
    }

    if (!rowData.productAdjustments) {
      rowData.productAdjustments = [];
    }

    const adjustmentIndex = rowData.productAdjustments.findIndex(adjustment => adjustment.ratingPlanID === productAdjustment.ratingPlanID);

    if (adjustmentIndex !== -1) {
      rowData.productAdjustments[adjustmentIndex] = productAdjustment;
    } else {
      rowData.productAdjustments.push(productAdjustment);
    }
  }

  updateRateActionAdjustment(rowData, key, ratingPlanId, newValue) {
    const propertyName = 'ratingPlanID';
    let adjustment = this.findProductByPropertyInAdjustments(propertyName, ratingPlanId, rowData)
    if (adjustment) {
      adjustment['proposedRateActionAdjustment'] = Number(newValue);
      this.updateProductAdjustmentsSet(rowData, key, adjustment);
    }
  }

  isRateActionAdjColumnProperty(columnProperty) {
    return CommonConstants.DEN_VIS_RA_ADJ_COLUMNS_PROPERTIES.includes(columnProperty);
  }

  isRateActionAdjColumnClicked(columnName) {
    if (this.isRateActionAdjColumn(columnName)) {
      return this.rateActionAdjustmentIconClicked;
    } else {
      return false;
    }
  }

  isRateActionAdjColumn(columnName) {
    return CommonConstants.DEN_VIS_RA_ADJ_COLUMNS.includes(columnName);
  }

  getVisDenProductAdjustments(columnName, bulkData) {
    let result = [];
    // Use vision or dental product adjustments dynamically
    const adjustments = bulkData.visionProductAdjustments || bulkData.dentalProductAdjustments || [];
    // Dynamically filter bulkTableDenVisCols based on available adjustments across ALL rows
    if (this.bulkTableDenVisCols && Array.isArray(this.bulkViewTableData)) {
      let columns = this.getVisDenBulkTableColumns();
      // Check for each plan column if ANY row has data for that plan
          const hasPlan1 = this.bulkViewTableData.some(row => {
            const adj = row.visionProductAdjustments || row.dentalProductAdjustments || [];
            return Array.isArray(adj) && adj[0];
          });
          const hasPlan2 = this.bulkViewTableData.some(row => {
            const adj = row.visionProductAdjustments || row.dentalProductAdjustments || [];
            return Array.isArray(adj) && adj[1];
          });
          const hasPlan3 = this.bulkViewTableData.some(row => {
            const adj = row.visionProductAdjustments || row.dentalProductAdjustments || [];
            return Array.isArray(adj) && adj[2];
          });
          const hasPlan4 = this.bulkViewTableData.some(row => {
            const adj = row.visionProductAdjustments || row.dentalProductAdjustments || [];
            return Array.isArray(adj) && adj[3];
          });
          const hasPlan5 = this.bulkViewTableData.some(row => {
            const adj = row.visionProductAdjustments || row.dentalProductAdjustments || [];
            return Array.isArray(adj) && adj[4];
          });
          const hasPlan6 = this.bulkViewTableData.some(row => {
            const adj = row.visionProductAdjustments || row.dentalProductAdjustments || [];
            return Array.isArray(adj) && adj[5];
          });

      // Hide RA - Adj and Suggested Increase columns for each plan if all rows are missing that plan
      if (!hasPlan1) {
        columns = columns.filter(col => col.header !== 'RA - Adj - Plan 1' && col.header !== 'Suggested Increase - Plan 1');
      }
      if (!hasPlan2) {
        columns = columns.filter(col => col.header !== 'RA - Adj - Plan 2' && col.header !== 'Suggested Increase - Plan 2');
      }
      if (!hasPlan3) {
        columns = columns.filter(col => col.header !== 'RA - Adj - Plan 3' && col.header !== 'Suggested Increase - Plan 3');
      }
      if (!hasPlan4) {
        columns = columns.filter(col => col.header !== 'RA - Adj - Plan 4' && col.header !== 'Suggested Increase - Plan 4');
      }
      if (!hasPlan5) {
        columns = columns.filter(col => col.header !== 'RA - Adj - Plan 5' && col.header !== 'Suggested Increase - Plan 5');
      }
      if (!hasPlan6) {
        columns = columns.filter(col => col.header !== 'RA - Adj - Plan 6' && col.header !== 'Suggested Increase - Plan 6');
      }
      this.bulkTableDenVisCols = columns;
    }
    switch (columnName) {
      case CommonConstants.RA_COLUMN_PLAN_1:
      case CommonConstants.SUGGESTED_INCR_PLAN_1:
        if (adjustments.length > 0) {
          result = [adjustments[0]];
        }
        break;
      case CommonConstants.RA_COLUMN_PLAN_2:
      case CommonConstants.SUGGESTED_INCR_PLAN_2:
        if (adjustments.length > 1) {
          result = [adjustments[1]];
        }
        break;
      case CommonConstants.RA_COLUMN_PLAN_3:
      case CommonConstants.SUGGESTED_INCR_PLAN_3:
        if (adjustments.length > 2) {
          result = [adjustments[2]];
        }
        break;
      case CommonConstants.RA_COLUMN_PLAN_4:
      case CommonConstants.SUGGESTED_INCR_PLAN_4:
        if (adjustments.length > 3) {
          result = [adjustments[3]];
        }
        break;
      case CommonConstants.RA_COLUMN_PLAN_5:
      case CommonConstants.SUGGESTED_INCR_PLAN_5:
        if (adjustments.length > 4) {
          result = [adjustments[4]];
        }
        break;
      case CommonConstants.RA_COLUMN_PLAN_6:
      case CommonConstants.SUGGESTED_INCR_PLAN_6:
        if (adjustments.length > 5) {
          result = [adjustments[5]];
        }
        break;
      default:
        result = [];
    }
    // Ensure proposedRateActionAdjustment is 0 if empty, null, or NaN
    result.forEach(adj => {
      if (
        adj.proposedRateActionAdjustment === undefined ||
        adj.proposedRateActionAdjustment === null ||
        adj.proposedRateActionAdjustment === '' ||
        isNaN(adj.proposedRateActionAdjustment)
      ) {
        adj.proposedRateActionAdjustment = '';
      }
    });
    return result;
  }

  calculateProposedIncreaseAfterFetch(bulkAdjustments: any[]) {
    bulkAdjustments.forEach(bulkAdjustment => {
      bulkAdjustment.overallProposedIncrease = this.calculateProposedIncrease(bulkAdjustment);
    })
  }

  calculateSuggestedIncreaseAfterFetch(bulkAdjustments: any[]) {
    bulkAdjustments.forEach(bulkAdjustment => {
      bulkAdjustment.overallSuggestedIncrease = this.calculateSuggestedIncrease(bulkAdjustment);
    })
  }

  calculateProposedIncrease(bulkData, overridePlanIdx = null, overrideValue = null) {
    let planComparisons = [];
    if (bulkData.visionPremiumComparison && bulkData.visionPremiumComparison.planComparison) {
      planComparisons = bulkData.visionPremiumComparison.planComparison;
    } else if (bulkData.dentalPremiumComparison && bulkData.dentalPremiumComparison.planComparison) {
      planComparisons = bulkData.dentalPremiumComparison.planComparison;
    }
    const adjustments = bulkData.visionProductAdjustments || bulkData.dentalProductAdjustments || [];
    let adjustedPlansTotal = 0;
    for (let i = 0; i < planComparisons.length; i++) {
      const monthlyPrem = planComparisons[i]?.currentRates?.monthlyTotal || 0;
      let factor = 1;
      if (overridePlanIdx !== null && i === overridePlanIdx && overrideValue !== null && overrideValue !== undefined && overrideValue !== '') {
        factor = Number(overrideValue);
      } else if (
        adjustments[i] &&
        adjustments[i].proposedRateActionAdjustment !== undefined &&
        adjustments[i].proposedRateActionAdjustment !== null &&
        adjustments[i].proposedRateActionAdjustment !== '' &&
        !isNaN(Number(adjustments[i].proposedRateActionAdjustment)) &&
        Number(adjustments[i].proposedRateActionAdjustment) !== 1
      ) {
        factor = Number(adjustments[i].proposedRateActionAdjustment);
      }
      adjustedPlansTotal += monthlyPrem * factor;
    }
    const currentPlansTotal = planComparisons.reduce((sum, plan) => sum + (plan.currentRates?.monthlyTotal || 0), 0);
    return this.roundFourDecimals(CalculatorUtils.calculateTotalIncreasePercentage(currentPlansTotal, adjustedPlansTotal));
  }

  calculateSuggestedIncrease(bulkData, overridePlanIdx = null, overrideValue = null) {
     let planComparisons = [];
    if (bulkData.visionPremiumComparison && bulkData.visionPremiumComparison.planComparison) {
      planComparisons = bulkData.visionPremiumComparison.planComparison;
    } else if (bulkData.dentalPremiumComparison && bulkData.dentalPremiumComparison.planComparison) {
      planComparisons = bulkData.dentalPremiumComparison.planComparison;
    }
    const adjustments = bulkData.visionProductAdjustments || bulkData.dentalProductAdjustments || [];
    let adjustedPlansTotal = 0;
    for (let i = 0; i < planComparisons.length; i++) {
      const monthlyPrem = planComparisons[i]?.currentRates?.monthlyTotal || 0;
      let factor = 1;
      if (overridePlanIdx !== null && i === overridePlanIdx && overrideValue !== null && overrideValue !== undefined && overrideValue !== '') {
        factor = Number(overrideValue);
      } else if (
        adjustments[i] &&
        adjustments[i].suggestedRateActionAdjustment !== undefined &&
        adjustments[i].suggestedRateActionAdjustment !== null &&
        adjustments[i].suggestedRateActionAdjustment !== '' &&
        !isNaN(Number(adjustments[i].suggestedRateActionAdjustment)) &&
        Number(adjustments[i].suggestedRateActionAdjustment) !== 1
      ) {
        factor = Number(adjustments[i].suggestedRateActionAdjustment);
      }
      adjustedPlansTotal += monthlyPrem * factor;
    }
    const currentPlansTotal = planComparisons.reduce((sum, plan) => sum + (plan.currentRates?.monthlyTotal || 0), 0);

    return this.roundFourDecimals(CalculatorUtils.calculateTotalIncreasePercentage(currentPlansTotal, adjustedPlansTotal));
  }

  calculateCurrentPlansTotal(bulkData: any): number {
    let currentPlansTotal = 0;
    bulkData.currentPlans?.forEach(currentPlan => {
      if (currentPlan.rateInfo?.TIERED && currentPlan.rateInfo?.TIERED.TOT.ACTIVE) {
        currentPlansTotal += this.getCurrentRatesSingle(currentPlan, bulkData, 1);
      } else if (currentPlan.rateInfo?.AGETIERED && currentPlan.rateInfo?.AGETIERED.TOT.ACTIVE) {
        currentPlansTotal += this.getCurrentRatesAgeBanded(currentPlan, bulkData, 1);
      }
    });
    return currentPlansTotal;
  }

  calculateAdjustedPlansTotal(bulkData, useSuggestedIncrease: boolean): number {
    const currentPlans = bulkData.currentPlans;
    const rateAdjustmentKey = useSuggestedIncrease ? 'suggestedRateActionAdjustment' : 'proposedRateActionAdjustment';
    let adjustedPlansTotal = 0;
    currentPlans?.forEach(currentPlan => {
      const adjustedPlan = this.findProductByPropertyInAdjustments('planName', currentPlan.planName, bulkData);
      let adjustment: number = adjustedPlan && !isNaN(adjustedPlan[rateAdjustmentKey])
        ? Number(adjustedPlan[rateAdjustmentKey]) : 1;

      if (currentPlan.rateInfo?.TIERED && currentPlan.rateInfo?.TIERED.TOT.ACTIVE) {
        adjustedPlansTotal += this.getCurrentRatesSingle(currentPlan, bulkData, adjustment);
      } else if (currentPlan.rateInfo?.AGETIERED && currentPlan.rateInfo?.AGETIERED.TOT.ACTIVE) {
        adjustedPlansTotal += this.getCurrentRatesAgeBanded(currentPlan, bulkData, adjustment);
      }
    });
    return adjustedPlansTotal;
  }

  roundFourDecimals(value) {
    if (value) {
      return Math.round(value * 10000) / 10000
    }
    return 0;
  }

  getCurrentRatesSingle(currentPlan: any, bulkData: any, adjustment: any): number {
    const proposedPlan = bulkData.data.proposedPlans.find(proposedPlan => proposedPlan.contractCode === currentPlan.contractCode);
    const mcpPlan = bulkData?.suppHealthPremiumComparison?.planComparison.find(mcp => mcp.quoteRatingPlanID === proposedPlan?.ratingPlanID);

    if (StringUtils.isEqualIgnoreCase(mcpPlan.isCurrentPlanRatesEdited, CommonConstants.YES)) {
      return mcpPlan?.currentRates.ratesT1 * (Number(adjustment));
    }
    return (currentPlan.rateInfo?.TIERED.TOT.ACTIVE?.EE?.rate ?? 0) * (Number(adjustment));
  }

  getCurrentRatesAgeBanded(currentPlan: any, bulkData: any, adjustment: any): number {
    const proposedPlan = bulkData.data.proposedPlans.find(proposedPlan => proposedPlan.contractCode === currentPlan.contractCode);
    const mcpPlan = bulkData?.suppHealthPremiumComparison?.planComparison.find(mcp => mcp.quoteRatingPlanID === proposedPlan?.ratingPlanID);

    let ageTieredTotalCurrent = 0;
    let ageBands = StringUtils.isEqualIgnoreCase(mcpPlan.isCurrentPlanRatesEdited, CommonConstants.YES) ?
      mcpPlan?.ageBandCurrentRates : currentPlan.rateInfo?.AGETIERED.TOT.ACTIVE;

    for (const key in ageBands) {
      ageTieredTotalCurrent += ((ageBands[key].ratesT1 ? ageBands[key]?.ratesT1 ?? 0 : ageBands[key].rate?.EE?.rate ?? 0) * (Number(adjustment)));
    }
    return ageTieredTotalCurrent;
  }

  findProductByPropertyInAdjustments(propertyName, value, rowData) {
        const adjustments = rowData.visionProductAdjustments || rowData.dentalProductAdjustments || null;
        if (adjustments) {
          if (Array.isArray(adjustments)) {
            for (const adj of adjustments) {
              const found = this.findAdjustmentByPropertyValue(adj, propertyName, value);
              if (found) {
                return found;
              }
            }
          } else {
            // If it's a single object, not an array
            return this.findAdjustmentByPropertyValue(adjustments, propertyName, value);
          }
        }
  }

  findAdjustmentByPropertyValue(adjustments: any[], property: string, value: string) {
    if (!adjustments) {
      return null;
    }
    // If adjustments is a single object, not an array
    if (!Array.isArray(adjustments)) {
      if (adjustments[property] === value) {
        return adjustments;
      } else {
        return null;
      }
    }
    // If adjustments is an array
    return adjustments.find((adjustment) => adjustment[property] === value);
  }


  ////////

  getRateActionAdjustment(visDenProductAdjustments) {
    return visDenProductAdjustments.proposedRateActionAdjustment;
  }

  checkAdjustmentValidNumber(key, index, value, disabled: boolean) {
    if (disabled) {
      return "";
    }
    if (!value || !Array.isArray(value) || !value[index] || value[index].proposedRateActionAdjustment === undefined) {
      return "";
    }
    if (value[index].proposedRateActionAdjustment === "0"
      || isNaN(value[index].proposedRateActionAdjustment)
      || StringUtils.isEmpty(value[index].proposedRateActionAdjustment)) {
      return "redContent";
    }
  }

  isSuggestedIncreaseColumn(columnName) {
    return CommonConstants.SUGGESTED_INCR_VIS_DEN_COLUMNS.includes(columnName);
  }

  checkBulkQuoteStatus(groupNumber: string) {
    let groupDetail = this.renewalBatchWrapper?.renewalBatchDetails.find((batchDetail) => batchDetail["groupNumber"] === groupNumber);
    if (!groupDetail) {
      return true;
    }
    return this.checkQuoteStatus(groupDetail);
  }

  checkQuoteStatus(groupDetail) {
    if (!groupDetail) {
      return true;
    }
    return !groupDetail.opportunityID || !groupDetail.quoteHeaderID || groupDetail?.submissionStatus != this.groupSubmissionStatus.SUCCESS || !groupDetail?.quoteRenewalStatus || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_RISK_SCORE || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_P2A_DATA || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.RECEIVED || groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.PROCESSING;
  }

  getGuaranteeEffEndDt(startDateString, rateGuaranteeMonths) {
    if (startDateString && rateGuaranteeMonths) {
      const rateGuaranteeEndDt = new Date(startDateString);
      // Add number of month to start date
      rateGuaranteeEndDt.setMonth(rateGuaranteeEndDt.getMonth() + rateGuaranteeMonths);
      // substract 1 day form rateGuaranteeEndDt
      const rateGuaranteeEndDtObj = new Date(rateGuaranteeEndDt);
      rateGuaranteeEndDtObj.setDate(rateGuaranteeEndDtObj.getDate() - 1)
      const formattedEndDate = rateGuaranteeEndDtObj.toISOString().split('T')[0]; // convert date to mm/dd/yyyy
      return 'Guarantee End Dt: '.concat(this.datepipe.transform(formattedEndDate, "MM/dd/yyyy"));
    }
  }

  getDisableMkgSegment(enableOrDisableflag) {
    this.availableMarketSegs.forEach((mktSeg) => {
      if (StringUtils.isEqual(mktSeg.value, CommonConstants.SG)) {
        mktSeg.disabled = enableOrDisableflag;
      }
      if (enableOrDisableflag) {
        this.batchSearchForm.patchValue({
          marketSegments: [CommonConstants.LG]
        });
      }
    });
  }
  getDisableLGMkgSegment(enableOrDisableflag) {
    this.availableMarketSegs.forEach((mktSeg) => {
      if (StringUtils.isEqual(mktSeg.value, CommonConstants.LG)) {
        mktSeg.disabled = enableOrDisableflag;
      }
      if (enableOrDisableflag) {
        this.batchSearchForm.patchValue({
          marketSegments: [CommonConstants.SG]
        });
      }
    });
  }

  getMkgSegmentValueForSearch() {
    this.availableMarketSegs.forEach((mktSeg) => {
      if (StringUtils.isEqual(mktSeg.value, CommonConstants.SG)) {
        if (mktSeg.disabled) {
          this.batchSearchForm.patchValue({
            marketSegments: [CommonConstants.LG]
          });
        }
      } else if (StringUtils.isEqual(mktSeg.value, CommonConstants.LG)) {
        if (mktSeg.disabled) {
          this.batchSearchForm.patchValue({
            marketSegments: [CommonConstants.SG]
          });
        }
      }
    });
  }

  getDisableFundingType(enableOrDisableflag) {
    this.availableFTs.forEach((fundingType) => {
      if (StringUtils.isEqual(fundingType.value, CommonConstants.FI)) {
        fundingType.disabled = enableOrDisableflag;
      }
      if (StringUtils.isEqual(fundingType.value, CommonConstants.ASO)) {
        fundingType.disabled = enableOrDisableflag;
      }
    });
  }

  showAutoRun() {
    if (!this.commonService.isAutoRunBatchEnabled) {
      return false;
    }
    return (
      (!this.selectedLOB ||
        (StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.FI) &&
          StringUtils.isEqualIgnoreCase(this.selectedLOB, CommonConstants.Medical)) ||
        (StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.ABF) &&
          StringUtils.isEqualIgnoreCase(this.selectedLOB, CommonConstants.Medical))) &&
      !this.renewalBatchWrapper?.renewalBatchDetails?.every((detail: any) => detail?.source === 'RARE')
    );
  }

  hideSendToOpp() {
    return (
      !this.batchSearchForm.value.lob ||
      (StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.FI) &&
        StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Medical)) ||
      (StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.ABF) &&
        StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Medical))
    );
  }

  hideFundingType() {
    const isMedicalLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.Medical);
    const isDentalLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.Dental);
    const isVisionLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.Vision);
    const isSuppHealthLob = StringUtils.isEqual(this.selectedLOB, CommonConstants.SuppHealth);
    this.availableFTs.forEach((fundingType) => {
      fundingType.hide = false;
      if (
        (isDentalLob || isVisionLob || isSuppHealthLob) &&
        (StringUtils.isEqual(fundingType.value, CommonConstants.ASO) || StringUtils.isEqual(fundingType.value, CommonConstants.MEWA))
      ) {
        fundingType.hide = true;
      }
      if (isMedicalLob && (StringUtils.isEqual(fundingType.value, CommonConstants.ASO) || StringUtils.isEqual(fundingType.value, CommonConstants.MEWA))) {
        fundingType.hide = false;
      }
    });
  }

  showFundingType() {
    this.availableFTs.forEach((fundingType) => {
      fundingType.hide = false;
    });
  }

  getLGDisableFundingType(enableOrDisableflag) {
    this.availableFTs.forEach((fundingType) => {
      if (StringUtils.isEqual(fundingType.value, CommonConstants.MEWA)) {
        fundingType.disabled = enableOrDisableflag;
      } else {
        fundingType.disabled = false;
      }
    });
  }

  ngAfterViewInit() {
    this.multiselectEle = document.querySelector('.p-multiselect') as any;
    if (this.multiselectEle) {
      this.multiselectEle.setAttribute('tabindex', -1);
    }
  }

  ngAfterViewChecked() {
    let hideFooterBtn = this.isShownFooterBtn();
    if (hideFooterBtn != this.hideFooterBtn) {
      this.hideFooterBtn = hideFooterBtn;
      this.cdRef.markForCheck();
    }
  }
  isShownFooterBtn() {
    return this.parentDiv && this.parentDiv.nativeElement.offsetHeight > window.innerHeight + 1;
  }

  public get submissionStatus(): typeof SubmissionStatus {
    return SubmissionStatus;
  }

  public get groupSubmissionStatus(): typeof QuoteSubmissionStatus {
    return QuoteSubmissionStatus;
  }

  public get sseProcess(): typeof BatchSSEProcess {
    return BatchSSEProcess;
  }

  public get quoteRenewalStatus(): typeof QuoteRenewalStatus {
    return QuoteRenewalStatus;
  }

  public get releaseSteps(): typeof ReleaseSteps {
    return ReleaseSteps;
  }

  public get convertBulkStatus(): typeof ConvertBulkStatus {
    return ConvertBulkStatus;
  }

  setDefaultFormValue() {
    this.batchSearchForm.patchValue({
      lob: '',
      fundingTypes: 'ABF',
      mbs: ['Key'],
      association: [],
      groupName: '',
      groupNumber: '',
      states: [],
      marketSegments: [],
      renewalMonths: [],
      renewalYears: [],
      renewalMonthYear: '',
      system: ['808'],
      dataSource: this.availableDatasourcesForBatchScreenSearchOverlay[0] || '',
      includeTestQuotes: ''
    });
    this.isFIselectedDropdown = CommonConstants.ABF;
  }

  myUploader(event) {
    this.file = undefined;
    this.file = event.files[0];
    this.showFileError = false;
    this.fileName = event.files[0].name;
    this.cdRef.markForCheck();
  }
  removeFile() {
    this.file = undefined;
    this.fileName = '';
  }

  disableUploadBtn() {
    if (this.file == undefined || this.file == null) {
      return true;
    } else {
      return false;
    }
  }

  getVisibleTabCount(): number {
    let count = 0;
    if (this.enableQuoteOptions && this.renewalBatchWrapper?.renewalBatchDetails[0]?.lob !== 'Supp Health') count++;
    if (this.showBulkAdjForMedicalAndSuppHealth() && this.bulkViewTableData.length > 0) count++;
    if (this.showBulkAdjForDenAndVis() && this.bulkAdjForVisDenEnabled && this.selectedMode !== 'fileUpload' && !this.detailsByFileUpload) count++;
    if (this.isAutoRunBatch) count++;
    if (this.isTieringInputEnabled) count++;
    return count;
  }

  onFileUpload() {
    this.batchSaveGroupSubmitted = true;
    if (this.selectedMode == 'fileUpload' && this.batchSaveGroup.invalid) {
      return;
    } else {
      this.showLoader = true;
      this.first = 0;
      this.errorExist = false;
      this.isPopupVisible = false;
      this.renewalsService.uploadSpecialtyBatch(this.file, this.batchSaveGroup.value.batchName).subscribe(
        (response) => {
          var source = this.commonService.listenForStream(response.body['processId']);
          source.addEventListener('RENEWAL_BATCH_SUMMARY', (event: any) => { });
          source.addEventListener('RENEWAL_SUMMARY', (event: any) => { });
          source.addEventListener('RENEWAL_BATCH_SUMMARY_STATUS_COMPLETE', (event: any) => {
            source.close();
            if (event && event.data) {
              let data = JSON.parse(event.data);
              this.renewalBatchWrapper = data.payload || {};
              this.buildBatchDetailsMap();
              if (this.renewalBatchWrapper.renewalBatchDetails.length) {
                this.fileUploadStatus = this.renewalBatchWrapper.renewalBatch.fileUploadStatus;
                if (this.renewalBatchWrapper.renewalBatch.fileUploadStatus == 'Success') {
                  let alertMsg = 'File uploaded successfully.';
                  this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
                } else {
                  this.errorExist = true;
                  this.errorList = this.renewalBatchWrapper.renewalBatch.errorList;
                  let alertMsg = 'Errors found during file Upload';
                  this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
                }
                window.scroll(0, 0);
                this.hideAlertVisibility();
              }
              this.detailsByFileUpload = true;
              this._visibleColumnsDirty = true;
              this.showLoader = false;
              this.cdRef.markForCheck();
            }
          });
          source.addEventListener('FAILED', (event: any) => {
            this.errorExist = true;
            source.close();
            this.showLoader = false;
            let eventdata = JSON.parse(event.data);
            let obj = JSON.parse(eventdata.message);
            this.errorList = obj.rareError[0].debugMessages[1].response;
            let alertMsg = 'Errors found during file Upload';
            this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
            this.hideAlertVisibility();
            this.cdRef.markForCheck();
          });
        },
        (error) => {
          this.errorExist = false;
          this.isPopupVisible = false;
          if (error.exceptions[0].message == 'Batch Name is Already Used') {
            this.setAlertVisibility(true, AlertType.WARNING, 'Batch Name is Already Used !');
          } else {
            this.setAlertVisibility(true, AlertType.ERROR, 'Something went wrong !');
          }
          this.showLoader = false;
          this.hideAlertVisibility();
          this.cdRef.markForCheck();
        }
      );
      this.searchResults = [];
      this.cdRef.markForCheck();
    }
  }
  errorList: any;
  errorExist: boolean = false;
  errorResponse: any;
  isPopupVisible: boolean = false;
  public aslFormartValidationPattern = '^([0-1]?(\\.\\d{1,2}?)?|[2])$';
  public refundPCTFormartValidationPattern = '^([0]?(\\.\\d{1,3}|[1])?)?$';
  public commissionFormatValidationPattern = '^[0-9]*.?[0-9]*$';

  errorPopup = () => {
    this.isPopupVisible = false;
    this.errorResponse = this.errorList;
    this.isPopupVisible = true;
  }

  openOpp(groupDetail) {
    const url = this.createOpportunityURL;
    if (url) {
      const pathToNavigate = this.createOpportunityURL;
      const url = this.router.serializeUrl(
        this.router.createUrlTree([pathToNavigate], {
          queryParams: {
            opportunityID: groupDetail['opportunityID']
          }
        })
      );
      localStorage.setItem('quoteHeaderID', groupDetail['quoteHeaderID']);
      localStorage.setItem('opportunityID', groupDetail['opportunityID']);
      localStorage.setItem('isLoginAgain', 'true');
      localStorage.setItem('assignedUserRoles', this.authenticationService.getUserRole());
      localStorage.setItem('assignedUserRolesTextToDisplay', this.authenticationService.getUserRoleTextToDisplay());
      localStorage.setItem('sendToOpp', 'true');
      localStorage.setItem('assignedUserLobs', this.authenticationService.getUserLob());
      localStorage.setItem('assignedUserStates', this.authenticationService.getUserState());
      localStorage.setItem('disableAll', 'false');
      window.open(url, '_blank');
    } else {
      alert("Opportunity Details doesn't exist");
    }
  }

  openQuote(groupDetail: any) {
    this.lob_FT = [];
    const dashboardSubmissionStatus = this.renewalBatchWrapper.renewalBatch['dashboardSubmissionStatus'];
    this.commonService.logUserOpeningQuoteEvent(
      groupDetail['ratingTransID'],
      groupDetail['opportunityID'],
      groupDetail['quoteHeaderID'],
      groupDetail['lob'],
      (groupDetail['fundingType'] ==  CommonConstants.MEWA ?  CommonConstants.ASO :groupDetail['fundingType'] ),
      groupDetail['marketSegment'],
      groupDetail['batchOrigin'],
      'Renewal-Batch'
    );
    this.commonQuoteService.getOpportunitesByOppID(groupDetail['opportunityID'], groupDetail['lob']).subscribe(
      (response) => {
        if (response != null) {
          for (var opp of response.opportunities) {
            if (opp && opp.quoteHeaderID === groupDetail['quoteHeaderID']) {
              let data =
                opp.lob == 'Medical' && opp.opportunityType == 'Renewal Local' && (opp.quotingType == 'ACA' || opp.quotingType == CommonConstants.MEWA)
                  ? opp.lob + '-' + opp.quotingType
                  : opp.lob + '-' + opp.fundingType;
              if (!this.lob_FT.find((x) => x === data)) {
                this.lob_FT.push(data);
              }
            }
          }
          this.lob_FT = this.lob_FT.sort(function (a, b) {
            return a > b ? 1 : a < b ? -1 : 0;
          });
          let quote;
          if (response.opportunities)
            quote = response.opportunities.find(
              (data) =>
                data.opportunityID == groupDetail['opportunityID'] &&
                data.quoteHeaderID == groupDetail['quoteHeaderID'] &&
                data.lob == groupDetail['lob'] &&
                data.fundingType == (groupDetail['fundingType'] ==  CommonConstants.MEWA ?  CommonConstants.ASO :groupDetail['fundingType'] ) &&
                (!data.quotingType || !groupDetail['quotingType'] ||
                  data.quotingType === 'POOL' || data.quotingType === CommonConstants.ACA ||data.quotingType === CommonConstants.MEWA ||
                  (!StringUtils.isEmpty(groupDetail['quotingType']) && data.quotingType === groupDetail['quotingType']))
            );
          if (quote && quote['ratingTransID']) {
            const pathToNavigate = this.identifyUWPath(groupDetail['lob']);
            const url = this.router.serializeUrl(
              this.router.createUrlTree([pathToNavigate], {
                queryParams: {
                  quoteHeaderID: groupDetail['quoteHeaderID'],
                  batchID: groupDetail['batchID'],
                  opportunityID: groupDetail['opportunityID'],
                  ratingTransID: groupDetail['ratingTransID'] ? groupDetail['ratingTransID'] : quote['ratingTransID'],
                  lob: groupDetail['lob'],
                  fundingType: (groupDetail['fundingType'] ==  CommonConstants.MEWA ?  CommonConstants.ASO :groupDetail['fundingType'] ),
                  availableTabs: this.lob_FT,
                  insertedTimestamp: quote['insertedTimestamp'],
                  quoteOrigin: groupDetail['isConvert'] ? 'convertedAutoRun' : (groupDetail['quoteOrigin'] ? groupDetail['quoteOrigin'] : groupDetail['batchOrigin']),
                  marketSegment: groupDetail['marketSegment'],
                  isLoginAgain: true,
                  disableAll: false
                }
              })
            );
            if (/Edge/.test(navigator.userAgent)) {
              if (localStorage.getItem('isLoginAgain')) this.commonService.removeHistoryLocalStorage();
            }
            localStorage.setItem('quoteHeaderID', groupDetail['quoteHeaderID']);
            localStorage.setItem('opportunityID', groupDetail['opportunityID']);
            localStorage.setItem('ratingTransID', groupDetail['ratingTransID'] ? groupDetail['ratingTransID'] : quote['ratingTransID']);
            localStorage.setItem('lob', groupDetail['lob']);
            localStorage.setItem('batchID', groupDetail['batchID']);
            localStorage.setItem('dashboardSubmissionStatus', dashboardSubmissionStatus);
            localStorage.setItem('fundingType', (groupDetail['fundingType'] ==  CommonConstants.MEWA ?  CommonConstants.ASO :groupDetail['fundingType'] ));
            localStorage.setItem('quoteOrigin', groupDetail['isConvert'] ? 'convertedAutoRun' : (groupDetail['quoteOrigin'] ? groupDetail['quoteOrigin'] : groupDetail['batchOrigin']));
            localStorage.setItem('insertedTimestamp', quote['insertedTimestamp']);
            localStorage.setItem('availableTabs', this.lob_FT.map((x) => x).join(','));
            localStorage.setItem('marketSegment', groupDetail['marketSegment']);
            localStorage.setItem('isLoginAgain', 'true');
            localStorage.setItem('assignedUserRoles', this.authenticationService.getUserRole());
            localStorage.setItem('assignedUserRolesTextToDisplay', this.authenticationService.getUserRoleTextToDisplay());
            localStorage.setItem('assignedUserLobs', this.authenticationService.getUserLob());
            localStorage.setItem('assignedUserStates', this.authenticationService.getUserState());
            localStorage.setItem('disableAll', 'false');
            window.open(url, '_blank');
          } else {
            alert("Quote Details doesn't exist");
          }
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }

  onCommissionDataChanged(updatedQuoteOptionsData: any) {
    // Update the local quoteOptionsData with the new commission values
    this.quoteOptionsData = updatedQuoteOptionsData;
    this.buildQuoteOptionsDataMap();

    // Also update the renewalBatchWrapper.renewalBatchDetails if needed
    if (this.renewalBatchWrapper && this.renewalBatchWrapper.renewalBatchDetails) {
      this.renewalBatchWrapper.renewalBatchDetails = updatedQuoteOptionsData;
      
    }
  }

  private identifyUWPath(lob: string): string {
    var path = '';
    switch (lob) {
      case 'Medical':
        path = '/quote/uw-rate';
        break;
      case 'Vision':
        path = '/quote/uw-rate-vision';
        break;
      case 'Dental':
        path = '/quote/uw-rate-dental';
        break;
      case CommonConstants.SuppHealth:
        path = '/quote/uw-rate-supplemental-health';
        break;
      default:
        break;
    }
    return path;
  }

  private showTabs() {
    this.showTab =
      !!(
        this.renewalBatchWrapper &&
        this.renewalBatchWrapper.renewalBatchDetails &&
        this.renewalBatchWrapper.renewalBatchDetails.find(
          (detail) =>
            detail['lob'] == 'Medical' ||
            (detail['lob'] == 'Medical' && detail['fundingType'] == 'ABF') ||
            (detail['lob'] == 'Medical' && detail['fundingType'] == 'FI') ||
            (detail['lob'] == 'Supp Health' && detail['fundingType'] == 'ABF') ||
            detail['lob'] == 'Supp Health' || detail['lob'] == 'Dental' || detail['lob'] == 'Vision'
        )
      );
  }
  showSendToOppBasedOnConfig() {
    return (
      this.lobFundingTypeMapForSendToOpp && (!this.detailsByFileUpload || (this.selectedMode && this.selectedMode !== 'fileUpload')) &&
      Object.keys(this.lobFundingTypeMapForSendToOpp).includes(this.selectedLOB) &&
      this.lobFundingTypeMapForSendToOpp[this.selectedLOB.toString()].includes(this.isFIselectedDropdown ? this.isFIselectedDropdown : this.fundTypeFromDetails)
    );
  }

  enableBulkAdjTab() {
    if (this.isAutoRunBatch) {
      this.checkBulkAdjStatus();
    } else if (this.activeTab == 'BATCH') {
      this.checkBulkAdjStatus();
    }
  }

  checkBulkAdjStatus() {
    this.disbleBulkAdj =
      (this.renewalBatchWrapper.renewalBatchDetails.findIndex(
        (detail) =>
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.PENDING ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.TRANSFER ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.RELEASED ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.SOLD ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.SOLD_MODIFIED ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.MODIFIED ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.PRESOLD ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.FAIL ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.PENDING_EXHIBIT ||
          detail['quoteRenewalStatus'] == QuoteRenewalStatus.DECLINED
      ) == -1 && !this.renewalBatchWrapper?.renewalBatchDetails?.every((detail: any) => detail.source === 'RARE'));
    this.allGroupsCrossSelled = this.renewalBatchWrapper.renewalBatchDetails.every(detail => detail['isCrossSelled']);
    // if(allGroupsCrossSelled){
    //   this.disbleBulkAdj = true;
    // }
  }

  checkAllRenewals(event) {
    (this.renewalBatchWrapper.renewalBatchDetails as any[]).forEach((renewal: any) => {
      if (renewal.source !== 'RARE') {
        (renewal['included'] as boolean) = event.checked as boolean;
      }
    });
    
    this.verifyCheckAllDetails();
    this.cdRef.markForCheck();
  }
  checkBulkDetails(event) {
    this.bulkViewTableData.forEach((renewal) => {
      if (!renewal?.isCrossSelled) {
        (renewal['included'] as boolean) = event.checked as boolean;
      }
    });
    if (event.checked) {
      this.autoSelectVersions();
    }
    this.cdRef.markForCheck();
  }

  checkEmptyBulkViewTableData() {
    let checkAllDetails = this.bulkViewTableData.filter((renewal) => renewal['included']);
    if (!checkAllDetails.length) {
      // If selectedVersion contains 'NON_CT_STATE' or 'CT_STATE', disable and uncheck those options in availableVersions
      if (this.selectedVersion && (this.selectedVersion.includes('NON_CT_STATE') || this.selectedVersion.includes('CT_STATE'))) {
        this.availableVersions = this.availableVersions.map(option => {
          if (option.value === 'NON_CT_STATE' || option.value === 'CT_STATE') {
            return { ...option, disabled: true };
          }
          return { ...option, disabled: false };
        });
        // Uncheck 'NON_CT_STATE' and 'CT_STATE' if present in selectedVersion
        this.selectedVersion = this.selectedVersion.filter(v => v !== 'NON_CT_STATE' && v !== 'CT_STATE');
      }
    } else {
      // Enable all options
      this.availableVersions = this.availableVersions.map(option => ({ ...option, disabled: false }));
    }
    return !checkAllDetails.length;
  }

  checkEmptyAutoRunTableData() {
    let checkAllDetails = this.autoRunBatchTableData.filter((renewal) => renewal['included']);
    return !checkAllDetails.length;
  }

  download() {
    let stateList = this.selectedVersion;
    this.renewalBatchWrapper.renewalBatchDetails.forEach((x) => {
      this.bulkViewTableData.forEach((renewal) => {
        if (renewal['included'] == true) {
          if (renewal['quoteHeaderID'] != undefined && renewal['ratingTransID'] && x['quoteHeaderID'] == renewal['quoteHeaderID']) {
            this.transIDArray.push(renewal['ratingTransID']);
          }
        }
      });
    });
    if (this.transIDArray.length !== 0 && (stateList as any)?.includes('NON_CT_STATE')) {
      const data = {
        data: {
          transIDs: this.transIDArray,
          batchName: this.renewalBatchWrapper.renewalBatch.batchName,
          fundingType: this.isFIBulkAdj ? CommonConstants.FI : (this.isMEWABulkAdj ? CommonConstants.MEWA : CommonConstants.ABF)
        }
      };
      this.renewalsService.getBulkAdjExcelData(data).subscribe(
        (x) => {
          if (x['processId'] != null && x['processId'] != undefined) {
            this.processId = x['processId'];
            this.showProgress = true;
            this.progressPercent = 1;
            this.progressStyle = 'progress-bar-warning';
            this.cdRef.markForCheck();
            var source = this.commonService.listenForStream(this.processId);
            source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
              this.progressStyle = '';
              let eventData = JSON.parse(event.data);
              var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
              this.cdRef.markForCheck();
            });
            source.addEventListener('SEND_EXHIBIT_TO_UI', (message: any) => {
              source.close();
              let eventData = JSON.parse(message.data);
              this.progressStyle = 'progress-bar-success';
              this.progressPercent = 100;
              this.progressMessage = eventData.message;
              this.cdRef.markForCheck();
              CommonService.exportFilename = eventData.metaData.fileName ? eventData.metaData.fileName : 'sheet';
              let fileName = this.commonService.getExportFilename();
              let contentData = eventData.payload.contentData;
              const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
              setTimeout(() => {
                this.showProgress = false;
                this.cdRef.markForCheck();
              }, this.commonService.getProgressBarTimeOut());
            });
            source.addEventListener('FAILED', (message: any) => {
              source.close();
              console.error('Received event : ', JSON.stringify(message.data));
              this.progressPercent = 90;
              this.progressStyle = 'progress-bar-danger';
              this.progressMessage = 'Error in getting response for download';
              this.cdRef.markForCheck();
              this.hideProgressBar();
            });
            source.addEventListener('error', (message: any) => {
              source.close();
              console.error('Received error event, with ready status :' + source.readyState);
              if (source.readyState == EventSource.CLOSED) {
                this.progressPercent = 90;
                this.progressStyle = 'progress-bar-danger';
                this.progressMessage = 'Failed to fetch progress because of communication failure';
                this.cdRef.markForCheck();
                this.hideProgressBar();
              }
            });
          }
        },
        (error) => {
          var promise = new Promise<any>((resolve) => {
            setTimeout(() => {
              resolve(false);
            }, 10000);
          });
          promise.then((res) => { });
        }
      );
    }
    if (this.transIDArray.length != 0 && (stateList as any).includes('CT_STATE') && !this.isMEWABulkAdj) {
      const data = {
        data: {
          transIDs: this.transIDArray,
          batchName: this.renewalBatchWrapper.renewalBatch.batchName,
          fundingType: this.isFIBulkAdj ? CommonConstants.FI : (this.isMEWABulkAdj ? CommonConstants.MEWA : CommonConstants.ABF)
        }
      };
      this.renewalsService.getCTBulkAdjExcelData(data).subscribe((x) => {
        if (x['processId'] != null && x['processId'] != undefined) {
          this.processId = x['processId'];
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = 'progress-bar-warning';
          this.cdRef.markForCheck();
          var source = this.commonService.listenForStream(this.processId);
          source.addEventListener('Bulk_Adjustment_V2_DETAILS_STATUS', (event: any) => {
            this.progressStyle = '';
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
            this.cdRef.markForCheck();
          });
          source.addEventListener('BULK_ADJ_V2_DETAILS_FETCH_COMPLETE', (event: any) => {
            this.progressStyle = '';
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
            this.cdRef.markForCheck();
          });
          source.addEventListener('SEND_BULK_ADJ_V2_TO_UI', (message: any) => {
            let eventData = JSON.parse(message.data);
            this.progressStyle = '';
            this.progressPercent = 90;
            this.progressMessage = eventData.message;
            this.cdRef.markForCheck();
            CommonService.exportFilename = eventData.metaData.fileName ? eventData.metaData.fileName : 'sheet';
            let fileName = this.commonService.getExportFilename();
            let contentData = eventData.payload.contentData;
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
            this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            setTimeout(() => {
              this.showProgress = false;
              this.cdRef.markForCheck();
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener('BULK_ADJ_V2_DOWNLOAD_COMPLETE', (event: any) => {
            source.close();
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            let eventData = JSON.parse(event.data);
            this.progressMessage = eventData.message;
            this.cdRef.markForCheck();
          });
          source.addEventListener('FAILED', (message: any) => {
            source.close();
            console.error('Received event : ', JSON.stringify(message.data));
            this.progressPercent = 90;
            this.progressStyle = 'progress-bar-danger';
            this.progressMessage = 'Error in getting response for download';
            this.cdRef.markForCheck();
            this.hideProgressBar();
          });
          source.addEventListener('error', (message: any) => {
            source.close();
            console.error('Received error event, with ready status :' + source.readyState);
            if (source.readyState == EventSource.CLOSED) {
              this.progressPercent = 90;
              this.progressStyle = 'progress-bar-danger';
              this.progressMessage = 'Failed to fetch progress because of communication failure';
              this.cdRef.markForCheck();
              this.hideProgressBar();
            }
          });
        }
      });
    }
    if ((stateList as any).includes('Adj_Template')) {
      this.exportBulkTemplate()
    }
    this.transIDArray = [];
  }
  checkEmptyRenewalBatchDetails() {
    let checkAllDetails = this.renewalBatchWrapper.renewalBatchDetails.filter((renewal) => renewal['included'] || renewal['sendToOpp']);
    return !checkAllDetails.length;
  }

  checkRenewalBatchDetailsSelected() {
    return this.renewalBatchWrapper.renewalBatchDetails.filter((renewal) => renewal['included']).length == 0;
  }

  currentRenewalDashboardSubmission(): string {
    const submissionStatus = this.renewalBatchWrapper?.renewalBatch['currentRenewalDashboardSubmission']?.request?.submissionStatus;
    if (submissionStatus == 'SUCCESS') {
      return 'Submitted Successfully';
    } else if (submissionStatus == 'FAILED') {
      return 'Submission Failed';
    }
  }

  dashboardIcon() {
    const batchID = this.renewalBatchWrapper.renewalBatch['id'];
    this.commonQuoteService.dashboardIcon(batchID);
  }


  onAddToBatch(selectedGroups: any[]) {
    const checkedGroups = (selectedGroups || []).filter(g => g.included);
    const existingGroupNumbers = this.renewalBatchWrapper.renewalBatchDetails.map(
      (g) => String(g.originalGroupNumber || g.groupNumber)
    );

    // Duplicate group numbers found in the selected groups
    const hasDuplicateGroupNumbers = (() => {
      const seen = new Set<string>();
      for (const group of checkedGroups) {
        const groupNumber = String(group.originalGroupNumber || group.groupNumber);
        if (seen.has(groupNumber)) {
          return true;
        }
        seen.add(groupNumber);
      }
      return false;
    })();
    if (hasDuplicateGroupNumbers) {
      this.alert = {
        show: true,
        type: 'warning',
        message: 'Duplicate group numbers found in the selected groups. Please remove duplicates and try again.',
        cssClass: 'alert-warning',
        header: 'warning',
        headerVisibility: true,
        isSearch: true
      };
      // Optionally, auto-hide after a few seconds
      setTimeout(() => {
        this.alert = { ...this.alert, show: false };
      }, 5000);
      return;
    }

    // --- Enforce single LOB in batch ---
    if (this.groupNumbersFile && this.renewalBatchWrapper.renewalBatchDetails.length === 0) {
      const selectedLob = checkedGroups[0].lob;
      const invalidLob = checkedGroups.filter(g => g.lob == selectedLob).length === checkedGroups.length;
      // const invalidLob = checkedGroups.find(g => g.lob !== existingLob);
      if (!invalidLob) {
        // Set alert for overlay (isSearch: true)
        this.alert = {
          show: true,
          type: 'warning',
          message: `A Renewal Batch is allowed to have a single LOB.`,
          cssClass: 'alert-warning',
          header: 'warning',
          headerVisibility: true,
          isSearch: true
        };
        // Optionally, auto-hide after a few seconds
        setTimeout(() => {
          this.alert = { ...this.alert, show: false };
        }, 5000);
        return;
      }

      const selectedFundingType = checkedGroups[0].fundingType;
      const invalidFundingType = checkedGroups.filter(g => g.fundingType == selectedFundingType).length === checkedGroups.length;;
      if (!invalidFundingType) {
        this.alert = {
          show: true,
          type: 'warning',
          message: `A Renewal Batch is allowed to have a single Funding Type. Only "${selectedFundingType}" groups can be added to this batch.`,
          cssClass: 'alert-warning',
          header: 'warning',
          headerVisibility: true,
          isSearch: true
        };
        setTimeout(() => {
          this.alert = { ...this.alert, show: false };
        }, 5000);
        return;
      }
    }
    if (this.renewalBatchWrapper.renewalBatchDetails.length > 0) {
      const existingLob = this.renewalBatchWrapper.renewalBatchDetails[0].lob;
      const invalidLob = checkedGroups.find(g => g.lob !== existingLob);
      if (invalidLob) {
        // Set alert for overlay (isSearch: true)
        this.alert = {
          show: true,
          type: 'warning',
          message: `A Renewal Batch is allowed to have a single LOB. Only "${existingLob}" groups can be added to this batch.`,
          cssClass: 'alert-warning',
          header: 'warning',
          headerVisibility: true,
          isSearch: true
        };
        // Optionally, auto-hide after a few seconds
        setTimeout(() => {
          this.alert = { ...this.alert, show: false };
        }, 5000);
        return;
      }

      const existingFundingType = this.renewalBatchWrapper.renewalBatchDetails[0].fundingType;
      const invalidFundingType = checkedGroups.find(g => g.fundingType !== existingFundingType);
      if (invalidFundingType) {
        this.alert = {
          show: true,
          type: 'warning',
          message: `A Renewal Batch is allowed to have a single Funding Type. Only "${existingFundingType}" groups can be added to this batch.`,
          cssClass: 'alert-warning',
          header: 'warning',
          headerVisibility: true,
          isSearch: true
        };
        setTimeout(() => {
          this.alert = { ...this.alert, show: false };
        }, 5000);
        return;
      }
    }

    const newGroups = checkedGroups.filter(
      (group) =>
        !existingGroupNumbers.includes(String(group.originalGroupNumber || group.groupNumber))
    );
    if (!checkedGroups.length) {
      this.setAlertVisibility(true, 'warning', 'Please select at least one group to add.');
      this.hideAlertVisibility();
      return;
    }
    this.renewalBatchWrapper.renewalBatchDetails = [
      ...this.renewalBatchWrapper.renewalBatchDetails,
      ...newGroups,
    ];
    this.buildBatchDetailsMap();
    
    this.selectedLOB = this.renewalBatchWrapper.renewalBatchDetails[0].lob;
    this.verifyCheckAllDetails();
    this.enableQuoteOptionsData();
    this.enableTieringTab();
    this.checkRareSourceGroups();
    this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS;
    this.showSubmitOptions();
    this.showTabs();

    // Set disableVisionDentalLgBatchSubmit for Vision or Dental LG non-fileupload batches after adding groups (for new batches)
    if (
      this.renewalBatchWrapper.renewalBatchDetails.length > 0 &&
      (
        StringUtils.isEqual(this.renewalBatchWrapper.renewalBatchDetails[0].lob, CommonConstants.Vision) ||
        StringUtils.isEqual(this.renewalBatchWrapper.renewalBatchDetails[0].lob, CommonConstants.Dental)
      ) &&
      this.renewalBatchWrapper.renewalBatchDetails[0].marketSegment === CommonConstants.LG &&
      !this.detailsByFileUpload &&
      this.selectedMode !== 'fileUpload'
    ) {
      this.disableVisionDentalLgBatchSubmit = this.commonService.getDisableVisionDentalLgBatchSubmit();
    }

    // Switch to Batch Info tab and close overlay
    // this.selectedMode = null;
    // this.activeTab = 'BATCH';
    // this.searchResults = [];
    this.checkAllDetailsOverlay = false;
    if (this.lastSearchResults && this.lastSearchResults.length > 0) {
      this.searchResults = JSON.parse(JSON.stringify(this.lastSearchResults));
      if (this.lastSearchCriteria) {
        this.batchSearchForm.patchValue(this.lastSearchCriteria);
      }
    }

    if (newGroups.length > 0) {
      this.setAlertVisibility(true, 'success', `${newGroups.length} group(s) added to batch.`, undefined, true);
    } else {
      this.setAlertVisibility(true, 'warning', 'Selected groups are already in the batch.', undefined, true);
    }
    this.hideAlertVisibility();
  }

  checkRareSourceGroups(){
    if (this.renewalBatchWrapper?.renewalBatchDetails && Array.isArray(this.renewalBatchWrapper.renewalBatchDetails)) {
      (this.renewalBatchWrapper.renewalBatchDetails as any[]).forEach(obj => {
        if (obj.source === 'RARE') {
          obj.included = false;
        }
      });
    }
  }

  enableTieringTab() {
    // Enable tiering input only if:
    // - Tiering is enabled globally
    // - All batch details are Medical LOB
    // - Batch status is "Submitted"
    // - All details have the same state, marketSegment, fundingType, and renewalDate
    // - Each detail's marketSegment exists in tieringConfig and includes its fundingType
    const details: RenewalBatchDetails[] = this.renewalBatchWrapper?.renewalBatchDetails as RenewalBatchDetails[];
    const batchStatus = this.renewalBatchWrapper?.renewalBatch?.batchStatus;

    if (
      this.isTieringEnabled &&
      Array.isArray(details) &&
      details.length > 0 &&
      details.every(d => d.lob === 'Medical') &&
      (batchStatus === SubmissionStatus.SUCCESS || batchStatus === SubmissionStatus.PARTIAL || details.every(d => d?.source === 'RARE')) &&
      this.renewalBatchWrapper?.renewalBatch?.id
    ) {
      const uniqueCombo = new Set(
        details.map(d => [d.state, d.marketSegment, d.fundingType, d.renewalDate].join('|'))
      );
      const allValid = details.every(d => {
        const allowed = this.tieringConfig?.[d.marketSegment];
        return Array.isArray(allowed) && allowed.includes(d.fundingType);
      });
      this.isTieringInputEnabled = allValid && uniqueCombo.size === 1;
      if(this.renewalBatchWrapper?.renewalBatch?.batchOrigin == BATCH_ORIGIN.AUTO_RUN_BATCH && this.disbleBulkAdj) {
        this.isTieringInputEnabled = false;
      }
    } else {
      this.isTieringInputEnabled = false;
      if(this.activeTab === 'TIERING') {
        this.setActiveTab("BATCH");
      }
    }
    // Disable tiering input if tieringStatus is not "Completed" or "Failed"
    // OR if any renewalBatchDetail does not have quoteRenewalStatus key
    const batch = this.renewalBatchWrapper?.renewalBatch ?? {};
    const batchDetails = this.renewalBatchWrapper?.renewalBatchDetails ?? [];
    const missingQuoteRenewalStatus =  batchDetails.every(detail => !detail.hasOwnProperty('quoteRenewalStatus'));
    if (
      !(!('tieringStatus' in batch) ||
      batch.tieringStatus === "Completed" ||
      batch.tieringStatus === "Failed") ||
      missingQuoteRenewalStatus
    ) {
      this.disableTieringInput = true;
    } else {
      this.disableTieringInput = false;
    }
    if(!this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput?.selectedSnapMonthYear){
        this.disableTierDropdownOption = true;
    }
  }

  enableQuoteOptionsData() {
    if (StringUtils.isEqual(this.selectedLOB, CommonConstants.Medical)) {
      this.enableQuoteOptions = this.renewalBatchWrapper?.renewalBatchDetails?.some((detail: { state: string, included?: boolean, alternateQuotes?: any[] }) =>
          (detail?.alternateQuotes?.length ?? 0) > 0
          && (
            detail.included ||
            detail.alternateQuotes?.some(
              (quote) =>
                (quote.fundingOptions['ABF']?.isEnabled && quote.fundingOptions['ABF'] && quote.fundingOptions['ABF']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
                (quote.fundingOptions['FI']?.isEnabled && quote.fundingOptions['FI'] && quote.fundingOptions['FI']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
                (quote.fundingOptions['ACA']?.isSelected && quote.fundingOptions['ACA'] && quote.fundingOptions['ACA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
                (quote.fundingOptions['MEWA']?.isEnabled && quote.fundingOptions['MEWA'] && quote.fundingOptions['MEWA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED)
            )
          )
      );
      this.quoteOptionsData = this.renewalBatchWrapper?.renewalBatchDetails?.filter((detail: { state: string, included?: boolean, alternateQuotes?: any[] }) =>
        (detail.alternateQuotes?.length ?? 0) > 0
        && (
          detail.included ||
          detail.alternateQuotes?.some(
            (quote) =>
              (quote.fundingOptions['ABF']?.isEnabled && quote.fundingOptions['ABF'] && quote.fundingOptions['ABF']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['FI']?.isEnabled && quote.fundingOptions['FI'] && quote.fundingOptions['FI']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['ACA']?.isSelected && quote.fundingOptions['ACA'] && quote.fundingOptions['ACA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['MEWA']?.isEnabled && quote.fundingOptions['MEWA'] && quote.fundingOptions['MEWA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED)
          )
        ));
      this.buildQuoteOptionsDataMap();
    } else if (StringUtils.isEqual(this.selectedLOB, CommonConstants.Vision) || StringUtils.isEqual(this.selectedLOB, CommonConstants.Dental)) {
      this.enableQuoteOptions = this.renewalBatchWrapper?.renewalBatchDetails?.some((detail: { state: string, included?: boolean, alternateQuotes?: any[] }) =>
        (detail?.alternateQuotes?.length ?? 0) > 0
        && (
          detail.included ||
          detail.alternateQuotes?.some(
            (quote) =>
              (quote.fundingOptions['FI']?.isEnabled && quote.fundingOptions['FI'] && quote.fundingOptions['FI']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['ACA']?.isEnabled && quote.fundingOptions['ACA'] && quote.fundingOptions['ACA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED)
          )
        ));
      this.quoteOptionsData = this.renewalBatchWrapper?.renewalBatchDetails?.filter((detail: { state: string, included?: boolean, alternateQuotes?: any[] }) =>
        (detail.alternateQuotes?.length ?? 0) > 0
        && (
          detail.included ||
          detail.alternateQuotes?.some(
            (quote) =>
              (quote.fundingOptions['FI']?.isEnabled && quote.fundingOptions['FI'] && quote.fundingOptions['FI']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['ACA']?.isEnabled && quote.fundingOptions['ACA'] && quote.fundingOptions['ACA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED)
          )
        ));
      this.buildQuoteOptionsDataMap();
    }
  }

  showSubmitOptions() {
    this.detailsByFileUpload = this.renewalBatchWrapper.renewalBatchDetails[0]?.uploadStatus != undefined;
    this._visibleColumnsDirty = true;
    if (!this.renewalBatchWrapper.renewalBatch['id'] || this.selectedMode === 'fileUpload') {
      this.selectedSubmitOptions = ['ORIGNAL_QUOTES'];
    }
    if(StringUtils.isEqual(this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType, CommonConstants.ACA) || (StringUtils.isEqual(this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType, CommonConstants.MEWA) && !this.mewaOriginalQuoteEnabled)) {
      this.selectedSubmitOptions = this.selectedSubmitOptions?.filter((option: string) => option !== 'ORIGNAL_QUOTES');
    }
    this.batchSubmitOptions.forEach((option: { label: string; value: string; enableQuoteOptions?: boolean }) => {
      if (option.value === 'ALTERNATE_QUOTES') {
        option.enableQuoteOptions = this.enableQuoteOptions;
      } else {
        option.enableQuoteOptions = true;
      }
    });
    this.batchSubmitOptions = this.batchSubmitOptions.filter((option: { label: string; value: string; enableQuoteOptions?: boolean }) => option.enableQuoteOptions);
    if (!this.detailsByFileUpload && (StringUtils.isEqual(this.selectedLOB, CommonConstants.Vision) || StringUtils.isEqual(this.selectedLOB, CommonConstants.Dental))) {
      this.batchSubmitOptions = this.batchSubmitOptions.filter((option: { label: string; value: string; enableQuoteOptions?: boolean }) => option.value === 'ALTERNATE_QUOTES');
    }
    if (
      this.selectedLOB && this.renewalBatchWrapper?.renewalBatchDetails[0]?.marketSegment === CommonConstants.LG &&
      Array.isArray(this.specialtyLobsEnabledForBatchSubmission) &&
      (this.specialtyLobsEnabledForBatchSubmission.includes(this.selectedLOB) ||
      (this.selectedMode === 'fileUpload' || this.detailsByFileUpload))
    ) {
      if((StringUtils.isEqual(this.selectedLOB, CommonConstants.SuppHealth) && this.enableSendToOppForSuppHealth)
        || (StringUtils.isEqual(this.selectedLOB, CommonConstants.Vision) && this.enableSendToOppForVision)
        || (StringUtils.isEqual(this.selectedLOB, CommonConstants.Dental) && this.enableSendToOppForDental)){
        this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS.filter((option: { label: string; value: string; enableQuoteOptions?: boolean }) => option.value === 'ORIGNAL_QUOTES' || option.value === 'OPP_CREATION');
        if((StringUtils.isEqual(this.selectedLOB, CommonConstants.SuppHealth) && this.enableSendToOppForSuppHealth)){
          this.selectedSubmitOptions = ['ORIGNAL_QUOTES'];
        }
      }
      else{
      this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS.filter((option: { label: string; value: string; enableQuoteOptions?: boolean }) => option.value === 'ORIGNAL_QUOTES');
      this.selectedSubmitOptions = ['ORIGNAL_QUOTES'];
    }
    }
    if (this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType === 'ACA' || (this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType === 'MEWA' && !this.mewaOriginalQuoteEnabled)) {
      this.batchSubmitOptions = this.batchSubmitOptions.filter((option: { label: string; value: string; enableQuoteOptions?: boolean }) => option.value !== 'ORIGNAL_QUOTES');
      if(this.batchSubmitOptions.length === 1) {
        this.selectedSubmitOptions = [this.batchSubmitOptions[0].value];
      }
    }

    if (this.detailsByFileUpload || (this.selectedMode && this.selectedMode === 'fileUpload')) {
      this.batchSubmitOptions = this.batchSubmitOptions.filter((option: { label: string; value: string; enableQuoteOptions?: boolean }) => option.value === 'ORIGNAL_QUOTES');
    }

    if (this.showSendToOppBasedOnConfig()) {
      const hasOppCreation = this.batchSubmitOptions.some((option: { label: string; value: string; enableQuoteOptions?: boolean }) => option.value === 'OPP_CREATION');
      if (!hasOppCreation) {
        this.batchSubmitOptions.push({
          label: 'Opp Creation',
          value: 'OPP_CREATION'
        });
      }
    }

    //Filter to remove invalid options selected by default
    this.selectedSubmitOptions = this.selectedSubmitOptions.filter(val => this.batchSubmitOptions.some(batchOption => batchOption.value === val));
  }

  processRenewalBatchSaveResponse(response: any) {
    let alertMsg: string;
    this.renewalBatchWrapper = response;
    this.buildBatchDetailsMap();
    this.convertTieringToPercentage();
    this.listOfGroupsWithOverrides = [];
    if (this.renewalBatchWrapper.renewalBatchDetails.length) {
      this.selectedMode = null;
      alertMsg = 'Renewal Batch Saved Successfully.';
      this.getAlternetQuoteStatus(this.renewalBatchWrapper);
      this.initializeABFCommissionDefaults();
      this.isSaveFlow = true;
      this.detailsByFileUpload = this.renewalBatchWrapper.renewalBatchDetails[0].uploadStatus != undefined;
      this._visibleColumnsDirty = true;
      this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
      this.hideAlertVisibility();
      this.first = 0;
      window.scroll(0, 0);
      let originalGroupData = RenewalsUtil.updateRenewalBatchColumns(this.quoteReason, this.renewalBatchColumns);
      this.showOriginalGroupNumber = originalGroupData.showOriginalGroupNumber;
      this.renewalBatchColumns = originalGroupData.batchColumns;
      this.cdRef.markForCheck();
    } else {
      alertMsg = 'No details associated with Batch!';
      this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
      this.hideAlertVisibility();
      this.first = 0;
      this.cdRef.markForCheck();
      return;
    }
  }

  initializeABFCommissionDefaults() {
    this.renewalBatchWrapper?.renewalBatchDetails?.forEach((detail: any) => {
      if (detail.lob === 'Medical' && detail.fundingType === 'ACA') {
        detail.alternateQuotes?.forEach((alternateQuote: any) => {
          if ((alternateQuote.marketSegment === 'SG' || alternateQuote.marketSegment === 'LG') && alternateQuote.fundingOptions?.ABF) {
            if (!alternateQuote.fundingOptions.ABF.commissionValue) {
              alternateQuote.fundingOptions.ABF.commissionValue = this.commonService.getDefaultCommissionValue();
            }
            if (!alternateQuote.fundingOptions.ABF.commissionType) {
              alternateQuote.fundingOptions.ABF.commissionType = this.commonService.getDefaultCommissionType();
            }
          }
        });
      }
    });
  }

  private _computeVisibleColumns(): void {
    if (!this._visibleColumnsDirty) {
      return;
    }
    this._visibleColumnsDirty = false;

    const fundingType = this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType;
    const isAcaMewa = fundingType === 'ACA' || fundingType === 'MEWA';
    const isAsoMewaAca = fundingType === 'ASO' || fundingType === 'MEWA' || fundingType === 'ACA';
    const isFI = fundingType === 'FI' || this.isFIRewewalSearch;

    const ACA_MEWA_VISIBLE = new Set([
      'Source System', 'Group Number', 'Group Name', 'State', 'Renewal Date',
      'LOBs - FA Type', 'Market Segment', 'MBU', 'Subs Count',
      'Renewal Opportunity ID', 'Renewal Quote ID', 'Submission Status', 'Renewal Quote Status'
    ]);
    const ASO_MEWA_ACA_HIDDEN = new Set([
      'SSL', 'ASL', 'Group Refund', 'Comm Value', 'Comm Type',
      'Renewal Opportunity ID', 'Renewal Quote ID', 'Renewal Quote Status', 'Submission Status'
    ]);
    const SSL_ASL_REFUND = new Set(['ASL', 'SSL', 'Group Refund']);

    this._cachedVisibleColumns = new Set(
      this.renewalBatchColumns
        .map((col: any) => col.header)
        .filter((colHeader: string) => {
          if (colHeader === 'Original Group Number') return !!this.quoteReason;
          if (isAcaMewa) return ACA_MEWA_VISIBLE.has(colHeader);
          if (colHeader === 'File Upload Status') return !!this.detailsByFileUpload;
          if (SSL_ASL_REFUND.has(colHeader)) {
            if (this.detailsByFileUpload) return false;
            if (isFI) return false;
          }
          if (ASO_MEWA_ACA_HIDDEN.has(colHeader)) return !isAsoMewaAca;
          return true;
        })
    );
  }

  isColumnVisible(colHeader: string): boolean {
    this._computeVisibleColumns();
    return this._cachedVisibleColumns.has(colHeader);
  }

  saveRenewalBatchDetails() {
    let alertMsg;
    this.errorExist = false;
    this.isPopupVisible = false;
    this.batchSaveGroupSubmitted = true;
    if(!this.renewalBatchWrapper?.renewalBatch?.id) {
      this.hasDeletedGroupsInBatch = false;
    }
    this.removeAlertMsg();
    if (this.validateRenewalBatchDetails()) {
      return;
    }
    this.setLoaderVisibility(true);
    let renewalBatchWrapper = JSON.parse(JSON.stringify(this.renewalBatchWrapper));
    this.isAutoRunBatch = this.autorunCheckboxDisplay() ? this.isAutoRunBatch : false;
    renewalBatchWrapper.renewalBatch = RenewalsUtil.buildRenewalWrapper(
      renewalBatchWrapper,
      this.batchSaveGroup.value.batchName.trim(),
      this.renewalBatchWrapper?.renewalBatch?.batchStatus ? this.renewalBatchWrapper.renewalBatch.batchStatus : SubmissionStatus.NOT_SUBMITTED,
      this.fileUploadStatus,
      this.quoteReason,
      this.isAutoRunBatch,
      this.selectedAssociationCodes
    );

    renewalBatchWrapper.renewalBatch.actionPerformed = 'save';

    this.setBatchOriginInRenewalBatchDetails(renewalBatchWrapper, this.isAutoRunBatch);

    this.updateOverRidesToBatchDetails(renewalBatchWrapper);
    renewalBatchWrapper.renewalBatchDetails.forEach((detail) => {
      detail.quoteReason = renewalBatchWrapper.renewalBatch.quoteReason;
      if (typeof detail.priorGroupNumbers === 'string' && !detail.priorGroupNumbers.isEmpty) {
        detail.priorGroupNumbers = detail.priorGroupNumbers?.split(',').map((priorGroupNumbers) => priorGroupNumbers.trim());
      } else if (Array.isArray(detail.priorGroupNumbers)) {
        detail.priorGroupNumbers = detail.priorGroupNumbers.map((priorGroupNumber) => priorGroupNumber.trim());
      } else {
        delete detail.priorGroupNumbers;
      }
    });
    if (renewalBatchWrapper?.renewalBatch?.tieringInfo?.tieringInput) {
      // Divide only overallRateIncrease, minIncrease, maxIncrease in formulaInput and uwTieredInput by 100 if they exist and are numbers
      const tieringInput = renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput;
      ['formulaInput', 'uwTieredInput'].forEach(key => {
      if (tieringInput[key]) {
        ['overallRateIncrease', 'minIncrease', 'maxIncrease'].forEach(field => {
        const value = tieringInput[key][field];
        if (typeof value === 'number') {
          tieringInput[key][field] = value / 100;
        } else if (!isNaN(Number(value)) && value !== '') {
          tieringInput[key][field] = Number(value) / 100;
        }
        });
      }
      });
    }
    this.renewalsService.saveRenewalDetails(renewalBatchWrapper).subscribe(
      (response) => {
        this.setLoaderVisibility(false);
        if (response) {
          this.repeatingGroupsSet = new Set<string>();
          if (response.exceptions && response.repeatingGroupsAndBatchNames) {
            this.handleRepeatingGroupsException(response);
          } else {
            this.processRenewalBatchSaveResponse(response);
            this.checkBulkAdjStatus();
            this.enableQuoteOptionsData();
            this.enableTieringTab();
          }
        } else {
          alertMsg = 'No response from save service - Please contact RARE Support Team';
          this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
          this.hideAlertVisibility();
        }
      },
      (error) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(true, AlertType.WARNING, error.exceptions[0].message);
        this.hideAlertVisibility();
      }
    );
  }

  setBatchOriginInRenewalBatchDetails(renewalBatchWrapper: any, isAutoRunBatch: boolean) {
    const batchOriginValue = isAutoRunBatch ? BATCH_ORIGIN.AUTO_RUN_BATCH : BATCH_ORIGIN.USER_BATCH;
    renewalBatchWrapper.renewalBatchDetails.forEach((detail: any) => {
      detail.batchOrigin = batchOriginValue;
    });
  }

  //We set the user details in the renewal batch details here using logged user info to ensure that only logged user (or default) is set in the user info in case of submission from UI
  //This is specifically to ensure that autoRunBatches submitted by scheduler initially and then submitted by the user from UI will have the logged user info
  //and not the scheduler system user details as once its submitted from UI the userInfo should be of the submitter
  setUserInfoInRenewalBatchDetails(renewalBatchWrapper: any) {
    const fullName =
      renewalBatchWrapper?.renewalBatch?.loggedUserName || this.authenticationService.getUserName() ? this.authenticationService.getUserName() : 'Local User';
    const usDomainId =
      renewalBatchWrapper?.renewalBatch?.loggedUserID || this.authenticationService.getUserID() ? this.authenticationService.getUserID() : 'Local User ID';
    renewalBatchWrapper.renewalBatchDetails.forEach((detail: any) => {
      detail.userInfo = {
        fullName: fullName,
        usDomainId: usDomainId
      };
    });
  }

  private buildQuoteOptionsDataMap(): void {
    this.quoteOptionsDataMap.clear();
    if (this.quoteOptionsData) {
      this.quoteOptionsData.forEach((item: any) => {
        if (item?.groupNumber != null) {
          const key = String(item.groupNumber).trim().toLowerCase();
          const existing = this.quoteOptionsDataMap.get(key);
          if (existing) {
            existing.push(item);
          } else {
            this.quoteOptionsDataMap.set(key, [item]);
          }
        }
      });
    }
  }

  private buildBatchDetailsMap() {
    this._visibleColumnsDirty = true;
    this.batchDetailsMap.clear();
    this.alternateBatchDetailsMap.clear();
    this.renewalBatchWrapper.renewalBatchDetails.forEach((detail: RenewalBatchDetails ) => {
      const key = `${detail.batchID}_${detail.groupNumber}_${detail.opportunityID}_${detail.quoteHeaderID}_${detail.lob}_${detail.fundingType}`;
      this.batchDetailsMap.set(key, detail);
      
      const alternateKey = `${detail.batchID}_${detail.groupNumber}_${detail.opportunityID}_${detail.lob}`;
      this.alternateBatchDetailsMap.set(alternateKey, detail);
    });
  }

  
  private scheduleChangeDetection() {
    if (!this.changeDetectionScheduled) {
      this.changeDetectionScheduled = true;
      this.ngZone.runOutsideAngular(() => {
        requestAnimationFrame((timestamp) => {
          if (timestamp - this.lastRender >= 100) {
            this.changeDetectionScheduled = false;
            this.lastRender = timestamp;
            this.ngZone.run(() => {
              this.cdRef.markForCheck();
            });
          } else {
            // Re-arm so the trailing update of a burst is not dropped.
            this.changeDetectionScheduled = false;
            this.scheduleChangeDetection();
          }
        });
      });
    }
  }

  isDummyEvent(payload: any) {
    return payload && payload.dummyEvent && payload.dummyEvent == 'true';
  }

  processRenewalBatchSubmissionEvent(event: any, batchName: string, ignoreAlternates?: boolean) {
    if (event && event.data) {
      let eventData = JSON.parse(event.data);
      let payload = eventData.payload;
      if (this.isDummyEvent(payload)) {
        return;
      }
      let eventName = eventData.eventName;
      let eventKey = batchName + this.sseProcess.SUBMISSION + eventName + payload.uniqueRecordID;
      if (!this.receivedBatchEvents.has(eventKey)) {
        const lookupKey = `${payload.batchID}_${payload.groupNumber}_${payload.opportunityID}_${payload.quoteHeaderID}_${payload.lob}_${payload.fundingType}`;
        const batchDetail = this.batchDetailsMap.get(lookupKey);
        
        if (batchDetail) {
          batchDetail.submissionErrors = payload.submissionErrors;
          batchDetail.specialtyErrors = payload.specialtyErrors;
          batchDetail.submissionFailCheckPoint = payload.submissionFailCheckPoint;
          batchDetail.submissionStatus = payload.submissionStatus;
          batchDetail.opportunityID = payload.opportunityID;
          batchDetail.quoteHeaderID = payload.quoteHeaderID;
          batchDetail.isSubmitted = payload.isSubmitted;
          batchDetail.isUnifiedPayloadSubmission = payload.isUnifiedPayloadSubmission;
          batchDetail.isQueuedForDataGathering = payload.isQueuedForDataGathering;
          batchDetail.isRequestCreated = payload.isRequestCreated;
          batchDetail.isSubmittedToGateWay = payload.isSubmittedToGateWay;
          batchDetail.isSpecialtySubmittedToGateWay = payload.isSpecialtySubmittedToGateWay;
          batchDetail.specialtySubmittedStatus = payload.specialtySubmittedStatus;
          batchDetail.invalidGroupNumbersForMerge = payload?.invalidGroupNumbersForMerge;
          batchDetail.inRateGuarantee = payload?.inRateGuarantee;
        }
        
        this.receivedBatchEvents.add(eventKey);
        this.scheduleChangeDetection();
      }
      if (payload?.alternateQuotes && !ignoreAlternates) {
        const alternateKey = `${payload.batchID}_${payload.groupNumber}_${payload.opportunityID}_${payload.lob}`;
        const batchDetail = this.alternateBatchDetailsMap.get(alternateKey);
        
        if (batchDetail) {
          this.updateAlternateBatchData(payload, eventKey);
        }
      }
    }
  }

  processBatchClosure(batchName: string, sseProcess: string) {
    const prefix = batchName + sseProcess;
    this.receivedBatchEvents.forEach(event => {
      if (event.startsWith(prefix)) {
        this.receivedBatchEvents.delete(event);
      }
    });
    this.completedBatchRequests = this.completedBatchRequests.filter((cmpltBatchReq) => !cmpltBatchReq.startsWith(prefix));
  }

  confirmWithoutAltMrkt(confirm: boolean) {
    if (confirm) {
      this.submitRenewalBatchDetails(true, true)
    }
    this.displayALTMrktSubmissionWarn = false;
  }

  submitRenewalBatchDetails(proceedWithoutAlt: boolean = false, proceedWithoutOppCreationCountCheck: boolean = false) {
    let alertMsg;
    this.errorExist = false;
    this.isPopupVisible = false;
    this.batchSaveGroupSubmitted = true;
    if(!this.renewalBatchWrapper?.renewalBatch?.id) {
      this.hasDeletedGroupsInBatch = false;
    }
    this.removeAlertMsg();
    let batchName = this.batchSaveGroup.value.batchName;
    const altQuoteSubmissionChecked = this.selectedSubmitOptions?.includes('ALTERNATE_QUOTES') ?? false;
    const hasOppCreationSubmissionChecked = (!proceedWithoutOppCreationCountCheck && (this.selectedSubmitOptions?.includes('OPP_CREATION') || this.selectedSubmitOptions?.includes('ALTERNATE_QUOTES'))) ?? false;
    if (this.validateRenewalBatchDetails(altQuoteSubmissionChecked, hasOppCreationSubmissionChecked)) {
      return;
    }
    if (!proceedWithoutAlt) {
      let altMrktData = this.renewalBatchWrapper?.renewalBatchDetails?.filter((detail) =>
        ((detail as { included?: boolean })?.included &&
          (detail as { alternateQuotes?: any[] })?.alternateQuotes?.some(
            (quote) =>
              (quote.fundingOptions['ABF']?.isEnabled && quote.fundingOptions['ABF'] && quote.fundingOptions['ABF']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['FI']?.isEnabled && quote.fundingOptions['FI'] && quote.fundingOptions['FI']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['ACA']?.isEnabled && quote.fundingOptions['ACA'] && quote.fundingOptions['ACA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED) ||
              (quote.fundingOptions['MEWA']?.isEnabled && quote.fundingOptions['MEWA'] && quote.fundingOptions['MEWA']?.submissionStatus !== QuoteSubmissionStatus.NOT_SUBMITTED)
          )
        )
      );
      if (
        this.selectedSubmitOptions &&
        !this.selectedSubmitOptions.includes("ALTERNATE_QUOTES") &&
        this.selectedSubmitOptions.includes("ORIGNAL_QUOTES") &&
        altMrktData && altMrktData.length > 0
      ) {
        this.displayALTMrktSubmissionWarn = true;
        return;
      }
    }
    this.setLoaderVisibility(true);
    this.isAutoRunBatch = this.autorunCheckboxDisplay() ? this.isAutoRunBatch : false;
    let renewalBatchWrapper = JSON.parse(JSON.stringify(this.renewalBatchWrapper));
    // Only for already submitted batches (batch id != null), filter included === true for submission
    let detailsToSubmit = this.renewalBatchWrapper.renewalBatchDetails;
    if (renewalBatchWrapper.renewalBatch && renewalBatchWrapper.renewalBatch.id != null) {
      detailsToSubmit = renewalBatchWrapper.renewalBatchDetails.filter(
        detail => detail.included === true
      );
    }
    // After submission, only keep checkboxes checked for submitted items
    const submittedIds = new Set(detailsToSubmit.map(d => d.groupNumber));
    if (renewalBatchWrapper.renewalBatch && !StringUtils.isEmpty(renewalBatchWrapper.renewalBatch.id)) {
      (this.renewalBatchWrapper.renewalBatchDetails as any[]).forEach((detail: any) => {
        detail.included = submittedIds.has(detail.groupNumber);
      });
    }
    // Reset header checkbox after submission only if test batch is selected
    if (this.quoteReason) {
      this.checkAllDetails = false;
    }
    // Use detailsToSubmit for submission, keep UI state untouched
    renewalBatchWrapper.renewalBatchDetails = detailsToSubmit;
    renewalBatchWrapper.renewalBatch = RenewalsUtil.buildRenewalWrapper(
      renewalBatchWrapper,
      batchName.trim(),
      SubmissionStatus.SUBMITTED,
      this.fileUploadStatus,
      this.quoteReason,
      this.isAutoRunBatch,
      this.selectedAssociationCodes
    );

    this.setBatchOriginInRenewalBatchDetails(renewalBatchWrapper, this.isAutoRunBatch);
    this.setUserInfoInRenewalBatchDetails(renewalBatchWrapper);

    renewalBatchWrapper.renewalBatchDetails.forEach((detail) => {
      detail.userSubmitActions = this.selectedSubmitOptions;
      // If userSubmitActions contains 'ALTERNATE_QUOTES' anywhere, set batchStatusForAlternates to 'Submitted'
      if (Array.isArray(detail.userSubmitActions) && detail.userSubmitActions.includes('ALTERNATE_QUOTES')) {
        renewalBatchWrapper.renewalBatch.batchStatusForAlternates = 'Submitted';
      }
      if (typeof detail.priorGroupNumbers === 'string' && !detail.priorGroupNumbers.isEmpty) {
        detail.priorGroupNumbers = detail.priorGroupNumbers?.split(',').map((priorGroupNumbers) => priorGroupNumbers.trim());
      }
    });

    renewalBatchWrapper.renewalBatch.actionPerformed = 'submit';
    if (renewalBatchWrapper?.renewalBatch?.tieringInfo?.tieringInput) {
      // Divide only overallRateIncrease, minIncrease, maxIncrease in formulaInput and uwTieredInput by 100 if they exist and are numbers
      const tieringInput = renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput;
      ['formulaInput', 'uwTieredInput'].forEach(key => {
      if (tieringInput[key]) {
        ['overallRateIncrease', 'minIncrease', 'maxIncrease'].forEach(field => {
        const value = tieringInput[key][field];
        if (typeof value === 'number') {
          tieringInput[key][field] = value / 100;
        } else if (!isNaN(Number(value)) && value !== '') {
          tieringInput[key][field] = Number(value) / 100;
        }
        });
      }
      });
    }
    this.updateOverRidesToBatchDetails(renewalBatchWrapper);
    RenewalsUtil.checkDeclineReasonLocalStorage(renewalBatchWrapper);
    this.renewalsService.submitRenewalBatch(renewalBatchWrapper).subscribe(
      (response) => {
        this.setLoaderVisibility(false);
        if (response) {
          this.repeatingGroupsSet = new Set<string>();
          if (response.exceptions && response.repeatingGroupsAndBatchNames) {
            this.handleRepeatingGroupsException(response);
          } else {
            this.processRenewalBatchSaveResponse(response);
            // After successful submission, update checkboxes: only submitted items remain checked
            const submittedIds = new Set((this.renewalBatchWrapper.renewalBatchDetails as any[]).filter(d => d.included).map(d => d.id));
            if (renewalBatchWrapper.renewalBatch && !StringUtils.isEmpty(renewalBatchWrapper.renewalBatch.id)) {
              (this.renewalBatchWrapper.renewalBatchDetails as any[]).forEach((detail: any) => {
                detail.included = submittedIds.has(detail.id);
              });
            }
            // reset alternate quotes data to only include submitted items
            this.quoteOptionsData = this.renewalBatchWrapper?.renewalBatchDetails?.filter((detail: { state: string, included?: boolean, alternateQuotes?: any[] }) =>
              (detail.alternateQuotes?.length ?? 0) > 0);
            this.buildQuoteOptionsDataMap();
            this.cdRef.markForCheck();
            if (StringUtils.isEqual(this.selectedLOB, CommonConstants.SuppHealth)) {
              // Collect selected group numbers (included checkboxes)
              const selectedGroups = (this.renewalBatchWrapper.renewalBatchDetails || [])
                .filter((g: any) => g.included)
                .map((g: any) => g.groupNumber);
              this.router.navigate(['group/batch/create-batch-supp-health'], {
                queryParams: {
                  batchId: response.renewalBatch.id,
                  batchStatus: response.renewalBatch.batchStatus,
                  batchName: response.renewalBatch.batchName,
                  headerName: 'Renewal Batch',
                  fileUploadStatus: response.renewalBatch.fileUploadStatus,
                  quoteReason: response.renewalBatch.quoteReason,
                  description: response.description,
                  submissionRedirected: true,
                  selectedGroups: selectedGroups.join(',')
                }
              });
            }
            this.showTabs();
            this.enableTieringTab();
            if (response['description'] && response['description'] == 'No Records Found') {
              alertMsg = 'No Renewal Groups found.';
              this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
              this.hideAlertVisibility();
              return;
            }
            alertMsg = 'Renewal Batch Submission initiated Successfully.';
            this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
            this.first = 0;
            window.scroll(0, 0);
            if (!(StringUtils.isEqual(CommonConstants.ASO, this.fundTypeFromDetails))) {
              var source = this.commonService.listenForStream(response['description']);
              this.listenRenewalBatchSubmissionEvents(source, batchName);
              var quoteStatusSource = this.commonService.listenForStream(this.renewalBatchWrapper.renewalBatch.statusEmitterID);
              this.listenRenewalBatchQuoteStatusEvents(quoteStatusSource, batchName);
              this.isTooltipVisible = true;
            }
          }
        } else {
          alertMsg = 'Something Went wrong !';
          this.setAlertVisibility(true, AlertType.WARNING, alertMsg);
        }
        this.hideAlertVisibility();
        // Ensure header checkbox is updated after submission
        this.verifyCheckAllDetails();
      },
      (error) => {
        this.showTab = false;
        console.error(error);
        this.setLoaderVisibility(false);
        this.setAlertVisibility(true, AlertType.WARNING, error ? (error.exceptions[0] ? error.exceptions[0].message : '') : '');
        this.hideAlertVisibility();
        this.verifyCheckAllDetails();
      }
    );
    this.groupNumberClicked = false;
  }

  ngOnDestroy() {
    // Close all EventSource instances
    this.eventSources.forEach((source) => source.close());
    this.receivedAlternateBatchEvents.clear();
    this.receivedAlternateQuoteEvents = [];
    this.receivedBatchEvents.clear();
  }

  listenRenewalBatchSubmissionEvents(source: any, batchName: string) {
    this.eventSources.push(source); // Store the EventSource reference
    if (!(StringUtils.isEqual(CommonConstants.ASO, this.fundTypeFromDetails))) {
      this.ngZone.runOutsideAngular(() => {
        source.addEventListener('BATCH_RENEWAL_REQUEST_SUBMITTED', (event: any) => {
          this.processRenewalBatchSubmissionEvent(event, batchName);
        });
        source.addEventListener('BATCH_RENEWAL_REQUEST_QUEUED', (event: any) => {
          this.processRenewalBatchSubmissionEvent(event, batchName);
        });
        source.addEventListener('BATCH_RENEWAL_REQUEST_PAYLOAD_CREATION', (event: any) => {
          let eventData = JSON.parse(event.data);
          let payload = eventData.payload;
          if (this.isDentaltieringEnabled || this.isVisiontieringEnabled) {
            this.batchDetailsPayload?.push(payload);
          }
          this.processRenewalBatchSubmissionEvent(event, batchName);
        });
        source.addEventListener('UNIFIED_PAYLOAD_SUBMIT_TO_OPPORTUNITIES', (event: any) => {
          this.processRenewalBatchSubmissionEvent(event, batchName, true);
        });
        source.addEventListener('BATCH_RENEWAL_REQUEST_GATEWAY_SUBMISSION', (event: any) => {
          this.processRenewalBatchSubmissionEvent(event, batchName);
        });
        source.addEventListener('BATCH_RENEWAL_REQUEST_SPECIALTY_SUBMISSION', (event: any) => {
          this.processRenewalBatchSubmissionEvent(event, batchName, true);
        });
        source.addEventListener('BATCH_RENEWAL_REQUEST_SINGLE_COMPLETE', (event: any) => {
          if (event && event.data) {
            var eventData = JSON.parse(event.data);
            var payload = eventData.payload;
            var completedBatchRequestId = batchName + this.sseProcess.SUBMISSION + eventData.eventName + payload.uniqueRecordID;
            if (!this.completedBatchRequests.includes(completedBatchRequestId)) {
              this.completedBatchRequests.push(completedBatchRequestId);
            }
            this.scheduleChangeDetection();
          }
        });
        source.addEventListener('BATCH_RENEWAL_PROCESS_COMPLETION_TRIGGER', (event: any) => {
          if (event && event.data) {
            var eventData = JSON.parse(event.data);
            var payload = eventData.payload;
            var payloadBatchStatus = payload.batchStatus;
            this.renewalBatchWrapper.renewalBatch['batchStatus'] = payloadBatchStatus;
            this.ngZone.run(() => {
              this.setAlertVisibility(false);
              this.getAlternateStatusFromEvent(event, this.renewalBatchWrapper);
              this.enableTieringTab();
              this.processBatchClosure(batchName, this.sseProcess.SUBMISSION);
              this.cdRef.markForCheck();
            });
          }
        });
        source.addEventListener('BATCH_RENEWAL_PROCESS_COMPLETE', (event: any) => {
          source.close();
          this.ngZone.run(() => this.processBatchClosure(batchName, this.sseProcess.SUBMISSION));
        });
        source.addEventListener('NO_EVENTS', (event: any) => {
          source.close();
          this.ngZone.run(() => this.processBatchClosure(batchName, this.sseProcess.SUBMISSION));
        });
      });
    }
  }

  callTieringAPIforVisDenOnCondition() {
    return (((this.isDentaltieringEnabled && this.renewalBatchWrapper?.renewalBatch?.lobs.includes(CommonConstants.Dental)) || (this.isVisiontieringEnabled && this.renewalBatchWrapper?.renewalBatch?.lobs.includes(CommonConstants.Vision))) && !this.detailsByFileUpload &&  this.batchDetailsPayload?.filter((data: { inRateGuarantee?: boolean }) => data?.inRateGuarantee === false).length > 0 && this.renewalBatchWrapper?.renewalBatchDetails?.filter((data: { marketSegment?: string }) => data?.marketSegment === 'LG').length > 0 &&  this.renewalBatchWrapper?.renewalBatchDetails?.filter((data: { userSubmitActions?: string[] }) => data?.userSubmitActions?.includes('ORIGNAL_QUOTES')).length > 0);
  }

  getAlternateStatusFromEvent(event, data) {
    const batchOrigin = data.renewalBatch?.batchOrigin;
    let altvalue = data.renewalBatch?.batchStatusForAlternates;
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      var payload = eventData.payload;
      var payloadBatchStatus = payload.batchStatus;
      // Use alternate status from event payload if present
      if (payload.batchStatusForAlternates !== undefined) {
        altvalue = payload.batchStatusForAlternates;
      }
      this.renewalBatchWrapper.renewalBatch['batchStatus'] = payloadBatchStatus;
      this.setAlertVisibility(false);
    }
    // Recalculate status/tooltip after event
    const details = (data.renewalBatchDetails || []).filter((d: any) => d.included === true);
    const actionsArr = details.map((d: any) => d.userSubmitActions || []);
    const allActions = [].concat(...actionsArr);
    const onlyAlternate = allActions.length > 0 && allActions.every((a: string) => a === 'ALTERNATE_QUOTES');
    const hasOriginal = allActions.includes('ORIGNAL_QUOTES');
    const hasAlternate = allActions.includes('ALTERNATE_QUOTES');
    if (batchOrigin === 'autoRunBatch') {
      this.batchStatusObj = { status: data.renewalBatch.batchStatus, tooltip: null };
    } else if (onlyAlternate) {
      this.batchStatusObj = { status: altvalue, tooltip: null };
    } else if (hasOriginal) {
      this.batchStatusObj = { status: data.renewalBatch.batchStatus, tooltip: hasAlternate ? altvalue : null };
    } else {
      this.batchStatusObj = { status: data.renewalBatch.batchStatus, tooltip: null };
    }
  }

  listenRenewalBatchQuoteStatusEvents(source: any, batchName: string) {
    this.eventSources.push(source); // Store the EventSource reference
    this.ngZone.runOutsideAngular(() => {
      source.addEventListener('BATCH_QUOTE_STATUS_RECEIVED', (event: any) => {
        this.processRenewalBatchQuoteStatusEvent(event, batchName);
      });
      source.addEventListener('BATCH_QUOTE_STATUS_TRACKING_COMPLETION_TRIGGER', (event: any) => {
        this.renewalBatchWrapper.renewalBatch.batchQuoteStatusEmitStatus = BatchQuoteStatusEmitStatus.COMPLETED;
        this.scheduleChangeDetection();
      });
      source.addEventListener('BATCH_QUOTE_STATUS_TRACKING_COMPLETE', (event: any) => {
        source.close();
        this.ngZone.run(() => {
          this.receivedAlternateQuoteEvents = [];
          this.processBatchClosure(batchName, this.sseProcess.QUOTESTATUSRETRIEVAL);
          this.fetchRenewalDetailsByBatch();
          if (this.callTieringAPIforVisDenOnCondition()) {
            this.renewalsService.callTieringAPIForLGVisDen(this.renewalBatchWrapper).subscribe(
              (response) => {
                if (response) {
                  if (response?.processID) this.listenToTieringEvents(response.processID, null);
                  if (response.exceptions) {
                    console.error('Error in tiering API call after submission:', response.exceptions[0].message);
                  } else if (response?.status?.code === 'success') {
                    console.log('Tiering API call successful after submission:', response);
                  }
                }
                this.cdRef.markForCheck();
              });
          }
        });
      });
      source.addEventListener('NO_EVENTS', (event: any) => {
        source.close();
        this.ngZone.run(() => this.processBatchClosure(batchName, this.sseProcess.QUOTESTATUSRETRIEVAL));
      });
      source.addEventListener('FAILED', (event: any) => {
        source.close();
        this.ngZone.run(() => this.processBatchClosure(batchName, this.sseProcess.QUOTESTATUSRETRIEVAL));
      });
    }); // end runOutsideAngular
  }

  processRenewalBatchQuoteStatusEvent(event: any, batchName: string) {
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      var payload = eventData.payload;
      const fundingType = payload.fundingType === CommonConstants.ASO
        ? [payload.fundingType, CommonConstants.MEWA]
        : [payload.fundingType];
      const matched = fundingType
        .map(ft => `${payload.batchID}_${payload.groupNbr}_${payload.opportunityID}_${payload.quoteHeaderID}_${payload.lob}_${ft}`)
        .map(key => this.batchDetailsMap.get(key))
        .find(detail => !!detail) as RenewalBatchDetails;
      if (matched && this.isNewStatusEvent(matched.submittedTimestamp, payload.statusEmittedTimestamp)) {
        if (
          matched.marketSegment == payload.marketSegment &&
          matched.isSSEQuoteStatusReceived == false
        ) {
          matched.quoteRenewalStatus = payload.status;
          matched.isSSEQuoteStatusReceived = payload.isSSEQuoteStatusReceived;
          matched.submittedTimestamp = payload.submittedTimestamp;
          matched.quoteErrors = payload.errors;
          matched.currentQuoteStatusBatchID = payload.batchID;
          matched.currentQuoteStatusBatchName = payload.batchName;
        }
        this.updateAlternateQuoteData(matched, payload);
      }
      if (this.showTab) {
        this.enableBulkAdjTab();
      }
      this.scheduleChangeDetection();
    }
  }

  isNewStatusEvent(submittedTimestamp: any, statusEmittedTimestamp: any) {
    if (submittedTimestamp == undefined) {
      return true;
    }
    var date1 = new Date(submittedTimestamp);
    var date2 = new Date(statusEmittedTimestamp);
    return date2 > date1;
  }

  validateRenewalBatchDetails(altSubmissionChecked: boolean = false, hasOppCreationSubmission: boolean = false): boolean {
    if (this.batchSaveGroup.invalid) return true;

    if (!this.renewalBatchWrapper.renewalBatchDetails.length) {
      this.setAlertVisibility(true, AlertType.WARNING, 'No details associated with Batch!');
      this.hideAlertVisibility();
      return true;
    }

    if(altSubmissionChecked) {
      const includedCount = this.renewalBatchWrapper.renewalBatchDetails.filter(groupDetail => {
        if(!groupDetail['included']) {
          return false;
        }
        const altQuotes: any[] = (groupDetail as any).alternateQuotes ?? [];
        for(let altDetails of altQuotes) {
          const fundingOptions = altDetails.fundingOptions;
          for(let key of Object.keys(altDetails.fundingOptions)) {
            if(fundingOptions[key].isSelected) {
              return true;
            }
          }
        }
      })?.length ?? 0;

      const thresholdLimitConfig = this.commonService.getBatchAltQuoteSubmitThreshold();
      const lob = this.renewalBatchWrapper.renewalBatchDetails[0]['lob'];
      const fundingType = this.renewalBatchWrapper.renewalBatchDetails[0]['fundingType'];
      
      const thresholdLimitCount = thresholdLimitConfig[lob]?.[fundingType] ?? -1;
      
      if(thresholdLimitCount > 0 && includedCount > thresholdLimitCount) {
        this.setAlertVisibility(true, AlertType.WARNING, `Maximum of ${thresholdLimitCount} groups can be submitted for alternate quotes at a time.`);
        return true;
      }
    }

    if(hasOppCreationSubmission) {
      const includedCount = this.renewalBatchWrapper.renewalBatchDetails.filter(groupDetail => groupDetail['included'] as boolean)?.length ?? 0;
      const thresholdLimitConfig = this.commonService.getBatchOppQuoteSubmitThreshold();
      const lob = this.renewalBatchWrapper.renewalBatchDetails[0]['lob'];
      const fundingType = this.renewalBatchWrapper.renewalBatchDetails[0]['fundingType'];
      
      const oppCreationSubmissionCount = thresholdLimitConfig[lob]?.[fundingType] ?? -1;
      
      if(oppCreationSubmissionCount > 0 && includedCount > oppCreationSubmissionCount) {
        this.confirmationService.confirm({
          message: `You are submitting over ${oppCreationSubmissionCount} groups to the opportunity screen, which may affect the duration of batch processing.`,
          header: 'Confirmation',
          key: 'createOppSubmissionConfirmation',
          acceptButtonStyleClass: 'dialog-button-icon',
          rejectButtonStyleClass: 'dialog-button-icon',
          accept: () => {
            this.submitRenewalBatchDetails(false, true);
          }
        });
        return true;
      }
    }

    if (this.overRideDetails) {
      const errors = [
        {
          condition: this.overRideDetails?.aslErrors?.length > 0 && this.overRideDetails?.refundPctErrors?.length > 0,
          message: 'Please enter valid values for ASL & Group refund.'
        },
        {
          condition: this.overRideDetails?.refundPctErrors?.length > 0,
          message: 'Please enter a valid value for Group refund.'
        },
        {
          condition: this.overRideDetails?.aslErrors?.length > 0,
          message: 'Please enter a valid value for ASL.'
        },
        {
          condition: this.overRideDetails?.commissionErrors?.length > 0,
          message: 'Please enter a valid value for Commission.'
        }
      ];

      for (let error of errors) {
        if (error.condition) {
          this.setAlertVisibility(true, AlertType.WARNING, error.message);
          this.hideAlertVisibility();
          return true;
        }
      }
    }
  }
  getFTSelection = (optionlabel, fundTypeFromDetails) => {
    if (!StringUtils.isEmpty(fundTypeFromDetails)) {
      return StringUtils.isEqual(optionlabel, fundTypeFromDetails);
    } else {
      return StringUtils.isEqual(optionlabel, CommonConstants.ABF);
    }
  }

  fetchRenewalDetailsByBatch() {
    const deletedGroupsFromStorage = localStorage.getItem('deletedGroups');
    this.deletedGroups = deletedGroupsFromStorage ? JSON.parse(deletedGroupsFromStorage) : this.deletedGroups;
    this.hasDeletedGroupsInBatch = false;
    this.errorExist = false;
    this.isPopupVisible = false;
    this.showLoader = true;
    let batchID = this.renewalBatchWrapper?.renewalBatch?.['id'];
    let batchStatus = this.renewalBatchWrapper?.renewalBatch?.['batchStatus'];
    if (!this.renewalBatchWrapper.renewalBatch || Object.keys(this.renewalBatchWrapper.renewalBatch).length === 0) {
      const matchingDeletedGroups = this.deletedGroups.filter(
        g => g.batchID === batchID && g.batchStatus === batchStatus
      );
      if (matchingDeletedGroups.length > 0) {
        this.renewalBatchWrapper.renewalBatchDetails = matchingDeletedGroups;
        
        this.tableDataExist = true;
        this.showLoader = false;
        return;
      }
    }

    this.renewalBatchWrapper.renewalBatch['batchStatus'] = this.submissionStatus.LOADING;
    this.renewalsService.fetchRenewalDetailsByBatch(batchID, batchStatus).subscribe(
      (data) => {
        if (data.renewalBatchDetails[0]?.fundingType) {
          this.fundTypeFromDetails = data.renewalBatchDetails[0]?.fundingType;
          this.batchSearchForm.patchValue({
            fundingTypes: data.renewalBatchDetails[0]?.fundingType
          });
        }
        if (StringUtils.isEqual(CommonConstants.FI, this.fundTypeFromDetails) || StringUtils.isEqual(CommonConstants.ASO, this.fundTypeFromDetails)) {
          this.isFIselectedDropdown = this.fundTypeFromDetails;
          this.getDisableMkgSegment(false);
        }
        if (StringUtils.isEqual(CommonConstants.MEWA, this.fundTypeFromDetails)) {
          this.isFIselectedDropdown = this.fundTypeFromDetails;
          this.getDisableLGMkgSegment(false);
        }
        this.renewalBatchWrapper.renewalBatch = data.renewalBatch;
        // If tiering repull is in progress, listen to tiering events.
        // This is to handle the scenario where user refreshes/closes the page when tiering repull is in progress and we need to listen to events for tiering completion
        if (
          this.initialCheckForTieringRepullInprogress &&
          this.renewalBatchWrapper.renewalBatch &&
          this.renewalBatchWrapper.renewalBatch.tieringStatus === 'Started' &&
          this.renewalBatchWrapper.renewalBatch.tieringStatusEmitterID
        ) {
          this.initialCheckForTieringRepullInprogress = false;
          this.listenToTieringEvents(
            this.renewalBatchWrapper.renewalBatch.tieringStatusEmitterID,
            this.renewalBatchWrapper.renewalBatch.tieringInfo?.tieringInput?.selectedSnapMonthYear || ''
          );
        }
        this.initialCheckForTieringRepullInprogress = false;
        this.convertTieringToPercentage();
        this.hasDeletedGroupsInBatch = this.renewalBatchWrapper.renewalBatch[RenewalsConstants.HAS_DELETED_GROUPS] == 'true' ? true : false;
        let quoteReason =
          this.renewalBatchWrapper.renewalBatch.quoteReason && StringUtils.isEqual(this.renewalBatchWrapper.renewalBatch.quoteReason, CommonConstants.TEST);
        if (quoteReason) {
          this.quoteReason = quoteReason;
        }
        this.isAutoRunBatch = StringUtils.isEqual(this.renewalBatchWrapper.renewalBatch.batchOrigin, BATCH_ORIGIN.AUTO_RUN_BATCH);
        let originalGroupData = RenewalsUtil.updateRenewalBatchColumns(this.quoteReason, this.renewalBatchColumns);
        this.showOriginalGroupNumber = originalGroupData.showOriginalGroupNumber;
        this.renewalBatchColumns = originalGroupData.batchColumns;
        this.renewalBatchWrapper.renewalBatchDetails = data.renewalBatchDetails as [];
        this.buildBatchDetailsMap();
        if (this.renewalBatchWrapper.renewalBatchDetails.length > 0) {
          this.getAlternetQuoteStatus(this.renewalBatchWrapper);
          this.renewalBatchWrapper.renewalBatchDetails.forEach((batchDetails: RenewalBatchDetails) => {
            this.renewalMonthsFromResponse.push(batchDetails?.renewalDate.split('-')[1].toString());
            this.statesFromResponse.push(batchDetails?.state);
            this.marketSegmentsFromResponse.push(batchDetails?.marketSegment);
          });
          this.selectmonths = [...new Set(this.renewalMonthsFromResponse)];

          // Only restore states and associations present in the actual batch
          const batchStates = (this.renewalBatchWrapper.renewalBatchDetails || []).map(g => g.state);
          this.selectstate = [...new Set(batchStates)];
          this.batchSearchForm.patchValue({ states: this.selectstate });
          this.onStatesSelected(true);

          let associationRespCodes = data.renewalBatch?.associationCodes;
          if (associationRespCodes && this.filteredAssociation) {
            this.selectedAssociation = this.filteredAssociation.filter(
              (item) =>
                associationRespCodes.some((code) => item.associationCode.startsWith(code)) &&
                this.selectstate.includes(item.state)
            );
            this.batchSearchForm.patchValue({
              association: [this.selectedAssociation]
            });
            this.selectedAssociationCodes = associationRespCodes;
          }

          this.batchSearchForm.patchValue({
            marketSegments: [...new Set(this.marketSegmentsFromResponse)]
          });
          this.selectedLOB = this.renewalBatchWrapper.renewalBatchDetails[0].lob;
          this.isFundingTypeSelectedFirst = true;

          // Set disableVisionDentalLgBatchSubmit for Vision or Dental LG non-fileupload batches after batch details are loaded
          if (
            this.renewalBatchWrapper.renewalBatchDetails.length > 0 &&
            (
              StringUtils.isEqual(this.renewalBatchWrapper.renewalBatchDetails[0].lob, CommonConstants.Vision) ||
              StringUtils.isEqual(this.renewalBatchWrapper.renewalBatchDetails[0].lob, CommonConstants.Dental)
            ) &&
            this.renewalBatchWrapper.renewalBatchDetails[0].marketSegment === CommonConstants.LG &&
            !this.detailsByFileUpload &&
            this.selectedMode !== 'fileUpload'
          ) {
            this.disableVisionDentalLgBatchSubmit = this.commonService.getDisableVisionDentalLgBatchSubmit();
          }

          if(this.tieringInputToRestore){
            this.renewalBatchWrapper.renewalBatch.tieringInfo = this.renewalBatchWrapper.renewalBatch.tieringInfo || {};
            this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput = { ...this.tieringInputToRestore };
          }
          this.verifyCheckAllDetails();
          this.isSaveDataExist = true;
          this.tableDataExist = true;
          this.first = 0;
          this.detailsByFileUpload = this.renewalBatchWrapper.renewalBatchDetails[0].uploadStatus != undefined;
          this._visibleColumnsDirty = true;
          this.isFIRewewal = StringUtils.isEqualIgnoreCase(CommonConstants.FI, this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType);
          this.checkAllDetails = false;
          this.getAlternetQuoteStatus(this.renewalBatchWrapper);
          this.renewalBatchWrapper.renewalBatchDetails.forEach((renewal) => {
            (renewal['included'] as boolean) = false;
          });

          // Restore included state if needed
          if (this.includedMapToRestore) {
            (this.renewalBatchWrapper?.renewalBatchDetails || []).forEach(g => {
              g.included = this.includedMapToRestore?.get(g.groupNumber) || false;
            });
            this.includedMapToRestore = null;
            this.verifyCheckAllDetails();
          }
          // will remove this code once alternate quotes are implemented for Vision and Dental LOBs
          // if (this.renewalBatchWrapper.renewalBatch.lobs.includes("Vision") || this.renewalBatchWrapper.renewalBatch.lobs.includes("Dental")) {
          //   this.renewalBatchWrapper?.renewalBatchDetails?.forEach((detail: RenewalBatchDetails) => {
          //     detail.alternateQuotes = RenewalsConstants.alternateQuotes;
          //   })
          // }
          this.isSelectedAltsGroupsToRestore?.forEach(element => {
            const group = this.renewalBatchWrapper?.renewalBatchDetails?.find((x: { groupNumber: string }) => x.groupNumber === element.groupNumber);
            group?.alternateQuotes?.forEach(grpQuote => {
              element?.alternateQuotes?.forEach(quote => {
                if (quote.marketSegment === grpQuote.marketSegment) {
                  Object.keys(quote.fundingOptions).forEach(key => {
                    if (grpQuote.fundingOptions[key]) {
                      grpQuote.fundingOptions[key].isSelected = quote.fundingOptions[key]?.isSelected;
                    }
                  });
                }
              });
            });
          });

          if (this.renewalBatchWrapper.renewalBatchDetails.filter((renewal) => renewal['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH).length > 0) {
            this.getAutoRunBatchDetails();
          }
          this.showTabs();
          if (this.showTab) {
            this.enableBulkAdjTab();
          }
          this.enableQuoteOptionsData();
          this.calculateformulaTotalRateActionPercent();
          this.enableTieringTab();
          this.checkRareSourceGroups();
          this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS;
          this.showSubmitOptions();
          this.showPlusIconForGroupMerge = StringUtils.isEqual(this.selectedLOB, CommonConstants.Medical);
          if (
            this.renewalBatchWrapper.renewalBatch &&
            this.renewalBatchWrapper.renewalBatch.submissionProcessID != undefined &&
            this.renewalBatchWrapper.renewalBatch.batchStatus == SubmissionStatus.SUBMITTED
          ) {
            if (!(StringUtils.isEqual(CommonConstants.ASO, this.fundTypeFromDetails))) {
              let source = this.commonService.listenForStreamTrackAndFail(this.renewalBatchWrapper.renewalBatch.submissionProcessID);
              this.listenRenewalBatchSubmissionEvents(source, this.renewalBatchWrapper.renewalBatch.batchName);
            }
          }
          if (
            this.renewalBatchWrapper.renewalBatch &&
            this.renewalBatchWrapper.renewalBatch.statusEmitterID != undefined &&
            this.renewalBatchWrapper.renewalBatch.batchQuoteStatusEmitStatus == BatchQuoteStatusEmitStatus.STARTED
          ) {
            let source = this.commonService.listenForStreamTrackAndFail(this.renewalBatchWrapper.renewalBatch.statusEmitterID);
            this.listenRenewalBatchQuoteStatusEvents(source, this.renewalBatchWrapper.renewalBatch.batchName);
          }
        } else {
          this.tableDataExist = this.renewalBatchWrapper.renewalBatchDetails.length > 0 || false;
        }
        this.showLoader = false;
        window.scroll(0, 0);
        this.cdRef.markForCheck();
      },
      (error) => {
        this.showLoader = false;
        this.initialCheckForTieringRepullInprogress = false;
        this.setAlertVisibility(true, AlertType.ERROR, error.exceptions[0].message);
        this.hideAlertVisibility();
        this.cdRef.markForCheck();
      }
    );
    this.isTooltipVisible = true;
  }

  getAlternetQuoteStatus(data) {
    const batchOrigin = data.renewalBatch?.batchOrigin;
    let altvalue = data.renewalBatch?.batchStatusForAlternates;
    // Set initial status/tooltip immediately after submit, before event
    const details = (data.renewalBatchDetails || []).filter((d: any) => d.included === true);
    const actionsArr = details.map((d: any) => d.userSubmitActions || []);
    const allActions = [].concat(...actionsArr);
    const onlyAlternate = allActions.length > 0 && allActions.every((a: string) => a === 'ALTERNATE_QUOTES');
    const hasOriginal = allActions.includes('ORIGNAL_QUOTES');
    const hasAlternate = allActions.includes('ALTERNATE_QUOTES');
    if (batchOrigin === 'autoRunBatch') {
      this.batchStatusObj = { status: data.renewalBatch.batchStatus, tooltip: null };
    } else if (onlyAlternate) {
      this.batchStatusObj = { status: altvalue, tooltip: null };
    } else if (hasOriginal) {
      this.batchStatusObj = { status: data.renewalBatch.batchStatus, tooltip: hasAlternate ? altvalue : null };
    } else {
      this.batchStatusObj = { status: data.renewalBatch.batchStatus, tooltip: null };
    }
  }

  calculateformulaTotalRateActionPercent() {
    // Set formulaTotalRateActionPercent using the last index of formulaRates array
    const formulaRates = this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringRates?.formulaRates;
    if (Array.isArray(formulaRates) && formulaRates.length > 0) {
      const lastIndex = formulaRates.length - 1;
      this.formulaTotalRateActionPercent = (parseFloat(formulaRates[lastIndex].totalBlockRateAction) * 100).toLocaleString('en', { minimumFractionDigits: 2 });
    } else {
      this.formulaTotalRateActionPercent = undefined;
    }
    // Set formulaTotalRateActionPercent using the last index of formulaRates array
    const uwRates = this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringRates?.uwRates;
    if (Array.isArray(uwRates) && uwRates.length > 0) {
      const lastIndex = uwRates.length - 1;
      this.uwTieredRateAction = (parseFloat(uwRates[lastIndex].totalBlockRateAction) * 100).toLocaleString('en', { minimumFractionDigits: 2 });
    } else {
      this.uwTieredRateAction = undefined;
    }
  }

  renderQuoteErrors(quoteErrors: any) {
    var displayableErrors: string;
    if (quoteErrors && quoteErrors.errorList) {
      let errMsgs = [];
      for (let error of quoteErrors.errorList) {
        if (!errMsgs.includes(error.msg)) {
          errMsgs.push(error.msg);
          if (displayableErrors) displayableErrors = displayableErrors + ' , ' + error.msg;
          else displayableErrors = error.msg;
        }
      }
    }
    return displayableErrors;
  }

  hasSgRole() {
    return this.commonService.hasSgRole();
  }

  hasLgRole() {
    return this.commonService.hasLgRole();
  }

  displayOptionsPannel = () => {
    this.isSearchChanged = true;
    this.showProgress = false;
    if (this.multiselectEle) {
      this.multiselectEle.focus();
    }
    const marketSegments = this.batchSearchForm.value.marketSegments;
    const isLGSelected = marketSegments.includes('SG');
    const isSGSelected = marketSegments.includes('LG');

    this.availableFTs.forEach((fundingType) => {
      fundingType.disabled = false;
    });

    this.onMBSOptionsSelected();
  }

  onOptionsSelected = (event) => {
    this.batchSearchForm.patchValue({
      marketSegments: []
    });
    this.isFundingTypeChangeByUser = true;
    if (StringUtils.isEmpty(this.selectedLOB) && !this.isFundingTypeSelectedFirst) {
      this.isFundingTypeSelectedFirst = true;
    }
    if(event?.value) {
      this.isFIselectedDropdown = event.value;
    } else {
      this.isFIselectedDropdown = event.target.value;
    }

    if (StringUtils.isEqual(this.isFIselectedDropdown, CommonConstants.FI) || StringUtils.isEqual(this.isFIselectedDropdown, CommonConstants.ASO)) {
      const marketSegments = this.batchSearchForm.value.marketSegments || [];

      // Retain only LG and remove SG if both are selected
      if (marketSegments.includes(CommonConstants.LG) && marketSegments.includes(CommonConstants.SG)) {
        this.batchSearchForm.patchValue({
          marketSegments: [CommonConstants.LG]
        });
      }

      // Remove SG if it is selected
      if (marketSegments.includes(CommonConstants.SG)) {
        const updatedMarketSegments = marketSegments.filter((segment) => segment !== CommonConstants.SG);
        this.batchSearchForm.patchValue({
          marketSegments: updatedMarketSegments
        });
      }

      // Disable SG market segment directly
      if (StringUtils.isEqual(this.batchSearchForm.value.lob, CommonConstants.Medical) || StringUtils.isEqual(this.batchSearchForm.value.lob, CommonConstants.SuppHealth)) {
        this.getDisableMkgSegment(true);
      } else {
        this.getDisableMkgSegment(false);
      }
      this.getDisableLGMkgSegment(false);
    } else if (StringUtils.isEqual(this.isFIselectedDropdown, CommonConstants.MEWA) || StringUtils.isEqual(this.isFIselectedDropdown, CommonConstants.ACA)) {
      const marketSegments = this.batchSearchForm.value.marketSegments || [];

      // Remove LG if it is selected
      if (marketSegments.includes(CommonConstants.LG)) {
        const updatedMarketSegments = marketSegments.filter((segment) => segment !== CommonConstants.LG);
        this.batchSearchForm.patchValue({
          marketSegments: updatedMarketSegments
        });
      }

      // Enable SG market segment
      this.getDisableMkgSegment(false);
      this.getDisableLGMkgSegment(true);
    } else {
      // Enable SG market segment for other funding types
      this.getDisableMkgSegment(false);
      this.getDisableLGMkgSegment(false);
    }

    this.onMBSOptionsSelected();
    this.showSendToOppBasedOnConfig();
    this.checkFundingType(this.isFIselectedDropdown);
  }

  onMBSOptionsSelected = () => {
    this.isSearchChanged = true;
    if (
      this.isFIselectedDropdown &&
      this.selectedMbs.includes('Non-Key') &&
      this.selectedMbs?.length > 1 &&
      (this.selectmonths?.length > 1 || this.selectstate?.length > 1)
    ) {
      this.setAlertVisibility(
        true,
        AlertType.WARNING,
        'Limiting your search to 1 State and 1 Renewal month will yield better search performance and a simpler user experience.'
      );
    } else {
      this.setAlertVisibility(false);
    }
    this.hideAlertVisibility();
  }

  onOptionChange = () => {
    this.isSearchChanged = true;
  }

  searchClicked() {
    //Check if there is an existing search result by checking the fundingType in the first element
    //Check if the search is done on an existing batch's search result by checking the batchID and then the fundingType in the first element
    //if the search is for a not for an existing batch then we don't need to check any changes in the funding type
    if (!this.groupNumbersFile && this.renewalBatchWrapper?.renewalBatch?.id && this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType) {
      //Check if the search form has a different funding type than the existing groups in the batch
      if (Object.keys(this.renewalBatchWrapper.renewalBatch).length !== 0) {
        if (StringUtils.isNotEqualIgnoreCase(this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType, this.batchSearchForm.value.fundingTypes)) {
          this.setAlertVisibility(
            true,
            AlertType.WARNING,
            'A Renewal Batch is allowed to have single funding type. Please adjust the search criteria for funding type.',
            undefined,
            true
          );
          this.showLoader = false;
          this.hideAlertVisibility();
          return;
        }
      }
    }

    if (
      this.renewalBatchWrapper.renewalBatchDetails.length > 0 &&
      !StringUtils.isEqualIgnoreCase(this.renewalBatchWrapper?.renewalBatchDetails[0]?.lob, this.batchSearchForm?.value?.lob) &&
      (this.isSaveDataExist || this.isSaveFlow)
    ) {
      this.setAlertVisibility(true, AlertType.WARNING, 'A Renewal Batch is allowed to have single LOB. Please adjust the search criteria for LOB.',
        undefined,
        true
      );
      this.hideAlertVisibility();
      this.showLoader = false;
      return;
    }
    this.isFIRewewalSearch =
      StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.FI) &&
      (StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Medical) ||
        StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Vision) ||
        StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Dental) ||
        StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.SuppHealth));
    this._visibleColumnsDirty = true;
    this.isSuppHealthSearch = StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.SuppHealth);
    this.errorExist = false;
    this.isPopupVisible = false;
    this.formSubmitted = true;
    this.removeAlertMsg();
    this.repeatingGroupsToHighlight = [];
    if (this.batchSearchForm.invalid) {
      return;
    } else {
      this.showLoader = true;
      this.getMkgSegmentValueForSearch();
      this.batchSearch = this.getBatchSearchRequest(this.isFIRewewalSearch);
      // For Vision/Dental, if LG is not selected (including no market segment), set mbs to empty array
      const isVisOrDen = StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Vision) || StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Dental);
      const marketSegments = this.batchSearchForm.value.marketSegments || [];
      const isLG = marketSegments.includes(CommonConstants.LG);
      //line no 3045 and 3046 commented for one defect fix ALGR-136211
      // if (isVisOrDen && !isLG) {
      //   this.batchSearch.mbs = [];
      // }
      this.first = 0;
      (this.selectedAssociationCodes =
        this.batchSearchForm.value?.association?.length > 0
          ? this.batchSearchForm.value.association.flatMap((assoc) => assoc?.associationCode?.split(',')) || []
          : []),
        (this.showPlusIconForGroupMerge = StringUtils.isEqual(this.selectedLOB, CommonConstants.Medical));
      this.renewalsService.fetchRenewalDetailsFromDatamart(this.groupNumbersFile, this.batchSearch).subscribe(
        (res) => {
          if (res) {
            let renewalBatchWrapper: RenewalBatchWrapper = res;
            // will remove once alternate quotes are implemented for Vision and Dental LOBs
            // if (renewalBatchWrapper?.renewalBatchDetails[0]?.lob === "Vision" || renewalBatchWrapper?.renewalBatchDetails[0]?.lob ==="Dental") {
            //   renewalBatchWrapper?.renewalBatchDetails?.forEach((detail: RenewalBatchDetails) => {
            //     detail.alternateQuotes = RenewalsConstants.alternateQuotes;
            //   })
            // }
            this.searchResults = renewalBatchWrapper?.renewalBatchDetails || [];
            this.lastSearchResults = JSON.parse(JSON.stringify(this.searchResults));
            this.lastSearchCriteria = JSON.parse(JSON.stringify(this.batchSearchForm.value));
            // Only update main batch details if this is a NEW batch (no batch id)
            // if (!this.renewalBatchWrapper?.renewalBatch?.id) {
            //   // New batch: update main table and merge
            //   this.filterDuplicateRenewalDetails(renewalBatchWrapper.renewalBatchDetails);
            // }
            if (
              renewalBatchWrapper &&
              renewalBatchWrapper.renewalBatch &&
              renewalBatchWrapper.renewalBatch.errorList &&
              renewalBatchWrapper.renewalBatch.errorList.length > 0
            ) {
              this.setAlertVisibility(true, AlertType.ERROR, renewalBatchWrapper.renewalBatch.errorList.join(', '), false);
            }
            let invalidGroups = 'The following groups were not found:'
            if (renewalBatchWrapper?.failedGrpNbrsInSearch && renewalBatchWrapper?.failedGrpNbrsInSearch.length > 0) {
              let failedGrpNbrsInSearch =  [...new Set(renewalBatchWrapper?.failedGrpNbrsInSearch)];
              let invalidGroupsMsg = invalidGroups + ' ' + failedGrpNbrsInSearch.join(', ');
              if (invalidGroupsMsg.length > 150) {
                invalidGroupsMsg = invalidGroupsMsg.substring(0, 150) + '...';
                this.invalidGroupsTooltipMsg = invalidGroups + ' ' + failedGrpNbrsInSearch.join(', ');
              }

              this.errorExist = true;
              this.setAlertVisibility(true, AlertType.ERROR, invalidGroupsMsg,
                undefined,
                true
              );
            }
            setTimeout(() => {
              this.setAlertVisibility(false);
            }, 10000);
            this.tableDataExist = this.renewalBatchWrapper.renewalBatchDetails.length > 0;
            if (this.tableDataExist) {
              let originalGroupData = RenewalsUtil.updateRenewalBatchColumns(false, this.renewalBatchColumns);
              this.showOriginalGroupNumber = false;
              this.renewalBatchColumns = originalGroupData.batchColumns;
              this._visibleColumnsDirty = true;
            }
            this.formSubmitted = false;
            setTimeout(() => {
              this.showLoader = false;
              this.cdRef.markForCheck();
            }, 500);
          } else {
            this.errorExist = true;
            this.lastSearchResults = [];
            this.lastSearchCriteria = null;
            let alertMsg = 'Please contact RARE Support Team';
            this.setAlertVisibility(true, AlertType.ERROR, 'Something went wrong !' + ' ' + alertMsg, undefined,
            true);
            this.showLoader = false;
            this.cdRef.markForCheck();
          }
        },
        (error) => {
          this.errorExist = true;
          let alertMsg = '- Please contact RARE Support Team';
          this.setAlertVisibility(true, AlertType.ERROR, error.exceptions[0].message + ' ' + alertMsg,
            undefined,
            true
          );
          this.showLoader = false;
          this.cdRef.markForCheck();
        }
      );
      this.batchSearch.marketSegments = [];
    }
    this.isSearchChanged = false;
  }

  getBatchSearchRequest(isFIRewewalSearch: boolean) {
    const req: any = {
      groupName: this.batchSearchForm.value.groupName,
      groupNumber: this.batchSearchForm.value.groupNumber,
      states: this.batchSearchForm.value.states || [],
      lob: this.batchSearchForm.value.lob || [],
      marketSegments: this.batchSearchForm.value.marketSegments || [],
      fundingTypes: this.batchSearchForm.value.fundingTypes || '',
      mbs: isFIRewewalSearch ? this.batchSearchForm.value.mbs : [],
      associationCodes:
        this.batchSearchForm.value?.association?.length > 0
          ? this.batchSearchForm.value.association.flatMap((assoc) => assoc?.associationCode?.split(',')) || []
          : [],
      renewalMonths: this.batchSearchForm.value.renewalMonths || [],
      sourceSystemCodes: this.batchSearchForm.value.system || []
    };
    if (this.availableDatasourcesForBatchScreenSearchOverlay && this.availableDatasourcesForBatchScreenSearchOverlay.length > 0) {
      req.dataSource = this.batchSearchForm.value.dataSource || [];
      if(req.dataSource == "Rare (Original Quote)") {
        req.dataSource = "Rare";
      }
      if(this.batchSearchForm.value.dataSource !== this.availableDatasourcesForBatchScreenSearchOverlay[0] ){
      if ([CommonConstants.MEWA, CommonConstants.ACA].includes(req.fundingTypes)) {
        req.quotingType = req.fundingTypes;
        req.fundingTypes = "";
      }
      req.renewalYears = this.batchSearchForm.value.renewalYears || [];
      req.includeTestQuotes = this.batchSearchForm.value.includeTestQuotes || false;
      req.sourceSystemCodes = [];
      req.mbs = [];
    }
    }
    return req;
  }

  filterDuplicateRenewalDetails(renewalBatchDetails: RenewalBatchDetails[]) {
    this.renewalBatchWrapper.renewalBatchDetails = this.renewalBatchWrapper.renewalBatchDetails.filter((renewal: RenewalBatchDetails) => renewal['batchID']);
    if (this.renewalBatchWrapper.renewalBatchDetails.length > 0) {
      this.isFIRewewal = StringUtils.isEqualIgnoreCase(this.renewalBatchWrapper.renewalBatchDetails[0].fundingType, CommonConstants.FI);
      const filteredRenewalBatchDetails = renewalBatchDetails.filter((renewal: RenewalBatchDetails) => {
        return (
          this.renewalBatchWrapper.renewalBatchDetails.findIndex(
            (existingRenewal: RenewalBatchDetails) =>
              (existingRenewal.originalGroupNumber ? existingRenewal.originalGroupNumber : existingRenewal.groupNumber) ===
              (renewal.originalGroupNumber ? renewal.originalGroupNumber : renewal.groupNumber)
          ) === -1
        );
      });
      this.renewalBatchWrapper.renewalBatchDetails = [...this.renewalBatchWrapper.renewalBatchDetails, ...filteredRenewalBatchDetails];
      this.renewalBatchWrapper.renewalBatchDetails.sort((first, second) => {
        return first['groupName'].localeCompare(second['groupName']);
      });
    } else {
      this.renewalBatchWrapper.renewalBatchDetails = renewalBatchDetails;
    }
    this.buildBatchDetailsMap();
    
    this.verifyCheckAllDetails();
  }
  enableFTAandMrketSegs() {
    this.availableMarketSegs.forEach((mktseg) => {
      mktseg.disabled = false;
    });
    this.availableFTs.forEach((fundingType) => {
      fundingType.disabled = false;
    });
  }

  verifyCheckAllDetails() {
    this.checkAllDetails = this.renewalBatchWrapper.renewalBatchDetails.filter((detail) => !detail['included']).length <= 0;
    
    this.enableQuoteOptionsData();
    this.enableTieringTab();
    this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS;
    this.showSubmitOptions();

    // Initialize commission defaults for newly selected groups
    this.initializeABFCommissionDefaults();
  }

  verifyCheckAllDetailsOverlay() {
    this.checkAllDetailsOverlay = this.searchResults.length > 0 && this.searchResults.every((detail) => detail['included']);
  }

  checkAllRenewalsOverlay = (event: any) => {
    this.searchResults.forEach(item => {
      item.included = this.checkAllDetailsOverlay;
    });
    this.cdRef.markForCheck();
  }

  closeOverlay() {
    this.selectedMode = null;
  }

  resetClicked() {
    if(this.selectedMode === 'fileUpload') {
      this.renewalBatchWrapper.renewalBatchDetails = [];
      
    }
    this.isFundingTypeSelectedFirst = false;
    this.formSubmitted = false;
    this.groupNumbersFile = null;
    this.enableFTAandMrketSegs();
    this.showFundingType();
    this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS;
    this.showSubmitOptions();
    this.first = 0;

    // Reset form and clear all validation states
    this.batchSearchForm.reset();
    this.setDefaultFormValue();
    this.batchSearchForm.markAsUntouched();
    this.batchSearchForm.markAsPristine();
    this.searchResults = [];

    this.lastSearchResults = [];
    this.lastSearchCriteria = null;

    if (this.selectedMode !== 'search' && this.renewalBatchWrapper?.renewalBatchDetails?.length > 0) {
      this.renewalBatchWrapper.renewalBatchDetails.forEach((detail) => {
        (detail['included'] as boolean) = false;
      });
      this.checkAllDetails = false;
    }
    this.cdRef.markForCheck();
  }

  onSearchSuccess(results: any[]) {
    this.searchResults = results;
    this.lastSearchResults = JSON.parse(JSON.stringify(results));
    this.lastSearchCriteria = this.batchSearchForm.getRawValue();
    this.cdRef.markForCheck();
  }

  openSearchModeAndRestore() {
    this.selectedMode = 'search';

    if (this.lastSearchResults && this.lastSearchResults.length > 0) {
      this.searchResults = JSON.parse(JSON.stringify(this.lastSearchResults));
    }

    if (this.lastSearchCriteria) {
      this.batchSearchForm.patchValue(this.lastSearchCriteria);
      this.selectedLOB = this.lastSearchCriteria.lob;
      this.selectstate = this.lastSearchCriteria.states;
      this.selectmonths = this.lastSearchCriteria.renewalMonths;
      this.selectedYear = this.lastSearchCriteria.renewalYears;
      this.selectedMbs = this.lastSearchCriteria.mbs;
      this.selectedAssociation = this.lastSearchCriteria.association;
      this.selectedSystem = this.lastSearchCriteria.system;
      this.selectedDatasourceForBatchScreenSearchOverlay = this.lastSearchCriteria.dataSource;
      this.selectedRenewalMonthYear=this.getRenewalMonthYears(this.selectmonths, this.selectedYear);
      this.includeTestQuotesSelected = this.lastSearchCriteria.includeTestQuotes;
      if (this.renewalBatchWrapper?.renewalBatchDetails?.length) {
        const uniqueSegments = Array.from(
          new Set(this.renewalBatchWrapper.renewalBatchDetails.map(g => g.marketSegment).filter(Boolean))
        );
        if (uniqueSegments.length) {
          this.batchSearchForm.patchValue({ marketSegments: uniqueSegments });
        }
      }
    } else if (
      this.renewalBatchWrapper?.renewalBatch?.batchStatus === this.submissionStatus.SUBMITTED ||
      this.renewalBatchWrapper?.renewalBatch?.batchStatus === this.submissionStatus.NOT_SUBMITTED
    ) {
      const group = this.renewalBatchWrapper?.renewalBatchDetails?.[0];
      if (group) {
        this.batchSearchForm.patchValue({
          states: group.state ? [group.state] : [],
          lob: group.lob || '',
          marketSegments: this.renewalBatchWrapper?.renewalBatchDetails
            ? Array.from(new Set(this.renewalBatchWrapper.renewalBatchDetails.map(g => g.marketSegment).filter(Boolean)))
            : [],
          fundingTypes: group.fundingType || '',
        });
      }
    }
  }

  getRenewalMonthYears(months: number[], year: number) {
  if (Array.isArray(months) && months.length > 0 && year) {
    return months.map(month => new Date(year, month - 1, 1));
  }
  return [];
}

  restoreLastSearch() {
    if (this.lastSearchResults && this.lastSearchResults.length > 0) {
      this.searchResults = JSON.parse(JSON.stringify(this.lastSearchResults));
    } else {
      this.searchResults = [];
    }
    if (this.lastSearchCriteria) {
      this.batchSearchForm.patchValue(this.lastSearchCriteria);
    } else {
      this.setDefaultFormValue();
    }
    this.cdRef.markForCheck();
  }

  setAlertVisibility(visibility: boolean, type = '', message: string = '', headervisibility?: boolean, isSearchAlert: boolean = false) {
    window.scroll(0, 0);
    this.alert.show = visibility;
    this.alert.type = type || '';
    this.alert.message = message;
    this.alert.cssClass = type === AlertType.ERROR ? 'alert-danger' : `alert-${type}`;
    this.alert.header = type === AlertType.ERROR ? 'failed' : type;
    this.alert.isSearch = isSearchAlert;
    if (headervisibility != undefined) {
      this.alert.headerVisibility = headervisibility;
    }
    this.cdRef.markForCheck();
  }

  setLoaderVisibility(visibility: boolean) {
    window.scroll(0, 0);
    this.loader_visible = visibility;
    this.cdRef.markForCheck();
  }

  removeAlertMsg = () => {
    this.alert = {
      show: false,
      message: '',
      type: '',
      cssClass: '',
      header: '',
      headerVisibility: true,
      isSearch: false
    };
    this.cdRef.markForCheck();
  }

  goToBatchSearch(): void {
    this.router.navigate(['/group/batch']);
    this.enableFTAandMrketSegs();
  }

  addItemToLocalStorage(key, value) {
    const idExist = JSON.parse(localStorage.getItem(key) || '[]');
    if (!idExist.includes(value)) {
      idExist.push(value);
      localStorage.setItem(key, JSON.stringify(idExist));
    }
  }

  verifyAllBulkDataDetails() {
    this.checkAllBulkDetails = this.bulkViewTableData.filter((detail) => !detail['included']).length <= 0;
    let checkAllDetails = this.bulkViewTableData.filter((renewal) => renewal['included']);
    if (checkAllDetails.length) {
      this.autoSelectVersions();
    }
  }

  verifyAllAutoRunDataDetails() {
    this.checkAllAutoRunDetails = this.autoRunBatchTableData.filter((detail) => !detail['included']).length <= 0;
  }

  setActiveTab(tab: string, isDeleteOrRestoreFlow?: boolean) {
    this.activeTab = tab;
    this.showImportedProgress = false;
    if (tab == 'BULK') {
      this.hideTestBatch = true;
      this.retriveBulkAdjDetails(isDeleteOrRestoreFlow);
      this.bulkViewTableData.forEach((renewal) => {
        (renewal['included'] as boolean) = false;
      });
    } else if (tab == 'AUTORUN') {
      this.hideTestBatch = true;
      this.getAutoRunBatchDetails();
      this.autoRunBatchTableData.forEach((renewal) => {
        (renewal['included'] as boolean) = false;
      });
    } else if (tab == 'BATCH') {
      this.hideTestBatch = false;
      this.expandClicked = false;
      this.uwSalesNoteIconClicked = false;
      this.uwSelfNoteIconClicked = false;
      this.groupNumberClicked = false;
      if (!isDeleteOrRestoreFlow) this.setAlertVisibility(false);
      this.includedMapToRestore = new Map(
        (this.renewalBatchWrapper?.renewalBatchDetails || []).map(g => [g.groupNumber, g.included])
      );
      if (this.quoteOptionsData && this.quoteOptionsData.length > 0) {
        this.isSelectedAltsGroupsToRestore = JSON.parse(JSON.stringify(this.quoteOptionsData));
      }
      if(this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput){
        this.tieringInputToRestore = JSON.parse(JSON.stringify(this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput));
      }
      const hasUnsavedGroups = (this.renewalBatchWrapper?.renewalBatchDetails || []).some(g => !g.batchID && !g.id);
      if ((isDeleteOrRestoreFlow !== false && this.renewalBatchWrapper?.renewalBatch?.id) ||
        (this.renewalBatchWrapper?.renewalBatch?.id &&
          this.renewalBatchWrapper?.renewalBatch?.batchStatus !== this.submissionStatus.NOT_SUBMITTED)) {
        if (!hasUnsavedGroups) {
          this.fetchRenewalDetailsByBatch();
        }
      } else {
        (this.renewalBatchWrapper?.renewalBatchDetails || []).forEach(g => {
          g.included = this.includedMapToRestore?.get(g.groupNumber) || false;
        });
        this.includedMapToRestore = null;
      }
    }
    if (!this.isAdminUser && this.renewalBatchWrapper?.renewalBatch['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH) {
      this.batchSaveGroup.get('isAutoRunBatch')?.disable();
    }
    this.cdRef.markForCheck();
  }

  bulkTableExpand() {
    this.expandClicked = !this.expandClicked;
    if (this.expandClicked) {
      this.bulkTableCols.push(...RenewalsConstants.BULK_TABLE_COLUMNS_AFTER);
      this.bulkTableDenVisCols.push(...RenewalsConstants.BULK_TABLE_COLUMNS_AFTER);
    } else {
      this.bulkTableCols = [...RenewalsConstants.BULK_TABLE_COLUMNS_BEFORE];
      this.bulkTableDenVisCols = [...RenewalsConstants.BULK_TABLE_COLUMNS_BEFORE];
    }
    if (this.bulkViewTableData.every(item => !('formulaTieredRateActionPercent' in item))) {
      // Remove object with header 'Formula Tiered RA%' from bulkTableCols
      this.bulkTableCols = this.bulkTableCols.filter(col => col.header !== 'Formula Tiered RA%');
    }
    if (this.bulkViewTableData.every(item => !('uwTieredRateActionPercent' in item))) {
      // Remove object with header 'UW Tiered RA%' from bulkTableCols
      this.bulkTableCols = this.bulkTableCols.filter(col => col.header !== 'UW Tiered RA%');
    }
    this.removeAcaColumns();
  }

  removeAcaColumns() {
    if (!(this.bulkViewTableData.some(item => item?.oppOrigin?.originalRatingMethod !== undefined) && StringUtils.isEqual(this.bulkViewTableData[0].fundingType, CommonConstants.ABF))) {
      const headersToRemove = [
        'Renewal Premium',
        'Current to Renewal RA%',
        'Renewal to Quoted RA%'
      ];
      this.bulkTableCols = this.bulkTableCols.filter(col =>
        !headersToRemove.includes(col?.header)
      );

    }
  }

  onAdjustment(action: string) {
    if (!this.isDirty && !StringUtils.isEqualIgnoreCase(action, CommonConstants.releaseAction)) {
      let warningMsg = "No Adjustments to Save";
      this.setAlertVisibility(true, AlertType.WARNING, warningMsg);
      return;
    }
    if (this.bulkViewTableData.find((rowData) => rowData['invalidinput'] == true)) {
      this.setAlertVisibility(true, AlertType.WARNING, 'Please fix Invalid value entered in proposed section.');
      this.hideAlertVisibility();
      return;
    }
    let data = {};
    data['errors'] = '';
    this.constructBulkAdjActionRequest(data, action);
    if (data && data['bulkAdjustmentDetails'] && data['bulkAdjustmentDetails'].length < 1) {
      let warningMsg = 'No Adjustments to Save';
      if (action != 'adjust') {
        warningMsg = 'No Eligible groups to ' + action + '.';
      }
      this.setAlertVisibility(true, AlertType.WARNING, warningMsg);
      this.hideAlertVisibility();
      return;
    } else {

    }
    data['batchID'] = this.renewalBatchWrapper.renewalBatch['id'];
    data['batchName'] = this.renewalBatchWrapper.renewalBatch['batchName'];
    this.setAlertVisibility(false);
    this.setLoaderVisibility(true);
    this.renewalsService.bulkAdjustmentAction(data, action).subscribe(
      (response) => {
        if (action == 'adjust') {
          let alertMsg = 'Changes are saved successfully.';
          this.showImportedProgress = false;
          this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
        }
        this.setLoaderVisibility(false);
        if (response && response.body && response.body['description'] && !response.body['description'].startsWith('No Data found')) {
          this.renewalBatchWrapper.renewalBatch['adjustmentStatus'] = 'In Progress';
          this.listenToBulkAdjEvents(response.body['description'], action);
          if (action == 'release') {
            let alertMsg = 'Rates released successfully.';
            this.setAlertVisibility(true, AlertType.SUCCESS, alertMsg);
            this.renewalBatchWrapper.renewalBatch['recentReleaseProcessStatus'] = 'In Progress';
            var eventSource = this.commonService.listenForStream(response.body['description'] + 'REL');
            this.listenToBulkReleaseEvents(eventSource);
          }
        } else {
          this.setAlertVisibility(true, AlertType.WARNING, 'No Adjustments to ' + action);
        }
        this.hideAlertVisibility();
      },
      (error) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(true, AlertType.WARNING, 'Bulk adjustment ' + action + ' Failed !');
        this.hideAlertVisibility();
      }
    );
  }

  private validateAdjAction(action: string, data: {}) {
    for (let bulkAdjustmentDetails of data['bulkAdjustmentDetails']) {
      let changedData = bulkAdjustmentDetails['uw-request']['uwAdjustment'];
      if ('release' == action && changedData && changedData.included && (!changedData.uwNotesToSales || changedData.uwNotesToSales.trim() == '')) {
        data['errors'] = data['errors'].concat('Please enter UW notes to sales for all the selected groups.');
        break;
      }
    }
  }

  private listenToBulkAdjEvents(processID: string, action: string): void {
    var eventSource = this.commonService.listenForStream(processID);
    this.ngZone.runOutsideAngular(() => {
      eventSource.addEventListener('BATCH_RENEWAL_ADJUST_REQUEST_SUBMITTED', (event: any) => {
        this.mapEventStreamResponse(event, 'SUBMITTED');
        this.scheduleChangeDetection();
      });
      eventSource.addEventListener('BATCH_RENEWAL_ADJUST_REQUEST_QUEUED', (event: any) => {
        this.mapEventStreamResponse(event, 'QUEUED');
        this.scheduleChangeDetection();
      });
      eventSource.addEventListener('BATCH_RENEWAL_ADJUST_REQUEST_SINGLE_COMPLETE', (event: any) => {
        var eventData = JSON.parse(event.data);
        if (action == 'adjust') {
          this.mapEventStreamResponse(event, 'SINGLE_COMPLETE');
        }
        if (action == 'release') {
          const p = eventData['payload'];
          const foundGroup = this.bulkViewTableDataMap.get(`${p['opportunityID']}_${p['quoteHeaderID']}_${p['ratingTransID']}`);
          if (foundGroup) {
            if (p && (p['mpcRateAction'] || p['mpcRateAction'] == 0)) {
              foundGroup['mpcRateAction'] = p['mpcRateAction'] || 0;
            }
            if (p && (p['diffToRenewalRatePercentage'] || p['diffToRenewalRatePercentage'] == 0)) {
              foundGroup['diffToRenewalRatePercentage'] = p['diffToRenewalRatePercentage'] || 0;
            }
          }
        }
        this.scheduleChangeDetection();
      });
      eventSource.addEventListener('BATCH_RENEWAL_ADJUST_PROCESS_COMPLETION_TRIGGER', (event: any) => {
        eventSource.close();
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          this.renewalBatchWrapper.renewalBatch['adjustmentStatus'] = payload.adjustmentStatus;
        }
        this.ngZone.run(() => {
          this.cdRef.markForCheck();
          setTimeout(() => {
            this.bulkViewTableData.forEach((data) => {
              if (data['adjustmentStatus'] == 'SUCCESS') data['adjustmentStatus'] = '';
            });
            this.cdRef.markForCheck();
          }, 9000);
        });
      });
    });
  }

  private listenToBulkReleaseEvents(eventSource: any, isTieringCompleted?: boolean): void {
    this.ngZone.runOutsideAngular(() => {
      eventSource.addEventListener('BATCH_RELEASE_UPDATEUI_TASK', (event: any) => {
        this.processBulkReleaseEvents(event);
        this.scheduleChangeDetection();
      });
      eventSource.addEventListener('BATCH_RELEASE_PROCESS_COMPLETION_TRIGGER', (event: any) => {
        eventSource.close();
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          this.receivedBatchEvents.forEach(e => {
            if (e.startsWith(eventData.processId)) {
              this.receivedBatchEvents.delete(e);
            }
          });
          this.ngZone.run(() => {
            this.renewalBatchWrapper.renewalBatch['recentReleaseProcessStatus'] = payload.recentReleaseProcessStatus;
            this.receivedAlternateBatchEvents.clear();
            this.bulkViewTableData.forEach((bulkdata) => {
              bulkdata['adjustmentStatus'] = 'SUCCESS';
            });
            if (isTieringCompleted) {
              this.fetchRenewalDetailsByBatch();
            }
            this.cdRef.markForCheck();
          });
        }
      });
    });
  }

  checkIfAdjustmentActionInProgress() {
    //Add Decline, if implemented
    return (
      this.renewalBatchWrapper?.renewalBatch['adjustmentStatus'] == 'In Progress' ||
      this.renewalBatchWrapper.renewalBatch['recentReleaseProcessStatus'] == 'In Progress' ||
      this.isUserReadOnly
    );
  }

  private mapEventStreamResponse(event: any, adjStatus: string) {
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      let group = this.setAdjustmentStatus(eventData, adjStatus);
      if (group) {
        if (group['saveActionStatus'] == 'Success') {
          const adjRow = this.bulkAdjDataMap.get(`${group['opportunityID']}_${group['quoteHeaderID']}_${group['ratingTransID']}`);
          if (adjRow) {
            adjRow['adjustedRateActionPercent'] = group['adjustedRateActionPercent'];
            adjRow['renewalWHAPercent'] = group['renewalWHAPercent'];
            adjRow['asoAdminFee'] = group['asoAdminFee'];
            adjRow['sslPremium'] = group['sslPremium'];
            adjRow['aslPremium'] = group['aslPremium'];
            adjRow['maxPaidClaim'] = group['maxPaidClaim'];
            adjRow['terminalLiability'] = group['terminalLiability'];
            adjRow['wholeHealthAdjustmentFactor'] = group['wholeHealthAdjustmentFactor'];
            adjRow['discountSplits'] = group['discountSplits'];
            adjRow['currentRiskFactor'] = group['currentRiskFactor'];
            adjRow['riskFactor'] = group['riskFactor'];
            adjRow['uwAdjustmentFactor'] = group['uwAdjustmentFactor'];
            adjRow['finalRiskFactor'] = group['finalRiskFactor'];
            adjRow['whsReduction'] = group['whsReduction'];
            adjRow['uwNotesToSales'] = group['uwNotesToSales'];
            adjRow['uwComments'] = group['uwComments'];
          }
        }
      }
    }
  }

  private processBulkReleaseEvents(event: any) {
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      let payload = eventData['payload'];
      if (this.isDummyEvent(payload)) {
        return;
      }
      const row = this.bulkViewTableDataMap.get(`${payload['opportunityID']}_${payload['quoteHeaderID']}_${payload['ratingTransID']}`);
      if (row) {
        let releaseProcessDetails = payload['releaseProcessDetails'];
        const eventKey = eventData.processId + payload['ratingTransID'] + releaseProcessDetails.eventName;
        if (this.receivedBatchEvents.has(eventKey)) {
          return;
        }
        this.receivedBatchEvents.add(eventKey);
        let eventName = releaseProcessDetails.eventName;
        let medicalReleaseProcessDetails = releaseProcessDetails.medicalReleaseProcessDetails;
        let visionReleaseProcessDetails = releaseProcessDetails.visionReleaseProcessDetails;
        let dentalReleaseProcessDetails = releaseProcessDetails.dentalReleaseProcessDetails;
        if (!row['medicalReleaseProcessDetails']) {
          row['medicalReleaseProcessDetails'] = {};
        }
        if (!row['visionReleaseProcessDetails']) {
          row['visionReleaseProcessDetails'] = {};
        }
        if (!row['dentalReleaseProcessDetails']) {
          row['dentalReleaseProcessDetails'] = {};
        }
        if (eventName == 'BATCH_RELEASE_CLEAN_DATA') {
          row['releaseStatus'] = releaseProcessDetails['releaseStatus'];
          row['releaseProcessErrors'] = releaseProcessDetails['releaseProcessErrors'];
          row['medicalReleaseProcessDetails'] = medicalReleaseProcessDetails;
          row['visionReleaseProcessDetails'] = visionReleaseProcessDetails;
          row['dentalReleaseProcessDetails'] = dentalReleaseProcessDetails;
        } else if (eventName == 'BATCH_RELEASE_MED_ADJUST') {
          row['medicalReleaseProcessDetails']['isAdjustTaskDone'] = medicalReleaseProcessDetails['isAdjustTaskDone'];
          row['medicalReleaseProcessDetails']['adjustmentStatus'] = medicalReleaseProcessDetails['adjustmentStatus'];
        } else if (eventName == 'BATCH_RELEASE_MED_GENERATE_EXHIBIT') {
          row['medicalReleaseProcessDetails']['isExhibitGenerationTaskDone'] = medicalReleaseProcessDetails['isExhibitGenerationTaskDone'];
          row['medicalReleaseProcessDetails']['exhibitGenerationStatus'] = medicalReleaseProcessDetails['exhibitGenerationStatus'];
        } else if (eventName == 'BATCH_RELEASE_VIS_GENERATE_EXHIBIT') {
          row['visionReleaseProcessDetails']['isExhibitGenerationTaskDone'] = visionReleaseProcessDetails['isExhibitGenerationTaskDone'];
          row['visionReleaseProcessDetails']['exhibitGenerationStatus'] = visionReleaseProcessDetails['exhibitGenerationStatus'];
        } else if (eventName == 'BATCH_RELEASE_DEN_GENERATE_EXHIBIT') {
          row['dentalReleaseProcessDetails']['isExhibitGenerationTaskDone'] = dentalReleaseProcessDetails['isExhibitGenerationTaskDone'];
          row['dentalReleaseProcessDetails']['exhibitGenerationStatus'] = dentalReleaseProcessDetails['exhibitGenerationStatus'];
        } else if (eventName == 'BATCH_RELEASE_MED_MERGE_EXHIBITS') {
          row['medicalReleaseProcessDetails']['isMergeExhibitsTaskDone'] = medicalReleaseProcessDetails['isMergeExhibitsTaskDone'];
          row['medicalReleaseProcessDetails']['exhibitsMergeStatus'] = medicalReleaseProcessDetails['exhibitsMergeStatus'];
        } else if (eventName == 'BATCH_RELEASE_MED_GENERATE_FINAL_RESPONSE') {
          row['medicalReleaseProcessDetails']['isResponseGenerationTaskDone'] = medicalReleaseProcessDetails['isResponseGenerationTaskDone'];
          row['medicalReleaseProcessDetails']['responseGenerationStatus'] = medicalReleaseProcessDetails['responseGenerationStatus'];
        } else if (eventName == 'BATCH_RELEASE_MED_SUBMIT_RESPONSE_EXTERNAL') {
          row['medicalReleaseProcessDetails']['isResponseExtSubmitTaskDone'] = medicalReleaseProcessDetails['isResponseExtSubmitTaskDone'];
          row['medicalReleaseProcessDetails']['responseExtSubmissionStatus'] = medicalReleaseProcessDetails['responseExtSubmissionStatus'];
        } else if (eventName == 'BATCH_RELEASE_MED_UPDATE_STATUS') {
          row['medicalReleaseProcessDetails']['isStatusUpdateTaskDone'] = medicalReleaseProcessDetails['isStatusUpdateTaskDone'];
          row['medicalReleaseProcessDetails']['statusUpdateStatus'] = medicalReleaseProcessDetails['statusUpdateStatus'];
        } else if (eventName == 'BATCH_RELEASE_VIS_GENERATE_FINAL_RESPONSE') {
          row['visionReleaseProcessDetails']['isResponseGenerationTaskDone'] = visionReleaseProcessDetails['isResponseGenerationTaskDone'];
          row['visionReleaseProcessDetails']['responseGenerationStatus'] = visionReleaseProcessDetails['responseGenerationStatus'];
        } else if (eventName == 'BATCH_RELEASE_VIS_SUBMIT_RESPONSE_EXTERNAL') {
          row['visionReleaseProcessDetails']['isResponseExtSubmitTaskDone'] = visionReleaseProcessDetails['isResponseExtSubmitTaskDone'];
          row['visionReleaseProcessDetails']['responseExtSubmissionStatus'] = visionReleaseProcessDetails['responseExtSubmissionStatus'];
        } else if (eventName == 'BATCH_RELEASE_VIS_UPDATE_STATUS') {
          row['visionReleaseProcessDetails']['isStatusUpdateTaskDone'] = visionReleaseProcessDetails['isStatusUpdateTaskDone'];
          row['visionReleaseProcessDetails']['statusUpdateStatus'] = visionReleaseProcessDetails['statusUpdateStatus'];
        } else if (eventName == 'BATCH_RELEASE_DEN_GENERATE_FINAL_RESPONSE') {
          row['dentalReleaseProcessDetails']['isResponseGenerationTaskDone'] = dentalReleaseProcessDetails['isResponseGenerationTaskDone'];
          row['dentalReleaseProcessDetails']['responseGenerationStatus'] = dentalReleaseProcessDetails['responseGenerationStatus'];
        } else if (eventName == 'BATCH_RELEASE_DEN_SUBMIT_RESPONSE_EXTERNAL') {
          row['dentalReleaseProcessDetails']['isResponseExtSubmitTaskDone'] = dentalReleaseProcessDetails['isResponseExtSubmitTaskDone'];
          row['dentalReleaseProcessDetails']['responseExtSubmissionStatus'] = dentalReleaseProcessDetails['responseExtSubmissionStatus'];
        } else if (eventName == 'BATCH_RELEASE_DEN_UPDATE_STATUS') {
          row['dentalReleaseProcessDetails']['isStatusUpdateTaskDone'] = dentalReleaseProcessDetails['isStatusUpdateTaskDone'];
          row['dentalReleaseProcessDetails']['statusUpdateStatus'] = dentalReleaseProcessDetails['statusUpdateStatus'];
        } else if (eventName == 'BATCH_RELEASE_PROCESS_SINGLE_COMPLETE') {
          row['releaseStatus'] = releaseProcessDetails['releaseStatus'];
          this.flushGrdRlMsgOnRelease(releaseProcessDetails['releaseStatus'], row);
          this.setAdjustmentStatus(eventData, 'SINGLE_COMPLETE');
          row['releaseProcessErrors'] = releaseProcessDetails['releaseProcessErrors'];
        }
      }
    }
  }

  private flushGrdRlMsgOnRelease(releaseStatus: string, bulkViewData: any): void {
    if (releaseStatus == 'Success') {
      bulkViewData['errorMsg'] = '';
    }
  }

  getReleaseProcessTabletclass(lobReleaseProcessNode: string, tabletIsDoneNode: string, tabletEventNode: string, bulkdata: any, view: string) {
    if (bulkdata[lobReleaseProcessNode]) {
      if (bulkdata[lobReleaseProcessNode][tabletIsDoneNode] == true) {
        if (bulkdata[lobReleaseProcessNode][tabletEventNode] == 'Success') {
          return 'renewalGrpsbmsnSuccess';
        } else if (bulkdata[lobReleaseProcessNode][tabletEventNode] && bulkdata[lobReleaseProcessNode][tabletEventNode].startsWith('Failed')) {
          return 'renewalGrpsbmsnFailed';
        } else {
          return '';
        }
      } else if (bulkdata[lobReleaseProcessNode][tabletEventNode] == 'NA') {
        return 'renewalGrpsbmsnNA';
      }
    }
    if((lobReleaseProcessNode == "visionReleaseProcessDetails" || lobReleaseProcessNode == "dentalReleaseProcessDetails") && view == "MedicalSuppl" && bulkdata?.source == 'RARE' && bulkdata?.alternateQuote && !bulkdata?.altMarket) {
      return 'renewalGrpsbmsnRare';
    }
    return '';
  }

  setbgColor(header: string, bulkdata: any) {
    if (header == 'Release Status' && ['Success', 'Failed'].includes(bulkdata.releaseStatus)) {
      if (bulkdata.releaseProcessErrors) {
        return 'bg-alert-danger';
      } else {
        return 'bg-alert-success';
      }
    }
    return '';
  }

  getReleaseProcessTabletToolTip(lobReleaseProcessNode: string, tabletIsDoneNode: string, tabletStatusNode: string, step: string, bulkdata: any) {
    if (bulkdata[lobReleaseProcessNode] && bulkdata[lobReleaseProcessNode][tabletIsDoneNode]) {
      if (
        bulkdata[lobReleaseProcessNode][tabletStatusNode] != 'Success' ||
        (this.bulkViewTableData['releaseFailCheckPoint'] && this.bulkViewTableData['releaseFailCheckPoint'] == step)
      ) {
        return bulkdata[lobReleaseProcessNode][tabletStatusNode];
      } else {
        return '';
      }
    }
    return '';
  }

  private setAdjustmentStatus(eventData: any, status: string) {
    const p = eventData['payload'];
    let foundGroup = this.bulkViewTableDataMap.get(`${p['opportunityID']}_${p['quoteHeaderID']}_${p['ratingTransID']}`);
    if (foundGroup) {
      if (status == 'SINGLE_COMPLETE' && eventData['payload'] && (eventData['payload']['mpcRateAction'] || eventData['payload']['mpcRateAction'] == 0)) {
        foundGroup['mpcRateAction'] = eventData['payload']['mpcRateAction'] || 0;
      }
      
      if (status == 'SINGLE_COMPLETE' && eventData['payload'] && (eventData['payload']['diffToRenewalRatePercentage'] || eventData['payload']['diffToRenewalRatePercentage'] == 0)) {
        foundGroup['diffToRenewalRatePercentage'] = eventData['payload']['diffToRenewalRatePercentage'] || 0;
      }

      if (eventData['payload'] && eventData['payload']['status']) {
        foundGroup['saveActionStatus'] = eventData['payload']['status'];
      }
      if (eventData['payload']['errorMsg']) {
        foundGroup['adjustmentStatus'] = foundGroup['saveActionStatus'] == 'Failed' ? 'FAILED' : '';
        foundGroup['errorMsg'] = eventData['payload']['errorMsg'];
        return foundGroup;
      }
      if (status == 'SINGLE_COMPLETE') {
        foundGroup['adjustmentStatus'] = 'SUCCESS';
        return foundGroup;
      }

      foundGroup['adjustmentStatus'] = status;
      return foundGroup;
    }
  }

  private constructBulkAdjActionRequest(data: {}, action: string) {
    data['bulkAdjustmentDetails'] = [];
    this.bulkAdjData.forEach((bulkdata) => {
      let requestData = {};
      var changedData = this.bulkViewTableData.find((viewdata) => viewdata['groupNumber'] == bulkdata['groupNumber']);
      var changedDataIndex = this.bulkViewTableData.findIndex((viewdata) => viewdata['groupNumber'] == bulkdata['groupNumber']);
      if (changedData && bulkdata) {
        let changeSet = this.uwChangeSetService.constructBulkChangeSet(bulkdata, changedData, changedData.quotingType);
        if ((action != 'adjust' && changedData.included) || (action == 'adjust' && null != changeSet)) {
          let adjustStatus = action != 'adjust' ? '' : 'SUBMITTED';
          this.bulkViewTableData[changedDataIndex]['adjustmentStatus'] = adjustStatus;
          this.bulkViewTableData[changedDataIndex]['errorMsg'] = '';
          if (null != changeSet) {
            requestData['uw-action-changeset'] = changeSet;
          }

          // For MEWA original quotes, if currentRiskFactor is empty/null, use the initial risk factor value
          if (changedData.quotingType === 'MEWA' && !changedData.alternateQuote) {
            const currentRiskFactorValue = changedData.currentRiskFactor;
            if (currentRiskFactorValue === null || currentRiskFactorValue === undefined || currentRiskFactorValue === '') {
              const initialRiskFactor = changedData.data?.medical?.riskFactor;
              if (initialRiskFactor !== null && initialRiskFactor !== undefined) {
                changedData.currentRiskFactor = initialRiskFactor;
                this.bulkViewTableData[changedDataIndex].currentRiskFactor = initialRiskFactor;
              }
            }
          }

          requestData['uw-request'] = CreateBatchUtil.constructUWRequest(changedData, action, this.isFIBulkAdj);

          // Set uwAdjustment.outputTier based on LOB
          if (requestData['uw-request'] && requestData['uw-request'].uwAdjustment) {
            if (changedData.lob === CommonConstants.Medical) {
              requestData['uw-request'].uwAdjustment.outputTier = changedData['data']?.['medicalAlternateTier'];
            } else if (changedData.lob === CommonConstants.Vision) {
              requestData['uw-request'].uwAdjustment.outputTier = changedData.data.visionOutputTier;
            } else if (changedData.lob === CommonConstants.Dental) {
              requestData['uw-request'].uwAdjustment.outputTier = changedData.data.dentalOutputTier;
            }
          }

          // DRY: Add dynamic productAdjustments for Vision and Dental only
          const lobAdjustmentsMap = {
            'Vision': 'visionProductAdjustments',
            'Dental': 'dentalProductAdjustments'
          };
          if (lobAdjustmentsMap[changedData.lob] && Array.isArray(changedData[lobAdjustmentsMap[changedData.lob]])) {
            requestData['uw-request']['productAdjustments'] = changedData[lobAdjustmentsMap[changedData.lob]].map(adj => {
              // If suggestedRateActionAdjustment is missing, set to 1.1 for initial payload
              let suggestedAdj = (adj.suggestedRateActionAdjustment === null || adj.suggestedRateActionAdjustment === undefined)
                ? 1
                : adj.suggestedRateActionAdjustment;
              return {
                planName: adj.planName,
                ratingPlanID: adj.ratingPlanID,
                suggestedRateActionAdjustment: suggestedAdj,
                uwAdjustmentFactor: adj.proposedRateActionAdjustment
              };
            });
          }

          // Update quoteOrigin if not already existing
          if (!requestData['uw-request']['opportunity']['quoteOrigin']) {
            requestData['uw-request']['opportunity']['quoteOrigin'] = this.getQuoteOrigin();
          }

          requestData['groupNumber'] = bulkdata['groupNumber'];
          data['bulkAdjustmentDetails'].push(requestData);
        }
      }
    });
  }

  getQuoteOrigin() {
    this.route.queryParams.subscribe((params) => {
      return params[CommonConstants.QUOTE_ORIGIN];
    });
  }

  retriveBulkAdjDetails(isDeleteOrRestoreFlow?: boolean) {
    this.expandClicked = false;
    this.uwSalesNoteIconClicked = false;
    this.uwSelfNoteIconClicked = false;
    this.groupNumberClicked = false;
    this.bulkViewTableData = [];
    this.bulkAdjData = [];
    this.expTotalRateActionPercent = '';
    this.uwTotalRateActionPercent = '';
    this.currentPlanTotPrem = 0;
    this.renewalPlanTotPrem = 0;
    this.adjustedPlanTotprem = 0;
    if (this.activeTab == 'BULK') {
      this.showLoader = true;
      // Enable import/export if all batch details match bulkUploadImportConfig
      this.isImportExportEnabled = false;
      const config = this.bulkUploadImportConfig;
      const details = this.renewalBatchWrapper?.renewalBatchDetails || [];
      if (
        Array.isArray(details) &&
        details.length > 0 &&
        typeof config === 'object' &&
        config !== null
      ) {
        this.isImportExportEnabled = details.every(obj => {
          const lob = obj.lob;
          const marketSegment = obj.marketSegment;
          const fundingType = obj.fundingType;
          if (
            lob &&
            config[lob] &&
            marketSegment &&
            config[lob][marketSegment] &&
            Array.isArray(config[lob][marketSegment])
          ) {
            return config[lob][marketSegment].includes(fundingType);
          }
          return false;
        });
      }

      if (this.isImportExportEnabled) {
        // if (!this.availableVersions.some(option => option.value === 'Adj_Template')) {
        //   this.availableVersions.push({ label: 'Adj Template', value: 'Adj_Template', disabled: false });
        // }
      }
    }
    this.renewalsService.fetchBulkAdjustmentDetails(this.renewalBatchWrapper.renewalBatch['id']).subscribe(
      (data) => {
        if (data['processId']) this.listenToBulkAdjDetailsEvents(data['processId'], isDeleteOrRestoreFlow);
      },
      (error) => {
        this.showLoader = false;
        console.error('error retriveBulkAdjDetails ', error);
        this.cdRef.markForCheck();
      }
    );
  }
  isFIBulkAdj: boolean = false;
  isMEWABulkAdj: boolean = false;
  private listenToBulkAdjDetailsEvents(processID: string, isDeleteOrRestoreFlow?: boolean) {
    this.hasDeletedGroupsInBulk = false;
    // Clear the Map so the in-place merge doesn't match stale entries from a previous load
    // (retriveBulkAdjDetails already resets bulkViewTableData = [] before calling this)
    this.bulkViewTableDataMap.clear();
    var eventSource = this.commonService.listenForStream(processID);
    eventSource.addEventListener('BULK_DETAILS_STATUS', (event: any) => { });
    eventSource.addEventListener('BULK_ADJ_DETAILS_FETCH', (event: any) => {
      if (event.data) {
        const scrollY = window.scrollY; // capture scroll before any data mutation
        var eventData = JSON.parse(event.data);
        var bulkAdjdetails = eventData['payload']['bulkAdjDetails'];
        this.hasDeletedGroupsInBulk = eventData['payload'][RenewalsConstants.HAS_DELETED_GROUPS] == 'true' ? true : false;
        this.calculateProposedIncreaseAfterFetch(bulkAdjdetails);
        this.calculateSuggestedIncreaseAfterFetch(bulkAdjdetails);
        // this.loadProductAdjustments(bulkAdjdetails);
        // Merge incoming rows in-place when we have a complete identity key, to preserve object
        // identity (keeps trackBy stable → no DOM teardown → no scroll reset).
        // Only merge when all three IDs are present — rows with missing IDs (e.g. not-yet-rated
        // cross-sell rows) would otherwise collapse into each other and disappear from the table.
        bulkAdjdetails.forEach((incoming: any) => {
          const hasFullKey = incoming['opportunityID'] != null
            && incoming['quoteHeaderID'] != null
            && incoming['ratingTransID'] != null;
          const key = `${incoming['opportunityID']}_${incoming['quoteHeaderID']}_${incoming['ratingTransID']}`;
          const existing = hasFullKey ? this.bulkViewTableDataMap.get(key) : undefined;
          if (existing) {
            // Update in-place — same object reference, trackBy sees no change → no DOM teardown
            Object.assign(existing, incoming);
          } else {
            this.bulkViewTableData.push(incoming);
            if (hasFullKey) {
              this.bulkViewTableDataMap.set(key, incoming);
            }
          }
        });
        // addLatestAutoRunConvertedToBulk mutates rows in-place so map references stay valid
        this.addLatestAutoRunConvertedToBulk();
        // Filter to exclude auto-run-only rows; re-sync the map to match the surviving rows
        this.bulkViewTableData = this.bulkViewTableData.filter((data) => {
          const isAutoRunBatch = data['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH;
          const quoteOriginPresent = !!data['quoteOrigin'];
          const isQuoteOriginAutoRun = data['quoteOrigin'] === QUOTE_ORIGIN.AUTO_RUN_BATCH;
          const isCrossSelled = data['isCrossSelled'];

          if (isAutoRunBatch) {
            // For auto-run batches, include only converted auto-run quotes OR userBatch
            return (quoteOriginPresent && !isQuoteOriginAutoRun) || (!quoteOriginPresent && isCrossSelled);
          } else {
            // For user batches exclude autoRunBatches
            return !isQuoteOriginAutoRun;
          }
        });
        // Re-sync the map to exactly the rows still in the array after filtering
        this.bulkViewTableDataMap.clear();
        this.bulkViewTableData.forEach((row: any) => {
          const hasFullKey = row['opportunityID'] != null
            && row['quoteHeaderID'] != null
            && row['ratingTransID'] != null;
          if (hasFullKey) {
            this.bulkViewTableDataMap.set(
              `${row['opportunityID']}_${row['quoteHeaderID']}_${row['ratingTransID']}`, row
            );
          }
        });
        // Preserve one-row-per-groupNumber behaviour: collapse duplicate group rows the same way
        // the original code did (last chunk wins per groupNumber), so batches with multiple
        // quotes that were previously deduplicated continue to render correctly.
        const uniqueArray = [...new Map(this.bulkViewTableData.map(item => [item.groupNumber, item])).values()];
        this.bulkViewTableData = uniqueArray;
        if (this.bulkViewTableData.length == 0) {
          this.disbleBulkAdj = true;
        }
        this.calculateRateActionGrndTotal(bulkAdjdetails);
        this.enableBulkAdjTab();
        if (this.bulkViewTableData.length > 0) {
          this.isFIBulkAdj = StringUtils.isEqual(this.bulkViewTableData[0].fundingType, CommonConstants.FI);
          this.isMEWABulkAdj = StringUtils.isEqual(this.bulkViewTableData[0].fundingType, CommonConstants.MEWA);
          
          // Update download versions based on funding type
          this.updateDownloadVersions();
          // Auto-select versions if groups are already selected
          this.verifyAllBulkDataDetails();
          
          if (StringUtils.isEqual(this.bulkViewTableData[0].fundingType, CommonConstants.FI)) {
            this.bulkTableCols = RenewalsConstants.FI_BULK_TABLE_COLUMNS;
          } else if (StringUtils.isEqual(this.bulkViewTableData[0].fundingType, CommonConstants.MEWA)) {
            this.bulkTableCols = RenewalsConstants.MEWA_BULK_TABLE_COLUMNS;
          } else {
            this.bulkTableCols = [...RenewalsConstants.BULK_TABLE_COLUMNS_BEFORE];
          }
        }
        this.bulkTableDenVisCols = this.getVisDenBulkTableColumns();
        this.bulkAdjData = CreateBatchUtil.constructBulkAdjDataForComparsion(bulkAdjdetails, this.bulkAdjData);
        if (this.checkBulkAdjDataExists()) {
          this.showLoader = false;
          if (isDeleteOrRestoreFlow) {
            this.disbleBulkAdj = false;
          }
        }
        this.enableTieringTab();
        if (this.bulkViewTableData.every(item => !('formulaTieredRateActionPercent' in item))) {
          // Remove object with header 'Formula Tiered RA%' from bulkTableCols
          this.bulkTableCols = this.bulkTableCols.filter(col => col.header !== 'Formula Tiered RA%');
        }
        if (this.bulkViewTableData.every(item => !('uwTieredRateActionPercent' in item))) {
          // Remove object with header 'UW Tiered RA%' from bulkTableCols
          this.bulkTableCols = this.bulkTableCols.filter(col => col.header !== 'UW Tiered RA%');
        }
        this.removeAcaColumns();
        this.cdRef.markForCheck();
        // Safety net: only restore if the position actually moved, to avoid fighting the user's scroll
        requestAnimationFrame(() => { if (window.scrollY !== scrollY) window.scrollTo({ top: scrollY, behavior: 'instant' }); });
      }
    });
    eventSource.addEventListener('BULK_ADJ_DETAILS_FETCH_COMPLETE', (event: any) => {
      eventSource.close();
      if (this.checkBulkAdjDataExists()) {
        this.bulkViewTableData.sort((first, second) => {
          return (first['groupName'] ?? '').localeCompare(second['groupName'] ?? '');
        });
        this.bulkViewTableDataMap.clear();
        this.bulkViewTableData.forEach(row => {
          this.bulkViewTableDataMap.set(`${row['opportunityID']}_${row['quoteHeaderID']}_${row['ratingTransID']}`, row);
        });
        this.bulkAdjDataMap.clear();
        this.bulkAdjData.forEach(row => {
          this.bulkAdjDataMap.set(`${row['opportunityID']}_${row['quoteHeaderID']}_${row['ratingTransID']}`, row);
        });
        this.calculateTotalRateActionPercent();
        if (this.activeTab == 'BULK') {
          this.setAlertVisibility(true, AlertType.SUCCESS, 'Bulk adjustment details loaded successfully');
        }
        this.hideAlertVisibility();
        this.verifyAllBulkDataDetails();
        this.verifyAllAutoRunDataDetails();
        this.cdRef.markForCheck();
        if (event.data) {
          var eventData = JSON.parse(event.data);
          var adjustmentProcessID = eventData['payload']['adjustmentProcessID'];
          var releaseProcessID = eventData['payload']['releaseProcessID'];
          var exhibitFetchProcessID = eventData['payload']['exhibitFetchProcessID'];
          var exhibitFetchStatus = eventData['payload']['exhibitFetchStatus'];
          if (adjustmentProcessID) this.commonService.listenForStream(adjustmentProcessID);
          if (releaseProcessID) {
            var relEventSource = this.commonService.listenForStreamTrackAndFail(releaseProcessID);
            this.listenToBulkReleaseEvents(relEventSource);
          }
          if (exhibitFetchProcessID && null != exhibitFetchProcessID) {
            this.currentExhibitLinkProcessId = exhibitFetchProcessID;
            this.renewalBatchWrapper.renewalBatch['recentExhibitsFetchStatus'] = status;
            if ('In Progress' == exhibitFetchStatus) {
              var exhibitFetchEventSource = this.commonService.listenForStreamTrackAndFail(exhibitFetchProcessID);
              this.listenRenewalExhibitFetchLinkEvents(exhibitFetchEventSource, exhibitFetchProcessID);
            } else {
              this.downloadPrintExhibitsZip(true);
            }
          }
        }
      } else {
        this.showLoader = false;
        if (this.bulkViewTableData.length > 0) {
          if (isDeleteOrRestoreFlow) {
            this.tableDataExist = false;
            this.hasDeletedGroupsInBulk = true;
          } else {
            this.setAlertVisibility(true, AlertType.ERROR, 'Error occured while fetching Bulk adjustment details');
            this.hideAlertVisibility();
          }
        }
      }
      if (this.activeTab == 'AUTORUN') {
        this.setAlertVisibility(true, AlertType.SUCCESS, 'AutoRun details loaded successfully');
        this.hideAlertVisibility();
      }
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('FAILED', (event: any) => {
      eventSource.close();
      this.cdRef.markForCheck();
    });
  }

  private checkBulkAdjDataExists(): boolean {
    return this.bulkViewTableData && this.bulkViewTableData.length > 0;
  }

  private calculateTotalRateActionPercent() {
    this.expTotalRateActionPercent = this.uwAdjService.totalRateActionCalc(this.currentPlanTotPrem, this.renewalPlanTotPrem);
    this.uwTotalRateActionPercent = this.uwAdjService.totalRateActionCalc(this.currentPlanTotPrem, this.adjustedPlanTotprem);
  }

  private calculateRateActionGrndTotal(bulkAdjdetails: any) {
    let calc = UnderwriterAdjustmentService.summingPlanTotprem(bulkAdjdetails);
    if (calc) {
      this.currentPlanTotPrem = this.currentPlanTotPrem + calc['currentPlanTotPrem'];
      this.renewalPlanTotPrem = this.renewalPlanTotPrem + calc['renewalPlanTotPrem'];
      this.adjustedPlanTotprem = this.adjustedPlanTotprem + calc['adjustedRenewalPlanTotPrem'];
    }
  }

  assignChangedValue(rowData, key) {
    if (this.changedKey == key) {
      rowData[key] = this.valueChanged;
      this.valueChanged = '';
      this.cmplnFldCodes = CreateBatchUtil.setorRevertGuardRailMsg(rowData, this.cmplnFldCodes, this.bulkAdjData);
      this.changedKey = '';
    }
  }

  onRateActionChange(key, rowData, eventObj, triggeredImport: boolean = false) {
    let enterdValue: any;
    let eventVal: any;
    this.isDirty = true;
    let ratingPlanId = rowData.ratingTransID;
    if (rowData.invalidRow) {
      rowData.invalidRow = {};
    }
    if (key === 'overallProposedIncrease') {
      this.updateAllAdjustmentsToProposedIncrease(rowData, eventObj);
    }
    if (!(eventObj instanceof InputEvent)) {
      eventVal = eventObj;
    } else {
      const target = eventObj.target as HTMLInputElement; // Type assertion
      eventVal = target.value;
    }
    if (eventVal.toString().includes('%') || eventVal.toString().includes(',')) {
      enterdValue = eventVal.replace('%', '').replace(',', '');
    } else {
      enterdValue = eventVal;
    }
    if (!triggeredImport) {
      this.valueChanged = enterdValue;
      this.changedKey = key;
    }

    const allowedEmptyFields = ['renewalWHAPercent', 'wholeHealthAdjustmentFactor', 'riskFactor', 'uwAdjustmentFactor', 'currentRiskFactor'];
    
    if ((key === 'currentRiskFactor' || key === 'riskFactor' || key === 'uwAdjustmentFactor') && 
        rowData?.quotingType === 'MEWA' && !rowData?.alternateQuote &&
        enterdValue !== '' && enterdValue !== null && enterdValue !== undefined && isNaN(enterdValue)) {
      rowData['invalidinput'] = true;
      this.updateRateActionAdjustment(rowData, key, ratingPlanId, enterdValue);
      if (this.isRateActionAdjColumnProperty(key)) {
        const planIdx = key.startsWith('adjPlan') ? parseInt(key.replace('adjPlan', '')) - 1 : null;
        rowData["overallProposedIncrease"] = this.calculateProposedIncrease(rowData, planIdx, enterdValue);
      } else {
        rowData["overallProposedIncrease"] = this.calculateProposedIncrease(rowData);
      }
      return;
    }
    
    if ((enterdValue === '' && !allowedEmptyFields.includes(key)) || isNaN(enterdValue)) {
      rowData['invalidinput'] = true;
      this.updateRateActionAdjustment(rowData, key, ratingPlanId, enterdValue);
      if (this.isRateActionAdjColumnProperty(key)) {
        const planIdx = key.startsWith('adjPlan') ? parseInt(key.replace('adjPlan', '')) - 1 : null;
        rowData["overallProposedIncrease"] = this.calculateProposedIncrease(rowData, planIdx, enterdValue);
      } else {
        rowData["overallProposedIncrease"] = this.calculateProposedIncrease(rowData);
      }
      return;

    } else {
      if (rowData?.quotingType === 'MEWA' && !rowData?.alternateQuote) {
        // Check each field, using the current enterdValue for the field being edited
        const currentRiskFactorValue = key === 'currentRiskFactor' ? enterdValue : rowData.currentRiskFactor;
        const riskFactorValue = key === 'riskFactor' ? enterdValue : rowData.riskFactor;
        const uwAdjFactorValue = key === 'uwAdjustmentFactor' ? enterdValue : rowData.uwAdjustmentFactor;
        
        const currentRiskFactorValid = !currentRiskFactorValue || currentRiskFactorValue === '' || !isNaN(currentRiskFactorValue);
        const riskFactorValid = !riskFactorValue || riskFactorValue === '' || !isNaN(riskFactorValue);
        const uwAdjFactorValid = !uwAdjFactorValue || uwAdjFactorValue === '' || !isNaN(uwAdjFactorValue);
        
        rowData['invalidinput'] = !(currentRiskFactorValid && riskFactorValid && uwAdjFactorValid);
      } else {
        rowData['invalidinput'] = false;
      }
    }
    if (rowData['status']) {
      if (key == 'adjustedRateActionPercent' || key === 'renewalWHAPercent') {
        let calcProposedIncrease =
          key === 'renewalWHAPercent' ? rowData['adjustedRateActionPercent'] : enterdValue;
        if ((rowData[key] || key === 'renewalWHAPercent') && CreateBatchUtil.checkExpFactorsPresent(rowData)) {


          let mpc = this.getExpGrandTotal(rowData, enterdValue)


          let fundingType = this.isFIBulkAdj ? CommonConstants.FI : CommonConstants.ABF;
          let expAdjFactor = this.uwAdjService.callRateActionForBulk(
            calcProposedIncrease,
            rowData['data']['factors']['experienceFactors']['currentComponentTotal']['totalPremium'],
            rowData['data']['factors'],
            rowData['data']['factors']['experienceFactors']['experienceAdjustmentFactor'],
            rowData['data']['medicalAlternateTier'],
            fundingType,
            mpc
          );
          if (StringUtils.isEqual(key, CommonConstants.RENEWAL_WHA_PERCENT)) {
            if (enterdValue == 0) {
              delete rowData[CommonConstants.RENEWAL_WHA_PERCENT];
            } else {
              rowData[CommonConstants.RENEWAL_WHA_PERCENT] = enterdValue;
            }
          }
          let whSaving = rowData[CommonConstants.RENEWAL_WHA_PERCENT];
          if (!StringUtils.isUndefined(whSaving)) {
            whSaving = whSaving / 100;
            expAdjFactor *= (1 - whSaving);
          }
          rowData['totalQlAdj'] = expAdjFactor;
          this.calculateRateActionPercent(rowData, expAdjFactor, enterdValue);
        }
      } else if ((key == 'asoAdminFee' || key == 'sslPremium' || key == 'aslPremium' || key == 'terminalLiability' || key == 'maxPaidClaim') && rowData[key]) {
        if (!rowData['totalQlAdj'] && CreateBatchUtil.checkExpFactorsPresent(rowData)) {
          let mpc = this.getExpGrandTotal(rowData, rowData['adjustedRateActionPercent'])
          rowData['totalQlAdj'] = this.uwAdjService.calculateRateActionFactor(
            this.getRateActionPercent(rowData, rowData['adjustedRateActionPercent'] || rowData['blendedIncrease'] * 100),
            rowData['data']['factors']['experienceFactors']['currentComponentTotal']['totalPremium'],
            mpc && mpc?.quoteMonthlyGrandTotal ? mpc?.quoteMonthlyGrandTotal : rowData['data']['factors']['experienceFactors']['expComponentTotal']['totalPremium'],
            rowData['data']['factors']['experienceFactors']['experienceAdjustmentFactor']
          );
        }
        if (!rowData['calculatedIntialCompRates']) {
          let quoteDetail = {
            medical: { currentPlans: rowData['currentPlans'] },
            uwAdjustment: {
              abfRateActionAdjustment: {
                totalQlAdj: rowData['totalQlAdj'],
                abfRateActionPercent: rowData['adjustedRateActionPercent'] || rowData['blendedIncrease'] * 100
              },
              outputTier: rowData['data']['medicalOutputTier'],
              tierRatioCalculationType: rowData['data']['factors']['tierRatioCalculationType']
            },
            factors: rowData['data']['factors']
          };
          rowData['quoteDetail'] = quoteDetail;
          let calculatedCompRates = this.uwAdjService.calculateQtLvlAdjAndComponentRates(rowData['data']['proposedPlans'], quoteDetail);
          rowData['calculatedIntialCompRates'] = JSON.parse(JSON.stringify(calculatedCompRates));
          let abfRateActionAdjustments = {
            abfRateActionPercent: rowData['adjustedRateActionPercent'] || rowData['blendedIncrease'] * 100,
            totalQlAdj: rowData['totalQlAdj'],
            asoAdminFee: key == 'asoAdminFee' ? enterdValue : rowData['asoAdminFee'],
            sslPremium: key == 'sslPremium' ? enterdValue : rowData['sslPremium'],
            aslPremium: key == 'aslPremium' ? enterdValue : rowData['aslPremium'],
            terminalLiability: key == 'terminalLiability' ? enterdValue : rowData['terminalLiability'],
            maxPaidClaim: key == 'maxPaidClaim' ? enterdValue : rowData['maxPaidClaim']
          };
          rowData['quoteDetail']['uwAdjustment']['abfRateActionAdjustment'] = abfRateActionAdjustments;
          this.uwAdjService.calculateComponentAdjFactors(rowData['data']['factors'], calculatedCompRates, calculatedCompRates, abfRateActionAdjustments);
          rowData['calculatedCompRates'] = calculatedCompRates;
          rowData['adjustedRateActionPercent'] = abfRateActionAdjustments['abfRateActionPercent'];
        }

        if (
          rowData[key] &&
          rowData['data'] &&
          rowData['data']['factors']['experienceFactors'] &&
          rowData['data']['factors']['experienceFactors'] &&
          rowData['data']['factors']['experienceFactors']['currentComponentTotal'] &&
          rowData['data']['factors']['experienceFactors']['currentComponentTotal'][key]
        ) {
          let adjFactor = this.uwAdjService.calculateRateActionFactor(
            enterdValue,
            rowData['data']['factors']['experienceFactors']['currentComponentTotal'][key],
            rowData['calculatedIntialCompRates'][this.uwAdjService.getKey(key, false)],
            1
          );
          rowData['quoteDetail']['uwAdjustment']['abfRateActionAdjustment'][key] = enterdValue;
          rowData['calculatedCompRates'][this.uwAdjService.getKey(key, true)] = adjFactor;
          rowData['calculatedCompRates'] = this.uwAdjService.calculateQtLvlAdjAndComponentRates(
            rowData['data']['proposedPlans'],
            rowData['quoteDetail'],
            rowData['calculatedCompRates']
          );
          this.uwAdjService.calculateComponentPercentage(
            rowData['data']['factors']['experienceFactors']['currentComponentTotal'],
            rowData['calculatedCompRates']
          );
          rowData['quoteDetail']['uwAdjustment']['abfRateActionAdjustment'][key] = enterdValue;
          this.uwAdjService.calculateComponentAdjFactors(
            rowData['data']['factors'],
            rowData['calculatedCompRates'],
            rowData['calculatedIntialCompRates'],
            rowData['quoteDetail']['uwAdjustment']['abfRateActionAdjustment']
          );
          rowData['maxPaidClaim'] = rowData['calculatedCompRates']['maxPaidClaimCompPercent'];
          if (!rowData['asoAdminFee']) {
            rowData['asoAdminFee'] = rowData['calculatedCompRates']['asoAdminCompPercent'];
          }
          if (!rowData['sslPremium']) {
            rowData['sslPremium'] = rowData['calculatedCompRates']['sslPremCompPercent'];
          }
          if (!rowData['aslPremium']) {
            rowData['aslPremium'] = rowData['calculatedCompRates']['aslPremCompPercent'];
          }
          if (!rowData['terminalLiability']) {
            rowData['terminalLiability'] = rowData['calculatedCompRates']['terminalLiabilityCompPercent'];
          }
        }
      }
      else if (rowData.quotingType === 'MEWA' && 
               (key === 'currentRiskFactor' || key === 'riskFactor' || key === 'uwAdjustmentFactor' || key === 'wholeHealthAdjustmentFactor')) {
        
        rowData[key] = enterdValue;
        
        let quoteDetail = {
          medical: { 
            riskFactor: rowData.data?.medical?.riskFactor 
          },
          opportunityType: CommonConstants.RENEWAL_LOCAL,
          uwAdjustment: {
            quoteAdjustments: {
              currentRiskFactor: rowData.currentRiskFactor,
              riskFactor: rowData.riskFactor,
              uwAdjustmentFactor: rowData.uwAdjustmentFactor,
              wholeHealthAdjustmentFactor: rowData.wholeHealthAdjustmentFactor
            },
            outputTier: rowData['data']['medicalAlternateTier'],
            tierRatioCalculationType: rowData['data']['factors']['tierRatioCalculationType']
          },
          factors: rowData['data']['factors']
        };
        
        rowData['quoteDetail'] = quoteDetail;
      }
      if (this.isRateActionAdjColumnProperty(key)) {
        this.updateRateActionAdjustment(rowData, key, ratingPlanId, enterdValue);
        const planIdx = key.startsWith('adjPlan') ? parseInt(key.replace('adjPlan', '')) - 1 : null;
        rowData["overallProposedIncrease"] = this.calculateProposedIncrease(rowData, planIdx, enterdValue);
      }
      if (rowData['data']['proposedPlans']) {
        this.invokeRatesCalAndCheckGuardRails(rowData);
        if (key == 'adjustedRateActionPercent' || key == 'renewalWHAPercent') {
          this.adjustedPlanTotprem = UnderwriterAdjustmentService.calculateUWGrandTotal(rowData, this.bulkViewTableData);
          this.uwTotalRateActionPercent = this.uwAdjService.totalRateActionCalc(this.currentPlanTotPrem, this.adjustedPlanTotprem);
        }
      }
    }
  }

  getExpGrandTotal(rowData: any, enterdValue) {
    if (
      rowData['data'] &&
      rowData['data']['proposedPlans'] &&
      rowData['data']['proposedPlans'].length > 0 &&
      rowData['currentPlans'] &&
      rowData['currentPlans'].length > 0 &&
      this.customTierRatioTypeRateActionFixEnabled
    ) {
      let proposedPlansCopy = JSON.parse(JSON.stringify(rowData['data']['proposedPlans'].filter(x => x?.planTypeRequested == 'F')));
      let quoteDetail = {
        medical: { currentPlans: rowData['currentPlans'] },
        uwAdjustment: {
          abfRateActionAdjustment: {
            totalQlAdj: rowData['data']['factors']['experienceFactors']['experienceAdjustmentFactor'],
            abfRateActionPercent: enterdValue
          },
          outputTier: rowData['data']['medicalAlternateTier'],
          tierRatioCalculationType: rowData['data']['factors']['tierRatioCalculationType']
        },
        factors: rowData['data']['factors'],
        medicalOutputTier: rowData['data']['medicalOutputTier']
      };
      if (!this.isFIBulkAdj && !(rowData?.fundingType == 'ABF' && ((rowData?.alternateQuote && !rowData?.altMarket) || (rowData?.alternateQuote && rowData?.altMarket && rowData?.currentPlansFundingType != 'ABF')))) {
        proposedPlansCopy = this.uwAdjService.calculateQtLvlAdjAndComponentRates(proposedPlansCopy, quoteDetail, null, true);

        // Copy all key-values from calRateInfo to rateInfo for each plan in proposedPlansCopy
        if (proposedPlansCopy && Array.isArray(proposedPlansCopy)) {
          proposedPlansCopy.forEach(plan => {
            if (plan.calRateInfo && plan.rateInfo) {
              Object.keys(plan.calRateInfo).forEach(key => {
                if (plan.rateInfo.hasOwnProperty(key)) {
                  plan.rateInfo[key] = plan.calRateInfo[key];
                }
              });
            }
          });
        }
        // adj factor calc
        let mpc = JSON.parse(JSON.stringify(rowData["medicalPremiumComparison"])) || {};
        this.createTempQuoteRatingPlanID(mpc);
        let requestedTier = rowData['data']['medicalOutputTier'];
        let initialTier = requestedTier;
        let quoteData = {
          medical: {
            proposedPlans: rowData['currentPlans']
          },
          virginGroup: rowData["medicalPremiumComparison"]["virginGroup"],
          factors: rowData['data']['factors'],
          medicalPremiumComparison: rowData["medicalPremiumComparison"]
        };
        mpc = this.expGrandTotalCalcService.calculateQuoteRates(mpc, proposedPlansCopy, quoteData, requestedTier, initialTier);
        return mpc;
      }
    }
    return null;
  }

  createTempQuoteRatingPlanID(mpc: MedicalPremiumComparison) {
    if (mpc && mpc.planComparison) {
      mpc.planComparison.forEach(x => {
        if (!x.tempQuoteRatingPlanID && x.quoteRatingPlanID) {
          x.tempQuoteRatingPlanID = x.quoteRatingPlanID;
          x.quoteRatingPlanID = x.quoteRatingPlanID + "_" + x.currPlanId;
        }
      });
    }
  }

  private getRateActionPercent(rowData, enterdValue) {
    let renewalHWPercent = rowData['renewalWHAPercent'];
    return renewalHWPercent ? enterdValue - renewalHWPercent : enterdValue;
  }

  private calculateRateActionPercent(rowData: any, expAdjFactor: number, enterdValue) {
    if (
      rowData['data'] &&
      rowData['data']['proposedPlans'] &&
      rowData['data']['proposedPlans'].length > 0 &&
      rowData['currentPlans'] &&
      rowData['currentPlans'].length > 0
    ) {
      let quoteDetail = {
        medical: { currentPlans: rowData['currentPlans'] },
        uwAdjustment: {
          abfRateActionAdjustment: {
            totalQlAdj: expAdjFactor,
            abfRateActionPercent: enterdValue
          },
          outputTier: rowData['data']['medicalAlternateTier'],
          tierRatioCalculationType: rowData['data']['factors']['tierRatioCalculationType']
        },
        factors: rowData['data']['factors'],
        medicalOutputTier: rowData['data']['medicalOutputTier']
      };
      rowData['quoteDetail'] = quoteDetail;
      if (!this.isFIBulkAdj) {
        let calculatedCompRates = this.uwAdjService.calculateQtLvlAdjAndComponentRates(rowData['data']['proposedPlans'], quoteDetail);
        this.uwAdjService.calculateComponentPercentage(rowData['data']['factors']['experienceFactors']['currentComponentTotal'], calculatedCompRates);
        Object.keys(calculatedCompRates).forEach(key => {
          if (!Number.isFinite(calculatedCompRates[key])) {
            calculatedCompRates[key] = 0;
          }
        });
        rowData['calculatedIntialCompRates'] = JSON.parse(JSON.stringify(calculatedCompRates));
        rowData['calculatedCompRates'] = calculatedCompRates;
        rowData = CreateBatchUtil.setCalculatedRateActionPercent(rowData, calculatedCompRates);
        this.uwAdjService.calculateComponentAdjFactors(
          rowData['data']['factors'],
          calculatedCompRates,
          calculatedCompRates,
          rowData['quoteDetail']['uwAdjustment']['abfRateActionAdjustment']
        );
      }
    }
  }

  formatNumbers(value, field) {
    if (this.fieldToPercentConvert.includes(field) && (value || value == 0) && !isNaN(value)) return formatPercent(value, this.locale, '1.0-4');

    if (this.fieldToConcatPrcnt.includes(field) && !this.isEmptyValue(value) && (value || value == 0) && !isNaN(value))
      return formatPercent(value / 100, this.locale, '1.0-4');

    if (field == 'cyTotalClmsOverSsl' || field == 'cySurplusOrDeficit')
      return value == null ? value : formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'));

    if (field == 'renewalMonthlyGrandTotal' && !this.isEmptyValue(value))
      return formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.0-0'); 

    return value;
  }

  checkValidNumber(key, value, disabled: boolean, colHeader, invalidRow, rowData?) {
    if (disabled) {
      return '';
    }
    
    if (invalidRow && invalidRow[colHeader]) {
      return 'redContent';
    }
    
    if (key === 'renewalWHAPercent' || key === 'wholeHealthAdjustmentFactor') {
      return (value !== '' && value !== undefined && value !== null && isNaN(value)) ? 'redContent' : '';
    }
    
    // Guard rail validation for MEWA risk factor (excluding currentRiskFactor)
    if (key === 'riskFactor' && rowData?.quotingType === 'MEWA' && value !== '' && value !== undefined && value !== null) {
      const guardRails = rowData?.data?.factors?.guardRails;
      if (guardRails && guardRails.length > 0) {
        const riskFactorGuardRail = guardRails.find(gr => gr.attrbNm === 'request.medical.riskFactor');
        if (riskFactorGuardRail) {
          const numValue = Number(value);
          if (!isNaN(numValue) && (numValue < riskFactorGuardRail.minVal || numValue > riskFactorGuardRail.maxVal)) {
            return 'redContent';
          }
        }
      }
    }
    
    if (value === null || value === undefined || value === '') return '';
    if (key === 'currentRiskFactor') {
      return isNaN(value) ? 'redContent' : '';
    }
    
    if (isNaN(value) || (invalidRow && invalidRow[colHeader])) return 'redContent';
    return '';
  }

  getGuardRailTooltipMessage(key, value, rowData) {
    // Check for upload validation errors first (higher priority)
    if (rowData?.invalidRow) {
      if (key === 'riskFactor' && rowData.invalidRow['Tiered Risk Factor']) {
        return rowData.invalidRow['Tiered Risk Factor'];
      }
      if (key === 'currentRiskFactor' && rowData.invalidRow['Current Risk Factor']) {
        return rowData.invalidRow['Current Risk Factor'];
      }
      if (key === 'uwAdjustmentFactor' && rowData.invalidRow['UW Risk Adjustment Factor']) {
        return rowData.invalidRow['UW Risk Adjustment Factor'];
      }
    }
    
    // Then check guard rail validation
    if (key === 'riskFactor' && rowData?.quotingType === 'MEWA' && value !== '' && value !== undefined && value !== null) {
      const guardRails = rowData?.data?.factors?.guardRails;
      if (guardRails && guardRails.length > 0) {
        const riskFactorGuardRail = guardRails.find(gr => gr.attrbNm === 'request.medical.riskFactor');
        if (riskFactorGuardRail) {
          const numValue = Number(value);
          if (!isNaN(numValue) && (numValue < riskFactorGuardRail.minVal || numValue > riskFactorGuardRail.maxVal)) {
            return `MEWA tiered risk factor is out of range : ${riskFactorGuardRail.minVal} - ${riskFactorGuardRail.maxVal}`;
          }
        }
      }
    }
    return '';
  }

  getNestedValue(obj: any, path: string) {
    return path.split('.').reduce((o, key) => o?.[key], obj);
  }

  getClassForValues(field: string, value: number) {
    if (field == 'cyTotalClmsOverSsl' || field == 'cySurplusOrDeficit') {
      return value < 0 ? 'lesser' : '';
    }
  }
  getToolTipHeaderValue() {
    return this.isFIBulkAdj ? 'Incurred' : 'Paid';
  }
  getToolTipValue(field: string, bulkData: any) {
    if (field == 'cyTotalClmsOverSsl')
      return bulkData['sslDeductable'] ? formatCurrency(bulkData['sslDeductable'], this.locale, getCurrencySymbol('USD', 'wide'), '', '2.0') : '';
    if (field == 'cyCntrctMaxClmFndLr') return bulkData['aggSLCorridor'] ? formatPercent(bulkData['aggSLCorridor'], this.locale, '1.0-4') : '';
    if (field == 'cySurplusOrDeficit') return bulkData['surplusRefund'] ? formatPercent(bulkData['surplusRefund'], this.locale, '1.0-4') : '';
  }

  grpNameAndNumberValidation = () => {
    const groupNameValue = this.batchSearchForm.get('groupName').value as string;
    const groupNumberValue = this.batchSearchForm.get('groupNumber').value as string;
    if(groupNameValue.length !== 0 || groupNumberValue.length !== 0) {
      this.groupNumbersFile = null;
    }
    if (this.groupNumbersFile || groupNameValue.length !== 0 || groupNumberValue.length !== 0) {
      let states = [];
      let months = [];
      this.commonService.getStateList().forEach((val: any) => {
        states.push(val.value);
      });
      this.selectstate = states;
      this.availableRenewalMonths.forEach((val: any) => {
        months.push(val.value);
      });
      this.selectmonths = months;
      if(this.selectmonths.length > 0) {
        const currentYear = new Date().getFullYear();
        this.selectedYear = currentYear;
        this.selectedRenewalMonthYear = this.getRenewalMonthYears(this.selectmonths, this.selectedYear);
      }
    } else if (groupNameValue.length === 0 && groupNumberValue.length === 0 && !this.groupNumbersFile) {
      this.selectstate = [];
      this.selectmonths = [];
      this.selectedYear = null;
      this.selectedRenewalMonthYear = [];
    }
  }

  disableRateActionInput(bulkdata: any): boolean {
    return (
      bulkdata['status'] === QuoteRenewalStatus.AWAITING_RISK_SCORE ||
      bulkdata['status'] === QuoteRenewalStatus.AWAITING_P2A_DATA ||
      bulkdata['status'] === QuoteRenewalStatus.RECEIVED ||
      bulkdata['status'] === QuoteRenewalStatus.PROCESSING ||
      bulkdata['status'] === QuoteRenewalStatus.FAIL ||
      bulkdata['adjustmentStatus'] == 'SUBMITTED' ||
      bulkdata['status'] == QuoteRenewalStatus.FAILED_TO_GATEWAY ||
      bulkdata['status'] == QuoteRenewalStatus.SENT_TO_RARE ||
      bulkdata['adjustmentStatus'] == 'QUEUED' ||
      bulkdata?.isCrossSelled ||
      this.disableTieringInput
    );
  }
  trackByFunction = (_index: number, item: any): string => {
    // Stable key independent of index — matches the canonical row identity used in bulkViewTableDataMap/autoRunDetailsMap
    return `${item.groupNumber}_${item.opportunityID}_${item.quoteHeaderID}_${item.ratingTransID}`;
  };
  getSubmissionToopTipStatus(groupDetail: any, submissionFailCheckPoint: any): string {
    if (groupDetail) {
      if (!StringUtils.isEmpty(submissionFailCheckPoint)) {
        if (
          StringUtils.isEqualIgnoreCase(submissionFailCheckPoint, groupDetail.submissionFailCheckPoint) &&
          StringUtils.isEqualIgnoreCase(groupDetail.submissionStatus, QuoteSubmissionStatus.FAILED)
        ) {
          return groupDetail.submissionErrors || 'Something went wrong !!!';
        }
      } else if (StringUtils.isEqualIgnoreCase(groupDetail.specialtySubmittedStatus, QuoteSubmissionStatus.FAILED)) {
        return groupDetail.specialtyErrors.join('\n') || 'Something went wrong !!!';
      }
    }
    return '';
  }
  deleteSelectedGroups = (): void => {
    let userConfirmation = confirm(RenewalsConstants.DELETE_CONFIRMATION_MSG);
    if (userConfirmation) {
      let deletedGroups = this.renewalBatchWrapper.renewalBatchDetails.filter((group) => group['included']);
      if (deletedGroups && deletedGroups.length > 0) {
        this.hasDeletedGroupsInBatch = true;
        localStorage.setItem('deletedGroups', JSON.stringify(deletedGroups));
        var groupIds: string[] = [];
        var grouNbrList: string[] = [];

        for (let index = 0; index < deletedGroups.length; index++) {
          if (deletedGroups[index]['id']) groupIds.push(deletedGroups[index]['id']);

          if (deletedGroups[index]['submissionStatus']) {
            grouNbrList.push(deletedGroups[index]['groupNumber']);
          }
        }
        if (groupIds && groupIds.length > 0) {
          this.constructDeleteInfoAndinvokeDelete(groupIds, grouNbrList, RenewalsConstants.BATCH);
        }
        this.renewalBatchWrapper.renewalBatchDetails = this.renewalBatchWrapper.renewalBatchDetails.filter((group) => !group['included']);
        
        this.enableQuoteOptionsData();
        this.enableTieringTab();
        this.batchSubmitOptions = RenewalsConstants.BATCH_SUBMIT_OPTIONS;
        this.showSubmitOptions();
        this.searchResults = this.searchResults.filter((group) => !group['included']);
        if (this.renewalBatchWrapper.renewalBatchDetails.length < 1) {
          this.checkAllDetails = false;
          this.disbleBulkAdj = true;
        }
        this.cdRef.markForCheck();
      }
    }
  }

  private invokeRatesCalAndCheckGuardRails(rowData: any): void {
    this.cmplnFldCodes = [];
    let proposedPlan = rowData.data.proposedPlans;
    for (let plan of proposedPlan) {
      if (this.isFIBulkAdj) {
        this.uwAdjService.getFiAdjusments(plan, rowData['quoteDetail']);
      } else if (rowData.quotingType === 'MEWA') {
        this.uwAdjService.getMEWAAdjusments(plan, rowData['quoteDetail']);
        if (plan.factors?.mewaFactors) {
          rowData.finalRiskFactor = plan.factors.mewaFactors.finalRiskFactor;
          rowData.whsReduction = (plan.factors.mewaFactors.whsReduction && 
                                  plan.factors.mewaFactors.whsReduction !== 0) 
                                  ? plan.factors.mewaFactors.whsReduction 
                                  : '';
        }
      } else {
        this.uwAdjService.getAbfExperienceAdjusments(plan, rowData['quoteDetail'], rowData['calculatedCompRates']);
      }
      if (plan.failedGuardRails && plan.failedGuardRails.includes('factors.abfFactors.excessOfLimit')) this.cmplnFldCodes.push(plan.contractCode);
    }
  }

  disableDeleteOption() {
    for (let grp of this.renewalBatchWrapper.renewalBatchDetails) {
      if (
        grp['included'] &&
        grp['batchID'] &&
        grp['currentQuoteStatusBatchID'] &&
        grp['batchID'] != grp['currentQuoteStatusBatchID'] &&
        grp['submissionStatus'] &&
        grp['submissionStatus'] != this.groupSubmissionStatus.FAILED
      ) {
        return true;
      }
    }
  }
  isEmptyValue(value) {
    return value === null || value === undefined || value === '';
  }

  restoreGroups(page) {
    let restoreInfo = {
      batchID: this.renewalBatchWrapper.renewalBatch.id
    };
    this.renewalsService.restoreRenewalGroups(restoreInfo).subscribe(
      (res: any ) => {
        this.setLoaderVisibility(false);
        if (res && res?.exceptions) {
          let errorMsg = res?.description;
          this.setAlertVisibility(true, AlertType.WARNING, errorMsg);
         } else {
          this.setAlertVisibility(true, AlertType.SUCCESS, RenewalsConstants.RESTORE_SUCCESS_MSG);
        }
        this.setActiveTab(page, true);
        this.hideAlertVisibility();
        this.cdRef.markForCheck();
      },
      (error) => {
        this.setLoaderVisibility(false);
        console.error('Error while restoring grps ', error);
        this.cdRef.markForCheck();
      }
    );
  }
  deleteGrpsFromBulkTab() {
    let userConfirmation = confirm(RenewalsConstants.DELETE_CONFIRMATION_MSG);
    if (userConfirmation) {
      let deletedGroupNbrList = this.bulkViewTableData.filter((group) => group['included']).map((ele) => ele['groupNumber']);
      let groupsWithId = this.bulkViewTableData.filter((e) => deletedGroupNbrList.includes(e['groupNumber']));
      var groupIds: string[] = [];

      for (let grp of groupsWithId) {
        if (grp['renewalBatchDetailID']) {
          groupIds.push(grp['renewalBatchDetailID']);
        }
      }
      if (groupIds && groupIds.length > 0) {
        this.hasDeletedGroupsInBulk = true;
        this.constructDeleteInfoAndinvokeDelete(groupIds, deletedGroupNbrList, RenewalsConstants.BULK);
      }
      //Remove from main batch details if present
      if (groupsWithId && groupsWithId.length > 0) {
        this.renewalBatchWrapper.renewalBatchDetails = this.renewalBatchWrapper.renewalBatchDetails.filter(
          (group: any) => !groupsWithId.some(g => g.groupNumber === group?.groupNumber)
        );
        
        this.enableQuoteOptionsData();
      }
      this.bulkViewTableData = this.bulkViewTableData.filter((grp) => !grp['included']);
      this.resetTotalRateActionData();
      if (this.bulkViewTableData.length < 1) {
        this.checkAllBulkDetails = false;
        this.disbleBulkAdj = true;
      } else {
        this.calculateRateActionGrndTotal(this.bulkViewTableData);
        this.calculateTotalRateActionPercent();
      }
      this.cdRef.markForCheck();
    }
  }
  private constructDeleteInfoAndinvokeDelete(groupIds: string[], grouNbrList: string[], tab: string) {
    let deleteInfo = {
      batchID: this.renewalBatchWrapper.renewalBatch.id,
      renewalGroupIdList: groupIds,
      renewalGroupNbrList: grouNbrList
    };
    this.setLoaderVisibility(true);
    this.renewalsService.deleteRenewalGroups(deleteInfo).subscribe(
      (res) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(true, AlertType.SUCCESS, RenewalsConstants.DELETE_SUCCESS_MSG);
        this.hideAlertVisibility();
        this.renewalBatchWrapper.renewalBatch[RenewalsConstants.HAS_DELETED_GROUPS] = true;
      },
      (error) => {
        this.setLoaderVisibility(false);
        console.error('Error while deleting grps ', error);
      }
    );
  }

  resetTotalRateActionData() {
    this.uwTotalRateActionPercent = this.expTotalRateActionPercent = '';
    this.currentPlanTotPrem = this.renewalPlanTotPrem = this.adjustedPlanTotprem = 0;
  }

  overRideDetailsChanged(event: any, groupNumber: any, oldValue: any, category: string) {
    if (this.isValidInputAndCategory(category, event)) {
      if (!this.overRideDetails) {
        this.overRideDetails = {};
      }
      if (category) {
        let newValue = null;
        if (event.target) {
          newValue = event.target.value ? parseFloat(event.target.value) : null;
        } else {
          newValue = event.value;
        }
        this.setOverridden(groupNumber, category, newValue);
        if (!this.overRideDetails[category]) {
          this.overRideDetails[category] = {};
          this.overRideDetails[category][groupNumber] = {
            oldValue: oldValue,
            newValue: newValue
          };
        } else {
          let grpNbrDetails = this.overRideDetails[category][groupNumber];
          if (!grpNbrDetails) {
            this.overRideDetails[category][groupNumber] = {
              oldValue: oldValue,
              newValue: newValue
            };
          } else {
            this.overRideDetails[category][groupNumber]['newValue'] = newValue;
          }
        }
        if (newValue == oldValue && this.overRideDetails[category]?.[groupNumber]) {
          delete this.overRideDetails[category][groupNumber];
        }
      }
      if (
        StringUtils.isEqual(CommonConstants.REFUND_PCT, category) &&
        this.overRideDetails['aslErrors'] &&
        this.overRideDetails['refundPctErrors'].length > 0
      ) {
        this.overRideDetails['refundPctErrors'] = this.overRideDetails['refundPctErrors'].filter((refundPctError) => refundPctError.groupNumber != groupNumber);
      } else if (StringUtils.isEqual('ASL', category) && this.overRideDetails['aslErrors']?.length > 0) {
        this.overRideDetails['aslErrors'] = this.overRideDetails['aslErrors'].filter((aslError) => aslError.groupNumber != groupNumber);
      }
    } else {
      if (!this.overRideDetails) {
        this.overRideDetails = {
          aslErrors: [],
          refundPctErrors: [],
          commissionErrors: []
        };
      } else {
        if (this.overRideDetails && !this.overRideDetails.aslErrors) {
          this.overRideDetails['aslErrors'] = [];
        }
        if (this.overRideDetails && !this.overRideDetails.refundPctErrors) {
          this.overRideDetails['refundPctErrors'] = [];
        }
      }
      this.overRideDetails = RenewalsUtil.updateOverRideDetails(this.renewalBatchWrapper, category, groupNumber, this.overRideDetails);
    }
  }

  isValidInputAndCategory(category: string, event: any): boolean {
    return (
      StringUtils.isEqual(CommonConstants.SSL, category) ||
      (StringUtils.isEqual(CommonConstants.REFUND_PCT, category) &&
        ValidationService.validateRefundPCTDecimalNumber(event.target.value ? parseFloat(event.target.value) : 0)) ||
      (StringUtils.isEqual(CommonConstants.ASL, category) &&
        ValidationService.validateASLDecimalNumber(event.target.value ? parseFloat(event.target.value) : 0))
    );
  }

  updateOverRidesToBatchDetails(renewalBatchWrapper: any) {
    if (this.overRideDetails) {
      const overridesToApply = [
        { detailName: CommonConstants.SSL, batchFieldToUpdate: 'sslLevel' },
        { detailName: CommonConstants.REFUND_PCT, batchFieldToUpdate: 'refundPct' },
        { detailName: CommonConstants.ASL, batchFieldToUpdate: 'aslLevel' },
        { detailName: CommonConstants.COMMISSION, batchFieldToUpdate: 'commissionValue' },
        { detailName: CommonConstants.COMMISSION_TYPE, batchFieldToUpdate: 'commissionType' }
      ];

      for (let overrideDetail of overridesToApply) {
        if (this.overRideDetails[overrideDetail.detailName]) {
          renewalBatchWrapper.renewalBatchDetails.forEach((batchDetail) => {
            const grpNbr = batchDetail['groupNumber'];
            if (this.overRideDetails[overrideDetail.detailName][grpNbr]) {
              batchDetail[overrideDetail.batchFieldToUpdate] = this.overRideDetails[overrideDetail.detailName][grpNbr]['newValue'];
            }
          });
        }
      }
    }
  }


  getExhibitDownloadLink() {
    this.setAlertVisibility(false);
    let selectedBulkviewData = this.bulkViewTableData.filter((renewal) => renewal['included']);
    let data = {};
    data['opportunityList'] = [];
    selectedBulkviewData.forEach((viewData) => {
      let opportunity = {
        opportunityID: viewData['opportunityID'],
        quoteHeaderID: viewData['quoteHeaderID'],
        fundingType: viewData['fundingType'],
        lob: viewData['lob'],
        ratingTransID: viewData['ratingTransID'],
        accountName: viewData['groupName'],
        metaTransId: viewData['metaTransID'],
        batchOrigin: this.renewalBatchWrapper?.renewalBatch?.batchOrigin,
        quoteOrigin: viewData['quoteOrigin'] ? viewData['quoteOrigin'] : this.renewalBatchWrapper?.renewalBatch?.quoteOrigin,
        userInfo: viewData['userInfo']
      };
      data['opportunityList'].push(opportunity);
    });
    this.showExhibitsZipDownloadLink = false;
    this.renewalsService.fetchBulkExhibitsZipDownloadLink(data, this.renewalBatchWrapper.renewalBatch['id']).subscribe(
      (response) => {
        if (response && response['description'] && !response['description'].startsWith('No Data found')) {
          var eventSource = this.commonService.listenForStream(response['description']);
          this.listenRenewalExhibitFetchLinkEvents(eventSource, response['description']);
        } else {
          this.setAlertVisibility(true, AlertType.WARNING, 'No Data found to Fetch Exhibits Download Link', false);
          this.hideAlertVisibility();
        }
      },
      (error) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(true, AlertType.WARNING, error.exceptions[0].message);
        this.hideAlertVisibility();
      }
    );
  }

  private listenRenewalExhibitFetchLinkEvents(eventSource: any, sseProcessID: string) {
    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';
    this.cdRef.markForCheck();
    eventSource.addEventListener('BATCH_FETCH_EXHIBITS_UPDATEUI_TASK', (event: any) => {
      if (event && event.data) {
        var data = JSON.parse(event.data);
        var payload = data.payload;
        if (!this.receivedCurrentExhibitEvents.includes(data.processId + payload.groupNumber)) {
          this.receivedCurrentExhibitEvents.push(data.processId + payload.groupNumber);
          this.progressStyle = '';
          var percent = Math.floor((this.receivedCurrentExhibitEvents.length / payload.totalExhibits) * 100);
          this.progressPercent = percent;
          this.progressMessage = 'Processed ' + payload.groupNumber + '. [' + this.progressPercent + '% complete.]';
          this.cdRef.markForCheck();
        }
      }
    });
    eventSource.addEventListener('BATCH_FETCH_EXHIBITS_PROCESS_COMPLETION_TRIGGER', (event: any) => {
      eventSource.close();
      if (event && event.data) {
        var eventData = JSON.parse(event.data);
        var payload = eventData.payload;
        this.renewalBatchWrapper.renewalBatch['recentExhibitsFetchStatus'] = status;
        this.processExhibitFetchUpdates(payload.recentExhibitsFetchStatus, sseProcessID);
        this.receivedCurrentExhibitEvents = [];
        setTimeout(() => {
          this.showProgress = false;
          this.cdRef.markForCheck();
        }, this.commonService.getProgressBarTimeOut());
      }
    });
  }

  private processExhibitFetchUpdates(status: string, sseProcessID: string) {
    //Excluded 'Zipping Failed' status
    if (status && ['Success', 'Partial', 'Failed'].includes(status)) {
      this.currentExhibitLinkProcessId = sseProcessID;
      this.progressStyle = 'progress-bar-success';
      this.progressPercent = 100;
      this.progressMessage = 'Exhibits Link Fetch Process completed successfully.';
      this.showExhibitsZipDownloadLink = true;
      this.setAlertVisibility(true, AlertType.SUCCESS, 'Exhibits Link Fetch Process completed successfully.');
      this.cdRef.markForCheck();
    } else {
      console.error('Received Exhibit Status :' + status);
      this.progressPercent = 90;
      this.progressStyle = 'progress-bar-danger';
      this.progressMessage = 'Received Exhibit Status :' + status;
      this.showExhibitsZipDownloadLink = false;
      this.setAlertVisibility(true, AlertType.ERROR, status);
      this.hideProgressBar();
      this.cdRef.markForCheck();
    }
    this.hideAlertVisibility();
  }

  downloadPrintExhibitsZip(isOnloadFlow: boolean) {
    this.setAlertVisibility(false);
    if (!this.currentExhibitLinkProcessId || null == this.currentExhibitLinkProcessId) {
      this.showExhibitsZipDownloadLink = false;
      this.setAlertVisibility(true, AlertType.WARNING, 'Recent Exhibits Fetch Process Failed. Please retry, if desired.', false);
      this.hideAlertVisibility();
      return;
    }
    let fileName = this.renewalBatchWrapper.renewalBatch['id'] + '-' + this.currentExhibitLinkProcessId + '.zip';
    this.commonService.fileDownload(CreateBatchComponent.BATCH_EXHIBITS_BASE_PATH, fileName).subscribe(
      (response) => {
        if (isOnloadFlow) {
          this.showExhibitsZipDownloadLink = true;
          return;
        }
        if (response) {
          fileName = this.renewalBatchWrapper.renewalBatch['id'] + '-' + this.datepipe.transform(new Date(), "yyyy-MM-dd'T'hh_mm_ssa") + '.zip';
          this.peService.createAndDownloadBlobFile(response, fileName);
          this.setAlertVisibility(true, AlertType.SUCCESS, 'Exhibits Zip Downloaded Successfully.');
        } else {
          this.setAlertVisibility(true, AlertType.ERROR, 'Exhibits Zip Download Failed.');
        }
        this.hideAlertVisibility();
      },
      (errorResponse) => {
        if (errorResponse && errorResponse.error && errorResponse.error instanceof Blob) {
          const reader: FileReader = new FileReader();
          reader.readAsText(errorResponse.error);
          reader.onload = (e) => {
            var errMsg = JSON.parse(JSON.parse(JSON.stringify(e.target.result)));
            if (errMsg && errMsg.exceptions && errMsg.exceptions.exceptions[0] && errMsg.exceptions.exceptions[0].type == 'java.io.FileNotFoundException') {
              this.showExhibitsZipDownloadLink = false;
              this.setAlertVisibility(true, AlertType.WARNING, 'The bulk download exhibit link has expired. Please re-create, if desired.', false);
              this.hideAlertVisibility();
              return;
            }
            if (isOnloadFlow) {
              this.showExhibitsZipDownloadLink = true;
              return;
            }
          };
        } else if (isOnloadFlow) {
          this.showExhibitsZipDownloadLink = true;
          return;
        }
        if (!isOnloadFlow) {
          this.setAlertVisibility(true, AlertType.ERROR, 'Exhibits Zip Download Failed.');
          this.hideAlertVisibility();
        }
      }
    );
  }
  onUwNoteToSaleEvent(event, bulkdata, i) {
    this.isDirty = true;
    let index = this.bulkViewTableData.findIndex((x) => x == bulkdata);
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.bulkViewTableData[index].uwNotesToSales = ASCII;
    } else {
      this.bulkViewTableData[index].uwNotesToSales = '';
    }
  }

  onUwNoteToSelfEvent(event, bulkdata, i) {
    this.isDirty = true;
    let index = this.bulkViewTableData.findIndex((x) => x == bulkdata);
    if (event?.target?.value) {
      let ASCII = CommonUtil.convertSpecialCharToASCII(event.target.value);
      this.bulkViewTableData[index].uwComments = ASCII;
    } else {
      this.bulkViewTableData[index].uwComments = '';
    }
  }

  onStatesSelected = (isngOnInit?: boolean) => {
    if (isngOnInit) {
      this.isSearchChanged = false;
    } else {
      this.isSearchChanged = true;
    }
    const statesValue = this.batchSearchForm.get('states').value;
    if (statesValue && statesValue.length > 0) {
      this.selectstate = statesValue;
      if (this.associationList) {
        this.filteredAssociation = this.associationList?.filter((association) => {
          return this.selectstate.includes(association.state);
        });
      } else {
        this.filteredAssociation = [];
      }
      this.selectedAssociation = this.selectedAssociation?.filter((selected) =>
        this.filteredAssociation.some((association) => association.state === selected.state)
      );
    } else {
      // If no states selected, clear associations
      this.filteredAssociation = [];
      this.selectedAssociation = [];
    }
  }

  onLobSelected = () => {
    this.isSearchChanged = true;
    this.batchSearchForm.patchValue({
      marketSegments: []
    });
    const selectedLOB = this.batchSearchForm.controls.lob.value;
    this.onDataSourceSelected(selectedLOB);
    this.hideFundingType();
    if (StringUtils.isEqual(selectedLOB, CommonConstants.SuppHealth)) {
      this.batchSearchForm.controls.fundingTypes.setValue(CommonConstants.FI);
      if (this.batchSearchForm.value.marketSegments.includes(CommonConstants.LG) && this.batchSearchForm.value.marketSegments.includes(CommonConstants.SG)) {
        this.batchSearchForm.patchValue({
          marketSegments: [CommonConstants.LG]
        });
      } else if (this.batchSearchForm.value.marketSegments.includes(CommonConstants.SG)) {
        this.batchSearchForm.patchValue({
          marketSegments: []
        });
      }
      this.getDisableMkgSegment(true);
      this.getDisableLGMkgSegment(false);
      this.isFIselectedDropdown = CommonConstants.FI;
    } else if (StringUtils.isEqual(selectedLOB, CommonConstants.Vision) ||
      StringUtils.isEqual(selectedLOB, CommonConstants.Dental)) {
      this.batchSearchForm.controls.fundingTypes.setValue(CommonConstants.FI);
      this.getDisableMkgSegment(false);
      this.getDisableLGMkgSegment(false);
      this.isFIselectedDropdown = CommonConstants.FI;
    } else {
      if (!this.isFundingTypeSelectedFirst && !this.isFundingTypeChangeByUser) {
        this.batchSearchForm.controls.fundingTypes.setValue(CommonConstants.ABF);
        this.isFIselectedDropdown = CommonConstants.ABF;
      }
    }

    if (StringUtils.isEqual(selectedLOB, CommonConstants.Medical) && !this.isFundingTypeChangeByUser) {
      this.batchSearchForm.controls.fundingTypes.setValue(CommonConstants.ABF);
      this.isFIselectedDropdown = CommonConstants.ABF;
      this.getDisableMkgSegment(false);
    } else if (!this.isFundingTypeChangeByUser) {
      this.batchSearchForm.controls.fundingTypes.setValue(CommonConstants.FI);
      this.isFIselectedDropdown = CommonConstants.FI;
    }
    if (this.groupNumbersFile) {
      this.batchSearchForm.controls.fundingTypes.setValue('ALL');
    }
    if (StringUtils.isEqual(this.isFIselectedDropdown, CommonConstants.FI) || StringUtils.isEqual(this.isFIselectedDropdown, CommonConstants.ASO)) {
      if (StringUtils.isEqual(this.batchSearchForm.value.lob, CommonConstants.Medical) || StringUtils.isEqual(this.batchSearchForm.value.lob, CommonConstants.SuppHealth)) {
        this.getDisableMkgSegment(true);
      } else {
        this.getDisableMkgSegment(false);
      }
      this.getDisableLGMkgSegment(false);
    }

    this.showSendToOppBasedOnConfig();
  }

  onDataSourceSelected = (selectedLOB) => {
    this.isSearchChanged = true;
    if(StringUtils.isEqual(selectedLOB, CommonConstants.SuppHealth) || StringUtils.isEqual(selectedLOB, CommonConstants.Vision) || StringUtils.isEqual(selectedLOB, CommonConstants.Dental)){
    this.batchSearchForm.controls.dataSource.setValue(this.availableDatasourcesForBatchScreenSearchOverlay[0]);
   }
 }

  createWhSavingPopup(groupDate) {
    groupDate['isBulkFlow'] = true;
    this.uwAdjustment = this.uwAdjustmentFetchObject = groupDate;
  }
  whAdjustmentsUpdates(event) {
    this.whAdjustmentsDetails = event;
    let whSavingValue = 0;
    if (this.whAdjustmentsDetails?.whSavingsAdjustment.controls) {
      Object.keys(this.whAdjustmentsDetails?.whSavingsAdjustment.controls).forEach((speciality) => {
        whSavingValue = whSavingValue + Number(this.whAdjustmentsDetails.whSavingsAdjustment.get(speciality).value);
      });
    }
    if (whSavingValue != 0 && !StringUtils.isUndefined(whSavingValue)) {
      whSavingValue = 100 * whSavingValue;
      whSavingValue = this.uwAdjService.roundValueToFourDecimals(whSavingValue);
    }
    let whSavingFormDetailsArray = [];
    this.whAdjustmentsDetails.SpecialityTypes?.forEach((specialityType) => {
      if (StringUtils.isEqual(specialityType.label, CommonConstants.OTHER)) {
        whSavingFormDetailsArray.push({
          value: specialityType.defaultValue,
          id: this.whAdjustmentsDetails.otherUnitType
        });
      } else {
        whSavingFormDetailsArray.push({
          value: specialityType.defaultValue,
          id: specialityType.value
        });
      }
    });
    this.bulkViewTableData.forEach((bulkdata) => {
      if (bulkdata['groupNumber'] == this.whAdjustmentsDetails.uwAdjustment['groupNumber']) {
        if (!isNaN(whSavingValue)) {
          if (bulkdata.quotingType === 'MEWA') {
            if (whSavingValue == 0) {
              bulkdata.wholeHealthAdjustmentFactor = '';
            } else {
              bulkdata.wholeHealthAdjustmentFactor = whSavingValue;
            }
          } else if (bulkdata.quotingType !== 'MEWA' && whSavingValue != 0 ) {
            bulkdata.renewalWHAPercent = whSavingValue;
          }
          bulkdata['discountSplits'] = whSavingFormDetailsArray;
        }
      }
    });
    if (Object.keys(this.whAdjustmentsDetails?.uwAdjustment).length != 0) {
      if (this.whAdjustmentsDetails.uwAdjustment.quotingType !== 'MEWA') {
        this.onRateActionChange(CommonConstants.RENEWAL_WHA_PERCENT, this.whAdjustmentsDetails.uwAdjustment, whSavingValue);
      } else {
        this.onRateActionChange('wholeHealthAdjustmentFactor', this.whAdjustmentsDetails.uwAdjustment, whSavingValue == 0 ? '' : whSavingValue);
      }
    }
  }
  getToolTipValueForWholeHealth(col, bulkdata) {
    let whSavingsSpecialty = '';
    if (StringUtils.isEqual(col, CommonConstants.RENEWAL_WHA_PERCENT) || col === 'wholeHealthAdjustmentFactor') {
      if (StringUtils.isEqual(this.whAdjustmentsDetails?.uwAdjustment?.groupNumber, bulkdata.groupNumber)) {
        Object.keys(this.whAdjustmentsDetails?.whSavingsAdjustment.value).forEach((key) => {
          if (
            this.whAdjustmentsDetails?.whSavingsAdjustment.value[key] &&
            !StringUtils.isUndefined(this.whAdjustmentsDetails?.whSavingsAdjustment.value[key])
          ) {
            whSavingsSpecialty +=
              (StringUtils.isEqual(key, CommonConstants.OTHER) ? this.whAdjustmentsDetails.otherUnitType : key) +
              ' : ' +
              this.uwAdjService.roundValueToFourDecimals(this.whAdjustmentsDetails.whSavingsAdjustment.value[key] * 100) +
              '%' +
              '\n';
          }
        });
      } else if (bulkdata.discountSplits && bulkdata.discountSplits.length > 0) {
        bulkdata.discountSplits.forEach((discountSplit) => {
          if (!StringUtils.isUndefined(discountSplit.value))
            whSavingsSpecialty += discountSplit.id + ' : ' + this.uwAdjService.roundValueToFourDecimals(discountSplit.value * 100) + '%' + '\n';
        });
      }
      return whSavingsSpecialty;
    }
  }

  checkFirstCharNotToBeSpecialChar(event) {
    ValidationUtils.doNotAllowFirstCharacterToBeSpecialCharacter(event);
  }

  omit_special_char(event) {
    let key;
    key = event.charCode;
    return (key > 64 && key < 91) || (key > 96 && key < 123) || key == 8 || key == 32 || (key >= 48 && key <= 57);
  }

  pasteEmitter = (event) => {
    this.grpNameAndNumberValidation();
    this.batchSearchForm.patchValue({
      groupNumber: event.target?.value
    });
    event.preventDefault();
  }

  setIsCommissionOverridden(groupDetail: any) {
    groupDetail.commissionValue = groupDetail.commissionValue || '0';
    const renewalBatchDetail = this.findRenewalBatchDetail(groupDetail.groupNumber);
    if (renewalBatchDetail) {
      renewalBatchDetail.isCommissionOverridden = CommonConstants.YES;
      const componentAdjustmentsForCommissionType = this.createComponentAdjustments(
        CommonConstants.COMPONENT_ADJUSTMENT_COMMISSION_TYPE_OVERRIDDEN,
        groupDetail.commissionType
      );
      const componentAdjustmentsForCommissionValue = this.createComponentAdjustments(
        CommonConstants.COMPONENT_ADJUSTMENT_COMMISSION_VALUE_OVERRIDDEN,
        groupDetail.commissionValue
      );

      if (this.listOfGroupsWithOverrides.includes(groupDetail.groupNumber)) {
        this.handleCurrentAdjustmentForCommissionsOverride(renewalBatchDetail, componentAdjustmentsForCommissionType, componentAdjustmentsForCommissionValue);
      } else {
        this.handleNewAdjustmentForCommissionsOverride(renewalBatchDetail, componentAdjustmentsForCommissionType, componentAdjustmentsForCommissionValue);
      }
    }
  }

  handleCurrentAdjustmentForCommissionsOverride(
    renewalBatchDetail: RenewalBatchDetails,
    componentAdjustmentsForCommissionType: any,
    componentAdjustmentsForCommissionValue: any
  ): void {
    let lastAddedAdjustment = this.getLastAddedAdjustment(renewalBatchDetail);
    this.ensureUniqueUWActions(lastAddedAdjustment, CommonConstants.UW_ACTION_COMMISSION_OVERRIDDEN);
    this.updateComponentAdjustmentsForCommissionsOverride(lastAddedAdjustment, componentAdjustmentsForCommissionType, componentAdjustmentsForCommissionValue);
  }

  updateComponentAdjustmentsForCommissionsOverride(
    lastAddedAdjustment: any,
    componentAdjustmentsForCommissionType: any,
    componentAdjustmentsForCommissionValue: any
  ): void {
    this.updateAdjustment(lastAddedAdjustment, componentAdjustmentsForCommissionType);
    this.updateAdjustment(lastAddedAdjustment, componentAdjustmentsForCommissionValue);
  }

  updateAdjustment(lastAddedAdjustment: any, componentAdjustment: any): void {
    const existingIndex = this.getIndexForExistingAdjustmentOfMappedField(lastAddedAdjustment, componentAdjustment[CommonConstants.ADJUSTMENT_TYPE]);
    if (existingIndex !== -1) {
      lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS][existingIndex] = componentAdjustment;
    } else {
      lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS].push(componentAdjustment);
    }
  }

  private handleNewAdjustmentForCommissionsOverride(
    renewalBatchDetail: RenewalBatchDetails,
    componentAdjustmentsForCommissionType: any,
    componentAdjustmentsForCommissionValue: any
  ): void {
    this.listOfGroupsWithOverrides.push(renewalBatchDetail.groupNumber);
    const newAdjustmentsTrail = this.createNewAdjustmentsTrailForCommissionsOverride(
      renewalBatchDetail,
      componentAdjustmentsForCommissionType,
      componentAdjustmentsForCommissionValue
    );
    if (!renewalBatchDetail.adjustmentsTrail) {
      renewalBatchDetail.adjustmentsTrail = [];
    }
    renewalBatchDetail.adjustmentsTrail.push(newAdjustmentsTrail);
  }

  createNewAdjustmentsTrailForCommissionsOverride(
    renewalBatchDetail: RenewalBatchDetails,
    componentAdjustmentsForCommissionType: any,
    componentAdjustmentsForCommissionValue: any
  ): any {
    const newAdjustmentsTrail: any = {};
    const lowerCaseMedical = CommonConstants.Medical.toLowerCase();
    if (StringUtils.isEqualIgnoreCase(renewalBatchDetail.lob, lowerCaseMedical)) {
      newAdjustmentsTrail[lowerCaseMedical] = true;
    }
    this.ensureUniqueUWActions(newAdjustmentsTrail, CommonConstants.UW_ACTION_COMMISSION_OVERRIDDEN);
    newAdjustmentsTrail[CommonConstants.COMPONENT_ADJUSTMENTS] = [componentAdjustmentsForCommissionType, componentAdjustmentsForCommissionValue];
    return newAdjustmentsTrail;
  }

  setOverridden(groupNumber: string, field: string, newValue: any) {
    const renewalBatchDetail = this.findRenewalBatchDetail(groupNumber);
    if (renewalBatchDetail) {
      const mappedField = this.editableFieldsMapping[field];
      if (mappedField) {
        const componentAdjustments = this.createComponentAdjustments(mappedField, newValue);
        if (this.listOfGroupsWithOverrides.includes(groupNumber)) {
          this.handleCurrentAdjustment(renewalBatchDetail, mappedField, componentAdjustments);
        } else {
          this.handleNewAdjustment(renewalBatchDetail, mappedField, componentAdjustments);
        }
      }
    }
  }

  findRenewalBatchDetail(groupNumber: string): RenewalBatchDetails | undefined {
    return this.renewalBatchWrapper.renewalBatchDetails?.find((renewalBatchDetail: RenewalBatchDetails) =>
      StringUtils.isEqual(renewalBatchDetail.groupNumber, groupNumber)
    );
  }

  createComponentAdjustments(mappedField: string, newValue: any): any {
    return {
      [CommonConstants.ADJUSTMENT_TYPE]: mappedField,
      [CommonConstants.ADJUSTMENT_VALUE]: newValue
    };
  }

  handleCurrentAdjustment(renewalBatchDetail: RenewalBatchDetails, mappedField: string, componentAdjustments: any): void {
    let lastAddedAdjustment = this.getLastAddedAdjustment(renewalBatchDetail);
    const existingIndex = this.getIndexForExistingAdjustmentOfMappedField(lastAddedAdjustment, mappedField);

    if (existingIndex !== -1) {
      //replace the last adjustment with updated componentAdjustments
      lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS][existingIndex] = componentAdjustments;
    } else {
      if (lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS]) {
        lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS].push(componentAdjustments);
      } else {
        lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS] = [componentAdjustments];
      }
    }
    this.ensureUniqueUWActions(lastAddedAdjustment, mappedField);
    if (renewalBatchDetail.adjustmentsTrail && renewalBatchDetail.adjustmentsTrail.length > 0) {
      renewalBatchDetail.adjustmentsTrail[renewalBatchDetail.adjustmentsTrail.length - 1] = lastAddedAdjustment;
    } else {
      renewalBatchDetail.adjustmentsTrail = [lastAddedAdjustment];
    }
  }

  getLastAddedAdjustment(renewalBatchDetail: RenewalBatchDetails): any {
    if (renewalBatchDetail.adjustmentsTrail && renewalBatchDetail.adjustmentsTrail.length > 0) {
      return renewalBatchDetail.adjustmentsTrail[renewalBatchDetail.adjustmentsTrail.length - 1];
    } else {
      return {};
    }
  }

  getIndexForExistingAdjustmentOfMappedField(lastAddedAdjustment: any, mappedField: string): number {
    if (lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS]) {
      return lastAddedAdjustment[CommonConstants.COMPONENT_ADJUSTMENTS].findIndex(
        (adjustment: any) => adjustment[CommonConstants.ADJUSTMENT_TYPE] === mappedField
      );
    } else {
      return -1;
    }
  }

  ensureUniqueUWActions(lastAddedAdjustment: any, mappedField: string): void {
    if (lastAddedAdjustment[CommonConstants.UW_ACTIONS]) {
      if (!lastAddedAdjustment[CommonConstants.UW_ACTIONS].includes(mappedField)) {
        lastAddedAdjustment[CommonConstants.UW_ACTIONS].push(mappedField);
      }
    } else {
      lastAddedAdjustment[CommonConstants.UW_ACTIONS] = [mappedField];
    }
  }

  handleNewAdjustment(renewalBatchDetail: RenewalBatchDetails, mappedField: string, componentAdjustments: any): void {
    this.listOfGroupsWithOverrides.push(renewalBatchDetail.groupNumber);
    const newAdjustmentsTrail = this.createNewAdjustmentsTrail(renewalBatchDetail, mappedField, componentAdjustments);
    if (!renewalBatchDetail.adjustmentsTrail) {
      renewalBatchDetail.adjustmentsTrail = [];
    }
    renewalBatchDetail.adjustmentsTrail.push(newAdjustmentsTrail);
  }

  createNewAdjustmentsTrail(renewalBatchDetail: RenewalBatchDetails, mappedField: string, componentAdjustments: any): any {
    const newAdjustmentsTrail: any = {};
    const lowerCaseMedical = CommonConstants.Medical.toLowerCase();
    if (StringUtils.isEqualIgnoreCase(renewalBatchDetail.lob, lowerCaseMedical)) {
      newAdjustmentsTrail[lowerCaseMedical] = true;
    }
    newAdjustmentsTrail[CommonConstants.UW_ACTIONS] = [mappedField];
    newAdjustmentsTrail[CommonConstants.COMPONENT_ADJUSTMENTS] = [componentAdjustments];
    return newAdjustmentsTrail;
  }

  protected readonly RenewalsUtil = RenewalsUtil;
  protected readonly NonChangeableRenewalStatuses = NonChangeableRenewalStatuses;
  protected readonly CalculatorUtils = CalculatorUtils;

  isValidCommissionValue(event) {
    return CommonUtil.isNumberWithGivenDecimalPlaces(event, 2);
  }

  /**
   * Validates a number with given expected decimals as a param
   * @param event
   * @param decimals
   */
  isValidNumberValueWithDecimals(event, decimals) {
    return CommonUtil.isNumberWithGivenDecimalPlaces(event, decimals);
  }

  isBatchInfoSmallTableHeader = (header: string) => {
    return this.BATCH_INFO_SMALL_TH.includes(header);
  }
  isRenewalRestoreEnabled() {
    return this.commonService.hasRenewalRestoreRole();
  }

  getToolTipMessgeForPriorNumber(groupDetail) {
    let message;
    if (groupDetail.priorGroupNumbers.length === 0 || StringUtils.isEmpty(groupDetail.priorGroupNumbers[0].trim())) {
      message = CommonConstants.EMPTY_STRING;
    } else if (StringUtils.isEmpty(groupDetail.invalidGroupNumbersForMerge)) {
      message = `Merged Groups: ${groupDetail.priorGroupNumbers}`;
    } else {
      const result = this.filterInvalidGroupNumbers(groupDetail.priorGroupNumbers, groupDetail.invalidGroupNumbersForMerge);
      if (result.remainingNumbers.length === 0 && result.invalidNumbers.length > 0) {
        message = `Group Merge Unsuccessful - Invalid group number(s) found: ${result.invalidNumbers}`;
      } else if (result.remainingNumbers.length > 0 && result.invalidNumbers.length === 0) {
        message = `Merged Groups: ${result.remainingNumbers}`;
      } else if (result.remainingNumbers.length > 0 && result.invalidNumbers.length > 0) {
        message = `Merged Groups: ${result.remainingNumbers}\nGroup Merge Unsuccessful - Invalid group number(s) found: ${result.invalidNumbers}`;
      }
    }
    return message;
  }

  filterInvalidGroupNumbers(priorGroupNumbers, invalidGroupNumbersForMerge) {
    const invalidNumbers = Array.isArray(priorGroupNumbers) ? priorGroupNumbers.filter((number) => invalidGroupNumbersForMerge.includes(number)) : [];

    const remainingNumbers = Array.isArray(priorGroupNumbers) ? priorGroupNumbers?.filter((number) => !invalidGroupNumbersForMerge.includes(number)) : [];

    return { invalidNumbers, remainingNumbers };
  }

  handleRepeatingGroupsException(response: any) {
    this.showTab = true;
    this.setLoaderVisibility(false);
    this.setAlertVisibility(true, AlertType.WARNING, response.description);
    this.hideAlertVisibility();
    this.repeatingGroupsToHighlight = Object.keys(response.repeatingGroupsAndBatchNames) || [];
    this.repeatingGroupsSet = new Set(this.repeatingGroupsToHighlight);
  }

  isGroupHighlighted(groupDetail: any): boolean {
    const isRepeating = this.repeatingGroupsSet.has(groupDetail.groupNumber);
    const groupNumberWithoutTest = groupDetail.groupNumber?.toString().replace(/T3ST/gi, '');
    const hasMatchInRepeatingSet = groupNumberWithoutTest ? this.repeatingGroupsSet.has(groupNumberWithoutTest) : false;
    return isRepeating || hasMatchInRepeatingSet;
  }

  downloadBatchDetails() {
    if (!this.showMewaDownloadMenu) {
      this.downloadBatch();
      return;
    }

    const wantsBatchInfo         = this.selectedMewaDownloadType.includes('Batch Info');
    const wantsOveragedDependent = this.selectedMewaDownloadType.includes('Overaged Dependent');

    if (wantsBatchInfo && wantsOveragedDependent) {
      this.downloadBothBatchFiles();
    } else if (wantsBatchInfo) {
      this.downloadBatch();
    } else if (wantsOveragedDependent) {
      this.downloadOveragedDependent();
    }
  }

  private buildOveragedDependentPayload(): any {
    return {
      batchID: this.renewalBatchWrapper.renewalBatch['id'] ?? '',
      batchName: this.renewalBatchWrapper.renewalBatch['batchName'] ?? '',
      groupDetails: this.renewalBatchWrapper.renewalBatchDetails
        .filter((grp: any) => grp.source !== 'RARE')
        .map(group => ({
          // quoteReason is true when it is a TEST batch
          groupNumber: this.quoteReason ? (group.originalGroupNumber || group.groupNumber) : group.groupNumber,
          groupName: group.groupName,
          renewalDate: group.renewalDate,
          state: group.state,
          lob: group.lob,
          fundingType: group.fundingType,
          marketSegment: group.marketSegment
        }))
    };
  }

  downloadOveragedDependent() {
    const data = this.buildOveragedDependentPayload();

    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';
    this.cdRef.markForCheck();

    this.renewalsService.downloadOveragedDepedents(data).subscribe(
      (resp) => {
        if (!resp?.processId) {
          this.progressPercent = 90;
          this.progressStyle = 'progress-bar-danger';
          this.progressMessage = 'Error in getting response for download';
          this.cdRef.markForCheck();
          this.hideProgressBar();
          return;
        }
        var source = this.commonService.listenForStream(resp.processId);
        this.eventSources.push(source);
        source.addEventListener('FILE_GENERATION_STATUS', (event: any) => {
          this.progressStyle = '';
          let eventData = JSON.parse(event.data);
          let percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
          this.progressPercent = percent;
          this.progressMessage = eventData.message;
          this.cdRef.markForCheck();
        });
        source.addEventListener('FILE_GENERATION_PROCESS_COMPLETED', (message: any) => {
          this.handleFileDownload(source, message);
          source.close();
        });
        source.addEventListener('FAILED', (data: any) => {
          source.close();
          console.error('Received event : ', JSON.stringify(data.message));
          this.progressPercent = 90;
          this.progressStyle = 'progress-bar-danger';
          this.progressMessage = 'Error in getting response for download';
          this.cdRef.markForCheck();
          this.hideProgressBar();
        });
        source.addEventListener('error', (message: any) => {
          source.close();
          console.error('Received error event, with ready status :' + source.readyState);
          if (source.readyState == EventSource.CLOSED) {
            this.progressPercent = 90;
            this.progressStyle = 'progress-bar-danger';
            this.progressMessage = 'Failed to fetch progress because of communication failure';
            this.cdRef.markForCheck();
            this.hideProgressBar();
          }
        });
      },
      (error) => {
        this.progressPercent = 90;
        this.progressStyle = 'progress-bar-danger';
        this.progressMessage = 'Error in getting response for download';
        this.cdRef.markForCheck();
        this.hideProgressBar();
      }
    );
    
  }

  private downloadBothBatchFiles() {
    let batchPercent   = 0;
    let overagedPercent = 0;
    let batchFailed    = false;
    let overagedFailed = false;
    let batchStreamCompleted   = false;
    let overagedStreamCompleted = false;
    let batchMsg   = 'In progress...';
    let overagedMsg = 'In progress...';

    // avg of both percents; success style only when both done without error
    const setProgress = () => {
      this.progressPercent = Math.floor((batchPercent + overagedPercent) / 2);
      this.progressMessage = `Batch Info: ${batchMsg} | Overaged Dependent: ${overagedMsg}`;
      const bothDone = batchStreamCompleted && overagedStreamCompleted;
      if (bothDone && !batchFailed && !overagedFailed) {
        this.progressStyle = 'progress-bar-success';
      } else if (batchFailed || overagedFailed) {
        this.progressStyle = 'progress-bar-danger';
      }
    };

    let completedCount = 0;
    const onStreamComplete = () => {
      completedCount++;
      if (completedCount === 2) {
        this.hideProgressBar();
      }
    };

    // safety timeout — forces resolution if a terminal SSE event is never received
    const safetyTimeout = 60000;

    setTimeout(() => {
      if (!batchStreamCompleted) {
        batchStreamCompleted = true;
        batchFailed = true;
        batchPercent = 100;
        batchMsg = 'Failed to fetch progress';
        setProgress();
        this.cdRef.markForCheck();
        onStreamComplete();
      }
    }, safetyTimeout);

    setTimeout(() => {
      if (!overagedStreamCompleted) {
        overagedStreamCompleted = true;
        overagedFailed = true;
        overagedPercent = 100;
        overagedMsg = 'Failed to fetch progress';
        setProgress();
        this.cdRef.markForCheck();
        onStreamComplete();
      }
    }, safetyTimeout);

    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';
    this.progressMessage = `Batch Info: ${batchMsg} | Overaged Dependent: ${overagedMsg}`;
    this.cdRef.markForCheck();

    let batchData: any = {};
    if (!this.enabledBatchGroupDownload) {
      if (this.isSearchChanged) {
        this.searchClicked();
      } else {
        this.isFIRewewalSearch =
          StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.FI) &&
          (StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Medical) ||
           StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.SuppHealth));
        this.batchSearch = this.getBatchSearchRequest(this.isFIRewewalSearch);
        if (this.batchSearch.marketSegments.length < 1) {
          this.batchSearch.marketSegments = ['LG', 'SG'];
        }
      }
      if (this.batchSearch.marketSegments.length === 0) {
        this.batchSearch.marketSegments = this.batchSearchForm.value.marketSegments;
      }
    } else {
      batchData['batchID'] = this.renewalBatchWrapper.renewalBatch['id']
        ? this.renewalBatchWrapper.renewalBatch['id'] : '';
    }
    this.setLoaderVisibility(true);

    this.renewalsService.downloadRenewalBatchDetails(
      this.enabledBatchGroupDownload ? batchData : this.batchSearch
    ).subscribe(
      (res) => {
        this.setLoaderVisibility(false);
        if (!res?.processId) {
          batchStreamCompleted = true;
          batchFailed = true;
          batchPercent = 100;
          batchMsg = 'Error in getting response for download';
          setProgress();
          this.cdRef.markForCheck();
          onStreamComplete();
          return;
        }
        const batchSource = this.commonService.listenForStream(res.processId);
        this.eventSources.push(batchSource);

        batchSource.addEventListener('PE_GENERATION_STATUS', (event: any) => {
          const eventData = JSON.parse(event.data);
          batchPercent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
          batchMsg = eventData.message;
          setProgress();
          this.cdRef.markForCheck();
        });

        const onBatchDone = (message: any) => {
          if (batchStreamCompleted) { return; }
          batchStreamCompleted = true;
          batchSource.close();
          const eventData = JSON.parse(message.data);
          batchPercent = 100;
          batchMsg = eventData.message;
          setProgress();
          this.cdRef.markForCheck();
          const filename = eventData.metaData?.fileName ?? 'sheet';
          const arrayBuffer = this.peService.base64ToArrayBuffer(eventData.payload.contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, filename);
          onStreamComplete();
        };
        batchSource.addEventListener('SEND_EXHIBIT_TO_UI', onBatchDone);
        batchSource.addEventListener('PE_GENERATION_STATUS_COMPLETE', onBatchDone);

        batchSource.addEventListener('FAILED', (msg: any) => {
          if (batchStreamCompleted) { return; }
          batchStreamCompleted = true;
          batchFailed = true;
          batchPercent = 100;
          batchSource.close();
          console.error('Received event : ', JSON.stringify(msg.data));
          batchMsg = 'Error in getting response for download';
          setProgress();
          this.cdRef.markForCheck();
          onStreamComplete();
        });
        batchSource.addEventListener('error', (msg: any) => {
          if (batchStreamCompleted) { return; }
          batchSource.close();
          console.error('Received error event, with ready status :' + batchSource.readyState);
          if (batchSource.readyState == EventSource.CLOSED) {
            batchStreamCompleted = true;
            batchFailed = true;
            batchPercent = 100;
            batchMsg = 'Failed to fetch progress';
            setProgress();
            this.cdRef.markForCheck();
            onStreamComplete();
          }
        });
      },
      () => {
        batchStreamCompleted = true;
        batchFailed = true;
        batchPercent = 100;
        this.setLoaderVisibility(false);
        batchMsg = 'Error in getting response for download';
        setProgress();
        this.cdRef.markForCheck();
        onStreamComplete();
      }
    );

    const overagedData = this.buildOveragedDependentPayload();

    this.renewalsService.downloadOveragedDepedents(overagedData).subscribe(
      (resp) => {
        if (!resp?.processId) {
          overagedStreamCompleted = true;
          overagedFailed = true;
          overagedPercent = 100;
          overagedMsg = 'Error in getting response for download';
          setProgress();
          this.cdRef.markForCheck();
          onStreamComplete();
          return;
        }
        const overagedSource = this.commonService.listenForStream(resp.processId);
        this.eventSources.push(overagedSource);

        overagedSource.addEventListener('FILE_GENERATION_STATUS', (event: any) => {
          const eventData = JSON.parse(event.data);
          overagedPercent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
          overagedMsg = eventData.message;
          setProgress();
          this.cdRef.markForCheck();
        });

        overagedSource.addEventListener('FILE_GENERATION_PROCESS_COMPLETED', (message: any) => {
          if (overagedStreamCompleted) { return; }
          overagedStreamCompleted = true;
          overagedPercent = 100;
          overagedSource.close();
          const eventData = JSON.parse(message.data);
          overagedMsg = eventData.message;
          setProgress();
          this.cdRef.markForCheck();
          const filename = eventData.metaData?.fileName ?? 'sheet';
          const arrayBuffer = this.peService.base64ToArrayBuffer(eventData.payload.contentData);
          this.peService.createAndDownloadBlobFile(arrayBuffer, filename);
          onStreamComplete();
        });

        overagedSource.addEventListener('FAILED', (data: any) => {
          if (overagedStreamCompleted) { return; }
          overagedStreamCompleted = true;
          overagedFailed = true;
          overagedPercent = 100;
          overagedSource.close();
          console.error('Received event : ', JSON.stringify(data.message));
          overagedMsg = 'Error in getting response for download';
          setProgress();
          this.cdRef.markForCheck();
          onStreamComplete();
        });
        overagedSource.addEventListener('error', (msg: any) => {
          if (overagedStreamCompleted) { return; }
          overagedSource.close();
          console.error('Received error event, with ready status :' + overagedSource.readyState);
          if (overagedSource.readyState == EventSource.CLOSED) {
            overagedStreamCompleted = true;
            overagedFailed = true;
            overagedPercent = 100;
            overagedMsg = 'Failed to fetch progress';
            setProgress();
            this.cdRef.markForCheck();
            onStreamComplete();
          }
        });
      },
      () => {
        overagedStreamCompleted = true;
        overagedFailed = true;
        overagedPercent = 100;
        overagedMsg = 'Error in getting response for download';
        setProgress();
        this.cdRef.markForCheck();
        onStreamComplete();
      }
    );
  }

  downloadBatch() {
    let data = {};
    if(!this.enabledBatchGroupDownload) {
      if (this.isSearchChanged) {
        this.searchClicked();
      } else {
        this.isFIRewewalSearch =
          StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.fundingTypes, CommonConstants.FI) &&
          (StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.Medical) ||
          StringUtils.isEqualIgnoreCase(this.batchSearchForm.value.lob, CommonConstants.SuppHealth));
        this._visibleColumnsDirty = true;
        this.batchSearch = this.getBatchSearchRequest(this.isFIRewewalSearch);
        if (this.batchSearch.marketSegments.length < 1) {
          this.batchSearch.marketSegments = ['LG', 'SG'];
        }
      }

      if (this.batchSearch.marketSegments.length === 0) {
        this.batchSearch.marketSegments = this.batchSearchForm.value.marketSegments;
      }
    } else {
      data['batchID'] = this.renewalBatchWrapper.renewalBatch['id'] ? this.renewalBatchWrapper.renewalBatch['id'] : '';
    }
    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';
    this.cdRef.markForCheck();
    this.setLoaderVisibility(true);

    this.renewalsService.downloadRenewalBatchDetails(this.enabledBatchGroupDownload ? data : this.batchSearch).subscribe((res) => {
        this.setLoaderVisibility(false);
        if (res && res?.processId) {
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = 'progress-bar-warning';
          this.cdRef.markForCheck();
          var source = this.commonService.listenForStream(res?.processId);
          source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
            this.progressStyle = '';
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
            this.cdRef.markForCheck();
          });
          source.addEventListener('SEND_EXHIBIT_TO_UI', (message: any) => {
            this.handleFileDownload(source, message);
          });
          source.addEventListener('PE_GENERATION_STATUS_COMPLETE', (message: any) => {
            this.handleFileDownload(source, message);
          });
          source.addEventListener('FAILED', (message: any) => {
            source.close();
            console.error('Received event : ', JSON.stringify(message.data));
            this.progressPercent = 90;
            this.progressStyle = 'progress-bar-danger';
            this.progressMessage = 'Error in getting response for download';
            this.cdRef.markForCheck();
            this.hideProgressBar();
          });
          source.addEventListener('error', (message: any) => {
            source.close();
            console.error('Received error event, with ready status :' + source.readyState);
            if (source.readyState == EventSource.CLOSED) {
              this.progressPercent = 90;
              this.progressStyle = 'progress-bar-danger';
              this.progressMessage = 'Failed to fetch progress because of communication failure';
              this.cdRef.markForCheck();
              this.hideProgressBar();
            }
          });
        }
      },
      (error) => {
        this.setLoaderVisibility(false);
        this.progressPercent = 90;
        this.progressStyle = 'progress-bar-danger';
        this.progressMessage = 'Error in getting response for download';
        this.cdRef.markForCheck();
        this.hideProgressBar();
      }
    );
  }

  handleFileDownload(source, message) {
    source.close();
    let eventData = JSON.parse(message.data);
    this.progressStyle = 'progress-bar-success';
    this.progressPercent = 100;
    this.progressMessage = eventData.message;
    this.cdRef.markForCheck();
    if (this.progressMessage.includes(CommonConstants.EMPTY_RECORD)) {
      this.progressPercent = 90;
      this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
      this.progressMessage = CommonConstants.NO_RESULTS_FOUND;
      this.cdRef.markForCheck();
      setTimeout(() => {
        this.showProgress = false;
        this.cdRef.markForCheck();
      }, this.commonService.getProgressBarTimeOut());
    } else {
      CommonService.exportFilename = eventData.metaData.fileName ? eventData.metaData.fileName : 'sheet';
      let fileName = this.commonService.getExportFilename();
      let contentData = eventData.payload.contentData;
      const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
      this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
      setTimeout(() => {
        this.showProgress = false;
        this.cdRef.markForCheck();
      }, this.commonService.getProgressBarTimeOut());
    }
  }

  checkQuoteLinkStatus(groupDetail) {
    return (
      !groupDetail.opportunityID ||
      !groupDetail.quoteHeaderID ||
      groupDetail?.submissionStatus != this.groupSubmissionStatus.SUCCESS ||
      !groupDetail?.quoteRenewalStatus ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_RISK_SCORE ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.AWAITING_P2A_DATA ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.RECEIVED ||
      groupDetail?.quoteRenewalStatus === this.quoteRenewalStatus.PROCESSING
    );
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
      this.cdRef.markForCheck();
    }, this.commonService.getProgressBarTimeOut());
  }

  checkAutoRunGroup(bulkData) {
    return (
      (bulkData['quoteOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH && bulkData['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH) ||
      (bulkData['quoteOrigin'] !== QUOTE_ORIGIN.CONVERTED_AUTO_RUN &&
        bulkData['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH &&
        bulkData['quoteOrigin'] !== 'userBatch' &&
        bulkData['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH)
    );
  }

  checkAutorunConvertStatus(AutorunData) {
    return AutorunData['quoteOrigin'] === QUOTE_ORIGIN.CONVERTED_AUTO_RUN;
  }

  disableQuoteStatus(bulkdata) {
    return (
      !bulkdata['status'] ||
      bulkdata['status'] === this.quoteRenewalStatus.AWAITING_RISK_SCORE ||
      bulkdata['status'] === this.quoteRenewalStatus.AWAITING_P2A_DATA ||
      bulkdata['status'] === this.quoteRenewalStatus.RECEIVED ||
      bulkdata['status'] === this.quoteRenewalStatus.FAILED_TO_GATEWAY ||
      bulkdata['status'] === this.quoteRenewalStatus.SENT_TO_RARE ||
      bulkdata?.isCrossSelled
    );
  }

  disableAutoruntabForFailedQuoteStatus() {
    return (
      this.autoRunBatchTableData.filter(
        (autoRunData) =>
          !autoRunData['status'] ||
          autoRunData['status'] === this.quoteRenewalStatus.AWAITING_RISK_SCORE ||
          autoRunData['status'] === this.quoteRenewalStatus.AWAITING_P2A_DATA ||
          autoRunData['status'] === this.quoteRenewalStatus.RECEIVED ||
          autoRunData['status'] === this.quoteRenewalStatus.FAILED_TO_GATEWAY ||
          autoRunData['status'] === this.quoteRenewalStatus.SENT_TO_RARE
      ).length === this.autoRunBatchTableData.length
    );
  }

  isAutoRunBatchEnabled() {
    return this.commonService.isAutoRunBatchEnabled;
  }

  getConvertImg() {
    if (this.checkEmptyAutoRunTableData() || this.isUserReadOnly) {
      return './assets/Convert_range_gray.svg';
    } else {
      return './assets/Convert_range_green.svg';
    }
  }

  private constructAutoRunConvertRequest(data: {}) {
    this.isFailedGroups = false;
    this.isAlreadyConverted = false;
    this.isFailedAndAlreadyConverted = false;
    data['rareQuoteKeys'] = [];
    let slectedQuote = this.autoRunBatchTableData.filter((autoRunData) => autoRunData['included']).length;
    let failedQuote = this.autoRunBatchTableData.filter((autoRunData) => autoRunData['included'] && (!autoRunData['status'] || StringUtils.isEqual(autoRunData['status'], CommonConstants.Failed))).length;
    let convertedAutoLength = this.autoRunBatchTableData.filter(
      (autoRunData) => autoRunData['included'] && (autoRunData['latestAutoRunConverted'] || autoRunData?.isAutoRunConvertTaskDone)
    ).length;
    if (slectedQuote === failedQuote) {
      this.isFailedGroups = true;
      return;
    } else if (slectedQuote === convertedAutoLength) {
      this.isAlreadyConverted = true;
      this.setLoaderVisibility(false);
      this.setAlertVisibility(true, AlertType.ERROR, 'All selected groups are already converted.');
      this.hideAlertVisibility();
      return;
    } else if (slectedQuote === convertedAutoLength + failedQuote) {
      this.isFailedAndAlreadyConverted = true;
      return;
    }  else {
      this.isAlreadyConverted = false;
    }
    this.autoRunBatchTableData.forEach((autoRunData) => {
      let requestData = {};
      if (autoRunData['included'] && !autoRunData['latestAutoRunConverted']) {
        requestData = {
          opportunityID: autoRunData['opportunityID'] ? autoRunData['opportunityID'] : '',
          quoteHeaderID: autoRunData['quoteHeaderID'] ? autoRunData['quoteHeaderID'] : '',
          fundingType: autoRunData['fundingType'] ? autoRunData['fundingType'] : '',
          lob: autoRunData['lob'] ? autoRunData['lob'] : '',
          ratingTransID: autoRunData['ratingTransID'] ? autoRunData['ratingTransID'] : '',
          quoteOrigin: autoRunData['batchOrigin'] ? autoRunData['batchOrigin'] : ''
        };
        data['rareQuoteKeys'].push(requestData);
      }
    });
  }

  onConvertClick() {
    if(this.autoRunBatchTableData.filter((autoRunData) => autoRunData['included']).length === 0) {
      return;
    }
    this.isConvert = true;
    this.autoRunBatchTableData.forEach((autoRunDetail) => {
      if (autoRunDetail['included']) {
        autoRunDetail.convert = true;
      } else {
        autoRunDetail.convert = false;
      }
    });
    let data = {};
    this.constructAutoRunConvertRequest(data);
    let isError = this.getErrorMsgForAutoRunConvert();
    if(isError) {
      return;
    }
    data['batchID'] = this.renewalBatchWrapper.renewalBatch['id'] ? this.renewalBatchWrapper.renewalBatch['id'] : '';
    this.setAlertVisibility(false);
    this.setLoaderVisibility(true);
    this.renewalsService.bulkAutoRunConvertAction(data, data['batchID']).subscribe(
      (response) => {
        this.setLoaderVisibility(false);
        if (response && response.body && response.body['description'] && !response.body['description'].startsWith('No Data found')) {
          this.setLoaderVisibility(true);
          this.renewalBatchWrapper.renewalBatch['autoRunConvertProcessDetails'] = 'In Progress';
          var eventSource = this.commonService.listenForStream(response.body['description']);
          this.listenToAutoRunConvertEvents(eventSource);
          setTimeout(() => {
            this.setLoaderVisibility(false);
            this.isConvert = false;
            this.setAlertVisibility(true, AlertType.SUCCESS, 'Submitted for convert Successfully');
            this.hideAlertVisibility();
            this.verifyAllAutoRunDataDetails();
            this.autoRunBatchTableData.forEach((renewal) => {
              (renewal['included'] as boolean) = false;
            });
          }, 10000);
        }
      },
      (error) => {
        this.setLoaderVisibility(false);
        this.setAlertVisibility(true, AlertType.WARNING, 'Bulk Convert Failed !');
        this.hideAlertVisibility();
      }
    );
  }

  getErrorMsgForAutoRunConvert() {
    if(this.isFailedGroups && this.autoRunBatchTableData.filter((autoRunData) => autoRunData['included']).length > 0) {
      this.setLoaderVisibility(false);
      this.setAlertVisibility(true, AlertType.ERROR, 'The selected groups are failed and cannot be convert.');
      this.hideAlertVisibility();
      return true;
    } else if(this.isFailedAndAlreadyConverted && this.autoRunBatchTableData.filter((autoRunData) => autoRunData['included']).length > 0) {
      this.setLoaderVisibility(false);
      this.setAlertVisibility(true, AlertType.ERROR, 'The Selected groups are already converted or failed and cannot be convert.');
      this.hideAlertVisibility();
      return true;
    }else if (this.isAlreadyConverted && this.autoRunBatchTableData.filter((autoRunData) => autoRunData['included']).length > 0) {
      this.setLoaderVisibility(false);
      this.setAlertVisibility(true, AlertType.ERROR, 'Selected groups are already converted.');
      this.hideAlertVisibility();
      this.autoRunBatchTableData.forEach((renewal) => {
        if (renewal['included'] && renewal['latestAutoRunConverted']) {
          this.isConvert = true;
        }
      });
      return true;
    }
  }

  listenToAutoRunConvertEvents(eventSource: any): void {
    this.ngZone.runOutsideAngular(() => {
      eventSource.addEventListener('BATCH_AUTORUN_CONVERT_UPDATEUI_TASK', (event: any) => {
        this.processBulkConvertEvents(event);
        this.autoRunBatchTableData = [...this.autoRunBatchTableData];
        this.scheduleChangeDetection();
        setTimeout(() => {
          this.checkIsAutoRunConvertCompleted();
          this.scheduleChangeDetection();
        }, 5000);
      });

      eventSource.addEventListener('BATCH_AUTORUN_CONVERT_COMPLETION_TRIGGER', (event: any) => {
        eventSource.close();
        if (event && event.data) {
          var eventData = JSON.parse(event.data);
          var payload = eventData.payload;
          this.receivedBatchEvents.forEach(e => {
            if (e.startsWith(eventData.processId)) {
              this.receivedBatchEvents.delete(e);
            }
          });
          this.ngZone.run(() => {
            this.renewalBatchWrapper.renewalBatch['recentAutoRunConvertProcessStatus'] = payload.recentAutoRunConvertProcessStatus;
            this.retriveBulkAdjDetails();
          });
        }
        setTimeout(() => {
          this.checkIsAutoRunConvertCompleted();
          this.scheduleChangeDetection();
        }, 5000);
      });
    }); // end runOutsideAngular
  }

  checkIsAutoRunConvertCompleted() {
    this.autoRunBatchTableData
      .filter((autoRunData) => autoRunData.convert === true)
      .forEach((autoRunData) => {
        if (autoRunData.convert) {
          if (this.autoRunBatchTableData.filter((autoRunData) => autoRunData['isAutoRunConvertTaskDone'] === false).length > 0) {
            this.isNotConverted = true;
            this.addFailedConvertGroups.push(autoRunData.groupNumber);
            this.setAutorunFailedMassage();
          }
          if (autoRunData['convertProcessDetails']) {
            if (autoRunData['convertProcessDetails']['isAutoRunConvertTaskDone']) {
              autoRunData.isAutoRunConvertTaskDone = true;
            } else if (!autoRunData['convertProcessDetails']['isAutoRunConvertTaskDone']) {
              autoRunData['convert'] = false;
              autoRunData.isAutoRunConvertTaskDone = false;
              this.addFailedConvertGroups.push(autoRunData.groupNumber);
              this.isNotConverted = true;
            }
          }
        }
      });
  }

  setAutorunFailedMassage() {
    this.addFailedConvertGroups.forEach((groupNumber) => {
      this.autoRunBatchTableData
        .filter((autoRunData) => autoRunData.groupNumber === groupNumber)
        .forEach((autoRunData) => {
          autoRunData.convert = false;
        });
    });
    if (this.isNotConverted || this.autoRunBatchTableData.filter((autoRunData) => autoRunData['isAutoRunConvertTaskDone'] === false).length > 0) {
      this.setMsgForFailedConverts = 'AutoRun convert failed.';
      setTimeout(() => {
        this.setMsgForFailedConverts = '';
        this.isNotConverted = false;
      }, 15000);
    }
  }

  private processBulkConvertEvents(event: any) {
    if (event && event.data) {
      var eventData = JSON.parse(event.data);
      let payload = eventData['payload'];
      if (this.isDummyEvent(payload)) {
        return;
      }
      const lookupKey = `${payload['opportunityID']}_${payload['quoteHeaderID']}_${payload['ratingTransID']}`;
      const autoRunDetail = this.autoRunDetailsMap.get(lookupKey);
      if (autoRunDetail) {
        let autoRunConvertProcessDetails = payload['autoRunConvertProcessDetails'];
        const eventKey = eventData.processId + payload['ratingTransID'] + autoRunConvertProcessDetails.eventName;
        if (this.receivedBatchEvents.has(eventKey)) {
          return;
        }
        this.receivedBatchEvents.add(eventKey);
        let eventName = autoRunConvertProcessDetails.eventName;
        let convertProcessDetails = autoRunConvertProcessDetails.convertProcessDetails;
        autoRunDetail['convertProcessDetails'] = convertProcessDetails;
        if (eventName == 'BATCH_RENEWAL_AUTORUN_CONVERT_CHECK_ELIGIBILITY') {
          autoRunDetail['convertStatus'] = convertProcessDetails['convertStatus'];
          autoRunDetail['convertProcessErrors'] = convertProcessDetails['convertProcessErrors'];
          autoRunDetail['convertProcessDetails'] = convertProcessDetails;
          autoRunDetail['convertProcessDetails']['isCheckConvertEligibilityTaskDone'] =
            convertProcessDetails['isCheckConvertEligibilityTaskDone'];
          autoRunDetail['convertProcessDetails']['checkConvertEligibilityStatus'] = convertProcessDetails['checkConvertEligibilityStatus'];
        } else if (eventName == 'BATCH_RENEWAL_AUTORUN_CONVERT_QUOTE') {
          autoRunDetail['convertProcessDetails']['isAutoRunConvertTaskDone'] = convertProcessDetails['isAutoRunConvertTaskDone'];
          autoRunDetail['convertProcessDetails']['autoRunConvertStatus'] = convertProcessDetails['autoRunConvertStatus'];
          autoRunDetail['isAutoRunConvertTaskDone'] = convertProcessDetails['isAutoRunConvertTaskDone'];
        } else if (eventName == 'BATCH_RENEWAL_AUTORUN_CONVERT_SINGLE_COMPLETE') {
          autoRunDetail['convertStatus'] = convertProcessDetails['convertStatus'];
          this.flushGrdRlMsgOnRelease(convertProcessDetails['convertStatus'], autoRunDetail);
          this.renewalBatchWrapper.renewalBatch['recentAutoRunConvertProcessStatus'] = 'SUCCESS';
          autoRunDetail['convertProcessErrors'] = convertProcessDetails['convertProcessErrors'];
          autoRunDetail['isAutoRunConvertTaskDone'] = convertProcessDetails['isAutoRunConvertTaskDone'];
        }
      }
    }
  }

  hideAlertVisibility() {
    const timeout = this.commonService.getProgressBarTimeOut();
    setTimeout(() => {
      this.setAlertVisibility(false);
      this.cdRef.markForCheck();
    }, timeout);
  }

  showAlertBasedOnConditions(message: string) {
    return {
      'alert-largeText alertContainer-largeText renewal-alert-largeText': message.length > 150,
      'alert alertContainer renewal-alert': message.length < 150
    };
  }

  getAutoRunBatchDetails() {
    this.expandClicked = false;
    if (this.activeTab == 'AUTORUN') {
      this.showLoader = true;
    }
    this.renewalsService.fetchAutoRunBatchDetails(this.renewalBatchWrapper.renewalBatch['id']).subscribe(
      (data) => {
        if (data['processId']) this.listenToAutoRunDetailsEvents(data['processId']);
      },
      (error) => {
        this.showLoader = false;
        console.error('error in getAutoRunBatchDetails ', error);
        this.cdRef.markForCheck();
      }
    );
  }

  private listenToAutoRunDetailsEvents(processID: string) {
    let isTableDataCleared = false;
    var eventSource = this.commonService.listenForStream(processID);
    this.ngZone.runOutsideAngular(() => {
      eventSource.addEventListener('AUTO_RUN_BULK_DETAILS_STATUS', (event: any) => { });
      eventSource.addEventListener('AUTO_RUN_BULK_ADJ_DETAILS_FETCH', (event: any) => {
        if (event.data) {
          const scrollY = window.scrollY; // capture scroll before any data mutation
          var eventData = JSON.parse(event.data);
          var autoRunBatchdetails = eventData['payload']['autoRunBulkAdjDetails'];
          // Clear the table data only once, because we are getting the data in chunks i.e multiple events
          if (!isTableDataCleared) {
            this.autoRunBatchTableData = [];
            this.autoRunDetailsMap.clear();
            isTableDataCleared = true;
          }
          // Merge in-place to preserve object identity (keeps trackBy stable → no DOM teardown → no scroll reset).
          // Only merge when all three IDs are present — rows with missing IDs would otherwise
          // collapse into each other and disappear from the table.
          autoRunBatchdetails.forEach((incoming: any) => {
            const hasFullKey = incoming.opportunityID != null
              && incoming.quoteHeaderID != null
              && incoming.ratingTransID != null;
            const key = `${incoming.opportunityID}_${incoming.quoteHeaderID}_${incoming.ratingTransID}`;
            const existing = hasFullKey ? this.autoRunDetailsMap.get(key) : undefined;
            if (existing) {
              Object.assign(existing, incoming);
            } else {
              this.autoRunBatchTableData.push(incoming);
              if (hasFullKey) {
                this.autoRunDetailsMap.set(key, incoming);
              }
            }
          });
          this.showLoader = false;
          this.scheduleChangeDetection();
          // Safety net: only restore if the position actually moved, to avoid fighting the user's scroll
          requestAnimationFrame(() => { if (window.scrollY !== scrollY) window.scrollTo({ top: scrollY, behavior: 'instant' }); });
        }
      });
      eventSource.addEventListener('AUTO_RUN_BULK_ADJ_DETAILS_FETCH_COMPLETE', (event: any) => {
        eventSource.close();
        this.ngZone.run(() => {
          if (this.autoRunBatchTableData.length > 0) {
            this.setAutorunFailedMassage();
          }
          // Null-safe sort: rows with missing groupName sort to end
          this.autoRunBatchTableData = [...this.autoRunBatchTableData]
            .sort((a, b) => {
              if (!a.groupName && !b.groupName) return 0;
              if (!a.groupName) return 1;
              if (!b.groupName) return -1;
              return a.groupName.localeCompare(b.groupName);
            });
          this.showLoader = false;
          this.verifyAllAutoRunDataDetails();
          this.enableBulkAdjTab();
          this.enableTieringTab();
          if (this.activeTab == 'AUTORUN') {
            this.setAlertVisibility(true, AlertType.SUCCESS, 'AutoRun details loaded successfully');
            this.hideAlertVisibility();
          }
          this.cdRef.markForCheck();
        });
      });
      eventSource.addEventListener('FAILED', (event: any) => {
        eventSource.close();
        this.ngZone.run(() => {
          this.cdRef.markForCheck();
        });
      });
    }); // end runOutsideAngular
    // For autorun batches: fetch bulk-adj eagerly on batch load (activeTab='BATCH').
    // Skip when called from AUTORUN tab click — bulk was already loaded at batch open.
    if (this.activeTab === 'BULK' || (this.isAutoRunBatch && this.activeTab !== 'AUTORUN')) {
      this.retriveBulkAdjDetails();
    }
  }

  addLatestAutoRunConvertedToBulk() {
    // Mutate in-place rather than replacing with clones, so that bulkViewTableDataMap references
    // remain valid and the merge loop in listenToBulkAdjDetailsEvents sees the same objects.
    this.bulkViewTableData.forEach((row: any) => {
      const match = this.autoRunBatchTableData.find((obj2) => obj2.groupNumber === row.groupNumber);
      row.isAutoRunConverted = match?.latestAutoRunConverted;
    });
  }
  EmptyAutoRunTableData() {
    return this.autoRunBatchTableData.length === 0;
  }

  checkFundingType(selectedValue) {
    this.fundingTypeCheck = (selectedValue == CommonConstants.FI || selectedValue == CommonConstants.ABF);
  }

  updateDownloadVersions() {
    if (this.isMEWABulkAdj) {
      this.availableVersions = [
        { label: 'V1', value: 'NON_CT_STATE' }
      ];
    } else {
      this.availableVersions = [
        { label: 'V1', value: 'NON_CT_STATE' },
        { label: 'V2', value: 'CT_STATE' }
      ];
    }
    this.selectedVersion = [];
  }

  autoSelectVersions() {
    if (this.isMEWABulkAdj) {
      this.selectedVersion = ['NON_CT_STATE'];
    } else {
      this.selectedVersion = ['NON_CT_STATE', 'CT_STATE'];
    }
  }

  autorunCheckboxDisplay() {
    return (
      ((this.groupNumbersFile && this.commonService.isAutoRunBatchEnabled) || this.showAutoRun()) &&
      !(
        (this.selectedMode === 'fileUpload' || this.detailsByFileUpload) &&
        [undefined, this.submissionStatus.NOT_SUBMITTED].includes(this.renewalBatchWrapper?.renewalBatch?.batchStatus)
      )
    );
  }

  getUploadFileName(event: any) {
    this.groupNumbersFile = event;
    this.batchSearchForm.controls.fundingTypes.setValue('ALL');
    this.batchSearchForm.controls.groupNumber.setValue('');
    this.grpNameAndNumberValidation();
    this.setAlertVisibility(true, AlertType.SUCCESS, this.groupNumbersFile.name + ' uploaded successfully. Click on "Search" to find the groups.',
      undefined,
      true
    );
    this.hideAlertVisibility();
  }

  showdownloadIcon() {
    return this.enabledBatchGroupDownload && this.renewalBatchWrapper.renewalBatch.actionPerformed == 'save' && StringUtils.isEqual(this.renewalBatchWrapper.renewalBatch['batchStatus'], CommonConstants.NOT_SUBMITTED);
  }

  checkIsLOBVisionOrDental() {
    const isVisionLob = StringUtils.isEqual(this.renewalBatchWrapper?.renewalBatchDetails[0]?.lob, CommonConstants.Vision);
    const isDentalLob = StringUtils.isEqual(this.renewalBatchWrapper?.renewalBatchDetails[0]?.lob, CommonConstants.Dental);

    return isVisionLob || isDentalLob;
  }

  getVisDenBulkTableColumns() {
    let columns = [...RenewalsConstants.VIS_DEN_BULK_TABLE_COLUMNS];

    // Filter out Loss Ratio column for Vision LOB unless backend flag is enabled
    const isVisionLob = StringUtils.isEqual(this.renewalBatchWrapper?.renewalBatchDetails[0]?.lob, CommonConstants.Vision);
    if (isVisionLob && !this.lossRationVisionViewOnBulkScreenEnabled) {
      columns = columns.filter(col => col.header !== 'Loss Ratio');
    }

    return columns;
  }

  showBatchInfoTabOnlyForVisionAndDental() {
    return !this.enableQuoteOptions && this.checkIsLOBVisionOrDental();
  }

  disableBulkAdjustment() {
    return this.disbleBulkAdj
      || this.allGroupsCrossSelled
      || [CommonConstants.ACA].includes(this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType)
      || (
      [undefined, this.submissionStatus.NOT_SUBMITTED].includes(this.renewalBatchWrapper?.renewalBatch?.batchStatus) 
      && !this.renewalBatchWrapper?.renewalBatchDetails?.every((detail: any) => detail.source === 'RARE') 
      );
  }

  updateAlternateQuoteData(batchDetail: RenewalBatchDetails, payload: any) {
    const eventKey = payload.batchID + payload.groupNumber + payload?.marketSegment + payload?.fundingType + payload?.status;
    if (this.receivedAlternateQuoteEvents.includes(eventKey)) {
      return;
    }
    const scrollY = window.scrollY; // capture scroll after early-return, before any data mutation
    
    const key = String(batchDetail?.groupNumber).trim().toLowerCase();
    const quoteOptions = this.quoteOptionsDataMap.get(key) ?? [];
    let applied = false;
    quoteOptions.forEach((quoteOption: any) => {
      quoteOption.alternateQuotes?.forEach((alternateQuote: any) => {
        if (StringUtils.isEqualIgnoreCase(alternateQuote?.marketSegment, payload?.marketSegment)) {
          if (alternateQuote?.fundingOptions?.[payload?.fundingType]) {
            alternateQuote.fundingOptions[payload.fundingType].quoteRenewalStatus = payload?.status;
            if (payload?.isSSEQuoteStatusReceived) {
              alternateQuote.fundingOptions[payload.fundingType].isSSEQuoteStatusReceived = payload?.isSSEQuoteStatusReceived;
            }
            if (payload.quoteHeaderID) {
              alternateQuote.fundingOptions[payload.fundingType].quoteHeaderID = payload?.quoteHeaderID;
            }
            applied = true; 
          }
        }
      });
    });
    if (applied) {
      this.receivedAlternateQuoteEvents.push(eventKey); 
    }
    this.quoteOptionsData = [...this.quoteOptionsData];
    this.scheduleChangeDetection();
    // Safety net: only restore if the position actually moved, to avoid fighting the user's scroll
    requestAnimationFrame(() => { if (window.scrollY !== scrollY) window.scrollTo({ top: scrollY, behavior: 'instant' }); });
  }

  updateAlternateBatchData(payload: any, eventKey: string) {
    if (payload && payload.alternateQuotes && payload.alternateQuotes.length > 0) {
      const scrollY = window.scrollY; // capture scroll after guard check, before any data mutation
      const key = String(payload?.groupNumber).trim().toLowerCase();
      const quoteOptions = this.quoteOptionsDataMap.get(key) ?? [];
      payload.alternateQuotes.forEach((alternateQuote: any) => {
        const alternateKey = eventKey + alternateQuote.marketSegment + payload.groupNumber;
        const fundingOptionsKeys = Object.keys(alternateQuote.fundingOptions);
        fundingOptionsKeys.forEach((fundingOptionKey: any) => {
          const alternateEventKey = alternateKey + fundingOptionKey + alternateQuote.fundingOptions[fundingOptionKey]?.submissionStatus;
          if (!this.receivedAlternateBatchEvents.has(alternateEventKey)) {
            let batchApplied = false;
            quoteOptions.forEach((quoteOption: any) => {
              const originalAlternateQuotes: any[] = quoteOption.alternateQuotes.filter(
                (originalAlternateQuote: any) => originalAlternateQuote.marketSegment === alternateQuote.marketSegment
              );
              originalAlternateQuotes.forEach((originalAlternateQuote: any) => {
                const originalFundingOption = originalAlternateQuote.fundingOptions[fundingOptionKey];
                const payloadFundtionOption: any = alternateQuote.fundingOptions[fundingOptionKey];
                if (!StringUtils.isEqualIgnoreCase(originalFundingOption.submissionStatus, this.groupSubmissionStatus.SUCCESS) || !StringUtils.isEqualIgnoreCase(originalFundingOption.submissionStatus, this.groupSubmissionStatus.FAILED)) {
                  originalFundingOption.submissionStatus = payloadFundtionOption.submissionStatus;
                  originalFundingOption.isSubmitted = !originalFundingOption.isSubmitted && payloadFundtionOption.isSubmitted ? payloadFundtionOption.isSubmitted : originalFundingOption.isSubmitted;
                  originalFundingOption.isQueuedForDataGathering = !originalFundingOption.isQueuedForDataGathering && payloadFundtionOption.isQueuedForDataGathering ? payloadFundtionOption.isQueuedForDataGathering : originalFundingOption.isQueuedForDataGathering;
                  originalFundingOption.isRequestCreated = !originalFundingOption.isRequestCreated && payloadFundtionOption.isRequestCreated ? payloadFundtionOption.isRequestCreated : originalFundingOption.isRequestCreated;
                  originalFundingOption.isSubmittedToGateWay = !originalFundingOption.isSubmittedToGateWay && payloadFundtionOption.isSubmittedToGateWay ? payloadFundtionOption.isSubmittedToGateWay : originalFundingOption.isSubmittedToGateWay;
                  originalFundingOption.submissionFailCheckPoint = payloadFundtionOption.submissionFailCheckPoint;
                  originalFundingOption.submissionErrors = payloadFundtionOption.submissionErrors;
                  batchApplied = true;
                }
              });
            });
            if (batchApplied) {
              this.receivedAlternateBatchEvents.add(alternateEventKey);
            }
          }
        });
      });
      this.quoteOptionsData = [...this.quoteOptionsData];
      this.scheduleChangeDetection();
      // Safety net: only restore if the position actually moved, to avoid fighting the user's scroll
      requestAnimationFrame(() => { if (window.scrollY !== scrollY) window.scrollTo({ top: scrollY, behavior: 'instant' }); });
    }
  }

  showBulkAdjForMedicalAndSuppHealth() {
    return StringUtils.isEqual(this.selectedLOB, CommonConstants.Medical) || StringUtils.isEqual(this.selectedLOB, CommonConstants.SuppHealth);
  }

  showBulkAdjForDenAndVis() {
    return (StringUtils.isEqual(this.selectedLOB, CommonConstants.Dental) || StringUtils.isEqual(this.selectedLOB, CommonConstants.Vision))
      && this.renewalBatchWrapper?.renewalBatchDetails[0]?.marketSegment === CommonConstants.LG;
  }

  onTierChange(event) {
    this.selectedTierAction = event;
    if ((this.renewalBatchWrapper.renewalBatchDetails as RenewalBatchDetails[]).some((detail: RenewalBatchDetails) => detail.quoteRenewalStatus === QuoteRenewalStatus.PROCESSING || detail.quoteRenewalStatus === QuoteRenewalStatus.FAIL)) {
      this.customizePlanModal();
    }
    else {
      this.continueTierChange();
    }
  }

  continueTierChange(){
    if (this.selectedTierAction) {
      let renewalData = {
        "lob": this.renewalBatchWrapper.renewalBatchDetails[0]?.lob,
        "renewalDate": this.renewalBatchWrapper.renewalBatchDetails[0]?.renewalDate,
        "fundingType": this.renewalBatchWrapper.renewalBatchDetails[0]?.fundingType,
        "marketSegment": this.renewalBatchWrapper.renewalBatchDetails[0]?.marketSegment,
        "state": this.renewalBatchWrapper.renewalBatchDetails[0]?.state,
      };
      if (!this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput?.selectedSnapMonthYear) {
        this.renewalsService.getTieringInput(renewalData).subscribe(data => {
          if (data && data?.snapMonthYearsFromDataMart[0]){
             this.tierOrRepullTier(this.selectedTierAction, data.snapMonthYearsFromDataMart[0]);
          }
        }, (error) => {
          console.error("error getTieringInput ", error);
        });
      } else {
        this.tierOrRepullTier(this.selectedTierAction, this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput?.selectedSnapMonthYear)
      }
    }
  }

  tierOrRepullTier(event, selectedSnapMonthYear){
    if (selectedSnapMonthYear) {
      let renewalDateStr = this.renewalBatchWrapper.renewalBatchDetails[0]?.renewalDate;
      let monthNumber = renewalDateStr ? parseInt(renewalDateStr.split('-')[1], 10) : null;

      this.renewalBatchWrapper.renewalBatch.tieringInfo = this.renewalBatchWrapper.renewalBatch.tieringInfo || {};
      this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput = this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput || {};
      this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput.selectedSnapMonthYear = selectedSnapMonthYear;
      this.convertTieringToDecimal();
      let data = {
        "lob": this.renewalBatchWrapper.renewalBatchDetails[0]?.lob,
        "batchID": this.renewalBatchWrapper.renewalBatchDetails[0]?.batchID,
        "renewalMonth": monthNumber,
        "fundingType": this.renewalBatchWrapper.renewalBatchDetails[0]?.fundingType,
        "marketSegment": this.renewalBatchWrapper.renewalBatchDetails[0]?.marketSegment,
        "state": this.renewalBatchWrapper.renewalBatchDetails[0]?.state,
        "repull": event == 'Repull and Tier' ? true : false,
        "snapMonthYear": selectedSnapMonthYear,
        "tieringInput": this.renewalBatchWrapper.renewalBatch?.tieringInfo?.tieringInput
      };

      this.tierLoader = true;
      this.renewalsService.rePullTier(data).subscribe(response => {
        // Handle the response
        this.tierLoader = false;
        this.convertTieringToPercentage();
        if (response?.processID) this.listenToTieringEvents(response.processID, selectedSnapMonthYear);
      }, (error) => {
        this.tierLoader = false;
        console.error("error repull ", error);
      });
    }
  }

  updateProgressBar(progressStyle, progressPercent, progressMessage) {
    this.progressStyle = progressStyle;
    this.progressPercent = progressPercent;
    this.progressMessage = progressMessage;
  }

  listenToTieringEvents(processID: string, selectedSnapMonthYear: string){
    this.showProgress = true;
    this.progressPercent = 1;
    this.progressStyle = 'progress-bar-warning';
    this.cdRef.markForCheck();
    var eventSource = this.commonService.listenForStream(processID);
    eventSource.addEventListener('TIERING_MODULE_TIERING_STARTED', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_REPULL_COMPLETED', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_COMPONENT_CALC_INPROGRESS', (event: any) => {
      this.getFailedTieringGroupNumbers(event);
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_COMPONENT_CALC_COMPLETED', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_FORMULA_RATE_CALC_INPROGRESS', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_FORMULA_RATE_CALC_COMPLETED', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_UW_RATE_CALC_INPROGRESS', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_UW_RATE_CALC_COMPLETED', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_APPLY_ADJUSTMENT_TO_QUOTE_INPROGRESS', (event: any) => {
      this.updateTierProgress(event);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_ADJUSTMENTS_APPLIED_COMPLETED', (event: any) => {
      this.updateTierProgress(event, true);
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('FAILED', (event: any) => {
      eventSource.close();
      this.disableTieringInput = false;
      this.updateProgressBar('progress-bar-danger', 90, 'Failed to Tier');
      this.updateTieringFromEvent(event, selectedSnapMonthYear);
      this.hideProgressBar();
      this.cdRef.markForCheck();
    });
    eventSource.addEventListener('TIERING_MODULE_TIERING_COMPLETED', (event: any) => {
      eventSource.close();
      this.disableTieringInput = false;
      this.updateProgressBar('progress-bar-success', 100, 'Tiering Completed');
      this.updateTieringFromEvent(event, selectedSnapMonthYear);
      this.hideProgressBar();
      this.cdRef.markForCheck();
    });
  }

  updateTierProgress(event, isTieringCompleted?: boolean) {
    this.disableTieringInput = true;
    let eventData = JSON.parse(event.data);
    if(isTieringCompleted && eventData?.payload?.recentAdjustmentProcessID) {
      this.listenToBulkAdjEvents(eventData?.payload?.recentAdjustmentProcessID, 'release');
      let eventSource = this.commonService.listenForStream(eventData?.payload?.recentAdjustmentProcessID + 'REL');
      this.listenToBulkReleaseEvents(eventSource, true);
    }
    var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
    this.updateProgressBar('', percent, eventData.message);
  }

  updateTieringFromEvent(event, selectedSnapMonthYear) {
    if (event?.data) {
      const eventData = JSON.parse(event.data);
      if(eventData && eventData?.payload?.groupRiskDetails){
        this.renewalBatchWrapper.renewalBatch.groupRiskDetails = eventData.payload.groupRiskDetails;
        this.onSnapMonthYearChanged(selectedSnapMonthYear);
      }
      if (eventData && eventData?.payload?.tieringInfo) {
        this.renewalBatchWrapper.renewalBatch.tieringInfo = eventData.payload.tieringInfo;
        this.convertTieringToPercentage();
        this.calculateformulaTotalRateActionPercent();
        if (this.activeTab === 'BULK') {
          this.retriveBulkAdjDetails();
        }
      }
    }
  }

  getFailedTieringGroupNumbers(event: any) {
    let eventData = JSON.parse(event.data);

    let groupsExcludedFromTiering = eventData?.payload?.groupsExcludedFromTiering;
    if (groupsExcludedFromTiering && Object.keys(groupsExcludedFromTiering).length > 0) {
      this.failedTieringGroups = Object.keys(groupsExcludedFromTiering);

      // Set the main error message
      this.errorMsgforFailedTiering = Object.values(groupsExcludedFromTiering).join(',');
    } else {
      // Clear failed groups if none exist
      this.failedTieringGroups = [];
    }
  }

  showFailedTieringGrp(groupNumber) {
    const groupsExcludedFromTiering = this.renewalBatchWrapper?.renewalBatch?.groupsExcludedFromTiering;
    if (groupsExcludedFromTiering && typeof groupsExcludedFromTiering === 'object') {
      return groupsExcludedFromTiering.hasOwnProperty(groupNumber);
    }
    return false;
  }

  getFailedTieringGroupNumberMessage(groupNumber) {
    const groupsExcludedFromTiering = this.renewalBatchWrapper?.renewalBatch.groupsExcludedFromTiering;
    if (groupsExcludedFromTiering && typeof groupsExcludedFromTiering === 'object') {
      if (groupsExcludedFromTiering.hasOwnProperty(groupNumber)) {
        return groupsExcludedFromTiering[groupNumber];
      }
    }
    return null;
  }

  convertTieringToPercentage() {
    if (this.renewalBatchWrapper?.renewalBatch?.tieringInfo?.tieringInput) {
      // Multiply only overallRateIncrease, minIncrease, maxIncrease in formulaInput and uwTieredInput by 100 if they exist and are numbers
      const tieringInput = this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput;
      ['formulaInput', 'uwTieredInput'].forEach(key => {
        if (tieringInput[key]) {
          ['overallRateIncrease', 'minIncrease', 'maxIncrease'].forEach(field => {
            const value = tieringInput[key][field];
            if (typeof value === 'number') {
              tieringInput[key][field] = Math.round(value * 100 * 100) / 100;
            } else if (!isNaN(Number(value)) && value !== '') {
              tieringInput[key][field] = Math.round(Number(value) * 100 * 100) / 100;
            }
          });
        }
      });
    }
  }

  convertTieringToDecimal(){
    if (this.renewalBatchWrapper?.renewalBatch?.tieringInfo?.tieringInput) {
      // Divide only overallRateIncrease, minIncrease, maxIncrease in formulaInput and uwTieredInput by 100 if they exist and are numbers
      const tieringInput = this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput;
      ['formulaInput', 'uwTieredInput'].forEach(key => {
      if (tieringInput[key]) {
        ['overallRateIncrease', 'minIncrease', 'maxIncrease'].forEach(field => {
        const value = tieringInput[key][field];
        if (typeof value === 'number') {
          tieringInput[key][field] = value / 100;
        } else if (!isNaN(Number(value)) && value !== '') {
          tieringInput[key][field] = Number(value) / 100;
        }
        });
      }
      });
    }
  }

  onSnapMonthYearChanged(event: any) {
    // Update the selected value in renewalBatchWrapper
    const snapMonthYears = this.renewalBatchWrapper?.renewalBatch?.groupRiskDetails ?? {};
    const isPresent = Object.keys(snapMonthYears).includes(event);

    if (!isPresent) {
      // Disable tier option from tierOptions dropdown
      this.disableTierDropdownOption = true;
    } else {
      this.disableTierDropdownOption = false;
    }

  }

  hideDropdownWithDelay() {
    this.hideDropdownTimeout = setTimeout(() => {
      this.showTierDropdown = false;
    }, 150); // 150ms delay allows mouse to move to dropdown
  }

  onTierButtonMouseEnter() {
    if (this.hideDropdownTimeout) {
      clearTimeout(this.hideDropdownTimeout);
    }
    this.showTierDropdown = true;
  }

  onTierDropdownMouseEnter() {
    if (this.hideDropdownTimeout) {
      clearTimeout(this.hideDropdownTimeout);
    }
    this.showTierDropdown = true;
  }

  onTierDropdownMouseLeave() {
    this.hideDropdownWithDelay();
  }

  customizePlanModal() {
    // Open the modal using Bootstrap's modal API
    const modal = document.getElementById('customizeModal');
    if (modal) {
      // For Bootstrap 5
      // @ts-ignore
      const bsModal = new window.bootstrap.Modal(modal);
      bsModal.show();
    }
  }

  onDownloadBotData(){

      let renewalDateStr = this.renewalBatchWrapper.renewalBatchDetails[0]?.renewalDate;
      let monthNumber = renewalDateStr ? parseInt(renewalDateStr.split('-')[1], 10) : null;
      let data = {
        "batchID": this.renewalBatchWrapper.renewalBatchDetails[0]?.batchID,
        "renewalMonth": monthNumber,
        "fundingType": this.renewalBatchWrapper.renewalBatchDetails[0]?.fundingType,
        "marketSegment": this.renewalBatchWrapper.renewalBatchDetails[0]?.marketSegment,
        "state": this.renewalBatchWrapper.renewalBatchDetails[0]?.state,
        "snapMonthYear": this.renewalBatchWrapper.renewalBatch.tieringInfo.tieringInput.selectedSnapMonthYear,
      };
    this.renewalsService.generatePrintExhibit(this.renewalBatchWrapper?.renewalBatch?.id, data).subscribe(
      (response) => {
          if (response['processId'] != null && response['processId'] != undefined) {
            this.processId = response['processId'];
            this.showProgress = true;
            this.progressPercent = 1;
            this.progressStyle = 'progress-bar-warning';
            var source = this.commonService.listenForStream(this.processId);
            source.addEventListener('FILE_GENERATION_PROCESS_STARTED', (event: any) => {
              this.progressStyle = '';
              let eventData = JSON.parse(event.data);
              var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            });
            source.addEventListener('FILE_GENERATION_PROCESS_INPROGRESS', (event: any) => {
              this.progressStyle = '';
              let eventData = JSON.parse(event.data);
              var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            });
            source.addEventListener('FILE_GENERATION_PROCESS_COMPLETED', (message: any) => {
              source.close();
              let eventData = JSON.parse(message.data);
              this.progressStyle = 'progress-bar-success';
              this.progressPercent = 100;
              this.progressMessage = eventData.message;
              CommonService.exportFilename = eventData.metaData.fileName ? eventData.metaData.fileName : 'sheet';
              let fileName = this.commonService.getExportFilename();
              let contentData = eventData.payload.contentData;
              const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
              setTimeout(() => {
                this.showProgress = false;
              }, this.commonService.getProgressBarTimeOut());
            });
            source.addEventListener('FILE_GENERATION_PROCESS_FAILED', (message: any) => {
              source.close();
              let eventData = JSON.parse(message.data);
              this.progressPercent = 90;
              this.progressStyle = 'progress-bar-danger';
              this.progressMessage = eventData.message;
              this.hideProgressBar();
            });
            source.addEventListener('FILE_GENERATION_PROCESS_NO_DATA_AVAILABLE', (message: any) => {
              source.close();
              let eventData = JSON.parse(message.data);
              if (source.readyState == EventSource.CLOSED) {
                this.progressPercent = 90;
                this.progressStyle = 'progress-bar-danger';
                this.progressMessage = eventData.message;
                this.hideProgressBar();
              }
            });
          }
        // this.onGeneratePrintExhibitSuccess.call(this, response);
      },
        (error) => {
          var promise = new Promise<any>((resolve) => {
            setTimeout(() => {
              resolve(false);
            }, 10000);
          });
          promise.then((res) => { });
        }
    );
  }

  updateBulkRowsFromExcel(eventData) {
    if (Array.isArray(eventData.payload?.missingMandatoryHeaderValueRows) && eventData.payload?.missingMandatoryHeaderValueRows.length > 0) {
      this.progressStyle = 'progress-bar-warning';
      const missingRows = eventData.payload?.missingMandatoryHeaderValueRows;
      this.missingGroupNumbers = missingRows;
      this.showMissingGroupsAccordion = true;
      this.isMissingGroupsAccordionExpanded = false;
      this.progressMessage = eventData.message;
    }
    else {
      this.progressStyle = 'progress-bar-success';
      this.progressMessage = eventData.message;
      this.showMissingGroupsAccordion = false;
      this.missingGroupNumbers = [];
    }
    if (eventData.payload && Array.isArray(eventData.payload.validRows) && eventData.payload.validRows.length > 0) {
      eventData.payload.validRows.forEach((updatedRow) => {
        // Find the group in bulkViewTableData by groupNumber
        const groupNumber = updatedRow['Group Number'];
        const grpObject = this.bulkViewTableData.find(g => String(g.groupNumber) === String(groupNumber));
        if (grpObject && updatedRow['editable fields'] && grpObject?.status != "Failed" && grpObject?.status != "Received" && grpObject?.status != "Processing") {
          // For each key in editable fields, map header to field and update grpObject
          Object.keys(updatedRow['editable fields']).forEach(headerKey => {
            // Find the column definition with this header
            const colDef = this.bulkTableCols.find(col => col.header === headerKey);
            if (colDef && colDef.field) {
              const uploadedValue = updatedRow['editable fields'][headerKey];
              
              if (colDef.field === 'currentRiskFactor' && grpObject.quotingType === 'MEWA') {
                if (grpObject.alternateQuote) {
                  return;
                }
                if (uploadedValue === '' || uploadedValue === null || uploadedValue === undefined) {
                  const initialRiskFactor = grpObject.data?.medical?.riskFactor;
                  if (initialRiskFactor !== null && initialRiskFactor !== undefined) {
                    grpObject[colDef.field] = initialRiskFactor;
                  }
                  return; 
                }
              }
              
              grpObject[colDef.field] = colDef.field == 'adjustedRateActionPercent'
                ? (typeof uploadedValue === 'number'
                    ? String(uploadedValue)
                    : uploadedValue)
                : uploadedValue;
            }
          });
          
          if (grpObject.quotingType === 'MEWA') {
            if (grpObject.currentRiskFactor !== undefined) {
              this.onRateActionChange('currentRiskFactor', grpObject, grpObject.currentRiskFactor, true);
            }
            if (grpObject.riskFactor !== undefined) {
              this.onRateActionChange('riskFactor', grpObject, grpObject.riskFactor, true);
            }
            if (grpObject.uwAdjustmentFactor !== undefined) {
              this.onRateActionChange('uwAdjustmentFactor', grpObject, grpObject.uwAdjustmentFactor, true);
            }
          } else {
            this.onRateActionChange(CommonConstants.adjustedRateActionPercent, grpObject, grpObject.adjustedRateActionPercent, true);
          }
        }
      });
    }
    if (Array.isArray(eventData.payload?.invalidRows) && eventData.payload.invalidRows.length > 0) {
      eventData.payload.invalidRows.forEach((invalidRow) => {
        const groupNumber = invalidRow['Group Number'];
        const grpObject = this.bulkViewTableData.find(g => String(g.groupNumber) === String(groupNumber));
        if (grpObject) {
          // Exclude 'Group Number' key from invalidRow when storing
          const { ['Group Number']: _, ...rest } = invalidRow;
          // For MEWA alt, exclude 'Current Risk Factor' errors 
          if (grpObject.quotingType === 'MEWA' && grpObject.alternateQuote) {
            const { ['Current Risk Factor']: __, ...filteredRest } = rest;
            grpObject['invalidRow'] = filteredRest;
          } else {
            grpObject['invalidRow'] = rest;
          }
        }
      });
    }
    
    this.isDirty = true;
    this.hideProgressBar();
  }

  checkBatchStatusSubmitWarn(){
    return this.renewalBatchWrapper?.renewalBatch?.batchStatus === this.submissionStatus.SUBMITTED && (this.activeTab === 'BATCH' || this.activeTab === 'QUOTEACTION' || this.activeTab === 'TIERING');
  }

  getToolTipValueInvalidImportField(col, invalidRow) {
    if (invalidRow && invalidRow[col]) {
      return invalidRow[col];
    }
  }

  closeMissingGroupsAccordion() {
    this.showMissingGroupsAccordion = false;
    this.missingGroupNumbers = [];
  }

  toggleMissingGroupsAccordion() {
    this.isMissingGroupsAccordionExpanded = !this.isMissingGroupsAccordionExpanded;
  }

  getMissingGroupNumbersDisplay(): string {
    const groupNumbers = this.missingGroupNumbers.map(row => row['Group Number'] || 'Unknown');
    return `Missing Proposed Increase in Group: ${groupNumbers.join(', ')}`;
  }

  validateUploadedFile(file: File): Promise<boolean> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

          const headers = jsonData[0] as string[];
          const groupNumberIndex = headers.indexOf('Group Number');

          if (groupNumberIndex === -1) {
            resolve(false);
            return;
          }

          for (let i = 1; i < jsonData.length; i++) {
            const row = jsonData[i] as any[];
            const groupNumber = row[groupNumberIndex];
            if (groupNumber === undefined || groupNumber === null || groupNumber === '') {
              resolve(true);
              return;
            }
          }

          resolve(false);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsArrayBuffer(file);
    });
  }


  uploadFileToBackend(event: any) {
    let fundingType = this.isFIBulkAdj ? CommonConstants.FI : (this.isMEWABulkAdj ? CommonConstants.MEWA : CommonConstants.ABF);
    if (this.renewalBatchWrapper?.renewalBatch?.id && event.files[0] && this.renewalBatchWrapper?.renewalBatch?.lobs[0]) {
      this.renewalsService.uploadImportFileBatch(event.files[0], this.renewalBatchWrapper?.renewalBatch?.id, this.renewalBatchWrapper?.renewalBatch?.lobs[0], fundingType, this.renewalBatchWrapper.renewalBatchDetails[0]?.marketSegment).subscribe(
        (response) => {
          if (response.body['processId'] != null && response.body['processId'] != undefined) {
            this.showProgress = true;
            this.progressPercent = 1;
            this.progressStyle = 'progress-bar-warning';
            this.cdRef.markForCheck();
            var source = this.commonService.listenForStream(response.body['processId']);
            this.showLoader = false;
            source.addEventListener('RENEWAL_BULK_UPLOAD_IMPORT', (event: any) => {
              this.progressStyle = '';
              this.progressPercent = 50;
              let eventData = JSON.parse(event.data);
              this.progressMessage = eventData.message;
              this.bulkViewTableData.forEach(item => item.invalidRow && (item.invalidRow = {}));
              this.cdRef.markForCheck();
            });
            source.addEventListener('RENEWAL_BULK_UPLOAD_IMPORT_STATUS_COMPLETE', (event: any) => {
              source.close();
              this.showImportedProgress = true;
              this.progressPercent = 100;
              let eventData = JSON.parse(event.data);
              if (eventData.failedEvent) {
                this.progressStyle = 'progress-bar-danger';
                this.progressMessage = eventData.message;
              }
              else if (Array.isArray(eventData.payload?.invalidRows) && eventData.payload.invalidRows.length === 0) {
                this.updateBulkRowsFromExcel(eventData);
              }
              else {
                this.updateBulkRowsFromExcel(eventData);
              }
              this.cdRef.markForCheck();
            });
            source.addEventListener('FAILED', (event: any) => {
              source.close();
              this.progressPercent = 100;
              let eventData = JSON.parse(event.data);
              this.progressStyle = 'progress-bar-danger';
              this.progressMessage = eventData.message;
              this.hideProgressBar();
              this.cdRef.markForCheck();
            });
          }
        },
        (error) => {
          this.showLoader = false;
          this.hideAlertVisibility();
        }
      );
    }
  }

  onInputFileUpload(event) {
    if (this.renewalBatchWrapper?.renewalBatch?.id && event.files[0] && this.renewalBatchWrapper?.renewalBatch?.lobs[0]) {
      this.validateUploadedFile(event.files[0]).then((hasMissingGroupNumber) => {
        if (hasMissingGroupNumber) {
          this.showValidationErrorDialog = true;
        } else {
          this.uploadFileToBackend(event);
        }
      }).catch((error) => {
        console.error('File validation error:', error);
        this.uploadFileToBackend(event);
      });
    }
  }

  closeValidationDialog() {
    this.showValidationErrorDialog = false;
  }

  exportBulkTemplate() {
    const data = {
      data: {
        batchName: this.renewalBatchWrapper.renewalBatch.batchName,
        fundingType: this.isFIBulkAdj ? CommonConstants.FI : (this.isMEWABulkAdj ? CommonConstants.MEWA : CommonConstants.ABF),
        lob: this.renewalBatchWrapper?.renewalBatch?.lobs[0],
        marketSegment: this.renewalBatchWrapper.renewalBatchDetails[0]?.marketSegment
      }
    };
    this.renewalsService.getBulkAdjExportExcelData(data).subscribe(
      (x) => {
        if (x['processId'] != null && x['processId'] != undefined) {
          this.processId = x['processId'];
          this.showProgress = true;
          this.progressPercent = 1;
          this.progressStyle = 'progress-bar-warning';
          var source = this.commonService.listenForStream(this.processId);
          source.addEventListener('PE_GENERATION_STATUS', (event: any) => {
            this.progressStyle = '';
            let eventData = JSON.parse(event.data);
            var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
            this.progressPercent = percent;
            this.progressMessage = eventData.message;
          });
          source.addEventListener('SEND_EXHIBIT_TO_UI', (message: any) => {
            source.close();
            let eventData = JSON.parse(message.data);
            this.progressStyle = 'progress-bar-success';
            this.progressPercent = 100;
            this.progressMessage = eventData.message;
            CommonService.exportFilename = eventData.metaData.fileName ? eventData.metaData.fileName : 'sheet';
            let fileName = this.commonService.getExportFilename();
            let contentData = eventData.payload.contentData;
            const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
            this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
            setTimeout(() => {
              this.showProgress = false;
            }, this.commonService.getProgressBarTimeOut());
          });
          source.addEventListener('FAILED', (message: any) => {
            source.close();
            console.error('Received event : ', JSON.stringify(message.data));
            this.progressPercent = 90;
            this.progressStyle = 'progress-bar-danger';
            this.progressMessage = 'Error in getting response for download';
            this.hideProgressBar();
          });
          source.addEventListener('error', (message: any) => {
            source.close();
            console.error('Received error event, with ready status :' + source.readyState);
            if (source.readyState == EventSource.CLOSED) {
              this.progressPercent = 90;
              this.progressStyle = 'progress-bar-danger';
              this.progressMessage = 'Failed to fetch progress because of communication failure';
              this.hideProgressBar();
            }
          });
        }
      },
      (error) => {
        var promise = new Promise<any>((resolve) => {
          setTimeout(() => {
            resolve(false);
          }, 10000);
        });
        promise.then((res) => { });
      }
    );
  }

  showFilterErrors(){
    if(this.bulkViewTableData.some(item => item.hasOwnProperty('invalidRow'))){
      this.filterError = false;
    }
    return this.bulkViewTableData.some(item => item.hasOwnProperty('invalidRow'));
  }

  onFilterErrorChange(){
    
    if(this.filterError){
      this.bulkViewTableDataWithErrors = JSON.parse(JSON.stringify(this.bulkViewTableData.filter(item => !item.hasOwnProperty('invalidRow'))));
      this.bulkViewTableData = this.bulkViewTableData.filter(item => item.hasOwnProperty('invalidRow'));
    }
    else{
      // Merge back errors and non-errors into bulkViewTableData
      if (this.bulkViewTableDataWithErrors && this.bulkViewTableDataWithErrors.length > 0) {
        this.bulkViewTableData = [...this.bulkViewTableData, ...this.bulkViewTableDataWithErrors];
        this.bulkViewTableDataWithErrors = [];
      }
    }
    this.cdRef.markForCheck();
  }

  checkIfDashboardLinkShouldBeShown() {
    return !this.renewalBatchWrapper?.renewalBatchDetails?.every((detail: any) => detail?.source === 'RARE');
  }

  isDownloadBulk() {
    return !Array.isArray(this.selectedVersion) || this.selectedVersion.length === 0;
  }

  disableMewaOrginal() {
    return StringUtils.isEqual(this.renewalBatchWrapper?.renewalBatchDetails[0]?.fundingType, CommonConstants.MEWA) && this.mewaOriginalQuoteEnabled;
  }
  hasRareSourceInBatchDetails(): boolean {
  return Array.isArray(this.renewalBatchWrapper?.renewalBatchDetails)
    && this.renewalBatchWrapper.renewalBatchDetails.length > 0
    && this.renewalBatchWrapper?.renewalBatchDetails.every((detail: RenewalBatchDetails) => detail.source === 'RARE')
  }

  // Loss Ratio tooltip methods
  getLossRatioTooltip(bulkData: any): string {
    const lossRatioData = this.getLossRatioData(bulkData);
    if (!lossRatioData || !lossRatioData.value) {
      return '';
    }

    const lossRatioValue = parseFloat(lossRatioData.value);
    if (isNaN(lossRatioValue)) {
      return '';
    }

    return 'Loss Ratio:' +  (lossRatioValue * 100)?.toFixed(2) +'%';
  }

  formatLossRatio(value: any): string {
    if (!value) {
      return '';
    }
    const parsedValue = parseFloat(value);
    if (isNaN(parsedValue)) {
      return '';
    }
    return (parsedValue * 100).toFixed(2) + '%';
  }

  getLossRatioData(bulkData: any): any {
    if (!bulkData || !bulkData.quoteLevelGuardRailStatus) {
      return null;
    }
    return bulkData.quoteLevelGuardRailStatus.request_groupExperienceSummary_lossRatio;
  }

  hasLossRatioGuardrailFailed(bulkData: any): boolean {
    const lossRatioData = this.getLossRatioData(bulkData);
    return lossRatioData && lossRatioData.status === 'Failed';
  }

  getLossRatioValueForDisplay(bulkData: any): string {
    const lossRatioData = this.getLossRatioData(bulkData);
    if (!lossRatioData || !lossRatioData.value) {
      return '';
    }
    return this.formatLossRatio(lossRatioData.value);
  }
  
}
