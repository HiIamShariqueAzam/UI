import { CommonConstants } from "src/app/shared/constants/common.constants";
import {QuoteRenewalStatus} from "../../../shared/models/renewal-batch-details";
import {RenewalsConstants} from "../../renewals-constants";
import { CalculatorUtils } from "src/app/shared/utils/calculator-utils";

export class CreateBatchUtil {
  
  public static constructUWRequest(quoteData: any, action: string, isFIBulkAdj: boolean) : {} {
    let uwRequestData = {};
    //For MEWA Quotes we need to send ASO as fundingType
    const fundingType = (quoteData["fundingType"] === CommonConstants.MEWA && quoteData["quotingType"] === CommonConstants.MEWA) ? CommonConstants.ASO : quoteData["fundingType"];
    const isMEWA = quoteData["quotingType"] === CommonConstants.MEWA;
    
    uwRequestData["opportunity"] = {
      opportunityID: quoteData["opportunityID"],
      quoteHeaderID: quoteData["quoteHeaderID"],
      accountName: quoteData["groupName"],
      fundingType: fundingType,
      lob: quoteData["lob"],
      marketSegment: quoteData["marketSegment"],
      ratingTransID: quoteData["ratingTransID"],
      insertedTimeStamp: quoteData["insertedTimeStamp"],
      metaTransId: quoteData["metaTransID"],
      quotingType: quoteData["quotingType"],
      quoteOrigin: quoteData["quoteOrigin"],
    };
    // Handle LOB-specific uwAdjustment
    if (quoteData["lob"] === "Vision") {
      uwRequestData["uwAdjustment"] = {
        abfRateActionAdjustment: {
          adjustedRateActionPercent: quoteData["adjustedRateActionPercent"],
          renewalWHAPercent: quoteData["renewalWHAPercent"],
          discountSplits: quoteData[CommonConstants.DISCOUNT_SPLITS]
        },
        outputTier: quoteData.data.visionOutputTier,
        vision: quoteData["lob"] === "Vision" ? true : undefined,
        status: quoteData["status"],
        action: action.toUpperCase(),
        included: quoteData.included,
        uwNotesToSales: quoteData["uwNotesToSales"],
        uwComments: quoteData["uwComments"],
        tierRatioCalculationType:
          quoteData["data"] && quoteData["data"]["factors"]
            ? quoteData["data"]["factors"]["tierRatioCalculationType"]
            : null,
        overallProposedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['overallProposedIncrease'])),
        overallSuggestedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['overallSuggestedIncrease'])),
      };
      // Remove undefined keys (vision)
      if (uwRequestData["uwAdjustment"].vision === undefined) delete uwRequestData["uwAdjustment"].vision;
    } else if (quoteData["lob"] === "Dental") {
      uwRequestData["uwAdjustment"] = {
        abfRateActionAdjustment: {
          adjustedRateActionPercent: quoteData["adjustedRateActionPercent"],
          renewalWHAPercent: quoteData["renewalWHAPercent"],
          discountSplits: quoteData[CommonConstants.DISCOUNT_SPLITS]
        },
        outputTier: quoteData.data.dentalOutputTier,
        dental: quoteData["lob"] === "Dental" ? true : undefined,
        status: quoteData["status"],
        action: action.toUpperCase(),
        included: quoteData.included,
        uwNotesToSales: quoteData["uwNotesToSales"],
        uwComments: quoteData["uwComments"],
        tierRatioCalculationType:
          quoteData["data"] && quoteData["data"]["factors"]
            ? quoteData["data"]["factors"]["tierRatioCalculationType"]
            : null,
        overallProposedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['overallProposedIncrease'])),
        overallSuggestedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['overallSuggestedIncrease'])),
      };
      // Remove undefined keys (dental)
      if (uwRequestData["uwAdjustment"].dental === undefined) delete uwRequestData["uwAdjustment"].dental;
       } else {
      if (isMEWA) {
        const quoteAdjustments: any = {
          riskFactor: quoteData["riskFactor"],
          uwAdjustmentFactor: quoteData["uwAdjustmentFactor"],
          wholeHealthAdjustmentFactor: quoteData["wholeHealthAdjustmentFactor"],
          discountSplits: quoteData[CommonConstants.DISCOUNT_SPLITS]
        };
        
        if (!quoteData["alternateQuote"]) {
          quoteAdjustments.currentRiskFactor = quoteData["currentRiskFactor"];
        }

        uwRequestData["uwAdjustment"] = {
          quoteAdjustments: quoteAdjustments,
          outputTier: quoteData["data"] ? quoteData["data"]["medicalAlternateTier"] : null,
          medical: true,
          status: quoteData["status"],
          action: action.toUpperCase(),
          included: quoteData.included,
          uwNotesToSales: quoteData["uwNotesToSales"],
          uwComments: quoteData["uwComments"],
          tierRatioCalculationType: quoteData["data"] && quoteData["data"]["factors"] ? quoteData["data"]["factors"]["tierRatioCalculationType"] : null,
        };
      } else {
        uwRequestData["uwAdjustment"] = {
          abfRateActionAdjustment: {
            adjustedRateActionPercent: quoteData["adjustedRateActionPercent"],
            renewalWHAPercent: quoteData["renewalWHAPercent"],
            discountSplits: quoteData[CommonConstants.DISCOUNT_SPLITS]
          },
          outputTier: quoteData["data"] ? quoteData["data"]["medicalAlternateTier"] : null,
          medical: true,
          status: quoteData["status"],
          action: action.toUpperCase(),
          included: quoteData.included,
          uwNotesToSales: quoteData["uwNotesToSales"],
          uwComments: quoteData["uwComments"],
          tierRatioCalculationType: quoteData["data"] && quoteData["data"]["factors"] ? quoteData["data"]["factors"]["tierRatioCalculationType"] : null,
          overallProposedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['overallProposedIncrease'])),
          overallSuggestedIncrease: CalculatorUtils.convertPercentageToFactor(Number(quoteData['overallSuggestedIncrease'])),
        };
      }
    }
    if (quoteData["lob"] !== "Vision" && quoteData["lob"] !== "Dental") {
      if (!isMEWA) {
        if(!isFIBulkAdj)
      {
        uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]["componentRateAction"]=  {
            asoAdminFee: quoteData["asoAdminFee"],
            sslPremium: quoteData["sslPremium"],
            aslPremium: quoteData["aslPremium"],
            terminalLiability: quoteData["terminalLiability"],
            maxPaidClaim: quoteData["maxPaidClaim"],
          }
      }
      else {
        if(quoteData['formulaTieredRateActionPercent'] != null && quoteData['formulaTieredRateActionPercent'] != undefined) {
        uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]['formulaTieredRateActionPercent'] = quoteData['formulaTieredRateActionPercent'];
      }
      if(quoteData['uwTieredRateActionPercent'] != null && quoteData['uwTieredRateActionPercent'] != undefined) {
        uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]['uwTieredRateActionPercent'] = quoteData['uwTieredRateActionPercent'];
      }
      if (quoteData['isFlatRateApplied'] != null && quoteData['isFlatRateApplied'] != undefined) {
          uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]['isFlatRateApplied'] = quoteData['isFlatRateApplied'];
        }
        else {
          uwRequestData["uwAdjustment"]["abfRateActionAdjustment"]['isFlatRateApplied'] = false;
        }
      }
      }
    }
    uwRequestData["quoteReason"] = "REAL";
    if (quoteData["lob"] !== "Vision" && quoteData["lob"] !== "Dental") {
      if (quoteData["renewalWHAPercent"]) {
        uwRequestData["uwAdjustment"]["abfRateActionAdjustment"][
          "renewalWHAPercent"
          ] = quoteData["renewalWHAPercent"];
      }
    }
    return uwRequestData;
  }

  public static setOnLoadErrorMsgOnRevert(rowData: any, bulkAdjData) : any {
    let foundGrp = bulkAdjData.find(
      (grp) =>
        grp["ratingTransID"] == rowData["ratingTransID"] &&
        rowData["adjustedRateActionPercent"] ==
          grp["adjustedRateActionPercent"] &&
        rowData["asoAdminFee"] == grp["asoAdminFee"] &&
        rowData["sslPremium"] == grp["sslPremium"] &&
        rowData["aslPremium"] == grp["aslPremium"] &&
        rowData["terminalLiability"] == grp["terminalLiability"] &&
        rowData["maxPaidClaim"] == grp["maxPaidClaim"]
    );
    return foundGrp;
  }

  public static setCalculatedRateActionPercent(
    rowData: any,
    calculatedCompRates: any
  ): any {

    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "asoAdminFee"
    ] = calculatedCompRates["asoAdminCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "sslPremium"
    ] = calculatedCompRates["sslPremCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "aslPremium"
    ] = calculatedCompRates["aslPremCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "terminalLiability"
    ] = calculatedCompRates["terminalLiabilityCompPercent"];
    rowData["quoteDetail"]["uwAdjustment"]["abfRateActionAdjustment"][
      "maxPaidClaim"
    ] = calculatedCompRates["maxPaidClaimCompPercent"];
    rowData["asoAdminFee"] = calculatedCompRates["asoAdminCompPercent"];
    rowData["sslPremium"] = calculatedCompRates["sslPremCompPercent"];
    rowData["aslPremium"] = calculatedCompRates["aslPremCompPercent"];
    rowData["terminalLiability"] =
      calculatedCompRates["terminalLiabilityCompPercent"];
    rowData["maxPaidClaim"] = calculatedCompRates["maxPaidClaimCompPercent"];

    return rowData;
  }

  public static checkExpFactorsPresent(rowData): boolean {
    return (
      rowData["data"] &&
      rowData["data"]["factors"] &&
      rowData["data"]["factors"]["experienceFactors"] &&
      rowData["data"]["factors"]["experienceFactors"][
        "experienceAdjustmentFactor"
        ] &&
      rowData["data"]["factors"]["experienceFactors"]["currentComponentTotal"][
        "totalPremium"
        ] &&
      rowData["data"]["factors"]["experienceFactors"]["expComponentTotal"][
        "totalPremium"
        ]
    );
  }

  public static constructBulkAdjDataForComparsion(bulkAdjdetails: any[], bulkAdjData: any[]): any[] {
    bulkAdjdetails.forEach((data) => {
      if (
        data["status"] &&
        data["status"] != QuoteRenewalStatus.AWAITING_P2A_DATA &&
        data["status"] != QuoteRenewalStatus.AWAITING_RISK_SCORE &&
        data["status"] != QuoteRenewalStatus.PROCESSING &&
        data["status"] != QuoteRenewalStatus.RECEIVED &&
        data["status"] != QuoteRenewalStatus.FAIL
      ) {
        bulkAdjData.push({
          opportunityID: data["opportunityID"],
          quoteHeaderID: data["quoteHeaderID"],
          ratingTransID: data["ratingTransID"],
          adjustedRateActionPercent: data["adjustedRateActionPercent"],
          renewalWHAPercent: data["renewalWHAPercent"],
          wholeHealthAdjustmentFactor: data["wholeHealthAdjustmentFactor"],
          uwAdjustmentFactor: data["uwAdjustmentFactor"],
          currentRiskFactor: data["currentRiskFactor"],
          riskFactor: data["riskFactor"],
          finalRiskFactor: data["finalRiskFactor"],
          whsReduction: data["whsReduction"],
          asoAdminFee: data["asoAdminFee"],
          sslPremium: data["sslPremium"],
          aslPremium: data["aslPremium"],
          terminalLiability: data["terminalLiability"],
          maxPaidClaim: data["maxPaidClaim"],
          status: data["status"],
          groupNumber: data["groupNumber"],
          quotingType: data["quotingType"],
          errorMsg: data["errorMsg"],
          uwNotesToSales: data["uwNotesToSales"],
          uwComments: data["uwComments"],
          discountSplits: data["discountSplits"],
          overallProposedIncrease: data["overallProposedIncrease"],
          overallSuggestedIncrease: data["overallSuggestedIncrease"],
          visionProductAdjustments: data["visionProductAdjustments"] ? JSON.parse(JSON.stringify(data["visionProductAdjustments"])) : [],
        });
      }
    });
    return bulkAdjData;
  }

  public static setorRevertGuardRailMsg(rowData: any, cmplnFldCodes, bulkAdjData) {
    let foundGrp = CreateBatchUtil.setOnLoadErrorMsgOnRevert(rowData, bulkAdjData);
    if (foundGrp) {
      rowData["errorMsg"] = foundGrp["errorMsg"];
      return;
    } else if (cmplnFldCodes.length > 0) {
      rowData["errorMsg"] = RenewalsConstants.COMPLIANCE_CHECK_MSG.concat(
        cmplnFldCodes.join(" ,")
      );
      cmplnFldCodes = [];
    } else {
      rowData["errorMsg"] = "";
    }
    return cmplnFldCodes;
  }
}

