import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchOverlaysComponent } from './search-overlays.component';

describe('SearchOverlaysComponent', () => {
  let component: SearchOverlaysComponent;
  let fixture: ComponentFixture<SearchOverlaysComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SearchOverlaysComponent]
    });
    fixture = TestBed.createComponent(SearchOverlaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
