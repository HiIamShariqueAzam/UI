import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { RenewalsUtil } from '../../renewals-util';
import { RenewalsConstants } from '../../renewals-constants';
import { CommonConstants } from 'src/app/shared/constants/common.constants';

@Component({
  selector: 'app-search-overlays',
  templateUrl: './search-overlays.component.html',
  styleUrls: ['./search-overlays.component.css'],
  standalone: false
})
export class SearchOverlaysComponent {
    @Input() selectedMarketSegs: any;
  @Input() batchSearchForm: any;
  private _searchResults: any[] = [];
  @Input() showLoader: boolean;
  @Input() alert: any;
  @Input() errorExist: boolean;
  @Input() submissionStatus: any;
  @Input() renewalBatchWrapper: any;
  @Input() isAdminUser: boolean;
  @Input() isUserReadOnly: boolean;
  @Input() checkAllDetailsOverlay: boolean;
  @Input() renewalBatchColumnsNewBatch: any[];
  @Input() activeTab: string;
  @Input() searchBatchTab: boolean;
  @Input() first: number;
  @Input() detailsByFileUpload: boolean;
  @Input() hasDeletedGroupsInBatch: boolean;
  @Input() showOriginalGroupNumber: boolean;
  @Input() showPlusIconForGroupMerge: boolean;
  @Input() arrowIndex: number;
  @Input() groupNumberClicked: boolean;
  @Input() isTooltipVisible: boolean;
  @Input() mbuList: any[];
  @Input() isFIRewewalSearch: boolean;
  @Input() hideFooterBtn: boolean = true;
  @Input() isBatchInfoSmallTableHeaderFn: (header: string) => boolean;
  @Input() selectedMode: string;
  @Input() selectedAssociation: string;
  @Input() filteredAssociation: any[];
  @Input() onOptionChangeFn: () => void;
  @Input() selectedLOB: string;
  @Input() isFIselectedDropdown: string;
  @Input() onMBSOptionsSelectedFn: () => void;
  private _selectedMbs: any[] = [];
  @Input() set availableMBS(val: any[]) {
    // Always include 'Key' option at the top if not present
    if (Array.isArray(val)) {
      const hasKey = val.some(opt => opt && (opt.label === 'Key' || opt.value === 'Key'));
      if (!hasKey) {
        this._availableMBS = [{ label: 'Key', value: 'Key' }, ...val];
      } else {
        this._availableMBS = val;
      }
    } else {
      this._availableMBS = [{ label: 'Key', value: 'Key' }];
    }
    // Always select 'Key' by default if not already selected
    if (!this._selectedMbs || !Array.isArray(this._selectedMbs)) {
      this._selectedMbs = ['Key'];
    }
  }
  get availableMBS(): any[] {
    return this._availableMBS;
  }
  private _availableMBS: any[] = [];
  @Input() formSubmitted: boolean;
  @Input() selectedSystem: any;
  @Input() availableSystems: any[];
  @Input() selectmonths: any;
  @Input() selectedYear: any;
  @Input() includeTestQuotesSelected: boolean;
  @Input() removeAlertMsgFn: () => void;
  @Input() availableRenewalMonths: any[];
  @Input() fundTypeFromDetails: any;
  @Input() getFTSelectionFn: (label: string, fundTypeFromDetails: any) => boolean;
  @Input() availableFTs: any[];
  @Input() selectedRenewalMonthYear: any;
  @Input() disableFundingType: boolean;
  @Input() displayOptionsPannelFn: () => void;
  @Input() availableMarketSegs: any[];
  @Input() onLobSelectedFn: () => void;
  @Input() onStatesSelectedFn: () => void;
  @Input() onOptionsSelectedFn: (event: any) => void;
  @Input() availableStates: any[];
  @Input() selectstate: any;
  @Input() availableDatasourcesForBatchScreenSearchOverlay: any[];
  @Input() selectedDatasourceForBatchScreenSearchOverlay: any;
  @Input() omit_special_char: (event: KeyboardEvent) => void;
  @Input() grpNameAndNumberValidation: () => void;
  @Input() pasteEmitter: (event: ClipboardEvent) => void;
  @Input() errorPopup: () => void;
  @Input() availableLOBs: any[];
  @Input() tableDataExist: boolean;
  @Input() loader_visible: boolean;
  @Input() invalidGroupsTooltipMsg: string;
  @Input()
  set selectedMbs(val: any[]) {
    this._selectedMbs = Array.isArray(val) ? val : [];
  }
  get selectedMbs(): any[] {
    return this._selectedMbs;
  }
  @Input()
  set searchResults(val: any[]) {
    let deletedGroups = [];
    try {
      deletedGroups = JSON.parse(localStorage.getItem('deletedGroups') || '[]');
    } catch { }
    if (val && val.length && deletedGroups.length) {
      this._searchResults = val.filter(g => {
        const gGroupNumber = g.groupNumber ? String(g.groupNumber) : null;
        const gOriginalGroupNumber = g.originalGroupNumber ? String(g.originalGroupNumber) : null;
        return !deletedGroups.some(dg =>
          (dg.groupNumber && gGroupNumber && dg.groupNumber === gGroupNumber) ||
          (dg.originalGroupNumber && gOriginalGroupNumber && dg.originalGroupNumber === gOriginalGroupNumber)
        );
      });
    } else {
      this._searchResults = val || [];
    }
  }
  get searchResults(): any[] {
    return this._searchResults;
  }

  @Output() closeOverlay = new EventEmitter<void>();
  @Output() searchClicked = new EventEmitter<void>();
  @Output() resetClicked = new EventEmitter<void>();
  @Output() checkAllRenewalsOverlay = new EventEmitter<any>();
  @Output() deleteSelectedGroups = new EventEmitter<void>();
  @Output() submitRenewalBatchDetails = new EventEmitter<void>();
  @Output() saveRenewalBatchDetails = new EventEmitter<void>();
  @Output() checkAllDetailsOverlayChange = new EventEmitter<boolean>();
  @Output() addToBatchClicked = new EventEmitter<any[]>();
  @Output() groupNumberUploadFile = new EventEmitter<any>();
  @Output() indexClicked = new EventEmitter<number>();

  public RenewalsUtil = RenewalsUtil;
  public _checkAllDetailsOverlay: boolean = false;
  public isFileSelected: boolean = false;
  selectedFileName: string = '';
  searchAttempted: boolean = false;
  selectedFTs: any[] = [];
  lockMinDate: Date | undefined;
  lockMaxDate: Date | undefined;

  ngOnInit() {
    if (this.isFileSelected) {
      this.batchSearchForm.get('fundingTypes').setValue(0);
    } else {
      const currentFundingType = this.batchSearchForm.get('fundingTypes').value;
      if (currentFundingType === null || currentFundingType === undefined || currentFundingType === '') {
        const selected = this.availableFTs.find(option =>
          this.getFTSelection(option.label, this.fundTypeFromDetails)
        );
        if (selected) {
          this.batchSearchForm.get('fundingTypes').setValue(selected.value);
        }
      }
    }
    document.body.style.overflow = 'hidden';
    this.isFIselectedDropdown = this.batchSearchForm.get('fundingTypes').value;
    if(this.selectedDatasourceForBatchScreenSearchOverlay != null && this.availableDatasourcesForBatchScreenSearchOverlay != null && this.availableDatasourcesForBatchScreenSearchOverlay.length > 0) {
      this.batchSearchForm.get('dataSource').patchValue(this.selectedDatasourceForBatchScreenSearchOverlay);
    }
    // Auto-populate market segment for existing batch
    if (this.renewalBatchWrapper && this.renewalBatchWrapper.renewalBatchDetails && Array.isArray(this.renewalBatchWrapper.renewalBatchDetails)) {
      const submittedGroups = this.renewalBatchWrapper.renewalBatchDetails;
      const uniqueMarketSegments = Array.from(new Set(submittedGroups
        .map(g => g.marketSegment)
        .filter(seg => !!seg)));
      if (uniqueMarketSegments.length > 0) {
        this.batchSearchForm.get('marketSegments').patchValue(uniqueMarketSegments);
        this.selectedMarketSegs = uniqueMarketSegments;
      }
    }
  }

  ngOnDestroy() {
    document.body.style.overflow = '';
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.checkAllDetailsOverlay) {
      this._checkAllDetailsOverlay = this.checkAllDetailsOverlay;
    }
  }


  addToBatch() {

    const selectedGroups = this.searchResults?.filter(item => item.included);
    if (selectedGroups && selectedGroups.length) {
      this.addToBatchClicked.emit(selectedGroups);

      const batchDetails = (this.renewalBatchWrapper?.renewalBatchDetails || []).map(g => ({
        groupNumber: g.groupNumber ? String(g.groupNumber) : null,
        originalGroupNumber: g.originalGroupNumber ? String(g.originalGroupNumber) : null
      }));

      let deletedGroups: any[] = [];
      try {
        deletedGroups = JSON.parse(localStorage.getItem('deletedGroups') || '[]');
      } catch { }
      const deletedGroupKeys = deletedGroups.map(g => ({
        groupNumber: g.groupNumber ? String(g.groupNumber) : null,
        originalGroupNumber: g.originalGroupNumber ? String(g.originalGroupNumber) : null
      }));
      this.searchResults = this.searchResults.filter(g => {
        const gGroupNumber = g.groupNumber ? String(g.groupNumber) : null;
        const gOriginalGroupNumber = g.originalGroupNumber ? String(g.originalGroupNumber) : null;

        const inBatch = batchDetails.some(bd =>
          (bd.groupNumber && gGroupNumber && bd.groupNumber === gGroupNumber) ||
          (bd.originalGroupNumber && gOriginalGroupNumber && bd.originalGroupNumber === gOriginalGroupNumber)
        );

        const inDeleted = deletedGroupKeys.some(dgk =>
          (dgk.groupNumber && gGroupNumber && dgk.groupNumber === gGroupNumber) ||
          (dgk.originalGroupNumber && gOriginalGroupNumber && dgk.originalGroupNumber === gOriginalGroupNumber)
        );
        return !inBatch && !inDeleted;
      });
    }
    this._checkAllDetailsOverlay = false;
  }

  showMBSField(): boolean {
    if (this.isFIselectedDropdown === CommonConstants.FI) {
      if (this.selectedLOB === CommonConstants.Medical || CommonConstants.SuppHealth) {
        return true;
      }
      if ((this.selectedLOB === CommonConstants.Dental || this.selectedLOB === CommonConstants.Vision) && Array.isArray(this.selectedMarketSegs)) {
        const segs = this.selectedMarketSegs;
        const isLG = segs.includes(CommonConstants.LG);
        // Show only if LG is selected
        return isLG;
      }
    }
    return false;
  }

  deleteSelectedFromSearchResults() {
    let userConfirmation = confirm(RenewalsConstants.DELETE_CONFIRMATION_MSG);
    if (userConfirmation) {
      const deleted = this.searchResults.filter(item => item.included);
      let deletedGroups = [];
      try {
        deletedGroups = JSON.parse(localStorage.getItem('deletedGroups') || '[]');
      } catch { }
      deleted.forEach(g => {
        if (!deletedGroups.some(dg =>
          (dg.groupNumber && g.groupNumber && String(dg.groupNumber) === String(g.groupNumber)) ||
          (dg.originalGroupNumber && g.originalGroupNumber && String(dg.originalGroupNumber) === String(g.originalGroupNumber))
        )) {
          deletedGroups.push({
            groupNumber: g.groupNumber ? String(g.groupNumber) : null,
            originalGroupNumber: g.originalGroupNumber ? String(g.originalGroupNumber) : null
          });
        }
      });
      localStorage.setItem('deletedGroups', JSON.stringify(deletedGroups));
      this.searchResults = this.searchResults.filter(item => !item.included);
    }
  }

  hasSelectedSearchResults(): boolean {
    return Array.isArray(this.searchResults) && this.searchResults.some(item => item.included);
  }

  isAddToBatchDisabled(): boolean {
    return this.showLoader
      || this.searchResults.length === 0
      || !this.searchResults.some((g: any) => g.included)
      || (this.renewalBatchWrapper?.renewalBatch['batchStatus'] == this.submissionStatus.SUBMITTED && !this.isAdminUser)
      || this.isUserReadOnly;
  }

  onHeaderCheckboxChange(event: any) {
    this._checkAllDetailsOverlay = event.checked;
    // Update all rows
    if (this.searchResults) {
      this.searchResults.forEach(item => item.included = this._checkAllDetailsOverlay);
    }
    this.checkAllDetailsOverlayChange.emit(this._checkAllDetailsOverlay);
  }

  onSearchClicked() {
     this._checkAllDetailsOverlay = false;
     localStorage.removeItem('deletedGroups');
     if(!this.showMBSField()) {
      this.batchSearchForm.value.mbs = []
     }
     this.searchClicked.emit();
  }

  showAlertBasedOnConditions(msg: string) {
    return '';
  }

  verifyCheckAllDetails() {
    if (this.searchResults && this.searchResults.length > 0) {
      this.checkAllDetailsOverlay = this.searchResults.every(item => item.included);
    }
  }

  verifyCheckAllDetailsOverlay() {
    this._checkAllDetailsOverlay = this.searchResults.length > 0 && this.searchResults.every((detail) => detail['included']);
    this.checkAllDetailsOverlayChange.emit(this._checkAllDetailsOverlay);
  }

  getToolTipMessgeForPriorNumber(groupDetail: any) { return ''; }
  checkQuoteLinkStatus(groupDetail: any) { return false; }
  openQuote(groupDetail: any) { }
  isGroupHighlighted(groupDetail: any) { return false; }
  checkEmptyRenewalBatchDetails() { return false; }
  disableDeleteOption() { return false; }
  restoreGroups(tab: string) { }
  setIndex(rowIndex: number) { }

  onFileSelected(event: Event) {
    this.batchSearchForm.get('groupName').value = '';
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.isFileSelected = true;
      const selectedFile = input.files[0];
      this.selectedFTs = this.availableFTs;
      this.selectedFileName = selectedFile.name;
      this.groupNumberUploadFile.emit(selectedFile);
    }
    input.value = '';
  }

  resetClickedOnSearch() {
    this.resetClicked.emit();
    this.isFileSelected = false;
    this.searchAttempted = false;
  }

  groupNameAndNumberValidation() {
    this.isFileSelected = false;
    this.availableFTs = this.availableFTs.filter(ft => ft.value !== 0);
    this.grpNameAndNumberValidation();
  }

  getFTSelection(label: string, fundTypeFromDetails: any) {
    if (this.isFileSelected) {
      return;
    } else {
      return this.getFTSelectionFn(label, fundTypeFromDetails);
    }
  }
   isNonMedicalLOB(): boolean {
      if(this.selectedLOB === undefined || this.selectedLOB === null || this.selectedLOB === '' || this.selectedLOB === CommonConstants.Medical) {
        return false;
      }
      else{
        return true;
      }
}

isDatamart(): boolean {
  if(this.availableDatasourcesForBatchScreenSearchOverlay == null || this.availableDatasourcesForBatchScreenSearchOverlay.length == 0){
    return true;
  }
  else{
  return this.batchSearchForm.get('dataSource').value === this.availableDatasourcesForBatchScreenSearchOverlay[0];
  }
}

onRenewalCalendarChange(selectedDates: Date[]) {
  const normalizedDates = Array.isArray(selectedDates)
    ? selectedDates.map(date => (typeof date === 'string' ? new Date(date) : date))
    : [];
  if (normalizedDates.length > 0) {
    const year = normalizedDates[0].getFullYear();
    this.lockMinDate = new Date(year, 0, 1);
    this.lockMaxDate = new Date(year, 11, 31);

    const months = normalizedDates.map(date => {
      const m = date.getMonth() + 1;
      return m < 10 ? '0' + m : '' + m;
    });

    this.selectmonths = months;
    this.selectedRenewalMonthYear = normalizedDates;
    this.batchSearchForm.get('renewalMonths').setValue(months);
    this.batchSearchForm.get('renewalYears').setValue(year);
  } else {
    this.lockMinDate = undefined;
    this.lockMaxDate = undefined;
    this.selectmonths = [];
    this.selectedRenewalMonthYear = null;
    this.batchSearchForm.get('renewalMonths').setValue([]);
    this.batchSearchForm.get('renewalYears').setValue(null);
  }
}
  onRenewalmonth(selectedMonths: any[]) {
  this.selectmonths = selectedMonths;
  if (this.batchSearchForm.get('renewalMonths').value !== selectedMonths) {
    this.batchSearchForm.get('renewalMonths').setValue(selectedMonths, { emitEvent: false });
  }
  let year = new Date().getFullYear();
  if (this.selectedRenewalMonthYear && this.selectedRenewalMonthYear.length > 0) {
    const firstDate = this.selectedRenewalMonthYear[0];
    if (firstDate instanceof Date) {
      year = firstDate.getFullYear();
    }
  }
  this.selectedRenewalMonthYear = (selectedMonths || []).map(m => new Date(year, parseInt(m, 10) - 1, 1));
}
}
