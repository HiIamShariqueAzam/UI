import { DatePipe, formatCurrency, formatPercent, getCurrencySymbol } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, Inject, Input, LOCALE_ID, OnChanges, OnInit, SimpleChanges, ViewChild, booleanAttribute } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { MultiSelect } from 'primeng/multiselect';
import { CommonQuoteService } from 'src/app/quotes/services/common-quote.service';
import { UnderwriterAdjustmentService } from 'src/app/quotes/uw-adjustment/medical/uw-adjustment.service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { StringUtils } from 'src/app/shared/utils/string-utils';


import {
  AlertType,
  RenewalBatchWrapper,
  ConvertBulkStatus,
  QuoteRenewalStatus,
  BATCH_ORIGIN,
  QUOTE_ORIGIN
} from '../../../shared/models/renewal-batch-details';
import { RenewalsConstants } from '../../renewals-constants';
import { RenewalsService } from '../../services/renewals.service';
import { CreateBatchUtil } from '../create-batch/create-batch-util';

@Component({
  selector: 'app-autorun-tab',
  templateUrl: './autorun-tab.component.html',
  styleUrls: ['./autorun-tab.component.css'],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [NgbModalConfig, NgbModal]
})
export class AutorunTabComponent implements OnInit, OnChanges {
  @ViewChild('renwalParentDiv') parentDiv: ElementRef;
  @ViewChild(MultiSelect) multiSelect: MultiSelect;
  checkAllAutoRunDetails: boolean = false;
  autoRunFirst: number = 0;
  lob_FT = [];
  batchStatus: string;
  loader_visible: boolean = false;
  receivedBatchEvents = [];
  alert = {
    show: false,
    message: '',
    type: '',
    cssClass: '',
    header: '',
    headerVisibility: true
  };
  valueChanged = '';
  changedKey = '';
  cmplnFldCodes = [];
  overRideDetails: any;
  isFIBulkAdj: boolean = false;
  @Input() renewalBatchWrapper: RenewalBatchWrapper = {
    renewalBatch: {},
    renewalBatchDetails: [],
    failedGrpNbrsInSearch: []
  };
  @Input() autoRunBatchTableData: any[];
  @Input() isConvert: boolean;
  @Input() isNotConverted: boolean;
  @Input() setMsgForFailedConverts: string;
  @Input() showLoader: boolean;
  onMouseFocus(event) {
    this.multiSelect.show();
    event.stopPropagation();
  }
  sortableColList = ['Release Status', 'UW note to sales', 'Proposed Max Clm Fund Increase'];
  bulkEditColumn = [
    'Proposed Increase',
    'WH Sav %',
    'Proposed Admin Fee Increase',
    'Proposed SSL Increase',
    'Proposed ASL Increase',
    'Proposed TL Increase',
    'UW note to sales'
  ];
  autoRunTableCols = [...RenewalsConstants.AUTORUN_TABLE_COLUMNS_BEFORE];
  expandClicked = false;
  bulkAdjData = [];
  readonly fieldToPercentConvert = new Set([
    'lossRatio',
    'pyLossRatio',
    'blendedIncrease',
    'pyCntrctMaxClmFndLr',
    'cyCntrctMaxClmFndLr',
    'adminFeeIncrease',
    'sslIncrease',
    'aslIncrease',
    'tlIncrease',
    'maxClmFndIncrease',
    'manualOnlySugstdIncrease',
    'clmOnlySugstdIncrease',
    'cyContractSpecificStopLossRatio',
    'pycontractSpecificStopLossRatio',
    'mpcRateAction'
  ]);
  readonly fieldToConcatPrcnt = new Set(['adjustedRateActionPercent', 'renewalWHAPercent', 'asoAdminFee', 'sslPremium', 'aslPremium', 'terminalLiability', 'maxPaidClaim']);
  readonly BATCH_INFO_SMALL_TH: string[] = ['Source System', 'Group Number', 'Market Segment', 'Group Refund', 'Comm Value'];
  readonly editableFieldsMapping = {
    ASL: 'ASL_OVERRIDDEN',
    REFUND_PCT: 'GROUP_REFUND_OVERRIDDEN',
    SSL: 'SSL_OVERRIDDEN'
  };

  isAdminUser: boolean = false;
  isUserReadOnly: boolean = false;
  quoteReason: boolean = false;
  isAutoRunBatch: boolean = false;
  uwSalesNoteIconClicked = false;
  private eventSources: EventSource[] = [];
  // lobFundingTypeMapForSendToOpp = this.commonService.getEnableSendToOppMap();

  constructor(
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private cdRef: ChangeDetectorRef,
    private Ref: ElementRef,
    public datepipe: DatePipe,
    public renewalsService: RenewalsService,
    @Inject(LOCALE_ID) private locale: string,
    private commonQuoteService: CommonQuoteService,
    private uwAdjService: UnderwriterAdjustmentService,
  ) { }
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  batchSearch: any;
  whAdjustmentsDetails: any;
  autoRunQuoteConvertToSave: string = 'This Quote is already converted.';

  ngOnInit() {
    let userRole = this.authenticationService.userRole['_value'];
    this.isAdminUser = CommonUtil.userHasAdminRole(userRole);
    this.isUserReadOnly = this.authenticationService.isUserReadOnly(userRole);
    this.getAutoRunTableCols(); }

  ngOnChanges(changes: SimpleChanges) {
    // Reset paginator to page 1 when data is cleared mid-stream
    if (changes['autoRunBatchTableData']) {
      const current = changes['autoRunBatchTableData'].currentValue;
      if (Array.isArray(current) && current.length === 0) {
        this.autoRunFirst = 0;
      }
    }
  }

  showAutoRun() {
    if (!this.commonService.isAutoRunBatchEnabled) {
      return false;
    }
    return true;
  }

  public get quoteRenewalStatus(): typeof QuoteRenewalStatus {
    return QuoteRenewalStatus;
  }

  public get convertBulkStatus(): typeof ConvertBulkStatus {
    return ConvertBulkStatus;
  }

  isEmptyValue(value: any) {
    return value === null || value === undefined || value === '';
  }

  formatNumbers(value, field) {
    if (this.fieldToPercentConvert.has(field) && (value || value == 0) && !isNaN(value)) return formatPercent(value, this.locale, '1.0-4');

    if (this.fieldToConcatPrcnt.has(field) && !this.isEmptyValue(value) && (value || value == 0) && !isNaN(value))
      return formatPercent(value / 100, this.locale, '1.0-4');

    if (field == 'cyTotalClmsOverSsl' || field == 'cySurplusOrDeficit')
      return value == null ? value : formatCurrency(Math.abs(value), this.locale, getCurrencySymbol('USD', 'wide'));

    return value;
  }

  getToolTipValue(field: string, bulkData: any) {
    if (field == 'cyTotalClmsOverSsl')
      return bulkData['sslDeductable'] ? formatCurrency(bulkData['sslDeductable'], this.locale, getCurrencySymbol('USD', 'wide'), '', '2.0') : '';
    if (field == 'cyCntrctMaxClmFndLr') return bulkData['aggSLCorridor'] ? formatPercent(bulkData['aggSLCorridor'], this.locale, '1.0-4') : '';
    if (field == 'cySurplusOrDeficit') return bulkData['surplusRefund'] ? formatPercent(bulkData['surplusRefund'], this.locale, '1.0-4') : '';
  }

  getClassForValues(field: string, value: number) {
    if (field == 'cyTotalClmsOverSsl' || field == 'cySurplusOrDeficit') {
      return value < 0 ? 'lesser' : '';
    }
  }

  disableRateActionInput(autoRunData: any): boolean {
    return (
      autoRunData['status'] === QuoteRenewalStatus.AWAITING_RISK_SCORE ||
      autoRunData['status'] === QuoteRenewalStatus.AWAITING_P2A_DATA ||
      autoRunData['status'] === QuoteRenewalStatus.RECEIVED ||
      autoRunData['status'] === QuoteRenewalStatus.PROCESSING ||
      autoRunData['status'] === QuoteRenewalStatus.FAIL ||
      autoRunData['adjustmentStatus'] == 'SUBMITTED' ||
      autoRunData['status'] == QuoteRenewalStatus.FAILED_TO_GATEWAY ||
      autoRunData['status'] == QuoteRenewalStatus.SENT_TO_RARE ||
      autoRunData['adjustmentStatus'] == 'QUEUED'
    );
  }

  checkValidNumber(key, value, disabled: boolean) {
    if (disabled) {
      return '';
    }
    if (key === 'renewalWHAPercent') {
      return isNaN(value) && !(value === '' || typeof value == 'undefined') ? 'redContent' : '';
    }
    if (value == '') return 'redContent';
    if (isNaN(value)) return 'redContent';
  }

  getToolTipValueForWholeHealth(col, bulkdata) {
    let whSavingsSpecialty = '';
    if (StringUtils.isEqual(col, CommonConstants.RENEWAL_WHA_PERCENT)) {
      if (StringUtils.isEqual(this.whAdjustmentsDetails?.uwAdjustment?.groupNumber, bulkdata.groupNumber)) {
        Object.keys(this.whAdjustmentsDetails?.whSavingsAdjustment.value).forEach((key) => {
          if (
            this.whAdjustmentsDetails?.whSavingsAdjustment.value[key] &&
            !StringUtils.isUndefined(this.whAdjustmentsDetails?.whSavingsAdjustment.value[key])
          ) {
            whSavingsSpecialty +=
              (StringUtils.isEqual(key, CommonConstants.OTHER) ? this.whAdjustmentsDetails.otherUnitType : key) +
              ' : ' +
              this.uwAdjService.roundValueToFourDecimals(this.whAdjustmentsDetails.whSavingsAdjustment.value[key] * 100) +
              '%' +
              '\n';
          }
        });
      } else if (bulkdata.discountSplits && bulkdata.discountSplits.length > 0) {
        bulkdata.discountSplits.forEach((discountSplit) => {
          if (!StringUtils.isUndefined(discountSplit.value))
            whSavingsSpecialty += discountSplit.id + ' : ' + this.uwAdjService.roundValueToFourDecimals(discountSplit.value * 100) + '%' + '\n';
        });
      }
      return whSavingsSpecialty;
    }
  }

  assignChangedValue(rowData, key) {
    if (this.changedKey == key) {
      rowData[key] = this.valueChanged;
      this.valueChanged = '';
      this.cmplnFldCodes = CreateBatchUtil.setorRevertGuardRailMsg(rowData, this.cmplnFldCodes, this.bulkAdjData);
      this.changedKey = '';
    }
  }

  setbgColor(header: string, bulkdata: any) {
    if (header == 'Release Status' && ['Success', 'Failed'].includes(bulkdata.releaseStatus)) {
      if (bulkdata.releaseProcessErrors) {
        return 'bg-alert-danger';
      } else {
        return 'bg-alert-success';
      }
    }
    return '';
  }

  autoRunTableExpand() {
    this.expandClicked = !this.expandClicked;
    if (this.expandClicked) {
      this.autoRunTableCols.push(...RenewalsConstants.BULK_TABLE_COLUMNS_AFTER);
    } else {
      this.autoRunTableCols = [...RenewalsConstants.AUTORUN_TABLE_COLUMNS_BEFORE];
    }
  }

  getAutoRunTableCols() {
    if (this.autoRunBatchTableData.length > 0) {
      this.isFIBulkAdj = StringUtils.isEqual(this.autoRunBatchTableData[0].fundingType, CommonConstants.FI);
      this.autoRunTableCols = StringUtils.isEqual(this.autoRunBatchTableData[0].fundingType, CommonConstants.FI)
        ? RenewalsConstants.FI_AUTORUN_TABLE_COLUMNS
        : (this.autoRunTableCols = [...RenewalsConstants.AUTORUN_TABLE_COLUMNS_BEFORE]);
    }
    this.autoRunTableCols = this.autoRunTableCols.filter((col) => col.field !== 'Release Status');
  }

  getToolTipHeaderValue() {
    return this.isFIBulkAdj ? 'Incurred' : 'Paid';
  }

  checkAutoRunDetails(event) {
    this.autoRunBatchTableData.forEach((renewal) => {
      (renewal['included'] as boolean) = event.checked as boolean;
    });
  }

  trackByFunction = (_index: number, item: any): string => {
    // Stable key independent of index — matches the canonical row identity used in the parent
    // component's autoRunDetailsMap (groupNumber + opportunityID + quoteHeaderID + ratingTransID)
    return `${item.groupNumber}_${item.opportunityID}_${item.quoteHeaderID}_${item.ratingTransID}`;
  };

  openQuote(groupDetail: any) {
    this.lob_FT = [];
    const dashboardSubmissionStatus = this.renewalBatchWrapper.renewalBatch['dashboardSubmissionStatus'];
    this.commonService.logUserOpeningQuoteEvent(
      groupDetail['ratingTransID'],
      groupDetail['opportunityID'],
      groupDetail['quoteHeaderID'],
      groupDetail['lob'],
      groupDetail['fundingType'],
      groupDetail['marketSegment'],
      groupDetail['batchOrigin'],
      'Renewal-Batch'
    );
    this.commonQuoteService.getOpportunitesByOppID(groupDetail['opportunityID'], groupDetail['lob']).subscribe(
      (response) => {
        if (response != null) {
          for (var opp of response.opportunities) {
            if (opp && opp.quoteHeaderID === groupDetail['quoteHeaderID']) {
              let data =
                opp.lob == 'Medical' && opp.opportunityType == 'Renewal Local' && (opp.quotingType == 'ACA' || opp.quotingType == CommonConstants.MEWA)
                  ? opp.lob + '-' + opp.quotingType
                  : opp.lob + '-' + opp.fundingType;
              if (!this.lob_FT.find((x) => x === data)) {
                this.lob_FT.push(data);
              }
            }
          }
          this.lob_FT = this.lob_FT.sort(function (a, b) {
            return a > b ? 1 : a < b ? -1 : 0;
          });
          let quote;
          if (response.opportunities)
            quote = response.opportunities.find(
              (data) =>
                data.opportunityID == groupDetail['opportunityID'] &&
                data.quoteHeaderID == groupDetail['quoteHeaderID'] &&
                data.lob == groupDetail['lob'] &&
                data.fundingType == (groupDetail['fundingType'] == CommonConstants.MEWA ? CommonConstants.ASO : groupDetail['fundingType']) &&
                (!data.quotingType || data.quotingType === 'POOL' || data.quotingType === CommonConstants.MEWA)
            );
          if (quote && quote['ratingTransID']) {
            const pathToNavigate = this.identifyUWPath(groupDetail['lob']);
            const url = this.router.serializeUrl(
              this.router.createUrlTree([pathToNavigate], {
                queryParams: {
                  quoteHeaderID: groupDetail['quoteHeaderID'],
                  batchID: groupDetail['batchID'],
                  opportunityID: groupDetail['opportunityID'],
                  ratingTransID: groupDetail['ratingTransID'],
                  lob: groupDetail['lob'],
                  fundingType: groupDetail['fundingType'],
                  availableTabs: this.lob_FT,
                  insertedTimestamp: groupDetail['insertedTimestamp'],
                  quoteOrigin: groupDetail['batchOrigin'],
                  marketSegment: groupDetail['marketSegment'],
                  isLoginAgain: true,
                  disableAll: false
                }
              })
            );
            if (/Edge/.test(navigator.userAgent)) {
              if (localStorage.getItem('isLoginAgain')) this.commonService.removeHistoryLocalStorage();
            }
            localStorage.setItem('quoteHeaderID', groupDetail['quoteHeaderID']);
            localStorage.setItem('opportunityID', groupDetail['opportunityID']);
            localStorage.setItem('ratingTransID', groupDetail['ratingTransID']);
            localStorage.setItem('lob', groupDetail['lob']);
            localStorage.setItem('batchID', groupDetail['batchID']);
            localStorage.setItem('dashboardSubmissionStatus', dashboardSubmissionStatus);
            localStorage.setItem('fundingType', groupDetail['fundingType']);
            localStorage.setItem('quoteOrigin', groupDetail['batchOrigin']);
            localStorage.setItem('insertedTimestamp', groupDetail['insertedTimestamp']);
            localStorage.setItem('availableTabs', this.lob_FT.map((x) => x).join(','));
            localStorage.setItem('isLoginAgain', 'true');
            localStorage.setItem('assignedUserRoles', this.authenticationService.getUserRole());
            localStorage.setItem('assignedUserRolesTextToDisplay', this.authenticationService.getUserRoleTextToDisplay());
            localStorage.setItem('assignedUserLobs', this.authenticationService.getUserLob());
            localStorage.setItem('assignedUserStates', this.authenticationService.getUserState());
            localStorage.setItem('marketSegment', groupDetail['marketSegment']);
            localStorage.setItem('disableAll', 'false');
            window.open(url, '_blank');
          } else {
            alert("Quote Details doesn't exist");
          }
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }

  private identifyUWPath(lob: string): string {
    var path = '';
    switch (lob) {
      case 'Medical':
        path = '/quote/uw-rate';
        break;
      case 'Vision':
        path = '/quote/uw-rate-vision';
        break;
      case 'Dental':
        path = '/quote/uw-rate-dental';
        break;
      case CommonConstants.SuppHealth:
        path = '/quote/uw-rate-supplemental-health';
        break;
      default:
        break;
    }
    return path;
  }

  checkEmptyAutoRunTableData() {
    let checkAllDetails = this.autoRunBatchTableData.filter((renewal) => renewal['included']);
    return !checkAllDetails.length;
  }

  ngOnDestroy() {
    // Close all EventSource instances
    this.eventSources.forEach((source) => source.close());
  }

  setAlertVisibility(visibility: boolean, type = '', message: string = '', headervisibility?: boolean) {
    window.scroll(0, 0);
    this.alert.show = visibility;
    this.alert.type = type || '';
    this.alert.message = message;
    this.alert.cssClass = type === AlertType.ERROR ? 'alert-danger' : `alert-${type}`;
    this.alert.header = type === AlertType.ERROR ? 'failed' : type;
    if (headervisibility != undefined) {
      this.alert.headerVisibility = headervisibility;
    }
    this.cdRef.markForCheck();
  }

  setLoaderVisibility(visibility: boolean) {
    window.scroll(0, 0);
    this.loader_visible = visibility;
    this.cdRef.markForCheck();
  }

  removeAlertMsg() {
    this.alert = {
      show: false,
      message: '',
      type: '',
      cssClass: '',
      header: '',
      headerVisibility: true
    };
    this.cdRef.markForCheck();
  }

  goToBatchSearch(): void {
    this.router.navigate(['/group/batch']);
  }

  addItemToLocalStorage(key, value) {
    const idExist = JSON.parse(localStorage.getItem(key) || '[]');
    if (!idExist.includes(value)) {
      idExist.push(value);
      localStorage.setItem(key, JSON.stringify(idExist));
    }
  }

  verifyAllAutoRunDataDetails() {
    this.checkAllAutoRunDetails = this.autoRunBatchTableData.filter((detail) => !detail['included']).length <= 0;
  }

  getQuoteOrigin() {
    this.route.queryParams.subscribe((params) => {
      return params[CommonConstants.QUOTE_ORIGIN];
    });
  }

  hideProgressBar() {
    setTimeout(() => {
      this.showProgress = false;
      this.cdRef.markForCheck();
    }, this.commonService.getProgressBarTimeOut());
  }

  checkAutoRunGroup(autoRunData) {
    return ((autoRunData['quoteOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH && autoRunData['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH) || ((autoRunData['quoteOrigin'] !== QUOTE_ORIGIN.CONVERTED_AUTO_RUN && autoRunData['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH) && (autoRunData['quoteOrigin'] !== 'userBatch' && autoRunData['batchOrigin'] === BATCH_ORIGIN.AUTO_RUN_BATCH)));
  }

  checkAutorunConvertStatus(autoRunData) {
    return (autoRunData['quoteOrigin'] === QUOTE_ORIGIN.CONVERTED_AUTO_RUN || autoRunData['latestAutoRunConverted'] || autoRunData['isAutoRunConvertTaskDone']);
  }

  disableQuoteStatus(autoRunData) {
    return (!autoRunData['status'] || autoRunData['status'] === this.quoteRenewalStatus.AWAITING_RISK_SCORE || autoRunData['status'] === this.quoteRenewalStatus.AWAITING_P2A_DATA || autoRunData['status'] === this.quoteRenewalStatus.RECEIVED ||
    autoRunData['status'] === this.quoteRenewalStatus.FAILED_TO_GATEWAY || autoRunData['status'] === this.quoteRenewalStatus.SENT_TO_RARE)
  }

  isAutoRunBatchEnabled() {
    return this.commonService.isAutoRunBatchEnabled;
  }

  isDummyEvent(payload: any) {
    return payload && payload.dummyEvent && payload.dummyEvent == 'true';
  }
  

  hideAlertVisibility() {
    setTimeout(() => {
      this.setAlertVisibility(false);
      this.cdRef.markForCheck();
    }, this.commonService.getProgressBarTimeOut());
  }
  
}
