import { Component, OnInit } from '@angular/core';
import { CommonUtil } from 'src/app/shared/utils/common-util';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { RenewalsService } from '../services/renewals.service';

@Component({
  selector: "app-group",
  templateUrl: "./group.component.html",
  styleUrls: ["./group.component.css"],
  standalone: false,
})
export class GroupComponent implements OnInit {
  opportunityId: string;
  quoteHeaderId: string;
  system: string;
  groupNumber: string;
  status: string;
  errorMsg: string;
  showErrorMsg: boolean;
  successMsg: string;
  showSuccessMsg: boolean;
  showTable: boolean = false;
  showProcessingTxt: boolean = false;
  isAdminUser: boolean = false;

  constructor(
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    public renewalsService: RenewalsService
  ) {}

  ngOnInit() {
    this.isAdminUser = CommonUtil.userHasAdminRole(
      this.authenticationService.userRole["_value"]
    );
  }

  onSubmit(data) {
    this.showTable = false;
    this.showProcessingTxt = true;
    this.showErrorMsg = false;
    this.showSuccessMsg = false;
    this.clearTableData();
    if (data.WGCnumber) {
      this.renewalsService
        .getRenewals(data.WGCnumber, data.isTestQuote ? "TEST" : "REAL")
        .subscribe(
          (result) => {
            this.groupNumber = result.groupNbr;
            this.showProcessingTxt = false;
            this.showTable = true;
            this.opportunityId = result.opportunityID;
            this.quoteHeaderId = result.quoteHeaderID;
            var status = result.status.code;
            this.status = status;
            if (status.toUpperCase() == "SUCCESS") {
              this.successMsg = "Success!! " + result.status.msg;
              this.showSuccessMsg = true;
            } else {
              this.errorMsg = result.status.msg;
              this.showErrorMsg = true;
              this.opportunityId = "NA";
              this.quoteHeaderId = "NA";
              this.system = "NA";
            }
            if (result.response && result.response.data) {
              var system = result.response.data.systemResponses[0].sourceSystem;
              this.system = system;
            }
          },
          (errorResponse) => {
            this.showProcessingTxt = false;
            console.log(errorResponse);
            this.errorMsg =
              errorResponse.error.exceptions.exceptions[0].message;
            this.showErrorMsg = true;
            this.opportunityId = "NA";
            this.quoteHeaderId = "NA";
            this.system = "NA";
          }
        );
    } else {
      this.showProcessingTxt = false;
      this.errorMsg = "WGS Group Number must not be empty.";
      this.showErrorMsg = true;
    }
  }

  clearTableData() {
    this.opportunityId = "";
    this.quoteHeaderId = "";
    this.system = "";
    this.groupNumber = "";
    this.status = "";
  }

  hasReadOnly() {
    return this.commonService.hasReadOnlyRole();
  }
}
