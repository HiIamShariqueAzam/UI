import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService, CommonService } from 'src/app/shared/services';

@Component({
  selector: 'app-files',
  templateUrl: './files.component.html',
  styleUrls: ['./files.component.scss'],
  standalone: false,
})
export class FilesComponent implements OnInit {

  files: any = [];
  folders: any = []
  changeText: {};
  changeIcon: {};
  assignedUserRoles: any;
  arr = [];
  userRole: any;
  isClicked: boolean = false;
  subFolders = [];
  isLoading: boolean = false;
  fileStructure: any = [];
  isSearch:boolean=false;
  checks:boolean;
  searchText:string ="";
  folderPath:any;
  checkboxHide:boolean=true;
  sortDir = -1;
  constructor(private http: HttpClient, private commonService: CommonService, private authenticationService: AuthenticationService,) {}

  ngOnInit() {
    this.fetchFiles();
  }

  // for searching folders and files //
  searchFile() {
    let val = this.searchText.toLowerCase();
    let files= this.files.filter(x=> x.fileName.toLowerCase().includes(val))
    let folders= this.folders.filter(x=> x.folderName.toLowerCase().includes(val));
    this.fileStructure = []
    this.fileStructure.push({ 'files': files });
    this.fileStructure.push({ 'folders': folders });
    if((folders && folders.length == 0) && (files && files.length == 0)) {
      this.isSearch =true;
    } else {
      this.isSearch = false;
    }
  }

  delete(index) {
    this.files.splice(index, 1);
  }

  selectingCheckbox(file, isChecked: any) {
    if (isChecked) {
      this.arr.push(file.fileName);
    }
    else if (!isChecked) {
      const index = this.arr.indexOf(file.fileName);
      if (index > -1) {
        this.arr.splice(index,1);
      }
    }
    if (this.arr.length > 0) {
      this.isClicked = true;
    } else {
      this.isClicked = false;
    }
  }

  bulk(e){
    if(e.target.checked==true){
      this.checks=true;
      this.files.forEach(file=>{
        this.arr.push(file);
        })
    }else{
      this.arr.length=0;
      this.checks=false;
      this.isClicked = false;
    }
  }

//loading data in page //
  fetchFiles() {
    this.fileStructure = [];
    this.files = [];
    this.folders = [];
    this.commonService.getFiles(this.currentPath).subscribe((result: any) => {
      if (result) {
        this.isLoading = true;
      }
      this.currentPath = result.currentPath;
      this.files = result.files || [];
      this.folders = result.folders || [];
      this. removingSameFolder();
      this.fileStructure.push({ 'files': this.files });
      this.fileStructure.push({ 'folders': this.folders });
      this.sortArrFoldersLastmodified('lastModified');
      this.sortArrFilesLastmodified('lastModified');
      this.searchFile()
    })
  }

  // accessing breadcrub  //
  breadcrumb1 = ['data']
  openingFolder(folderName) {
    this. folderPath =folderName
    this.fileStructure = [];
    this.files = [];
    this.folders = [];
    if (!this.breadcrumb1.find(x => x == folderName)) {
      this.breadcrumb1.push(folderName)
    }
    this.breadcrumb1.filter(e => e != 'data').forEach(ele => {
      if(!this.currentPath.split('/').includes(ele)){
        this.currentPath = this.currentPath + '/' + ele;
      }
    })
    this.commonService.getFiles(this.currentPath).subscribe((result: any) => {
      this.currentPath = result.currentPath
      this.files = result.files || [];
      this.folders = result.folders || [];
      this. removingSameFolder();
      this.fileStructure.push({ 'files': this.files });
      this.fileStructure.push({ 'folders': this.folders });
      this.sortArrFoldersLastmodified('lastModified');
      this.sortArrFilesLastmodified('lastModified');
      this.searchFile()
    })
  }
 removingSameFolder(){
  var curPath = this.currentPath.split('/');
  var ind = curPath.length - 1;
  for (var i = 0; i < this.folders.length; i++) {
    if (curPath[ind] == this.folders[i].folderName) {
      this.folders.splice(i, 1);
    }
  }
 }
  currentPath: any = '/data';
  onBreadcrumbClick(b) {
    this.checks=false;
    this.isClicked =false;
    this.arr.length=0;
    let ind = this.breadcrumb1.findIndex(x => x == b);
    this.breadcrumb1.length = ind + 1;
    let url : any;
    url = this.breadcrumb1.toString();
    url = url.replaceAll(",","/")
    this.currentPath = '/data';
    if (b == 'data') {
      this.fetchFiles();
    } else {
      this.currentPath = '';
      this.currentPath = this.currentPath+ '/'+url
      this.fetchFiles();
    }
  }


  hasReadOnly(){
    let str: any;
    str = this.authenticationService.getUserRole();
    if (str.includes('READONLY')) {
      return true
    } else {
      return false;
    }
  }

// to download all button //
  downloadAll() {
     let foldername;
     foldername = this.breadcrumb1[this.breadcrumb1.length-1]
     this.commonService.getDownloadAllAsZip(this.currentPath).subscribe((result: any) => {
     this.DownloadFile(result,foldername,'application/zip');

    })
  }

 // to download selected  button //
  downloadSelected(){
    let foldername;
     foldername = this.breadcrumb1[this.breadcrumb1.length-1]
    this.commonService.downloadSelectedFiles(this.currentPath,this.arr).subscribe((result: any) => {
      this.DownloadFile(result,foldername,'application/zip');
    })
  }

  // to download selected files from icon //
  openingFile(fileName){
    return this.commonService.fileDownload(this.currentPath, fileName).subscribe((result:any)=>{
      this.DownloadFile(result,fileName,fileName.includes('.zip') ? 'application/zip': 'text/plain');
    })
  }

// to folders and files saving //
  DownloadFile(body, filename,filetype) {
    const blob = new Blob([body],{type:filetype});
    if (navigator.msSaveBlob) {
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement("a");
     if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

// to download particular folder from icon //
  downloadFolder(folderName){
    return this.commonService.folderDownload(this.currentPath+'/'+folderName).subscribe((result:any)=>{
      this.DownloadFile(result, folderName,'application/zip');

    })
  }

  // on sorting of files and lastmodifed time //
  onSorting(event) {
    let target = event.currentTarget,
      classList = target.classList;

    if (classList.contains('fa-chevron-up')) {
      classList.remove('fa-chevron-up');
      classList.add('fa-chevron-down');
      this.sortDir=1;
    } else {
      classList.add('fa-chevron-up');
      classList.remove('fa-chevron-down');
      this.sortDir=-1;
    }
    this.sortArrFolders('folderName');
    this.sortArrFoldersLastmodified('lastModified');
    this.sortArrFiles('fileName');
    this.sortArrFilesLastmodified('lastModified');
  }

  sortArrFolders(folderName:any){
    this.folders.sort((a,b)=>{
      a= a[folderName].toLowerCase();
      b= b[folderName].toLowerCase();
      return a.localeCompare(b) * this.sortDir;
    });
  }

  sortArrFiles(fileName:any){
    this.files.sort((a,b)=>{
      a= a[fileName].toLowerCase();
      b= b[fileName].toLowerCase();
      return a.localeCompare(b) * this.sortDir;
    });
  }

  sortArrFoldersLastmodified(lastModified:any){
    this.folders.sort((a,b)=>{
      a= a[lastModified].toLowerCase();
      b= b[lastModified].toLowerCase();
      return a.localeCompare(b) * this.sortDir;
    });
  }

  sortArrFilesLastmodified(lastModified:any){
    this.files.sort((a,b)=>{
      a= a[lastModified].toLowerCase();
      b= b[lastModified].toLowerCase();
      return a.localeCompare(b) * this.sortDir;
    });
  }


}
