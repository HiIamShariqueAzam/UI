import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FilesComponent} from './files.component';
import { RouterModule } from '@angular/router';
import {FormsModule} from '@angular/forms'
import { ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MultiSelectModule } from 'primeng/multiselect';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [FilesComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ProgressSpinnerModule,
    ButtonModule,
    MultiSelectModule,
    RouterModule.forChild([
      { path: '', component: FilesComponent, pathMatch: 'full' },
    ])
  ],
})
export class FilesModule { }
