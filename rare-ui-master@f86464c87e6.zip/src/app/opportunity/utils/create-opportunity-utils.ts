export class CreateOpportunityUtils {
  public static buildOpportunityData(opportunityData: any, opportunityDataForm: any): any {
    return opportunityData;
  }
}
