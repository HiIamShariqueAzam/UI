
export class CreateOpportunityUtil {

    public static setMarketSegmentInfo(getOppQuoteDetails, marketSegInformation, planDetails, chamber, virGrpQte) {
        if (getOppQuoteDetails.medical && getOppQuoteDetails.medical.participationRate && getOppQuoteDetails.medical.participationRate.length > 0) {
            const pRate = getOppQuoteDetails.medical.participationRate.find(rate => rate.type == 'WholeCase');
            if (pRate && !isNaN(pRate.value)) {
                marketSegInformation.controls.participationName.setValue((this.precisionRound(parseFloat(pRate.value) * 100, 13)).toString());
            }
        } else {
            marketSegInformation.controls.participationName.setValue('');
        }
        if (getOppQuoteDetails.userSelectedChamberOfCommerce) {
            marketSegInformation.controls.chamberName.setValue({
                chamberName: getOppQuoteDetails.userSelectedChamberOfCommerce.toLowerCase() == "true" ? "Yes" : "No"
            });
        } else {
            if (planDetails.chamberOfCommerce) {
                marketSegInformation.controls.chamberName.setValue({
                    chamberName: planDetails.chamberOfCommerce.toLowerCase() == "true" ? "Yes" : "No"
                });
            } else {
                marketSegInformation.controls.chamberName.setValue(chamber[0]);
            }
        }
        if (getOppQuoteDetails.virginGroup) {
            marketSegInformation.controls.virGrpQteName.setValue({ virGrpQteName: getOppQuoteDetails.virginGroup });
        } else {
            marketSegInformation.controls.virGrpQteName.setValue(virGrpQte[0]);
        }
        if (getOppQuoteDetails.quoteName) {
            marketSegInformation.controls.quoteName.setValue(getOppQuoteDetails.quoteName);
        } else {
            marketSegInformation.controls.quoteName.setValue("");
        }

        if (getOppQuoteDetails.medical && getOppQuoteDetails.medical.employerFundingLevel) {
            marketSegInformation.controls.empFundLevelName.setValue(
                (this.precisionRound(parseFloat(getOppQuoteDetails.medical.employerFundingLevel) * 100, 13)).toString());
        } else {
            marketSegInformation.controls.empFundLevelName.setValue("");
        }
        return marketSegInformation;
    }

    public static precisionRound(number, precision) {
        var factor = Math.pow(10, precision);
        return Math.round(number * factor) / factor;
    }

    public static setCommissionInfo(getOppQuoteDetails, commissionInformation, planDetails, fundingType) {
        if (getOppQuoteDetails.userSelectedFundingType) {
            commissionInformation.controls.ftFrmCtrlName.setValue({ fundingTypeName: getOppQuoteDetails.userSelectedFundingType });
            if (getOppQuoteDetails.userSelectedFundingType.includes("FI")) {
                commissionInformation.controls.fiCommFrmCtrlName.setValue(getOppQuoteDetails.userSelectedFIComissionValue);
                commissionInformation.controls.fiCommValFrmCtrlName.setValue(
                    { fiCommissionName: getOppQuoteDetails.userSelectedFIComissionType });
            }
        } else {
            if (planDetails.fundingType) {
                commissionInformation.controls.ftFrmCtrlName.setValue({ fundingTypeName: planDetails.fundingType });
                if (planDetails.fundingType.includes("FI")) {
                    commissionInformation.controls.fiCommFrmCtrlName.setValue(planDetails.commissionValue);
                    commissionInformation.controls.fiCommValFrmCtrlName.setValue(
                        { fiCommissionName: planDetails.commissionType });
                }
            } else {
                commissionInformation.controls.ftFrmCtrlName.setValue(fundingType[0]);
            }
        }
        commissionInformation.controls.abfCommFrmCtrlName.setValue(getOppQuoteDetails.medical.abfCommissionValue);
        commissionInformation.controls.abfCommValFrmCtrlName.setValue({ abfCommissionType: getOppQuoteDetails.medical.abfCommissionType });
        return commissionInformation;
    }

    public static hasErrors(commissionInformation, isSelectedFI, isSelectedABF, groupInformation, marketSegInformation): boolean {
      let hasFiCommissionError = false;
      let hasABFCommissionError = false;
      if (!commissionInformation.valid) {
        if (isSelectedFI) {
          hasFiCommissionError = commissionInformation.controls.fiCommValFrmCtrlName.invalid ||
            commissionInformation.controls.fiCommFrmCtrlName.invalid;
        }
        if (isSelectedABF) {
          hasABFCommissionError = commissionInformation.controls.abfCommValFrmCtrlName.invalid ||
          commissionInformation.controls.abfCommFrmCtrlName.invalid ||
          commissionInformation.controls.srFrmCtrlName.invalid ||
          commissionInformation.controls.aslFrmCtrlName.invalid ||
          commissionInformation.controls.sslFrmCtrlName.invalid ||
          commissionInformation.controls.cpFrmCtrlName.invalid;
        }
      }
      let returnValue =
        !(hasFiCommissionError || hasABFCommissionError) &&
        groupInformation.valid &&
        marketSegInformation.valid;
      return !returnValue;
    }
}