import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CreateOpportunityService } from '../services/create-opportunity-service';
import { CommonService, CacheService, AuthenticationService } from 'src/app/shared/services';
import { UserService } from 'src/app/shared/services/user.service';
import { forkJoin, Subject } from 'rxjs';
import { map, switchMap, take, takeUntil } from 'rxjs/operators';
import { CreateOppQueryParams } from './constants/create-opportunity.constants';

@Component({
  selector: 'app-create-opportunity-new',
  templateUrl: 'create-opportunity-new.component.html',
  styleUrls: ['./create-opportunity-new.component.css'],
  standalone: false,
})
export class CreateOpportunityNewComponent implements OnInit, OnDestroy {
  schema: any;
  data: any[] = [];
  isNewForm: boolean = false;
  newFormData: any[] = [];
  destroy$: Subject<void> = new Subject();
  opportunityID: any;
  quoteHeaderId: any;
  isHistoryQuoteData: boolean = false;

  createOpportunityService = inject(CreateOpportunityService);
  router = inject(Router);
  route = inject(ActivatedRoute);

  ngOnInit(): void {
    this.getData();
  }

  getData() {
    let dataApis$ = [this.createOpportunityService.getSchema(), this.createOpportunityService.getNewFormData()];

    this.route.queryParams
      .pipe(
        take(1),
        takeUntil(this.destroy$),
        switchMap((params) => {
          const opportunityID = params[CreateOppQueryParams.OpportunityId] ?? '';
          if (
            params[CreateOppQueryParams.OpportunityId] &&
            params[CreateOppQueryParams.QuoteId] &&
            params[CreateOppQueryParams.QuoteHistoryId] &&
            params[CreateOppQueryParams.FundingType]
          ) {
            this.opportunityID = params[CreateOppQueryParams.OpportunityId];
            this.quoteHeaderId = params[CreateOppQueryParams.QuoteId];
            this.isHistoryQuoteData = true;
            dataApis$.push(
              this.createOpportunityService.getUnifiedQuoteDetails(
                this.opportunityID,
                this.quoteHeaderId,
                params[CreateOppQueryParams.QuoteHistoryId],
                params[CreateOppQueryParams.FundingType],
                params[CreateOppQueryParams.MarketSegment],
                params[CreateOppQueryParams.Lob]
              )
            );
            return forkJoin(dataApis$);
          } else if (params && opportunityID) {
            this.opportunityID = opportunityID;
            dataApis$.push(this.getOpportunities(this.opportunityID));
            return forkJoin(dataApis$);
          } else {
            this.isNewForm = true; // New form since no opportunityID or oppId is present
            return forkJoin(dataApis$);
          }
        })
      )
      .subscribe((response) => {
        this.schema = response[0];
        this.newFormData = response[1];
        if (this.isHistoryQuoteData) {
          this.data = [response[2]]; // Set response[2] in an array if isHistoryQuoteData is true
        } else {
           this.data = this.isNewForm ? [structuredClone(this.newFormData['medical'])] : response[2];
        }
        this.data = this.normalizeChamberOfCommerceValuesPerUnified(this.data);
      });
  }

  normalizeChamberOfCommerceValuesPerUnified(data: any[]) {
    data.forEach((item) => {
      if (item?.data?.unifiedPayload?.data?.medical?.proposedPlans) {
        item.data.unifiedPayload.data.medical.proposedPlans.forEach((plan: any) => {
          plan.chamberOfCommerce = String(plan.chamberOfCommerce).toLowerCase() === 'true' ? 'True' : 'False';
        });
      }
    });
    return data;
  }

  getOpportunities(opportunityID: string) {
    return this.createOpportunityService.getOpportunities(opportunityID).pipe(map((d) => d.filter((e) => e.data.isCurrent)));
  }

  back() {
    this.router.navigate(['/opportunity']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }


  // Comment this line before committing. This helps in continuous reloads during development
  // //  Will be removed once Create opp development is done
  // constructor(
  //   private commonService: CommonService,
  //   private cacheService: CacheService,
  //   private userService: UserService,
  //   private authService: AuthenticationService
  // ) {
  //   this.cacheService.setRareUIUrl('https://rare-ui.uw.dev2.elevancehealth.com/api/rare/v1');
  //   this.commonService.setRareUIUrl('https://rare-ui.uw.dev2.elevancehealth.com/api/rare/v1');
  //   this.commonService.setQuoteOptionStatesMap(["CO"])
  //   this.userService.setUserGlobalData(['RARE_ADMIN', 'RARE_MODIFY_OPP'].join(), true);
  //   this.commonService.setRareSpecialitySendToOppEnabled(true);
  //   this.commonService.setMEWAOriginalQuoteEnabled(true);
  //   this.commonService.setExperienceExtractionEnabled(true)
  //   this.commonService.setCrossSellingRestrictionMap({
  //     LG_ABF: { CO: ['12-31-2025'], CA: ['12-31-9999'] },
  //     LG_FI: { CO: ['12-31-2025'], CA: ['12-31-9999'] },
  //     SG_ABF: { NH: ['12-31-9999'] },
  //     SG_FI: { NH: ['12-31-9999'] }
  //   });
  //   this.commonService.setMedicareStateMarkerMap({
  //       'SG_MEWA_Renewal Local': [
  //           'OH'
  //       ],
  //       'SG_MEWA_New Business Local': [
  //           'OH'
  //       ]
  //   });
  //   this.commonService.setOppSpecialityPlanUpdateConfig({
  //     vision: {
  //       'SG_FI_New Business Local': ['CA', 'CO', 'CT', 'GA', 'IN', 'KY', 'ME', 'MO', 'NH', 'NV', 'NH', 'NV', 'OH', 'VA', 'WI', 'NY'],
  //       'LG_FI_Renewal Local': ['CA', 'CO', 'CT', 'GA', 'IN', 'KY', 'ME', 'MO', 'NH', 'NV', 'NH', 'NV', 'OH', 'VA', 'WI', 'NY'],
  //       'SG_FI_Renewal Local': ['CA', 'CO', 'CT', 'GA', 'IN', 'KY', 'ME', 'MO', 'NH', 'NV', 'NH', 'NV', 'OH', 'VA', 'WI', 'NY'],
  //       'LG_FI_New Business Local': ['CA', 'CO', 'CT', 'GA', 'IN', 'KY', 'ME', 'MO', 'NH', 'NV', 'NH', 'NV', 'OH', 'VA', 'WI', 'NY']
  //     },
  //     dental: {
  //       'SG_FI_New Business Local': ['CA', 'CO', 'CT', 'GA', 'IN', 'KY', 'ME', 'MO', 'NH', 'NV', 'NH', 'NV', 'OH', 'VA', 'WI', 'NY'],
  //       'LG_FI_Renewal Local': ['CA', 'CO', 'CT', 'GA', 'IN', 'KY', 'ME', 'MO', 'NH', 'NV', 'NH', 'NV', 'OH', 'VA', 'WI', 'NY'],
  //       'SG_FI_Renewal Local': ['CA', 'CO', 'CT', 'GA', 'IN', 'KY', 'ME', 'MO', 'NH', 'NV', 'NH', 'NV', 'OH', 'VA', 'WI', 'NY']
  //     },
  //     suppHealth: {}
  //   });
  //   this.authService.changeUserID('');
  //   this.authService.changeUserName('');
  // }
}
