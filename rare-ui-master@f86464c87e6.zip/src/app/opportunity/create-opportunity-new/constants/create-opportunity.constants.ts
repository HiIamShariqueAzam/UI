export enum CreateOppScreenMessages {
  GenericFormError = 'Please fill in all the mandatory fields with correct validity.',
  StopLossCoverageEmptyABF = 'Looks like there is no SSL Values available for the Market Segment and date combinations selected, you will not be able to create ABF Quote with this. ',
  NonPlansSelected = 'Please select the plans you want to submit for this Quote.',
  NoSupportContractCodes = `You have plans selected which are not supported for {fundingType} Funding Type. Do remove them before proceeding!`,
  EmptyCensus = 'Please enter / fix the Census information you want to submit for this Quote.',
  EmptySummaryCensus = 'Please enter / fix the Summary Census Information',
  InvalidCurrentCarrier = 'Please verify all the Current Carrier Plan information and ensure the mandatory fields are entered.',
  InvalidSalesAndBroker = 'Please verify all the Sales Broker information and ensure the mandatory fields are entered.',
  QuoteInfoInvalidPercent = 'Please enter valid Percentage in Quote information',
  InvalidFundingCommisionValue = 'Please enter {fundingType} Commision information under Funding Information',
  QuoteDeleteWarning = 'Are you sure you want to Delete this Quote? Any updates made so far will be lost.',
  LastQuoteDeleteWarning = 'Are you sure you want to Delete this Quote? The opportunity will be permanently deleted. Is this ok?',
  FundingTypeAlreadyExistForQuote = '{fundingType} Funding Type already exists for the quote.',
  CurrentPlanMapWarning = 'Please map current plans to feature plans before submitting.',
  FeaturePlanMapWarning = 'Please map feature plans to current plans before submitting.',
  NoChangesWarning = 'No changes to save.',
  InvalidMarketSegmentFundingTypeCombination = '{marketSegment} Market Segment with {fundingType} Funding Type is not support for {state} State.',
  CrossSellingAlert = 'The quote will be submitted with the equivalent {marketSegment} plan mapped with current plans',
  RateGuarMonthsError = 'Rate Guarantee Effective date should be before or equal to Rate Guarantee End date.'
}

export enum Sections {
  QuoteTable = 'quotesSection',
  GroupInfo = 'groupInfo',
  QuoteInfo = 'quoteInfo',
  FundingInfo = 'fundingInfo',
  CurrentCarrier = 'currentCarrier',
  Plan = 'plan',
  Census = 'censusInfo',
  SalesAndBroker = 'salesAndBrokerInfo',
  Experience = 'experience',
  SummaryCensus = 'summaryCensus'
}

export enum Lob {
  Medical = 'Medical',
  Dental = 'Dental',
  Vision = 'Vision',
  SuppHealth = 'Supp Health'
}

export type PlanModalDropDownOptions = {
  lobValues: Options[];
  contractCodes: Options[];
  networks?: Options[];
  prodCategories?: Options[];
  prodCodes?: Options[];
  expandCategoryType?: Options[];
  voluntaryIndicator?: Options[];
};

export enum FieldTypes {
  Text = 'text',
  Number = 'number',
  Date = 'date',
  Dropdown = 'dropdown',
  MultiDropdown = 'multiDropdown',
  Checkbox = 'checkbox',
  Radio = 'radio',
  TextArea = 'textarea'
}

export type Options = {
  label: string;
  value: any;
};

export type Alert = {
  show: boolean;
  message: string;
  type: string;
  cssClass: AlertType;
  header: string;
  headerVisibility: false;
};

export enum AlertType {
  Warning = 'alert-warning',
  Error = 'alert-danger',
  Success = 'alert-success',
  None = ''
}

export type CreateOppViewSettings = {
  view: Views;
  opportunityType: OpportunityType;
  lob: Lob;
  creatingNewOpp?: boolean;
  quoteOrigin?: string;
  isAltQuote?: boolean;
  canEditOpp: boolean;
  screenOppType: string;
  isOnlyAlts?: boolean;
};

export enum OpportunityType {
  RenewalLocal = 'Renewal Local',
  NewBusinessLocal = 'New Business Local'
}

export enum Views {
  QuoteViewHidden = 'quoteViewHidden',
  Create = 'create',
  AltInit = 'altInit',
  QuoteHistoryView = 'quoteHistoryView',
  ReadonlyView = 'readonlyView',
  Edit = 'Edit'
}

const TierRatesLists: ReadonlyArray<[string, Array<TierDetails>]> = [
  ['1', [{ tier: 'T1', pathString: 'EE', header: 'EE' }]],
  [
    '2',
    [
      { tier: 'T1', pathString: 'EE', header: 'EE' },
      { tier: 'T2', pathString: 'EF', header: 'EF' }
    ]
  ],
  [
    '3',
    [
      { tier: 'T1', pathString: 'EE', header: 'EE' },
      { tier: 'T2', pathString: 'E1', header: 'E1' },
      { tier: 'T3', pathString: 'EF', header: 'EF' }
    ]
  ],
  [
    '4',
    [
      { tier: 'T1', pathString: 'EE', header: 'EE' },
      { tier: 'T2', pathString: 'ES', header: 'ES' },
      { tier: 'T3', pathString: 'EC', header: 'EC' },
      { tier: 'T4', pathString: 'EF', header: 'EF' }
    ]
  ],
  [
    '5',
    [
      { tier: 'T1', pathString: 'EE', header: 'EE' },
      { tier: 'T2', pathString: 'ES', header: 'ES' },
      { tier: 'T3', pathString: 'EK', header: 'EK' },
      { tier: 'T4', pathString: 'EC', header: 'EC' },
      { tier: 'T5', pathString: 'EF', header: 'EF' }
    ]
  ]
];

export const TierRatesMap: ReadonlyMap<string, Array<TierDetails>> = new Map<string, any>(TierRatesLists);

export type TierDetails = {
  tier: string;
  pathString: string;
  header: string;
};

export type TierCalcDetails = {
  targetTier: string;
  sourceTiers: string[];
}

const TierRatesCalcLists: ReadonlyArray<[string, TierCalcDetails]> = [
  ['1', { targetTier: 'EE', sourceTiers: ['EE','ES','EC','EK','EF'] }],
  ['2', { targetTier: 'EF', sourceTiers: ['ES','EC','EK','EF'] }],
  ['3', { targetTier: 'E1', sourceTiers: ['ES','EC','EK'] }],
  ['4', { targetTier: 'EC', sourceTiers: ['EK','EC'] }],
  ['5', { targetTier: '', sourceTiers: [] }]
];

export const TierRatesCalcMap: ReadonlyMap<string, TierCalcDetails> = new Map<string, any>(TierRatesCalcLists);

export enum CreateOppQueryParams {
  OpportunityId = 'opportunityID',
  QuoteId = 'quoteId',
  QuoteHistoryId = 'quoteHistoryId',
  FundingType = 'fundingType',
  MarketSegment = 'marketSegment',
  Lob = 'lob'
}

export enum Links {
  Delete = 'Delete',
  Copy = 'Copy',
  Alt = 'Alt',
  AltMrkt = 'Alt Mrkt',
  Dental = 'Dental',
  Vision = 'Vision',
  SpecialtyMewa = 'Specialty MEWA'
}

export enum QuoteStatus {
  Submitted = 'Submitted',
  NotSubmitted = 'Not Submitted',
  Failed = 'Failed',
  Modified = 'Modified'
}

export enum QuoteOrigin {
  OppScreen = 'oppScreen',
  PartnerAPI = 'partnerAPI'
}

export enum MarketSegments {
  LargeGroup = 'LG',
  SmallGroup = 'SG'
}

export enum FundingTypes {
  ABF = 'ABF',
  FI = 'FI',
  ACA = 'ACA',
  MEWA = 'MEWA',
  ASO = 'ASO'
}

export enum GroupExperienceKeySuffix {
  Paid = '_paid',
  Incurred = '_incurred',
  Claim = 'claim_',
  Revenue = 'revenue_',
  ClaimDate = 'claimDate',
  SubscriberCount = 'SubscriberCount',
  MemberCount = 'MemberCount'
}

export enum ClaimType {
  MedClaims = 'MedClaims',
  RxClaims = 'RxClaims'
}

export enum ColumnHeader {
  ExpDate = 'Exp Date',
  SubscriberCount = 'Subscriber Count',
  MemberCount = 'Member Count',
  GroupExperience = 'Group Experience',
  Enrollment = 'Enrollment',
  ClaimsHistory = 'Claims History',
  RevenueHistory = 'Revenue History'
}

export enum ColumnDefaults {
  ShowTrue = 'true',
  ShowFalse = 'false'
}

const OriginalFundingTypes: ReadonlyArray<[string, Array<string>]> = [
  [MarketSegments.SmallGroup, [FundingTypes.ABF]],
  [MarketSegments.LargeGroup, [FundingTypes.ABF, FundingTypes.FI]]
];
export const OriginalFundingTypesMap: ReadonlyMap<string, Array<string>> = new Map<string, any>(OriginalFundingTypes);

const AltFundingTypes: ReadonlyArray<[string, Array<string>]> = [
  [MarketSegments.SmallGroup, [FundingTypes.ACA, FundingTypes.MEWA]],
  [MarketSegments.LargeGroup, [FundingTypes.ABF, FundingTypes.FI]]
];
export const AltFundingTypesMap: ReadonlyMap<string, Array<string>> = new Map<string, any>(AltFundingTypes);

const ButtonStatusConfigList: ReadonlyArray<[string, Array<string>]> = [
  [QuoteStatus.NotSubmitted, [Links.Delete, Links.Alt, Links.Copy, Links.AltMrkt]],
  [QuoteStatus.Submitted, [Links.Copy, Links.Alt, Links.AltMrkt]],
  [QuoteStatus.Failed, [Links.Alt, Links.Delete, Links.AltMrkt]],
  [QuoteStatus.Modified, [Links.Alt, Links.Copy, Links.AltMrkt]]
];

export const ButtonStatusConfigMap: ReadonlyMap<string, Array<string>> = new Map<string, any>(ButtonStatusConfigList);

export type QuoteMEWADetails = {
  mewaEligible: boolean;
  contractEndDate: any;
  associationDetails: any;
};

export const RoleBasedAccessDetails = {
  isUserAdmin: false,
  isLGSalesUser: false,
  isSGSalesUser: false,
  isUnderwriter: false,
  isUserModifyOpp: false
};

export const PercentileKeys: string[] = ['participationRate', 'employerFundingLevel', 'surplusRefund', 'aggSLCorridor'];
export const DollarKeys: string[] = ['sslDeductible'];

export const BooleanDropdownKeys: string[] = ['chamberOfCommerce'];

export const tableHistoryKeys = [
  { name: 'currentCarrierTable', key: 'Current Plans', message: 'Current Carrier Changes' },
  { name: 'planTable', key: 'Proposed Plans', message: 'Plan Changes' },
  { name: 'censusTable', key: 'Census', message: 'Census Changes' },
  { name: 'salesAndBrokerTable', key: 'Sales & Broker', message: 'Sales & Broker Changes' },
  { name: 'experience', key: 'Group Experience', message: 'Group Experience Changes' }
];

export const CommisionKeys: string[] = ['abfCommissionValue', 'commissionValue', 'abfCommissionType', 'commissionType'];
export const excludeUpdateHistoryKeys: string[] = ['networkName', 'networkType', 'CDHPIndicator'];
export const arrayHistoryKeys: string[] = ['specialQuoteType'];

export type ContractCodeReplacementDetails = {
  state: string;
  contractCodes: string[];
  marketSegment: string;
  newFundingType: string;
  contractEffectiveDate: string;
  factorEffectiveDate: string;
  censusDetails: any[];
  proposedPlansDetails: any[];
  oppType: string;
  zipCode: string;
  county: string;
  association: string;
};

export const KeyMBUStringConstant: string = 'KY{state}ZZ';
export const SGMBUStringConstant: string = 'SG{state}ZZ';

export const VisDenMBUStringConstant: string = 'DV{mktSeg}{state}';

export enum VoluntaryIndicatorOptionsLabel {
  Y = 'Yes',
  N = 'No'
}

export enum ExpandCategoryTypeOptionsLabel {
  FS = 'Full Service',
  MO = 'Material Only',
  EX = 'Exam Only'
}

export const DentalProposedPlansObject = {
  contractCode: '',
  networkName: 'NA',
  networkType: '',
  planName: '',
  currPlanId: '',
  fundingType: '',
  planTypeRequested: '',
  CDHPIndicator: '',
  volPlanInd: '',
  versionNbr: '',
  vepp: '',
  rateBankAdjPct: '',
  salesAdjPct: ''
}

export const VisionProposedPlansObject = {
  contractCode: '',
  networkName: 'NA',
  networkType: '',
  planName: '',
  currPlanId: '',
  fundingType: '',
  planTypeRequested: '',
  CDHPIndicator: '',
  adjustmentType: 'none'
}

export const TwoCompositTierDetails = [
  { tier: 'T1', pathString: 'EE', header: 'Adult' },
  { tier: 'T3', pathString: 'EC', header: 'Child' }
]