import { inject, Injectable } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class DynamicFormService {
  private schema: any;
  private data: any;

  private fb: FormBuilder = inject(FormBuilder);

  setSchema(schema: any) {
    this.schema = schema;
  }

  getSchema() {
    return this.schema;
  }

  setData(data: any) {
    this.data = data;
  }

  getData() {
    return this.data;
  }
}
