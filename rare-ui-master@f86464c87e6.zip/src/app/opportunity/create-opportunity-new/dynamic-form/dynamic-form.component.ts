import { DatePipe, formatCurrency, formatPercent, getCurrencySymbol } from '@angular/common';
import { Component, Inject, Input, LOCALE_ID, OnChanges, OnDestroy, signal, effect } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import  moment from 'moment';
import { ConfirmationService, MessageService } from 'primeng/api';
import { BehaviorSubject, firstValueFrom, forkJoin, Observable, of, Subject, throwError } from 'rxjs';
import { filter, map, pairwise, startWith, takeUntil, catchError } from 'rxjs/operators';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { AuthenticationService, CacheService, CommonService } from 'src/app/shared/services';
import * as XLSX from 'xlsx';
import { StringUtils } from '../../../shared/utils/string-utils';
import { CreateOpportunityService } from '../../services/create-opportunity-service';
import {
  Alert,
  AlertType,
  arrayHistoryKeys,
  BooleanDropdownKeys,
  ButtonStatusConfigMap,
  CommisionKeys,
  ContractCodeReplacementDetails,
  CreateOppQueryParams,
  CreateOppScreenMessages,
  CreateOppViewSettings,
  DollarKeys,
  excludeUpdateHistoryKeys,
  ExpandCategoryTypeOptionsLabel,
  FieldTypes,
  FundingTypes,
  KeyMBUStringConstant,
  Links,
  Lob,
  MarketSegments,
  OpportunityType,
  PercentileKeys,
  PlanModalDropDownOptions,
  QuoteMEWADetails,
  QuoteOrigin,
  QuoteStatus,
  RoleBasedAccessDetails,
  Sections,
  tableHistoryKeys,
  TierDetails,
  TierRatesMap,
  Views,
  VisDenMBUStringConstant,
  SGMBUStringConstant,
  VoluntaryIndicatorOptionsLabel,
  DentalProposedPlansObject,
  VisionProposedPlansObject,
  TierCalcDetails,
  TierRatesCalcMap,
  TwoCompositTierDetails
} from '../constants/create-opportunity.constants';
import { GroupExperienceService } from 'src/app/shared/components/group-experience/service/group-experience.service';


@Component({
  selector: 'app-dynamic-form',
  templateUrl: 'dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],
  standalone: false
})
export class DynamicFormComponent implements OnChanges, OnDestroy {
  @Input() schemaDetails: any;
  @Input() data: any[];
  @Input() isNewForm: boolean;
  @Input() newFormData: any;
  @Input() isHistoryQuoteData: boolean;
  showTable = false;
  schema: any;
  viewSettings: CreateOppViewSettings;
  currentDataObj: any = null;
  opportunityID: string;
  formGroup: FormGroup;
  planModalformGroup: FormGroup;

  public viewList = Views;

  fileName: string = 'CensusData.xlsx';
  zipCodes: any;
  sicCodeList: any;
  stateCode: any;
  
  subColumnsToUpdate: any = [];
  quoteFieldsToUpdate: any = {};
  displayDeleteDialog: boolean = false;
  destroy$: Subject<void> = new Subject<void>();

  showPlanModal = false;
  planBenefits: any[];
  planDropdownValues: PlanModalDropDownOptions;

  displayWarningDialog: boolean = false;
  planBenefitsUnfiltered: any[];

  isRequestHistory: boolean = false;
  quoteHistoryList: any[] = [];
  isAdjHistory: boolean = false;
  adjHistoryList: any[] = [];
  $loaderVisible: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  isCrossSellingEnabled = this.commonService.getCrossSellingEnabled();
  altAndAltMrktStates = {};
  eligibleAlternates = [];
  blockValueChangeDetection: boolean = false;
  quoteMEWADetails: Map<string, QuoteMEWADetails> = new Map<string, QuoteMEWADetails>();
  keyMBUStringConst: string = KeyMBUStringConstant;
  isMemberCountExpanded: boolean = true;
  isSubscriberCountExpanded: boolean = true;
  alert: Alert = {
    show: false,
    message: '',
    type: '',
    cssClass: AlertType.None,
    header: '',
    headerVisibility: false
  };
  alertMessage: string = '';
  showAlert = false;

  userRole: any;
  rbsDetails = RoleBasedAccessDetails;
  canSalesUserModifyOpp: boolean;
  canUnderwriterModifyOpp: boolean;
  canEditOpp: boolean;
  inCrossSellingMode: boolean = false;
  isCrossSellingInProcess: boolean = false;
  isReadOnlyUser: boolean = false;
  createMEWAEnabled: boolean = false;

  readonly crossSellingRestrictionMap = this.commonService.getCrossSellingRestrictionMap();
  defaultEmployerFundingLevel: number = 0;
  currentCacheCodes = {
    premDelay: '',
    mbu: ''
  };

  showSpecialityQuotes: boolean = false;
  medicareStateMarkerMap = this.commonService.getMedicareStateMarkerMap();

  mewaCallStatus$ = signal(null);
  altMarketCallStatus$ = signal(null);
  asyncMethodCall$ = signal(null);
  defaultsLoading: boolean = false;
  quoteChanged$ = new Subject<void>();

  mewaSubmitEnabled: boolean = false;
  specialityPlanUpdateConfig: any;
  experienceExtractionEnabled: boolean = false;
  
  sectionConstant = Sections;
  isGroupExperienceEditable: boolean = false;
  groupExpObjectChanges: { identifier: string , changed: boolean }[] = [];
  claimsBasisChanges: { identifier: string, previousValue: string, currentValue: string, changed: boolean }[] = [];
  groupExpObjectHasChanged: boolean = false;
  selectedLOB: string;
  showOPPCreationForSGVisionDentalSHP: boolean =false;
  constructor(
    private fb: FormBuilder,
    private cacheService: CacheService,
    private commonService: CommonService,
    private createOpportunityService: CreateOpportunityService,
    public datepipe: DatePipe,
    private confirmationService: ConfirmationService,
    private authService: AuthenticationService,
    private router: Router,
    private route: ActivatedRoute,
    private messageService: MessageService,
    public groupExperienceService: GroupExperienceService,
    @Inject(LOCALE_ID) private locale: string
  ) {
    effect(() => {
      const altMrktStatus = this.altMarketCallStatus$();
      const mewaDetails = this.mewaCallStatus$();
      const asyncCall = this.asyncMethodCall$();
      
      if (altMrktStatus && mewaDetails) {
        this.prepareQuotesTable();
      }

      if(asyncCall && typeof this[asyncCall.name] === 'function') {
        this[asyncCall.name].apply(this, asyncCall.params);
      }
    });

    this.viewSettings = {
      view: Views.QuoteViewHidden,
      opportunityType: OpportunityType.NewBusinessLocal,
      lob: Lob.Medical,
      creatingNewOpp: false,
      quoteOrigin: '',
      canEditOpp: false,
      screenOppType: '',
      isOnlyAlts: false
    };

    this.userRole = this.authService.userRole.value;
    [
      this.rbsDetails.isUserAdmin,
      this.rbsDetails.isLGSalesUser,
      this.rbsDetails.isSGSalesUser,
      this.rbsDetails.isUnderwriter,
      this.rbsDetails.isUserModifyOpp
    ] = [
      this.authService.isUserRoleAdmin(this.userRole),
      this.authService.isUserMarketSegmentLargeGroup(this.userRole),
      this.authService.isUserMarketSegmentSmallGroup(this.userRole),
      this.authService.isUserRoleUnderwriter(this.userRole),
      this.authService.isUserModifyOpp(this.userRole)
    ];

    this.canSalesUserModifyOpp = (this.rbsDetails.isLGSalesUser || this.rbsDetails.isSGSalesUser) && this.rbsDetails.isUserModifyOpp;
    this.canUnderwriterModifyOpp = this.rbsDetails.isUnderwriter && this.rbsDetails.isUserModifyOpp;

    if (this.authService.isUserReadOnly(this.userRole)) {
      this.viewSettings.view = Views.ReadonlyView;
    }
    this.canEditOpp = this.rbsDetails.isUserAdmin || this.canSalesUserModifyOpp || this.canUnderwriterModifyOpp;
    this.viewSettings.canEditOpp = this.canEditOpp;
    this.isReadOnlyUser = this.authService.isUserReadOnly(this.userRole);
    this.showSpecialityQuotes = this.commonService.getRareSpecialitySendToOppEnabled();
    this.createMEWAEnabled = this.commonService.getRareSpecialitySendToOppEnabled();
    this.mewaSubmitEnabled = this.commonService.getMEWAOriginalQuoteEnabled();
    this.specialityPlanUpdateConfig = this.commonService.getOppSpecialityPlanUpdateConfig();
    this.experienceExtractionEnabled = this.commonService.getExperienceExtractionEnabled();
    this.showOPPCreationForSGVisionDentalSHP = this.commonService.getSGSpecialtyVisionDentalEnabled();
  }

  ngOnChanges(): void {
    this.checkAndBuildForm();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  async checkAndBuildForm() {
    const idResult = await this.getQuoteAndOppId();
    if (this.isNewForm) {
      this.opportunityID = idResult.opportunityID;
      this.data[0].data['lob'] = this.selectedLOB ? this.selectedLOB : 'Medical';
    }
    if (!this.showSpecialityQuotes) {
      this.data = this.data.filter((d) => this.getLobFromQuote(d, true) === this.toLobCase(Lob.Medical));
    }
    // Setting schema and lob initially from data array's 1st element to fix missing properties
    let initLob = this.toLobCase(this.data[0].data.lob);
    this.schema = structuredClone(this.schemaDetails[initLob]);
    this.setMissingAlternateQuoteProperty();

    // Selecting first element as the default element on page open
    this.currentDataObj = structuredClone(this.data[0]);
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    
    this.schema = structuredClone(this.schemaDetails[lob]);
    this.viewSettings.opportunityType = this.getValueOfPropertyFromDataObject('opportunityType', this.currentDataObj);
    this.viewSettings.creatingNewOpp = this.getValueOfPropertyFromDataObject('state', this.data[0]) ? true : false;
    this.viewSettings.quoteOrigin = this.getValueOfPropertyFromDataObject('quoteOrigin', this.currentDataObj) ?? QuoteOrigin.OppScreen;
    this.viewSettings.lob = lob;

    this.setQuoteSectionHeaderAllLobs();
    
    if (Array.isArray(this.data)) {
      const quote = this.data.find((item) => {
        const lob = this.getLobFromQuote(item, true);
        const alternateQuote = this.getValueOfPropertyFromDataObject('alternateQuote', item, lob);
        const opportunityType = this.getValueOfPropertyFromDataObject('opportunityType', item, lob);

        return alternateQuote === 'No' && opportunityType === OpportunityType.RenewalLocal;
      });
      
      if (quote) {
        this.viewSettings.screenOppType = this.getValueOfPropertyFromDataObject('opportunityType', quote);
      } else {
        this.viewSettings.screenOppType = OpportunityType.NewBusinessLocal;
      }

      const isOnlyAlts = this.data.every((item) => {
        const lob = this.getLobFromQuote(item, true);
        return this.getValueOfPropertyFromDataObject('alternateQuote', item, lob) === 'Yes';
      });

      if (isOnlyAlts) {
        this.viewSettings.isOnlyAlts = true;
      }
    }
    if (this.currentDataObj.data.opportunityID) {
      this.opportunityID = this.currentDataObj.data.opportunityID;
    }
    let cacheServiceApis$: Observable<any>[] = [this.cacheService.getZipCodeList(''), this.cacheService.getStates(''), this.cacheService.getSICCodeList('')];
    this.altAndAltMrktStates = {};
    this.eligibleAlternates = [];
    let altMrktOptions$: Observable<any>[] = [];
    let altAndAltMrktStatesDetails: any[] = [];

    this.data.forEach((quote) => {
      const isAlt = this.getValueOfPropertyFromDataObject('alternateQuote', quote, this.getLobFromQuote(quote, true)) === 'Yes';
      if (!isAlt) {
        const [state, contractEffectiveDate, marketSegment, factorEffectiveDate] = [
          this.getValueOfPropertyFromDataObject('state', quote, this.getLobFromQuote(quote, true)),
          this.getValueOfPropertyFromDataObject('contractEffectiveDate', quote, this.getLobFromQuote(quote, true)),
          this.getValueOfPropertyFromDataObject('marketSegment', quote, this.getLobFromQuote(quote, true)),
          this.getValueOfPropertyFromDataObject('factorEffectiveDate', quote, this.getLobFromQuote(quote, true))
        ];

        if (state && contractEffectiveDate && marketSegment && factorEffectiveDate && this.getLobFromQuote(quote) === Lob.Medical) {
          cacheServiceApis$.push(this.getMEWAQuoteDetails(quote));
        }

        let [lob, opportunityType, fundingType] = [
          this.getLobFromQuote(quote),
          this.getValueOfPropertyFromDataObject('opportunityType', quote),
          this.getValueOfPropertyFromDataObject('fundingType', quote)
        ];

        if (fundingType && lob !== Lob.SuppHealth) {
          altMrktOptions$.push(this.fetchFundingTypeForAltMrkt(marketSegment, lob, opportunityType, fundingType, state, contractEffectiveDate));
          const atlMarktDataKey = `${state}-${marketSegment}-${opportunityType}-${fundingType}-${lob}`.toLowerCase();
          altAndAltMrktStatesDetails.push({fundingType: fundingType, key: atlMarktDataKey});
        }
      }
    });

    // Adding catchError to each altMrktOptions$ observable to handle errors individually and allow forkJoin to complete
    altMrktOptions$ = altMrktOptions$.map(x=> x.pipe(catchError(error => of(null))));
    forkJoin(altMrktOptions$).subscribe((altMrktOptionsData) => {
      if (altMrktOptionsData && Array.isArray(altMrktOptionsData) && altMrktOptionsData.length > 0) {
        altAndAltMrktStatesDetails.forEach((altMrktDataTag, index) => {
          // Add 'Alternate' eligible alternate if present
          const alternateOption = altMrktOptionsData[index]?.find((option) => option.attrbNm === 'Alternate');
          if (alternateOption) {
            alternateOption.fndngType = altMrktDataTag.fundingType;
            this.eligibleAlternates.push(alternateOption);
          }
          // Add 'Alternate Market' if present
          this.altAndAltMrktStates[altMrktDataTag.key] = altMrktOptionsData[index]
        });

        this.altMarketCallStatus$.set(true);
      }
    });

    //Removing test quotes if user is not Admin
    if (!(this.rbsDetails.isUserAdmin || this.rbsDetails.isSGSalesUser || this.rbsDetails.isLGSalesUser || this.rbsDetails.isUnderwriter)) {
      this.data = this.data.filter((d) => this.getValueOfPropertyFromDataObject('quoteReason', d) !== 'TEST');
    }

    forkJoin(cacheServiceApis$)
      .pipe(takeUntil(this.destroy$))
      .subscribe((response) => {
        this.zipCodes = response[0] || [];
        if (this.formGroup) {
          this.formGroup.get('companyZipCode')?.updateValueAndValidity({ onlySelf: true, emitEvent: false });
          this.formGroup.get('censusTable')?.updateValueAndValidity({ onlySelf: true, emitEvent: false });
        }
        this.stateCode = response[1] || [];
        this.stateCode = this.stateCode.filter((e) => {
          return e.drvdStCd != 'WC';
        });
        this.populateStateOptions();
        this.sicCodeList = response[2] || {};

        response.slice(3).forEach((resp) => {
          this.quoteMEWADetails.set(resp[0], { mewaEligible: resp[1], contractEndDate: resp[2], associationDetails: resp[3] });
        });
        this.mewaCallStatus$.set(true);
      });

    if (this.isNewForm) {
      this.currentDataObj.data.opportunityID = this.opportunityID;
      this.currentDataObj.data.unifiedPayload.data.opportunityID = this.opportunityID;
    }

    if (this.schema && this.data) {
      if (this.isHistoryQuoteData) {
        this.prepareQuotesTable();
        this.viewQuoteHistory();
      } else {
        this.prepareQuotesTable();
      }
    }
  }

  setQuoteSectionHeaderAllLobs() {
    for (const lobKey in this.schemaDetails) {
      if (this.schemaDetails.hasOwnProperty(lobKey)) {
        const schemaObj = this.schemaDetails[lobKey];
        if (schemaObj.sections && schemaObj.sections.quotesSection) {
          schemaObj.sections.quotesSection.forEach((section) => {
            if (section.header) {
              section.header.forEach((h) => {
                h.value = this.getValueFromPath(h.path, this.currentDataObj);
              });
            }
          });
        }
      }
    }
  }

  setMissingAlternateQuoteProperty() {
    // used to set missing alternate quote property for few original quotes
    this.data.forEach(d=> {
      const lob = this.toLobCase(this.data[0].data.lob);
      if(this.getValueOfPropertyFromDataObject('alternateQuote', d, lob) === undefined) {
        this.setValueOfPropertyOfDataObject('alternateQuote', 'No', d, lob);
      }
    })
  }

  prepareQuotesTable() {
    this.showTable = false;
    const schema = this.schema;
    const sections = schema.sections;
    sections['quotesSection'].forEach((section) => {
      if (section.header) {
        section.header.forEach((h) => {
          h.value = this.getValueFromPath(h.path, this.currentDataObj);
        });
      }
      section.fields.forEach((field) => {
        field.rows = [];
        let rowDetails = [];
        this.data
          .filter((d) => d.data.quoteHeaderID && d.data.fundingType)
          .forEach((dt: any) => {
            let row = {};
            field.columns.forEach((col) => {
              const altPathValue = col.altPath ? this.getValueFromPath(col.altPath, dt) : null;
              let value = (this.getValueFromPath(col.path, dt) || altPathValue) ?? '';
              // Check if col.format is defined and apply date formatting
              if (col.format && value) {
                value = this.datepipe.transform(value, col.format);
              }
              row[col.name] = value;
            });

            let lob = this.getLobFromQuote(dt);
            row['lob'] = lob;

            this.configureTableButtons(row, dt);
            rowDetails.push(row);
          });

        field.rows = [...rowDetails];
        for (const lob of Object.values(Lob)) {
          const lobSchema = this.schemaDetails[this.toLobCase(lob)];
          lobSchema.sections['quotesSection'][0].fields[0].rows = [...rowDetails];
        }
      });
    });
    this.showTable = true;
  }

  configureTableButtons(row, dt) {
    const lob = this.getLobFromQuote(dt, true);
    const visibileButtons = this.getVisibleButtons(row['displayStatus'], dt);

    const buttons = structuredClone(this.getSectionOrFieldFromSchema(Sections.QuoteTable, 'quotesTable', 'links', true, lob)['buttons']);

    let filteredButtons = visibileButtons
      .map((btnLabel) => {
        let label = btnLabel;
        let isDisabled = false;
        if (label.includes(':Disabled')) {
          isDisabled = true;
          label = label.substring(0, label.indexOf(':'));
        }

        const buttonConfig = buttons.find((bt) => bt.label === label);
        if (isDisabled && buttonConfig) {
          buttonConfig['disabled'] = true;
          buttonConfig['showTooltip'] = true;
        }
        return buttonConfig;
      })
      .filter((x) => x)
      .sort((a, b) => a.order - b.order);

    const hasMenu = filteredButtons.filter((bt) => bt.type === 'Menu')?.length ? true : false;
    if (hasMenu) {
      this.disableAltMrktOptions(filteredButtons, dt);
    }

    row['buttons'] = filteredButtons;
  }
  setupSchemaAndDataForOpp() {
    
    this.viewSettings.isAltQuote =
      this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true)) === 'Yes' ? true : false;
    if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      const currentPlanTableConfig = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');

      currentPlanTableConfig.parentHeaders = currentPlanTableConfig.parentHeaders.filter((col) => !(col?.basedOnOpportunity === 'isNewBusiness'));
      currentPlanTableConfig.columns = currentPlanTableConfig.columns.filter((col) => !(col?.basedOnOpportunity === 'isNewBusiness'));

      currentPlanTableConfig.columns.find((col) => col.name === 'contractCode').validators.push({ type: 'required' });

      const groupNumberField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'groupNbr');
      groupNumberField.validators.push({ type: 'required' });

      const virginGroupField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'virginGroup');
      virginGroupField['disabled'] = true;
      const inputTierField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'inputTier');
      if (!this.rbsDetails.isUserAdmin) {
        inputTierField['disabled'] = true;
      }
    } else if (this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal) {
      const currentPlanTableConfig = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');
      currentPlanTableConfig.parentHeaders = currentPlanTableConfig.parentHeaders.filter((col) => !(col?.basedOnOpportunity === 'isRenewal'));
      currentPlanTableConfig.columns = currentPlanTableConfig.columns.filter((col) => !(col?.basedOnOpportunity === 'isRenewal'));
      currentPlanTableConfig.togglerColumns = [];
    }
    const currentPlanTableConfig = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');
    const currentPlans = this.currentDataObj?.data?.unifiedPayload?.data?.medical?.currentPlans || [];

    const hasRenewalData = currentPlans.some(plan => {
      const renewal = plan.rateInfo?.TIERED?.RENEWAL;
      if (!renewal) return false;

      const active = renewal.ACTIVE;
      if (!active) return false;

      // Check if any tier object (EE, ES, EF, EC) inside ACTIVE has a rate key
      return Object.values(active).some((tierObj: any) =>
        tierObj?.rate !== undefined
      );
    });

    if (!hasRenewalData && this.viewSettings.opportunityType !== OpportunityType.NewBusinessLocal) {
      currentPlanTableConfig.parentHeaders = currentPlanTableConfig.parentHeaders.filter(
        header => !header?.showRenewals
      );
      currentPlanTableConfig.columns = currentPlanTableConfig.columns.filter(
        col => !col?.showRenewals);      
    }
    //Removing test quotes if user is not Admin
    if (!(this.rbsDetails.isUserAdmin || this.rbsDetails.isSGSalesUser || this.rbsDetails.isLGSalesUser || this.rbsDetails.isUnderwriter)) {
      const testOppField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'quoteReason');
      testOppField['visible'] = false;
    }

    let hasLgRole = this.commonService.hasLgRole();
    let hasSgRole = this.commonService.hasSgRole();
    let marketSegmentOptions = [];

    if (hasSgRole && !hasLgRole) {
      marketSegmentOptions.push({ label: 'Small Group', value: 'SG' });
    } else if (hasLgRole && !hasSgRole) {
      marketSegmentOptions.push({ label: 'Large Group', value: 'LG' });
    } else {
      marketSegmentOptions = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment')['options'];
    }

    this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment')['options'] = marketSegmentOptions;
    
    if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      const hasCensusPrivilege = this.authService.isCensusPrivilegedUser(this.commonService.getAssignedUserGroup());
      if (!hasCensusPrivilege) {
        const censusSection = this.getSectionOrFieldFromSchema(Sections.Census);
        if (censusSection) {
          censusSection.fields?.forEach(field => {
            field.disabled = true;
            // If it's a table field, disable all columns
            if (field.type === 'table' && field.columns) {
              field.columns.forEach(column => {
                column.disabled = true;
              });
            }
          });

          if (censusSection.sectionActions) {
            censusSection.sectionActions = censusSection.sectionActions.filter((action: any) => {
              if (action.type === 'fileUpload') {
                return false;
              } else {
                action.hidden = true;
                return true;
              }
            })
          }
        }
      }
    }
  }

  async prepareForm(onEdit: boolean = false) {
    this.quoteChanged$.next();
    const lob = this.getLobFromQuote(this.currentDataObj);

    this.viewSettings.lob = lob;
    this.viewSettings.opportunityType = this.getValueOfPropertyFromDataObject('opportunityType', this.currentDataObj);
    this.viewSettings.creatingNewOpp = this.getValueOfPropertyFromDataObject('state', this.data[0]) ? true : false;
    this.viewSettings.quoteOrigin = this.getValueOfPropertyFromDataObject('quoteOrigin', this.currentDataObj) ?? QuoteOrigin.OppScreen;
    this.viewSettings.lob = lob;
    // Selecting schema based on lob
    this.schema = structuredClone(this.schemaDetails[this.toLobCase(lob)]);

    this.subColumnsToUpdate = [];
    this.quoteFieldsToUpdate = {};

    this.setupSchemaAndDataForOpp();

    const quoteHeaderID = this.currentDataObj.data.quoteHeaderID || '';
    if (quoteHeaderID && !this.quoteMEWADetails.has(quoteHeaderID)) {
      const [state, contractEffectiveDate, marketSegment, factorEffectiveDate] = [
        this.getValueOfPropertyFromDataObject('state', this.currentDataObj),
        this.getValueOfPropertyFromDataObject('contractEffectiveDate', this.currentDataObj),
        this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj),
        this.getValueOfPropertyFromDataObject('factorEffectiveDate', this.currentDataObj)
      ];
      if (state && contractEffectiveDate && marketSegment && factorEffectiveDate) {
        await this.getMEWAQuoteDetails(this.currentDataObj)
          .toPromise()
          .then((resp) => {
            this.quoteMEWADetails.set(resp[0], { mewaEligible: resp[1], contractEndDate: resp[2], associationDetails: resp[3] });
          });
      }
    }

    this.buildForm();
    if (onEdit) {
      setTimeout(() => {
        this.isValidQuote(this.currentDataObj, false, true);
      }, 500);
    }

    if (lob !== Lob.SuppHealth) {
      this.memberCountToggle(false);
      this.subscriberCountToggle(false);
    }
  }

  setupSchemaAndDataForQuote() {
    const marketSegment =
      this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj) ||
      this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment').options[0].value;

    this.setFundingTypeDropdownOptions(marketSegment);

    const fundingType = this.currentDataObj.data.fundingType;
    const state = this.getValueOfPropertyFromDataObject('state', this.currentDataObj);

    const isAltQuote = this.viewSettings.isAltQuote;
    //-- Need to check if isAltQuote,fundingType === FundingTypes.ACA, this.isCrossSellingEnabled logic is relivant anymore after ALGR-129004 create opp changes
    if (isAltQuote || fundingType === FundingTypes.ACA) {
      this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType')['disabled'] = true;
      this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment')['disabled'] = true;
    }

    if (!this.isCrossSellingEnabled) {
      this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment')['disabled'] = true;
    }
    //-- Enabling Market Segment and Funding Type fields only for Create and Edit view with Not Submitted status ALGR-129004
    if (
      [Views.Create].includes(this.viewSettings.view) ||
      ([Views.Edit].includes(this.viewSettings.view) && !isAltQuote && this.currentDataObj.data.status == 'Not Submitted')
    ) {
      this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment')['disabled'] = false;
      this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType')['disabled'] = false;
     
    } else {
      this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment')['disabled'] = true;
      this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType')['disabled'] = true;
    }

    let groupInfoFieldsToDisable = [];

    if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      if (this.viewSettings.creatingNewOpp) {
        groupInfoFieldsToDisable.push('state');
        groupInfoFieldsToDisable.push('groupNbr');
      }
    } else if (this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal) {
      // Removing Submitter user.

      const userInfo = this.getValueOfPropertyFromDataObject('userInfo', this.currentDataObj) || [];
      const userInfoTablePath = this.getSectionOrFieldFromSchema(Sections.SalesAndBroker, 'salesAndBrokerTable').path;

      this.setValueAtPath(
        userInfoTablePath,
        userInfo.filter((user) => user.role !== 'Submitter'),
        this.currentDataObj
      );

      if (this.viewSettings.creatingNewOpp) {
        groupInfoFieldsToDisable.push('state');
      }
    }
    // To Make County Code as mandatory field if the quote is MEWA and ACA type
    this.addCountyCodeValidation(fundingType);

    const groupSectionFields = this.getSectionOrFieldFromSchema(Sections.GroupInfo).fields;
    groupSectionFields.forEach((field) => {
      if (groupInfoFieldsToDisable.includes(field.name)) {
        field['disabled'] = true;
      }
    });

    this.prepareMEWAQuoteInfoFields();
    this.prepareMEWAPlanFields();
    this.prepareMEWACensusInfoSection();
    if (
      fundingType === FundingTypes.MEWA &&
      this.viewSettings.opportunityType === OpportunityType.RenewalLocal &&
      this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true)) === 'No' &&
      !this.mewaSubmitEnabled
    ) {
      const grpInfoBtns = this.getSectionOrFieldFromSchema(Sections.GroupInfo).buttons;
      grpInfoBtns.forEach((button) => {
        if (button.label === 'Submit') {
          button.disabled = true;
        }
      });
      this.getSectionOrFieldFromSchema(Sections.SalesAndBroker).footerButtons[1]['disabled'] = true;
    }

    const inputTier = this.getValueOfPropertyFromDataObject('inputTier', this.currentDataObj);
    const outputTier = this.getValueOfPropertyFromDataObject('outputTier', this.currentDataObj);
    this.setValueOfPropertyOfDataObject('inputTier', inputTier ? inputTier + '' : '', this.currentDataObj);
    this.setValueOfPropertyOfDataObject('outputTier', outputTier ? outputTier + '' : '', this.currentDataObj);

    this.getValueOfPropertyFromDataObject('proposedPlans', this.currentDataObj)?.forEach((e) => {
      const currPlanIdFieldType = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'currPlanId').type;
      if (currPlanIdFieldType === FieldTypes.MultiDropdown) {
        if (!Array.isArray(e.currPlanId)) {
          e.currPlanId = [e.currPlanId];
        }
      }
    });

    const lobProperty = this.getValueOfPropertyFromDataObject('lobProperty', this.currentDataObj);
    if (!lobProperty.hasOwnProperty('specialQuoteType')) {
      this.setValueOfPropertyOfDataObject('specialQuoteType', [], this.currentDataObj);
    }

    if (this.getLobFromQuote(this.currentDataObj) === Lob.Medical && !lobProperty.hasOwnProperty('stopLossCovg')) {
      this.setValueOfPropertyOfDataObject('stopLossCovg', [], this.currentDataObj);
    }

    this.prepareCurrentPlansTable(inputTier, true);
    
    this.planModalformGroup = null;


    if (this.getSectionOrFieldFromSchema(Sections.Experience)) {
      const quoteIdentifier = `${this.currentDataObj.data.quoteHeaderID}-${this.currentDataObj.data.fundingType}-${this.getLobFromQuote(this.currentDataObj)}`.toLowerCase();
      const groupExpObject = { identifier: quoteIdentifier , changed: false };
      const claimsBasis = this.getValueOfPropertyFromDataObject('claimBasis',this.currentDataObj);
      const claimBasisObject = { identifier: quoteIdentifier, previousValue: claimsBasis, currentValue: claimsBasis, changed: false }
      if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
        // Renewals
        this.getSectionOrFieldFromSchema(Sections.Experience)['showOnlyProjectedContent'] = true;
        this.getSectionOrFieldFromSchema(Sections.Experience).hideSection = false;
        this.getSectionOrFieldFromSchema(Sections.SalesAndBroker).hideFooterButtons = true;

        this.claimsBasisChanges = this.claimsBasisChanges.filter(d=> d.identifier !== quoteIdentifier);
        this.groupExpObjectChanges = this.groupExpObjectChanges.filter(d=> d.identifier !== quoteIdentifier);
        this.groupExpObjectChanges.push(groupExpObject);
        this.claimsBasisChanges.push(claimBasisObject);
      } else {
        // New Business
        if (this.experienceExtractionEnabled) {
          this.getSectionOrFieldFromSchema(Sections.Experience)['showOnlyProjectedContent'] = true;
          this.getSectionOrFieldFromSchema(Sections.Experience).hideSection = false;

          this.getSectionOrFieldFromSchema(Sections.SalesAndBroker).hideFooterButtons = true;

          this.claimsBasisChanges = this.claimsBasisChanges.filter(d=> d.identifier !== quoteIdentifier);
          this.groupExpObjectChanges = this.groupExpObjectChanges.filter(d=> d.identifier !== quoteIdentifier);
          this.groupExpObjectChanges.push(groupExpObject);
          this.claimsBasisChanges.push(claimBasisObject);
        }
      }

      const isAltQuote =
      this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true)) === 'Yes' ? true : false;
      

      if (this.canEditOpp || StringUtils.isEqualIgnoreCase(this.viewSettings.quoteOrigin, QuoteOrigin.OppScreen)) {
        this.isGroupExperienceEditable =  !this.isReadOnlyUser ? true : false;
      } else {
        if (isAltQuote && !this.isReadOnlyUser) {
          this.isGroupExperienceEditable = true;
        } else {
          this.isGroupExperienceEditable = false;
        }
      }


    }

    if (fundingType === FundingTypes.ACA) {
      this.prepareACAFields();
    }

    const lob = this.getLobFromQuote(this.currentDataObj);
    switch (lob) {
      case Lob.SuppHealth: {

        const key = `${marketSegment}_${fundingType}_${this.viewSettings.opportunityType}`;
        const planUpdateStates = this.specialityPlanUpdateConfig[this.getLobFromQuote(this.currentDataObj, true)]?.[key] ?? [];
        if(!planUpdateStates.includes(state)) {
          // Hide plan add and remove as per ALGR-129914
          this.hidePlanTableAddAndDeleteRows()
        }


        const planTableContractCodeField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'contractCode');
        planTableContractCodeField.type = FieldTypes.Text;

        if (planTableContractCodeField['validators']) {
          planTableContractCodeField['validators'].push([{ type: 'required' }]);
        } else {
          planTableContractCodeField['validators'] = [{ type: 'required' }];
        }

        this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable', 'planName')['disabled'] = true;
        const currentCarrierSection = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier);
        const currentCarrierTable = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');

        currentCarrierTable.columns = currentCarrierTable.columns.filter((col) => col.name !== 'checkbox');
        if (currentCarrierTable.parentHeaders && Array.isArray(currentCarrierTable.parentHeaders)) {
          currentCarrierTable.parentHeaders.forEach((parentHeader) => {
            if (parentHeader.header === '') {
              parentHeader.colspan = parentHeader.colspan - 1;
            }
          });
        }

        currentCarrierTable.togglerColumns.forEach(col => {
          col.colspan = col.colspan - 1;
        })

        // Hiding section actions for non-create views
        if (this.viewSettings.view !== Views.Create) {
          const currentCarrierActions = currentCarrierSection.sectionActions;
          currentCarrierActions.forEach((act) => {
            act['hidden'] = true;
          });
          this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'inputTier')['disabled'] = true;
          this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'outputTier')['disabled'] = true;
        }
        break;
      }

      case Lob.Vision: {

        const key = `${marketSegment}_${fundingType}_${this.viewSettings.opportunityType}`;
        const planUpdateStates = this.specialityPlanUpdateConfig[this.getLobFromQuote(this.currentDataObj, true)]?.[key] ?? [];
        if(!planUpdateStates.includes(state)) {
          // Hide plan add and remove as per ALGR-129914
          this.hidePlanTableAddAndDeleteRows()
        }

        if (marketSegment === MarketSegments.SmallGroup) {
          const planTableContractCodeField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'contractCode');
          planTableContractCodeField.type = FieldTypes.Text;
          planTableContractCodeField['changeHandler'] = 'speciliatyPlanNameChange';
          if (planTableContractCodeField['validators']) {
            planTableContractCodeField['validators'].push([{ type: 'required' }]);
          } else {
            planTableContractCodeField['validators'] = [{ type: 'required' }];
          }

          if (this.showOPPCreationForSGVisionDentalSHP) {
            // Make Contract Code readonly for SG Vision
            planTableContractCodeField.disabled = true;

            // Hide Network, Product Category, Product Code columns for SG Vision
            const networkNameField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'networkName');
            const networkTypeField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'networkType');
            const cdhpIndicatorField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'CDHPIndicator');

            if (networkNameField) {
              networkNameField.show = 'false';
              networkNameField.disabled = true;
            }
            if (networkTypeField) {
              networkTypeField.show = 'false';
              networkTypeField.disabled = true;
            }
            if (cdhpIndicatorField) {
              cdhpIndicatorField.show = 'false';
              cdhpIndicatorField.disabled = true;
            }
          }
          this.getSectionOrFieldFromSchema(Sections.FundingInfo).fields.forEach((field) => {
            if (!['fundingType', 'fiCommission', 'fiCommissionType'].includes(field.name)) {
              field['show'] = 'false';
              field['showOverride'] = true;
            }
          });

          // Hide MBS field for Small Group Vision
          const mbsField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'mbs');
          if (mbsField) {
            mbsField.show = 'false';
            mbsField.disabled = true;
          }

          // Set changeHandler and initializingHandler for inputTier to ensure Summary Census tier fields are shown/hidden correctly
          const inputTierField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'inputTier');
          if (inputTierField) {
            inputTierField.changeHandler = 'inputTierChangedVision';
            inputTierField.initializingHandler = 'initInputTierVision';
          }
        }

        break;
      }
      case Lob.Dental: {
        const key = `${marketSegment}_${fundingType}_${this.viewSettings.opportunityType}`;
        const planUpdateStates = this.specialityPlanUpdateConfig[this.getLobFromQuote(this.currentDataObj, true)]?.[key] ?? [];
        if(!planUpdateStates.includes(state)) {
          // Hide plan add and remove as per ALGR-129914
          this.hidePlanTableAddAndDeleteRows()
        }

        if (marketSegment === MarketSegments.SmallGroup) {
          const planTableContractCodeField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'contractCode');
          planTableContractCodeField.type = FieldTypes.Text;
          planTableContractCodeField['changeHandler'] = 'speciliatyPlanNameChange';
          if (planTableContractCodeField['validators']) {
            planTableContractCodeField['validators'].push([{ type: 'required' }]);
          } else {
            planTableContractCodeField['validators'] = [{ type: 'required' }];
          }
          if (this.showOPPCreationForSGVisionDentalSHP) {
            // Make Contract Code readonly for SG Dental
            planTableContractCodeField.disabled = true;

            // Hide Network, Product Category, Product Code columns for SG Dental
            const networkNameField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'networkName');
            const networkTypeField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'networkType');
            const cdhpIndicatorField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'CDHPIndicator');

            if (networkNameField) {
              networkNameField.show = 'false';
              networkNameField.disabled = true;
            }
            if (networkTypeField) {
              networkTypeField.show = 'false';
              networkTypeField.disabled = true;
            }
            if (cdhpIndicatorField) {
              cdhpIndicatorField.show = 'false';
              cdhpIndicatorField.disabled = true;
            }
          }
          this.getSectionOrFieldFromSchema(Sections.FundingInfo).fields.forEach((field) => {
            if (!['fundingType', 'fiCommission', 'fiCommissionType'].includes(field.name)) {
              field['show'] = 'false';
              field['showOverride'] = true;
            }

            if (field.name === 'fiCommission') {
              const fiCommisionValue = this.getValueOfPropertyFromDataObject(
                'fiCommission',
                this.currentDataObj,
                this.getLobFromQuote(this.currentDataObj, true)
              );
              if (!fiCommisionValue) {
                //Defaulting commission value to 0 if no value present
                this.setValueOfPropertyOfDataObject('fiCommission', '0', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true));
              }

              field.validators = field.validators.filter((v) => v.type !== 'required');
            }
          });

          // Hide MBS field for Small Group Dental
          const mbsField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'mbs');
          if (mbsField) {
            mbsField.show = 'false';
            mbsField.disabled = true;
          }

          // Set changeHandler and initializingHandler for inputTier to ensure Summary Census tier fields are shown/hidden correctly
          const inputTierField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'inputTier');
          if (inputTierField) {
            inputTierField.changeHandler = 'inputTierChangedVision';
            inputTierField.initializingHandler = 'initInputTierVision';
          }
        }
        break;
      }

      case Lob.Medical: {
        this.checkMedicareFieldEligibility(state);
        break;
      }
    }
  }

  hidePlanTableAddAndDeleteRows(isVisDenSHP?: boolean) {
    const planSection = this.getSectionOrFieldFromSchema(Sections.Plan);
    const planTable = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable');

    planTable.columns = planTable.columns.filter((col) => col.name !== 'checkbox');

    const plantSectionActions = planSection.sectionActions;
    plantSectionActions.forEach((act) => {
      if (act.name !== 'includeAllPortfolioPlans' && !isVisDenSHP) {
        act['hidden'] = true;
      } else if(isVisDenSHP) {
        act['hidden'] = false;
      }
    });
  }

  checkStateAltMrktElgibility(quote) {
    let [lob, opportunityType, fundingType, state, mktSegment] = [
      this.getLobFromQuote(quote),
      this.getValueOfPropertyFromDataObject('opportunityType', quote),
      this.getValueOfPropertyFromDataObject('fundingType', quote),
      this.getValueOfPropertyFromDataObject('state', quote),
      this.getValueOfPropertyFromDataObject('marketSegment', quote)
    ];

    const atlMarktDataKey = `${state}-${mktSegment}-${opportunityType}-${fundingType}-${lob}`.toLowerCase();
    return this.altAndAltMrktStates[atlMarktDataKey]?.some((state) => state.attrbNm === 'Alternate Market') ?? false;
  }

  checkStateAltFundingElgibility(quote) {
    let [lob, opportunityType, fundingType, state, mktSegment] = [
      this.getLobFromQuote(quote),
      this.getValueOfPropertyFromDataObject('opportunityType', quote),
      this.getValueOfPropertyFromDataObject('fundingType', quote),
      this.getValueOfPropertyFromDataObject('state', quote),
      this.getValueOfPropertyFromDataObject('marketSegment', quote)
    ];

    const atlFundingDataKey = `${state}-${mktSegment}-${opportunityType}-${fundingType}-${lob}`.toLowerCase();
    return this.altAndAltMrktStates[atlFundingDataKey]?.some((state) => state.attrbNm === 'Alternate') ?? false;
  }

  private addCountyCodeValidation(fundingType: any) {
    let countyField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'county');
    let index = countyField.validators.map((validator) => validator.type).indexOf('required');

    if ([FundingTypes.ACA, FundingTypes.MEWA].includes(fundingType)) {
      if (index === -1) countyField.validators.push({ type: 'required' });
    } else {
      if (index !== -1) countyField.validators.splice(index, 1);
    }
  }

  updateAddPlanButtonState() {
    if (!this.showOPPCreationForSGVisionDentalSHP) {
      return;
    }
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    const marketSegment = this.formGroup?.get('marketSegment')?.value;
    
    // Only apply for Dental/Vision Small Group (MEWA/ACA quotes that use quotablePlans API)
    if ((lob !== this.toLobCase(Lob.Dental) && lob !== this.toLobCase(Lob.Vision)) || 
        marketSegment !== MarketSegments.SmallGroup) {
      return;
    }

    // Check if census exists
    const census = this.getValueOfPropertyFromDataObject('census', this.currentDataObj, lob) || [];
    const hasCensus = Array.isArray(census) && census.length > 0;

    // Get the plan section from the current schema (not original)
    const planSection = this.schema?.sections?.quoteDetailsSections?.find(sec => sec.name === Sections.Plan);
    if (!planSection?.sectionActions) {
      return;
    }

    // Find the add plan button and update its disabled state
    const addPlanButton = planSection.sectionActions.find(act => act.clickHandler === 'addPlan');
    if (addPlanButton) {
      addPlanButton['disabled'] = !hasCensus;
    }
  }

  prepareACAFields(formLoaded: boolean = false) {
    const proposedPlanIdField = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'proposedPlanId');
    const subscriberIdField = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'subscriberID');
    const memberIdField = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'memberID');
    subscriberIdField.validators = [...subscriberIdField.validators, { type: 'required' }];
    memberIdField.validators = [...memberIdField.validators, { type: 'required' }];
    proposedPlanIdField.validators = [...proposedPlanIdField.validators, { type: 'required' }];

    this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'outputTier')['disabled'] = true;
    const isAltQuote = this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true)) === 'Yes';
    if (this.checkStateAltMrktElgibility(this.currentDataObj) && !isAltQuote) {
      const grpInfoBtns = this.getSectionOrFieldFromSchema(Sections.GroupInfo).buttons;
      grpInfoBtns.forEach((button) => {
        if (button.label === 'Submit') {
          button.disabled = true;
        }
      });
      this.getSectionOrFieldFromSchema(Sections.SalesAndBroker).footerButtons[1]['disabled'] = true;
    }
    const premDelayField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'premiumDelay');
    let quoteInfoFieldNames = this.getSectionOrFieldFromSchema(Sections.QuoteInfo).fields
      .filter((field) => field.show !== 'false' && field.name !== premDelayField.name).map((f) => f.name);
    
    if(quoteInfoFieldNames.some(field =>field === 'mbs')) {
      const marketSegment = formLoaded ? this.formGroup.get('marketSegment').value : this.getValueOfPropertyFromDataObject('mbs', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true)) ;
      if(marketSegment === MarketSegments.SmallGroup) {
        quoteInfoFieldNames.splice(quoteInfoFieldNames.findIndex(field =>field === 'mbs'), 1);
      }
      
    }

    this.addRemoveFieldsFromQuoteInfo(quoteInfoFieldNames, formLoaded)
  }

  checkMedicareFieldEligibility(state, stateChangedAfterFormLoad = false) {
    let medicareKey = '';

    if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      medicareKey = 'SG_MEWA_Renewal Local';
    } else if (this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal) {
      medicareKey = 'SG_MEWA_New Business Local';
    }

    const fundingType = (this.formGroup?.get('fundingType')?.value ?? null) || this.getValueOfPropertyFromDataObject('fundingType', this.currentDataObj);
    if (
      fundingType === FundingTypes.MEWA &&
      medicareKey &&
      Array.isArray(this.medicareStateMarkerMap[medicareKey]) &&
      this.medicareStateMarkerMap[medicareKey].includes(state)
    ) {
      const medicareField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'isIncludeMedicareRates');
      medicareField.show = 'true';
      
      medicareField.structureStyleClass = 'medicare-checkbox-field';
      
      // Disable for Renewal Local, enable for New Business Local
      medicareField.disabled = this.viewSettings.opportunityType === OpportunityType.RenewalLocal;

      const isIncludeMedicareRates = this.getValueOfPropertyFromDataObject(
        'isIncludeMedicareRates',
        this.currentDataObj,
        this.getLobFromQuote(this.currentDataObj, true)
      );
      if (!isIncludeMedicareRates) {
        //Defaulting commission value to 0 if no value present
        this.setValueOfPropertyOfDataObject('isIncludeMedicareRates', false, this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true));
      }

      if (stateChangedAfterFormLoad) {
        const value = isIncludeMedicareRates ?? false;
        this.formControlAddFieldHelper(medicareField, value);
        
        // Apply disabled state to form control
        if (medicareField.disabled) {
          this.formGroup.get('isIncludeMedicareRates')?.disable();
        } else {
          this.formGroup.get('isIncludeMedicareRates')?.enable();
        }
      }
    } else {
      const medicareField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'isIncludeMedicareRates');
      medicareField.show = 'false';

      if (stateChangedAfterFormLoad) {
        this.formControlRemoveFieldHelper(medicareField);
      }
    }
  }

  prepareMEWACensusInfoSection(formLoaded: boolean = false) {
    const subscriberIdField = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'subscriberID');
    const memberIdField = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'memberID');
    const ft = formLoaded ? this.formGroup.get('fundingType').value : this.getFundingTypeFromObj(this.currentDataObj);
    if (ft === FundingTypes.MEWA) {
      subscriberIdField.validators = [...subscriberIdField.validators, { type: 'required' }];
      memberIdField.validators = [...memberIdField.validators, { type: 'required' }];

      if (formLoaded) {
        const censusTableFormArray = this.formGroup.get('censusTable') as FormArray;
        censusTableFormArray.controls.forEach((group) => {
          group.get(subscriberIdField.name).addValidators(this.getValidators(subscriberIdField.validators, subscriberIdField));
          group.get(memberIdField.name).addValidators(this.getValidators(memberIdField.validators, memberIdField));
        });
      }
    }
  }

  prepareMEWAPlanFields(formLoaded: boolean = false) {
    const ft = formLoaded ? this.formGroup.get('fundingType').value : this.getFundingTypeFromObj(this.currentDataObj);
    if (ft === FundingTypes.MEWA && !this.commonService.mewaPortfolioEnabled) {
      const planSectionActions = this.getSectionOrFieldFromSchema(Sections.Plan).sectionActions;
      let includeAllPortfolioPlansField = planSectionActions.find((field) => field.name === 'includeAllPortfolioPlans');
      includeAllPortfolioPlansField.disabled = true;

      if (formLoaded) {
        this.formGroup.get('includeAllPortfolioPlans').disable();
      }
    }
  }

  prepareMEWAQuoteInfoFields(formLoaded: boolean = false) {
    let quoteInfoFieldsToShow = [];
    const ft = formLoaded ? this.formGroup.get('fundingType').value : this.getFundingTypeFromObj(this.currentDataObj);
    if (ft === FundingTypes.MEWA) {
      quoteInfoFieldsToShow.push('contractEffectiveDate', 'contractEndDate', 'factorEffectiveDate', 'mbu', 'association', 'inputTier', 'outputTier');

      const quoteInfoFields = this.getSectionOrFieldFromSchema(Sections.QuoteInfo).fields;
      let inputTier = quoteInfoFields.find((field) => field.name === 'inputTier');
      let outputTier = quoteInfoFields.find((field) => field.name === 'outputTier');

      inputTier.disabled = true;
      outputTier.disabled = true;

      this.addRemoveFieldsFromQuoteInfo(quoteInfoFieldsToShow, formLoaded);

      if (formLoaded) {
        this.formGroup.get('inputTier').setValue('4');
        this.formGroup.get('outputTier').setValue('4');
      }
    }
  }

  getValueFromPath(path: string, data: any[]): any {
    try {
      return path?.split('.').reduce((acc, key) => {
        let isArrayKey = false;
        if (key.includes('[')) {
          isArrayKey = true;
          key = key.substring(0, key.indexOf('['));
        }

        if (acc === undefined) {
          // Safety check for missing key.
          throw new Error();
        }

        return acc && (isArrayKey ? acc[key][0] : acc[key]);
      }, data);
    } catch (e) {
      return undefined;
    }
  }

  setValueAtPath(path: string, value: any, obj: any, isUpdateHistory: boolean = false, oppJson: any = {}, isUpdateOrginalValue: boolean = true): void {
    const keys = path.split('.');
    const lastKey = keys.pop();

    let arrayPopulationType = null;
    let target = undefined;
    try {
      target = keys.reduce((acc, key) => {
        if (acc === undefined) {
          throw new Error();
        }

        const match = key.match(/^([^\[]+)\[([^\]]+)\]$/);
        if (match) {
          const propKey = match[1];
          const indexKey = parseInt(match[2], 10);

          arrayPopulationType = !isNaN(indexKey) ? { type: 'index', index: indexKey } : { type: 'all', index: null };
          return acc[propKey];
        }

        return acc[key];
      }, obj);
    } catch {
      return undefined;
    }

    if (target) {
      if (!arrayPopulationType || arrayPopulationType.type === 'index') {
        if (arrayPopulationType?.type === 'index') {
          if (Array.isArray(target) && target.length === 0) {
            target.push({});
          }
          target = target[arrayPopulationType.index];
        }
        if (isUpdateHistory) {
          this.updateHistory(obj, target, lastKey, value, oppJson);
        }
        if (isUpdateOrginalValue) {
          target[lastKey] = value;
        }
      } else if (arrayPopulationType.type === 'all') {
        target.forEach((tarObj) => {
          if (isUpdateHistory) {
            this.updateHistory(obj, tarObj, lastKey, value, oppJson);
          }
          if (isUpdateOrginalValue) {
            tarObj[lastKey] = value;
          }
        });
      }
    }
  }

  updateHistory(obj: any, target: any, lastKey: string, value: any, oppJson: any) {
    const label = oppJson?.label ? oppJson?.label : lastKey;
    if (target[lastKey] !== undefined && !Array.isArray(value) && target[lastKey] !== value && label) {
      if (BooleanDropdownKeys.includes(lastKey)) {
        this.updateHistoryOldNewValues(obj, label, this.setDropDownLabels(value, oppJson), this.setDropDownLabels(target[lastKey], oppJson));
      } else if (CommisionKeys.includes(lastKey)) {
        if (lastKey === 'abfCommissionValue' || lastKey === 'abfCommissionType') {
          const oldABFCommissionValue = this.getValueOfPropertyFromDataObject('abfCommission', obj, this.getLobFromQuote(obj, true));
          const oldCommissionType = this.getValueOfPropertyFromDataObject('abfCommissionType', obj, this.getLobFromQuote(obj, true));
          const newCommissionType = this.formGroup.get('abfCommissionType').value;
          const newValue =
            newCommissionType === 'Percent'
              ? this.formGroup.get('abfCommission').value !== ''
                ? this.formGroup.get('abfCommission').value + '%'
                : this.formGroup.get('abfCommission').value
              : this.formGroup.get('abfCommission').value !== ''
                ? '$' + this.formGroup.get('abfCommission').value + '/' + newCommissionType
                : this.formGroup.get('abfCommission').value;
          const oldValue =
            oldCommissionType === 'Percent'
              ? oldABFCommissionValue !== ''
                ? oldABFCommissionValue + '%'
                : oldABFCommissionValue
              : oldABFCommissionValue !== ''
                ? '$' + oldABFCommissionValue + '/' + oldCommissionType
                : oldABFCommissionValue;
          this.updateHistoryOldNewValues(obj, 'ABF Commission', newValue, oldValue);
        }

        if (lastKey === 'commissionValue' || lastKey === 'commissionType') {
          const oldFICommissionValue = this.getValueOfPropertyFromDataObject('fiCommission', obj);
          const oldFiCommissionType = this.getValueOfPropertyFromDataObject('fiCommissionType', obj);

          const newCommissionType = this.formGroup.get('fiCommissionType').value;
          const newValue =
            newCommissionType === 'Percent'
              ? this.formGroup.get('fiCommission').value !== ''
                ? this.formGroup.get('fiCommission').value + '%'
                : this.formGroup.get('fiCommission').value
              : this.formGroup.get('fiCommission').value !== ''
                ? '$' + this.formGroup.get('fiCommission').value + '/' + newCommissionType
                : this.formGroup.get('fiCommission').value;
          const oldValue =
            oldFiCommissionType === 'Percent'
              ? oldFICommissionValue !== ''
                ? oldFICommissionValue + '%'
                : oldFICommissionValue
              : oldFICommissionValue !== ''
                ? '$' + oldFICommissionValue + '/' + oldFiCommissionType
                : oldFICommissionValue !== '';
          this.updateHistoryOldNewValues(obj, 'FI Commission', newValue, oldValue);
        }
      } else if (lastKey === 'adjustmentType') {
        if (target[lastKey].toLowerCase() !== value.toLowerCase()) {
          this.updateHistoryOldNewValues(obj, label, value, target[lastKey]);
        }
      } else {
        const newValue =
          PercentileKeys.includes(lastKey) && !StringUtils.isEmpty(value)
            ? (parseFloat(value) * 100).toLocaleString('en', { minimumFractionDigits: 2 }) + '%'
            : DollarKeys.includes(lastKey) && !StringUtils.isEmpty(value)
              ? '$' + value
              : value;
        const oldValue =
          PercentileKeys.includes(lastKey) && !StringUtils.isEmpty(target[lastKey])
            ? (parseFloat(target[lastKey]) * 100).toLocaleString('en', { minimumFractionDigits: 2 }) + '%'
            : DollarKeys.includes(lastKey) && !StringUtils.isEmpty(target[lastKey])
              ? '$' + target[lastKey]
              : target[lastKey];
        this.updateHistoryOldNewValues(obj, label, newValue, oldValue);
      }
    }
    if (target[lastKey] !== undefined && Array.isArray(value) && label && arrayHistoryKeys.includes(lastKey)) {
      const areArraysEqual = value.every((item) => target[lastKey].includes(item)) && target[lastKey].every((item) => value.includes(item));
      // Handle the case where arrays are not equal
      if (!areArraysEqual) {
        const newValue = value.length ? value.join(', ') : '';
        const oldValue = target[lastKey]?.length ? target[lastKey].join(', ') : '';
        this.updateHistoryOldNewValues(obj, label, newValue, oldValue);
      }
    }
  }

  updateHistoryOldNewValues(quote, lastKey, newValue, oldValue) {
    if (!quote.data.updateHistory[quote.data.updateHistory.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(lastKey)) {
      if (typeof newValue === 'string') {
        if (!StringUtils.isEmpty(newValue)) {
          quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[lastKey] = newValue;
        }
      } else {
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[lastKey] = newValue;
      }

      if (typeof oldValue === 'string') {
        if (!StringUtils.isEmpty(oldValue)) {
          quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.oldValue[lastKey] = oldValue;
        }
      } else {
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.oldValue[lastKey] = oldValue;
      }
    } else {
      if (typeof newValue === 'string') {
        if (!StringUtils.isEmpty(newValue)) {
          quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[lastKey] = newValue;
        } else {
          delete quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[lastKey];
        }
      } else {
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[lastKey] = newValue;
      }
    }
  }

  setDropDownLabels(value: string, oppJson: any) {
    if (oppJson?.field?.options) {
      const option = oppJson.field.options.find((opt) => opt.value === value);
      return option ? option.label : value;
    }
    return value;
  }

  async buildForm() {
    this.populateStateOptions();
    // initiating data with today's date
    this.setValueOfPropertyOfDataObject('requestedDueDate', this.datepipe.transform(new Date(), 'yyyy-MM-dd'), this.currentDataObj);

    this.setupSchemaAndDataForQuote();
    this.formGroup = null;
    const formControls = {};
    const sections = this.schema.sections;

    for (let key in sections) {
      switch (key) {
        case 'quoteDetailsSections': {
          if (true) {
            const tableCheckAllFields = [];
            sections[key].forEach((section, index) => {
              if (section.header) {
                section.header.forEach((h) => {
                  h.value = this.getValueFromPath(h.path, this.currentDataObj);

                  if (h.id === 'lob') {
                    h.value = this.getLobFromQuote(this.currentDataObj);
                  }
                });
              }
              if (section.buttons) {
                section.buttons.forEach((button) => {
                  if (
                    button.label === 'Update History' &&
                    this.currentDataObj.data?.updateHistory?.length &&
                    this.currentDataObj.data.updateHistory.some(
                      (history) =>
                        Object.keys(history.changeSetDetail?.adjustmentData?.newValue || {}).length > 0 ||
                        Object.keys(history.changeSetDetail?.adjustmentData?.oldValue || {}).length > 0
                    )
                  ) {
                    button.showOnView = true;
                  }
                });
              }
              section.sectionActions?.forEach((action) => {
                if (action.type === 'formField') {
                  const validators = this.getValidators(action.validators);
                  let value = this.getValueFromPath(action.path, this.currentDataObj) ?? action.defaultValue ?? '';
                  let modifiedValue = undefined;

                  if (action.valueModifier) {
                    let valueModifierName = action.valueModifier;

                    if (valueModifierName && typeof this[valueModifierName] === 'function') {
                      modifiedValue = this[valueModifierName].apply(this, [
                        {
                          value: value,
                          field: action,
                          type: 'get'
                        }
                      ]);
                    }
                  }

                  value = modifiedValue !== undefined ? modifiedValue : value;
                  formControls[action.name] = new FormControl({ value, disabled: action.disabled }, validators);

                  this.quoteFieldsToUpdate[action.name] = {
                    path: action.path,
                    name: action.name,
                    type: action.subType,
                    label: action.label,
                    columns: action.columns ?? null,
                    field: action
                  };
                }
              });

              section.fields.forEach((field) => {
                if (field.show !== 'false') {
                  let value = undefined;
                  const validators = this.getValidators(field.validators);

                  if (field?.togglerColumns) {
                    field.togglerColumns.forEach((togglerColumn) => {
                      if (togglerColumn.columns) {
                        togglerColumn.columns.forEach((column) => {
                          this.subColumnsToUpdate.push(column);
                        });
                      }
                    });
                  }
                  
                  switch (field.type) {
                    case 'table': {
                      let data = this.getValueFromPath(field.path, this.currentDataObj) ?? [];
                      let formArray = this.prepareFormArrayForTable(field.columns, data, field.togglerColumns, field.subColRowCheckFn);

                      if (field.columns.find((col) => col.type === 'checkbox')) {
                        tableCheckAllFields.push(field.name);
                      }

                      formControls[field.name] = this.fb.array(formArray);

                      //component rates for form
                      if (
                        this.getLobFromQuote(this.currentDataObj) !== Lob.SuppHealth &&
                        this.viewSettings.opportunityType === OpportunityType.RenewalLocal &&
                        field?.togglerColumns &&
                        formControls[field.name]?.controls
                      ) {
                        formControls[field.name].controls.forEach((group: FormGroup) => {
                          //disable funding type in current plans for renewals
                          group.get(CommonConstants.FUNDING_TYPE).disable();
                          const idBasedRateInfo = data.filter((x) => x.id == group.get('id').value);
                          const tieredRateInfo = idBasedRateInfo[0].rateInfo.TIERED;
                          //check component rates available
                          if (Object.keys(tieredRateInfo)?.filter(key => key !== 'RENEWAL').length > 1) {
                            Object.keys(group.controls).forEach((ctrlName) => {
                              if (ctrlName.includes('currRates')) {
                                group.get(ctrlName).disable();
                              }
                            });
                            field.togglerColumns.forEach((togglerColumn) => {
                              let formTogglerArray = this.prepareFormArrayForTable(togglerColumn.columns, idBasedRateInfo);
                              formTogglerArray.forEach((toggleGroup) => {
                                Object.keys(toggleGroup.controls).forEach((ctrlName) => {
                                  group.addControl(ctrlName, toggleGroup.get(ctrlName));
                                });

                                (group as FormGroup).addControl('_showSubCols', new FormControl(true));
                              });
                            });
                          }
                        });
                      } 
                      break;
                    }

                    case 'date': {
                      value = this.getValueFromPath(field.path, this.currentDataObj) ?? null;

                      value = value ? moment(value).toDate() : null;
                      if (!value && field.defaultValue) {
                        /* Default value for dates are numerical values of number of days from today, can be negative to set
                        past dates*/
                        const today = new Date();

                        value = moment(today).add(field.defaultValue, 'd').toDate();
                      }

                      formControls[field.name] = new FormControl({ value, disabled: field.disabled }, validators);

                      break;
                    }

                    case 'autocomplete': {
                      const valueFromAltPath = field.altPath ? this.getValueFromPath(field.altPath, this.currentDataObj) : null;

                      value = this.getValueFromPath(field.path, this.currentDataObj) ?? valueFromAltPath ?? field.defaultValue ?? '';

                      formControls[field.name] = new FormControl({ value, disabled: field.disabled }, validators);
                      const subscriber = new BehaviorSubject<any>(undefined);

                      field['subscriber'] = subscriber;
                      break;
                    }

                    default: {
                      const valueFromAltPath = field.altPath ? this.getValueFromPath(field.altPath, this.currentDataObj) : null;

                      value = this.getValueFromPath(field.path, this.currentDataObj) ?? valueFromAltPath ?? field.defaultValue ?? '';
                      if (field.type === 'dropdown' && field.supportedOptions?.values) {
                        const currentFundingType = this.getValueOfPropertyFromDataObject('fundingType', this.currentDataObj);
                        const currentMarketSegment = this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj);
                        const currentState = this.getValueOfPropertyFromDataObject('state', this.currentDataObj);

                        const matchingConfig = field.supportedOptions.values.find((config) => {
                          const ftMatch = config.ft === currentFundingType;
                          return ftMatch;
                        });

                        // If no funding type (creating new opp), default to ABF options
                        if (!currentFundingType && field.supportedOptions.values.length > 0) {
                          const abfConfig = field.supportedOptions.values.find((config) => config.ft === 'ABF');
                          field.options = abfConfig?.options || field.supportedOptions.values[0]?.options || [];
                        } else {
                          field.options = matchingConfig?.options || [];
                        }

                        // If current value is not in the new options, default to first option
                        if (field.options.length > 0 && value && !field.options.some(opt => opt.value === value)) {
                          value = field.options[0].value;
                        }
                      }

                      let modifiedValue = undefined;

                      if (field.valueModifier) {
                        let valueModifierName = field.valueModifier;

                        if (valueModifierName && typeof this[valueModifierName] === 'function') {
                          modifiedValue = this[valueModifierName].apply(this, [
                            {
                              value: value,
                              field: field,
                              type: 'get'
                            }
                          ]);
                        }
                      }

                      value = modifiedValue !== undefined ? modifiedValue : value;
                      formControls[field.name] = new FormControl({ value, disabled: field.disabled }, validators);
                    }
                  }

                  let fieldObj = structuredClone(field);
                  if (field['subscriber']) {
                    delete fieldObj['subscriber'];
                  }

                  this.quoteFieldsToUpdate[fieldObj.name] = {
                    path: fieldObj.path,
                    name: fieldObj.name,
                    type: fieldObj.type,
                    label: fieldObj.label,
                    columns: fieldObj.columns ?? null,
                    field: fieldObj
                  };

                  if (field.changeHandler) {
                    (formControls[field.name] as FormControl).valueChanges
                      .pipe(
                        startWith(value),
                        pairwise(),
                        filter((_) => !this.blockValueChangeDetection),
                        takeUntil(this.destroy$),
                        takeUntil(this.quoteChanged$)
                      )
                      .subscribe(([previousVal, val]) => {
                        let handlerName = field.changeHandler;

                        if (handlerName && typeof this[handlerName] === 'function') {
                          this[handlerName].apply(this, [
                            {
                              value: val,
                              field: field,
                              previousVal: previousVal
                            }
                          ]);
                        }
                      });
                  }
                }
              });
            });

            // Adding all check all header checkbos to form group
            tableCheckAllFields.forEach((table) => {
              let checkAllControl = new FormControl();
              checkAllControl.valueChanges.pipe(takeUntil(this.destroy$), takeUntil(this.quoteChanged$)).subscribe((val) => {
                (this.formGroup.get(table) as FormArray).controls.forEach((group) => {
                  group.get('checkbox').setValue(val, { emitEvent: false });
                });
              });

              formControls[table + 'CheckAll'] = checkAllControl;
            });
          }

          break;
        }
      }
    }

    this.formGroup = this.fb.group(formControls);
    this.initializeFieldsWithHandlers();
    
    // Set initial add plan button state based on census
    this.updateAddPlanButtonState();
    
    return new Promise((resolve) => resolve('form built'));
  }

  disableAltMrktOptions(buttons, quote) {
    const marketSegment = this.getValueOfPropertyFromDataObject('marketSegment', quote);
    const targetMarketSegment = marketSegment === MarketSegments.SmallGroup ? MarketSegments.LargeGroup : MarketSegments.SmallGroup;

    this.fetchMewaEligibility(marketSegment, quote, this.getLobFromQuote(quote, true));

    const matchingQuote = this.data.find((d) => {
      return (
        this.getValueOfPropertyFromDataObject('marketSegment', d) === targetMarketSegment && this.getLobFromQuote(d, true) === this.getLobFromQuote(quote, true)
      );
    });

    if (matchingQuote) {
      this.fetchMewaEligibility(targetMarketSegment, matchingQuote, this.getLobFromQuote(matchingQuote, true));
    }

    let menuItem = buttons.find(b => b.type === 'Menu').options[0];
    let items = menuItem.items
    const isAltMarketEnabled = this.checkStateAltMrktElgibility(quote);
    const isAltFundingEnabled = this.checkStateAltFundingElgibility(quote);

    if(!isAltMarketEnabled) {
      items = items.filter(opt => opt.handler !== 'altMarketCross');
    }

    if(!isAltFundingEnabled) {
      items = items.filter(opt => opt.handler !== 'addAlternateQuote');
    }

    if(items.length < 3) {
      // Options List has 3 options, if alt and alt market both not available, removing Both option
      items = items.filter(opt => opt.label !== 'Both');
    }

    menuItem.items = items;

    return buttons;
  }

  private async fetchMewaEligibility(marketSegment: any, quote: any, lob?) {
    lob = lob ? lob : this.getLobFromQuote(this.currentDataObj, true);
    if (marketSegment === MarketSegments.SmallGroup || marketSegment === MarketSegments.LargeGroup) {
      // Fetch mewa eligibility to check if mewa alternates are allowed or not for new SG quotes
      const mewaFetchObj = structuredClone(quote);
      this.setValueOfPropertyOfDataObject('marketSegment', marketSegment, mewaFetchObj);

      await this.getMEWAQuoteDetails(mewaFetchObj, lob)
        .toPromise()
        .then((resp) => {
          this.quoteMEWADetails.set(resp?.[0] ?? '', { mewaEligible: resp[1], contractEndDate: resp[2], associationDetails: resp[3] });
        });
    }

    return new Promise((res) => res('Mewa Eligibility Fetched'));
  }

  initializeFieldsWithHandlers() {
    const sections = this.schema.sections;
    for (let key in sections) {
      switch (key) {
        case 'groupSection':
          sections[key].forEach((section) => {
            section.fields.forEach((field) => {
              if (field.initializingHandler && field.show !== 'false') {
                let handlerName = field.initializingHandler;
                if (handlerName && typeof this[handlerName] === 'function') {
                  this[handlerName].apply(this, [
                    {
                      field: field
                    }
                  ]);
                }
              }
            });
          });
          break;
        case 'quoteDetailsSections': {
          if (this.viewSettings.view !== Views.QuoteViewHidden) {
            sections[key].forEach((section) => {
              section.fields.forEach((field) => {
                if (field.initializingHandler && field.show !== 'false') {
                  let handlerName = field.initializingHandler;
                  if (handlerName && typeof this[handlerName] === 'function') {
                    this[handlerName].apply(this, [
                      {
                        field: field
                      }
                    ]);
                  }
                }

                if (field.type === 'table') {
                  field.columns.forEach((col) => {
                    if (col.initializingHandler && col.show !== 'false') {
                      let handlerName = col.initializingHandler;
                      if (handlerName && typeof this[handlerName] === 'function') {
                        this[handlerName].apply(this, [
                          {
                            field: col
                          }
                        ]);
                      }
                    }
                  });
                }
              });
            });
          }

          break;
        }
      }
    }
  }

  initState(...args) {
    const stateValue = this.formGroup.get('state').value;
    if (stateValue) {
      this.populateSicOptionsValues(stateValue);
    }
  }

  stateChanged(...args) {
    const { value } = args[0];
    this.populateSicOptionsValues(value);

    if(!this.viewSettings.creatingNewOpp) {
      const marketSegmentFieldOriginal = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment', null, true);
      const marketSegmentField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment');
      marketSegmentField.options = this.checkMarketSegmentFundingTypeRestrictions(marketSegmentFieldOriginal.options);
    }
    
    const contEffDate = this.formGroup.get('contractEffectiveDate').value;
    if (contEffDate) {
      this.formGroup.get('contractEffectiveDate').setValue(contEffDate);
    }

    if (this.getLobFromQuote(this.currentDataObj) === Lob.Medical) {
      this.checkMedicareFieldEligibility(value, true);
    }

    if((this.selectedLOB === CommonConstants.Vision || this.selectedLOB === CommonConstants.Dental || this.selectedLOB === CommonConstants.SuppHealth) && this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal && this.showOPPCreationForSGVisionDentalSHP) {
      this.hidePlanTableAddAndDeleteRows(true)
    }
  }

  async zipCodeChanged(...args) {
    const { value } = args[0];
    let countyCodeField = this.formGroup.get('county');
    countyCodeField.setValue('');
    const countyCode = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'county');
    countyCode.options = [];
    if (countyCode.subscriber) {
      countyCode.subscriber.next(null);
    }
    if (this.formGroup.get('companyZipCode').errors == null) {
      this.getCountyCodes(value)
        .toPromise()
        .then((countyCodeList) => {
          if (countyCodeList.length == 1) {
            countyCodeField.setValue(countyCodeList[0].countyCd);
          }
          this.initializeCountyCode(countyCodeList);
        });
    }
  }

  populateStateOptions() {
    const stateCodeList = [];
    if (this.stateCode) {
      this.stateCode.forEach((val: any) => {
        stateCodeList.push({ label: val.stCd, value: val.stCd });
      });
    }

    let stateField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'state');
    stateField.options = stateCodeList;
  }

  populateSicOptionsValues(stateCode) {
    let sicField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'sicCode');
    sicField.options = this.sicCodeList && this.sicCodeList[stateCode] ? this.sicCodeList[stateCode].map((sic) => ({ label: sic, value: sic })) : [];
  }

  setPlanNameInPlanTable() {
    let planTableForm = this.formGroup.get('planTable') as FormArray;
    if (planTableForm) {
      const lob = this.getLobFromQuote(this.currentDataObj, true);
      const marketSegment = this.formGroup.get('marketSegment').value;
      const isSGDentalVision = this.showOPPCreationForSGVisionDentalSHP &&(lob === this.toLobCase(Lob.Dental) || lob === this.toLobCase(Lob.Vision)) && marketSegment === MarketSegments.SmallGroup;
      
      planTableForm.controls.forEach((group) => {
        let contractCode = group.get('contractCode').value;

        if (contractCode && this.planBenefitsUnfiltered) {
          const filteredPlans = this.planBenefitsUnfiltered.filter((plan) => plan.cntrctCd === contractCode);
          if (filteredPlans.length > 0) {
            let planName = (lob === this.toLobCase(Lob.Vision) ? filteredPlans[0].planCd : filteredPlans[0].planName) ?? '';
            group.get('planName').setValue(planName);
            
            // Skip setting networkName, networkType, and CDHPIndicator for Vision/Dental New Business
            const isVisionOrDental = lob === this.toLobCase(Lob.Vision) || lob === this.toLobCase(Lob.Dental);
            const isNewBusiness = this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal;
            
            if (!(isVisionOrDental && isNewBusiness)) {
              group.get('networkName')?.setValue(isSGDentalVision ? 'NA' : (filteredPlans[0]?.ntwrkName ?? ''));
              group.get('networkType')?.setValue(filteredPlans[0]?.prodCtgryCd ?? '');
              group.get('CDHPIndicator')?.setValue(filteredPlans[0]?.prodCd ?? '');
            }
          }
        }
      });
    }
  }

  initializeCurrentPlanDropdown() {
    this.populateCurrentPlanOptions();
  }

  populateCurrentPlanOptions(valueBeforeTierChange = []) {
    let currentCarrierFormValue = (this.formGroup.get('currentCarrierTable') as FormArray).getRawValue() || [];

    const currentPlanField = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'currPlanId');

    let ids = currentCarrierFormValue.map((carrier) => carrier.id);
    let options = [];
    ids.forEach((id) => {
      const label = currentCarrierFormValue.find((carrier) => carrier.id === id)?.planName;
      if (label) {
        options.push({
          value: id,
          label: label
        });
      }
    });

    currentPlanField.options = options;

    const planFormArray = this.formGroup.get('planTable') as FormArray;
    valueBeforeTierChange.forEach((id, index) => {
      planFormArray.at(index).get('currPlanId').setValue(id);
    });

    planFormArray.controls.forEach((group) => {
      let selectedPlanIdValue = group.get('currPlanId').value;

      let valueToSet = null;
      const currPlanIdFieldType = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'currPlanId').type;
      if (currPlanIdFieldType === FieldTypes.MultiDropdown) {
        if (!Array.isArray(selectedPlanIdValue)) {
          selectedPlanIdValue = [selectedPlanIdValue];
        }

        valueToSet = selectedPlanIdValue.filter((val) => ids.includes(val));
      } else if (currPlanIdFieldType === FieldTypes.Dropdown) {
        valueToSet = ids.includes(selectedPlanIdValue) ? selectedPlanIdValue : '';
      }

      group.get('currPlanId').setValue(valueToSet);
    });
  }

  initializeContractCodeDropdown() {
    this.populateContractCodeOptions();
  }

  populateContractCodeOptions() {
    let proposedPlans = (this.formGroup.get('planTable') as FormArray)?.getRawValue() || [];
    if (proposedPlans) {
      const contractCodeField = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'proposedPlanId');

      let quoteLineItemIds = proposedPlans.map((plan) => plan.quoteLineItemID);
      let options = [];
      quoteLineItemIds?.forEach((quoteLineItemID) => {
        const label = proposedPlans.find((plan) => plan.quoteLineItemID === quoteLineItemID)?.contractCode;
        if (label) {
          options.push({
            value: quoteLineItemID,
            label: label
          });
        }
      });
      contractCodeField.options = options;
      this.blockValueChangeDetection = true;
      if (options.length) {
        (this.formGroup.get('censusTable') as FormArray).controls.forEach((control) => {
          if (control.get('proposedPlanId').value && control.get('proposedPlanId').value.length) {
            const updatedValues = control.get('proposedPlanId').value.filter((val) => quoteLineItemIds.includes(val));
            control.get('proposedPlanId').setValue(updatedValues);
          }
        });
      } else {
        (this.formGroup.get('censusTable') as FormArray).controls.forEach((control) => {
          control.get('proposedPlanId').setValue([]);
        });
      }
      this.blockValueChangeDetection = false;
    }
  }

  initAdjustmentType(...args) {
    const { field } = args[0];

    this.updateCompetitiveRateFieldValidator(this.formGroup.get(field.name).value);
  }

  adjustmentTypeChanged(...args) {
    const { value } = args[0];

    this.updateCompetitiveRateFieldValidator(value);
  }

  associationChanged(...args) {
    const { value } = args[0];
    let contractCodeDefaults = this.quoteMEWADetails.get(this.currentDataObj.data.quoteHeaderID)['contractEndDate'];
    this.formGroup.get('contractEndDate').setValue(moment(contractCodeDefaults[value]).toDate());
  }

  updateCompetitiveRateFieldValidator(value) {
    let rateField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'competitiveRateAdjustmentPercent');
    const rateFieldOriginalSetting = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'competitiveRateAdjustmentPercent', null, true);
    // Copying original validators to preserve any other Validators present
    rateField.validators = structuredClone(rateFieldOriginalSetting.validators);

    if (['none', 'Match Competitor Current Rates', 'Match Competitor Renewal Rates'].includes(value) || !value) {
      // making rate field optional
      rateField.validators = rateField.validators.filter((v) => v.type !== 'required');
    }

    this.formGroup.get(rateField.name).clearValidators();
    this.formGroup.get(rateField.name).addValidators(this.getValidators(rateField.validators));
    this.formGroup.get(rateField.name).updateValueAndValidity();
  }

  async contractEffectiveDateChanged(...args) {
    const { value } = args[0];
    const contEffDate: Date = value;
    const contEndDate = moment(contEffDate).add(1, 'y').subtract(1, 'd').toDate();
    if (moment(contEffDate).isValid()) {
      this.formGroup.get('contractEndDate').setValue(contEndDate);
      const fundingType = this.formGroup.get('fundingType').value;

      if(!this.viewSettings.creatingNewOpp) {
        let marketSegmentField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'marketSegment');
        marketSegmentField.options = this.checkMarketSegmentFundingTypeRestrictions(marketSegmentField.options);
      }
      
      await this.checkAndEnableMewaFTOption(contEffDate);

      await this.prepareFundingType(fundingType, false);
      await this.populateQuoteAndFundingInfoOptions();
    } else {
      this.formGroup.get('contractEndDate').setValue('');
    }
  }

  async initializeContractEffectiveDate(...args) {
    const { field } = args[0];
    const contEffectiveDate = this.formGroup.get(field.name);

    if (contEffectiveDate && contEffectiveDate.value) {
      await this.populateQuoteAndFundingInfoOptions();
    }

    return new Promise((resolve) => resolve('Complete'));
  }

  initGuarEffectiveDate(...args) {
    const { field } = args[0];
 
    const rateGuarEffectiveDateField = this.formGroup.get(field.name);
 
    // Skip auto-population for Dental/Vision Small Group (MEWA/ACA) - these fields should remain empty
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    const quotingType = this.getValueOfPropertyFromDataObject('quotingType', this.currentDataObj, lob);
    const marketSegment = this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj, lob);
    if ((lob === 'dental' || lob === 'vision') && marketSegment === MarketSegments.SmallGroup && (quotingType === FundingTypes.ACA || quotingType === FundingTypes.MEWA)) {
      return;
    }
 
    if (!rateGuarEffectiveDateField?.value) {
      this.blockValueChangeDetection = true;
      const currentDate = moment().format('YYYY-MM-DD');
      rateGuarEffectiveDateField.setValue(currentDate);
      this.blockValueChangeDetection = false;
    }
  }

  initGuarEndDate(...args) {
    const { field } = args[0];

    const rateGuarEndDateField = this.formGroup.get(field.name);

    // Skip auto-population for Dental/Vision Small Group (MEWA/ACA) - these fields should remain empty
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    const quotingType = this.getValueOfPropertyFromDataObject('quotingType', this.currentDataObj, lob);
    const marketSegment = this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj, lob);
    if ((lob === 'dental' || lob === 'vision') && marketSegment === MarketSegments.SmallGroup && (quotingType === FundingTypes.ACA || quotingType === FundingTypes.MEWA)) {
      return;
    }

    const monthsToAdd = this.formGroup.get('rateGuarMonths')?.value;
    const contractEffectiveDate = this.formGroup.get('contractEffectiveDate')?.value;

    if (!rateGuarEndDateField?.value && contractEffectiveDate && moment(contractEffectiveDate).isValid()) {
      let value = moment(contractEffectiveDate).add(monthsToAdd, 'months').subtract(1, 'days').toDate();

      this.blockValueChangeDetection = true;
      rateGuarEndDateField.setValue(value);
      this.blockValueChangeDetection = false;
    }
  }

  rateGuarEffectiveDateChange(...args) {
    const { value } = args[0];

    const rateGuarEndDate: Date = this.formGroup.get('rateGuarEndDate').value;

    if (value && rateGuarEndDate) {
      this.setRateGuarMonths(value, rateGuarEndDate);
    }
  }

  rateGuarEndDateChange(...args) {
    const { value } = args[0];

    const rateGuarEffDate: Date = this.formGroup.get('rateGuarEffectiveDate').value;

    if (value && rateGuarEffDate) {
      this.setRateGuarMonths(rateGuarEffDate, value);
    }
  }

  setRateGuarMonths(startDate, endDate) {
    if (!startDate || !endDate) {
      return;
    }

    if (moment(startDate).isAfter(moment(endDate))) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.RateGuarMonthsError });
      return;
    }

    const monthDiff = moment(endDate).add(1, 'days').diff(moment(startDate), 'months');
    this.formGroup.get('rateGuarMonths')?.setValue(monthDiff + '');
  }

  factorEffDateChange() {
    this.populateQuoteAndFundingInfoOptions();
    const fundingType = this.formGroup.get('fundingType').value;
    this.prepareQuoteType(fundingType);
  }

  resetQuoteDetailSections(formLoaded: boolean) {
    this.resetSchemaSection(Sections.QuoteInfo, formLoaded);
    if(this.getSectionOrFieldFromSchema(Sections.Census)) {
      this.resetSchemaSection(Sections.Census, formLoaded);
    }
    
    this.resetSchemaSection(Sections.Plan, formLoaded);
    this.resetSchemaSection(Sections.SalesAndBroker, formLoaded);
  }

  resetSchemaSection(sectionName: string, formLoaded: boolean) {
    const originalSectionInfo = structuredClone(this.getSectionOrFieldFromSchema(sectionName, null, null, true));
    const sectionInfo = this.getSectionOrFieldFromSchema(sectionName);
    const sectionInfoIndex = this.schema.sections['quoteDetailsSections'].findIndex((sec) => sec.name === sectionName);
   
    for(let [key , value] of Object.entries(originalSectionInfo)) {
      if(key === 'fields') {
        continue;
      }

      originalSectionInfo[key] = structuredClone(sectionInfo[key]);
    }

    originalSectionInfo.fields.forEach((field) => {
      const currentFieldSchema = sectionInfo.fields.find((x) => x.name === field.name);
      if (currentFieldSchema.options !== undefined) {
        // Preserving the options
        field['options'] = currentFieldSchema.options;
      }

      if (formLoaded) {
        if (field.type === 'table') {
          const censusTableFormArray = this.formGroup.get(field.name) as FormArray;
          censusTableFormArray.controls.forEach((row) => {
            field.columns.forEach((col) => {
              const control = (row as FormGroup).get(col.name);
              const currentColField = this.getSectionOrFieldFromSchema(sectionName, field.name, col.name);
              if (currentColField.options !== undefined) {
                // Preserving the options
                col['options'] = structuredClone(currentColField.options);
              }
              if (col.validators?.length) {
                control.addValidators(this.getValidators(col.validators, col));
              } else {
                control.clearValidators();
              }
            });
          });
        } else {
          if (field.validators?.length) {
            this.formGroup.get(field.name)?.addValidators(this.getValidators(field.validators, field));
          } else {
            this.formGroup.get(field.name)?.clearValidators();
          }
        }
      }
    });
    this.schema.sections['quoteDetailsSections'].splice(sectionInfoIndex, 1, originalSectionInfo);
  }

  async prepareQuoteDetailSections(fundingType) {
    const state = this.formGroup.get('state').value;
    this.resetQuoteDetailSections(true);
    switch (fundingType) {
      case FundingTypes.MEWA: {
        this.prepareMEWAQuoteInfoFields(true);
        this.prepareMEWAPlanFields(true);
        this.prepareMEWACensusInfoSection(true);
        break;
      }

      case FundingTypes.ACA: {
        this.prepareACAFields(true);
        break;
      }

      default: {
        const originalQuoteInfo = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, null, null, true);
        const quoteInfoFieldNames = originalQuoteInfo.fields.filter((field) => field.show !== 'false').map((f) => f.name);
        this.addRemoveFieldsFromQuoteInfo(quoteInfoFieldNames, true);
      }
    }
    return new Promise((resolve) => resolve('Quote Info Prepared'));
  }

  addRemoveFieldsFromQuoteInfo(fieldList, formLoaded: boolean = false) {
    const originalQuoteInfo = this.getSectionOrFieldFromSchema(Sections.QuoteInfo).fields;
    originalQuoteInfo.forEach((field) => {
      if (fieldList.includes(field.name)) {
        field['show'] = 'true';

        if (formLoaded) {
          let fieldValue = this.getValueFromPath(field.path, this.currentDataObj) ?? field.defaultValue ?? '';
          if (!this.formGroup.get(field.name)) {
            this.formGroup.addControl(field.name, new FormControl({ value: fieldValue, disabled: field.disabled }, this.getValidators(field.validators)));
            this.quoteFieldsToUpdate[field.name] = { path: field.path, name: field.name, type: field.type, label: field.label, columns: field.columns ?? null };
            this.formGroup.get(field.name).updateValueAndValidity();
            if (field.initializingHandler) {
              let handlerName = field.initializingHandler;
              if (handlerName && typeof this[handlerName] === 'function') {
                this[handlerName].apply(this, [
                  {
                    field: field
                  }
                ]);
              }
            }
          } else {
            if (field.disabled) {
              this.formGroup.get(field.name).disable();
            } else {
              this.formGroup.get(field.name).enable();
            }
          }
        }
      } else {
        field['show'] = 'false';
        if (formLoaded && this.formGroup.get(field.name)) {
          this.formGroup.removeControl(field.name);
          delete this.quoteFieldsToUpdate[field.name];
        }
      }
    });
  }

  async populateQuoteAndFundingInfoOptions() {
    const cacheCode = this.generateCacheCodeString();
    let [state, marketSegment, contEffectiveDate, factorEffectiveDate] = cacheCode.split('##');

    const fundingType = this.formGroup.get('fundingType').value;
    let mbs = marketSegment === MarketSegments.SmallGroup ? marketSegment : (this.formGroup.get('mbs')?.value ?? 'Key');

    const commissionInfoCacheCode = cacheCode + '##' + fundingType;
    const zipCode = this.formGroup?.get('companyZipCode')?.value
      ? this.formGroup?.get('companyZipCode')?.value
      : this.getValueOfPropertyFromDataObject('companyZipCode', this.currentDataObj);

    let defaultValueApis = [
      this.cacheService.getCommissionInfo(
        commissionInfoCacheCode,
        state,
        marketSegment,
        fundingType,
        contEffectiveDate,
        factorEffectiveDate,
        this.viewSettings.opportunityType,
        this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true))
      ),
      this.getPlanBenefits(cacheCode, state, contEffectiveDate, factorEffectiveDate, marketSegment, mbs),
      this.getCountyCodes(zipCode)
    ];

    let apiIndexMap = { defaults: 0, planBenefits: 1, countyCodes: 2 };
    let indexCounter = 3;

    if (this.formGroup.get('mbu')) {
      defaultValueApis.push(this.cacheService.getMBUCodesList(cacheCode, state, marketSegment, contEffectiveDate, factorEffectiveDate));
      apiIndexMap['mbu'] = indexCounter;
      indexCounter++;
    }

    this.defaultsLoading = true;
    let response;
    await forkJoin([...defaultValueApis])
      .pipe(takeUntil(this.destroy$))
      .toPromise()
      .then((resp) => {
        response = resp;
      });

    this.defaultsLoading = false;

    const lob = this.getLobFromQuote(this.currentDataObj, true);
    switch (lob) {
      case this.toLobCase(Lob.Vision): {
        this.initializeVisionPlanBenefits(response[apiIndexMap['planBenefits']] ?? []);
        break;
      }

      case this.toLobCase(Lob.Dental): {
        this.initializeDentalPlanBenefits(response[apiIndexMap['planBenefits']] ?? []);
        break;
      }

      default: {
        this.initializePlanBenefits(response[apiIndexMap['planBenefits']] ?? []);
        break;
      }
    }

    this.initializeCountyCode(response[apiIndexMap['countyCodes']] ?? []);

    if (apiIndexMap['mbu'] > -1) {
      this.initialiazeMBUOptions(response[apiIndexMap['mbu']] ?? [], cacheCode);
    }

    if (this.formGroup.get('premiumDelay')) {
      this.initialiazePremiumDelayOptions(cacheCode);
    }

    if (this.formGroup.get('employerFundingLevel')) {
      this.initialiazeEmployerFundingLevel(response[apiIndexMap['defaults']] ?? []);
    }

    if (fundingType === FundingTypes.ABF && moment(contEffectiveDate).isValid()) {
      this.initialiazeSSLDefaultOptions(response[apiIndexMap['defaults']] ?? []);
    }

    if (fundingType === FundingTypes.MEWA) {
      const respValue = response[apiIndexMap['defaults']];

      this.quoteMEWADetails.set(this.currentDataObj.data.quoteHeaderID, {
        mewaEligible: respValue.mewaEligible || false,
        contractEndDate: respValue['contractEndDate'],
        associationDetails: respValue['associationDetails'] || []
      });

      this.initialiazeMEWAEligibleFields(respValue ?? []);
    }
  }

  generateCacheCodeString() {
    const stateCode = this.formGroup.get('state').value;
    const marketSegment = this.formGroup.get('marketSegment').value;
    const contractEffectiveDate = moment(this.formGroup.get('contractEffectiveDate').value).format('YYYY-MM-DD');
    const factorEffectiveDate = moment(this.formGroup.get('factorEffectiveDate').value).format('YYYY-MM-DD');

    return `${stateCode}##${marketSegment}##${contractEffectiveDate}##${factorEffectiveDate}`;
  }

  initialiazeMBUOptions(list: any[], cacheCode) {
    const state = this.formGroup.get('state').value;
    const marketSegment = this.formGroup.get('marketSegment').value;
    const cacheCodeChanged = this.currentCacheCodes.mbu && this.currentCacheCodes.mbu !== cacheCode ? true : false;
    this.currentCacheCodes.mbu = cacheCode;
    let mbuField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'mbu');
    if (this.formGroup.get(mbuField.name)) {
      let options = list.map((item) => {
        return { label: item.slsMbuCd, value: item.slsMbuCd };
      });

      let defaultIndex = 0;

      let messageParams: any = {
        state: state
      };
      let defaultString = this.setMessageStringParams(messageParams, this.keyMBUStringConst);

      const lob = this.getLobFromQuote(this.currentDataObj);
      let currentValueInvalid: boolean = false;
      switch (lob) {
        case Lob.SuppHealth:
        case Lob.Vision:
        case Lob.Dental: {
          // For Vision and Dental mbu field is disabled
          const mbuValue = this.getValueOfPropertyFromDataObject('mbu', this.currentDataObj);
          options.push({ label: mbuValue, value: mbuValue });
          mbuField['disabled'] = true;
          this.formGroup.get(mbuField.name).disable();

          messageParams = {
            mktSeg: marketSegment,
            state: state
          };

          defaultString = this.setMessageStringParams(messageParams, VisDenMBUStringConstant);
          defaultIndex = options.findIndex((opt) => opt.value === defaultString);
          defaultIndex = defaultIndex < 0 ? 0 : defaultIndex;
          break;
        }

        case Lob.Medical: {
          if (marketSegment === MarketSegments.LargeGroup) {
            const SGMBUString = this.setMessageStringParams(messageParams, SGMBUStringConstant);
            const SGMBUStringIndex = options.findIndex((opt) => opt.value === SGMBUString);
            if (SGMBUStringIndex > -1) {
              options = options.filter((opt) => opt.value !== SGMBUString);
            }

            const currentValue = this.formGroup.get(mbuField.name).value;
            currentValueInvalid = options.some((op) => op.value === currentValue) ? false : true;
            defaultIndex = options.findIndex((opt) => opt.value === defaultString);
            const currentValueIndex = options.findIndex((opt) => opt.value === currentValue);
            defaultIndex = currentValueIndex > -1 ? currentValueIndex : defaultIndex < 0 ? 0 : defaultIndex;
          } else if (marketSegment === MarketSegments.SmallGroup) {
            defaultString = this.setMessageStringParams(messageParams, SGMBUStringConstant);
            const currentValue = this.formGroup.get(mbuField.name).value;
            currentValueInvalid = options.some((op) => op.value === currentValue) ? false : true;
            defaultIndex = options.findIndex((opt) => opt.value === defaultString);
            const currentValueIndex = options.findIndex((opt) => opt.value === currentValue);
            defaultIndex = currentValueIndex > -1 ? currentValueIndex : defaultIndex < 0 ? 0 : defaultIndex;
          }
          break;
        }
      }

      mbuField.options = options;

      const mbu = this.formGroup.get(mbuField.name);
      const hasOptionsChanged = this.hasObjectChanged(structuredClone(mbuField.options), options);

      if (options.length && (!mbu.value || cacheCodeChanged || hasOptionsChanged || currentValueInvalid)) {
        mbu.setValue(options[defaultIndex].value);
      } else if (!options.length) {
        mbu.setValue('');
      }
    }
  }

  initialiazePremiumDelayOptions(cacheCode) {
    let premiumDelayField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'premiumDelay');
    if (!premiumDelayField || !premiumDelayField.supportedOptions?.values) {
      return;
    }

    const cacheCodeChanged = this.currentCacheCodes.premDelay && this.currentCacheCodes.premDelay !== cacheCode ? true : false;
    this.currentCacheCodes.premDelay = cacheCode;

    if (this.formGroup.get(premiumDelayField.name)) {
      const fundingType = this.formGroup.get('fundingType').value;
      
      const matchingConfig = premiumDelayField.supportedOptions.values.find((config) => config.ft === fundingType);
      let options = matchingConfig?.options || [];

      const hasOptionsChanged = this.hasObjectChanged(premiumDelayField.options, options);
      premiumDelayField.options = options;

      
      const premiumDelay = this.formGroup.get(premiumDelayField.name);
      // If premium delay has value but not present in option (eg. ABF to FI Alt creation, ABF has 7 as valid value and FI doesn't)
      const isValueNotSupportedPremDelay = premiumDelay.value && !options.some(val=> val.value === premiumDelay.value);
      if (options.length && (!premiumDelay.value || hasOptionsChanged || cacheCodeChanged || isValueNotSupportedPremDelay)) {
        premiumDelay.setValue(options[0].value);
      }
    }
  }

  initialiazeMEWAEligibleFields(defaultValues: any) {
    if (defaultValues && defaultValues.mewaEligible === false) {
      return;
    }

    let associationField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'association');
    let riskFactorField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'riskFactor');

    const isAlternate = this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true));

    let incldAltFilteredAssociations = defaultValues.associationDetails
      .filter((item) => isAlternate === 'Yes' ? item.incldAlt === 'Y' : true)
      .map((item) => {
        return { label: item.assnNm, value: item.assnCd };
      });

    let options: any = [...new Map(incldAltFilteredAssociations.map((item) => [item['value'], item])).values()];

    associationField.options = options;
    if (options.length && !this.formGroup.get(associationField.name).value) {
      this.formGroup.get(associationField.name).setValue(options[0].value);
    }

    if (StringUtils.isEmpty(this.formGroup.get(riskFactorField.name).value) && defaultValues.riskFactorDefault) {
      this.formGroup.get(riskFactorField.name).setValue(defaultValues.riskFactorDefault.dataCtgryValue);
    }

    if (defaultValues.contractEndDate) {
      let assocValue = this.formGroup.get(associationField.name).value;
      this.formGroup.get('contractEndDate').setValue(moment(defaultValues.contractEndDate[assocValue]).toDate());
    }
  }

  initialiazeEmployerFundingLevel(defaultData: any) {
    const employerFundingLevel = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'employerFundingLevel');

    if (this.formGroup.get(employerFundingLevel.name)) {
      if (defaultData && Array.isArray(defaultData.EmployerFundingLevel) && defaultData.EmployerFundingLevel[0]) {
        const hasDefaultValueChanged = this.defaultEmployerFundingLevel !== defaultData.EmployerFundingLevel[0].dfltPct * 100;
        this.defaultEmployerFundingLevel = defaultData.EmployerFundingLevel[0].dfltPct * 100;
        if (hasDefaultValueChanged || !this.formGroup.get(employerFundingLevel.name).value) {
          this.formGroup.get(employerFundingLevel.name).setValue(this.defaultEmployerFundingLevel);
        }
      }
    }
  }

  initialiazeSSLDefaultOptions(defaultData: any) {
    let surplusRefundOptions = [];
    let sslDeductLevelAmountOptions = [];
    let coveragePeriodOptions = [];
    let aslDeductLevelAmountOptions = [];

    if (defaultData?.StopLossCoverage?.length) {
      let surplusRefundDefault, sslDeductibleDefault, coveragePeriodDefault, aslDeductDefault;
      defaultData.StopLossCoverage.forEach((slc) => {
        switch (slc.dataCtgry) {
          case 'SURPLUS_REFUND': {
            if (slc.dfltInd === 'Y') {
              surplusRefundDefault = slc.dataCtgryValue;
            }

            surplusRefundOptions.push({
              label: formatPercent(parseFloat(slc.dataCtgryValue), this.locale, '1.0-0'),
              value: slc.dataCtgryValue
            });
            break;
          }

          case 'SSL_DEDUCTIBLE': {
            if (slc.dfltInd === 'Y') {
              sslDeductibleDefault = slc.dataCtgryValue;
            }

            sslDeductLevelAmountOptions.push({
              label: formatCurrency(slc.dataCtgryValue, this.locale, getCurrencySymbol('USD', 'wide'), undefined, '1.0-0'),
              value: slc.dataCtgryValue
            });
            break;
          }

          case 'ASL_AGG_ATCH_PT': {
            if (slc.dfltInd === 'Y') {
              aslDeductDefault = slc.dataCtgryValue;
            }

            aslDeductLevelAmountOptions.push({
              label: formatPercent(parseFloat(slc.dataCtgryValue), this.locale, '1.0-0'),
              value: slc.dataCtgryValue
            });
            break;
          }
          case 'SSL_CONTRACT_BASIS': {
            if (slc.dfltInd === 'Y') {
              coveragePeriodDefault = slc.dataCtgryValue;
            }
            coveragePeriodOptions.push({ label: slc.dataCtgryValue, value: slc.dataCtgryValue });
            break;
          }
        }
      });

      surplusRefundOptions.sort((a, b) => (parseFloat(a.value) > parseFloat(b.value) ? 1 : -1));
      sslDeductLevelAmountOptions.sort((a, b) => (parseFloat(a.value) > parseFloat(b.value) ? 1 : -1));
      coveragePeriodOptions.sort((a, b) => (a.value > b.value ? 1 : -1));
      aslDeductLevelAmountOptions.sort((a, b) => (parseFloat(a.value) > parseFloat(b.value) ? 1 : -1));

      let surplusRefundField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'surplusRefund');
      let sslDeductibleAmtField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'sslDeductible');
      let coveragePeriodField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'sslContractBasis');
      let aslDeductLevelAmtField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'aslCorridor');

      surplusRefundField.options = surplusRefundOptions;
      sslDeductibleAmtField.options = sslDeductLevelAmountOptions;
      coveragePeriodField.options = coveragePeriodOptions;
      aslDeductLevelAmtField.options = aslDeductLevelAmountOptions;

      const [sslDeductible, surplusRefund, coveragePeriod, aslDeductible] = [
        this.formGroup.get(sslDeductibleAmtField.name),
        this.formGroup.get(surplusRefundField.name),
        this.formGroup.get(coveragePeriodField.name),
        this.formGroup.get(aslDeductLevelAmtField.name)
      ];

      const [isSslDeductibleValueInvalid, isSurplusRefundValueInvalid, isCoveragePeriodValueInvalid, isAslDeductibleValueInvalid] = [
        sslDeductible.value && !sslDeductibleAmtField.options.some((option) => option.value === sslDeductible.value),
        surplusRefund.value && !surplusRefundField.options.some((option) => option.value === surplusRefund.value),
        coveragePeriod.value && !coveragePeriodField.options.some((option) => option.value === coveragePeriod.value),
        aslDeductible.value && !aslDeductLevelAmtField.options.some((option) => option.value === aslDeductible.value)
      ];

      if (isSslDeductibleValueInvalid || !sslDeductible.value) {
        sslDeductible.setValue(sslDeductibleDefault);
      }

      if (isSurplusRefundValueInvalid || !surplusRefund.value) {
        surplusRefund.setValue(surplusRefundDefault);
      }

      if (isCoveragePeriodValueInvalid || !coveragePeriod.value) {
        coveragePeriod.setValue(coveragePeriodDefault);
      }

      if (isAslDeductibleValueInvalid || !aslDeductible.value) {
        aslDeductible.setValue(aslDeductDefault);
      }
    } else {
      this.setOrRemoveAlertMsg(true, CreateOppScreenMessages.StopLossCoverageEmptyABF, AlertType.Error);
    }
  }

  initializeVisionPlanBenefits(list: any[]) {
    this.planBenefits = list.map((resp, index) => {
      return {
        ...resp,
        exCatType: resp.planCd?.substring(0, (resp.planCd + '').indexOf('.')) ?? ''
      };
    });

    this.planBenefitsUnfiltered = structuredClone(this.planBenefits);

    this.planDropdownValues = {
      lobValues: [{ label: this.viewSettings.lob, value: this.viewSettings.lob }],
      voluntaryIndicator: [],
      expandCategoryType: [],
      contractCodes: []
    };

    const selectedContractCodes = [];
    const planTbleArray = this.formGroup?.get('planTable') as FormArray;
    planTbleArray.controls.forEach((row) => {
      selectedContractCodes.push(row.get('contractCode').value);
    });

    //Removing selected contract code from list.
    this.planBenefits = this.planBenefits.filter((plan) => !selectedContractCodes.includes(plan.cntrctCd));
    if (this.planBenefits.length) {
      this.populateExtraCategoryTypeOptions();
      this.setPlanNameInPlanTable();
    }
  }

  initializeDentalPlanBenefits(list: any[]) {
    this.planBenefits = list;

    this.planBenefitsUnfiltered = structuredClone(this.planBenefits);

    const selectedContractCodes = [];
    const planTbleArray = this.formGroup?.get('planTable') as FormArray;
    planTbleArray.controls.forEach((row) => {
      selectedContractCodes.push(row.get('contractCode').value);
    });

    if (this.planBenefits.length) {
      this.setPlanNameInPlanTable();
    }

    //Removing selected contract code from list.
    this.planBenefits = this.planBenefits.filter((plan) => !selectedContractCodes.includes(plan.cntrctCd));
  }

  initializeSuppHealthPlanBenefits(list: any[]) {
    this.planBenefits = list;

    this.planBenefitsUnfiltered = structuredClone(this.planBenefits);

    const selectedContractCodes = [];
    const planTbleArray = this.formGroup?.get('planTable') as FormArray;
    planTbleArray.controls.forEach((row) => {
      selectedContractCodes.push(row.get('contractCode').value);
    });

    if (this.planBenefits.length) {
      this.setPlanNameInPlanTable();
    }

    //Removing selected contract code from list.
    this.planBenefits = this.planBenefits.filter((plan) => !selectedContractCodes.includes(plan.cntrctCd));
  }

  initializeCountyCode(list: any[]) {
    let countyCodeField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'county', null, null, this.getLobFromQuote(this.currentDataObj, true));
    countyCodeField.options = list
      ? list.map((county) => ({
          label: county.countyCd + ' - ' + county.cityNm,
          value: county.countyCd + ' - ' + county.cityNm,
          valueLabel: county.countyCd
        }))
      : [];

    const currentValue = this.formGroup.get(countyCodeField.name).value;

    this.quoteFieldsToUpdate[countyCodeField.name].field.options = [...countyCodeField.options];

    this.formGroup.get(countyCodeField.name).setValue(countyCodeField.options.find((opt) => opt.valueLabel === currentValue)?.value ?? currentValue);
    countyCodeField.subscriber.next(countyCodeField.options);
  }

  initializePlanBenefits(list: any[]) {
    const fundingType = this.formGroup?.get('fundingType')?.value ?? '';
    this.planBenefits = list.filter((plan) => {
      return plan.fndngType.includes(fundingType) || plan.fndngType.includes('ALL');
    });

    this.planBenefitsUnfiltered = structuredClone(this.planBenefits);

    const planTableFormArray = this.formGroup.get('planTable') as FormArray;
    let originalFundingType;

    const lob = this.getLobFromQuote(this.currentDataObj, true);
    if (this.viewSettings.isAltQuote) {
      originalFundingType = this.getFundingTypeFromObj(
        this.data.find(
          (d) =>
            d.quoteHeaderID === this.currentDataObj.quoteHeaderID &&
            ['No', undefined].includes(this.getValueOfPropertyFromDataObject('alternateQuote', d, lob)) &&
            this.getLobFromQuote(d, true) === lob
        )
      );
    }

    planTableFormArray.getRawValue().forEach((e, index) => {
      const contractCodeValue = planTableFormArray.at(index).get('contractCode').value;
      const fundingTypeField = planTableFormArray.at(index).get('fundingType');
      const validPlan = this.planBenefitsUnfiltered?.some(
        (plan) => plan.cntrctCd === contractCodeValue && (plan.fndngType.includes(fundingType) || plan.fndngType.includes('ALL'))
      );

      if (this.viewSettings.isAltQuote && !validPlan) {
        fundingTypeField.setValue(originalFundingType);
      }

      if (validPlan && (!this.inCrossSellingMode || (this.inCrossSellingMode && !this.isCrossSellingInProcess))) {
        fundingTypeField.setValue(fundingType);
      }
    });

    this.planDropdownValues = {
      lobValues: [{ label: this.viewSettings.lob, value: this.viewSettings.lob }],
      networks: [],
      prodCategories: [],
      prodCodes: [],
      contractCodes: []
    };

    const selectedContractCodes = [];
    const planTbleArray = this.formGroup?.get('planTable') as FormArray;
    planTbleArray.controls.forEach((row) => {
      selectedContractCodes.push(row.get('contractCode').value);
    });

    //Removing selected contract code from list.
    this.planBenefits = this.planBenefits.filter((plan) => !selectedContractCodes.includes(plan.cntrctCd));

    if (this.planBenefits.length) {
      if (!this.hasSupportedContractCodes()) {
        // To show warning if any unsupported contract codes were existing in the quote.
        this.showInvalidPlansForFundingType(this.formGroup.get('fundingType').value, 'alert');
      }
      this.populateNetworkOptions();
      this.setPlanNameInPlanTable();
    }
  }

  populateExtraCategoryTypeOptions() {
    let options = [...new Set(this.planBenefits.filter((plan) => plan.exCatType).map((plan) => plan.exCatType))].map((val) => ({
      value: val,
      label: ExpandCategoryTypeOptionsLabel[val]
    }));

    this.planDropdownValues = { ...this.planDropdownValues, expandCategoryType: options };
    this.populateVoluntaryIndicatorOptions();
  }

  populateVoluntaryIndicatorOptions() {
    const exCatType = (this.planModalformGroup?.get('expandCategoryType')?.value || []).map((e) => e.trim().toLowerCase());
    let filteredPlanBenefits = this.planBenefits.filter((plan) => (exCatType.length ? exCatType.includes(plan.exCatType.toLowerCase()) : true));
    let options = [...new Set(filteredPlanBenefits.filter((plan) => plan.vlntryInd).map((plan) => plan.vlntryInd))].map((val) => ({
      value: val,
      label: VoluntaryIndicatorOptionsLabel[val]
    }));

    this.planDropdownValues = { ...this.planDropdownValues, voluntaryIndicator: options };
    this.populateContractCodeVision();
  }

  populateNetworkOptions() {
    const state = this.formGroup.get('state').value;
    const filteredPlanBenefits = this.planBenefits.filter((plan) => plan.stCd === state) || [];

    let options = [...new Set(filteredPlanBenefits.filter((plan) => plan.ntwrkName).map((plan) => plan.ntwrkName))].map((val) => ({
      value: val,
      label: val
    }));

    this.planDropdownValues = { ...this.planDropdownValues, networks: options };
    this.populateProdCategory();
  }

  populateProdCategory() {
    const networkSelected = (this.planModalformGroup?.get('networks')?.value || []).map((e) => e.trim().toLowerCase());
    let filteredPlanBenefits = this.planBenefits.filter((plan) => (networkSelected.length ? networkSelected.includes(plan.ntwrkName.toLowerCase()) : true));
    let options = [...new Set(filteredPlanBenefits.filter((plan) => plan.prodCtgryCd).map((plan) => plan.prodCtgryCd))].map((val) => ({
      value: val,
      label: val
    }));

    this.planDropdownValues = { ...this.planDropdownValues, prodCategories: options };
    this.populateProdCode();
  }

  populateProdCode() {
    const networkSelected = (this.planModalformGroup?.get('networks')?.value || []).map((e) => e.trim().toLowerCase());
    const prodCatSelected = (this.planModalformGroup?.get('prodCategories')?.value || []).map((cat) => cat.toLowerCase());

    let filteredPlanBenefits = this.planBenefits
      .filter((plan) => (networkSelected.length ? networkSelected.includes(plan.ntwrkName.toLowerCase()) : true))
      .filter((plan) => (prodCatSelected.length ? prodCatSelected.includes(plan.prodCtgryCd.toLowerCase()) : true));

    let options = [...new Set(filteredPlanBenefits.filter((plan) => plan.prodCd).map((plan) => plan.prodCd))].map((val) => ({
      value: val,
      label: val
    }));

    this.planDropdownValues = { ...this.planDropdownValues, prodCodes: options };
    this.populateContractCode();
  }

  populateContractCodeVision() {
    const exCatTypeSelected = (this.planModalformGroup?.get('expandCategoryType')?.value || []).map((e) => e.trim().toLowerCase());
    const voluntaryIndicatorSelected = (this.planModalformGroup?.get('voluntaryIndicator')?.value || []).map((vi) => vi.toLowerCase());

    let filteredPlanBenefits = this.planBenefits
      .filter((plan) => (exCatTypeSelected.length ? exCatTypeSelected.includes(plan.exCatType.toLowerCase()) : true))
      .filter((plan) => {
        if (voluntaryIndicatorSelected.length) {
          return plan.vlntryInd && voluntaryIndicatorSelected.includes(plan.vlntryInd.toLowerCase());
        }
        return true;
      });

    const lob = this.getLobFromQuote(this.currentDataObj, true);
    let options = [
      ...new Set(filteredPlanBenefits.map((plan) => `${plan.cntrctCd} - ${lob === this.toLobCase(Lob.Vision) ? plan.planCd : plan.planName}`))
    ].map((val) => ({
      value: val,
      label: val
    }));

    this.planDropdownValues = { ...this.planDropdownValues, contractCodes: options };
  }

  populateContractCode() {
    const networkSelected = (this.planModalformGroup?.get('networks')?.value || []).map((e) => e.trim().toLowerCase());
    const prodCatSelected = (this.planModalformGroup?.get('prodCategories')?.value || []).map((cat) => cat.toLowerCase());
    const prodCodeSelected = (this.planModalformGroup?.get('prodCodes')?.value || []).map((cat) => cat.toLowerCase());

    let filteredPlanBenefits = this.planBenefits
      .filter((plan) => (networkSelected.length ? networkSelected.includes(plan.ntwrkName.toLowerCase()) : true))
      .filter((plan) => {
        if (prodCatSelected.length) {
          return plan.prodCtgryCd && prodCatSelected.includes(plan.prodCtgryCd.toLowerCase());
        }
        return true;
      })
      .filter((plan) => {
        if (prodCodeSelected.length) {
          return plan.prodCd && prodCodeSelected.includes(plan.prodCd.toLowerCase());
        }
        return true;
      });

    const lob = this.getLobFromQuote(this.currentDataObj, true);
    let options = [
      ...new Set(filteredPlanBenefits.map((plan) => `${plan.cntrctCd} - ${lob === this.toLobCase(Lob.Vision) ? plan.planCd : plan.planName}`))
    ].map((val) => ({
      value: val,
      label: val
    }));

    this.planDropdownValues = { ...this.planDropdownValues, contractCodes: options };
  }

  populateContractCodesDirectly() {
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    let options = [
      ...new Set(this.planBenefits.map((plan) => `${plan.cntrctCd} - ${lob === this.toLobCase(Lob.Vision) ? plan.planCd : plan.planName}`))
    ].map((val) => ({
      value: val,
      label: val
    }));
    this.planDropdownValues = { ...this.planDropdownValues, contractCodes: options };
  }

  hasSupportedContractCodes() {

    const fundingType = this.formGroup?.get('fundingType')?.value;

    let selectedContractCodes: string[] = this.formGroup
      .get('planTable')
      .getRawValue()
      .map((value) => value.contractCode);

    if (selectedContractCodes.length === 0) {
      return true;
    }

    if ([Lob.Dental, Lob.Vision, Lob.SuppHealth].includes(this.getLobFromQuote(this.currentDataObj))) {
      return true;
    }

    const duplicateCC = selectedContractCodes.filter((cc, index) => selectedContractCodes.indexOf(cc) !== index);
    if (duplicateCC.length) {
      selectedContractCodes = [...new Set(selectedContractCodes)];
    }
    const validPlans =
      this.planBenefitsUnfiltered?.filter(
        (plan) => selectedContractCodes.includes(plan?.cntrctCd) && (plan?.fndngType?.includes(fundingType) || plan.fndngType.includes('ALL'))
      ) || [];

    if (!this.defaultsLoading && !this.planBenefitsUnfiltered.length) {
      return true;
    }

    if (this.isCrossSellingInProcess) {
      return true;
    }

    return validPlans.length === selectedContractCodes.length;
  }

  showInvalidPlansForFundingType(fundingType: string, notifType: 'toast' | 'alert' = 'toast') {
    let messageParams = {
      fundingType: fundingType
    };

    let message = CreateOppScreenMessages.NoSupportContractCodes as string;

    message = this.setMessageStringParams(messageParams, message);

    if (notifType === 'toast') {
      this.messageService.add({ severity: 'error', summary: 'Error', detail: message, life: 5000 });
      this.scrollToErrorSectionOrTable(Sections.Plan);
    } else {
      this.showPopupAlertMessage(message);
    }
  }

  currentCarrierAgeBandCheck(...args) {
    const { subRows, controls, row } = args[0];

    if(row.rateInfo.AGETIERED) {
      controls['_showSubCols'] = new FormControl(true);
      controls['ageBand'] = new FormControl('18-24');
      subRows?.forEach((r) => {
        r.columns.forEach((col) => {
          this.prepareRowFormControl(col, row, controls);
        })
      });
    }
  }

  prepareFormArrayForTable(cols: any[], data: any[], subRows?: any[], subColsRowCheckFn?: string) {
    // Preparing form array for table rows.
    return data.map((row, index) => {
      const rowId = new FormControl(Math.random() + Date.now());
      let controls = { _rowId: rowId };

      cols.forEach((col) => {
        this.prepareRowFormControl(col, row, controls);
      });

      if(subColsRowCheckFn) {
        if(typeof this[subColsRowCheckFn] === 'function') {
          this[subColsRowCheckFn].apply(this, [{
                subRows: subRows,
                controls: controls,
                row: row,
              }
            ]);
        }
      }

      return this.fb.group(controls);
    });
  }

  prepareRowFormControl(col, row, controls) {
    const altPathValue = col.altPath ? this.getValueFromPath(col.altPath, this.currentDataObj) : null;
    const altPathRowValue = col.altPathRow ? this.getValueFromPath(col.altPathRow, row) : null;
    
    let value;
    if ((!col.path || col.path === '') && col.name && row[col.name] !== undefined) {
      value = row[col.name];
    } else {
      value = ((this.getValueFromPath(col.path, row) || altPathValue) || altPathRowValue) ?? '';
    }
    
    let altPathUsed = false;
    if(!this.getValueFromPath(col.path, row) && altPathRowValue) {
      altPathUsed = true;
    }

    if (col.type === 'date') {
      if (!value || value === 'NaN') {
        value = ''; // Set value to empty string if value is empty or NaN
      } else {
        value = moment(value).isValid() ? moment(value).toDate() : value;
      }
    }

    let modifiedValue = undefined;
    if (col?.valueModifier) {
      let valueModifierName = col.valueModifier;

      if (valueModifierName && typeof this[valueModifierName] === 'function') {
        modifiedValue = this[valueModifierName].apply(this, [
          {
            value: value,
            field: col,
            type: 'get'
          }
        ]);
      }
    }
    value = modifiedValue !== undefined ? modifiedValue : value;

    let control = new FormControl({ value, disabled: col.disabled }, col.type === 'readonlyText' ? [] : this.getValidators(col.validators, col));

    if (col.changeHandler) {
      (control as FormControl).valueChanges
        .pipe(
          startWith(value),
          pairwise(),
          filter((_) => !this.blockValueChangeDetection),
          takeUntil(this.destroy$),
          takeUntil(this.quoteChanged$)
        )
        .subscribe(([previousValue, currentValue]) => {
          let handlerName = col.changeHandler;

          if (handlerName && typeof this[handlerName] === 'function') {
            this[handlerName].apply(this, [
              {
                previousValue: previousValue,
                value: currentValue,
                field: col,
                _rowId: controls['_rowId'].value
              }
            ]);
          }
        });
    }

    controls[col.name] = control;

    if(altPathUsed) {
      controls["_altPathUsed_"+col.name] = new FormControl(true);
    }
  }

  getValidators(validators, field?) {
    const formValidators = [];
    if (validators) {
      validators.forEach((validator) => {
        switch (validator.type) {
          case 'required':
            formValidators.push(Validators.required);
            break;
          case 'minLength':
            formValidators.push(Validators.minLength(validator.value));
            break;
          case 'maxLength':
            formValidators.push(Validators.maxLength(validator.value));
            break;
          case 'max':
            formValidators.push(Validators.max(validator.value));
            break;
          case 'min':
            formValidators.push(Validators.min(validator.value));
            break;
          case 'decimalPlaces':
            formValidators.push(this.validateDecimalPlaces(validator.value));
            break;
          case 'zipCode':
            formValidators.push(this.zipCodeValidator());
            break;
          case 'dateFormat':
            formValidators.push(this.validateDateFormat(validator.allowedFormats));
            break;
          case 'censusEligibility':
            const eligibilityOptions = field.options.map((option) => option.value);
            formValidators.push(this.validateDropdownOptions(eligibilityOptions));
            break;
          case 'censusGender':
            const censusGender = field.options.map((option) => option.value);
            formValidators.push(this.validateDropdownOptions(censusGender));
            break;
          case 'censusTier':
            const censusTier = field.options.map((option) => option.value);
            formValidators.push(this.validateDropdownOptions(censusTier));
            break;
          case 'censusRelationship':
            const censusRelationship = field.options.map((option) => option.value);
            formValidators.push(this.validateDropdownOptions(censusRelationship));
            break;
          // add more validators as needed
        }
      });
    }
    return formValidators;
  }

  validateDateFormat(allowedFormats: string[]): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const isValid = allowedFormats.some((format) => {
        const date = moment(control.value, format, true);
        if (format.includes('YYYY')) {
          // Restricting 5 digit years which moment.js considers valid
          return date.isValid() && /^(\d{4})$/.test(date.format('YYYY'));
        }

        return date.isValid();
      });
      return isValid ? null : { invalidDateFormat: true };
    };
  }
  validateDecimalPlaces(decimalPlaces?: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value as string;
      if (control.pristine) {
        return null;
      }

      if (!value.length) {
        return null;
      }

      if (value && !(value + '').includes('.')) {
        return null;
      }

      let finalRegex = new RegExp(`^[0-9]*\\.\\d{1,${decimalPlaces}}$`);
      const isValid = finalRegex.test(value);

      if (isValid) {
        return null; // Validation passes
      } else {
        return { decimalPlaces: true }; // Validation fails
      }
    };
  }

  zipCodeValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      // passing validation if zip api fetch is not complete
      const isValid = this.zipCodes?.some((zip) => zip.zipCd === control.value) ?? true;
      return isValid ? null : { invalidZipCode: true };
    };
  }

  carrierNameChanged(...args) {
    this.populateCurrentPlanOptions();
  }

  calculateTotalCurrRates(...args) {
    for (let tier = 1; tier <= 5; tier++) {
      this.calculateAndSetCurrRates(tier);
    }
  }

  calculateAndSetCurrRates(tier: number) {
    const currentCarrierTable = this.formGroup.get('currentCarrierTable') as FormArray;
    if (currentCarrierTable) {
      currentCarrierTable.controls.forEach((group: FormGroup) => {
        if (Object.keys(group.controls).some((key) => key.includes('CompRates'))) {
          const asoCompRates = parseFloat(group.get(`asoCompRatesT${tier}`).value) || 0;
          const sslCompRates = parseFloat(group.get(`sslCompRatesT${tier}`).value) || 0;
          const mcfCompRates = parseFloat(group.get(`mcfCompRatesT${tier}`).value) || 0;
          const tlCompRates = parseFloat(group.get(`tlCompRatesT${tier}`).value) || 0;
          const aslCompRates = parseFloat(group.get(`aslCompRatesT${tier}`).value) || 0;

          const sum = asoCompRates + sslCompRates + mcfCompRates + tlCompRates + aslCompRates;

          group.get(`currRatesT${tier}`).setValue(sum.toFixed(2));
        }
      });
    } else {
      console.error('currentCarrierTable not found in formGroup');
    }
  }

  memberCountChange(...args) {
    this.enrollmentChange(args, 'memCnt');
  }

  subscriberCountChange(...args) {
    this.enrollmentChange(args, 'sbscrbrCnt');
  }

  enrollmentChange(args, enrollmentCnt) {
    const currentCarrierTable = this.formGroup.get('currentCarrierTable') as FormArray;
    if (currentCarrierTable) {
      currentCarrierTable.controls.forEach((group: FormGroup, index: number) => {
        if (group.get('_rowId').value === args[0]._rowId) {
          const groupId = group.get('id').value;

          let matchingPlan = (this.getValueOfPropertyFromDataObject('currentPlans', this.currentDataObj) ?? []).find((plan) => plan.id === groupId);
          if (!matchingPlan) {
            // If no matching plan is found, consider the index of the current plan
            matchingPlan = this.getValueOfPropertyFromDataObject('currentPlans', this.currentDataObj)[index];
          }
          if (matchingPlan) {
            Object.keys(matchingPlan.rateInfo.TIERED).forEach((key) => {
              if (matchingPlan.rateInfo.TIERED[key].ACTIVE) {
                matchingPlan.rateInfo.TIERED[key].ACTIVE[args[0].field.header][enrollmentCnt] = Number(args[0].value);
              }
            });
          }
        }
      });
    }
    this.updateCurrentCarrierHistory();
  }

  currtCarrierFundingTypeChange(...args) {
    const currentCarrierTable = this.formGroup?.get('currentCarrierTable') as FormArray;
    const currentPlanTableConfig = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');
    if (currentCarrierTable) {
      currentCarrierTable.controls.forEach((group: FormGroup, index: number) => {
        if (group.get('_rowId').value === args[0]._rowId && this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
          let matchingPlan = this.getValueOfPropertyFromDataObject('currentPlans', this.currentDataObj)?.[index];
          

          if (
            group.get('fundingType').value?.toLowerCase() === FundingTypes.ABF.toLowerCase() ||
            group.get('fundingType').value?.toLowerCase() === FundingTypes.ASO.toLowerCase()
          ) {
            let newObj = {};
            currentPlanTableConfig.togglerColumns.forEach((componentColumns) => {
              componentColumns.columns.forEach((col) => {
                if (col.show !== 'false') {
                  if (col.path) {
                    this.createNewObjectWithPath(col.path, newObj);
                    if (col.dynamicPath?.includes('rateInfo')) {
                      // Setting "tier" property for each rates
                      const parentPath = col.path.substring(0, col.path.lastIndexOf('.'));
                      const tierValue = parentPath.substring(parentPath.lastIndexOf('.') + 1, parentPath.length);
                      this.createNewObjectWithPath(parentPath + '.tier', newObj);
                      this.setValueAtPath(parentPath + '.tier', tierValue, newObj);
                    }
                  }
                }

                this.prepareRowFormControl(col, {}, group.controls);
              });
            });
            Object.keys(newObj['rateInfo'].TIERED).forEach((tierKey) => {
              if (!matchingPlan.rateInfo.TIERED[tierKey]) {
                matchingPlan.rateInfo.TIERED[tierKey] = newObj['rateInfo'].TIERED[tierKey];
              } else {
                Object.assign(matchingPlan.rateInfo.TIERED[tierKey], newObj['rateInfo'].TIERED[tierKey]);
              }
            });
            
            // Add _showSubCols control if component rates were just created
            if (!group.get('_showSubCols')) {
              (group as any).addControl('_showSubCols', new FormControl(true));
            }
            
            // When component rates exist, disable only the total rate columns (not tier-specific rates)
            // The tier-specific rate columns (EE, ES, EC, EF) should remain enabled
            if (Object.keys(group.controls).some((key) => key.includes('CompRates'))) {
              Object.keys(group.controls).forEach((ctrlName) => {
                // Only disable the total/summary rate columns, not individual tier rate columns
                if (ctrlName.includes('currRates') && !ctrlName.match(/currRates(EE|ES|EC|EF|EK|E1)/)) {
                  group.controls[ctrlName].setValue('');
                  group.controls[ctrlName].disable();
                }
              });
            }
          } else {
            Object.keys(group.controls).forEach((ctrlName) => {
              if (ctrlName.includes('currRates')) {
                group.controls[ctrlName].enable();
              }
            });
            currentPlanTableConfig.togglerColumns.forEach((componentColumns) => {
              componentColumns.columns.forEach((col) => {
                if (group.controls.hasOwnProperty(col.name)) {
                  group.removeControl(col.name);
                }
              });
            });
            if (Object.keys(matchingPlan.rateInfo.TIERED).length > 1) {
              Object.keys(matchingPlan.rateInfo.TIERED).forEach((key) => {
                if (key !== 'TOT' && key !== 'RENEWAL') {
                  delete matchingPlan.rateInfo.TIERED[key];
                }
              });
            }
          }
        }
      });

      this.updateTogglerButton();
    }
  }

  updateTogglerButton() {
    if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      const currentCarrierTable = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');
      const hasComponentRates = (this.getValueOfPropertyFromDataObject('currentPlans', this.currentDataObj) ?? []).some(
        (currentPlan) => Object.keys(currentPlan.rateInfo.TIERED).filter(key => key !== 'RENEWAL').length > 1
      );
      currentCarrierTable.parentHeaders.forEach((parentHeader) => {
        if (parentHeader.header === 'Current Rates' && hasComponentRates) {
          parentHeader.showToggler = true;
          // Preserve clickHandler property for header menu functionality
          if (!parentHeader.clickHandler) {
            parentHeader.clickHandler = 'componentRatesToggle';
          }
        } else {
          parentHeader.showToggler = false;
        }
      });
    }
  }

  onButtonClicked(eventDetails: any) {
    const { handlerName, event } = eventDetails;

    if (handlerName && typeof this[handlerName] === 'function') {
      if (event) {
        this[handlerName].apply(this, [event]);
        return;
      }

      this[handlerName]();
    }
  }

  removeHistory(quote, isSubmit, altAction: boolean = false) {
    if (this.viewSettings.opportunityType == OpportunityType.RenewalLocal && quote.data.hasOwnProperty('updateHistory') && altAction) {
      delete quote.data.updateHistory;
    }
    if (
      this.viewSettings.opportunityType !== OpportunityType.RenewalLocal &&
      quote.data.hasOwnProperty('updateHistory') &&
      (StringUtils.isEmpty(quote.data?.status) ||
        quote.data?.status == QuoteStatus.NotSubmitted ||
        (quote.data?.status === QuoteStatus.Failed && quote.data?.versionNumber && quote.data?.versionNumber == 1))
    ) {
      delete quote.data.updateHistory;
    }
    if (!isSubmit && quote.data?.status == QuoteStatus.Submitted && quote.data.hasOwnProperty('updateHistory') && quote.data.updateHistory.length) {
      // Keep only the last index
      quote.data.updateHistory = [quote.data.updateHistory[quote.data.updateHistory.length - 1]];
    }
    if (isSubmit && quote.data?.status == QuoteStatus.Submitted && quote.data.hasOwnProperty('updateHistory') && quote.data.updateHistory.length) {
      if (
        Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue).length === 0 &&
        Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.oldValue).length === 0
      ) {
        delete quote.data.updateHistory;
      } else {
        quote.data.updateHistory = [quote.data.updateHistory[quote.data.updateHistory.length - 1]];
      }
    }
    if (
      isSubmit &&
      (quote.data?.status == QuoteStatus.Modified || quote.data?.status == QuoteStatus.Failed) &&
      quote.data.hasOwnProperty('updateHistory') &&
      quote.data.updateHistory.length
    ) {
      if (
        Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue).length === 0 &&
        Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.oldValue).length === 0
      ) {
        quote.data.updateHistory.pop();
      }
    }
    if (
      isSubmit &&
      this.viewSettings.opportunityType == OpportunityType.RenewalLocal &&
      quote.data?.status == QuoteStatus.NotSubmitted &&
      quote.data.hasOwnProperty('updateHistory') &&
      quote.data.updateHistory.length
    ) {
      if (
        Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue).length === 0 &&
        Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.oldValue).length === 0
      ) {
        quote.data.updateHistory.pop();
      }
    }
  }

  async saveQuote(quotesToSave: any[] = [], skipValidation: boolean) {
    quotesToSave = quotesToSave.length ? quotesToSave : [this.currentDataObj];
    if (!skipValidation) {
      quotesToSave.forEach((quote) => this.updateQuoteData(quote));
    }
    
    let areQuotesValid = skipValidation ? true : quotesToSave.map((quote) => this.isValidQuote(quote, false)).includes(false) ? false : true;

    if (areQuotesValid) {
      quotesToSave.forEach((quote) => this.removeHistory(quote, false, skipValidation));
      this.showLoader(true, false);
      let payloadData = quotesToSave;
      let payloadMetaData = payloadData[0].metadata;

      payloadData = payloadData.map((d) => {
        const data = d.data;
        const isNewBusiness = this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal;
        if(isNewBusiness) {
        // Remove quotingType for LG Vision and Dental
        const lob = this.getLobFromQuote(d);
        const marketSegment = data.unifiedPayload?.data?.marketSegment;
        if ((lob === Lob.Vision || lob === Lob.Dental) && marketSegment === MarketSegments.LargeGroup) {
          if (data.unifiedPayload?.data?.quotingType) {
            delete data.unifiedPayload.data.quotingType;
          }
        }
      }
        return data;
      });

      let finalPayloadData = {
        data: { quotes: payloadData },
        metadata: payloadMetaData
      };

      let response = await firstValueFrom(this.createOpportunityService.saveOpportunity(JSON.stringify(finalPayloadData))).then(
        (res) => {
          return res;
        },
        (error) => {
          console.error(error);
          this.setOrRemoveAlertMsg(true, 'Failed to Save quote.', AlertType.Error);
          this.showLoader(false, true);
        }
      );

      if (response) {
        if (this.viewSettings.view !== Views.AltInit) {
          this.showLoader(false, true);
        }
        this.setOrRemoveAlertMsg(true, 'Quote Saved Successfully.', AlertType.Success);
        let metadata = response.metadata;
        let destructuredResponse = response.data.quotes.map((d) => {
          return {
            metadata: metadata,
            data: d
          };
        });

        destructuredResponse.forEach((res) => {
          const responseMrkt = res.data.unifiedPayload.data.marketSegment;
          const responseQId = res.data.quoteHeaderID;
          const responseFundingType = this.getFundingTypeFromObj(res);
          const lob = this.getLobFromQuote(res);
          const responseQuoteIndentifier = `${responseMrkt}-${responseQId}-${responseFundingType}-${lob}`.toLowerCase();
          const saveQuoteIndex = this.data.findIndex((d) => {
            const fundingType = this.getFundingTypeFromObj(d);
            return (
              `${d.data.unifiedPayload.data.marketSegment}-${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() ===
              responseQuoteIndentifier
            );
          });

          const changesIdentifier = `${responseQId}-${responseFundingType}-${lob}`.toLowerCase();
          this.claimsBasisChanges = this.claimsBasisChanges.filter(d=> d.identifier !== changesIdentifier);
          this.groupExpObjectChanges = this.groupExpObjectChanges.filter(d=> d.identifier !== changesIdentifier);
          let dataObj = structuredClone(res);
          if ([Views.Create, Views.AltInit].includes(this.viewSettings.view)) {
            if (!this.getFundingTypeFromObj(this.data[0])) {
              // First object when creating doesn't have funding type defined, replacing with response
              this.data.splice(0, 1);
            }
            if (saveQuoteIndex > -1) {
              this.data[saveQuoteIndex] = dataObj;
            } else {
              this.data.push(dataObj);
            }
          } else {
            this.data[saveQuoteIndex] = dataObj;
          }

          if (this.inCrossSellingMode) {
            const alternateIndices = this.data.reduce(
              (r, value, index) =>
                r.concat(
                  value.data.quoteHeaderID === responseQId &&
                    this.getValueOfPropertyFromDataObject('alternateQuote', value, this.getLobFromQuote(value, true)) === 'Yes'
                    ? index
                    : []
                ),
              []
            );

            alternateIndices.reverse().forEach((index) => {
              this.data.splice(index, 1);
            });
          }
        });

        if (!window.location.search.includes(CreateOppQueryParams.OpportunityId)) {
          // Adding Opportunity ID on url after first quote save
          this.router.navigate([], {
            relativeTo: this.route,
            queryParams: {
              [CreateOppQueryParams.OpportunityId]: this.currentDataObj.data.opportunityID
            },
            queryParamsHandling: 'merge'
          });
        }

        if(this.getLobFromQuote(destructuredResponse[0]) !== Lob.SuppHealth) {
          await this.getAltMarketFundingTypeDetails(destructuredResponse[0]);  
        }

        this.prepareQuotesTable();
        this.editOrViewQuoteDetails({
          quoteTableRowDetails: {
            quoteHeaderId: destructuredResponse[0].data.quoteHeaderID,
            fundingType: destructuredResponse[0].data.fundingType,
            lob: this.getLobFromQuote(destructuredResponse[0])
          }
        });
      }
    }
  }

  async submitQuote() {
    let quote = this.currentDataObj;

    this.updateQuoteData(quote);
    let validity = this.isValidQuote(quote, true);

    if (validity) {
      this.removeHistory(quote, true);
      this.showLoader(true, false);
      this.getSectionOrFieldFromSchema(Sections.QuoteTable).buttons.find((btn) => btn.handler === 'createQuote').disabled = false;
      const isNewBusiness = this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal;
      if (isNewBusiness) {
        // Remove quotingType for LG Vision and Dental before submit
        const lob = this.getLobFromQuote(quote);
        const marketSegment = quote.data.unifiedPayload?.data?.marketSegment;
        if ((lob === Lob.Vision || lob === Lob.Dental) && marketSegment === MarketSegments.LargeGroup) {
          if (quote.data.unifiedPayload?.data?.quotingType) {
            delete quote.data.unifiedPayload.data.quotingType;
          }
        }
      }

      let submissionErrored = false;
      let response = await firstValueFrom(this.createOpportunityService.submitOpportunity(JSON.stringify(quote))).then(
        (response) => {
          return response;
        },
        (error) => {
          submissionErrored = true;
          console.error(error);
          let message: any = 'Quote submission failed.Please resolve the errors and resubmit.  ' + error.error.msg;
          message = message.replaceAll('. ', '.<br/> - ');
          this.setOrRemoveAlertMsg(true, message, AlertType.Error);
        }
      );

      this.showLoader(false, true);
      if (response) {
        this.setOrRemoveAlertMsg(true, 'Quote Submitted Successfully.', AlertType.Success);
        const responseMrkt = response.data.unifiedPayload.data.marketSegment;
        const responseQId = response.data.quoteHeaderID;
        const responseFundingType = this.getFundingTypeFromObj(response);
        const lob = this.getLobFromQuote(response);
        const responseQuoteIndentifier = `${responseMrkt}-${responseQId}-${responseFundingType}-${lob}`.toLowerCase();
        const submittedQuoteIndex = this.data.findIndex((d) => {
          const fundingType = this.getFundingTypeFromObj(d);
          return (
            `${d.data.unifiedPayload.data.marketSegment}-${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() ===
            responseQuoteIndentifier
          );
        });

        const changesIdentifier = `${responseQId}-${responseFundingType}-${lob}`.toLowerCase();
        this.claimsBasisChanges = this.claimsBasisChanges.filter(d => d.identifier !== changesIdentifier);
        this.groupExpObjectChanges = this.groupExpObjectChanges.filter(d => d.identifier !== changesIdentifier);

        let dataObj = structuredClone(response);
        if ([Views.Create, Views.AltInit].includes(this.viewSettings.view)) {
          if (!this.getFundingTypeFromObj(this.data[0])) {
            // First object when creating doesn't have funding type defined, replacing with response
            this.data.splice(0, 1);
          }
          this.data.push(dataObj);
        } else {
          this.data[submittedQuoteIndex] = dataObj;
        }

        if (this.inCrossSellingMode) {
          const alternateIndices = this.data.reduce(
            (r, value, index) =>
              r.concat(
                value.data.quoteHeaderID === responseQId &&
                  this.getValueOfPropertyFromDataObject('alternateQuote', value, this.getLobFromQuote(value, true)) === 'Yes'
                  ? index
                  : []
              ),
            []
          );

          alternateIndices.reverse().forEach((index) => {
            this.data.splice(index, 1);
          });
        }

        if(this.getLobFromQuote(dataObj) !== Lob.SuppHealth) {
          await this.getAltMarketFundingTypeDetails(dataObj);  
        }

        this.prepareQuotesTable();
        this.editOrViewQuoteDetails({
          quoteTableRowDetails: {
            quoteHeaderId: dataObj.data.quoteHeaderID,
            fundingType: dataObj.data.fundingType,
            lob: this.getLobFromQuote(dataObj)
          }
        });
      } else {
        if (submissionErrored) {
          this.showLoader(false, true);

          await firstValueFrom(
            this.createOpportunityService.getUnifiedQuoteDetails(
              this.opportunityID,
              this.currentDataObj.data.quoteHeaderID,
              null,
              this.currentDataObj.data.fundingType,
              this.getValueOfPropertyFromDataObject('marketSegment', quote),
              this.getLobFromQuote(this.currentDataObj)
            )
          ).then((response) => {
            if (response) {
              const responseQId = response.data.quoteHeaderID;
              const responseType = this.getFundingTypeFromObj(response);
              const responseQuoteIndentifier = `${responseQId}-${responseType}`.toLowerCase();
              const submittedQuoteIndex = this.data.findIndex((d) => {
                const fundingType = this.getFundingTypeFromObj(d);
                return `${d.data.quoteHeaderID}-${fundingType}`.toLowerCase() === responseQuoteIndentifier;
              });

              let dataObj = structuredClone(response);
              if ([Views.Create, Views.AltInit].includes(this.viewSettings.view)) {
                if (!this.getFundingTypeFromObj(this.data[0])) {
                  this.data.splice(0, 1);
                }
                this.data.push(dataObj);
              } else {
                this.data[submittedQuoteIndex] = dataObj;
              }
              this.currentDataObj.data = dataObj.data;
              this.updateViewMode(Views.Edit);
              this.prepareQuotesTable();
              this.prepareForm();
            }
          });
        }
      }
    }
  }

  cancelQuote(shouldBuildForm = true) {
    this.updateViewMode(Views.QuoteViewHidden);
    this.selectedLOB = '';
    if (shouldBuildForm) {
      this.prepareForm();
    }
  }

  async createQuote(event: any) {
    this.selectedLOB = event;
    if (this.viewSettings.view === Views.Create) {
      // Already in create mode
      return;
    }

    await this.prepareNewQuote(event);
    this.isNewForm = false;
    this.updateViewMode(Views.Create);
    this.getSectionOrFieldFromSchema(Sections.QuoteTable).buttons.find((b) => b.label === 'Create')['disabled'] = true;
    this.setQuoteSectionHeaderAllLobs();
    this.prepareForm();
  }

  editOrViewQuoteDetails(...args) {
    const { quoteTableRowDetails } = args[0];

    const selectedQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    const selectedQuote = this.data.find((d) => {
      const fundingType = this.getFundingTypeFromObj(d);
      return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === selectedQuoteIndetifier;
    });
    const selectedQuoteOrigin = this.getValueOfPropertyFromDataObject('quoteOrigin', selectedQuote);
    
    const isAltQuote =
      this.getValueOfPropertyFromDataObject('alternateQuote', selectedQuote, this.getLobFromQuote(selectedQuote, true)) === 'Yes' ? true : false;
    this.viewSettings.quoteOrigin = selectedQuoteOrigin;

    if (this.canEditOpp || StringUtils.isEqualIgnoreCase(selectedQuoteOrigin, QuoteOrigin.OppScreen)) {
      this.editQuote({ quoteTableRowDetails });
    } else {
      if (isAltQuote && !this.isReadOnlyUser) {
        // If alternate quote and allowed to edit, view the quote
        this.editQuote({ quoteTableRowDetails });
      } else {
        this.viewQuote({ quoteTableRowDetails });
      }
    }
  }

  viewQuote(...args) {
    const { quoteTableRowDetails } = args[0];
    const selectedQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();

    this.currentDataObj = this.data.find((d) => {
      const fundingType = this.getFundingTypeFromObj(d);
      return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === selectedQuoteIndetifier;
    });

    this.updateViewMode(Views.ReadonlyView);
    this.prepareForm();
  }

  viewQuoteHistory() {
    this.updateViewMode(Views.QuoteHistoryView);
    this.prepareForm();
  }

  editQuote(...args) {
    this.cancelQuote(false);
    this.showLoader(true);
    const { quoteTableRowDetails } = args[0];
    const selectedQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    this.handleEditQuote(selectedQuoteIndetifier);
  }

  async handleEditQuote(selectedQuoteIndetifier) {
    if (this.viewSettings.view !== Views.QuoteViewHidden) {
      const currentQId = this.currentDataObj.data.quoteHeaderID;
      const currentFundingType = this.getFundingTypeFromObj(this.currentDataObj);

      const currentQuoteIndentifier = `${currentQId}-${currentFundingType}-${this.getLobFromQuote(this.currentDataObj)}`.toLowerCase();

      if (this.viewSettings.view === Views.Edit && selectedQuoteIndetifier === currentQuoteIndentifier) {
        return new Promise((res, rej) => res('same quote'));
      }
    }

    this.currentDataObj = this.data.find((d) => {
      const fundingType = this.getFundingTypeFromObj(d);
      return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === selectedQuoteIndetifier;
    });

    this.updateViewMode(Views.Edit);
    this.prepareForm(true);
    this.showLoader(false);
  }

  copyQuote(...args) {
    const { quoteTableRowDetails } = args[0];
    const copyQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    this.handleCopyQuote(copyQuoteIndetifier);
  }

  async deleteQuote(...args) {
    let confirmed = await new Promise((resolve) => {
      this.confirmationService.confirm({
        message: this.data.length == 1 ? CreateOppScreenMessages.LastQuoteDeleteWarning : CreateOppScreenMessages.QuoteDeleteWarning,
        header: 'Confirmation',
        acceptButtonStyleClass: 'dialog-button-icon',
        rejectButtonStyleClass: 'dialog-button-icon',
        accept: () => {
          resolve(true);
        },
        reject: () => {
          resolve(false);
        }
      });
    });

    if (confirmed) {
      const { quoteTableRowDetails } = args[0];
      const deleteQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
      this.handleDeleteQuote(deleteQuoteIndetifier);
    }
  }

  addAlternateQuote(...args) {
    this.cancelQuote(false);
    const { quoteTableRowDetails } = args[0];
    const copyQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    this.handleAltQuote(copyQuoteIndetifier);
  }

  altMarketCross(...args) {
    this.cancelQuote(false);
    const { quoteTableRowDetails } = args[0];
    const copyQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    this.handleAltMarketCross(copyQuoteIndetifier);
  }

  altBoth(...args) {
    this.cancelQuote(false);
    const { quoteTableRowDetails } = args[0];
    const copyQuoteIndetifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    this.handleAltBoth(copyQuoteIndetifier);
  }
  async handleAltBoth(copyQuoteIndetifier: string) {
    this.showLoader(true);
    let altQuotesToSave = await this.altQuotesToSave(copyQuoteIndetifier);
    let altMrktQuotesToSave = await this.getAltMrktQuotesToSave(copyQuoteIndetifier);
    // Merge both arrays into one
    let quotesToSave = [...altQuotesToSave, ...altMrktQuotesToSave];
    this.updateViewMode(Views.AltInit);
    this.saveQuote(quotesToSave, true);
  }

  createDentalMewa(...args) {
    this.cancelQuote(false);
    const { quoteTableRowDetails } = args[0];
    const quoteIdentifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    this.handleSpecialtyMewaQuote(quoteIdentifier, Lob.Dental);
  }
 
  createVisionMewa(...args) {
    this.cancelQuote(false);
    const { quoteTableRowDetails } = args[0];
    const quoteIdentifier = `${quoteTableRowDetails.quoteHeaderId}-${quoteTableRowDetails.fundingType}-${quoteTableRowDetails.lob}`.toLowerCase();
    this.handleSpecialtyMewaQuote(quoteIdentifier, Lob.Vision);
  }
 
  async handleSpecialtyMewaQuote(quoteIdentifier: string, specialtyLob: Lob) {
    let quotesToSave = await this.createSpecialtyMewaQuotesToSave(quoteIdentifier, specialtyLob);
    this.updateViewMode(Views.AltInit);
    this.saveQuote(quotesToSave, true);
  }
 
  private async createSpecialtyMewaQuotesToSave(quoteIdentifier: string, specialtyLob: Lob) {
    this.showLoader(true);
    this.updateViewMode(Views.QuoteViewHidden);
 
    // Find the originating Medical MEWA quote
    let selectedQuote = structuredClone(
      this.data.find((d) => {
        const fundingType = this.getFundingTypeFromObj(d);
        return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === quoteIdentifier.toLowerCase();
      })
    );
 
    // Use the same Quote Header ID as Medical quote
    const newQuoteHeaderID = selectedQuote.data.quoteHeaderID;
 
    // Clear submission metadata
    selectedQuote.data['id'] = '';
    selectedQuote.data['lastSubmittedBy'] = '';
    selectedQuote.data['lastSubmittedTimestamp'] = '';
    selectedQuote.data['lastUpdatedBy'] = '';
    selectedQuote.data['lastUpdatedTimestamp'] = '';
   
    // Clear update history to ensure proper change tracking after first save
    if (selectedQuote.data.hasOwnProperty('updateHistory')) {
      delete selectedQuote.data.updateHistory;
    }
 
    // Create the specialty MEWA quote
    let specialtyMewaQuote = structuredClone(selectedQuote);
    specialtyMewaQuote.data.status = 'Not Submitted';
    specialtyMewaQuote.data.quoteHeaderID = newQuoteHeaderID;
    specialtyMewaQuote.data.unifiedPayload.data.quoteHeaderID = newQuoteHeaderID;
   
    // Change LOB
    specialtyMewaQuote.data.lob = specialtyLob;
    specialtyMewaQuote.data.unifiedPayload.data.productsQuoted = [specialtyLob];
 
    delete specialtyMewaQuote.data.id;
 
    const lobKey = this.toLobCase(specialtyLob);
    const medicalLobKey = this.toLobCase(Lob.Medical);
 
    // Initialize the LOB-specific data structure if it doesn't exist
    if (!specialtyMewaQuote.data.unifiedPayload.data[lobKey]) {
      specialtyMewaQuote.data.unifiedPayload.data[lobKey] = {};
    }
 
    // Inherit association from Medical MEWA
    const associationValue = this.getValueOfPropertyFromDataObject('association', selectedQuote, medicalLobKey);
    this.setValueOfPropertyOfDataObject('association', associationValue, specialtyMewaQuote, lobKey);
 
    // Inherit contract end date from Medical MEWA
    const contractEndDate = this.getValueOfPropertyFromDataObject('contractEndDate', selectedQuote, medicalLobKey);
    this.setValueOfPropertyOfDataObject('contractEndDate', contractEndDate, specialtyMewaQuote, lobKey);
 
    // Set funding type to FI
    this.setFundingTypeForObj(FundingTypes.FI, specialtyMewaQuote);
    this.setValueOfPropertyOfDataObject('fundingType', FundingTypes.FI, specialtyMewaQuote, lobKey);
 
    // Set quoting type to ACA (for Small Group Medical MEWA, Dental/Vision quotes use ACA quoting type)
    this.setValueOfPropertyOfDataObject('quotingType', FundingTypes.ACA, specialtyMewaQuote, lobKey);
 
    // Inherit factor effective date from Medical MEWA quote (don't modify)
    // Note: Alt flow does not modify factorEffectiveDate, it inherits from original quote
 
    // Set market segment to Small Group (default and disabled)
    this.setValueOfPropertyOfDataObject('marketSegment', MarketSegments.SmallGroup, specialtyMewaQuote, lobKey);
    this.setValueOfPropertyOfDataObject('mbs', 'Key', specialtyMewaQuote, lobKey);
 
    // Set input and output tiers to 4 (MEWA default)
    const inputTierField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'inputTier', null, false, lobKey);
    const outputTierField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'outputTier', null, false, lobKey);
    if (inputTierField) {
      this.setValueAtPath(inputTierField.path, 4, specialtyMewaQuote);
    }
    if (outputTierField) {
      this.setValueAtPath(outputTierField.path, 4, specialtyMewaQuote);
    }
 
    // Inherit MBU from Medical MEWA quote
    const medicalMbu = this.getValueOfPropertyFromDataObject('mbu', selectedQuote, medicalLobKey);
    this.setValueOfPropertyOfDataObject('mbu', medicalMbu, specialtyMewaQuote, lobKey);
 
    // Commission will be handled by MEWA preparation logic (lines 910-922)
    // which defaults to '0' at LOB level and removes required validator
    // When plans are added, commission will be set on each plan from form field
 
    // Clear proposed plans - will be populated via Eligibility Service
    this.setValueOfPropertyOfDataObject('proposedPlans', [], specialtyMewaQuote, lobKey);
 
    // Set includeAllPortfolioPlans based on MEWA portfolio setting
    if (!this.commonService.mewaPortfolioEnabled) {
      this.setValueOfPropertyOfDataObject('includeAllPortfolioPlans', 'No', specialtyMewaQuote, lobKey);
    } else {
      this.setValueOfPropertyOfDataObject('includeAllPortfolioPlans', 'Yes', specialtyMewaQuote, lobKey);
    }
 
    // Mark as not an alternate quote
    this.setValueOfPropertyOfDataObject('alternateQuote', 'No', specialtyMewaQuote, lobKey);
 
    // Set quote origin
    this.setValueOfPropertyOfDataObject('quoteOrigin', QuoteOrigin.OppScreen, specialtyMewaQuote, lobKey);
    specialtyMewaQuote.data.quoteOrigin = QuoteOrigin.OppScreen;
 
    // Clear stop loss coverage (not applicable for Dental/Vision)
    this.setValueOfPropertyOfDataObject('stopLossCovg', [], specialtyMewaQuote, lobKey);
 
    // Copy census from Medical and map field property names to Dental/Vision
    const medicalCensus = this.getValueOfPropertyFromDataObject('census', selectedQuote, medicalLobKey) || [];
    const lobPrefix = specialtyLob.toLowerCase().substring(0, 3); // 'den' or 'vis'
   
    const mappedCensus = medicalCensus.map(person => {
      // Create new object with mapped fields
      const mappedPerson = {
        ...person,
        // Map eligibility: medEligibility -> denEligibility/visEligibility
        [`${lobPrefix}Eligibility`]: person.medEligibility || person[`${lobPrefix}Eligibility`],
        // Map tier: medTier -> denTier/visTier
        [`${lobPrefix}Tier`]: person.medTier || person[`${lobPrefix}Tier`],
        // Clear proposed plan selection (keep as array if it was array)
        proposedPlanId: Array.isArray(person.proposedPlanId) ? [] : ''
      };
     
      // Remove old Medical-specific fields
      delete mappedPerson.medEligibility;
      delete mappedPerson.medTier;
     
      return mappedPerson;
    });
   
    this.setValueOfPropertyOfDataObject('census', mappedCensus, specialtyMewaQuote, lobKey);
 
    // Initialize current plans as empty array
    this.setValueOfPropertyOfDataObject('currentPlans', [], specialtyMewaQuote, lobKey);
 
    // Remove Medical LOB data from unified payload since this is now a Dental/Vision quote
    if (specialtyMewaQuote.data.unifiedPayload.data[medicalLobKey]) {
      delete specialtyMewaQuote.data.unifiedPayload.data[medicalLobKey];
    }

    // Delete stopLossCovg and association fields (not applicable for Dental/Vision MEWA)
    // Check both LOB-level and root level
    if (specialtyMewaQuote.data.unifiedPayload.data[lobKey]) {
      delete specialtyMewaQuote.data.unifiedPayload.data[lobKey].stopLossCovg;
      delete specialtyMewaQuote.data.unifiedPayload.data[lobKey].association;
      // Clear Rate Guarantee dates (not applicable for Dental/Vision MEWA)
      delete specialtyMewaQuote.data.unifiedPayload.data[lobKey].rateGuarEffDate;
      delete specialtyMewaQuote.data.unifiedPayload.data[lobKey].rateGuarEndDate;
    }
    // Also delete from root level if present
    if (specialtyMewaQuote.data.unifiedPayload.data.stopLossCovg) {
      delete specialtyMewaQuote.data.unifiedPayload.data.stopLossCovg;
    }
    if (specialtyMewaQuote.data.unifiedPayload.data.association) {
      delete specialtyMewaQuote.data.unifiedPayload.data.association;
    }
    if (specialtyMewaQuote.data.unifiedPayload.data.rateGuarEffDate) {
      delete specialtyMewaQuote.data.unifiedPayload.data.rateGuarEffDate;
    }
    if (specialtyMewaQuote.data.unifiedPayload.data.rateGuarEndDate) {
      delete specialtyMewaQuote.data.unifiedPayload.data.rateGuarEndDate;
    }
 
    // Return as array for batch save
    return [specialtyMewaQuote];
  }

  async handleAltMarketCross(quoteIdentifier: string) {
    let quotesToSave = await this.getAltMrktQuotesToSave(quoteIdentifier);
    this.updateViewMode(Views.AltInit);
    this.saveQuote(quotesToSave, true);
  }

  private async getAltMrktQuotesToSave(quoteIdentifier: string) {
    this.showLoader(true);
    this.updateViewMode(Views.QuoteViewHidden);

    let selectedQuote = structuredClone(
      this.data.find((d) => {
        const fundingType = this.getFundingTypeFromObj(d);
        return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === quoteIdentifier.toLowerCase();
      })
    );
    let updatedRenewalRates
    if (this.getFundingTypeFromObj(selectedQuote) === FundingTypes.ACA) {
      try {
        updatedRenewalRates = await this.getACARenewalRates(selectedQuote);
      } catch (error) {
        console.error('Error in updatedRenewalRates:', error);
      }
    }

    const selectedMarketSegment = this.getValueOfPropertyFromDataObject('marketSegment', selectedQuote);
    const targetMarketSegment = selectedMarketSegment === MarketSegments.SmallGroup ? MarketSegments.LargeGroup : MarketSegments.SmallGroup;
    const matchingQuote = this.data.find((d) => {
      return (
        this.getValueOfPropertyFromDataObject('marketSegment', d, this.getLobFromQuote(d, true)) === targetMarketSegment &&
        this.getValueOfPropertyFromDataObject('oppOrigin', d, this.getLobFromQuote(d, true))?.altMarket === 'altMarket' &&
        this.getValueOfPropertyFromDataObject('alternateQuote', d, this.getLobFromQuote(d, true)) === 'Yes'
      );
    });

    let newQuoteHeaderID;

    if (matchingQuote) {
      newQuoteHeaderID = matchingQuote.data.quoteHeaderID;
    } else {
      // Otherwise, generate a new quoteHeaderID
      newQuoteHeaderID = this.commonService.generateID('QT');
    }

    selectedQuote.data.unifiedPayload.data.quoteHeaderID = newQuoteHeaderID;
    selectedQuote.data['quoteHeaderID'] = newQuoteHeaderID;
    selectedQuote.data['id'] = '';
    selectedQuote.data['lastSubmittedBy'] = '';
    selectedQuote.data['lastSubmittedTimestamp'] = '';
    selectedQuote.data['lastUpdatedBy'] = '';
    selectedQuote.data['lastUpdatedTimestamp'] = '';

    let copiedCrossMrktQuote = structuredClone(selectedQuote);
    copiedCrossMrktQuote.data.status = 'Not Submitted';

    const lob = this.getLobFromQuote(copiedCrossMrktQuote);

    const mktSegment = this.getValueOfPropertyFromDataObject('marketSegment', copiedCrossMrktQuote, this.toLobCase(lob));
    this.setValueOfPropertyOfDataObject('mbs', mktSegment === MarketSegments.SmallGroup ? 'Key' : 'SG', copiedCrossMrktQuote, this.toLobCase(lob));
    this.setValueOfPropertyOfDataObject(
      'marketSegment',
      mktSegment === MarketSegments.SmallGroup ? MarketSegments.LargeGroup : MarketSegments.SmallGroup,
      copiedCrossMrktQuote,
      this.toLobCase(lob)
    );
    this.setValueOfPropertyOfDataObject('alternateQuote', 'Yes', copiedCrossMrktQuote, this.toLobCase(lob));

    const newMarketSegment = this.getValueOfPropertyFromDataObject('marketSegment', copiedCrossMrktQuote, this.toLobCase(lob));

    if ([Lob.Dental, Lob.Vision].includes(lob) && newMarketSegment === MarketSegments.LargeGroup) {
      this.setValueOfPropertyOfDataObject('includeAllPortfolioPlans', 'Yes', copiedCrossMrktQuote, this.toLobCase(lob));

      this.setValueOfPropertyOfDataObject('fiCommission', '10', copiedCrossMrktQuote, this.toLobCase(lob));
      this.setValueOfPropertyOfDataObject('fiCommissionType', 'Percent', copiedCrossMrktQuote, this.toLobCase(lob));

      const rateGuarStartDate = this.getValueOfPropertyFromDataObject('rateGuarEffectiveDate', copiedCrossMrktQuote, this.toLobCase(lob));
      const rateGuarEndDate = moment(rateGuarStartDate).add(24, 'months').subtract(1,'days').format('YYYY-MM-DD');
      this.setValueOfPropertyOfDataObject('rateGuarMonths', '24', copiedCrossMrktQuote, this.toLobCase(lob));
      this.setValueOfPropertyOfDataObject('rateGuarEndDate', rateGuarEndDate, copiedCrossMrktQuote, this.toLobCase(lob));

      let mbu = this.getValueOfPropertyFromDataObject('mbu', copiedCrossMrktQuote, this.toLobCase(lob));

      if (mbu.includes('SG')) {
        mbu = mbu.replace('SG', 'LG');
      }
      this.setValueOfPropertyOfDataObject('mbu', mbu, copiedCrossMrktQuote, this.toLobCase(lob));
    }

    await this.fetchMewaEligibility(newMarketSegment, copiedCrossMrktQuote, this.toLobCase(lob));

    delete copiedCrossMrktQuote.data.id;

    let quotesToSave = [];
    const altMrktFTOptions = await this.getFundingTypeOptions(copiedCrossMrktQuote);

    let options = altMrktFTOptions['Alternate Market'] || [];
    const checkForAltFT = lob !== this.toLobCase(Lob.Medical) ? false : true;
    let fundingTypeOptions = this.getAllowedFundingTypes(copiedCrossMrktQuote, newMarketSegment, checkForAltFT, options).allowedForAltCreation;
    if (this.getFundingTypeFromObj(selectedQuote) === FundingTypes.ACA && !updatedRenewalRates) {
      fundingTypeOptions = fundingTypeOptions.filter(
        type => type !== 'ABF'
      );
      this.setOrRemoveAlertMsg(true, 'ABF alternate creation failed in ACA renewal rate retrieval.', AlertType.Warning);
    }
    for (const newFundingType of fundingTypeOptions) {
      let crossMrktQuote = structuredClone(copiedCrossMrktQuote);
      const originalFundingType = this.getValueOfPropertyFromDataObject('fundingType', crossMrktQuote, this.toLobCase(lob));
      if (
        originalFundingType === FundingTypes.MEWA ||
        originalFundingType === FundingTypes.ACA ||
        (this.toLobCase(lob) === this.toLobCase(Lob.Vision) && newFundingType === FundingTypes.FI) ||
        (this.toLobCase(lob) === this.toLobCase(Lob.Dental) && newFundingType === FundingTypes.FI)
      ) {
        this.setValueOfPropertyOfDataObject('quotingType', 'POOL', crossMrktQuote, this.toLobCase(lob));

        if(originalFundingType === FundingTypes.ACA && newFundingType !== FundingTypes.ABF) {
          this.updateOppOrigin(crossMrktQuote);
        }
      }

      if (newFundingType === FundingTypes.MEWA || newFundingType === FundingTypes.ACA) {
        this.setValueOfPropertyOfDataObject('quotingType', newFundingType, crossMrktQuote, this.toLobCase(lob));
      }

      this.setFundingTypeForObj(newFundingType, crossMrktQuote);

      if (copiedCrossMrktQuote.data.fundingType === FundingTypes.FI && crossMrktQuote.data.fundingType === FundingTypes.ABF) {
        const fields = [
          { original: 'fiCommission', new: 'abfCommission' },
          { original: 'fiCommissionType', new: 'abfCommissionType' }
        ];

        fields.forEach((field) => {
          const originalPath = this.getSectionOrFieldFromSchema(Sections.FundingInfo, field.original, null, false, this.toLobCase(lob)).path;
          const newPath = this.getSectionOrFieldFromSchema(Sections.FundingInfo, field.new, null, false, this.toLobCase(lob)).path;
          const value = this.getValueFromPath(originalPath, copiedCrossMrktQuote);
          this.setValueAtPath(newPath, value, copiedCrossMrktQuote);
        });
      }
      // Handle ACA to ABF conversion - set default commission values for both SG and LG
      if (copiedCrossMrktQuote.data.fundingType === FundingTypes.ACA && crossMrktQuote.data.fundingType === FundingTypes.ABF) {
        const abfCommissionPath = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'abfCommission', null, false, this.toLobCase(lob)).path;
        const abfCommissionTypePath = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'abfCommissionType', null, false, this.toLobCase(lob)).path;
        
        const commissionValue = this.getValueFromPath(abfCommissionPath, crossMrktQuote);
        const commissionType = this.getValueFromPath(abfCommissionTypePath, crossMrktQuote);
        
        if (commissionValue === '0' || commissionValue === 0 || commissionValue === '' || commissionValue === undefined || commissionValue === null) {
          this.setValueAtPath(abfCommissionPath, this.commonService.getDefaultCommissionValue(), crossMrktQuote);
        }
        if (commissionType === '' || commissionType === undefined || commissionType === null) {
          this.setValueAtPath(abfCommissionTypePath, this.commonService.getDefaultCommissionType(), crossMrktQuote);
        }
      }
      if (copiedCrossMrktQuote.data.fundingType === FundingTypes.ABF && crossMrktQuote.data.fundingType === FundingTypes.FI) {
        const fields = [
          { original: 'fiCommission', new: 'abfCommission' },
          { original: 'fiCommissionType', new: 'abfCommissionType' }
        ];

        fields.forEach((field) => {
          const originalPath = this.getSectionOrFieldFromSchema(Sections.FundingInfo, field.new, null, false, this.toLobCase(lob)).path;
          const newPath = this.getSectionOrFieldFromSchema(Sections.FundingInfo, field.original, null, false, this.toLobCase(lob)).path;
          const value = this.getValueFromPath(originalPath, copiedCrossMrktQuote);
          this.setValueAtPath(newPath, value, crossMrktQuote);
        });
      }
      if (updatedRenewalRates && newFundingType === FundingTypes.ABF) {
        this.setValueOfPropertyOfDataObject('currentPlans', this.getValueOfPropertyFromDataObject('currentPlans', updatedRenewalRates, this.toLobCase(lob)), crossMrktQuote, this.toLobCase(lob));
      }
      const proposedPlans = this.getValueOfPropertyFromDataObject('proposedPlans', crossMrktQuote, this.toLobCase(lob));
      const census = this.getValueOfPropertyFromDataObject('census', crossMrktQuote, this.toLobCase(lob));
      const contractCodes = proposedPlans.map((plan) => plan.contractCode || '');
      const [state, contractEffectiveDate, marketSegment, factorEffectiveDate, oppType, zipCode, county, association] = [
        this.getValueOfPropertyFromDataObject('state', crossMrktQuote, this.toLobCase(lob)),
        this.getValueOfPropertyFromDataObject('contractEffectiveDate', crossMrktQuote, this.toLobCase(lob)),
        this.getValueOfPropertyFromDataObject('marketSegment', crossMrktQuote, this.toLobCase(lob)),
        this.getValueOfPropertyFromDataObject('factorEffectiveDate', crossMrktQuote, this.toLobCase(lob)),
        this.getValueOfPropertyFromDataObject('opportunityType', crossMrktQuote, this.toLobCase(lob)),
        this.getValueOfPropertyFromDataObject('companyZipCode', crossMrktQuote, this.toLobCase(lob)),
        this.getValueOfPropertyFromDataObject('county', crossMrktQuote, this.toLobCase(lob)),
        this.getValueOfPropertyFromDataObject('association', crossMrktQuote, this.toLobCase(lob))
      ];

      const details: ContractCodeReplacementDetails = {
        state: state,
        contractEffectiveDate: contractEffectiveDate,
        factorEffectiveDate: factorEffectiveDate,
        marketSegment: marketSegment,
        newFundingType: newFundingType,
        proposedPlansDetails: proposedPlans,
        censusDetails: census,
        contractCodes: contractCodes,
        oppType: oppType,
        zipCode: zipCode,
        county: county,
        association: association
      };

      let oppOrigin = this.getValueOfPropertyFromDataObject('oppOrigin', crossMrktQuote, this.toLobCase(lob)) ?? {};
      oppOrigin = {
        ...oppOrigin,
        altMarket: 'altMarket'
      };

      this.setValueOfPropertyOfDataObject('alternateQuote', 'Yes', crossMrktQuote, this.toLobCase(lob));
      this.setValueOfPropertyOfDataObject('oppOrigin', oppOrigin, crossMrktQuote, this.toLobCase(lob));

      await this.fetchAndReplaceContractCodes(details, false, true, lob);

      quotesToSave.push(crossMrktQuote);
    }
    return quotesToSave;
  }

  requestHistoryQuote() {
    this.isRequestHistory = true;
    this.fetchUnifiedQuoteHistory();
  }

  viewAdjustedHistory() {
    this.fetchAdjHistory();
  }

  fetchAdjHistory() {
    const currentFundingType = this.getFundingTypeFromObj(this.currentDataObj);
    const opportunityID = this.currentDataObj.data.opportunityID;
    const quoteHeaderID = this.currentDataObj.data.quoteHeaderID;
    const quoteHistoryID = this.currentDataObj.data.quoteHistoryID ? this.currentDataObj.data.quoteHistoryID : null;
    const marketSegment = this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj);
    const alternateQuote = this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true));
    this.adjHistoryList = [];

    this.createOpportunityService
      .fetchUnifiedUpdateHistory(
        opportunityID,
        quoteHeaderID,
        currentFundingType,
        quoteHistoryID,
        marketSegment,
        alternateQuote,
        this.getLobFromQuote(this.currentDataObj)
      )
      .subscribe((data) => {
        this.adjHistoryList = data || [];
        this.isAdjHistory = true;
        if (this.adjHistoryList.length) {
          this.adjHistoryList = this.adjHistoryList.map((adjData, index) => {
            adjData['adjNo'] = this.adjHistoryList.length - index;
            return adjData;
          });
          this.adjHistoryList.sort((a, b) => b.adjNo - a.adjNo);
        }
      });
  }

  updateViewMode(currentView) {
    const prevView = this.viewSettings.view;
    if ([Views.Create].includes(prevView)) {
      this.getSectionOrFieldFromSchema(Sections.QuoteTable).buttons.find((b) => b.label === 'Create')['disabled'] = false;
      if (currentView === Views.QuoteViewHidden) {
        this.currentDataObj = structuredClone(this.data[0]);
      }
    }
    this.viewSettings.view = currentView;
    this.inCrossSellingMode = false;
  }

  checkAllClicked(...args) {
    const section = args[0];

    const sectionFormArray = this.formGroup.get(section) as FormArray;
    sectionFormArray.controls.forEach((group) => {
      group.get('checkbox').patchValue(true);
    });
  }

  fetchUnifiedQuoteHistory() {
    const currentFundingType = this.getFundingTypeFromObj(this.currentDataObj);
    const opportunityID = this.currentDataObj.data.opportunityID;
    const quoteHeaderID = this.currentDataObj.data.quoteHeaderID;
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    const marketSegment = this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj);
    const alternateQuote = this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, lob);

    this.quoteHistoryList = [];

    this.createOpportunityService
      .fetchUnifiedQuoteHistory(opportunityID, quoteHeaderID, currentFundingType, marketSegment, alternateQuote, this.getLobFromQuote(this.currentDataObj))
      .subscribe((data) => {
        this.quoteHistoryList = data || [];
        this.sortQuoteHistoryList();
      });
  }

  sortQuoteHistoryList() {
    this.quoteHistoryList.sort((a, b) => b.versionNumber - a.versionNumber);
  }

  navigateToParticularQuoteDetails(opportunityData) {
    const url = this.router.serializeUrl(
      this.router.createUrlTree(['opportunity/create-opportunity-new'], {
        queryParams: {
          opportunityID: this.opportunityID,
          quoteId: opportunityData.quoteHeaderID,
          quoteHistoryId: opportunityData.quoteHistoryID,
          fundingType: opportunityData.fundingType,
          marketSegment: opportunityData?.marketSegment,
          isLoginAgain: true,
          lob: opportunityData.lob
        }
      })
    );

    localStorage.setItem('quoteHeaderID', opportunityData.quoteHeaderID);
    localStorage.setItem('opportunityID', this.opportunityID);
    localStorage.setItem('lob', opportunityData.lob);
    localStorage.setItem('fundingType', opportunityData.fundingType);
    localStorage.setItem('insertedTimestamp', opportunityData.insertedTimestamp);
    localStorage.setItem('quoteHistoryId', opportunityData.quoteHistoryID);
    localStorage.setItem('marketSegment', opportunityData?.marketSegment);
    localStorage.setItem('isLoginAgain', 'true');
    localStorage.setItem('assignedUserRoles', this.authService.getUserRole());
    localStorage.setItem('assignedUserRolesTextToDisplay', this.authService.getUserRoleTextToDisplay());
    localStorage.setItem('assignedUserLobs', this.authService.getUserLob());
    localStorage.setItem('assignedUserStates', this.authService.getUserState());

    window.open(url, '_blank');
  }

  setStatus(opportunityData): string {
    if (opportunityData.status === 'Submitted' && opportunityData.submittedStatus) {
      return opportunityData.status + ' ( ' + opportunityData.submittedStatus + ' )';
    }
    return opportunityData.status;
  }

  async handleCopyQuote(quoteIdentifier: string) {
    let selectedQuote = structuredClone(
      this.data.find((d) => {
        const fundingType = this.getFundingTypeFromObj(d);
        return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === quoteIdentifier.toLowerCase();
      })
    );

    this.showLoader(true);
    const idResult = await this.getQuoteAndOppId();

    selectedQuote.data['quoteHeaderID'] = idResult.quoteHeaderID;
    selectedQuote.data.unifiedPayload.data['quoteHeaderID'] = idResult.quoteHeaderID;

    selectedQuote.data['opportunityID'] = this.opportunityID;
    selectedQuote.data.unifiedPayload.data['opportunityID'] = this.opportunityID;
    this.setValueOfPropertyOfDataObject('quoteOrigin', QuoteOrigin.OppScreen, selectedQuote);

    if (selectedQuote.data.status === 'Submitted' || selectedQuote.data.status === 'Modified') {
      selectedQuote.data.status = 'Not Submitted';
    }

    //removing the submitted fields while copying the quote
    selectedQuote.data['lastSubmittedBy'] = '';
    selectedQuote.data['lastSubmittedTimestamp'] = '';
    selectedQuote.data['lastUpdatedBy'] = '';
    selectedQuote.data['lastUpdatedTimestamp'] = '';

    this.getSectionOrFieldFromSchema(Sections.GroupInfo).fields.forEach((field) => {
      const value = this.getValueFromPath(field.path, selectedQuote);
      this.setValueAtPath(field.path, value, selectedQuote);
    });

    delete selectedQuote.data.id;
    selectedQuote = { ...selectedQuote };

    this.setValueOfPropertyOfDataObject('quoteOrigin', QuoteOrigin.OppScreen, selectedQuote);
    selectedQuote.data.quoteOrigin = QuoteOrigin.OppScreen;
    if (selectedQuote.data.hasOwnProperty('updateHistory')) {
      delete selectedQuote.data.updateHistory;
    }

    this.showLoader(true, false);
    this.createOpportunityService.cloneQuote(selectedQuote).subscribe(
      (response) => {
        if (response) {
          this.setOrRemoveAlertMsg(true, 'Quote Copied Successfully.', AlertType.Success);
          this.data.push(response);
          this.currentDataObj = response;
          this.updateViewMode(Views.Edit);
          this.prepareQuotesTable();
          this.prepareForm();
          this.showLoader(false, true);
        } else {
          this.setOrRemoveAlertMsg(true, 'Failed to Copy Quote.', AlertType.Error);
          this.showLoader(false, true);
          console.error('Failed to copy quote:', response);
        }
      },
      (error) => {
        console.error(error);
        this.setOrRemoveAlertMsg(true, 'Failed to copy quote.', AlertType.Error);
        this.showLoader(false, true);
      }
    );
  }

  handleDeleteQuote(quoteIdentifier) {
    const selectedQuote = this.data.find((d) => {
      const fundingType = this.getFundingTypeFromObj(d);
      return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === quoteIdentifier.toLowerCase();
    });

    this.showLoader(true, false);
    this.createOpportunityService.deleteQuote(selectedQuote).subscribe(
      (response) => {
        this.setOrRemoveAlertMsg(true, 'Successfully deleted quote.', AlertType.Success);
        if (this.data.length == 1) {
          this.router.navigate(['/opportunity']);
        } else {
          this.data = this.data.filter((d) => {
            const fundingType = this.getFundingTypeFromObj(d);
            return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() !== quoteIdentifier.toLowerCase();
          });

          this.updateViewMode(Views.QuoteViewHidden);
          this.currentDataObj = structuredClone(this.data[0]);
          this.prepareQuotesTable();
          this.prepareForm();
        }
        this.showLoader(false, true);
      },
      (error) => {
        console.error(error);
        this.setOrRemoveAlertMsg(true, 'Failed to delete quote.', AlertType.Error);
        this.showLoader(false, true);
      }
    );
  }

  async handleAltQuote(quoteIdentifier: string) {
    let quotesToSave = await this.altQuotesToSave(quoteIdentifier);

    this.updateViewMode(Views.AltInit);
    this.saveQuote(quotesToSave, true);
  }

  private async altQuotesToSave(quoteIdentifier: string) {
    this.showLoader(true);
    this.updateViewMode(Views.QuoteViewHidden);

    let selectedQuote = structuredClone(
      this.data.find((d) => {
        const fundingType = this.getFundingTypeFromObj(d);
        return `${d.data.quoteHeaderID}-${fundingType}-${this.getLobFromQuote(d)}`.toLowerCase() === quoteIdentifier.toLowerCase();
      })
    );
    let updatedRenewalRates
    if (this.getFundingTypeFromObj(selectedQuote) === FundingTypes.ACA) {
      try {
        updatedRenewalRates = await this.getACARenewalRates(selectedQuote);
      } catch (error) {
        console.error('Error in updatedRenewalRates:', error);
      }
    }
    //removing the submitted fields while copying the quote
    selectedQuote.data['id'] = '';
    selectedQuote.data['lastSubmittedBy'] = '';
    selectedQuote.data['lastSubmittedTimestamp'] = '';
    selectedQuote.data['lastUpdatedBy'] = '';
    selectedQuote.data['lastUpdatedTimestamp'] = '';

    let copiedAltQuote = structuredClone(selectedQuote);

    copiedAltQuote.data.status = 'Not Submitted';

    const originalFundingType = this.getFundingTypeFromObj(copiedAltQuote);
    const marketSegment = this.getValueOfPropertyFromDataObject('marketSegment', copiedAltQuote);
    const lob = this.getLobFromQuote(copiedAltQuote, true);
    delete copiedAltQuote.data.id;
    this.setValueOfPropertyOfDataObject('alternateQuote', 'Yes', copiedAltQuote, lob);
    this.setValueOfPropertyOfDataObject('quoteOrigin', QuoteOrigin.OppScreen, copiedAltQuote, lob);
    copiedAltQuote.data.quoteOrigin = QuoteOrigin.OppScreen;

    let quotesToSave = [];
    let availableFundingTypes = this.getAllowedFundingTypes(copiedAltQuote, marketSegment, true, [], true).options.filter(
      (x) => x !== this.getFundingTypeFromObj(copiedAltQuote)
    );
    if (this.getFundingTypeFromObj(selectedQuote) === FundingTypes.ACA && !updatedRenewalRates) {
      availableFundingTypes = availableFundingTypes.filter(
        type => type !== 'ABF'
      );
      this.setOrRemoveAlertMsg(true, 'ABF alternate creation failed in ACA renewal rate retrieval.', AlertType.Warning);
    }
    for (const newFundingType of availableFundingTypes) {
      let altQuote = structuredClone(copiedAltQuote);

      this.setFundingTypeForObj(newFundingType, altQuote);

      const abfCommissionField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'abfCommission');
      const fiCommissionField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fiCommission');
      const abfCommissionTypeField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'abfCommissionType');
      const fiCommissionFTypeield = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fiCommissionType');

      switch (newFundingType) {
        case FundingTypes.ABF: {
          if (originalFundingType === FundingTypes.FI || originalFundingType === FundingTypes.ACA || originalFundingType === FundingTypes.MEWA) {
            const commValueOriginalPath = fiCommissionField.path;
            const commValueNewPath = abfCommissionField.path;
            const commTypeOriginalPath = fiCommissionFTypeield.path;
            const commTypeNewPath = abfCommissionTypeField.path;

            const commisionValue = this.getValueFromPath(commValueOriginalPath, altQuote);
            this.setValueAtPath(commValueNewPath, commisionValue, altQuote);

            const commTypeValue = this.getValueFromPath(commTypeOriginalPath, altQuote);
            this.setValueAtPath(commTypeNewPath, commTypeValue, altQuote);

           if (originalFundingType === FundingTypes.ACA) {

            this.setValueOfPropertyOfDataObject('quotingType', 'POOL', altQuote, lob);
            if(commisionValue === '0' || commisionValue === 0 || commisionValue === '' || commisionValue === undefined || commisionValue === null ){
              this.setValueAtPath(commValueNewPath, this.commonService.getDefaultCommissionValue(), altQuote);
            }
            if(commTypeValue === '' || commTypeValue === undefined || commTypeValue === null){
              this.setValueAtPath(commTypeNewPath, this.commonService.getDefaultCommissionType(), altQuote);
            }
            }
 
            if (originalFundingType === FundingTypes.MEWA) {
              this.setValueOfPropertyOfDataObject('quotingType', 'POOL', altQuote, lob);
            }
            if (updatedRenewalRates) {
              this.setValueOfPropertyOfDataObject('currentPlans', this.getValueOfPropertyFromDataObject('currentPlans', updatedRenewalRates, lob), altQuote, lob);
            }
          }
          break;
        }

        case FundingTypes.FI: {
          if (originalFundingType === FundingTypes.ABF) {
            const commValueOriginalPath = abfCommissionField.path;
            const commValueNewPath = fiCommissionField.path;
            const commTypeOriginalPath = abfCommissionTypeField.path;
            const commTypeNewPath = fiCommissionFTypeield.path;

            const commisionValue = this.getValueFromPath(commValueOriginalPath, altQuote);
            this.setValueAtPath(commValueNewPath, commisionValue, altQuote);

            const commTypeValue = this.getValueFromPath(commTypeOriginalPath, altQuote);
            this.setValueAtPath(commTypeNewPath, commTypeValue, altQuote);
          } else if (originalFundingType === FundingTypes.ACA) {
            this.updateOppOrigin(altQuote);
          }

          break;
        }

        case FundingTypes.MEWA: {
          const inputTierField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'inputTier');
          const outputTierField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'outputTier');
          this.setValueAtPath(inputTierField.path, 4, altQuote);
          this.setValueAtPath(outputTierField.path, 4, altQuote);

          const contEndDateField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'contractEndDate');
          const associationValue = this.quoteMEWADetails.get(altQuote.data.quoteHeaderID)?.associationDetails?.[0]?.assnCd ?? '';

          this.setValueOfPropertyOfDataObject('association', associationValue, altQuote, lob);
          this.setValueOfPropertyOfDataObject(
            'contractEndDate',
            this.quoteMEWADetails.get(altQuote.data.quoteHeaderID)['contractEndDate'][associationValue],
            altQuote,
            lob
          );
          this.setValueOfPropertyOfDataObject('quotingType', FundingTypes.MEWA, altQuote, lob);
          this.setValueOfPropertyOfDataObject('stopLossCovg', [], altQuote, lob);
          if (!this.commonService.mewaPortfolioEnabled) {
            this.setValueOfPropertyOfDataObject('includeAllPortfolioPlans', 'No', altQuote, lob);
          }

          if (originalFundingType === FundingTypes.ACA) {
            this.updateOppOrigin(altQuote);
          }


          break;
        }

        case FundingTypes.ACA: {
          this.setValueOfPropertyOfDataObject('quotingType', FundingTypes.ACA, altQuote, lob);
          break;
        }
      }

      // Plan Contract code remapping

      let proposedPlans = this.getValueOfPropertyFromDataObject('proposedPlans', altQuote, lob);
      const census = this.getValueOfPropertyFromDataObject('census', altQuote);

      const contractCodes = proposedPlans.map((plan) => plan.contractCode || '');

      const [state, contractEffectiveDate, marketSegment, factorEffectiveDate, oppType, zipCode, county, association] = [
        this.getValueOfPropertyFromDataObject('state', selectedQuote, lob),
        this.getValueOfPropertyFromDataObject('contractEffectiveDate', selectedQuote, lob),
        this.getValueOfPropertyFromDataObject('marketSegment', selectedQuote, lob),
        this.getValueOfPropertyFromDataObject('factorEffectiveDate', selectedQuote, lob),
        this.getValueOfPropertyFromDataObject('opportunityType', selectedQuote, lob),
        this.getValueOfPropertyFromDataObject('companyZipCode', selectedQuote, lob),
        this.getValueOfPropertyFromDataObject('county', selectedQuote, lob),
        this.getValueOfPropertyFromDataObject('association', selectedQuote, lob)
      ];

      const details: ContractCodeReplacementDetails = {
        state: state,
        contractEffectiveDate: contractEffectiveDate,
        factorEffectiveDate: factorEffectiveDate,
        marketSegment: marketSegment,
        newFundingType: newFundingType,
        proposedPlansDetails: proposedPlans,
        censusDetails: census,
        contractCodes: contractCodes,
        oppType: oppType,
        zipCode: zipCode,
        county: county,
        association: association
      };
      await this.fetchAndReplaceContractCodes(details, false, false, lob);

      quotesToSave.push(altQuote);
    }

    return quotesToSave;
  }

  async getACARenewalRates(selectedQuote) {
    try {
      const response = await firstValueFrom(this.createOpportunityService.addRenewalRates(selectedQuote));
      return response;

    } catch (error) {
      console.error('Error in commonMethod:', error);
      throw error; // optional
    }
  }


  fetchReplacementContactCodes(
    contractCodes: any[],
    state,
    contractEffectiveDate,
    marketSegment: string,
    newFundingType: string,
    lob: string,
    oppType: string,
    altMarket: boolean = false,
    zipCode,
    county,
    effectiveDate,
    association,
    opportunityID: any,
    quoteHeaderId: any
  ): Observable<any> {
    return this.createOpportunityService.fetchReplacementContactCodes(
      contractCodes,
      newFundingType,
      marketSegment,
      state,
      contractEffectiveDate,
      lob,
      oppType,
      altMarket,
      zipCode,
      county,
      effectiveDate,
      association,
      opportunityID,
      quoteHeaderId 
    );
  }

  getFundingTypeFromObj(obj: any) {
    const { path } = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType');
    return this.getValueFromPath(path, obj);
  }

  setFundingTypeForObj(value: string, obj: any) {
    const { path } = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType');
    this.setValueAtPath(path, value, obj);
  }

  getFundingTypeOptionsFromSchema(quoteKey, marketSegmentSchemaKey, lob) {
    const schema = this.schemaDetails[lob];
    return schema.fundingTypesAllowed[quoteKey][marketSegmentSchemaKey];
  }

  setFundingTypeDropdownOptions(marketSegment) {
    const fundingTypeOptions = this.getAllowedFundingTypes(this.currentDataObj, marketSegment, this.viewSettings.isAltQuote).options;
    const currentFTValue = this.formGroup ? this.formGroup.get('fundingType').value : null;
    const fundingTypeField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType');
    fundingTypeField.options = fundingTypeOptions.map((ftValue) => {
      return { label: ftValue, value: ftValue };
    });

    if (this.formGroup && currentFTValue) {
      if (!fundingTypeOptions.includes(currentFTValue)) {
        this.formGroup.get('fundingType').setValue(fundingTypeOptions[0]);
      }
    }
  }

  getAllowedFundingTypes(
    quote,
    marketSegment,
    checkingForAlternateQuote,
    checkingForAlternateMarketQuoteOptions: any = [],
    isAltQuoteSaveAction: boolean = false
  ) {
    const marketSegmentSchemaKey = `marketSegment${marketSegment}`;
    const quoteKey = checkingForAlternateQuote ? 'alternateQuote' : 'originalQuote';
    const lob = this.getLobFromQuote(quote, true);
    const isAlt = this.getValueOfPropertyFromDataObject('alternateQuote', quote, lob) === 'Yes' ? true : false;
    const fundingType = this.getFundingTypeFromObj(quote);
    let options;
    if (this.checkStateAltMrktElgibility(quote) && checkingForAlternateMarketQuoteOptions.length > 0) {
      options = checkingForAlternateMarketQuoteOptions;
      // options = this.getFundingTypeOptionsFromSchema(quoteKey, marketSegmentSchemaKey, lob);
    } else {
      if (!isAltQuoteSaveAction) {
        options = this.getFundingTypeOptionsFromSchema(quoteKey, marketSegmentSchemaKey, lob);
      } else {
        options = this.getElgibleAltFundingTypeOptions(fundingType, marketSegment);
      }
    }

    if (options.includes(FundingTypes.MEWA)) {
      const isMewaAllowed = this.quoteMEWADetails.get(quote.data.quoteHeaderID)?.mewaEligible;
      if (!isMewaAllowed || (!isAlt && this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal && !this.createMEWAEnabled)) {
        options = options.filter((ft) => ft !== FundingTypes.MEWA);
      }
    }

    const allowedForAltCreation = options;

    return {
      options,
      allowedForAltCreation
    };
  }

  getElgibleAltFundingTypeOptions(fundingType, marketSegment) {
    if (fundingType && marketSegment && this.eligibleAlternates.length > 0) {
      // Find the eligible alternate object
      const eligibleAlt = this.eligibleAlternates.find(
        (alt) => alt.fndngType === fundingType && typeof alt.attrValue === 'string' && alt.attrValue.includes(marketSegment)
      );
      if (eligibleAlt && typeof eligibleAlt.setAttrValue === 'string') {
        // Split setAttrValue by '|' and filter out empty strings
        return eligibleAlt.setAttrValue.split('|').filter((v) => v);
      }
      return [];
    }
    return [];
  }

  async fundingTypeChange(...args) {
    const { value, previousVal, field } = args[0];
    const isAltQuote =
      this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true)) === 'Yes' ? true : false;
    let commissionValue, commissionTypeValue, commissionValueTarget, commissionTypeValueTarget;

    if (!isAltQuote) {
      const marketSegment = this.formGroup.get('marketSegment').value;
      const existingFundingTypes = this.data
        .filter(
          (f) => f.data.quoteHeaderID === this.currentDataObj.data.quoteHeaderID && this.getValueOfPropertyFromDataObject('marketSegment', f) === marketSegment
        )
        .map((ft) => ft.data.fundingType);
      const currentObjFT = this.getFundingTypeFromObj(this.currentDataObj);
      if (existingFundingTypes.includes(value) && currentObjFT !== value) {
        let messageParams = {
          fundingType: value
        };

        this.showPopupAlertMessage(this.setMessageStringParams(messageParams, CreateOppScreenMessages.FundingTypeAlreadyExistForQuote as string));
        this.blockValueChangeDetection = true;
        this.formGroup.get(field.name).setValue(previousVal);
        this.formGroup.get(field.name).updateValueAndValidity();
        this.blockValueChangeDetection = false;
        return;
      }
    }

    if (previousVal === FundingTypes.ABF) {
      commissionValue = this.formGroup.get('abfCommission')?.value;
      commissionTypeValue = this.formGroup.get('abfCommissionType')?.value;
      commissionValueTarget = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fiCommission')?.name;
      commissionTypeValueTarget = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fiCommissionType')?.name;
    } else if (previousVal === FundingTypes.FI) {
      commissionValue = this.formGroup.get('fiCommission')?.value;
      commissionTypeValue = this.formGroup.get('fiCommissionType')?.value;
      commissionValueTarget = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'abfCommission')?.name;
      commissionTypeValueTarget = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'abfCommissionType')?.name;
    }

    await this.prepareQuoteDetailSections(value);
    await this.prepareFundingType(value, true);

    this.formGroup.get(commissionValueTarget)?.setValue(commissionValue);
    this.formGroup.get(commissionValueTarget)?.updateValueAndValidity();
    this.formGroup.get(commissionTypeValueTarget)?.setValue(commissionTypeValue);
    this.formGroup.get(commissionTypeValueTarget)?.updateValueAndValidity();

    this.populateQuoteAndFundingInfoOptions();
  }

  async initializeFundingType() {
    const value = this.formGroup.get('fundingType').value;
    
    // Disable funding type field on creation for Vision, Dental, and Supp Health
    const lob = this.getLobFromQuote(this.currentDataObj);
    const quoteStatus = this.currentDataObj.data.status;
    
    if ([Lob.Vision, Lob.Dental, Lob.SuppHealth].includes(lob) && this.viewSettings.view === Views.Create && this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal) {
      this.formGroup.get('fundingType').disable();
      this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType')['disabled'] = true;;
    }
    
    
    this.prepareFundingType(value);
  }

  async initializeQuotingType(...args) {
    const { field } = args[0];
    const value = this.formGroup.get('quotingType').value;
    
    const lob = this.getLobFromQuote(this.currentDataObj);
    
    // For New Business Vision, Dental, and Supp Health - show only if value exists
    if ([Lob.Vision, Lob.Dental, Lob.SuppHealth].includes(lob) && this.viewSettings.view === Views.Create && this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal) {
      if (value) {
        // Show and disable if value exists
        field.show = 'true';
        this.formGroup.get('quotingType').disable();
        this.quoteFieldsToUpdate[field.name] = {
          path: field.path,
          name: field.name,
          label: field.label,
          type: field.type,
          columns: field.columns ?? null
        };
      } else {
        // Hide if no value
        field.show = 'false';
        delete this.quoteFieldsToUpdate[field.name];
      }
    } else {
      // For other scenarios, show and enable
      field.show = 'false';
      this.formGroup.get('quotingType').disable();
      this.quoteFieldsToUpdate[field.name] = {
        path: field.path,
        name: field.name,
        label: field.label,
        type: field.type,
        columns: field.columns ?? null
      };
    }
  }

  async prepareFundingType(value, fromChangeHandler = false) {
    let originalFundingType;

    if (this.viewSettings.isAltQuote) {
      originalFundingType = this.getFundingTypeFromObj(
        this.data.find(
          (d) =>
            d.quoteHeaderID === this.currentDataObj.quoteHeaderID &&
            ['No', undefined].includes(this.getValueOfPropertyFromDataObject('alternateQuote', d, this.getLobFromQuote(d, true)))
        )
      );
    }

    if (fromChangeHandler && this.planBenefitsUnfiltered !== undefined && !this.hasSupportedContractCodes()) {
      this.showInvalidPlansForFundingType(value, 'alert');
    }
    await this.changeFundingInfoFields(value);
    await this.prepareQuoteType(value);

    return new Promise((resolve) => {
      resolve('Funding Type prepared');
    });
  }

  async changeFundingInfoFields(value) {
    let fundingSection = this.getSectionOrFieldFromSchema(Sections.FundingInfo);
    const state = this.formGroup.get('state').value;

    const fieldsToAdd = fundingSection.fields.filter(
      (field) => field.dependantField === 'fundingType' && field.dependantFieldValue === value && !field.showOverride
    );

    const fieldsToAddNames = fieldsToAdd.map((f) => f.name);

    const fieldsToRemove = fundingSection.fields.filter((field) => !fieldsToAddNames.includes(field.name) && field.name !== 'fundingType');

    fieldsToAdd.forEach((field) => {
      let fieldValue = this.getValueFromPath(field.path, this.currentDataObj) || field.defaultValue || '';
      this.formGroup.addControl(field.name, new FormControl(fieldValue, this.getValidators(field.validators)));
      field.show = 'true';
      this.quoteFieldsToUpdate[field.name] = { path: field.path, name: field.name, type: field.type, label: field.label, columns: field.columns ?? null };
    });

    fieldsToRemove.forEach((field) => {
      this.formGroup.removeControl(field.name);
      field.show = 'false';
      delete this.quoteFieldsToUpdate[field.name];
    });

    if (this.getLobFromQuote(this.currentDataObj) === Lob.Medical) {
      // Disabling / Enabling MEWA Medicare checkbox
      const isFormLoad = this.formGroup ? true : false;
      this.checkMedicareFieldEligibility(state, isFormLoad);
    }
    return;
  }

  async prepareQuoteType(fundingType) {
    const stateCode = this.formGroup.get('state').value;
    const marketSegment = this.formGroup.get('marketSegment').value;
    const contractEffectiveDate = moment(this.formGroup.get('contractEffectiveDate').value).format('YYYY-MM-DD');
    const factorEffectiveDate = moment(this.formGroup.get('factorEffectiveDate').value).format('YYYY-MM-DD');

    const cacheCode = this.generateCacheCodeString();

    let response;
    await this.createOpportunityService
      .fetchQuoteTypes(cacheCode, stateCode, contractEffectiveDate, factorEffectiveDate, marketSegment)
      .toPromise()
      .then((data) => {
        response = data;
      });

    if (response) {
      this.setQuoteTypes(response, fundingType);
    }
  }

  setQuoteTypes(list, fundingType) {
    const marketSegment = this.formGroup.get('marketSegment').value;

    let options = [
      ...new Set(list.filter((e) => e.fndngType.includes(fundingType) && (e.mbs.includes('ALL') || e.mbs.includes(marketSegment))).map((qt) => qt.quoteType))
    ].map((opt) => {
      return {
        label: opt,
        value: opt
      };
    });

    const quoteTypeField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'specialQuoteType');

    if (quoteTypeField && options.length) {
      quoteTypeField.options = options;
      quoteTypeField.show = 'true';
      this.quoteFieldsToUpdate[quoteTypeField.name] = {
        path: quoteTypeField.path,
        name: quoteTypeField.name,
        type: quoteTypeField.type,
        label: quoteTypeField.label,
        columns: quoteTypeField.columns ?? null
      };
      let fieldValue = this.getValueFromPath(quoteTypeField.path, this.currentDataObj) ?? quoteTypeField.defaultValue ?? [];
      this.formGroup.addControl(quoteTypeField.name, new FormControl(fieldValue, this.getValidators(quoteTypeField.validators)));
    } else {
      if (quoteTypeField?.show === 'true') {
        quoteTypeField.show = 'false';
        this.formGroup.removeControl(quoteTypeField.name);
        delete this.quoteFieldsToUpdate[quoteTypeField.name];
      }
    }
  }

  addHistoryObj(quote: any): any {
    if (!quote.data.hasOwnProperty('updateHistory')) {
      quote.data['updateHistory'] = [];
    }
    if (quote.data.updateHistory.every((history) => history?.adjustmentId)) {
      quote.data.updateHistory.push({
        changeSetDetail: {
          adjustmentData: {
            oldValue: {},
            newValue: {}
          }
        },
        updatedBy: this.authService.getUserName()
      });
    }
  }

  updateQuoteData(quote: any): any {
    this.addHistoryObj(quote);
    const updatedValues = this.formGroup.getRawValue();
    if (this.getLobFromQuote(quote) === Lob.Medical) {
      if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
        if (this.formGroup.get('fundingType').value === FundingTypes.FI) {
          const stopLossCovgPath = this.getPathOfProperty('stopLossCovg');
          const stopLossCoverageArr = this.getValueFromPath(stopLossCovgPath, quote);
          if (Array.isArray(stopLossCoverageArr) && stopLossCoverageArr.length) {
            delete stopLossCoverageArr[0]['sslDeductible'];
            delete stopLossCoverageArr[0]['aggSLCorridor'];
            delete stopLossCoverageArr[0]['surplusRefund'];
          }
        }
      } else if (this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal) {
        if (this.formGroup.get('fundingType').value === FundingTypes.FI) {
          this.setValueOfPropertyOfDataObject('stopLossCovg', [], quote);
        }
      }
    }

    Object.keys(updatedValues).forEach((key) => {
      /*
       * All the fields to update must be present in the quoteFieldsToUpdate object,
       * fields which are shown/hidden progrmatically is also needed to be added in quoteFieldsToUpdate Object,
       * It contains the setting for those fields from the schema.json
       */
      if (this.quoteFieldsToUpdate[key]) {
        const pathObj = JSON.parse(JSON.stringify(this.quoteFieldsToUpdate[key]));
        if (pathObj.field?.togglerColumns && this.subColumnsToUpdate?.length) {
          this.subColumnsToUpdate.forEach((col) => {
            pathObj.columns.push(col);
          });
        }
      
        let value = updatedValues[key];

        if (pathObj && pathObj.path) {
          switch (pathObj.type) {
           case 'date': {
              // Only format and save if date is valid, skip empty/null dates to prevent 1970-01-01
              if (updatedValues[key] && moment(updatedValues[key]).isValid()) {
                value = moment(new Date(updatedValues[key])).format('YYYY-MM-DD');
                this.setValueAtPath(pathObj.path, value, quote, true, pathObj);
              }
              break;
            }
            case 'table': {
              let dataObj = this.getValueFromPath(pathObj.path, quote) ?? [];

              if (value.length) {
                value.forEach((fieldValue, index) => {
                  pathObj.columns.forEach((col) => {
                    const data = dataObj[index];
                    let path = col.path
                    if(fieldValue['_altPathUsed_'+col.name]) {
                      path = col.altPathRow
                    }

                    if (path && !col.skipDataSave) {
                      
                      let val = fieldValue[col.name];
                      if (col.type === 'date') {
                        val = val ? moment(new Date(val)).format('YYYY-MM-DD') : '';
                      }
                      if (col.collectionDataType === 'number') {
                        val = +val;
                      }
                      // Set subscriberType to null if it is an empty string
                      if (col.name === 'subscriberType' && val === '') {
                        val = null;
                      }

                      let modifiedValue = undefined;
                      if (col?.valueModifier) {
                        let valueModifierName = col.valueModifier;

                        if (valueModifierName && typeof this[valueModifierName] === 'function') {
                          modifiedValue = this[valueModifierName].apply(this, [
                            {
                              value: val,
                              field: col,
                              type: 'set'
                            }
                          ]);
                        }
                      }
                      val = modifiedValue !== undefined ? modifiedValue : val;

                      this.updateTableHistory(col, data, val, quote, pathObj);
                      this.setValueAtPath(path, val, data);
                    }
                  });
                });
              }

              break;
            }

            default: {
              let value = updatedValues[key];
              let modifiedValue = undefined;

              if (pathObj.field?.valueModifier) {
                let valueModifierName = pathObj.field.valueModifier;

                if (valueModifierName && typeof this[valueModifierName] === 'function') {
                  modifiedValue = this[valueModifierName].apply(this, [
                    {
                      value: value,
                      field: pathObj.field,
                      type: 'set'
                    }
                  ]);
                }
              }

              value = modifiedValue !== undefined ? modifiedValue : value;
              this.setValueAtPath(pathObj.path, value, quote, true, pathObj);
              const proposedPlans = this.getValueOfPropertyFromDataObject('proposedPlans', quote);
              if (proposedPlans?.length === 0 && pathObj.field?.altPath) {
                this.setValueAtPath(pathObj.field.altPath, value, quote, true, pathObj, false);
              }

              if (pathObj.field?.altPath) {
                // Syncing up Alternate path with main path
                this.createNewObjectWithPath(pathObj.field.altPath, quote);
                this.setValueAtPath(pathObj.field.altPath, value, quote);
              }
            }
          }
        }
      }
    });
    // Sorting the census array object as per column names
    let censusArray = this.getValueOfPropertyFromDataObject('census', quote);
    if (Array.isArray(censusArray)) {
      censusArray = this.removeEmptyValuesFromCensus(censusArray);
      const sortedCensusArray = this.sortJsonKeysRecursive(censusArray);
      this.setValueOfPropertyOfDataObject('census', sortedCensusArray, quote);
    }

    const mrktSegment = this.getValueOfPropertyFromDataObject('marketSegment', quote);
    if ((quote.data.lob === Lob.Vision || quote.data.lob === Lob.Dental) && mrktSegment === MarketSegments.SmallGroup) {
      if (quote.data.unifiedPayload.data?.vision?.medLockEligible !== undefined) {
        delete quote.data.unifiedPayload.data.vision.medLockEligible;
      }
    }

    // Set networkName to 'NA' 
    if ((quote.data.lob === Lob.Dental) && this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal) {
      const proposedPlans = this.getValueOfPropertyFromDataObject('proposedPlans', quote);
      if (Array.isArray(proposedPlans)) {
        proposedPlans.forEach(plan => {
          if (mrktSegment === MarketSegments.SmallGroup) {
            plan.networkName = 'NA';
          }
        });
      }
    }

    let userInfoArray = this.getValueOfPropertyFromDataObject('userInfo', quote);
    if (Array.isArray(userInfoArray)) {
      const staticUserInfo = {
        fullName: this.authService.getUserName(),
        usDomainId: this.authService.getUserID(),
        role: 'Submitter',
        emailId: '',
        addr1: '',
        addr2: '',
        city: '',
        state: '',
        zipCode: '',
        contactUsage: '',
        companyName: '',
        contactNumber: '',
        lobSupported: [this.viewSettings.lob]
      };

      userInfoArray = userInfoArray.filter((user) => user.role !== 'Submitter');
      userInfoArray.push(staticUserInfo);
    }

    if (this.getValueOfPropertyFromDataObject('alternateQuote', quote, this.getLobFromQuote(quote, true)) !== 'Yes') {
      this.setValueOfPropertyOfDataObject('alternateQuote', 'No', quote, this.getLobFromQuote(quote, true));
    }

    if (quote.data.fundingType === FundingTypes.MEWA) {
      const medParticipationPercentValue = [{ type: 'WholeCase', value: '1' }];
      this.setValueOfPropertyOfDataObject('medParticipationPercent', medParticipationPercentValue, quote, this.getLobFromQuote(quote, true));
      this.setValueOfPropertyOfDataObject('quotingType', 'MEWA', quote, this.getLobFromQuote(quote, true));
    }


    if(this.getSectionOrFieldFromSchema(Sections.Experience)?.hideSection === false) {
      const quoteIdentifier = `${quote.data.quoteHeaderID}-${quote.data.fundingType}-${this.getLobFromQuote(quote)}`.toLowerCase();
      
      if(this.groupExpObjectChanges.find(d => d.identifier === quoteIdentifier)?.changed) {
        const updateDetails = tableHistoryKeys.find((x) => x.name === 'experience');
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[updateDetails.key] = updateDetails.message;
      }

      const claimBasisChange = this.claimsBasisChanges.find(d => d.identifier === quoteIdentifier);
      if(claimBasisChange?.changed && claimBasisChange?.currentValue !== claimBasisChange?.previousValue) {
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue['Claims Basis'] = claimBasisChange.currentValue;

        if(claimBasisChange?.previousValue) {
          quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.oldValue['Claims Basis'] = claimBasisChange.previousValue;
        }
      }
      
    }

    return quote;
  }

  updateTableHistory(col, data, val, quote, pathObj) {

    if (col && col?.name && !excludeUpdateHistoryKeys.includes(col?.name)) {
      const pathSegments = col.path.split('.');
      let currentData = data;
      for (const segment of pathSegments) {
        if (currentData && typeof currentData === 'object' && segment in currentData) {
          currentData = currentData[segment];
        } else {
          currentData = undefined;
          break;
        }
      }
      const keyMessage = tableHistoryKeys.find((x) => x.name === pathObj.name);
      if (Array.isArray(val) && Array.isArray(currentData)) {
        const areArraysEqual = val.every((item) => currentData.includes(item)) && currentData.every((item) => val.includes(item));
        if (
          !areArraysEqual &&
          keyMessage &&
          !quote.data.updateHistory[quote.data?.updateHistory?.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(keyMessage?.key)
        ) {
          // Handle the case where arrays are not equal
          quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] = keyMessage.message;
        }
      }
      if (
        Array.isArray(val) &&
        currentData == undefined &&
        val.length &&
        keyMessage &&
        !quote.data.updateHistory[quote.data?.updateHistory?.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(keyMessage?.key)
      ) {
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] = keyMessage.message;
      }
      if (
        currentData !== undefined &&
        !Array.isArray(val) &&
        currentData != val &&
        pathObj.name !== 'censusTable' &&
        keyMessage &&
        !quote.data.updateHistory[quote.data?.updateHistory?.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(keyMessage?.key)
      ) {
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] = keyMessage.message;
      }
      if (
        !Array.isArray(val) &&
        currentData != val &&
        pathObj.name === 'censusTable' &&
        keyMessage &&
        !quote.data.updateHistory[quote.data?.updateHistory?.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(keyMessage?.key) &&
        (!StringUtils.isEmpty(val) || currentData !== undefined)
      ) {
        quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] = keyMessage.message;
      }
    }
  }

  removeEmptyValuesFromCensus(obj: any): any {
    if (Array.isArray(obj)) {
      return obj.map((item) => this.removeEmptyValuesFromCensus(item)).filter((item) => item !== null && item !== undefined && item !== '');
    } else if (obj !== null && typeof obj === 'object') {
      return Object.keys(obj).reduce((acc, key) => {
        const value = this.removeEmptyValuesFromCensus(obj[key]);
        if (value !== null && value !== undefined && value !== '') {
          acc[key] = value;
        }
        return acc;
      }, {});
    }
    return obj;
  }

  onPlanModalSubmit() {
    if (this.planModalformGroup.invalid) {
      this.planModalformGroup.markAllAsTouched();
      return;
    }

    this.showPlanModal = false;

    const contractCodes = this.planModalformGroup.get('contractCodes').value;
    const fundingType = this.formGroup.get('fundingType').value;
    const fiCommission = this.formGroup.get('fiCommission')?.value ?? '';
    const abfCommission = this.formGroup.get('abfCommission')?.value ?? '';
    const fiCommissionType = this.formGroup.get('fiCommissionType')?.value ?? '';
    const abfCommissionType = this.formGroup.get('abfCommissionType')?.value ?? 'PCPM';

    const lob = this.getLobFromQuote(this.currentDataObj, true);
    const marketSegment = this.formGroup.get('marketSegment').value;
    const isSGDental = this.showOPPCreationForSGVisionDentalSHP && lob === this.toLobCase(Lob.Dental) && marketSegment === MarketSegments.SmallGroup;
    const isSGDentalVision = this.showOPPCreationForSGVisionDentalSHP && (lob === this.toLobCase(Lob.Dental) || lob === this.toLobCase(Lob.Vision)) && marketSegment === MarketSegments.SmallGroup;
    
    // Check if Vision/Dental New Business to exclude network fields
    const isVisionOrDental = lob === this.toLobCase(Lob.Vision) || lob === this.toLobCase(Lob.Dental);
    const isNewBusiness = this.viewSettings.opportunityType === OpportunityType.NewBusinessLocal;
    const excludeNetworkFields = isVisionOrDental && isNewBusiness;
    
    
    let dataObject = this.planBenefits
      .map((plan) => {
        let planName = (lob === this.toLobCase(Lob.Vision) ? plan.planCd : plan.planName) ?? '';
        const planNameContractCodeKey = `${plan.cntrctCd} - ${planName}`;
        const match = contractCodes.filter((cc) => cc.includes(planNameContractCodeKey)).length ? true : false;

        const currPlanFieldType = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable', 'currPlanId').type;
        const currPlanPlanInitValue = currPlanFieldType === FieldTypes.Dropdown ? '' : [];
        if (match) {
          const planData: any = {
            contractCode: plan.cntrctCd,
            currPlanId: currPlanPlanInitValue,
            planTypeRequested: plan.planTypeRequested || 'F'
          };
          
          // Only add planName and fundingType if not Medical
          if (isVisionOrDental) {
            planData.planName = planName;
            planData.fundingType = fundingType;
          }
          
          // Only add network fields if not Vision/Dental New Business
          if (!excludeNetworkFields) {
            // For Small Group Dental MEWA, set networkName to 'NA'. For Vision, don't set it.
            if (isSGDental) {
              planData.networkName = 'NA';
            } else if (!isSGDentalVision) {
              planData.networkName = plan.ntwrkName ?? '';
            }
            planData.networkType = plan.prodCtgryCd ?? '';
            planData.CDHPIndicator = plan.prodCd ?? '';
          }
          
          return planData;
        }
      })
      .filter((data) => data);

    this.showPlanModal = false;

    const planTableConfig = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable');

    let parentArray = this.getValueFromPath(planTableConfig.path, this.currentDataObj);

    dataObject.forEach((data) => {
      const rowId = new FormControl(Math.random() + Date.now());
      let formControls = { _rowId: rowId };
      let newObj = {};

      planTableConfig.columns.forEach((col) => {
        this.prepareRowFormControl(col, data, formControls);

        if (col.path) {
          this.createNewObjectWithPath(col.path, newObj);
        }
      });

      // Only set fundingType if not Medical
      if (isVisionOrDental && (formControls as any)['fundingType']) {
        ((formControls as any)['fundingType'] as FormControl).setValue(data.fundingType);
      }

      newObj['commissionValue'] = fiCommission ? fiCommission : abfCommission;
      newObj['commissionType'] = fiCommissionType ? fiCommissionType : abfCommissionType;
      newObj['lob'] = this.viewSettings.lob;
      newObj['quoteLineItemID'] = this.commonService.generateID('QL');
      newObj['planTypeRequested'] = 'F';

      Object.keys(data).forEach((key) => {
        if (!newObj[key]) {
          newObj[key] = data[key];
        }
      });

      parentArray.push(newObj);
      formControls['quoteLineItemID'] = new FormControl(newObj['quoteLineItemID']);
      (this.formGroup.get('planTable') as FormArray).push(this.fb.group(formControls));
    });

    this.setPlanNameInPlanTable();
    switch (this.viewSettings.lob) {
      case Lob.Vision: {
        this.populateContractCodeVision();
        this.populateContractCodeOptions();
        break;
      }

      case Lob.Dental:
      case Lob.SuppHealth: {
        this.populateContractCodeOptions();
        break;
      }

      case Lob.Medical: {
        this.populateContractCodeOptions();
        break;
      }
    }

    this.resetPlanForm();
  }

  resetPlanForm() {
    this.planModalformGroup.get('networks')?.reset();
    this.planModalformGroup.get('prodCategories')?.reset();
    this.planModalformGroup.get('prodCodes')?.reset();
    this.planModalformGroup.get('contractCodes')?.reset();
    this.planModalformGroup.get('expandCategoryType')?.reset();
    this.planModalformGroup.get('voluntaryIndicator')?.reset();
    this.planModalformGroup.updateValueAndValidity();
    this.planModalformGroup.markAsUntouched();
  }

  addPlanTableRowSuppHealth() {
    const fundingType = this.formGroup.get('fundingType').value;
    const fiCommission = this.formGroup.get('fiCommission')?.value ?? '';
    const fiCommissionType = this.formGroup.get('fiCommissionType')?.value ?? '';
    const proposedPlanDetails = this.getValueOfPropertyFromDataObject('proposedPlans', this.currentDataObj);
    let obj = {
      contractCode: '',
      networkName: '',
      fundingType: fundingType
    };
    

    const planTableConfig = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable');
    let parentArray = this.getValueFromPath(planTableConfig.path, this.currentDataObj);
    [obj].forEach((data) => {
      const rowId = new FormControl(Math.random() + Date.now());
      let formControls = { _rowId: rowId };
      let newObj = {};

      planTableConfig.columns.forEach((col) => {
        this.prepareRowFormControl(col, data, formControls);

        if (col.path) {
          this.createNewObjectWithPath(col.path, newObj);
        }
      });

      (formControls['fundingType'] as FormControl).setValue(data.fundingType);

      newObj['commissionValue'] = fiCommission;
      newObj['commissionType'] = fiCommissionType;
      newObj['lob'] = this.viewSettings.lob;
      newObj['quoteLineItemID'] = this.commonService.generateID('QL');
      newObj['planTypeRequested'] = 'F';

      Object.keys(data).forEach((key) => {
        if (!newObj[key]) {
          newObj[key] = data[key];
        }
      });

      parentArray.push(newObj);
      formControls['quoteLineItemID'] = new FormControl(newObj['quoteLineItemID']);
      (this.formGroup.get('planTable') as FormArray).push(this.fb.group(formControls));
    });
  }

  addPlanTableRowDental() {
    const fundingType = this.formGroup.get('fundingType').value;
    const fiCommission = this.formGroup.get('fiCommission')?.value ?? '';
    const fiCommissionType = this.formGroup.get('fiCommissionType')?.value ?? '';
    const proposedPlanDetails = this.getValueOfPropertyFromDataObject('proposedPlans', this.currentDataObj);
    let obj;
    if (proposedPlanDetails && proposedPlanDetails.length) {
      obj = structuredClone(proposedPlanDetails[0]);
    } else {
      obj = structuredClone(DentalProposedPlansObject);
    }

    obj.contractCode = '';
    obj.networkName = 'NA';
    obj.fundingType = fundingType;

    const planTableConfig = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable');
    let parentArray = this.getValueFromPath(planTableConfig.path, this.currentDataObj);
    [obj].forEach((data) => {
      const rowId = new FormControl(Math.random() + Date.now());
      let formControls = { _rowId: rowId };
      let newObj = {};

      planTableConfig.columns.forEach((col) => {
        col['changeHandler'] = 'speciliatyPlanNameChange';
        this.prepareRowFormControl(col, data, formControls);

        if (col.path) {
          this.createNewObjectWithPath(col.path, newObj);
        }
      });

      (formControls['fundingType'] as FormControl).setValue(data.fundingType);

      newObj['commissionValue'] = fiCommission;
      newObj['commissionType'] = fiCommissionType;
      newObj['lob'] = this.viewSettings.lob;
      newObj['quoteLineItemID'] = this.commonService.generateID('QL');
      newObj['planTypeRequested'] = 'F';

      Object.keys(data).forEach((key) => {
        if (!newObj[key]) {
          newObj[key] = data[key];
        }
      });

      parentArray.push(newObj);
      formControls['quoteLineItemID'] = new FormControl(newObj['quoteLineItemID']);
      (this.formGroup.get('planTable') as FormArray).push(this.fb.group(formControls));
    });
  }

  addPlanTableRowVision() {
    const fundingType = this.formGroup.get('fundingType').value;
    const fiCommission = this.formGroup.get('fiCommission')?.value ?? '';
    const fiCommissionType = this.formGroup.get('fiCommissionType')?.value ?? '';
    const proposedPlanDetails = this.getValueOfPropertyFromDataObject('proposedPlans', this.currentDataObj);
    let obj;
    if (proposedPlanDetails && proposedPlanDetails.length) {
      obj = structuredClone(proposedPlanDetails[0]);
    } else {
      obj = structuredClone(VisionProposedPlansObject);
    }

    obj.contractCode = '';
    // obj.networkName = 'NA';
    obj.fundingType = fundingType;

    const planTableConfig = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable');
    let parentArray = this.getValueFromPath(planTableConfig.path, this.currentDataObj);
    [obj].forEach((data) => {
      const rowId = new FormControl(Math.random() + Date.now());
      let formControls = { _rowId: rowId };
      let newObj = {};

      planTableConfig.columns.forEach((col) => {
        if (col.name === 'contractCode') {
          col['changeHandler'] = 'speciliatyPlanNameChange';
        }

        this.prepareRowFormControl(col, data, formControls);

        if (col.path) {
          this.createNewObjectWithPath(col.path, newObj);
        }
      });

      (formControls['fundingType'] as FormControl).setValue(data.fundingType);

      newObj['commissionValue'] = fiCommission;
      newObj['commissionType'] = fiCommissionType;
      newObj['lob'] = this.viewSettings.lob;
      newObj['quoteLineItemID'] = this.commonService.generateID('QL');
      newObj['planTypeRequested'] = 'F';

      Object.keys(data).forEach((key) => {
        if (!newObj[key]) {
          newObj[key] = data[key];
        }
      });

      parentArray.push(newObj);
      formControls['quoteLineItemID'] = new FormControl(newObj['quoteLineItemID']);
      (this.formGroup.get('planTable') as FormArray).push(this.fb.group(formControls));
    });
  }

  speciliatyPlanNameChange(...args) {
    this.populateContractCodeOptions();
  }

  calculateLivesFromCensus(): { eligibleLives: string; enrolledLives: string } {
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    
    // First, try to get lives from summary census (tier fields like EE, EF, EC, ES, E1)
    const selectedTier = this.formGroup?.get('inputTier')?.value;
    if (selectedTier) {
      const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);
      if (tierDetails && tierDetails.length > 0) {
        let totalLives = 0;
        let hasSummaryCensusData = false;
        
        tierDetails.forEach((tier) => {
          const tierField = tier.pathString.toLowerCase();
          const field = this.getSectionOrFieldFromSchema(Sections.SummaryCensus, tierField, null, false, lob);
          if (field) {
            const value = this.getValueFromPath(field.path, this.currentDataObj);
            if (value && !isNaN(+value) && +value > 0) {
              hasSummaryCensusData = true;
              totalLives += +value;
            }
          }
        });
        
        // If we have summary census data, use it
        if (hasSummaryCensusData && totalLives > 0) {
          return {
            eligibleLives: totalLives.toString(),
            enrolledLives: totalLives.toString()
          };
        }
      }
    }
    
    // If no summary census, fall back to counting individual census records
    const census = this.getValueOfPropertyFromDataObject('census', this.currentDataObj, lob) || [];
    
    if (!Array.isArray(census) || census.length === 0) {
      return { eligibleLives: '0', enrolledLives: '0' };
    }

    // Get the eligibility field name based on LOB (denEligibility for Dental, visEligibility for Vision)
    // Fallback to standard 'eligibility' field if LOB-specific field doesn't exist
    let eligibilityField = '';
    if (lob === this.toLobCase(Lob.Dental)) {
      eligibilityField = 'denEligibility';
    } else if (lob === this.toLobCase(Lob.Vision)) {
      eligibilityField = 'visEligibility';
    }

    // Count eligible lives: all census records with eligibility status (E=Enrolled, K=Kaiser)
    // Check LOB-specific field first, fallback to standard eligibility field
    const eligibleLives = census.filter(person => {
      const eligibilityValue = person[eligibilityField] || person.eligibility;
      return eligibilityValue && ['E', 'K'].includes(eligibilityValue);
    }).length;
    
    // Count enrolled lives: census records with eligibility = 'E' (Enrolled)
    const enrolledLives = census.filter(person => {
      const eligibilityValue = person[eligibilityField] || person.eligibility;
      return eligibilityValue === 'E';
    }).length;

    return {
      eligibleLives: eligibleLives.toString(),
      enrolledLives: enrolledLives.toString()
    };
  }

  buildQuotablePlansRequest(): any {
    const lob = this.getLobFromQuote(this.currentDataObj, true);
    const marketSegment = this.formGroup.get('marketSegment').value;
    const fundingType = this.formGroup.get('fundingType').value;
    
    let productType = '';
    if (lob === this.toLobCase(Lob.Dental)) {
      productType = 'Dental';
    } else if (lob === this.toLobCase(Lob.Vision)) {
      productType = 'Vision';
    }

    let portfolioType = 'SG';
    if (fundingType === FundingTypes.MEWA) {
      portfolioType = 'MEWA';
    }

    const countyValue = this.formGroup.get('county')?.value || '';
    const countyCode = countyValue ? countyValue.split(' - ')[0] : '';

    // Check if enrolledLives and eligibleLives input fields have values
    // If yes, use those values; otherwise calculate from census
    let enrolledLivesValue = '';
    let eligibleLivesValue = '';

    const enrolledLivesControl = this.formGroup.get('enrolledLives');
    const eligibleLivesControl = this.formGroup.get('eligibleLives');

    if (enrolledLivesControl?.value && eligibleLivesControl?.value) {
      // Use input field values if both are provided
      enrolledLivesValue = enrolledLivesControl.value.toString();
      eligibleLivesValue = eligibleLivesControl.value.toString();
    } else {
      // Calculate lives from census
      const { eligibleLives, enrolledLives } = this.calculateLivesFromCensus();
      enrolledLivesValue = enrolledLives;
      eligibleLivesValue = eligibleLives;
    }

    const request = {
      renewalOnly: 'N',
      zipCode: this.formGroup.get('companyZipCode')?.value || '',
      userType: 'External',
      targetSystem: 'ERE',
      state: this.formGroup.get('state')?.value || '',
      productType: productType,
      portfolioType: portfolioType,
      exchangeFlag: 'OF',
      enrolledLives: (enrolledLivesValue && enrolledLivesValue !== '0') ? enrolledLivesValue : '10',
      eligibleLives: (eligibleLivesValue && eligibleLivesValue !== '0') ? eligibleLivesValue : '15',
      effectiveDate: moment(this.formGroup.get('contractEffectiveDate')?.value).format('YYYY-MM-DD'),
      countyCode: countyCode,
      benefitPeriod: 'Plan Year',
      association: ''
    };

    return request;
  }

  parsePlanNameToPlanBenefit(contractCode: string, planName: string, state: string): any {
    return {
      cntrctCd: contractCode,
      planName: planName,
      planCd: planName,
      ntwrkName: 'NA',
      stCd: state
    };
  }

  initializeDentalQuotablePlans(quotablePlansResponse: any) {
    const state = this.formGroup.get('state').value;
    
    this.planBenefits = Object.entries(quotablePlansResponse).map(([contractCode, planName]) => {
      return this.parsePlanNameToPlanBenefit(contractCode, planName as string, state);
    });

    this.planBenefitsUnfiltered = structuredClone(this.planBenefits);

    const selectedContractCodes = [];
    const planTableArray = this.formGroup?.get('planTable') as FormArray;
    planTableArray?.controls.forEach((row) => {
      selectedContractCodes.push(row.get('contractCode').value);
    });

    this.planBenefits = this.planBenefits.filter(
      (plan) => !selectedContractCodes.includes(plan.cntrctCd)
    );

    this.planDropdownValues = {
      lobValues: [{ label: this.viewSettings.lob, value: this.viewSettings.lob }],
      contractCodes: []
    };

    if (this.planBenefits.length) {
      this.setPlanNameInPlanTable();
      this.populateContractCodesDirectly();
    }
  }

  initializeVisionQuotablePlans(quotablePlansResponse: any) {
    const state = this.formGroup.get('state').value;
    
    this.planBenefits = Object.entries(quotablePlansResponse).map(([contractCode, planName]) => {
      return this.parsePlanNameToPlanBenefit(contractCode, planName as string, state);
    });

    this.planBenefitsUnfiltered = structuredClone(this.planBenefits);

    const selectedContractCodes = [];
    const planTableArray = this.formGroup?.get('planTable') as FormArray;
    planTableArray?.controls.forEach((row) => {
      selectedContractCodes.push(row.get('contractCode').value);
    });

    this.planBenefits = this.planBenefits.filter(
      (plan) => !selectedContractCodes.includes(plan.cntrctCd)
    );

    this.planDropdownValues = {
      lobValues: [{ label: this.viewSettings.lob, value: this.viewSettings.lob }],
      contractCodes: []
    };

    if (this.planBenefits.length) {
      this.setPlanNameInPlanTable();
      this.populateContractCodesDirectly();
    }
  }

  async addPlan() {
    const cacheCode = this.generateCacheCodeString();
    let [state, marketSegment, contEffectiveDate, factorEffectiveDate] = cacheCode.split('##');

    const fundingType = this.formGroup.get('fundingType').value;
    let mbs = marketSegment === MarketSegments.SmallGroup ? marketSegment : (this.formGroup.get('mbs')?.value ?? 'Key');

    const lob = this.getLobFromQuote(this.currentDataObj, true);
    let showPlanModal = true;
    await firstValueFrom(this.getPlanBenefits(cacheCode, state, contEffectiveDate, factorEffectiveDate, marketSegment, mbs)).then(async (response) => {
      switch (lob) {
        case this.toLobCase(Lob.Vision): {
          if (this.showOPPCreationForSGVisionDentalSHP && marketSegment === MarketSegments.SmallGroup) {
            try {
              const quotablePlansRequest = this.buildQuotablePlansRequest();
              const quotablePlansResponse = await firstValueFrom(
                this.cacheService.getQuotablePlans(quotablePlansRequest)
              );
              
              if (quotablePlansResponse && Object.keys(quotablePlansResponse).length > 0) {
                this.initializeVisionQuotablePlans(quotablePlansResponse);
              } else {
                this.planBenefits = [];
                this.planBenefitsUnfiltered = [];
              }
              
            } catch (error) {
              this.planBenefits = [];
              this.planBenefitsUnfiltered = [];
            }
            
            this.planModalformGroup = this.fb.group({
              lob: new FormControl(this.viewSettings.lob, [Validators.required]),
              contractCodes: new FormControl('', [Validators.required])
            });
            
            showPlanModal = true;
          } else if (marketSegment === MarketSegments.LargeGroup) {
            this.initializeVisionPlanBenefits(response ?? []);
            
            this.planModalformGroup = this.fb.group({
              lob: new FormControl(this.viewSettings.lob, [Validators.required]),
              expandCategoryType: new FormControl(''),
              voluntaryIndicator: new FormControl(''),
              contractCodes: new FormControl('', [Validators.required])
            });

            this.planModalformGroup
              .get('expandCategoryType')
              ?.valueChanges.pipe(takeUntil(this.destroy$), takeUntil(this.quoteChanged$))
              .subscribe((value) => {
                const currentVoluntaryIndicator = this.planModalformGroup.get('voluntaryIndicator').value;
                this.populateVoluntaryIndicatorOptions();

                if (currentVoluntaryIndicator && this.planDropdownValues.voluntaryIndicator.findIndex((e) => e.value === currentVoluntaryIndicator) < 0) {
                  this.planModalformGroup.get('voluntaryIndicator').setValue('');
                }
              });

            this.planModalformGroup
              .get('voluntaryIndicator')
              ?.valueChanges.pipe(takeUntil(this.destroy$), takeUntil(this.quoteChanged$))
              .subscribe((value) => {
                const currentContractCode = this.planModalformGroup.get('contractCodes').value;
                this.populateContractCodeVision();

                if (currentContractCode && this.planDropdownValues.contractCodes.findIndex((e) => e.value === currentContractCode) < 0) {
                  this.planModalformGroup.get('contractCodes').setValue('');
                }
              });
          } else {
            this.initializeVisionPlanBenefits(response ?? []);
            this.addPlanTableRowVision();
            showPlanModal = false;
          }

          break;
        }

        case this.toLobCase(Lob.Dental): {
          if (this.showOPPCreationForSGVisionDentalSHP && marketSegment === MarketSegments.SmallGroup) {
            try {
              const quotablePlansRequest = this.buildQuotablePlansRequest();
              const quotablePlansResponse = await firstValueFrom(
                this.cacheService.getQuotablePlans(quotablePlansRequest)
              );
              
              if (quotablePlansResponse && Object.keys(quotablePlansResponse).length > 0) {
                this.initializeDentalQuotablePlans(quotablePlansResponse);
              } else {
                this.planBenefits = [];
                this.planBenefitsUnfiltered = [];
              }
              
            } catch (error) {
              this.planBenefits = [];
              this.planBenefitsUnfiltered = [];
            }
            
            this.planModalformGroup = this.fb.group({
              lob: new FormControl(this.viewSettings.lob, [Validators.required]),
              contractCodes: new FormControl('', [Validators.required])
            });
            
            showPlanModal = true;
          } else {
            this.initializeDentalPlanBenefits(response ?? []);
            this.addPlanTableRowDental();
            showPlanModal = false;
          }
          break;
        }

        case this.toLobCase(Lob.SuppHealth): {
          this.initializeSuppHealthPlanBenefits(response ?? []);
          this.addPlanTableRowSuppHealth();
          showPlanModal = false;
          break;
        }

        default: {
          this.initializePlanBenefits(response ?? []);

          this.planModalformGroup = this.fb.group({
            lob: new FormControl(this.viewSettings.lob, [Validators.required]),
            networks: new FormControl(''),
            prodCategories: new FormControl(''),
            prodCodes: new FormControl(''),
            contractCodes: new FormControl('', [Validators.required])
          });

          this.planModalformGroup
            .get('networks')
            ?.valueChanges.pipe(takeUntil(this.destroy$), takeUntil(this.quoteChanged$))
            .subscribe((value) => {
              const currentProdCategory = this.planModalformGroup.get('prodCategories').value;
              this.populateProdCategory();

              if (currentProdCategory && this.planDropdownValues.prodCategories.findIndex((e) => e.value === currentProdCategory) < 0) {
                this.planModalformGroup.get('prodCategories').setValue('');
              }
            });

          this.planModalformGroup
            .get('prodCategories')
            ?.valueChanges.pipe(takeUntil(this.destroy$), takeUntil(this.quoteChanged$))
            .subscribe((value) => {
              const currentProdCode = this.planModalformGroup.get('prodCodes').value;
              this.populateProdCode();

              if (currentProdCode && this.planDropdownValues.prodCodes.findIndex((e) => e.value === currentProdCode) < 0) {
                this.planModalformGroup.get('prodCodes').setValue('');
              }
            });

          this.planModalformGroup
            .get('prodCodes')
            ?.valueChanges.pipe(takeUntil(this.destroy$), takeUntil(this.quoteChanged$))
            .subscribe((value) => {
              const currentContractCode = this.planModalformGroup.get('contractCodes').value;
              this.populateContractCode();

              if (currentContractCode && this.planDropdownValues.contractCodes.findIndex((e) => e.value === currentContractCode) < 0) {
                this.planModalformGroup.get('contractCodes').setValue('');
              }
            });

          break;
        }
      }
    });

    this.showPlanModal = showPlanModal;
  }

  removePlans() {
    let formArray = this.formGroup.get('planTable') as FormArray;
    let removeIndexes = formArray.value
      .map((e, index) => {
        if (e.checkbox) {
          return index;
        }
      })
      .filter((e) => e !== undefined);

    const planTableConfig = this.getSectionOrFieldFromSchema(Sections.Plan, 'planTable');
    let parentArray = this.getValueFromPath(planTableConfig.path, this.currentDataObj);

    removeIndexes.reverse().forEach((i) => {
      formArray.removeAt(i);
      parentArray.splice(i, 1);
    });
    if (removeIndexes && removeIndexes.length) {
      this.addHistoryObj(this.currentDataObj);
      const keyMessage = tableHistoryKeys.find((x) => x.name === 'planTable');
      // Handle the case where arrays are not equal
      if (
        keyMessage &&
        !this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(
          keyMessage?.key
        )
      ) {
        this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] =
          keyMessage.message;
      }
    }

    this.formGroup.get('planTableCheckAll').setValue(false, { emitEvent: false });
    this.populateContractCodeOptions();
  }

  marketSegmentInitializeHandler(...args) {
    const { field } = args[0];

    const marketSegmentControl = this.formGroup.get(field.name);
    let currentValue = marketSegmentControl.value;


    if (!this.viewSettings.creatingNewOpp) {
      let marketSegmentOptions = field.options;
      marketSegmentOptions = this.checkMarketSegmentFundingTypeRestrictions(marketSegmentOptions);
      field.options = marketSegmentOptions;

      this.blockValueChangeDetection = true;
      if (!currentValue) {
        marketSegmentControl.setValue(field.options[0].value, { emitEvent: false });
      }
      this.blockValueChangeDetection = false;
    }

    let mbsField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'mbs');

    if (currentValue === MarketSegments.LargeGroup) {
      mbsField.show = 'true';
      this.quoteFieldsToUpdate[mbsField.name] = {
        path: mbsField.path,
        name: mbsField.name,
        label: mbsField.label,
        type: mbsField.type,
        columns: mbsField.columns ?? null
      };
    } else {
      mbsField.show = 'false';
      this.setValueOfPropertyOfDataObject('mbs', MarketSegments.SmallGroup, this.currentDataObj);
      delete this.quoteFieldsToUpdate[mbsField.name];
    }

    this.udpateCityFieldValidators();
  }

  async marketSegmentChange(...args) {
    let { value, field, previousVal } = args[0];

    value = value ? value : field.options[0].value;

    const quoteStatus = this.currentDataObj.data.status;

    const savedMktSegment = this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj);
    const savedFundingType = this.getFundingTypeFromObj(this.currentDataObj);

    const allowedFundingTypes = this.getAllowedFundingTypes(this.currentDataObj, value, false).options;
    this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fundingType').options = allowedFundingTypes.map((ftValue) => {
      return { label: ftValue, value: ftValue };
    });

    const currentFundingTypeValue = this.formGroup.get('fundingType').value;

    let fndTypeNotAllowed = false;
    if (!allowedFundingTypes.includes(currentFundingTypeValue)) {
      fndTypeNotAllowed = true;
    }

    if (quoteStatus?.length && savedMktSegment) {
      if (savedMktSegment !== value) {
        this.inCrossSellingMode = true;
        this.isCrossSellingInProcess = true;

        if (previousVal !== '' && value) {
          const messageParams = {
            marketSegment: field.options.filter((mktSeg) => mktSeg.value === value)[0].label
          };

          await this.showWaitingPopupAlertMessage(this.setMessageStringParams(messageParams, CreateOppScreenMessages.CrossSellingAlert as string));
          if (fndTypeNotAllowed) {
            this.formGroup.get('fundingType').setValue(allowedFundingTypes[0]);
          }
        } else {
          this.inCrossSellingMode = false;
          this.isCrossSellingInProcess = false;
          return;
        }

        await this.processCrossSelling();
      } else {
        this.formGroup.get('fundingType').setValue(savedFundingType, { emitEvent: false });
      }
    }

    let mbsField = this.getSectionOrFieldFromSchema(Sections.QuoteInfo, 'mbs');

    this.setFundingTypeDropdownOptions(value);

    if (value === MarketSegments.LargeGroup) {
      mbsField.show = 'true';
      this.formGroup.addControl('mbs', new FormControl(null, this.getValidators(mbsField.validators)));
      this.formGroup.get('mbs').updateValueAndValidity();

      let fieldValue = this.getValueFromPath(mbsField.path, this.currentDataObj);
      const mbsPermittedValuesForLG: string[] = mbsField.options.map((v) => v.value);
      fieldValue = !mbsPermittedValuesForLG.includes(fieldValue) ? mbsField.defaultValue : fieldValue;

      this.formGroup.get('mbs').setValue(fieldValue);

      this.quoteFieldsToUpdate[mbsField.name] = {
        path: mbsField.path,
        name: mbsField.name,
        label: mbsField.label,
        type: mbsField.type,
        columns: mbsField.columns ?? null
      };
    } else if (value === MarketSegments.SmallGroup) {
      if (this.formGroup.contains('mbs')) {
        this.formGroup.removeControl('mbs');
      }
      mbsField.show = 'false';
      this.setValueOfPropertyOfDataObject('mbs', MarketSegments.SmallGroup, this.currentDataObj);
      delete this.quoteFieldsToUpdate[mbsField.name];
    }

    this.udpateCityFieldValidators();

    if (value && previousVal?.length && value !== previousVal) {
      this.populateQuoteAndFundingInfoOptions();
    }
  }

  initMBS(...args) {
    const { field } = args[0];
    const marketSegment = this.formGroup.get('marketSegment').value;

    if (marketSegment === MarketSegments.LargeGroup) {
      field.show = 'true';
      this.formGroup.addControl('mbs', new FormControl(null, this.getValidators(field.validators)));
      this.formGroup.get('mbs').updateValueAndValidity();

      let fieldValue = this.getValueFromPath(field.path, this.currentDataObj);
      const mbsPermittedValuesForLG: string[] = field.options.map((v) => v.value);
      fieldValue = !mbsPermittedValuesForLG.includes(fieldValue) ? field.defaultValue : fieldValue;

      this.formGroup.get('mbs').setValue(fieldValue);

      this.quoteFieldsToUpdate[field.name] = {
        path: field.path,
        name: field.name,
        label: field.label,
        type: field.type,
        columns: field.columns ?? null
      };
    } else if (marketSegment === MarketSegments.SmallGroup) {
      if (this.formGroup.contains('mbs')) {
        this.formGroup.removeControl('mbs');
      }
      field.show = 'false';
      const existingMbsValue = this.getValueFromPath(field.path, this.currentDataObj);
      if (!existingMbsValue) {
        this.setValueOfPropertyOfDataObject('mbs', MarketSegments.SmallGroup, this.currentDataObj);
      }
      delete this.quoteFieldsToUpdate[field.name];
    }
  }
  udpateCityFieldValidators() {
    let cityField = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'city');
    const cityFieldOriginalSetting = this.getSectionOrFieldFromSchema(Sections.GroupInfo, 'city', null, true);
    // Copying original validators to preserve any other Validators present
    cityField.validators = structuredClone(cityFieldOriginalSetting.validators);

    const marketSegment = this.formGroup.get('marketSegment').value;

    if (marketSegment === MarketSegments.SmallGroup) {
      // making city field optional
      cityField.validators = cityField.validators.filter((v) => v.type !== 'required');
    }

    this.formGroup.get(cityField.name).clearValidators();
    this.formGroup.get(cityField.name).addValidators(this.getValidators(cityField.validators));
    this.formGroup.get(cityField.name).updateValueAndValidity();
  }

  checkMarketSegmentFundingTypeRestrictions(marketSegmentOptions) {
    const isAltQuote =
      this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true)) === 'Yes' ? true : false;
    const contractEffDate = this.formGroup.get('contractEffectiveDate').value;
    const state = this.formGroup.get('state').value;
    const fundingType = this.formGroup?.get('fundingType')?.value;
    const currentMarketSegment = this.formGroup.get('marketSegment').value;
    const marketSegmentOptionsCopy = structuredClone(marketSegmentOptions);
    // If alternateQuote is 'Yes', skip validation and return currentDataObj market segment values
    if (isAltQuote) {
      return marketSegmentOptionsCopy.filter((mktSeg) => mktSeg.value === currentMarketSegment);
    }

    if (state && contractEffDate) {
      marketSegmentOptions = marketSegmentOptions.filter((mktSeg) => {
        const mktSegFundingTypeStateRestriction = this.crossSellingRestrictionMap[`${mktSeg.value}_${fundingType}`];
        if (!mktSegFundingTypeStateRestriction) {
          return true;
        }

        const restrictionDate = mktSegFundingTypeStateRestriction[state];
        if (!restrictionDate) {
          return true;
        }

        const isAfter = moment(contractEffDate).isAfter(restrictionDate[0], 'day');

        return isAfter;
      });

      const marketSegmentOptionsValues = marketSegmentOptions.map((mktSegment) => mktSegment.value);

      if (!marketSegmentOptionsValues.includes(currentMarketSegment)) {
        const messageParams = {
          marketSegment: marketSegmentOptionsCopy.filter((mktSeg) => mktSeg.value === currentMarketSegment)[0].label,
          fundingType: fundingType,
          state: state
        };

        this.showPopupAlertMessage(this.setMessageStringParams(messageParams, CreateOppScreenMessages.InvalidMarketSegmentFundingTypeCombination as string));
      }
    }

    return marketSegmentOptions;
  }

  async prepareNewQuote(lob?: any) {
    // let hasQuote = this.data[0].data.quoteHeaderID ? true : false;
    // let newQuoteObject = hasQuote ? structuredClone(this.newFormData[this.toLobCase(lob)]) : structuredClone(this.data[0]);
    let newQuoteObject = structuredClone(this.newFormData[this.toLobCase(lob)]);

    this.showLoader(true);
    const idResult = await this.getQuoteAndOppId();
    this.showLoader(false);

    newQuoteObject.data['opportunityID'] = this.opportunityID;
    newQuoteObject.data.unifiedPayload.data['opportunityID'] = this.opportunityID;
    newQuoteObject.data['quoteHeaderID'] = idResult.quoteHeaderID;
    newQuoteObject.data.unifiedPayload.data['quoteHeaderID'] = idResult.quoteHeaderID;
    newQuoteObject.data['lob'] = lob;
    if(lob === Lob.Vision || lob === Lob.Dental) {
    newQuoteObject.data['fundingType'] = 'FI';

    }

    this.setValueOfPropertyOfDataObject('quoteOrigin', QuoteOrigin.OppScreen, newQuoteObject);
    newQuoteObject.data.quoteOrigin = QuoteOrigin.OppScreen;

    this.setValueOfPropertyOfDataObject('alternateQuote', 'No', newQuoteObject);

    this.getSectionOrFieldFromSchema(Sections.GroupInfo).fields.forEach((field) => {
      const value = this.getValueFromPath(field.path, this.data[0]);

      this.setValueAtPath(field.path, value, newQuoteObject);
    });

    this.currentDataObj = newQuoteObject;

    return new Promise((resolve) => resolve('New Quote Prepared'));
  }

  censusExportSampleTemplate() {
    var sampleData = [
      {
        firstName: 'sample',
        lastName: 'sample',
        age: '50',
        dob: '01/01/2000',
        gender: 'M/F/U',
        zipCode: '99999',
        eligibility: '(E)Enrolled/(K)Kaiser/(W)Waiver/(V)Valid Waiver/(I)Invalid',
        tier: 'EE/EF/EC/EK/ES/E1',
        relationship: '(C)Child/(D)Dependent/(P)Partner/(S)Subscriber',
        subscriberType: '(A)Active/(C)Cobra/(E)Early Retiree/(R)Retiree',
        contractCode: 'C123',
        subscriberID: '123435',
        memberID: '12345',
        medicareEligible: 'Yes/No'
      }
    ];
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(sampleData);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'CensusSampleData');

    /* save to file */
    XLSX.writeFile(wb, 'CensusSampleData.xlsx');
  }

  censusReset() {
    const censusTable = this.formGroup.get('censusTable') as FormArray;
    for (let i = censusTable.length - 1; i >= 0; i--) {
      censusTable.removeAt(i);
    }
    this.setValueOfPropertyOfDataObject('census', [], this.currentDataObj);
    
    // Update add plan button state after census reset
    this.updateAddPlanButtonState();
  }

  cesusExport(): void {
    const censusTable = this.formGroup.get('censusTable') as FormArray;
    const censusTableConfig = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable').columns;

    function getOptionLabelByValue(fieldName: string, value: string): string | undefined {
      const fieldConfig = censusTableConfig?.find((field) => field.field === fieldName);
      const options = fieldConfig?.options;
      return options?.find((option) => option.value === value)?.label;
    }
    const exportdata = censusTable.controls.map((control) => {
      const { firstName, lastName, dateOfBirth, age, zipCode, gender, eligibility, tier, relationType, subscriberType, contractCode, subscriberID, memberID, medicareEligible } =
        control.value;
      return {
        firstName,
        lastName,
        age: age || '',
        dob: this.datepipe.transform(dateOfBirth, 'MM/dd/yyyy'),
        gender: getOptionLabelByValue('gender', gender) || gender,
        zipCode,
        eligibility: getOptionLabelByValue('eligibility', eligibility) || eligibility,
        tier: tier,
        relationship: getOptionLabelByValue('relationType', relationType) || relationType,
        subscriberType: getOptionLabelByValue('subscriberType', subscriberType) || subscriberType,
        contractCode: (control.get('proposedPlanId').value || [])
          .map((quoteLineItemID) => {
            const plan = (this.formGroup.get('planTable') as FormArray).controls.find(
              (planControl) => planControl.get('quoteLineItemID').value === quoteLineItemID
            );
            return plan ? plan.get('contractCode').value : '';
          })
          .filter((code) => code)
          .join(', '),
        subscriberID: subscriberID,
        memberID: memberID,
        medicareEligible: medicareEligible
      };
    });

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportdata);
    ws['!cols'] = [];
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'CensusData');
    XLSX.writeFile(wb, this.fileName);
  }

  validateDropdownOptions(eligibilityOptions: string[]): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value as string;
      if (eligibilityOptions.includes(value)) {
        return null; // Validation passes
      } else {
        return { dropdownOptionValidator: true }; // Validation fails
      }
    };
  }

  async censusUpload(...args) {
    const target = args[0].target;
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    this.showLoader(true, false);
    const handleUpload = async (target) => {
      const file = target.files[0];
      target.value = '';

      try {
        const fileContents = await this.readUploadedFileAsBinaryString(file);
        this.handleCensusFileUpload(fileContents);
      } catch (e) {
        console.warn(e.message);
      }
    };

    await handleUpload(target);
  }

  readUploadedFileAsBinaryString(inputFile) {
    const reader: FileReader = new FileReader();

    return new Promise((resolve, reject) => {
      reader.onerror = (error) => {
        console.error('Error reading file:', error);
        reject(new Error('Error reading file:'));
      };

      reader.onload = () => {
        resolve(reader.result);
      };
      reader.readAsBinaryString(inputFile);
    });
  }

  handleCensusFileUpload(obj: any) {
    const wb: XLSX.WorkBook = XLSX.read(obj, {
      type: 'binary',
      cellDates: true,
      cellNF: false,
      cellText: false
    });

    /* grab first sheet */
    const wsname: string = wb.SheetNames[0];
    const ws: XLSX.WorkSheet = wb.Sheets[wsname];

    /* save data */
    let data = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, dateNF: 'MM-DD-YYYY' });
    data = data.filter((value) => JSON.stringify(value) !== '[]');
    
    
    /** clear the exsitng form array */
    this.censusReset();

    const censusTableConfig = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable');

    let mappedData = this.mapDataToCensusColumns(data, censusTableConfig.columns);

    if (this.getLobFromQuote(this.currentDataObj) === Lob.Vision && this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      const tierFieldConfig = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'tier');
      const eligibilityFieldConfig = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'eligibility');
      const relationTypeFieldConfig = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'relationType');
      const proposedPlanIdFieldConfig = this.getSectionOrFieldFromSchema(Sections.Census, 'censusTable', 'proposedPlanId');
      this.asyncMethodCall$.set({
        name: 'visCalcTotGroupSize',
        params: [
          {
            data: mappedData.map((row) => {
              return {
                [proposedPlanIdFieldConfig.name]: row[proposedPlanIdFieldConfig.path],
                [eligibilityFieldConfig.name]: row[eligibilityFieldConfig.path],
                [relationTypeFieldConfig.name]: row[relationTypeFieldConfig.path],
                [tierFieldConfig.name]: row[tierFieldConfig.path]
              };
            })
          }
        ]
      });
    }

    let censusFormGroup = this.prepareFormArrayForTable(censusTableConfig.columns, mappedData);
    censusFormGroup.forEach((cenus) => {
      const rowId = new FormControl(Math.random() + Date.now());
      let formControls = { _rowId: rowId };
      let newObj = {};
      censusTableConfig.columns.forEach((col) => {
        this.prepareRowFormControl(col, {}, formControls);
        if (col.path) {
          this.createNewObjectWithPath(col.path, newObj);
        }
      });
      let parentArray = this.getValueFromPath(censusTableConfig.path, this.currentDataObj);
      parentArray.push(newObj);

      (this.formGroup.get('censusTable') as FormArray).push(cenus);
    });

    this.addHistoryObj(this.currentDataObj);
    const keyMessage = tableHistoryKeys.find((x) => x.name === 'censusTable');
    // Handle the case where arrays are not equal
    if (
      keyMessage &&
      !this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(
        keyMessage?.key
      )
    ) {
      this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] =
        keyMessage.message;
    }
    

    this.showLoader(false, false);

    // Update add plan button state after census upload
    this.updateAddPlanButtonState();

    setTimeout(() => {
      this.checkCensusDataValidity();
    }, 500);
  }

  checkCensusDataValidity() {
    const censusFormArray = this.formGroup.get('censusTable') as FormArray;

    if (censusFormArray.invalid) {
      let invalidElementsId = [];
      censusFormArray.controls.forEach((group: FormGroup, index) => {
        group.markAsTouched();
        group.updateValueAndValidity();
        const controls = group.controls;
        Object.keys(controls).forEach((key) => {
          const control = controls[key] as FormControl;

          if (control.invalid) {
            control.markAsTouched();
            control.updateValueAndValidity();

            const idString = `censusTable_${index}_${key}`;
            invalidElementsId.push(idString);
          }
        });
      });

      if (invalidElementsId.length) {
        const element = document.getElementById(invalidElementsId[0]);

        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }

  // Function to map data array values to census columns
  mapDataToCensusColumns(dataArray: any[], columns: any[]) {
    // Get the field names from the first row of the data array
    const fieldNames = dataArray[0];

    // Create a mapping from field names to column fields
    const fieldToColumnMapping = columns.reduce((acc, column) => {
      acc[column.excelField?.toLowerCase()] = column.path;
      return acc;
    }, {});

    // Create a mapping for possible values
    const possibleValuesMapping = columns.reduce((acc, column) => {
      if (column.options) {
        column.options.forEach((option) => {
          if (option.possibleValues) {
            option.possibleValues.forEach((value) => {
              acc[value.toUpperCase()] = option.value;
            });
          }
        });
      }
      return acc;
    }, {});

    // Function to normalize values using the possible values mapping
    function normalizeValue(value: string): string {
      if (value && typeof value === 'string') {
        return possibleValuesMapping[value.toUpperCase()] || value;
      }
      return value || '';
    }

    // Map the data array values to the census columns using the field names
    return dataArray.slice(1).map((row) => {
      let id = this.commonService.generateID('CE');
      let mappedRow: any = {};
      mappedRow['id'] = id;
      fieldNames.forEach((fieldName, index) => {
        const field = fieldToColumnMapping[fieldName?.toLowerCase()];
        if (field) {
          let cellValue = row[index];
          cellValue = normalizeValue(cellValue);
          // Transform firstName and lastName to uppercase
          if (field === 'firstName' || field === 'lastName') {
            cellValue = cellValue.toUpperCase();
          }
          if (field === 'proposedPlanId') {
            const planTableFormArray = this.formGroup.get('planTable') as FormArray;
            const contractCodes = cellValue?.split(',').map((code) => code.trim());
            if (planTableFormArray && contractCodes) {
              cellValue = planTableFormArray.controls
                .filter((control) => contractCodes.map((code) => code.toLowerCase()).includes(control.get('contractCode').value.toLowerCase()))
                .map((control) => control.get('quoteLineItemID').value);
            } else {
              cellValue = [];
            }
          }
          mappedRow[field] = cellValue;
        }
      });
      return mappedRow;
    });
  }

  createNewObjectWithPath(pathValue, obj) {
    let current = obj;
    const paths = pathValue.split('.');
    const lastKeyIndex = paths.length - 1;

    paths.forEach((path, index) => {
      if (index === lastKeyIndex) {
        current[path] = '';
      } else {
        if (!current[path]) {
          current[path] = {};
        }

        current = current[path];
      }
    });
  }

  // Current Carrier (Optional Info)
  addCurrentPlan(existingValue?: any) {
    const currentPlanTableConfig = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');

    let newObj = {};

    currentPlanTableConfig.columns.forEach((col) => {
      if (col.show !== 'false') {
        if (col.path) {
          this.createNewObjectWithPath(col.path, newObj);

          if (existingValue) {
            this.setValueAtPath(col.path, existingValue[col.name], newObj);
          }

          if (col.dynamicPath?.includes('rateInfo')) {
            // Setting "tier" property for each rates
            const parentPath = col.path.substring(0, col.path.lastIndexOf('.'));
            const tierValue = parentPath.substring(parentPath.lastIndexOf('.') + 1, parentPath.length);
            this.createNewObjectWithPath(parentPath + '.tier', newObj);
            this.setValueAtPath(parentPath + '.tier', tierValue, newObj);
          }
        }
      }
    });

    let rowDataObj = existingValue ? newObj : { id: this.commonService.generateID('CU') };

    const rowId = new FormControl(Math.random() + Date.now());
    let formControls = { _rowId: rowId };
    currentPlanTableConfig.columns.forEach((col) => {
      this.prepareRowFormControl(col, rowDataObj, formControls);
    });

    let parentArray = this.getValueFromPath(currentPlanTableConfig.path, this.currentDataObj);
    if (!parentArray) {
      this.setValueAtPath(currentPlanTableConfig.path, [], this.currentDataObj);
      parentArray = this.getValueFromPath(currentPlanTableConfig.path, this.currentDataObj);
    }
    parentArray.push(newObj);

    let newFormGroup = this.fb.group(formControls);
    
    // Add component rate controls for renewal opportunities (matching initial form build logic)
    if (this.getLobFromQuote(this.currentDataObj) !== Lob.SuppHealth && 
        this.viewSettings.opportunityType === OpportunityType.RenewalLocal &&
        currentPlanTableConfig?.togglerColumns &&
        existingValue) {
      const tieredRateInfo = existingValue.rateInfo?.TIERED;
      if (tieredRateInfo && Object.keys(tieredRateInfo).length > 1) {
        // Add _showSubCols control for component rates
        (newFormGroup as any).addControl('_showSubCols', new FormControl(true));
        
        // Add component rate controls from togglerColumns
        currentPlanTableConfig.togglerColumns.forEach((togglerColumn) => {
          let formTogglerArray = this.prepareFormArrayForTable(togglerColumn.columns, [existingValue]);
          formTogglerArray.forEach((toggleGroup) => {
            Object.keys(toggleGroup.controls).forEach((ctrlName) => {
              (newFormGroup as any).addControl(ctrlName, toggleGroup.get(ctrlName));
            });
          });
        });
      }
    }
    
    (this.formGroup.get('currentCarrierTable') as FormArray).push(newFormGroup);
  }

  removeCurrentsPlan() {
    this.blockValueChangeDetection = true;
    const currentPlanTableConfig = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');

    let formArray = this.formGroup.get('currentCarrierTable') as FormArray;
    let removeIndexes = formArray.value
      .map((e, index) => {
        if (e.checkbox) {
          return index;
        }
      })
      .filter((e) => e !== undefined);

    let parentArray = this.getValueFromPath(currentPlanTableConfig.path, this.currentDataObj);
    removeIndexes.reverse().forEach((i) => {
      formArray.removeAt(i);
      parentArray.splice(i, 1);
    });
    if (removeIndexes && removeIndexes.length) {
      this.updateCurrentCarrierHistory();
    }

    this.formGroup.get('currentCarrierTableCheckAll').setValue(false, { emitEvent: false });

    this.populateCurrentPlanOptions();
    this.blockValueChangeDetection = false;
  }

  updateCurrentCarrierHistory() {
    this.addHistoryObj(this.currentDataObj);
    const keyMessage = tableHistoryKeys.find((x) => x.name === 'currentCarrierTable');
    if (
      keyMessage &&
      !this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(
        keyMessage?.key
      )
    ) {
      this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] =
        keyMessage.message;
    }
  }

  // Sales & Broker (Optional Info)
  addBrokerAndSalesInfo() {
    const salesBrokerTableConfig = this.getSectionOrFieldFromSchema(Sections.SalesAndBroker, 'salesAndBrokerTable');

    if (!salesBrokerTableConfig) {
      console.error('Sales and Broker table configuration not found');
      return;
    }

    const formArray = this.formGroup.get('salesAndBrokerTable') as FormArray;

    let newObj = {};
    const rowId = new FormControl(Math.random() + Date.now());
    let formControls = { _rowId: rowId };
    salesBrokerTableConfig.columns.forEach((col) => {
      this.prepareRowFormControl(col, {}, formControls);
      if (col.path) {
        this.createNewObjectWithPath(col.path, newObj);
      }
    });
    newObj['usDomainId'] = '';
    newObj['lobSupported'] = [this.viewSettings.lob];

    let parentArray = this.getValueFromPath(salesBrokerTableConfig.path, this.currentDataObj);
    parentArray.push(newObj);

    const newFormGroup = this.fb.group(formControls);
    formArray.push(newFormGroup);
  }

  removeBrokerAndSalesInfo() {
    let removingPrimaryUser: boolean = false;
    const salesBrokerTableConfig = this.getSectionOrFieldFromSchema(Sections.SalesAndBroker, 'salesAndBrokerTable');

    let formArray = this.formGroup.get('salesAndBrokerTable') as FormArray;
    let removeIndexes = formArray.value
      .map((e, index) => {
        if (e.checkbox) {
          if (formArray.at(index).get('contactUsage').value === 'Primary') {
            removingPrimaryUser = true;
          }

          return index;
        }
      })
      .filter((e) => e !== undefined);

    removeIndexes.reverse().forEach((i) => {
      formArray.removeAt(i);
      let parentArray = this.getValueFromPath(salesBrokerTableConfig.path, this.currentDataObj);
      parentArray.splice(i, 1);
    });
    if (removeIndexes && removeIndexes.length) {
      this.addHistoryObj(this.currentDataObj);
      const keyMessage = tableHistoryKeys.find((x) => x.name === 'salesAndBrokerTable');
      // Handle the case where arrays are not equal
      if (
        keyMessage &&
        !this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(
          keyMessage?.key
        )
      ) {
        this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1].changeSetDetail.adjustmentData.newValue[keyMessage.key] =
          keyMessage.message;
      }
    }

    this.formGroup.get('salesAndBrokerTableCheckAll').setValue(false, { emitEvent: false });
    if (removingPrimaryUser) {
      const firstValidIndex = formArray.getRawValue().findIndex((e) => !['Broker', 'Submitter'].includes(e.role));
      if (firstValidIndex >= 0) {
        formArray.at(firstValidIndex).get('contactUsage').setValue('Primary', { emitEvent: false });
      }
    }
  }

  userTypeChanged(...args) {
    const { value, field, _rowId } = args[0];

    const salesAndBrokerArray = this.formGroup.get('salesAndBrokerTable') as FormArray;
    const rowIndex = this.getFormTableRowUsingRowId(salesAndBrokerArray, _rowId);

    const primaryUsercontrol = (salesAndBrokerArray.at(rowIndex) as FormGroup).get('contactUsage');

    // Used to block change detection on primary user field because of a bug in angular reactive forms.
    this.blockValueChangeDetection = true;
    if (['Broker', 'Submitter'].includes(value)) {
      primaryUsercontrol.patchValue('', { emitEvent: false, onlySelf: true });
      primaryUsercontrol.disable();
    } else {
      primaryUsercontrol.enable();
    }

    const primaryUserIndex = salesAndBrokerArray.getRawValue().findIndex((e) => e.contactUsage === 'Primary');
    const firstValidIndex = salesAndBrokerArray.getRawValue().findIndex((e) => !['Broker', 'Submitter'].includes(e.role));

    if (primaryUserIndex === -1) {
      if (firstValidIndex >= 0) {
        const control = salesAndBrokerArray.at(firstValidIndex).get('contactUsage');
        control.patchValue('Primary', { emitEvent: false, onlySelf: true });
      }
    }

    this.blockValueChangeDetection = false;
  }

  initUserType() {
    const salesAndBrokerArray = this.formGroup.get('salesAndBrokerTable') as FormArray;
    this.blockValueChangeDetection = true;
    salesAndBrokerArray.controls.forEach((group) => {
      if (['Broker', 'Submitter'].includes(group.get('role').value)) {
        group.get('contactUsage').disable();
      }
    });
    this.blockValueChangeDetection = false;
  }

  primaryUserChanged(...args) {
    const { value, field, _rowId } = args[0];
    const salesAndBrokerArray = this.formGroup.get('salesAndBrokerTable') as FormArray;
    const rowIndex = this.getFormTableRowUsingRowId(salesAndBrokerArray, _rowId);

    this.blockValueChangeDetection = true;
    salesAndBrokerArray.controls.forEach((group) => {
      group.get('contactUsage').setValue('', { emitEvent: false, onlySelf: true });
    });

    salesAndBrokerArray.at(rowIndex).get('contactUsage').setValue(value, { emitEvent: false, onlySelf: true });
    this.blockValueChangeDetection = false;
  }

  testOppValueModifier(...args) {
    const { value, field, type } = args[0];

    if (type === 'get') {
      return value === 'TEST' ? true : false;
    }

    if (type === 'set') {
      return value === true ? 'TEST' : 'REAL';
    }
  }

  countyCodeValueModifier(...args) {
    const { value, field, type } = args[0];

    if (type === 'get') {
      return value;
    }

    if (type === 'set') {
      return field.options.find((opt) => opt.value === value)?.valueLabel ?? value;
    }
  }

  userTypeValueModifier(...args){
    const { value, field, type } = args[0];

    if (type === 'get') {
      return value === "Account Exec" ? "Account Executive" : value;
    }

    if (type === 'set') {
      if (value === "Account Executive") {
        const salesBrokerTableConfig = this.getSectionOrFieldFromSchema(Sections.SalesAndBroker, 'salesAndBrokerTable');
        let parentArray = this.getValueFromPath(salesBrokerTableConfig.path, this.currentDataObj);
        if (parentArray && parentArray.some((obj) => obj.role === 'Account Exec')) {
          return 'Account Exec';
        }
      }
      return value;
    }
  }

  portfolioPlansValueModifier(...args) {
    const { value, field, type } = args[0];

    if (type === 'get') {
      return value === 'Yes' ? true : false;
    }

    if (type === 'set') {
      return value === true ? 'Yes' : 'No';
    }
  }

  participationRateValueModifier(...args) {
    const { value, field, type } = args[0];

    if (type === 'get') {
      const participationRateValue = value.find((rate) => rate.type === 'WholeCase')?.value ?? '';
      const modifiedParticipationRateValue = !StringUtils.isEmpty(participationRateValue) ? participationRateValue * 100 : participationRateValue;
      return modifiedParticipationRateValue.toLocaleString('en', { minimumFractionDigits: 2 });
    }

    if (type === 'set') {
      const participationRate = this.getValueFromPath(field.path, this.currentDataObj) || [];
      if (participationRate.length) {
        const existingRate = participationRate.find((rate) => rate.type === 'WholeCase');
        if (existingRate) {
          let lastKey = 'Participation %';
          if (
            !this.currentDataObj.data?.updateHistory[
              this.currentDataObj.data.updateHistory.length - 1
            ]?.changeSetDetail?.adjustmentData?.newValue.hasOwnProperty(lastKey)
          ) {
            if (existingRate.value !== (value / 100).toString()) {
              if (!StringUtils.isEmpty(value)) {
                this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1].changeSetDetail.adjustmentData.newValue[lastKey] =
                  value ? value + '%' : value;
              }
              if (
                !this.currentDataObj.data?.updateHistory[
                  this.currentDataObj.data.updateHistory.length - 1
                ]?.changeSetDetail?.adjustmentData?.oldValue.hasOwnProperty(lastKey)
              ) {
                this.currentDataObj.data.updateHistory[this.currentDataObj.data.updateHistory.length - 1].changeSetDetail.adjustmentData.oldValue[lastKey] =
                  (parseFloat(existingRate.value) * 100).toLocaleString('en', { minimumFractionDigits: 2 }) + '%';
              }
            }
          }
          existingRate.value = (value / 100).toString();
        }
      } else {
        participationRate.push({
          type: 'WholeCase',
          value: (value / 100).toString()
        });
      }

      return participationRate;
    }
  }

  employerFundingLevelValueModifier(...args) {
    const { value, field, type } = args[0];

    if (type === 'get') {
      return !StringUtils.isEmpty(value) ? (parseFloat(value) * 100).toLocaleString('en', { minimumFractionDigits: 2 }) : value;
    }

    if (type === 'set') {
      return !StringUtils.isEmpty(value) ? (value / 100).toString() : '';
    }
  }

  initInputTierVision(...args) {
    const { field } = args[0];
    const selectedTier = this.formGroup.get(field.name).value;
    this.prepareSummaryCensus(selectedTier ? selectedTier + '' : '5', null);
  }

  populateSummaryCensus(availableTiers, selectedTier, inputTierChanged = false) {
    if (this.viewSettings.opportunityType === OpportunityType.RenewalLocal && this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);
      let summaryCensusBreakDown = {}
      let totalGroupSize = 0;
      
      const existingTotGroupSize = this.getValueOfPropertyFromDataObject('totGroupSize', this.currentDataObj);
      availableTiers.forEach((t) => {
        const field = this.getSectionOrFieldFromSchema(Sections.SummaryCensus, t.pathString.toLowerCase(), null, false, this.getLobFromQuote(this.currentDataObj, true));
        let value = this.getValueFromPath(field.path, this.currentDataObj);

        if (!value) {
          const tier = availableTiers.filter((p) => p.pathString.toLowerCase() === t.pathString.toLowerCase())[0].tier;
          const lob = this.getLobFromQuote(this.currentDataObj, true);
          const currentCarrierDetails: any[] = this.getValueOfPropertyFromDataObject('currentPlans', this.currentDataObj, lob) ?? [];
          const currentCarrierTable = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');
          const dynamicPath = currentCarrierTable.columns.filter((col) => col.dynamicPath && col.name === `sbscrbr${tier}`);
          const path = dynamicPath[0].dynamicPath.replace(`{${tier}}`, t.pathString.toUpperCase());

          let finalValue = 0;
          currentCarrierDetails.forEach((row) => {
            const value = this.getValueFromPath(path, row);
            finalValue = finalValue + +value;
          });
          summaryCensusBreakDown[t.pathString.toLowerCase()] = finalValue;
          totalGroupSize = totalGroupSize + finalValue;
        }
      });


      if((+(existingTotGroupSize) && +existingTotGroupSize === totalGroupSize) || (!+existingTotGroupSize)) {
        for(let tier in summaryCensusBreakDown) {
          const summarCensusfield = this.getSectionOrFieldFromSchema(Sections.SummaryCensus, tier);
          this.setValueAtPath(summarCensusfield.path, summaryCensusBreakDown[tier] + '', this.currentDataObj);
        }
      }

    }
  }

  prepareSummaryCensus(selectedTier, previousTier) {
    if (!this.getSectionOrFieldFromSchema(Sections.SummaryCensus)) {
      return;
    }

    const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);
    const lob = this.getLobFromQuote(this.currentDataObj).toLowerCase();
    const availableTiers = tierDetails.map((t) => t.pathString.toLowerCase());
    const marketSegment = this.getValueOfPropertyFromDataObject('marketSegment', this.currentDataObj);
    const oppType = this.getValueOfPropertyFromDataObject('opportunityType', this.currentDataObj);
   
    this.populateSummaryCensus(tierDetails, selectedTier, selectedTier !== previousTier);
   
    availableTiers.forEach((tier) => {
      const field = this.getSectionOrFieldFromSchema(Sections.SummaryCensus, tier, null, false, lob);
      let value = this.getValueFromPath(field?.path, this.currentDataObj) ?? '';

      if (marketSegment === MarketSegments.LargeGroup && oppType === OpportunityType.RenewalLocal) {
        value = value ?? null;
        value = !isNaN(+value) ? +value : 0;
      }

      const control = new FormControl(value + '', this.getValidators(field.validators));
      if (field.changeHandler) {
        control.valueChanges
          .pipe(
            startWith(value),
            pairwise(),
            filter((_) => !this.blockValueChangeDetection),
            takeUntil(this.destroy$),
            takeUntil(this.quoteChanged$)
          )
          .subscribe(([previousVal, val]) => {
            let handlerName = field.changeHandler;

            if (handlerName && typeof this[handlerName] === 'function') {
              this[handlerName].apply(this, [
                {
                  value: val,
                  field: field,
                  previousVal: previousVal
                }
              ]);
            }
          });
      }

      this.formGroup.addControl(tier, control);
      this.quoteFieldsToUpdate[field.name] = {
        path: field.path,
        name: field.name,
        type: field.type,
        label: field.label
      };
      field.show = 'true';
    });

    if (previousTier) {
      const prevTierDetails: TierDetails[] = TierRatesMap.get(previousTier);

      prevTierDetails
        .filter((td) => !availableTiers.includes(td.pathString.toLowerCase()))
        .map((t) => t.pathString.toLowerCase())
        .forEach((tier) => {
          const field = this.getSectionOrFieldFromSchema(Sections.SummaryCensus, tier);

          if (this.formGroup.get(field.name)) {
            this.formGroup.removeControl(field.name);
            field.show = 'false';
            delete this.quoteFieldsToUpdate[field.name];
          }
        });

      let currentSummaryCensus = this.getValueOfPropertyFromDataObject('summaryCensus', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true));

      this.getSectionOrFieldFromSchema(Sections.SummaryCensus)
        .fields.filter((field) => ![...availableTiers, 'waivers', 'totGroupSize'].includes(field.name))
        .map((f) => f.name)
        .forEach((name) => {
          delete currentSummaryCensus[name];
        });

      this.setValueOfPropertyOfDataObject('summaryCensus', currentSummaryCensus, this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true));
    }

    this['summaryCensusTierFieldChanged'].apply(this, [{
        inputTierChange: (selectedTier && previousTier && selectedTier !== previousTier) ? true : false
      }
    ]);
  }

  summaryCensusTierFieldChanged(...args) {
    let { value, inputTierChange } = args[0];
    if(value === undefined && !inputTierChange) {
      return;
    }

    const selectedTier = this.formGroup.get('inputTier').value;
    const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);

    let total = 0;

    const availableTiers = tierDetails.map((t) => t.pathString.toLowerCase());
    availableTiers.forEach((tier) => {
      const field = this.getSectionOrFieldFromSchema(Sections.SummaryCensus, tier);
      const fieldValue = ((+this.formGroup.get(field.name).value) || 0);
      total = total + fieldValue;
    });


    total = total + ((+this.formGroup.get('waivers').value) || 0);
    if (total >= 0) {
      this.formGroup.get('totGroupSize').setValue(total + '', { emitEvent: false });
    }
  }

  async inputTierChangedVision(...args) {
    const { value, previousVal } = args[0];
    const selectedTier = value ? value + '' : '5';

    this.prepareSummaryCensus(selectedTier, previousVal);
    this.inputTierChanged(...args);
  }

  async inputTierChanged(...args) {
    const { value, field, previousVal } = args[0];
    let confirmed = true;
    if (value === previousVal) {
      // having value/previousVal same means change is not triggered on actual form value change.
      return new Promise((resolve) => resolve(true));
    }

    const currentPlansFormArray = this.formGroup.get('currentCarrierTable') as FormArray;
    const hasEnrollment = currentPlansFormArray.controls.some((group: FormGroup) => {
      const controls = group.controls;
      let hasValues = false;
      Object.keys(controls).forEach((key) => {
        if (key.includes('enroll') && ![0, ''].includes(controls[key].value)) {
          hasValues = true;
        }
      });
      return hasValues;
    });

    if (hasEnrollment) {
      confirmed = await new Promise((resolve) => {
        this.confirmationService.confirm({
          message: 'Current Plan Enrollments need to be readjusted on Tier change. Are you sure that you want to proceed?',
          header: 'Confirmation',
          acceptButtonStyleClass: 'dialog-button-icon',
          rejectButtonStyleClass: 'dialog-button-icon',
          accept: () => {
            resolve(true);
          },
          reject: () => {
            resolve(false);
          }
        });
      });
    }

    if (confirmed) {
      this.prepareCurrentPlansTable(value, false, true);
    } else {
      this.formGroup.get(field.name).patchValue(previousVal, { emitEvent: false });
    }

    return new Promise((resolve) => resolve(true));
  }

 prepareCurrentRatesAfterTierChange() {
    const currentPlansFormArray = this.formGroup.get('currentCarrierTable') as FormArray;
    const currentCarrierTable = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');

    const formRowCopy = structuredClone(currentPlansFormArray.getRawValue());
    formRowCopy.forEach((values) => {
      this.currtCarrierFundingTypeChange(values);
    });
    
    // Fix: Recreate _showSubCols and component rate controls after tier change (matching initial buildForm behavior)
    if (currentCarrierTable?.togglerColumns && this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      currentPlansFormArray.controls.forEach((group: FormGroup) => {
        const idBasedRateInfo = this.getValueOfPropertyFromDataObject('currentPlans', this.currentDataObj).filter((x) => x.id == group.get('id').value);
        if (idBasedRateInfo && idBasedRateInfo.length > 0) {
          const tieredRateInfo = idBasedRateInfo[0].rateInfo?.TIERED;
          if (tieredRateInfo && Object.keys(tieredRateInfo).length > 1) {
            // Recreate _showSubCols control if component rates exist
            if (!group.get('_showSubCols')) {
              group.addControl('_showSubCols', new FormControl(true));
            }
            
            // Recreate component rate controls if they don't exist
            currentCarrierTable.togglerColumns.forEach((togglerColumn) => {
              let formTogglerArray = this.prepareFormArrayForTable(togglerColumn.columns, idBasedRateInfo);
              formTogglerArray.forEach((toggleGroup) => {
                Object.keys(toggleGroup.controls).forEach((ctrlName) => {
                  if (!group.get(ctrlName)) {
                    group.addControl(ctrlName, toggleGroup.get(ctrlName));
                  }
                });
              });
            });
          }
        }
      });
    }
  }

  prepareCurrentPlansTable(value: string, skipFormChange: boolean = false, tierChange: boolean = false) {
    const selectedTier = value ? value + '' : '5';
    let tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);
    const currentCarrierTable = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');
    const fieldsToUpdateDetails = this.quoteFieldsToUpdate ? this.quoteFieldsToUpdate['currentCarrierTable'] : null;
    const oppOrigin = this.getValueOfPropertyFromDataObject('oppOrigin', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true));
    currentCarrierTable.columns.forEach((col) => {
      const dynamicPath = col['dynamicPath'] || null;
      const dynamicPathAlt = col['dynamicPathAlt'] || null;
      const colFieldsToUpdateDetailsIndex = fieldsToUpdateDetails ? fieldsToUpdateDetails.columns.findIndex(c => c.name === col.name) : -1;
      if (dynamicPath || dynamicPathAlt) {
        // Check if 2COMPOSIT and dynamicPath ends with .rate which is renewal or current rates
        if (oppOrigin?.originalRatingMethod === '2COMPOSIT' && dynamicPath && dynamicPath.endsWith('.rate')) {
          tierDetails = TwoCompositTierDetails;
        }
        const tierDetailIndex = tierDetails?.findIndex((t) => dynamicPath.includes(`{${t.tier}}`)) ?? null;

        if (tierDetailIndex > -1) {
          const tierParamKey = `{${tierDetails[tierDetailIndex].tier}}`;
          const pathString = tierDetails[tierDetailIndex].pathString;

          col.path = col.dynamicPath.replace(tierParamKey, pathString);
          if(dynamicPathAlt) {
            col.altPathRow = col.dynamicPathAlt.replace(tierParamKey, pathString);
          }
          
          col.show = 'true';
          col.header = oppOrigin?.originalRatingMethod === '2COMPOSIT' ? tierDetails[tierDetailIndex].header : pathString;
          if (colFieldsToUpdateDetailsIndex > -1) {
            fieldsToUpdateDetails.columns.splice(colFieldsToUpdateDetailsIndex, 1, col);
          }
        } else {
          col.show = 'false';
          col.path = '';
          if (colFieldsToUpdateDetailsIndex > -1) {
            fieldsToUpdateDetails.columns.splice(colFieldsToUpdateDetailsIndex, 1, col);
          }
        }
      }

      
    });

    currentCarrierTable.togglerColumns?.forEach((tc) => {
      tc.columns.forEach((col) => {
        const subColToUpdateIndex = this.subColumnsToUpdate.findIndex(cl => cl.name === col.name);
        const dynamicPath = col['dynamicPath'] || null;
        
        if (dynamicPath) {
          const tierDetailIndex = tierDetails?.findIndex((t) => dynamicPath.includes(`{${t.tier}}`)) ?? null;

          if (tierDetailIndex > -1) {
            const tierParamKey = `{${tierDetails[tierDetailIndex].tier}}`;
            const pathString = tierDetails[tierDetailIndex].pathString;

            col.show = 'true';
            col['visible'] = true;
            col.path = col.dynamicPath.replace(tierParamKey, pathString);
            if (subColToUpdateIndex > -1) {
              this.subColumnsToUpdate.splice(subColToUpdateIndex, 1, col);
            }
          } else {
            col.show = 'false';
            col['visible'] = false;
            col.path = '';
            if (subColToUpdateIndex > -1) {
              this.subColumnsToUpdate.splice(subColToUpdateIndex, 1, col);
            }
          }
        }
      });
    });

    //component Rates start
    if (this.getLobFromQuote(this.currentDataObj) !== Lob.SuppHealth && this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      this.updateTogglerButton();
      currentCarrierTable.togglerColumns.forEach((componentColumns) => {
        componentColumns.colspan = 6 + 2 * parseInt(selectedTier) - 1;
        componentColumns.columns.forEach((col) => {
          const compDynamicPath = col['dynamicPath'] || null;
          if (compDynamicPath) {
            const tierIndex = tierDetails.findIndex((t) => compDynamicPath.includes(`{${t.tier}}`));
            if (tierIndex > -1) {
              const tierParamKey = `{${tierDetails[tierIndex].tier}}`;
              const pathString = tierDetails[tierIndex].pathString;

              col.path = col.dynamicPath.replace(tierParamKey, pathString);
              col.show = 'true';
              col.header = pathString;
            } else {
              col.show = 'false';
              col.path = '';
            }
          }
        });
      });
    }

    //component Rates end
    currentCarrierTable.parentHeaders.forEach((header) => {
      if (header.ratesHeader) {
        header.colspan = +selectedTier;
      }
      if (oppOrigin?.originalRatingMethod === '2COMPOSIT' && (header?.header == "Current Rates" || header?.header == "Renewal Rates")) {
        header.colspan = 2;
      }
    });

    if (!skipFormChange) {
      const currentPlansFormArray = this.formGroup.get('currentCarrierTable') as FormArray;

      const hasFormRows = currentPlansFormArray.length > 0;
      if (hasFormRows) {
        const baseArray = this.getValueFromPath(currentCarrierTable.path, this.currentDataObj);

        delete baseArray.rateInfo;
        const formRowCopy = structuredClone(currentPlansFormArray.getRawValue());

        const valueBeforeTierChange = structuredClone((this.formGroup.get('planTable') as FormArray).controls.map((group) => group.get('currPlanId').value));
        let removalEnabled = true;
        currentPlansFormArray.controls.forEach((group) => {
          if (group.get('checkbox') === null) {
            removalEnabled = false;
          }
          group.get('checkbox')?.setValue(true);
        });

        if (removalEnabled) {
          this.removeCurrentsPlan();

          formRowCopy.forEach((values) => {
            this.addCurrentPlan(values);
          });
        }

        if (tierChange && this.getLobFromQuote(this.currentDataObj) !== Lob.SuppHealth) {
          this.prepareCurrentRatesAfterTierChange();
        }

        this.populateCurrentPlanOptions(valueBeforeTierChange);
      }
    }
  }

  toggleCount(
    isExpanded: boolean | undefined,
    columnNameIncludes: string,
    headerName: string,
    toggleStateProperty: 'isMemberCountExpanded' | 'isSubscriberCountExpanded'
  ): void {
    const selectedTier = this.formGroup.get('inputTier')?.value;
    this[toggleStateProperty] = isExpanded !== undefined ? isExpanded : !this[toggleStateProperty];

    const currentCarrierTable = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');

    if (currentCarrierTable && currentCarrierTable.columns) {
      currentCarrierTable.columns.forEach((col) => {
        if (col.name.includes(columnNameIncludes)) {
          // Store the original minWidth if not already stored
          if (!col.originalMinWidth) {
            col.originalMinWidth = col.minWidth;
          }

          // Adjust the minWidth dynamically
          col.minWidth = this[toggleStateProperty] ? col.originalMinWidth : '0px';

          // Hide or show the column
          col['hidden'] = !this[toggleStateProperty];
        }
      });
    }

    if (currentCarrierTable && currentCarrierTable.parentHeaders) {
      currentCarrierTable.parentHeaders.forEach((header) => {
        if (header.header === headerName) {
          // Set colspan dynamically
          header.colspan = this[toggleStateProperty] ? +selectedTier : +selectedTier;

          // Adjust the minWidth of the parent header dynamically
          header.minWidth = this[toggleStateProperty] ? header.originalMinWidth || '100px' : '0px';

          // Store the original minWidth of the parent header if not already stored
          if (!header.originalMinWidth) {
            header.originalMinWidth = header.minWidth;
          }
        }
      });
    }
  }

  memberCountToggle(isExpanded?: boolean): void {
    this.toggleCount(isExpanded, 'mem', 'Member Count', 'isMemberCountExpanded');
  }

  subscriberCountToggle(isExpanded?: boolean): void {
    this.toggleCount(isExpanded, 'sbscrbr', 'Subscriber Count', 'isSubscriberCountExpanded');
  }

  //current component rates toggle click handler
  componentRatesToggle() {
    const currentCarrierTable = this.getSectionOrFieldFromSchema(Sections.CurrentCarrier, 'currentCarrierTable');
    if (currentCarrierTable.togglerColumn) {
      currentCarrierTable.togglerColumn = false;
    } else {
      currentCarrierTable.togglerColumn = true;
    }
  }

  setOrRemoveAlertMsg(isVisible, msg, alertClass?) {
    this.alert = {
      show: isVisible,
      message: msg,
      type: '',
      cssClass: alertClass || AlertType.Error,
      header: '',
      headerVisibility: isVisible
    };

    if (this.alert.show) {
      window.scroll(0, 0);
    }
  }

  showPopupAlertMessage(msg) {
    if (this.showAlert) {
      return;
    }

    this.alertMessage = msg;
    this.showAlert = true;
  }

  async showWaitingPopupAlertMessage(msg) {
    await new Promise((resolve) => {
      this.confirmationService.confirm({
        message: msg,
        header: 'Alert',
        acceptButtonStyleClass: 'dialog-button-icon',
        acceptLabel: 'OK',
        rejectButtonStyleClass: 'alert-cancel',
        accept: () => {
          resolve(true);
        }
      });
    });

    // this.showAlert = true;
    return new Promise((resolve) => resolve(true));
  }

  setMessageStringParams(messageParams, message) {
    let messageStr = message;
    Object.keys(messageParams).forEach((key) => {
      let messagekey = `{${key}}`;
      messageStr = messageStr.replace(new RegExp(messagekey, 'g'), messageParams[key]);
    });

    return messageStr;
  }

  isValidQuote(quote, isSubmit, changesCheck: boolean = false): boolean {
    this.messageService.clear();

    const selectedPlans: any[] = this.getValueOfPropertyFromDataObject('proposedPlans', quote) ?? [];
    const censusDetails: any[] = this.getValueOfPropertyFromDataObject('census', quote) ?? [];
    const currentCarrierDetails: any[] = this.getValueOfPropertyFromDataObject('currentPlans', quote) ?? [];
    const salesAndBrokerInfo: any[] = this.getValueOfPropertyFromDataObject('userInfo', quote) ?? [];
    const fundingType = this.formGroup.get('fundingType')?.value || '';
    const lob = this.getLobFromQuote(this.currentDataObj);

    this.formGroup.markAllAsTouched();

    if (isSubmit && selectedPlans.length === 0) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.NonPlansSelected });
      this.scrollToErrorSectionOrTable(Sections.Plan);
      return false;
    }

    if (isSubmit && this.viewSettings.opportunityType === OpportunityType.RenewalLocal) {
      const allIncluded = currentCarrierDetails.every((carrier) => {
        return selectedPlans.some((plan) => plan.currPlanId?.includes(carrier.id));
      });
      if (!allIncluded && currentCarrierDetails.length > 0) {
        this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.CurrentPlanMapWarning });
        this.scrollToErrorSectionOrTable(Sections.Plan);
        return false;
      }
      const hasUnmappedPlans = selectedPlans.some((plan) => !plan.currPlanId || plan.currPlanId.length === 0);
      if (hasUnmappedPlans && currentCarrierDetails.length > 0) {
        this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.CurrentPlanMapWarning });
        this.scrollToErrorSectionOrTable(Sections.Plan);
        return false;
      }
    }
    
    if (!changesCheck && selectedPlans.length > 0 && !this.hasSupportedContractCodes()) {
      this.showInvalidPlansForFundingType(fundingType);
      return false;
    }

    if (lob === Lob.Medical) {
      if (censusDetails.length === 0) {
        this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.EmptyCensus });
        this.scrollToErrorSectionOrTable(Sections.Census);
        return false;
      }
    }

    if (lob === Lob.Vision) {
      const selectedTier = this.formGroup.get('inputTier').value;
      const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);

      let isSummaryCensusValid = true;
      const availableTiers = tierDetails?.map((t) => t.pathString.toLowerCase());
      availableTiers?.forEach((tier) => {
        if (this.formGroup.get(tier).invalid) {
          this.formGroup.updateValueAndValidity({ onlySelf: true });
          isSummaryCensusValid = false;
        }
      });

      if (!isSummaryCensusValid) {
        this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.EmptySummaryCensus });
        this.scrollToErrorSectionOrTable(Sections.SummaryCensus);
        return false;
      }
    }

    const censusDetailsControl = this.formGroup.get('censusTable');
    
    if (censusDetailsControl && (censusDetails.length > 0 && censusDetailsControl?.invalid)) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.EmptyCensus });
      this.scrollToErrorSectionOrTable(Sections.Census);
      this.checkCensusDataValidity();
      return false;
    }

    const currentCarrierControl = this.formGroup.get('currentCarrierTable');
    if (currentCarrierDetails.length > 0 && currentCarrierControl.invalid) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.InvalidCurrentCarrier });
      this.scrollToErrorSectionOrTable(Sections.CurrentCarrier);
      return false;
    }

    const salesAndBrokerControl = this.formGroup.get('salesAndBrokerTable');
    if (salesAndBrokerInfo.length > 0 && salesAndBrokerControl.invalid) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.InvalidSalesAndBroker });
      this.scrollToErrorSectionOrTable(Sections.SalesAndBroker);
      return false;
    }

    const employerFundingLevelControl = this.formGroup.get('employerFundingLevel');
    const medParticipationPercentControl = this.formGroup.get('medParticipationPercent');

    if ((medParticipationPercentControl && medParticipationPercentControl.invalid) || (employerFundingLevelControl && employerFundingLevelControl.invalid)) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.QuoteInfoInvalidPercent });
      this.scrollToErrorSectionOrTable(Sections.QuoteInfo);
      return false;
    }

    let hasCommisionIssue = false;
    if (fundingType) {
      if (fundingType === FundingTypes.ABF && this.formGroup.get('abfCommission')?.invalid) {
        hasCommisionIssue = true;
      } else if (fundingType === FundingTypes.FI && this.formGroup.get('fiCommission')?.invalid) {
        hasCommisionIssue = true;
      }

      if (hasCommisionIssue) {
        let messageParams = {
          fundingType: fundingType
        };
        let message = CreateOppScreenMessages.InvalidFundingCommisionValue as string;
        message = this.setMessageStringParams(messageParams, message);
        this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: message });
        this.scrollToErrorSectionOrTable(Sections.FundingInfo);
        return false;
      }
    }

    if (this.formGroup.invalid && !changesCheck) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.GenericFormError });
      this.scrollToErrorSectionOrTable(Sections.GroupInfo);
      return false;
    }

    if (!isSubmit && !changesCheck && !quote.data.hasOwnProperty('updateHistory')) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.NoChangesWarning });
      return false;
    }

    if (
      !isSubmit &&
      !changesCheck &&
      quote.data.hasOwnProperty('updateHistory') &&
      Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.newValue).length === 0 &&
      Object.keys(quote.data.updateHistory[quote.data?.updateHistory?.length - 1].changeSetDetail.adjustmentData.oldValue).length === 0
    ) {
      this.messageService.add({ severity: 'error', life: 5000, summary: 'Error', detail: CreateOppScreenMessages.NoChangesWarning });
      return false;
    }

    return true;
  }

  scrollToErrorSectionOrTable(id) {
    //this.scroller.scrollToAnchor("targetGreen");
    const element = document.getElementById(id);
    const offset = 95; // Gap from the top
    const elementPosition = element.getBoundingClientRect().top + window.scrollY;
    const offsetPosition = elementPosition - offset;

    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth'
    });
  }

  sortJsonKeysRecursive(json: any): any {
    if (typeof json !== 'object' || json === null) {
      return json; // Return the value as is if it's not an object or is null.
    }

    if (Array.isArray(json)) {
      // If the element is an array, sort each item
      return json.map((item) => this.sortJsonKeysRecursive(item));
    }

    // If the element is an object, we need to handle key sorting
    const sortedJson: any = {};
    const sortedKeys = Object.keys(json).sort();
    sortedKeys.forEach((key) => {
      sortedJson[key] = this.sortJsonKeysRecursive(json[key]);
    });

    return sortedJson;
  }

  showLoader(visibility: boolean, scrollToTop: boolean = false) {
    this.$loaderVisible.next(visibility);

    if (scrollToTop) {
      window.scroll(0, 0);
    }
  }

  setSectionInCurrentSchema(sectionName: string, replacementSectionDetails: any, lob?) {
    lob = lob ? lob : this.getLobFromQuote(this.currentDataObj, true);

    let sectionIndex;
    switch (sectionName) {
      case Sections.QuoteTable: {
        return;
      }

      default: {
        sectionIndex = this.schema.sections['quoteDetailsSections'].findIndex((sec) => sec.name === sectionName);
      }
    }

    if (sectionIndex > -1) {
      this.schema.sections['quoteDetailsSections'].splice(sectionIndex, 1, structuredClone(replacementSectionDetails));
    }
  }

  getSectionOrFieldFromSchema(sectionName: string, fieldName?: string, tableColumnName?: string, getFromOriginalSchema: boolean = false, lob: string = null) {
    lob = lob ? lob : this.getLobFromQuote(this.currentDataObj, true);
    if (lob !== this.schema['schemaLob']) {
      getFromOriginalSchema = true;
    }

    const schemaOriginal = structuredClone(this.schemaDetails[lob]);
    const schema = !getFromOriginalSchema ? this.schema : schemaOriginal;

    let section;
    switch (sectionName) {
      case Sections.QuoteTable: {
        section = schema.sections[Sections.QuoteTable][0];
        break;
      }

      default: {
        section = schema.sections['quoteDetailsSections'].find((sec) => sec.name === sectionName);
      }
    }

    if (!section) {
      return null;
    }

    if (fieldName) {
      const field = section.fields.find((field) => field.name === fieldName);

      if (tableColumnName) {
        return field.columns.find((col) => col.name === tableColumnName);
      }
      return field;
    }
    return section;
  }

  getFormTableRowUsingRowId(tableControl: FormArray, rowId) {
    let index = -1;
    tableControl.controls.forEach((group, i) => {
      if (group.get('_rowId').value === rowId) {
        index = i;
      }
    });
    return index;
  }

  getVisibleButtons(status: string, quote) {
    let availableLinks = structuredClone(ButtonStatusConfigMap.get(status));
    let hiddenLinks = [];
    const isAltQuote = this.getValueOfPropertyFromDataObject('alternateQuote', quote, this.getLobFromQuote(quote, true)) === 'Yes' ? true : false;
    const lob = this.getLobFromQuote(quote, true);
    const quotingType = this.getValueOfPropertyFromDataObject('quotingType', quote, lob);
    const { versionNumber } = quote.data;

    if (status === QuoteStatus.Failed && versionNumber > 1) {
      // Removing delete links for quotes which failed submit after a successful submit.
      hiddenLinks.push(Links.Delete);
    }

    const oppType = this.getValueOfPropertyFromDataObject('opportunityType', quote);
    // Base links visibility configuration
    if (this.viewSettings.screenOppType === OpportunityType.RenewalLocal) {
      hiddenLinks.push(Links.Copy);
      if (!isAltQuote) {
        hiddenLinks.push(Links.Delete);
      }
    }

    if (isAltQuote) {
      // ALGR-123170 - hiding the Delete button for alternates
      hiddenLinks.push(Links.Delete);

      hiddenLinks.push(Links.Alt);
      hiddenLinks.push(Links.Copy);
      hiddenLinks.push(Links.AltMrkt);
      hiddenLinks.push(Links.Dental);
      hiddenLinks.push(Links.Vision);
    } else {
      // Alt and Alt Market Configuration for Orignals

      if (!this.checkStateAltMrktElgibility(quote)) {
        hiddenLinks.push(Links.AltMrkt);
      } else {
        // Hiding Alt links if Alt Market Icon is visible for Medical Lob,
        // Vision,Dental Lob doesn't support Alt button from schema
        hiddenLinks.push(Links.Alt);
      }

      if (
        !this.eligibleAlternates.some(
          (alternate) =>
            (alternate.fndngType === FundingTypes.ABF ||
              alternate.fndngType === FundingTypes.FI ||
              alternate.fndngType === FundingTypes.ACA ||
              alternate.fndngType === FundingTypes.MEWA) &&
            alternate.attrbNm === 'Alternate'
        )
      ) {
        // Hiding Alt links if Alt Market Icon is visible for Medical Lob,
        // Vision, Dental Lob doesn't support Alt button from schema
        hiddenLinks.push(Links.Alt);
      }
    }
// Specialty MEWA (Dental/Vision) Configuration
    // Show Specialty MEWA menu only for NB Medical MEWA quotes
    const shouldShowSpecialtyMewa =
      lob?.toLowerCase() === Lob.Medical.toLowerCase() &&
      quotingType === FundingTypes.MEWA &&
      oppType === OpportunityType.NewBusinessLocal &&
      !isAltQuote;
 
    if (!shouldShowSpecialtyMewa) {
      hiddenLinks.push(Links.SpecialtyMewa);
    } else {
      // Add Specialty MEWA menu to available links if not already there
      if (!availableLinks.includes(Links.SpecialtyMewa)) {
        availableLinks.push(Links.SpecialtyMewa);
      }
    }
 
    // Hide Alt/Alt Mrkt for Specialty MEWA quotes (Dental/Vision MEWA)
    if ((lob?.toLowerCase() === Lob.Dental.toLowerCase() || lob?.toLowerCase() === Lob.Vision.toLowerCase()) && quotingType === FundingTypes.MEWA) {
      hiddenLinks.push(Links.Alt);
      hiddenLinks.push(Links.AltMrkt);
    }
    const filteredLinks = availableLinks?.filter((link) => !hiddenLinks.includes(link)) ?? [];

    return filteredLinks;
  }

  async getAltMarketFundingTypeDetails(quote) {
    let [marketSegment, opportunityType, fundingType, state, lob, contEffDate] = [
      this.getValueOfPropertyFromDataObject('marketSegment', quote),
      this.getValueOfPropertyFromDataObject('opportunityType', quote),
      this.getValueOfPropertyFromDataObject('fundingType', quote),
      this.getValueOfPropertyFromDataObject('state', quote),
      this.getLobFromQuote(quote),
      this.getValueOfPropertyFromDataObject('contractEffectiveDate', quote)
    ];

    const isAlt = this.getValueOfPropertyFromDataObject('alternateQuote', quote, lob) === 'Yes';
    const eligibleAltExist = this.eligibleAlternates.find(
      (alt) => alt.fndngType === fundingType && typeof alt.attrValue === 'string' && alt.attrValue.includes(marketSegment)
    );
    if (!isAlt && marketSegment && fundingType && state && opportunityType && lob && !eligibleAltExist) {
      await firstValueFrom(this.fetchFundingTypeForAltMrkt(marketSegment, lob, opportunityType, fundingType, state, contEffDate))
        .then((resp) => {
          const alternateOption = resp.find((option) => option.attrbNm === 'Alternate');
          if (alternateOption) {
            alternateOption.fndngType = fundingType;
            this.eligibleAlternates.push(alternateOption);
          }
        });
    }

    return new Promise((res) => res('alt market fetched'));
  }

  getMEWAQuoteDetails(quote, lob?): Observable<[string, boolean, string, any[]]> {
    lob = lob ? lob : this.getLobFromQuote(quote, true);
    const [state, contractEffectiveDate, marketSegment, factorEffectiveDate] = [
      this.getValueOfPropertyFromDataObject('state', quote, lob),
      this.getValueOfPropertyFromDataObject('contractEffectiveDate', quote, lob),
      this.getValueOfPropertyFromDataObject('marketSegment', quote, lob),
      this.getValueOfPropertyFromDataObject('factorEffectiveDate', quote, lob)
    ];

    let ftOptions: string[] = [
      ...this.getFundingTypeOptionsFromSchema('originalQuote', `marketSegment${marketSegment}`, lob),
      ...this.getFundingTypeOptionsFromSchema('alternateQuote', `marketSegment${marketSegment}`, lob)
    ];

    if (!ftOptions.includes(FundingTypes.MEWA)) {
      return of([quote.data.quoteHeaderID, false, null, []]);
    }

    const cacheCode = `${state}##${marketSegment}##${contractEffectiveDate}##${factorEffectiveDate}`;
    return this.cacheService
      .getCommissionInfo(
        cacheCode + '##' + FundingTypes.MEWA,
        state,
        marketSegment,
        FundingTypes.MEWA,
        contractEffectiveDate,
        factorEffectiveDate,
        this.viewSettings.opportunityType,
        this.getValueOfPropertyFromDataObject('alternateQuote', this.currentDataObj, this.getLobFromQuote(this.currentDataObj, true))
      )
      .pipe(
        map((res: any) => {
          return [quote.data.quoteHeaderID, res['mewaEligible'] || false, res['contractEndDate'] || null, res['associationDetails'] || []];
        })
      );
  }

  async checkAndEnableMewaFTOption(contEffDate) {
    let quote = structuredClone(this.currentDataObj);
    const mktSegment = this.formGroup.get('marketSegment').value;
    this.setValueOfPropertyOfDataObject('contractEffectiveDate', moment(new Date(contEffDate)).format('YYYY-MM-DD'), quote);
    this.setValueOfPropertyOfDataObject('state', this.formGroup.get('state').value, quote);
    this.setValueOfPropertyOfDataObject('marketSegment', mktSegment, quote);
    this.setValueOfPropertyOfDataObject('factorEffectiveDate', moment(new Date(this.formGroup.get('factorEffectiveDate').value)).format('YYYY-MM-DD'), quote);

    await this.getMEWAQuoteDetails(quote)
      .toPromise()
      .then((resp) => {
        this.quoteMEWADetails.set(resp?.[0] ?? '', { mewaEligible: resp[1], contractEndDate: resp[2], associationDetails: resp[3] });
      });

    this.setFundingTypeDropdownOptions(mktSegment);
    return new Promise((resolve) => {
      resolve('mewa check done');
    });
  }

  async processCrossSelling() {
    this.inCrossSellingMode = true;

    if (this.getFundingTypeFromObj(this.currentDataObj) === FundingTypes.FI && this.formGroup.get('fundingType').value === FundingTypes.ABF) {
      const fiCommissionField = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fiCommission');
      const fiCommissionFTypeield = this.getSectionOrFieldFromSchema(Sections.FundingInfo, 'fiCommissionType');

      const fiCommissionValue = this.getValueFromPath(fiCommissionField.path, this.currentDataObj);
      const fiCommissionTypeValue = this.getValueFromPath(fiCommissionFTypeield.path, this.currentDataObj);
      this.formGroup.get('abfCommission')?.setValue(fiCommissionValue);
      this.formGroup.get('abfCommissionType')?.setValue(fiCommissionTypeValue);
    }
    const details: ContractCodeReplacementDetails = {
      state: this.formGroup.get('state').value,
      contractEffectiveDate: moment(this.formGroup.get('contractEffectiveDate').value).format('YYYY-MM-DD'),
      factorEffectiveDate: moment(this.formGroup.get('factorEffectiveDate').value).format('YYYY-MM-DD'),
      marketSegment: this.formGroup.get('marketSegment').value,
      newFundingType: this.formGroup.get('fundingType').value,
      proposedPlansDetails: this.getValueOfPropertyFromDataObject('proposedPlans', this.currentDataObj),
      censusDetails: this.getValueOfPropertyFromDataObject('census', this.currentDataObj),
      contractCodes: this.getValueOfPropertyFromDataObject('proposedPlans', this.currentDataObj).map((plan) => plan.contractCode),
      oppType: this.getValueOfPropertyFromDataObject('opportunityType', this.currentDataObj),
      zipCode: this.getValueOfPropertyFromDataObject('companyZipCode', this.currentDataObj),
      county: this.getValueOfPropertyFromDataObject('county', this.currentDataObj),
      association: this.getValueOfPropertyFromDataObject('association', this.currentDataObj)
    };
    await this.fetchAndReplaceContractCodes(details, true);

    if (this.formGroup.get('marketSegment').value === MarketSegments.SmallGroup) {
      // Fetch mewa eligibility to check if mewa alternates are allowed or not for new SG quotes
      const mewaFetchObj = structuredClone(this.currentDataObj);
      this.setValueOfPropertyOfDataObject('state', this.formGroup.get('state').value, mewaFetchObj);
      this.setValueOfPropertyOfDataObject(
        'contractEffectiveDate',
        moment(this.formGroup.get('contractEffectiveDate').value).format('YYYY-MM-DD'),
        mewaFetchObj
      );
      this.setValueOfPropertyOfDataObject('marketSegment', this.formGroup.get('marketSegment').value, mewaFetchObj);
      this.setValueOfPropertyOfDataObject('factorEffectiveDate', moment(this.formGroup.get('factorEffectiveDate').value).format('YYYY-MM-DD'), mewaFetchObj);

      await this.getMEWAQuoteDetails(mewaFetchObj)
        .toPromise()
        .then((resp) => {
          this.quoteMEWADetails.set(resp[0], { mewaEligible: resp[1], contractEndDate: resp[2], associationDetails: resp[3] });
        });
    }
    this.isCrossSellingInProcess = false;
    return new Promise((resolve) => {
      resolve('Cross-selling done');
    });
  }

  async fetchAndReplaceContractCodes(details: ContractCodeReplacementDetails, replaceInForm: boolean = false, isAltMarket: boolean = false, lob?) {
    lob = lob ? lob : this.getLobFromQuote(this.currentDataObj);    
    const { state, contractEffectiveDate, factorEffectiveDate, marketSegment, newFundingType, contractCodes, oppType, zipCode, county, association } = details;    
    let { proposedPlansDetails, censusDetails } = details;

    const planBenefitsCacheCode = `${state}##${marketSegment}##${contractEffectiveDate}##${factorEffectiveDate}`;

    let mbs = marketSegment === MarketSegments.SmallGroup ? marketSegment : 'Key';

    const planBenefits$ = this.getPlanBenefits(planBenefitsCacheCode, state, contractEffectiveDate, factorEffectiveDate, marketSegment, mbs, lob);    

    const replacementContactCodes$ = this.fetchReplacementContactCodes(
      contractCodes,
      state,
      contractEffectiveDate,
      marketSegment,
      newFundingType,
      lob,
      oppType,
      isAltMarket,
      zipCode,
      county,
      contractEffectiveDate,
      association,
      this.currentDataObj.data.opportunityID,
      this.currentDataObj.data.quoteHeaderID
    );

    try {
      // Wait for both API calls to complete
      const [planBenefitsData, replacementContractCodesData] = await forkJoin([planBenefits$, replacementContactCodes$]).toPromise();
      const quoteLineItemMapping = {};
      const contractCodesMap = new Map<string, number[]>();

      if (replacementContractCodesData[newFundingType] && replacementContractCodesData[newFundingType].length > 0) {
        proposedPlansDetails.forEach((plan, index) => {
          if (index < replacementContractCodesData[newFundingType].length) {
            const replacementContactCode = replacementContractCodesData[newFundingType][index];
            const planBenefitDetails = planBenefitsData.find((data) => data.cntrctCd === replacementContactCode);
            // Extract old quoteLineItemID
            const oldQuoteLineItemID = plan.quoteLineItemID;
            const newQuoteLineItemID = this.commonService.generateID('QL');
            if (planBenefitDetails) {
              contractCodesMap.set(replacementContactCode, [...(contractCodesMap.get(replacementContactCode) || []), index]);
              plan.contractCode = planBenefitDetails.cntrctCd;
              plan.networkName = planBenefitDetails.ntwrkName;
              plan.networkType = planBenefitDetails.prodCtgryCd;
              plan.quoteLineItemID = newQuoteLineItemID;

              if (replaceInForm) {
                const formGroupPlanTable = (this.formGroup.get('planTable') as FormArray).at(index) as FormGroup;
                formGroupPlanTable.get('contractCode').setValue(planBenefitDetails.cntrctCd);
                formGroupPlanTable.get('networkName').setValue(planBenefitDetails.ntwrkName);
                formGroupPlanTable.get('networkType').setValue(planBenefitDetails.prodCtgryCd);
                formGroupPlanTable.get('quoteLineItemID').setValue(newQuoteLineItemID);

                if (planBenefitDetails.fndngType.includes('ALL') || planBenefitDetails.fndngType.includes(newFundingType)) {
                  formGroupPlanTable.get('fundingType').setValue(newFundingType);
                }
              }

              if (!quoteLineItemMapping[newFundingType]) {
                quoteLineItemMapping[newFundingType] = {};
              }
              quoteLineItemMapping[newFundingType][oldQuoteLineItemID] = newQuoteLineItemID;
            } else {
              if (replacementContactCode && lob === Lob.Dental) {
                if (marketSegment === MarketSegments.LargeGroup) {
                  const planBenefitDetail = planBenefitsData.find((data) => data.planName === replacementContactCode);
                  if (planBenefitDetail) {
                    contractCodesMap.set(replacementContactCode, [...(contractCodesMap.get(replacementContactCode) || []), index]);
                  }
                  plan.planName = replacementContactCode;
                } else {
                  plan.contractCode = replacementContactCode;
                }

                plan.quoteLineItemID = newQuoteLineItemID;

                if (!quoteLineItemMapping[newFundingType]) {
                  quoteLineItemMapping[newFundingType] = {};
                }
                quoteLineItemMapping[newFundingType][oldQuoteLineItemID] = newQuoteLineItemID;
              } else {
                proposedPlansDetails = [];
              }
            }
            index++;
          }
        });
      }

      const removalIndexes: number[] = [];
      const quoteLineItemIdMap = new Map<string, string>();
      contractCodesMap.forEach((planIndexes) => {
        if (planIndexes.length > 1) {
          const baseIndex = planIndexes[0];
          planIndexes.forEach((planIdx, idx) => {
            if (idx > 0) {
              removalIndexes.push(planIdx);
              const baseObj = proposedPlansDetails[baseIndex];
              quoteLineItemIdMap.set(proposedPlansDetails[planIdx].quoteLineItemID, baseObj.quoteLineItemID);

              baseObj.currPlanId = [...(baseObj.currPlanId || []), ...(proposedPlansDetails[planIdx].currPlanId || [])];
              if (replaceInForm) {
                const plabTableFormArray = this.formGroup.get('planTable') as FormArray;
                const formGroupPlanTableBase = plabTableFormArray.at(baseIndex) as FormGroup;
                const formGroupPlanTableToBeRemoved = plabTableFormArray.at(planIdx) as FormGroup;
                const updatedCurrPlanIds = formGroupPlanTableBase.get('currPlanId').value || [];
                formGroupPlanTableBase
                  .get('currPlanId')
                  .setValue([...updatedCurrPlanIds, ...(formGroupPlanTableToBeRemoved.get('currPlanId').value || [])], { emitEvent: false });
              }
            }
          });
        }
      });

      removalIndexes.sort((a, b) => b - a).forEach((removalIdx) => {
        proposedPlansDetails.splice(removalIdx, 1);
        if (replaceInForm) {
          (this.formGroup.get('planTable') as FormArray).removeAt(removalIdx);
        }
      });

      if (replaceInForm) {
        this.populateContractCodeOptions();
      }

      censusDetails.forEach((censusItem, index) => {
        if (censusItem.proposedPlanId && Array.isArray(censusItem.proposedPlanId)) {
          censusItem.proposedPlanId = censusItem.proposedPlanId.map((oldQuoteLineItemID) => {
            return quoteLineItemMapping[newFundingType]?.[oldQuoteLineItemID] || oldQuoteLineItemID;
          });

          quoteLineItemIdMap.forEach((baseId, duplicateId) => {
            if (censusItem.proposedPlanId.includes(duplicateId)) {
              censusItem.proposedPlanId = censusItem.proposedPlanId.filter((qli) => qli !== duplicateId);
              if (!censusItem.proposedPlanId.includes(baseId)) {
                censusItem.proposedPlanId.push(baseId);
              }
            }
          });

          if (replaceInForm) {
            const formGroupPlanTable = (this.formGroup.get('censusTable') as FormArray).at(index) as FormGroup;
            formGroupPlanTable.get('proposedPlanId').setValue(censusItem.proposedPlanId, { emitEvent: false });
          }
        }
      });
    } catch (error) {
      // Handle errors from either API call
      console.error('Error occurred:', error);
    }

    return new Promise((resolve) => {
      resolve('Contract code replaced');
    });
  }

  adjustmentTypeValueModifier(...args) {
    const { value, field, type } = args[0];

    if (['get', 'set'].includes(type)) {
      return value === 'None' ? value.toLowerCase() : value;
    }
  }

  hasObjectChanged(a: any, b: any): boolean {
    if (!a || (Array.isArray(a) && a.length === 0)) {
      return false;
    }

    if (!b || (Array.isArray(b) && a.length === 0)) {
      return false;
    }

    return JSON.stringify(a) !== JSON.stringify(b);
  }

  async getQuoteAndOppId(): Promise<any> {
    const result = await this.commonService.getSafeOppAndQuoteHeaderID().toPromise();
    return result;
  }

  setQuoteOriginAsOppScreen(quote) {
    quote.data.quoteOrigin = QuoteOrigin.OppScreen;
    quote.data.unifiedPayload.data.quoteOrigin = QuoteOrigin.OppScreen;
  }

  getPathOfProperty(prop: string, lob: string = null): string | null {
    let path = null;
    for (let section in Sections) {
      const field = this.getSectionOrFieldFromSchema(Sections[section], prop, null, false, lob);
      if (field) {
        path = field.path;
        break;
      }
    }

    if (path === null) {
      let schema = this.schema;
      if (lob) {
        schema = this.schemaDetails[this.toLobCase(lob)];
      }
      path = schema.dataPaths[prop];
    }
    return path ? path : null;
  }

  getValueOfPropertyFromDataObject(prop: string, data: any, lob: string = null): any {
    lob = lob ? this.toLobCase(lob) : this.getLobFromQuote(this.currentDataObj, true);
    const path = this.getPathOfProperty(prop, lob);
    return !path ? null : this.getValueFromPath(path, data);
  }

  setValueOfPropertyOfDataObject(prop: string, value: any, data: any, lob: string = null) {
    const path = this.getPathOfProperty(prop, lob);
    if (path) {
      this.setValueAtPath(path, value, data);
    }
  }

  getLobFromQuote(quote: any, changeCase: boolean = false) {
    if (changeCase) {
      return this.toLobCase(quote.data.lob);
    }
    return quote.data.lob;
  }

  async getFundingTypeOptions(quote) {
    let [state, lob, marketSegment, opportunityType, fundingType, contEffData] = [
      this.getValueOfPropertyFromDataObject('state', quote),
      this.getLobFromQuote(quote),
      this.getValueOfPropertyFromDataObject('marketSegment', quote),
      this.getValueOfPropertyFromDataObject('opportunityType', quote),
      this.getValueOfPropertyFromDataObject('fundingType', quote),
      this.getValueOfPropertyFromDataObject('contractEffectiveDate', quote)
    ];
    marketSegment = marketSegment === MarketSegments.LargeGroup ? MarketSegments.SmallGroup : MarketSegments.LargeGroup;

    const altMrktOptions$ = this.fetchFundingTypeForAltMrkt(marketSegment, lob, opportunityType, fundingType, state, contEffData);
    let result: Record<string, string[]> = {};
    if (this.toLobCase(lob) === this.toLobCase(Lob.Vision)) {
      result['Alternate Market'] = ['FI'];
      return result;
    }

    if (this.toLobCase(lob) === this.toLobCase(Lob.SuppHealth)) {
      result['Alternate Market'] = [];
      return result;
    }

    try {
      // Use forkJoin to handle the observable
      const altMrktOptionsData = await forkJoin([altMrktOptions$]).toPromise();

      // Transform the data into attrbNm-wise values using a loop
      if (altMrktOptionsData) {
        for (const item of altMrktOptionsData[0]) {
          const attrbNm = item.attrbNm;
          const setAttrValue = item.setAttrValue;
          const parsedValues = setAttrValue.split('|').filter((value) => value);
          result[attrbNm] = parsedValues;
        }
        return result;
      }
    } catch (error) {
      console.error('Error fetching funding type options:', error);
      throw error;
    }
  }

  fetchFundingTypeForAltMrkt(marketSegment: any, lob: any, opportunityType: any, fundingType: any, state: any, contEffectiveDate: any): Observable<any> {
    return this.createOpportunityService.fetchFundingTypeForAltMrkt(marketSegment, lob, opportunityType, fundingType, state, contEffectiveDate);
  }

  getCountyCodes(zipCode) {
    return this.cacheService.getCountyCodeDetails(zipCode);
  }

  getPlanBenefits(cacheCode, state, contEffectiveDate, factorEffectiveDate, marketSegment, mbs, lob?): Observable<any> {
    lob = lob ? this.toLobCase(lob) : this.getLobFromQuote(this.currentDataObj, true);

    let obs;

    switch (lob) {
      case this.toLobCase(Lob.SuppHealth): {
        obs = of([]);
        break;
      }

      case this.toLobCase(Lob.Vision): {
        if (marketSegment === MarketSegments.SmallGroup) {
          obs = of([]);
        } else {
          obs = this.cacheService.getVisionPlanBenefits(cacheCode, state, contEffectiveDate, factorEffectiveDate, marketSegment);
        }

        break;
      }

      case this.toLobCase(Lob.Dental): {
        const proposedPlans = this.getValueOfPropertyFromDataObject('proposedPlans', this.currentDataObj, lob) ?? [];
        const mockBenefitsData = proposedPlans.map((plan) => {
          return {
            planName: plan.planName,
            ntwrkName: plan.networkName,
            cntrctCd: plan.contractCode
          };
        });
        /* Dental plan benefits api is not called, mocking the plan benefits array from existing proposed plan
         *  to work on create opp screen framework
         */
        obs = of(mockBenefitsData);

        break;
      }

      case this.toLobCase(Lob.Medical): {
        obs = this.cacheService.getPlanBenefits(cacheCode + `##${mbs}`, state, contEffectiveDate, factorEffectiveDate, marketSegment, mbs);
        break;
      }
    }

    return obs;
  }

  formControlAddFieldHelper(field, value) {
    this.formGroup.addControl(field.name, new FormControl(value, this.getValidators(field.validators)));

    this.quoteFieldsToUpdate[field.name] = {
      path: field.path,
      name: field.name,
      label: field.label,
      type: field.type,
      columns: field.columns ?? null
    };
  }

  formControlRemoveFieldHelper(field) {
    this.formGroup.removeControl(field.name);
    delete this.quoteFieldsToUpdate[field.name];
  }

  toLobCase(lobString: string): string {
    if (!lobString) return '';
    const words = lobString.trim().split(/\s+/);
    return words
      .map((word, idx) => (idx === 0 ? word.charAt(0).toLowerCase() + word.slice(1) : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()))
      .join('');
  }
  
  censusVisTierChanged(...args) {
    if(this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      this.asyncMethodCall$.set({
        name: 'visCalcTotGroupSize',
        params: [
          {
            data: (this.formGroup.get('censusTable') as FormArray).getRawValue()
          }
        ]
      });
    }
  }

  censusVisRelTypeChanged(...args) {
    if(this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      this.asyncMethodCall$.set({
        name: 'visCalcTotGroupSize',
        params: [
          {
            data: (this.formGroup.get('censusTable') as FormArray).getRawValue()
          }
        ]
      });
    }
  }

  censusVisEligibilityChanged(...args) {
    if(this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      this.asyncMethodCall$.set({
        name: 'visCalcTotGroupSize',
        params: [
          {
            data: (this.formGroup.get('censusTable') as FormArray).getRawValue()
          }
        ]
      });
    }
  }

  censusVisContractCodeChanged(...args) {
    if(this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      this.asyncMethodCall$.set({
        name: 'visCalcTotGroupSize',
        params: [
          {
            data: (this.formGroup.get('censusTable') as FormArray).getRawValue()
          }
        ]
      });
    }
  }

  intializeVisSummaryCensus(...args) {
    const { field } = args[0];
    const value = +(this.formGroup.get(field.name).value ?? 0);
    if(!value && this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      this.asyncMethodCall$.set({
        name: 'visCalcTotGroupSize',
        params: [
          {
            data: (this.formGroup.get('censusTable') as FormArray).getRawValue()
          }
        ]
      });
    }
    
  }

  initializeDentalSummaryCensus(...args) {
    const { field } = args[0];
    const value = +(this.formGroup.get(field.name).value ?? 0);
    if(!value && this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      this.asyncMethodCall$.set({
        name: 'dentalCalcTotGroupSize',
        params: [
          {
            data: (this.formGroup.get('censusTable') as FormArray).getRawValue()
          }
        ]
      });
    }
  }

  initializeSuppHealthSummaryCensus(...args) {
    const { field } = args[0];
    const value = +(this.formGroup.get(field.name).value ?? 0);
    if(!value && this.formGroup.get('marketSegment').value === MarketSegments.LargeGroup) {
      this.asyncMethodCall$.set({
        name: 'suppHealthCalcTotGroupSize',
        params: [
          {
            data: (this.formGroup.get('censusTable') as FormArray).getRawValue()
          }
        ]
      });
    }
  }

  visCalcTotGroupSize(...args) {
  
    const { data } = args[0];
    const selectedTier = this.formGroup.get('inputTier').value;
    const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);
    const tierCalcDetails: TierCalcDetails = TierRatesCalcMap.get(selectedTier);
    const { targetTier , sourceTiers } = tierCalcDetails;
    const availableTiers = tierDetails.map((t) => t.pathString.toLowerCase());

    setTimeout(()=> {
      let scValue = {};
      const subscriberData = data.filter(x=> x.relationType === 'S').filter(y=> y.proposedPlanId && y.proposedPlanId.length > 0);
      const eligibleData = subscriberData.filter(x=> ['K','E'].includes(x.eligibility));
      const waiverData = subscriberData.filter(x=> x.eligibility === 'W') ?? [];
      
      if(this.formGroup) {
        this.formGroup.get('waivers')?.setValue(waiverData.length + '');
      } else {
        this.setValueOfPropertyOfDataObject('waivers', waiverData.length, this.currentDataObj);
      }

      availableTiers.forEach((tier) => {
        let tierValue;
        if(tier.toLowerCase() === targetTier?.toLowerCase()) {
          tierValue = eligibleData.filter(x=> sourceTiers.map(t => t?.toLowerCase()).includes(x.tier.toLowerCase())).length;
        } else {
          tierValue = eligibleData.filter(x=> x.tier.toLowerCase() === tier).length;
        }
        scValue[tier] = tierValue;

        if(this.formGroup) {
          this.formGroup.get(tier)?.setValue(scValue[tier] + '');
        } else {
          this.setValueOfPropertyOfDataObject(tier, scValue[tier], this.currentDataObj);
        }
      });
    }, 10);
  }

  dentalCalcTotGroupSize(...args) {
    const { data } = args[0];
    const selectedTier = this.formGroup.get('inputTier').value;
    const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);
    const tierCalcDetails: TierCalcDetails = TierRatesCalcMap.get(selectedTier);
    const { targetTier , sourceTiers } = tierCalcDetails;
    const availableTiers = tierDetails.map((t) => t.pathString.toLowerCase());

    setTimeout(()=> {
      let scValue = {};
      const subscriberData = data.filter(x=> x.relationType === 'S').filter(y=> y.proposedPlanId && y.proposedPlanId.length > 0);
      const eligibleData = subscriberData.filter(x=> ['K','E'].includes(x.eligibility));
      const waiverData = subscriberData.filter(x=> x.eligibility === 'W') ?? [];
      
      if(this.formGroup) {
        this.formGroup.get('waivers')?.setValue(waiverData.length + '');
      } else {
        this.setValueOfPropertyOfDataObject('waivers', waiverData.length, this.currentDataObj);
      }

      availableTiers.forEach((tier) => {
        let tierValue;
        if(tier.toLowerCase() === targetTier?.toLowerCase()) {
          tierValue = eligibleData.filter(x=> sourceTiers.map(t => t?.toLowerCase()).includes(x.tier.toLowerCase())).length;
        } else {
          tierValue = eligibleData.filter(x=> x.tier.toLowerCase() === tier).length;
        }
        scValue[tier] = tierValue;

        if(this.formGroup) {
          this.formGroup.get(tier)?.setValue(scValue[tier] + '');
        } else {
          this.setValueOfPropertyOfDataObject(tier, scValue[tier], this.currentDataObj);
        }
      });
    }, 10);
  }

  suppHealthCalcTotGroupSize(...args) {
    const { data } = args[0];
    const selectedTier = this.formGroup.get('inputTier').value;
    const tierDetails: TierDetails[] = TierRatesMap.get(selectedTier);
    const tierCalcDetails: TierCalcDetails = TierRatesCalcMap.get(selectedTier);
    const { targetTier , sourceTiers } = tierCalcDetails;
    const availableTiers = tierDetails.map((t) => t.pathString.toLowerCase());

    setTimeout(()=> {
      let scValue = {};
      const subscriberData = data.filter(x=> x.relationType === 'S').filter(y=> y.proposedPlanId && y.proposedPlanId.length > 0);
      const eligibleData = subscriberData.filter(x=> ['K','E'].includes(x.eligibility));
      const waiverData = subscriberData.filter(x=> x.eligibility === 'W') ?? [];
      
      if(this.formGroup) {
        this.formGroup.get('waivers')?.setValue(waiverData.length + '');
      } else {
        this.setValueOfPropertyOfDataObject('waivers', waiverData.length, this.currentDataObj);
      }

      availableTiers.forEach((tier) => {
        let tierValue;
        if(tier.toLowerCase() === targetTier?.toLowerCase()) {
          tierValue = eligibleData.filter(x=> sourceTiers.map(t => t?.toLowerCase()).includes(x.tier.toLowerCase())).length;
        } else {
          tierValue = eligibleData.filter(x=> x.tier.toLowerCase() === tier).length;
        }
        scValue[tier] = tierValue;

        if(this.formGroup) {
          this.formGroup.get(tier)?.setValue(scValue[tier] + '');
        } else {
          this.setValueOfPropertyOfDataObject(tier, scValue[tier], this.currentDataObj);
        }
      });
    }, 10);
  }

  shpSyncContractCodeAcrossPlanTables(previousValue: string, value: string, targetTableName: string, fieldName: string = 'contractCode') {
    // Synchronize contract code changes across related tables
    if ((previousValue === '' || previousValue) && previousValue !== value) {
      const targetTable = this.formGroup.get(targetTableName) as FormArray;
      if (targetTable) {
        for (const row of targetTable.controls as FormGroup[]) {
          const currentFieldValue = row.get(fieldName)?.value;
          
          // If row references the old contract code, update it to new one
          if (currentFieldValue === previousValue) {
            this.blockValueChangeDetection = true;
            row.get(fieldName)?.setValue(value);
            setTimeout(() => {
              this.blockValueChangeDetection = false;
            }, 100);
            break; // Stop checking further once match is found
          }
        }
      }
    }
  }

  shpPlanContractCodeChanged(...args) {
    const { previousValue, value, _rowId } = args[0];
    
    // Update references in currentCarrierTable when planTable contract code changes
    this.shpSyncContractCodeAcrossPlanTables(previousValue, value, 'currentCarrierTable');
  }

  shpCurrentPlanContractCodeChanged(...args) {
    const { previousValue, value, _rowId } = args[0];
    
    // Update references in planTable when currentCarrierTable contract code changes
    this.shpSyncContractCodeAcrossPlanTables(previousValue, value, 'planTable');
  }

  groupExperienceChanged(data) {
    if(data) {
      const changesDetails = this.groupExpObjectChanges.find(data => data.identifier === 
        `${this.currentDataObj.data.quoteHeaderID}-${this.currentDataObj.data.fundingType}-${this.getLobFromQuote(this.currentDataObj)}`.toLowerCase())
      changesDetails.changed = true;
    }
    this.setValueOfPropertyOfDataObject('groupExperience', data, this.currentDataObj);
  }

  claimsBasisChanged(value) {
    const changesDetails = this.claimsBasisChanges.find(data => data.identifier ===
      `${this.currentDataObj.data.quoteHeaderID}-${this.currentDataObj.data.fundingType}-${this.getLobFromQuote(this.currentDataObj)}`.toLowerCase())
    
    changesDetails.changed = true;
    changesDetails.currentValue = value ? 'Paid' : 'Incurred';
    this.setValueOfPropertyOfDataObject('claimBasis', value ? 'Paid' : 'Incurred', this.currentDataObj)
  }

  updateOppOrigin(data) {
    const currentValue = this.getValueOfPropertyFromDataObject('oppOrigin', data, this.getLobFromQuote(data, true));
    
    if(currentValue.originalRatingMethod) {
      delete currentValue.originalRatingMethod      
    }
  }
}


