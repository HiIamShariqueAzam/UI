import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { Menu } from 'primeng/menu';
import { CreateOppViewSettings, OpportunityType, QuoteOrigin, Views } from '../../constants/create-opportunity.constants';

@Component({
  selector: 'app-dynamic-section',
  templateUrl: './dynamic-section.component.html',
  styleUrls: ['./dynamic-section.component.scss'],
  standalone: false,
})
export class DynamicSectionComponent implements OnChanges, OnInit {
  @ViewChild('menu') menu!: Menu;
  @Input({ required: true }) section: any;
  @Input() formGroup: FormGroup;
  @Input({ required: true }) viewSettings: CreateOppViewSettings;
  @Input({ required: true }) isReadOnlyUser: boolean;
  @Output() buttonClicked = new EventEmitter<{ handlerName: string; event: any }>();
  @Input() isMemberCountExpanded: boolean;
  @Input() isSubscriberCountExpanded: boolean;
  @Input() showOnlyProjectedContent: boolean;
  @Input() selectedLOB: string;
  @Input() showCreateDropdownForSG: boolean;
  view: Views;
  fieldsPerRow: number = 5;
  public viewList = Views;
  items: MenuItem[] | undefined;

  isAccordionCollapseed: boolean = false;
  userRole: any;
  showCreateDropdown: boolean = false;
  lobOptions = [
    { label: 'Medical', value: 'Medical' }
  ];

  ngOnInit(): void {
    // Add specialty LOBs only if showCreateDropdownForSG is true
    if (this.showCreateDropdownForSG) {
      this.lobOptions = [
        { label: 'Medical', value: 'Medical' },
        { label: 'Vision', value: 'Vision' },
        { label: 'Dental', value: 'Dental' },
        { label: 'Supp Health', value: 'Supp Health' }
      ];
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.view = this.viewSettings.view;
    if (this.isReadOnlyUser) {
      this.view = Views.ReadonlyView;
    }

    this.setFieldsPerRow();

    this.section.buttons?.forEach((button) => {
      this.setButtonVisibility(button);
    });

    this.section.footerButtons?.forEach((button) => {
      this.setButtonVisibility(button);
    });

    if(changes['section']) {
      this.hideColumnsOfReadonlyView();
    }

  }

  toggleMenu(event: Event, options, quoteData): void {
    if (this.menu) {
      this.menu.toggle(event);
    }
    this.items = structuredClone(options);
    this.items[0]?.items?.forEach((ele) => {
      ele['command'] = () => this.onButtonClick(`${ele.handler}`, quoteData);
    });
  }
  
  setFieldsPerRow() {
    const fieldsPerRowFromSchema = this.section.fieldsPerRow ? this.section.fieldsPerRow : '5';
    this.fieldsPerRow = fieldsPerRowFromSchema === 'all' ? this.section.fields.length : +fieldsPerRowFromSchema;
  }

  setButtonVisibility(button) {
    switch (button.handler) {
      case 'cancelQuote': {
        if ([Views.Create, Views.ReadonlyView].includes(this.view)) {
          button.showOnView = true;
        } else {
          button.showOnView = false;
        }
        break;
      }

      case 'saveQuote': {
        if ([Views.Edit, Views.Create, Views.AltInit].includes(this.view)) {
          button.showOnView = true;
        } else {
          button.showOnView = false;
        }
        break;
      }

      case 'submitQuote': {
        if ([Views.Edit, Views.Create, Views.AltInit].includes(this.view)) {
          button.showOnView = true;
        } else {
          button.showOnView = false;
        }
        break;
      }

      case 'createQuote': {
        if (this.viewSettings.screenOppType === OpportunityType.RenewalLocal || this.isReadOnlyUser || this.viewSettings.isOnlyAlts) {
          button.showOnView = false;
        } else {
          button.showOnView = true;
        }

        if (this.view === Views.Create) {
          button.disabled = true;
        } else {
          button.disabled = false;
        }
        break;
      }

      case 'requestHistoryQuote': {
        if (![Views.Create, Views.AltInit].includes(this.view)) {
          button.showOnView = true;
        } else {
          button.showOnView = false;
        }
        break;
      }
    }
  }

  hideColumnsOfReadonlyView() {
    //Hiding table checkbox columns and quote section action columns
    if ([Views.ReadonlyView, Views.QuoteHistoryView].includes(this.view)) {
      const tableFields = this.section.fields.filter((f) => f.type === 'table' || f.type === 'q-table');

      tableFields.forEach((table) => {
        const checkboxColumn = table.columns.find((col) => col.name === 'checkbox' && col.header === '');
        if (checkboxColumn && checkboxColumn?.show !== 'false') {
          checkboxColumn['show'] = 'false';

          if (table.parentHeader) {
            const colspan = table.parentHeaders.find((col) => col.header === '')?.colspan;
            table.parentHeaders.find((col) => col.header === '').colspan = colspan - 1;
          }

          if (table.togglerColumns?.length) {
            table.togglerColumns.forEach(tcol => {
              tcol.colspan = tcol.colspan - 1;
            })
          }
        }
      });

      if (this.view === Views.QuoteHistoryView) {
        if (this.section.title === 'Quotes') {
          const actionLinksColumn = tableFields[0].columns.find((col) => col.name === 'links');

          actionLinksColumn['show'] = 'false';
        }
      }
    }
  }

  getFormControl(fieldName: string, arrayIndex: number, arrayName: string) {
    if (arrayName) {
      return (this.formGroup.get(arrayName) as FormArray).at(arrayIndex).get(fieldName);
    }

    return this.formGroup.get(fieldName);
  }

  isRequired(field): boolean {
    return field.validators?.some((val) => val.type === 'required');
  }

  getViewText(field) {
    if (typeof this[field.viewTextHandler] === 'function') {
      return this[field.viewTextHandler].apply(this, [
        {
          field: field
        }
      ]);
    }
  }

  claimBasisViewText(...args) {
    const { field } = args[0];
    return this.formGroup.get(field.name).value === true ? field.onLabel : field.offLabel;
  }

  getToggleValues(fieldName: string): string {
    const value = this.formGroup.get(fieldName).value;
    return value === true ? 'Paid' : 'Incurred';
  }

  getErrorMessage(field, control) {
    if (control?.hasError('required')) {
      return 'This field is required';
    }

    if (control?.hasError('minlength')) {
      const minLength = field.validators.find((val) => val.type === 'minLength').value;
      return `Minimum length is ${minLength}`;
    }

    if (control?.hasError('maxlength')) {
      const maxLength = field.validators.find((val) => val.type === 'maxLength').value;
      return `Maximum length is ${maxLength}`;
    }

    if (control?.hasError('max')) {
      const max = field.validators.find((val) => val.type === 'max').value;
      return `Maximum value is ${max}`;
    }

    if (control?.hasError('min')) {
      const min = field.validators.find((val) => val.type === 'min').value;
      return `Minimum value is ${min}`;
    }

    if (control?.hasError('decimalPlaces')) {
      const decimalPlaces = field.validators.find((val) => val.type === 'decimalPlaces').value;
      return `Upto ${decimalPlaces} decimal places allowed`;
    }

    if (control?.hasError('invalidZipCode')) {
      return `ZipCode is invalid`;
    }

    if (control?.hasError('invalidDateFormat')) {
      return `Invalid date format`;
    }

    if (control?.hasError('dropdownOptionValidator')) {
      return `Please Select valid value`;
    }

    return '';
  }

  showHeaderFieldError(controlName, col) {
    const formArray = this.formGroup.get(controlName) as FormArray;

    if (formArray.invalid) {
      for (let group of formArray.controls) {
        const columnControls = group.get(col.name);
        if (columnControls.touched && columnControls.invalid) {
          return true;
        }
      }
    }

    return false;
  }

  onButtonClick(handlerName: string, $event: any = null) {
    this.buttonClicked.emit({ handlerName: handlerName, event: $event });
  }

  getTableControl(group) {
    return (this.formGroup.get(group) as FormGroup).controls;
  }

  getViewModeDropdownValue(options: any[], value: any): string {
    if (Array.isArray(value)) {
      // Handle multi-select values
      const labels = value.map((val) => {
        const selectedOption = options?.find((option) => option.value === val);
        return selectedOption?.label ?? 'N/A';
      });
      return labels?.length ? labels?.join(', ') : 'N/A';
    } else {
      // Handle single value
      const selectedOption = options?.find((option) => option.value === value);
      return selectedOption?.label ?? 'N/A';
    }
  }

  hasValues(controls: FormGroup): boolean {
    return Object.keys(controls.controls).some((key) => controls.get(key).value);
  }

  showFormFields() {
    const isGroupInfo = this.section.title === 'Group Information';

    if (isGroupInfo) {
      if (this.view !== Views.QuoteHistoryView) {
        return this.viewSettings.canEditOpp || this.viewSettings.quoteOrigin === QuoteOrigin.OppScreen;
      }
    }

    return ![Views.ReadonlyView, Views.QuoteHistoryView].includes(this.view);
  }

  checkTableData(field) {
    if (field?.emptyTable) {
      return this.checkEmptyTable(field.name);
    } else {
      return true;
    }
  }

  checkEmptyTable(tableName: string) {
    const tableControl = this.formGroup.get(tableName) as FormGroup;
    if (tableControl && tableControl.value?.length === 0) {
      return false;
    } else {
      return true;
    }
  }

  getColumnCount(field): number {
    return field.columns.filter((col) => col.show !== 'false' && !col.hidden).length;
  }

  getMaxlength(field) {
    const maxLengthValidator = field.validators?.filter((v) => v.type === 'maxLength') ?? [];
    return maxLengthValidator.length ? maxLengthValidator[0].value : 9999999;
  }

  getMax(field) {
    const maxLengthValidator = field.validators?.filter((v) => v.type === 'max') ?? [];
    return maxLengthValidator.length ? maxLengthValidator[0].value : Number.MAX_SAFE_INTEGER;
  }

  getMin(field) {
    const maxLengthValidator = field.validators?.filter((v) => v.type === 'min') ?? [];
    return maxLengthValidator.length ? maxLengthValidator[0].value : Number.MIN_SAFE_INTEGER;
  }

  checkComponentRates(controls) {
    return Object.keys(controls.controls).some((key) => key.includes('CompRates'));
  }

  createUniqueId(fieldName: string, arrayIndex: number, arrayName: string): string {
    if (arrayName) {
      return `${arrayName}_${arrayIndex}_${fieldName}`;
    }

    return `${fieldName}`;
  }

  autoCompleteSuggestionsSearch(event: AutoCompleteCompleteEvent, ctx, options) {
    ctx.field.options = event.query ? [...options.filter(opt => opt.label.toLowerCase().indexOf(event.query.toLowerCase()) == 0)] : [...options];
  }

  autoCompleteSuggestionsClear(ctx, options) {
    ctx.field.options = [...options];
  }

  autoCompleteSuggestionsOpen(event, autocomplete, field, options) {
    field.options = event.target.defaultValue ? [...options.filter(opt => opt.label.toLowerCase().indexOf(event.target.defaultValue.toLowerCase()) == 0)] : [...options];
    autocomplete.handleDropdownClick();
  }

  autoCompelteOnSelect(field, options) {
    field.options = [...options];
  }

  getCellClass(fnName, fieldName, rowIndex, arrayName) {
    if(typeof this[fnName] === 'function') {
      return this[fnName].apply(this, [
        {
          fieldName: fieldName,
          rowIndex: rowIndex,
          arrayName: arrayName
        }
      ]);
    }
  }

  getAgeBandStyleClass(...args) {
    const { fieldName, rowIndex, arrayName } = args[0];
    const showSubCols = this.getFormControl('_showSubCols', rowIndex, arrayName)?.value;
    if (showSubCols) {
     return 'age-band-cell';
    }
    return '';
  }

  onCreateButtonClick(handler: string, lob: string) {
    this.selectedLOB = lob;
    this.onButtonClick(handler, this.selectedLOB );
    this.showCreateDropdown = false;
  }

  onLOBChange(value: string) {
    this.selectedLOB = value;
  }
}
