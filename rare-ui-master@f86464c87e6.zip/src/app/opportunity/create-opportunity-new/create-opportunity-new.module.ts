import { A11yModule } from '@angular/cdk/a11y';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { OverlayModule } from '@angular/cdk/overlay';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationService, MessageService } from 'primeng/api';
import { CheckboxModule } from 'primeng/checkbox';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { RadioButtonModule } from 'primeng/radiobutton';
import { TableModule } from 'primeng/table';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { TooltipModule } from 'primeng/tooltip';
import { SharedModule } from '../../shared/shared.module';
import { CreateOpportunityService } from '../services/create-opportunity-service';
import { CreateOpportunityNewComponent } from './create-opportunity-new.component';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { DynamicSectionComponent } from './dynamic-form/dynamic-section/dynamic-section.component';
import { ToastModule } from 'primeng/toast';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { DrawerModule } from 'primeng/drawer';
import {IconField} from "primeng/iconfield";
import {InputIcon} from "primeng/inputicon";
import { DataTableEditOveralyComponent } from 'src/app/shared/components/data-table-edit-overaly/data-table-edit-overaly.component';
import { GroupExperienceComponent } from 'src/app/shared/components/group-experience/group-experience.component';

@NgModule({
  declarations: [CreateOpportunityNewComponent, DynamicFormComponent, DynamicSectionComponent],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    CheckboxModule,
    FontAwesomeModule,
    DialogModule,
    A11yModule,
    TableModule,
    AutoCompleteModule,
    CdkStepperModule,
    CdkTableModule,
    CdkTreeModule,
    DragDropModule,
    OverlayModule,
    PortalModule,
    ScrollingModule,
    MultiSelectModule,
    SelectModule,
    ToggleButtonModule,
    MenuModule,
    ProgressSpinnerModule,
    NgbModule,
    SharedModule,
    RouterModule.forChild([{path: '', component: CreateOpportunityNewComponent, pathMatch: 'full'}]),
    RadioButtonModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    ButtonModule,
    DatePickerModule,
    IconField,
    InputIcon,
    ToggleSwitchModule,
    DrawerModule,
    DataTableEditOveralyComponent,
    GroupExperienceComponent
  ],
  exports: [CreateOpportunityNewComponent, DynamicFormComponent, DynamicSectionComponent],
  providers: [CreateOpportunityService, ConfirmationService, MessageService]
})
export class CreateOpportunityNewModule {}
