import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { shareReplay, combineLatestWith, map } from 'rxjs/operators';
import { CommonService } from '../../shared/services';

/**
 * Service to handle operations related to creating and managing opportunities.
 * Provides methods to fetch, save, submit, and manage quotes and opportunities.
 */
@Injectable({
  providedIn: 'root'
})
export class CreateOpportunityService {
  /** URL for fetching the new form JSON schema. */
  private newFormUrl: string = 'assets/mock-jsons/create-opp-new.json';

  /** Base URL for fetching opportunities by ID. */
  private opportunityUrl: string = '/getOpportunities?opportunityID=';

  /** URL for fetching the dynamic form schema for creating opportunities. */
  private createOpportunitySchemaUrl: string = '/dynamicforms/CreateOpportunity';

  /** URL for saving a new opportunity. */
  private saveOpportunityURL: string = '/saveRareOpportunity';

  /** URL for saving a new opportunity. */
  private getACARenewalRatesURL: string = '/addRenewalRates';

  /** URL for saving or updating opportunities. */
  private saveOrUpdateOpportunityURL: string = '/saveOrUpdateOpportunities';

  /** URL for submitting an opportunity. */
  private submitOpportunityURL: string = '/submitOpportunity';

  /** URL for fetching unified quote history. */
  private requestHistory: string = '/unifiedQuoteHistory';

  /** URL for fetching quote history details. */
  private quoteHistoryDetails: string = '/unifiedQuoteDetails';

  /** URL for fetching unified update history. */
  private updateHistory: string = '/unifiedUpdateHistory';
  private replacementContactCodes: string = '/replacementContactCodes';
  private altMrktOptions: string = '/ui/batchOptions';

  /** Cache for storing quote types to avoid redundant API calls. */
  quoteTypeCache = {};

  /**
   * Constructor for CreateOpportunityService.
   * @param http - HttpClient for making HTTP requests.
   * @param commonService - CommonService for shared utility methods.
   */
  constructor(
    private http: HttpClient,
    private commonService: CommonService
  ) {}

  /**
   * Fetches the schema for creating opportunities.
   * @returns An observable containing the schema data.
   */
  getSchema(): Observable<any> {
    const url = this.commonService.getRareUiUrl() + this.createOpportunitySchemaUrl
    return this.http.get<any>(url, { headers: this.commonService.setRequestHeaders() })
  }

  /**
   * Fetches the new form data from a local JSON file.
   * @returns An observable containing the form data.
   */
  getNewFormData(): Observable<any> {
    return this.http.get<any>(this.newFormUrl);
  }

  /**
   * Fetches opportunities by their ID.
   * @param opportunityID - The ID of the opportunity to fetch.
   * @returns An observable containing the opportunity data.
   */
  getOpportunities(opportunityID: String): Observable<any> {
    const url = this.commonService.getRareUiUrl() + this.opportunityUrl + opportunityID;
    return this.http.get<any>(url, { headers: this.commonService.setRequestHeaders() });
  }

  /**
   * Saves a new opportunity.
   * @param opportunity - The opportunity data to save.
   * @returns An observable containing the response from the save operation.
   */
  saveOpportunity(opportunity: String): Observable<any> {
    return this.http.post<any>(this.commonService.getRareUiUrl() + this.saveOpportunityURL, opportunity, { headers: this.commonService.setRequestHeaders() });
  }

  /**
   * add a RenewalRates.
   * @param opportunity - The opportunity data to save.
   * @returns An observable containing the response from the save operation.
   */
  addRenewalRates(opportunity: String): Observable<any> {
    return this.http.post<any>(this.commonService.getRareUiUrl() + this.getACARenewalRatesURL, opportunity, { headers: this.commonService.setRequestHeaders() });
  }

  /**
   * Clones a selected quote.
   * @param selectedQuote - The quote data to clone.
   * @returns An observable containing the response from the clone operation.
   */
  cloneQuote(selectedQuote: any): Observable<any> {
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/copyRareQuote', selectedQuote, { headers: this.commonService.setRequestHeaders() });
  }

  /**
   * Deletes a selected quote.
   * @param selectedQuote - The quote data to delete.
   * @returns An observable containing the response from the delete operation.
   */
  deleteQuote(selectedQuote: any): Observable<any> {
    const options = {
      headers: this.commonService.setRequestHeaders(),
      body: selectedQuote
    };
    return this.http.delete<any>(this.commonService.getRareUiUrl() + '/deleteRareQuote', options);
  }

  /**
   * Submits an opportunity.
   * @param opportunity - The opportunity data to submit.
   * @returns An observable containing the response from the submit operation.
   */
  submitOpportunity(opportunity: String): Observable<any> {
    return this.http.post<any>(this.commonService.getRareUiUrl() + this.submitOpportunityURL, opportunity, { headers: this.commonService.setRequestHeaders() });
  }

  /**
   * Fetches quote types based on various parameters and caches the result.
   * @param cacheCode - The cache key for storing the result.
   * @param state - The state parameter for the API call.
   * @param quoteEffectiveDate - The effective date of the quote.
   * @param factorEffectiveDate - The effective date of the factor.
   * @param mrktSgmnt - The market segment parameter.
   * @returns An observable containing the quote types.
   */
  fetchQuoteTypes(cacheCode: string, state: string, quoteEffectiveDate: string, factorEffectiveDate: string, mrktSgmnt: string): Observable<any> {
    if (this.quoteTypeCache[cacheCode]) {
      return this.quoteTypeCache[cacheCode];
    }

    const parameters = new HttpParams()
      .set('state', state)
      .set('quoteEffDate', quoteEffectiveDate)
      .set('factorEffectiveDate', factorEffectiveDate)
      .set('rtngMkrtSgmnt', mrktSgmnt);
    this.quoteTypeCache[cacheCode] = this.http
      .get<any>(this.commonService.getRareUiUrl() + '/ui/manage/special-quote-types?', {
        params: parameters,
        headers: this.commonService.setRequestHeaders()
      })
      .pipe(shareReplay(1));

    return this.quoteTypeCache[cacheCode];
  }

  /**
   * Fetches the unified quote history for a given opportunity and quote.
   * @param opportunityID - The ID of the opportunity.
   * @param quoteHeaderID - The ID of the quote header.
   * @param fundingType - The funding type parameter.
   * @returns An observable containing the quote history data.
   */
  fetchUnifiedQuoteHistory(opportunityID: string, quoteHeaderID: string, fundingType: string, marketSegment: string, alternateQuote: string, lob: string) {
    const altQuote = alternateQuote ? alternateQuote : 'No';
    const parameters = new HttpParams()
      .set('opportunityID', opportunityID)
      .set('quoteHeaderID', quoteHeaderID)
      .set('fundingType', fundingType)
      .set('marketSegment', marketSegment)
      .set('alternateQuote', altQuote)
      .set('lob', lob);
    return this.http.get<any[]>(this.commonService.getRareUiUrl() + this.requestHistory, {
      headers: this.commonService.setRequestHeaders(),
      params: parameters
    });
  }

  /**
   * Fetches the unified update history for a given opportunity and quote.
   * @param opportunityID - The ID of the opportunity.
   * @param quoteHeaderID - The ID of the quote header.
   * @param fundingType - The funding type parameter.
   * @param quoteHistoryID - The ID of the quote history.
   * @returns An observable containing the update history data.
   */
  fetchUnifiedUpdateHistory(
    opportunityID: string,
    quoteHeaderID: string,
    fundingType: string,
    quoteHistoryID: string,
    marketSegment: string,
    alternateQuote: string,
    lob: string
  ) {
    const parameters = new HttpParams()
      .set('opportunityID', opportunityID)
      .set('quoteHeaderID', quoteHeaderID)
      .set('fundingType', fundingType)
      .set('quoteHistoryID', quoteHistoryID)
      .set('marketSegment', marketSegment)
      .set('alternateQuote', alternateQuote)
      .set('lob', lob);

    return this.http.get<any[]>(this.commonService.getRareUiUrl() + this.updateHistory, {
      headers: this.commonService.setRequestHeaders(),
      params: parameters
    });
  }

  /**
   * Fetches the unified quote details for a given opportunity and quote.
   * @param opportunityID - The ID of the opportunity.
   * @param quoteHeaderId - The ID of the quote header.
   * @param quoteHistoryId - The ID of the quote history (optional).
   * @param fundingType - The funding type parameter.
   * @returns An observable containing the quote details.
   */
  getUnifiedQuoteDetails(
    opportunityID: string,
    quoteHeaderId: string,
    quoteHistoryId: string,
    fundingType: string,
    marketSegment: string,
    lob: string
  ): Observable<any> {
    let parameters = new HttpParams().set('opportunityID', opportunityID).set('quoteHeaderID', quoteHeaderId).set('marketSegment', marketSegment);
    if (quoteHistoryId) {
      parameters = parameters.set('quoteHistoryID', quoteHistoryId);
    }
    parameters = parameters.set('fundingType', fundingType);
    parameters = parameters.set('lob', lob);

    return this.http.get<any>(this.commonService.getRareUiUrl() + this.quoteHistoryDetails, {
      headers: this.commonService.setRequestHeaders(),
      params: parameters
    });
  }

  fetchReplacementContactCodes(
    contractCodes: any,
    newFundingType: any,
    marketSegment: any,
    state: any,
    contractEffectiveDate: any,
    lob: string,
    oppType: string,
    altMarket: boolean = false,
    zipCode: any,
    county: any,
    effectiveDate: any,
    association: any,    
    opportunityID: any,
    quoteHeaderId: any
  ) {
    let parameters = new HttpParams()
      .set('contractCodes', contractCodes)
      .set('fundingType', newFundingType)
      .set('marketSegment', marketSegment)
      .set('state', state)
      .set('contractEffectiveDate', contractEffectiveDate)
      .set('lob', lob)
      .set('opportunityType', oppType)
      .set('zipCode', zipCode)
      .set('county', county)
      .set('effectiveDate', effectiveDate)
      .set('association', association ? association : '')
      .set('opportunityID', opportunityID)
      .set('quoteHeaderId', quoteHeaderId);
    if (altMarket) {
      parameters = parameters.set('altMarket', 'altMarket');
    }

    return this.http.get<any[]>(this.commonService.getRareUiUrl() + this.replacementContactCodes, {
      headers: this.commonService.setRequestHeaders(),
      params: parameters
    });
  }

  fetchFundingTypeForAltMrkt(marketSegment: any, lob: any, opportunityType: any, fundingType: any, state: any, contractEffectiveDate: any) {
    const parameters = new HttpParams()
      .set('marketSegment', marketSegment)
      .set('lob', lob)
      .set('opportunityType', opportunityType)
      .set('fundingType', fundingType)
      .set('state', state)
      .set('contractEffectiveDate', contractEffectiveDate);
    return this.http.get<any[]>(this.commonService.getRareUiUrl() + this.altMrktOptions, {
      headers: this.commonService.setRequestHeaders(),
      params: parameters
    });
  }
}
