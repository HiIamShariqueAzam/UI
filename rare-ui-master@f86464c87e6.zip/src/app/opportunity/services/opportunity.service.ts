import { HttpClient, HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { Observable } from 'rxjs';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { CommonService } from 'src/app/shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class OpportunityService {
  constructor(
    private http: HttpClient,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService
  ) {}

  callCacheRefresh(body, lobValue) {
    let headers = this.commonService.setCacheInfoHeaders();
    let request = {
      cacheRefreshBody: body
    };
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    if (lobValue === 'MED' || lobValue === 'SYS' || lobValue === 'SHP') {
      let headers = this.commonService.setCacheInfoHeaders().set('cacheType', lobValue);
      return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/cache' + '/' + lobValue + '/refresh', rareUiRequest, {
        headers: headers,
        observe: 'response'
      });
    } else if (lobValue === 'VIS') {
      if (body == null) {
        body = lobValue;
        request = {
          cacheRefreshBody: body
        };
        rareUiRequest = this.commonService.getRareUiRequest(request);
        return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/cache' + '/' + lobValue + '/refresh', rareUiRequest, {
          headers: headers,
          observe: 'response'
        });
      } else {
        return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/cache' + '/' + lobValue + '/refresh', rareUiRequest, {
          headers: headers,
          observe: 'response'
        });
      }
    } else if (lobValue === 'DEN') {
      if (body == null) {
        body = lobValue;
        request = {
          cacheRefreshBody: body
        };
        rareUiRequest = this.commonService.getRareUiRequest(request);
        return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/cache' + '/' + lobValue + '/refresh', rareUiRequest, {
          headers: headers,
          observe: 'response'
        });
      } else {
        return this.http.post<any>(this.commonService.getRareUiUrl() + '/ui/cache' + '/' + lobValue + '/refresh', rareUiRequest, {
          headers: headers,
          observe: 'response'
        });
      }
    }
  }

  callGatewayCache() {
    let headers = this.commonService.setCacheInfoHeaders();
    return this.http.get(this.commonService.gatewayCacheRefreshUrl, { headers: headers, observe: 'response' });
  }

  callRatingCache() {
    let headers = this.commonService.setCacheInfoHeaders();
    return this.http.get(this.commonService.getRareUiUrl() + '/rating/cache/clear', { headers: headers, observe: 'response' });
  }

  /*Opportunities Service*/
  getOpportunities(form: FormGroup, pageLimit: number, cursor: any, sortMetaData: any, mrktSg: any): Observable<any> {
    let queryObject = {};
    let flagFromdate: boolean = false;
    let flagTodate: boolean = false;
    Object.keys(form.controls).forEach((key) => {
      if (key === 'quoteReason') {
        queryObject[key] = form.value[key] ? { $in: ['TEST'] } : { $nin: ['TEST'] };
      } else {
        if (form.value[key] != '' && form.value[key] != null) {
          let keyValue = form.value[key];
          if (key === 'groupName') {
            keyValue = { $regex: '.*' + this.commonService.escapeRegExp(keyValue.trim()) + '.*' };
          } else if (key === 'opportunityID') {
            keyValue = { $regex: '.*' + this.commonService.escapeRegExp(keyValue.trim()) + '.*' };
          } else if (key === 'state') {
            keyValue = { $in: form.get('state').value };
          }
          if (key === 'marketSegment') {
            keyValue = { $in: form.get('marketSegment').value };
          } else if (key === 'opportunityType') {
            keyValue = { $in: form.get('opportunityType').value };
          }
          queryObject[key] = keyValue;
        } else {
          if ((this.commonService.hasSgRole() && !this.commonService.hasLgRole()) || (this.commonService.hasLgRole() && !this.commonService.hasSgRole())) {
            queryObject['marketSegment'] = { $in: [mrktSg.value] };
          }
        }
      }
    });

    let queryString = JSON.stringify(queryObject);
    this.storage.set('oppSearchQuery', queryString);
    let urlComponents = '?query=' + encodeURIComponent(queryString);
    if (pageLimit) {
      this.storage.set('oppPageLimit', pageLimit);
      urlComponents = urlComponents + '&pageLimit=' + pageLimit;
    }
    if (cursor) {
      this.storage.set('oppCursor', cursor);
      urlComponents = urlComponents + '&cursor=' + encodeURIComponent(JSON.stringify(cursor));
    }
    if (sortMetaData) {
      urlComponents = urlComponents + '&sortMetaData=' + encodeURIComponent(sortMetaData);
    }
    let headers = this.commonService.setRequestHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/rareOpportunities' + urlComponents, { headers: headers });
  }

  getOpportunityByQuery(queryString, pageLimit, cursor, sortMetaData) {
    let headers = this.commonService.setRequestHeaders();
    this.storage.set('oppSearchQuery', queryString);
    if (pageLimit) this.storage.set('oppPageLimit', pageLimit);
    if (cursor) this.storage.set('oppCursor', cursor);
    queryString = encodeURIComponent(queryString);
    if (sortMetaData) {
      queryString = queryString + '&sortMetaData=' + encodeURIComponent(JSON.stringify(sortMetaData));
    }
    if (pageLimit && cursor)
      return this.http.get<any>(
        this.commonService.getRareUiUrl() +
          '/rareOpportunities?cursor=' +
          encodeURIComponent(JSON.stringify(cursor)) +
          '&pageLimit=' +
          pageLimit +
          '&query=' +
          queryString,
        { headers: headers }
      );
    else if (pageLimit)
      return this.http.get<any>(this.commonService.getRareUiUrl() + '/rareOpportunities?pageLimit=' + pageLimit + '&query=' + queryString, {
        headers: headers
      });
    else return this.http.get<any>(this.commonService.getRareUiUrl() + '/rareOpportunities?query=' + queryString, { headers: headers });
  }

  fetchQuoteHistoryDetails(oppId: string, quoteId: string, version, quoteHistoryId: string): Observable<any> {
    const parameters = new HttpParams()
      .set('opportunityID', oppId)
      .set('quoteHeaderID', quoteId)
      .set('versionNumber', version)
      .set('quoteHistoryID', quoteHistoryId);

    return this.http.get<any>(this.commonService.getRareUiUrl() + '/old/quoteDetail?', { headers: this.commonService.setRequestHeaders(), params: parameters });
  }

  checkUserRoleForOpportunity() {
    let isValidRole = false;
    this.authenticationService
      .getUserRole()
      .split(',')
      .forEach((element) => {
        if (!isValidRole && CommonConstants.opportunityRoles.includes(element)) {
          isValidRole = true;
        }
      });
    return isValidRole;
  }

  getOpportunityDetail(oppID: String) {
    let epochTime = new Date().getTime();
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/getOpportunityQuoteDetails?opportunityID=' + oppID + '&epochTime=' + epochTime, {
      headers: headers
    });
  }

  cloneQuote(oppID: String, quoteHeaderID: string, copyQuoteHeaderID: string) {
    let request = {
      opportunityID: oppID,
      quoteHeaderID: quoteHeaderID,
      copyQuoteHeaderID: copyQuoteHeaderID
    };
    let rareUiRequest = this.commonService.getRareUiRequest(request);
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.post<any>(this.commonService.getRareUiUrl() + '/copyQuote', rareUiRequest, { headers: headers });
  }

  getOpportunityQuoteDetail(oppID: String, quoteHeaderID: string) {
    let epochTime = new Date().getTime();
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.get<any>(
      this.commonService.getRareUiUrl() + '/getQuoteDetails?opportunityID=' + oppID + '&quoteHeaderID=' + quoteHeaderID + '&epochTime=' + epochTime,
      { headers: headers }
    );
  }

  deleteQuoteDetails(oppId: any, quoteHeaderId: any) {
    let headers = this.commonService.setRateInfoHeaders();
    return this.http.delete<any>(this.commonService.getRareUiUrl() + '/deleteQuote/' + oppId + '/' + quoteHeaderId, { headers: headers });
  }

  fetchQuoteHistory(oppId: string, quoteId: string): Observable<any[]> {
    const parameters = new HttpParams().set('opportunityID', oppId).set('quoteHeaderID', quoteId);

    return this.http.get<any[]>(this.commonService.getRareUiUrl() + '/quoteHistory?', { headers: this.commonService.setRequestHeaders(), params: parameters });
  }

  fetchQuoteTypes(state: string, quoteEffectiveDate: string, factorEffectiveDate: string, mrktSgmnt: string): Observable<any> {
    const parameters = new HttpParams()
      .set('state', state)
      .set('quoteEffDate', quoteEffectiveDate)
      .set('factorEffectiveDate', factorEffectiveDate)
      .set('rtngMkrtSgmnt', mrktSgmnt);
    return this.http.get<any>(this.commonService.getRareUiUrl() + '/ui/manage/special-quote-types?', {
      params: parameters,
      headers: this.commonService.setRequestHeaders()
    });
  }
}
