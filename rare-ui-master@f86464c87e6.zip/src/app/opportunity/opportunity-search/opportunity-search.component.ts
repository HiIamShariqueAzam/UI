import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { OpportunityDetails } from 'src/app/shared/models/opportunityDetails';
import { AuthenticationService, CacheService, CommonService } from 'src/app/shared/services';
import { HttpClientService } from 'src/app/shared/services/http-client.service';
import { SearchConstants } from '../../quotes/quote-search/constants/index';
import { OpportunityService } from '../services/opportunity.service';
@Component({
  selector: 'app-opportunity-search',
  templateUrl: './opportunity-search.component.html',
  styleUrls: ['./opportunity-search.component.css'],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class OpportunitySearchComponent implements OnInit {
  [x: string]: any;
  opportunitySubmit: any;
  showNextButton: boolean = false;
  showPrevButton: boolean = false;
  nextCursor: any;
  prevCursor: any;
  opportunity_form: FormGroup<OpportunityDetails>;
  alphaNumericPattern = '^[a-z0-9_]{8,15}$';
  showSummary: boolean = false;
  selectedOpportunity = [];
  rowData: any[];
  pageIndex = 1;
  totalPages;
  isSearched: boolean = false;
  isEmpty: boolean = false;
  availableStates: any[];
  availableMarketSeg: any[];
  availableOppType: any[];
  selectedState: any;
  selectedMarketSeg: any;
  selectedOppType: any;
  multiselectEle: any;
  oppID: string;
  first = 0;
  rows = 10;
  rowsPerPage: any[];
  selectedPageSize: any;
  nextButtonClicked: boolean;
  prevButtonClicked: boolean;
  showOpportunities: boolean = false;
  sicCache: string = '';
  zipCache: string = '';
  stateCache: string = '';
  multiSortMeta = [
    {
      field: 'state',
      order: 1
    },
    {
      field: 'marketSegment',
      order: 1
    }
  ];
  cols = [
    {
      header: 'Opportunity ID',
      field: 'opportunityID'
    },
    {
      header: 'Group Name',
      field: 'groupName'
    },
    {
      header: 'Opportunity Type',
      field: 'opportunityType'
    },
    {
      header: 'State',
      field: 'state'
    },
    {
      header: 'Market Segment',
      field: 'marketSegment'
    }
  ];
  selectedQuoteReason: boolean = false;
  userRole: any;
  createOpportunityURL: string = '/opportunity/create-opportunity-new';

  constructor(
    private fb: FormBuilder,
    private httpClientService: HttpClientService,
    public datepipe: DatePipe,
    private router: Router,
    private opportunityService: OpportunityService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private authService: AuthenticationService,
    private cacheService: CacheService,
    private commonService: CommonService
  ) {
    let zipResponse = this.cacheService.getZipCodeList(this.zipCache);
    let stateResponse = this.cacheService.getStates(this.stateCache);
    let sicResponse = this.cacheService.getSICCodeList(this.sicCache);
    zipResponse.subscribe((response) => {
      let zipCode = response;
    });
    stateResponse.subscribe((response) => {
      let state = response;
    });
    sicResponse.subscribe((response) => {
      let sic = response;
    });
  }

  setFormValue() {
    this.opportunity_form.setValue({
      groupName: this.storage.get('oppGroupName') || '',
      state: this.storage.get('oppState') || null,
      opportunityID: this.storage.get('oppOpportunityID') || '',
      marketSegment: this.storage.get('oppMarketSegment') || null,
      opportunityType: this.storage.get('oppOpportunityType') || null,
      quoteReason: this.storage.get('quoteReason') || false
    });
    if (this.storage.get('oppState')) this.selectedState = this.storage.get('oppState');
    if (this.storage.get('oppMarketSegment')) this.selectedMarketSeg = this.storage.get('oppMarketSegment');
    if (this.storage.get('oppOpportunityType')) this.selectedOppType = this.storage.get('oppOpportunityType');
    if (this.storage.get('oppPageLimit'))
      this.selectedPageSize = { label: '' + this.storage.get('oppPageLimit') + '', value: this.storage.get('oppPageLimit') };
    if (this.storage.get('quoteReason')) this.selectedQuoteReason = this.storage.get('quoteReason');
  }

  ngOnInit() {
    this.opportunity_form = this.fb.group({
      groupName: [
        '',
        {
          validators: [Validators.minLength(3), Validators.pattern(this.alphaNumericPattern)],
          updateOn: 'submit'
        }
      ],
      state: [''],
      marketSegment: [''],
      opportunityType: [''],
      quoteReason: false,
      opportunityID: [
        '',
        {
          validators: [Validators.minLength(3), Validators.pattern(this.alphaNumericPattern)],
          updateOn: 'submit'
        }
      ]
    });

    this.rowsPerPage = [
      { label: '10', value: 10 },
      { label: '20', value: 20 },
      { label: '30', value: 30 }
    ];
    this.selectedPageSize = this.rowsPerPage[0];
    if (this.hasSgRole() && !this.hasLgRole()) {
      this.availableMarketSeg = CommonConstants.MARKET_SEGEMENT_SG_LIST;
    } else if (this.hasLgRole() && !this.hasSgRole()) {
      this.availableMarketSeg = CommonConstants.MARKET_SEGEMENT_LG_LIST;
    } else {
      this.availableMarketSeg = CommonConstants.MARKET_SEGEMENT_LIST;
    }
    this.availableOppType = SearchConstants.OPPORTUNITY_TYPE_LIST;
    this.userRole = this.authService.userRole['_value'];
    this.availableStates = this.commonService.getStateList();

    if (this.storage.get('oppShowOpportunities') === 'true') {
      this.showOpportunities = this.storage.get('oppShowOpportunities');
      if (this.storage.get('oppSearchQuery')) {
        this.getRowData(this.storage.get('oppSearchQuery'), this.storage.get('oppPageLimit'), this.storage.get('oppCursor'));
        this.setFormValue();
      } else this.showOpportunities = false;
      this.totalPages = this.storage.get('oppTotalPages');
      if (this.storage.get('oppFirst') && this.totalPages > 1) {
        this.first = this.storage.get('oppFirst');
        this.pageIndex = this.storage.get('oppPageIndex');
      } else {
        this.first = 0;
        this.pageIndex = 1;
      }
    } else {
      this.showOpportunities = false;
      this.rowData = [];
      this.totalPages = 0;
      this.first = 0;
    }
    this.cacheService.getSICCodeList('');
  }

  ngAfterViewInit() {
    this.multiselectEle = document.querySelector('.ui-multiselect') as any;
    if (this.multiselectEle != null) {
      this.multiselectEle.setAttribute('tabindex', -1);
    }
  }

  onRowSelect($event) {
    this.oppID = $event.data['opportunityID'];
  }

  onGoToPage(rowData, $event) {
    this.storage.set('oppMultiSortMeta', this.multiSortMeta);
    let opportunityID = rowData['opportunityID'];
    this.router.navigate(
      [this.createOpportunityURL],
      { queryParams: { opportunityID } }
    );
  }

  displayOptionsPannel() {
    if (this.multiselectEle) {
      this.multiselectEle.focus();
    }
  }

  nextClicked() {
    if (this.showNextButton) {
      this.nextButtonClicked = true;
      this.searchClicked();
      this.nextButtonClicked = false;
    }
  }

  prevClicked() {
    if (this.showPrevButton) {
      this.prevButtonClicked = true;
      this.searchClicked();
      this.prevButtonClicked = false;
    }
  }

  searchClicked(isRefresh?: boolean) {
    let flagFocus = false;
    this.isSearched = true;
    this.isEmpty = false;
    let pageLimit = 10;
    let cursor: any;
    let sortMetaData: any = null;

    if (this.selectedPageSize) pageLimit = this.selectedPageSize.value;

    if (this.nextButtonClicked) {
      cursor = this.nextCursor;
    }

    if (this.prevButtonClicked) {
      cursor = this.prevCursor;
    }

    if (this.multiSortMeta != undefined) {
      sortMetaData = JSON.stringify(this.multiSortMeta);
    }

    let form = this.opportunity_form;

    /*If  quoteReason has has no value*/
    if (form.get('quoteReason').value !== '' && (form.get('quoteReason').value === '' || form.get('quoteReason').value === null)) {
      form.get('quoteReason').setValue(false);
    }

    /*If Fromdate has no value*/
    Object.keys(form.controls).forEach((field) => {
      if (flagFocus == false) {
        const control = form.get(field).errors;
        if (control) {
          Object.keys(control).forEach((field1) => {
            if (field1 == 'minlength') {
              flagFocus = true;
            }
          });
          let element: HTMLElement = document.querySelectorAll('[formcontrolname="' + field + '"]')[0] as HTMLElement;
          element.focus();
        }
      }
    });

    if (!this.showEmptyFromDate && !flagFocus) {
      this.showOpportunities = false;
      this.rowData = [];
      this.totalPages = 0;

      this.getOpportunityData(form, pageLimit, cursor, sortMetaData, this.availableMarketSeg[0], isRefresh);
    } else {
      this.showOpportunities = false;
      this.isSearched = false;
      this.storage.set('oppShowOpportunities', 'false');
    }
  }

  createOppClicked() {
    this.router.navigate([this.createOpportunityURL]);
  }

  resetClicked() {
    this.opportunity_form.reset();
    this.isEmpty = false;
    this.isSearched = false;
    this.showOpportunities = false;
    this.rowData = [];
    this.totalPages = 0;
    this.selectedQuoteReason = false;

    this.storage.remove('oppShowOpportunities');
    this.storage.remove('oppTotalPages');
    this.storage.remove('oppFirst');
    this.storage.remove('oppPageIndex');
    this.storage.remove('oppSearchQuery');
    this.storage.remove('oppGroupName');
    this.storage.remove('oppState');
    this.storage.remove('oppOpportunityID');
    this.storage.remove('oppMarketSegment');
    this.storage.remove('oppOpportunityType');
    this.storage.remove('oppPageLimit');
    this.storage.remove('oppCursor');
    this.storage.remove('oppMultiSortMeta');
    this.storage.remove('quoteReason');
  }

  paginate(event) {
    this.pageIndex = event.first / event.rows + 1;
    this.storage.set('oppFirst', event.first);
    this.storage.set('oppPageIndex', this.pageIndex);
  }

  saveMultiSortMeta(event) {
    this.multiSortMeta = event.multisortmeta;
  }

  getOpportunityData(form, pageLimit, cursor, sortMetaData, mrktSg, isRefresh?: boolean) {
    this.opportunitySubmit = this.opportunityService.getOpportunities(form, pageLimit, cursor, sortMetaData, mrktSg).subscribe(
      (response) => {
        if (response.rareOpportunities.length) {
          this.showOpportunities = true;
          this.showNextButton = response.hasNextCursor;
          this.showPrevButton = response.hasPrevCursor;
          this.nextCursor = response.nextCursor;
          this.prevCursor = response.prevCursor;
          this.rowData = response.rareOpportunities;
          this.totalPages = Math.ceil(this.rowData.length / 10);
          this.first = 0;
          this.pageIndex = 1;
          this.storage.set('oppFirst', 0);
          this.storage.set('oppShowOpportunities', 'true');
          this.storage.set('oppTotalPages', this.totalPages);
          this.storage.set('oppPageIndex', 1);
          this.storage.set('oppGroupName', this.opportunity_form.controls.groupName.value);
          this.storage.set('oppState', this.opportunity_form.controls.state.value);
          this.storage.set('oppOpportunityID', this.opportunity_form.controls.opportunityID.value);
          this.storage.set('oppMarketSegment', this.opportunity_form.controls.marketSegment.value);
          this.storage.set('oppOpportunityType', this.opportunity_form.controls.opportunityType.value);
          this.storage.set('quoteReason', this.opportunity_form.controls.quoteReason.value);
          if (isRefresh) {
            this.storage.remove('oppCursor');
          }
        } else {
          this.showOpportunities = false;
          this.storage.set('oppShowOpportunities', 'false');
          this.isEmpty = true;
        }
      },
      (error) => {
        this.showOpportunities = false;
        this.storage.set('oppShowOpportunities', 'false');
      }
    );
  }

  checkUserRole() {
    return this.opportunityService.checkUserRoleForOpportunity();
  }

  hasSgRole() {
    return this.commonService.hasSgRole();
  }

  hasLgRole() {
    return this.commonService.hasLgRole();
  }

  hasReadOnly() {
    return this.commonService.hasReadOnlyRole();
  }

  getRowData(query, pageLimit, cursor) {
    this.multiSortMeta = this.storage.get('oppMultiSortMeta');
    this.opportunityService.getOpportunityByQuery(query, pageLimit, cursor, this.multiSortMeta).subscribe(
      (response) => {
        if (response.rareOpportunities.length) {
          this.showOpportunities = true;
          this.showNextButton = response.hasNextCursor;
          this.showPrevButton = response.hasPrevCursor;
          this.nextCursor = response.nextCursor;
          this.prevCursor = response.prevCursor;
          this.rowData = response.rareOpportunities;
        } else {
          this.showOpportunities = false;
          this.storage.set('oppShowOpportunities', 'false');
          this.isEmpty = true;
        }
      },
      (error) => {
        this.showOpportunities = false;
        this.storage.set('oppShowOpportunities', 'false');
      }
    );
  }

  checkAdminUserRole() {
    if (this.userRole.includes('ADMIN') || this.userRole.includes('UNDERWRITER') || this.userRole.includes('SGSALES') || this.userRole.includes('LGSALES')) {
      return true;
    } else if (this.userRole.includes('ADMIN') && !this.userRole.includes('READONLY')) {
      return false;
    }
  }
}
