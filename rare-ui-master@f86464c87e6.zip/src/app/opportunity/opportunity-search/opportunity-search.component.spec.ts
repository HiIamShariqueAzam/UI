import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { OpportunitySearchComponent } from './opportunity-search.component';

describe('OpportunitySearchComponent', () => {
  let component: OpportunitySearchComponent;
  let fixture: ComponentFixture<OpportunitySearchComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ OpportunitySearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunitySearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
