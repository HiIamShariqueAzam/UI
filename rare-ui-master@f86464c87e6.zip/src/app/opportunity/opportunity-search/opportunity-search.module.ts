import { NgModule  } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CheckboxModule } from 'primeng/checkbox';
import { SelectModule } from 'primeng/select';
import { MultiSelectModule } from 'primeng/multiselect';
import { OpportunitySearchComponent } from './opportunity-search.component';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
    declarations: [OpportunitySearchComponent],
    imports: [
        CommonModule, TableModule, ButtonModule, ReactiveFormsModule, SelectModule, RadioButtonModule, FlexLayoutModule,
        AutoCompleteModule, CheckboxModule, FormsModule, MultiSelectModule, ButtonModule, SharedModule,
        RouterModule.forChild([
            { path: '', component: OpportunitySearchComponent, pathMatch: 'full' }
        ])
    ],
    exports: [
        OpportunitySearchComponent
    ],
    providers: [DatePipe]
})
export class OpportunitySearchModule { }
