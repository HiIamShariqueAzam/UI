import { Component, OnInit, Output, EventEmitter, Input, OnChanges, SimpleChanges } from "@angular/core";
import { Validators, FormArray, FormGroup, FormBuilder } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from "rxjs/operators";
import { salesForm } from "src/app/shared/models/sales";
import { CommonService } from "src/app/shared/services";

@Component({
  selector: "app-sales-broker",
  templateUrl: "./sales-broker.component.html",
  styleUrls: ["./sales-broker.component.css"],
  standalone: false,
})
export class SalesBrokerComponent implements OnInit, OnChanges {
  userTypes: { name: string; }[] = [
    {name: "Sales Support"},
    {name: "Account Exec"},
    {name: "Broker"},
    {name: "Underwriter"}
  ];
  salesForm: FormGroup<salesForm>;
  salesChkAllboxUpdate: boolean;
  @Input() salesBrokerIP: any[] = [];
  @Input() isReadOnlyMode: boolean = false;
  @Output() salesBrokerOP = new EventEmitter<any>();

  constructor(private commonService: CommonService, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.salesForm = this.fb.group({
      Rows: this.fb.array([]) ,
    });
    this.setBrokerValues();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.salesBrokerIP && !changes.salesBrokerIP.firstChange) {
      this.setBrokerValues();
    }
  }

  setBrokerValues() {
    this.formArr.clear();
    if (this.salesBrokerIP && this.salesBrokerIP.length > 0) {
      for (var x = 0; x < this.salesBrokerIP.length; x++) {
        this.addFieldValue(this.salesBrokerIP[x]);
      }
      this.disableBrokerContactUsage();
    }
  }

  onChangeRole(index){
    if(this.formArr.controls[index].get('role').value.name == "Broker"){
      this.checkPrimaryContactUsage(index);
      this.formArr.controls[index].get('contactUsage').disable();
    }else{
      this.formArr.controls[index].get('contactUsage').enable();
      this.updateDefaultPrimaryContactUsage();
    }
  }

  setDefaultContactUsage(){
    for(var i=0; i< this.formArr.controls.length; i++){
      if(this.formArr.controls[i].get('role').value.name != "Broker"){
        this.formArr.controls[i].get('contactUsage').setValue('Primary');
        break;
      }
    }
  }

  disableBrokerContactUsage(){
    for(var i=0; i< this.formArr.controls.length; i++){
      if(this.formArr.controls[i].get('role').value.name == "Broker"){
        this.formArr.controls[i].get('contactUsage').setValue(null);
        this.formArr.controls[i].get('contactUsage').disable();
      }
    }
  }

  checkPrimaryContactUsage(index){
    if(this.formArr.controls[index].get('contactUsage') && this.formArr.controls[index].get('contactUsage').value == "Primary"){
      this.formArr.controls[index].get('contactUsage').setValue(null);
      if(this.formArr.controls.length > 1){
        this.setDefaultContactUsage();
      }
    }else{
      this.updateDefaultPrimaryContactUsage();
    }
  }

  updateDefaultPrimaryContactUsage(){
    if(this.formArr.controls.length >= 1){
      let primaryExists = this.formArr.controls.some(control => control.get('contactUsage').value == "Primary");
      if(!primaryExists){
        this.setDefaultContactUsage();
      }
    }
  }

  get formArr() {
    return this.salesForm.get("Rows") as FormArray;
  }

  addFieldValue(initalValue: any = {}) {
    this.formArr.push(this.initRows(initalValue));
  }

  initRows(defaultValue: any) {
    let brokerRow = this.fb.group({
      tblCheck: false ,
      role: [defaultValue.role ? {name: defaultValue.role} : '', Validators.required],
      fullName: [defaultValue.fullName || '', Validators.required],
      companyName: [defaultValue.companyName || ''],
      contactNumber: [defaultValue.contactNumber || '', []],
      emailId: [defaultValue.emailId || ''],
      contactUsage: [defaultValue.contactUsage || ''],
    });
    brokerRow.valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged()).subscribe(val => this.sendSalesBrokerOP(val));
    return brokerRow;

  }

  deleteFieldValue() {
    if (this.salesChkAllboxUpdate) {
      this.formArr.clear();
      this.salesChkAllboxUpdate = false ;
    } else {
      for (let i = 0; i < this.formArr.controls.length; ) {
        if (this.formArr.controls[i].get('tblCheck').value == true) {
          this.formArr.removeAt(i);
          this.updateDefaultPrimaryContactUsage();
        } else {
          i++;
        }
      }
    }
    this.sendSalesBrokerOP();
  }

  removePrimaryFromOther(index){
    if(this.formArr.controls.length) {
      for(let formIndex = 0 ; formIndex < this.formArr.length ;formIndex++) {
        if(index != formIndex){
        this.formArr.controls[formIndex].get('contactUsage').setValue('');
        }
      }
    }
  }

  sendSalesBrokerOP(val?: any) {
    if (this.formArr.controls.length) {
      this.salesBrokerOP.emit({"salesBroker": this.formArr.value, "hasErrors": this.formArr.status != "VALID"});
    } else {
      this.salesBrokerOP.emit({ "salesBroker": [], "hasErrors": false });
    }
  }

  selectAllSalesInfo(event) {
    this.formArr.controls.map(value => value.get('tblCheck').setValue(event.target.checked));
    this.salesChkAllboxUpdate = event.target.checked;
  }

  updateBrokerSelection() {
    let selectedCount = this.formArr.controls.filter(value => value.get('tblCheck').value == true);
    this.salesChkAllboxUpdate = this.formArr.controls.length == selectedCount.length;
  }

}


