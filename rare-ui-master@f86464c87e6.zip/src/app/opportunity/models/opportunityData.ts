export interface saveOppData {
    opportunityID: string;
    groupName: string;
    addr1: string;
    addr2: string;
    city: string;
    companyZipCode: string;
    state: string;
    sicCode: string;
    quotes?: any;
  }

  export interface oppScreenData {
    quoteHeaderID: string
    quoteName: string
    submittedTimestamp?: string
    accountID: string
    accountName: string
    quoteLegalEntity: string
    quoteIsWholeCase: string
    addr1: string
    addr2: string
    city: string
    state: string
    companyZipCode: string
    sicCode: string
    mbu: string
    mbs: string
    marketSegment: string
    quoteReason: string
    groupNbr: string
    groupNameDBA: string
    contractEffectiveDate: string
    contractEndDate: string
    requestedDueDate: string
    factorEffectiveDate: string
    virginGroup: string
    medicalInputTier: string
    medicalOutputTier: string
    productsQuoted: string[]
    userSelectedFundingType: string
    userSelectedFIComissionValue: string
    userSelectedFIComissionType: string
    userSelectedChamberOfCommerce: string
    userSelectedPremiumDelay: string
  }

  export interface oppStopLossData {
    'sslDeductible': string;
    'sslContractBasis': string;
    'aggSLCorridor': string;
    'surplusRefund': string;
  }