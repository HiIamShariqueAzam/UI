import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { RemoveFactorsComponent } from './remove-factors.component';

describe('RemoveFactorsComponent', () => {
  let component: RemoveFactorsComponent;
  let fixture: ComponentFixture<RemoveFactorsComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveFactorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveFactorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
