import { NgModule, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { RemoveFactorsComponent } from './remove-factors.component';
import { ToastModule } from 'primeng/toast';
import { MultiSelectModule } from 'primeng/multiselect';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';

@NgModule({
    declarations: [
        RemoveFactorsComponent
    ],
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule, ButtonModule, ProgressSpinnerModule, ToastModule, DialogModule,
        PickListModule, FlexLayoutModule, SelectModule, MultiSelectModule, RouterModule.forChild([
            { path: '', component: RemoveFactorsComponent, pathMatch: 'full' }
        ])
    ],
    exports: [
        RemoveFactorsComponent
    ],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class RemoveFactorsModule { }
