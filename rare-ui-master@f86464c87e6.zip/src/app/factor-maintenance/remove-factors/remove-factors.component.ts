import { Component, OnInit, Inject } from '@angular/core';
import { CommonService, AuthenticationService } from 'src/app/shared/services';
import { PickList } from 'primeng/picklist';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { MessageService } from 'primeng/api';
import { DateFormatPipe } from 'src/app/shared/pipes/date-format-pipe';

@Component({
    selector: 'app-remove-factors',
    templateUrl: './remove-factors.component.html',
    styleUrls: ['./remove-factors.component.css'],
    standalone: false,
})
export class RemoveFactorsComponent implements OnInit {
    sourceHeaderPicklist: string;
    targetHeaderPicklist: string;
    sourcePlaceholder: string;
    showLobDropdown: boolean = false;
    showLobError: boolean = false;
    showStateError: boolean = false;
    showTable: boolean = false;
    sourceList: any = [];
    targetList: any[];
    lobList: any[] = [];
    stateList: any[] = [];
    medMap: any[] = [];
    tableMap = new Map<string, string[]>();
    flagStatus: boolean = true;
    cacheRefreshStatus: boolean = false;
    failedTables: any[];
    versionArray: any[] = [];
    showVersionDropdown: boolean = false;
    showTableError: boolean = false;
    showVersionError: boolean = false;
    showStateSingleValue: boolean = false;
    showStateDropdown: boolean = false;
    userSelectedLob: any;
    lobValue: any;
    lobLabel: any;
    userSelectedVersion: any;
    userSelectedState: any;
    userSelectedTable: any;
    tableValue: any[];
    stateValue: any;
    response: any;
    loadingOverlayFlag: boolean = false;
    eventTest: PickList;
    div_visible: boolean = false;
    showDate: boolean = false;
    selcetedQuoteEffectiveDate: any;
    selcetedFactorEffectiveDate: any;
    map = new Map<string, string[]>();
    tableList: any[] = [];
    tableFinalList: any[] = [];
    viewMap = new Map<string, string>();
    disableSubmit: boolean = false;
    tableNames: any[];
    isWarningDisabled:boolean = true;
    showTablesDropdown: boolean = false;
    displayDialog: boolean;
    messages = {
        "errorMessageReqTable": "Please select the table",
        "errorMessageReqVersion": "Please select a version",
        "errorMessageLob": "Please select the LOB",
        "errorMessageState": "Please select the state"
    };
    readonly httpMessages = {
        errorMessage: `Error in deleting the selected factor data`,
        cacheErrorMessage: `Error in cache Refresh`,
        successMessage: 'All selected factors were removed successfully !!!',
    };

    constructor(private commonService: CommonService, private dateFormatPipe: DateFormatPipe, private messageService: MessageService,
        private authenticationService: AuthenticationService, @Inject(SESSION_STORAGE) private storage: WebStorageService) {

        this.lobList = this.commonService.getLobList();
        this.stateList = this.commonService.getStateList().slice(0);

        this.resetLobData();
        this.resetStateData();
    }

    setTableList(lob) {
        if (this.userSelectedLob.value) {
            this.map = this.commonService.getMapOfRoleAndTableNames();
            this.tableList = this.map.get(this.userSelectedLob.value);
            this.tableFinalList = this.tableList.map(val => {
                this.viewMap.set(val.tableName, val.viewName);
                return { label: val.displayName, value: val.tableName }
            });
        }
    }

    setHeaderPicklistTables() {
        this.sourceHeaderPicklist = "Available Factor Tables";
        this.targetHeaderPicklist = "Selected Factor Tables";
        this.sourcePlaceholder = "Search by table name";
        this.messages.errorMessageReqTable = "Please select the table";
    }

    ngOnInit() {
        this.targetList = [];
        this.setHeaderPicklistTables();
        this.map = this.commonService.getMapOfRoleAndTableNames();
        this.tableFinalList = [...this.tableFinalList]
    }

    addDisplayName(responseData) {
        for (var i = 0; i < responseData.length; i++) {
            responseData[i].displayName = responseData[i].tableName + " - Version " + responseData[i].versionText +
                " - " + responseData[i].quoteEffDate + " - " + responseData[i].factorEffDate;
        }
        return responseData;
    }

    isSelected: boolean = false;
    list = [];
    fillPicklistSource() {
        let selectedMap = new Map<string, string>();
        this.tableValue.forEach(element => {
            selectedMap.set(element, this.viewMap.get(element))
        });

        this.response = this.commonService.getRemoveTables(this.lobValue, this.stateValue, selectedMap).subscribe(res => {

            this.response = res.MED ? res.MED : [];
            this.list = this.response;

            if (this.list.length == 0) {
                this.isSelected = true;
            } else {
                this.isSelected = false;
            }
            this.sourceList = this.addDisplayName(this.list);

        }, error => {
            alert("Error in getting response from removeTables API...." + error);
        });

    }

    removeSuccessMsg() {
        this.isSelected = false;
    }

    onSubmit(event) {
        (this.userSelectedLob == undefined) ? (this.showLobError = true) : (this.showLobError = false);
        (this.userSelectedState == undefined) ? (this.showStateError = true) : (this.showStateError = false);
        (this.userSelectedVersion == undefined) ? (this.showVersionError = true) : (this.showVersionError = false);
        (this.targetList.length == 0) ? (this.showTableError = true) : (this.showTableError = false);

        if (this.showTableError) {
            this.messages.errorMessageReqTable = "Please select the table"
        }

        if (this.stateValue && !this.showTableError) {
            let jsonobj = {
                "deleteVersionDetails": this.targetList, "cacheRefresh": "true",
                "state": (this.stateValue) ? this.stateValue : ""
            };

            this.loadingOverlayFlag = true;
            this.commonService.submitRemoveTables(this.lobValue, jsonobj).subscribe(response => {
                if (response != null) {
                    this.parseHttpResponse(response);
                    if (this.checkSuccessResponse(response)) {
                        this.reset(event);
                        this.fillPicklistSource();
                        this.isWarningDisabled=false;
                    }
                }
                else {
                    alert('Error in getting response for Remove ');
                }
            },
                error => {
                    alert('Error in getting response for Remove ');
                });

        }
    }

    checkSuccessResponse(data) {
        let flag = false;
        for (var item of data) {
            if (item['factorTableVersionDetails'] && item['status'] === 'success') {
                flag = true;
            }
        }
        return flag;
    }

    parseHttpResponse(data) {
        this.flagStatus = true;
        this.failedTables = [];
        for (var item of data) {
            if (item['factorTableVersionDetails'] && item['status'] === 'FAILURE') {
                this.flagStatus = false;
                var displayName = item['factorTableVersionDetails'].tableName + " - Version " + item['factorTableVersionDetails'].versionText +
                    " - " + item['factorTableVersionDetails'].quoteEffDate + " - " + item['factorTableVersionDetails'].factorEffDate;
                var errorItem = {
                    displayName: displayName,
                    errorText: item.errorDetails
                }
                this.failedTables.push(errorItem);
            }
            else {
                if (item['status'] === 'FAILURE') {
                    this.cacheRefreshStatus = true;
                }
            }
        }

        if (this.flagStatus) {
            this.messageService.add({ key: 'success', severity: 'success', life: 1000000 });
        }
        else {
            this.displayDialog = true;
            this.messageService.add({ key: 'error', severity: 'error', life: 1000000 });
        }
    }

    reset(event: PickList) {
        this.resetLobData();
        this.resetStateData();

        if (this.showLobDropdown) {
            this.sourceList = [];
        }

        this.showTableError = false;
        this.showVersionError = false;
        this.showLobError = false;
        this.showStateError = false;
        this.userSelectedTable=false;
        this.setHeaderPicklistTables();
        event.resetFilter();
        event.moveAllLeft();
        this.isSelected = false;
    }

    resetLobData() {
        this.lobValue = undefined;
        this.userSelectedLob = undefined;
        this.lobLabel = undefined;

        if (this.lobList.length == 1) {
            this.lobValue = this.lobList[0].value;
            this.lobLabel = this.lobList[0].label;
        }

        if (this.lobList.length > 1) {
            this.showLobDropdown = true;
        }
    }

    resetStateData() {
        this.stateValue = undefined;
        this.userSelectedState = undefined;
        this.showTablesDropdown = false;
        this.userSelectedTable = '';

        if (this.stateList.length === 1 && String(this.authenticationService.getUserState()).indexOf('WI') === -1) {
            this.stateValue = this.authenticationService.getUserState();
        }

        if (this.lobValue === 'MED') {
            if (this.stateList.length > 1 || String(this.authenticationService.getUserState()).indexOf('WI') > -1) {
                this.showStateDropdown = true;
                this.showStateSingleValue = false;
                this.pushDerivedStateByUserGroup();
            } else if (this.stateList.length === 1) {
                this.showStateDropdown = false;
                this.showStateSingleValue = true;
            }
        } else {
            this.showStateSingleValue = false;
            this.showStateDropdown = false;
        }
    }
    pushDerivedStateByUserGroup() {
        const stateSplitArr = String(this.authenticationService.getUserState()).indexOf(',') > -1 ? String(this.authenticationService.getUserState()).split(',') : null;
        let stateArray = false;
        if (stateSplitArr) {
            stateSplitArr.forEach(element => {
                if (['ALL', 'WI'].indexOf(String(element)) !== -1)
                    return stateArray = true;
            });
        } else
            stateArray = ['ALL', 'WI'].indexOf(String(this.authenticationService.getUserState())) !== -1;
        const bool = this.stateList.findIndex(element => element.value == 'WC') === -1;
        if (stateArray && bool) {
            this.stateList.push({ "label": "WC", "value": "WC" });
        }
        this.stateList = [...this.stateList];
    }

    moveToTarget(event) {
        if (this.showTableError) {
            this.showTableError = false;
        }
        this.eventTest = event;
        this.targetList.sort((a, b) => a.tableName.localeCompare(b.tableName) || b.versionText - a.versionText);
    }

    moveToSource(event) {
        this.sourceList.sort((a, b) => a.tableName.localeCompare(b.tableName) || b.versionText - a.versionText);
    }

    lobChanged() {
        this.lobValue = this.userSelectedLob.value;
        this.setTableList(this.lobValue);
        this.resetStateData();

        if (this.lobValue == undefined) {
            this.showLobError = true;
        } else {
            this.showLobError = false;
        }

        if (this.eventTest) {
            this.eventTest.moveAllLeft();
        }
        this.showStateError = false;
        this.showTableError = false;
        this.sourceList = [];
        this.targetList = [];

        this.setHeaderPicklistTables();
    }

    stateChanged() {
        if (this.eventTest) {
            this.eventTest.moveAllLeft();
        }
        this.showTableError = false;
        this.stateValue = this.userSelectedState.value;
        this.showTablesDropdown = true;
        this.userSelectedTable=false;
        this.showStateError = false;
    }

    tableChanged() {
        this.tableValue = this.userSelectedTable.map(function (i) {
            return i.value;
        });
        this.disableSubmitBtn();
    }

    getVersions() {
        this.fillPicklistSource();
    }

    ngOnDestroy() {
        if (this.eventTest != undefined) {
            this.eventTest.moveAllLeft();
            this.sourceList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
        }
    }

    disableSubmitBtn() {
        if (this.userSelectedTable) {
            this.disableSubmit = true;
        }

    }

    hasReadOnly() {
        return this.commonService.hasReadOnlyRole();
    }

}
