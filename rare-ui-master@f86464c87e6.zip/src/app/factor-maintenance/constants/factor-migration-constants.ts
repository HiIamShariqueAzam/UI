export class FactorMigrationConstants {
  public static AVAILABLE_ENVIRONMENTS = [
    { name: 'LOCAL', code: 'LOCAL' },
    { name: 'LOCAL2', code: 'LOCAL2' }
  ];
  public static SYSTEMS = [
    { label: 'RARE', value: 'RARE' },
    { label: 'ERE', value: 'ERE' },
    { label: 'SRQ', value: 'SRQ' }
  ];
  public static ROWS_PER_PAGE = [
    { label: '10', value: 10 },
    { label: '20', value: 20 },
    { label: '30', value: 30 }
  ];
  public static MIGRATION_TYPES = [
    { label: 'Full', value: 'full' },
    { label: 'Partial', value: 'partial' },
    { label: 'Remove', value: 'remove' }
  ];
  public static HEADER_COLUMNS = [
    {
      header: 'Executed By',
      field: 'ExecutedBy'
    },
    {
      header: 'Executed Date & Time',
      field: 'ExecutedDate'
    },
    {
      header: 'Target Databases',
      field: 'TargetEnvironments'
    },
    {
      header: 'Migration Status',
      field: 'MigratedStatus'
    }
  ];


  public static HEADER_COLUMNS_BULK_IMPORT = [
      {
        header: 'Executed By',
        field: 'ExecutedBy'
      },
      {
        header: 'Executed Date',
        field: 'ExecutedDate'
      },
      {
        header: 'Target Databases',
        field: 'TargetEnvironments'
      },
    {
      header: 'Source Databases',
      field: 'SourceEnvironments'
    },
      {
        header: 'Migration Status',
        field: 'MigratedStatus'
      }
    ];

  public static MULTI_SORT_META = [
    {
      field: 'MigrationName',
      order: 1
    },
    {
      field: 'Created By',
      order: 1
    },
    {
      field: 'Created Date',
      order: 1
    },
    {
      field: 'System',
      order: 1
    },
    {
      field: 'Status',
      order: 1
    },
    {
      field: 'Source Environment',
      order: 1
    },
    {
      field: 'Target Environments',
      order: 1
    }
  ];

  public static LOB_ALL = 'ALL';
  public static BMS_SYSTEM = 'BMS';
  public static ERE = 'ERE';
  public static COMIX_SYSTEM = 'COMIX';
  public static ERE_EKS_SYSTEM = 'ERE_EKS';
  public static RARE_FACTOR_TABLE = 'RARE_FACTOR_TABLE_';
  public static RARE = 'RARE';
  public static LOB_MED = 'MED';
  public static MEDICAL_ACTUARIAL = 'RARE_ACTUARIAL_MEDICAL';
  public static FACTOR_EXECUTION_STATUSES = [
    { key: 'cacheRefreshStatus', label: 'Cache Refresh' },
    { key: 'deletedBackupStatus', label: 'Deleted Backup' }
  ]
}
