import { NgModule } from '@angular/core';
import { ExportFactorsComponent } from "./export-factors.component";
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { SharedModule } from 'src/app/shared/shared.module';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';

@NgModule({
    declarations: [
        ExportFactorsComponent
    ],
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule, ButtonModule, ProgressSpinnerModule,
        PickListModule, FlexLayoutModule, SharedModule, DatePickerModule, SelectModule, RouterModule.forChild([
            { path: '', component: ExportFactorsComponent, pathMatch: 'full' }
        ])
    ],
    exports: [
        ExportFactorsComponent
    ],
    providers: []
})
export class ExportFactorsModule {
}
