import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';
import { ExportFactorsComponent } from './export-factors.component';
import { DropdownModule, PickList } from 'primeng/primeng';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, ElementRef } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { CommonService, AuthenticationService } from 'src/app/shared/services';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { OidcSecurityService, AuthModule } from 'angular-auth-oidc-client';
import { Observable, throwError } from 'rxjs';
import { By } from '@angular/platform-browser';
import { mockLobListAll, mockLobList, targetList, response, response1, lobList, lobList1, stateList, stateList1, sortedList, sourceList, targetList1, sourceList1, unsortedList1, sortedList1 }
    from '../import-factors/import-factors.mock';

describe('ExportFactorsComponent', () => {
    let component: ExportFactorsComponent;
    let fixture: ComponentFixture<ExportFactorsComponent>;
    let commonService: CommonService;
    let authenticationService: AuthenticationService;
    let pickList: PickList;
    var exprtButton;
    var picklistEl;
    var resetButton;
    let picklistelement: ElementRef;
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ExportFactorsComponent],
            imports: [
                DropdownModule,
                AuthModule.forRoot()
            ],
            providers: [provideHttpClient(), MessageService, {
                provide: Router,
                useClass: class { navigate = jasmine.createSpy("navigate"); },
                OidcSecurityService
            }
            ],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExportFactorsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        commonService = TestBed.get(CommonService);
        authenticationService = TestBed.get(AuthenticationService);
        exprtButton = fixture.debugElement.query(By.css('#submit_export'));
        picklistEl = fixture.debugElement.query(By.css('#picklistId_export'));
        resetButton = fixture.debugElement.query(By.css('#reset_export'));
        pickList = new PickList(picklistelement);
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    it("should call the constructor and emit user role", () => {
        component = new ExportFactorsComponent(commonService, authenticationService);
        component.userSelectedLob = false;
        expect(component.userSelectedVersion).toEqual(component.versionArray[0]);
    });

    it("should call #ngOnInit", () => {
        spyOn(component, 'setHeaderPicklistTables');
        component.ngOnInit();
        expect(component.setHeaderPicklistTables).toHaveBeenCalled();

        spyOn(component, 'setHeaderPicklistStates');
        component.lobValue = "VIS";
        component.ngOnInit();
        expect(component.setHeaderPicklistStates).toHaveBeenCalled();

        spyOn(component, 'fillPicklistSource');
        component.ngOnInit();
        expect(component.fillPicklistSource).toHaveBeenCalled();

    });

    it("should call setHeaderPicklistTables", () => {
        expect(component.sourceHeaderPicklist).toEqual("Available Factor Tables");
        expect(component.targetHeaderPicklist).toEqual("Selected Factor Tables");
        expect(component.sourcePlaceholder).toEqual("Search by table name");
    });

    it("should call setHeaderPicklistStates", () => {
        component.lobValue = "VIS";
        component.setHeaderPicklistStates();
        expect(component.sourceHeaderPicklist).toEqual("Available States");
        expect(component.targetHeaderPicklist).toEqual("Selected States");
        expect(component.sourcePlaceholder).toEqual("Search by State");
    });

    it("should define fillPicklistSource and must call #getLobList in the constructor", () => {
        component.fillPicklistSource();
        component.lobList = mockLobListAll;
        expect(component.lobList.toString()).toContain(mockLobList.toString());
    });

    it('should export the form', () => {
        let userRole: Observable<any>;
        component.div_visible = true;
        spyOn(commonService, 'downloadData').and.returnValue(userRole);
        component.lobValue = "ADMIN";
        component.jsonobj = { "tables": targetList, "cacheRefresh": "true", "numberOfVersions": "2" };
        component.targetList = targetList;
        component.showVersionError = false;
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(commonService.downloadData).toHaveBeenCalled();
    });

    it('should check the error condition export the form', () => {
        component.jsonobj = { "tables": targetList, "cacheRefresh": "true", "numberOfVersions": "2" };
        component.targetList = targetList;
        component.lobValue = "DEN";
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.lobValue).toEqual("DEN");
    });

    it('should check the error condition export the form', () => {
        component.jsonobj = { "tables": targetList, "cacheRefresh": "true", "numberOfVersions": "2" };
        component.targetList = targetList;
        component.lobValue = "DEN";
        component.userSelectedState = { value: "CA" };
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.showStateError).toBe(false);
    });

    it('should check the error condition export the form', () => {
        component.div_visible = true;
        spyOn(commonService, 'downloadData').and.returnValue(throwError("Error"));
        component.lobValue = "ADMIN";
        component.jsonobj = { "tables": targetList, "cacheRefresh": "true", "numberOfVersions": "2" };
        component.targetList = targetList;
        component.showVersionError = false;
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(commonService.downloadData).toHaveBeenCalled();
        expect(component.div_visible).toEqual(false);
    });

    it('should create the Picklist', () => {
        fixture.detectChanges();
        expect(picklistEl).toBeTruthy();
    });

    it('should reset the Picklist', () => {
        spyOn(component, 'setHeaderPicklistTables');
        component.showTableError = true;
        component.sourceList = sourceList;
        expect(pickList).toBeDefined();
        resetButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.showTableError).toEqual(false);
        expect(component.showVersionError).toEqual(false);
        expect(component.userSelectedVersion.value).toEqual("1");
        expect(component.userSelectedLob).toBeUndefined();/*
        expect(component.sourceList.length).toEqual(0); */
        expect(component.setHeaderPicklistTables).toHaveBeenCalled();
    });
    it('should enter resetLobdata', () => {
        component.lobList = lobList;
        component.resetLobData();
        expect(component.lobValue).toEqual("DEN");
    });

    it('should enter resetLobdata if loblist > 1', () => {

        component.lobList = lobList1;
        component.resetLobData();
        expect(component.showLobDropdown).toEqual(true);
    });
    it('should define stateChanged', () => {
        component.userSelectedState = { value: "CA" };
        component.showStateError = true;
        component.stateChanged();
        fixture.detectChanges();
        expect(component.stateValue).toEqual("CA");
        expect(component.showStateError).toEqual(false);
    });
    it('should enter resetStatedata', () => {
        component.stateValue = "CA";
        component.userSelectedState = "CA";
        component.lobValue = "MED";
        component.showStateDropdown = true;
        component.showStateSingleValue = false;
        component.resetStateData();
        expect(component.stateValue).toBe(undefined);

        expect(component.userSelectedState).toBe(undefined);


        component.stateList = stateList;
        component.resetStateData();
        expect(component.stateValue).toEqual("CA");
        expect(component.showStateDropdown).toEqual(false);
        expect(component.showStateSingleValue).toEqual(true);

        component.stateList = stateList1;
        component.resetStateData();
        expect(component.showStateDropdown).toEqual(true);
        expect(component.showStateSingleValue).toEqual(false);

        component.lobValue = "DEN";
        component.resetStateData();
        expect(component.showStateDropdown).toEqual(false);
        expect(component.showStateSingleValue).toEqual(false);

    });

    it('should call moveToTarget', () => {
        component.showTableError = true;
        component.targetList = unsortedList1;
        component.moveToTarget(pickList);
        expect(component.showTableError).toEqual(false);
        expect(component.eventTest).toEqual(pickList);
        expect(component.targetList).toEqual(sortedList);

        component.targetList = sortedList1;
        component.moveToTarget(pickList);
        expect(component.targetList).toEqual(sortedList);

    });

    it('should call moveToSource', () => {
        component.sourceList = sourceList;
        component.moveToSource(pickList);
        expect(component.sourceList).toEqual(sortedList);

        component.sourceList = targetList;
        component.moveToSource(pickList);
        expect(component.sourceList).toEqual(sortedList);

    });

    it('should define lobChanged', () => {
        spyOn(component, 'setHeaderPicklistTables');
        component.userSelectedLob = { value: "DEN" };
        component.lobChanged();
        fixture.detectChanges();
        expect(component.setHeaderPicklistTables).toHaveBeenCalled();

        spyOn(component, 'setHeaderPicklistTables');
        component.userSelectedLob = { value: "VIS" };
        component.lobChanged();
        fixture.detectChanges();
        expect(component.setHeaderPicklistTables).toHaveBeenCalled();
        expect(component.messages.errorMessageReqTable).toEqual("Please select the table");
    });

    it('should define versionChanged', () => {
        component.showVersionError = true;
        component.versionChanged();
        fixture.detectChanges();
        expect(component.showVersionError).toEqual(false);

        component.userSelectedVersion = undefined;
        component.showVersionError = true;
        component.versionChanged();
        fixture.detectChanges();
        expect(component.showVersionError).toEqual(true);
    });

    it('should set the error text on click of Export form', () => {
        component.showTableError = true;
        component.userSelectedVersion = undefined;
        component.showVersionError = false;
        component.lobValue = "VIS";

        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.messages.errorMessageReqTable).toEqual("Please select the table");
        expect(component.showVersionError).toEqual(true);
        component.userSelectedLob = { value: "VIS" };
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.messages.errorMessageReqTable).toEqual("Please select the table");
    });

    it('should set the error text', () => {
        component.lobValue = "DEN";
        component.userSelectedLob = { value: "VIS" };
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.messages.errorMessageReqTable).not.toEqual("Please select the table");
    });

    it('should set the error text', () => {
        component.lobValue = "ADMIN";
        component.userSelectedLob = { value: "DEN" };
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.messages.errorMessageReqTable).not.toEqual("Please select the table");
    });

    it('should set the error text', () => {
        component.lobValue = "VIS";
        component.userSelectedLob = { value: "DEN" };
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.messages.errorMessageReqTable).toEqual("Please select the table");
    });

    it('should set the error text', () => {
        component.lobValue = "ADMIN";
        component.userSelectedLob = { value: "DEN" };
        exprtButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.messages.errorMessageReqTable).not.toEqual("Please select the table");
    });

    it("should call #ngOnDestroy", () => {
        component.eventTest = pickList;
        component.sourceList = sourceList1;

        component.ngOnDestroy();
        expect(component.sourceList).toEqual(sortedList);

        component.sourceList = targetList1;

        component.ngOnDestroy();
        expect(component.sourceList).toEqual(sortedList);
    });

});
