import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { CommonService, AuthenticationService, PrintExhibitService } from 'src/app/shared/services';
import { Subscription } from 'rxjs';
import { PickList } from 'primeng/picklist';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { TableNames } from 'src/app/shared/models';
import { DateFormatPipe } from 'src/app/shared/pipes/date-format-pipe';
declare global {
    interface Navigator {
        msSaveOrOpenBlob: (blob: Blob, filename: string) => void
    }
}

interface System {
  label: string,
  value: string
}

@Component({
    selector: 'app-export-factors',
    templateUrl: './export-factors.component.html',
    standalone: false,
})
export class ExportFactorsComponent implements OnInit, OnDestroy {
    private eventSources: EventSource[] = [];
    sourceHeaderPicklist: string;
    targetHeaderPicklist: string;
    sourcePlaceholder: string;
    showLobDropdown: boolean = false;
    showLobError: boolean = false;
    showStateError: boolean = false;
    sourceList: any[];
    targetList: any;
    lobList: any[] = [];
    stateList: any[] = [];
    map = new Map<string, string[]>();
    versionArray: any[] = [];
    showVersionDropdown: boolean = false;
    showTableError: boolean = false;
    showVersionError: boolean = false;
    showStateSingleValue: boolean = false;
    showStateDropdown: boolean = false;
    userSelectedLob: any;
    lobValue: any;
    lobLabel: any;
    jsonobj: any;
    userSelectedVersion: any;
    userSelectedState: any;
    stateValue: any;
    loadingOverlayFlag: boolean = false;
    private subscribeExportSubmit: Subscription;
    eventTest: PickList;
    div_visible: boolean = false;
    showQuoteEfftDate: boolean = false;
    showFactorEfftDate: boolean = false;
    quoteeffectivedate: Date;
    factoreffectivedate: Date;
    selcetedQuoteEffectiveDate: any;
    selcetedFactorEffectiveDate: any;
    showProgress: boolean = false;
    progressPercent: number = 0;
    progressMessage: any;
    progressStyle: String;
    processId: any;
    messages = {
        "errorMessageReqTable": "Please select the table",
        "errorMessageReqVersion": "Please select a version",
        "errorMessageLob": "Please select the LOB",
        "errorMessageState": "Please select the state"
    };

    private subscirbeUserRole: Subscription;
    systems: System[];
    userSelectedSystem: any;

    constructor(private commonService: CommonService, private dateFormatPipe: DateFormatPipe,
        private authenticationService: AuthenticationService, @Inject(SESSION_STORAGE) private storage: WebStorageService,private peService:PrintExhibitService) {

        this.lobList = this.commonService.getLobList();
        this.stateList = this.commonService.getStateList().slice(0);

        this.resetLobData();
        this.resetStateData();
        this.resetQuoteEffectiveDate();
        this.resetFactorEffectiveDate();
        this.resetVersionData();
    }

    setHeaderPicklistTables() {
        this.sourceHeaderPicklist = "Available Factor Tables";
        this.targetHeaderPicklist = "Selected Factor Tables";
        this.sourcePlaceholder = "Search by table name";
        this.messages.errorMessageReqTable = "Please select the table";
    }

    ngOnInit() {
        this.targetList = [];
        this.setHeaderPicklistTables();
        //Fill the source list of the pick list
        this.fillPicklistSource();
        this.resetQuoteEffectiveDate();
        this.resetFactorEffectiveDate();
        this.resetVersionData();
        this.systems = [
          { label: 'RARE', value: 'RARE' }
        ];
    }

    fillPicklistSource() {
        if (this.lobValue) {
            this.map = this.commonService.getMapOfRoleAndTableNames();
            let tableArray = this.map.get(this.lobValue);
            this.sourceList = <TableNames[]>tableArray;
        }
    }

    onSubmit(event) {
        (this.userSelectedLob == undefined) ? (this.showLobError = true) : (this.showLobError = false);
        (this.userSelectedState == undefined) ? (this.showStateError = true) : (this.showStateError = false);
        (this.userSelectedVersion == undefined) ? (this.showVersionError = true) : (this.showVersionError = false);


        (this.targetList.length == 0) ? (this.showTableError = true) : (this.showTableError = false);

        if (this.showTableError) {
            if (this.lobValue == "VIS") {
                this.messages.errorMessageReqTable = "Please select the table"
            }
        }

        //Integrating Export Service
        if (this.targetList.length > 1 && this.userSelectedVersion.value === "-1") {
            alert("Please make sure only one table is selected to export when 'All versions' option chosen");
            return;
        }

        if ((this.targetList.length > 0) && (!this.showVersionError)) {
            if (this.lobValue == "MED") {
                if (this.stateValue) {
                    this.jsonobj = {
                        "tables": this.targetList,
                        "cacheRefresh": "true",
                        "numberOfVersions": this.userSelectedVersion.value,
                        "quoteEffectiveDate": this.dateFormat(this.quoteeffectivedate),
                        "factorEffectiveDate": this.dateFormat(this.factoreffectivedate),
                        "state": (this.stateValue) ? this.stateValue : ""
                    };
                    this.loadingOverlayFlag = true;
                    this.commonService.downloadData(this.lobValue, this.jsonobj, this.authenticationService.getAppEnvironment()).subscribe(response => {
                        this.div_visible = false;
                        if (response.status === 200) {
                            this.processId = response.body.processId;
                            if (undefined != this.processId) {
                                this.showProgress = true;
                                this.progressPercent = 1;
                                this.progressStyle = "progress-bar-warning";
                                var source = this.commonService.listenForStream(this.processId);
                                this.eventSources.push(source);
                                source.addEventListener("FACTOR_EXPORT_GENERATION_STATUS", (event: any) => {
                                    this.progressStyle = "";
                                    let eventData = JSON.parse(event.data);
                                    var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
                                    this.progressPercent = percent;
                                    this.progressMessage = eventData.message;
                                });
                                source.addEventListener('FACTOR_EXPORT_GENERATION_STATUS_COMPLETE', (message: any) => {
                                    source.close();
                                    let eventData = JSON.parse(message.data);
                                    this.progressStyle = "progress-bar-success";
                                    this.progressPercent = 100;
                                    this.progressMessage = eventData.message;
                                    let contentData = eventData.payload.contentData;
                                    let fileName = this.commonService.getExportFilename();
                                    const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
                                    this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
                                    setTimeout( ()=>{
                                        this.showProgress = false;
                                        }, this.commonService.getProgressBarTimeOut());
                                });
                                source.addEventListener('FAILED', (message: any) => {
                                    source.close();
                                    let eventData = JSON.parse(message.data);
                                    console.error("Received event : ", JSON.stringify(message.data));
                                    this.progressPercent=90;
                                    this.progressStyle = "progress-bar-danger";
                                    this.progressMessage = "Error in getting response for Export";
                                });
                            }
                        }
                    }, error => {
                        console.error(error);
                        this.div_visible = false;
                        alert("Error in getting response for Export: " + error);
                    })
                }
                else {
                    this.loadingOverlayFlag = true;
                    this.div_visible = false;
                }
            }
            else {
                this.jsonobj = {
                    "tables": this.targetList, "cacheRefresh": "true", "numberOfVersions": this.userSelectedVersion.value,
                    "quoteEffectiveDate": this.dateFormat(this.quoteeffectivedate),
                    "factorEffectiveDate": this.dateFormat(this.factoreffectivedate)
                };

                this.loadingOverlayFlag = true;
                this.commonService.downloadData(this.lobValue, this.jsonobj, this.authenticationService.getAppEnvironment()).subscribe(response => {
                    this.div_visible = false;
                    if (response.status === 200) {
                        this.processId = response.body.processId;
                        if (undefined != this.processId) {
                            this.showProgress = true;
                            this.progressPercent = 1;
                            this.progressStyle = "progress-bar-warning";
                            var source = this.commonService.listenForStream(this.processId);
                            this.eventSources.push(source);
                            source.addEventListener("FACTOR_EXPORT_GENERATION_STATUS", (event: any) => {
                                this.progressStyle = "";
                                let eventData = JSON.parse(event.data);
                                var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
                                this.progressPercent = percent;
                                this.progressMessage = eventData.message;
                            });
                            source.addEventListener('FACTOR_EXPORT_GENERATION_STATUS_COMPLETE', (message: any) => {
                                source.close();
                                let eventData = JSON.parse(message.data);
                                this.progressStyle = "progress-bar-success";
                                this.progressPercent = 100;
                                this.progressMessage = eventData.message;
                                let contentData = eventData.payload.contentData;
                                let fileName = this.commonService.getExportFilename();
                                const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
                                this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
                                setTimeout( ()=>{
                                    this.showProgress = false;
                                    }, this.commonService.getProgressBarTimeOut());
                            });
                            source.addEventListener('FAILED', (message: any) => {
                                source.close();
                                let eventData = JSON.parse(message.data);
                                console.error("Received event : ", JSON.stringify(message.data));
                                this.progressPercent=90;
                                this.progressStyle = "progress-bar-danger";
                                this.progressMessage = "Error in getting response for Export";
                            });
                        }
                    }
                }, error => {
                    console.error(error);
                    this.div_visible = false;
                    alert("Error in getting response for Export: " + error);
                })
            }

        }
    }

    downloadFile(blob: any, type: string, filename: string) {

        var binaryData = [];
        binaryData.push(blob);

        /*Workaround for IE11 download issue*/
        // IE doesn't allow using a blob object directly as link href
        // instead it is necessary to use msSaveOrOpenBlob
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(new Blob(binaryData, { type: "" }), filename);
            return;
        }
        else {
            // create hidden dom element (so it works in all browsers)
            const url = window.URL.createObjectURL(new Blob(binaryData, { type: "" })); // <-- work with blob directly
            const a = document.createElement('a');
            a.setAttribute('style', 'display:none;');
            document.body.appendChild(a);

            // create file, attach to hidden element and open hidden element
            a.href = url;
            a.download = filename;
            a.click();
        }
    }

    reset(event: PickList) {
        this.resetLobData();
        this.resetStateData();
        this.resetQuoteEffectiveDate();
        this.resetFactorEffectiveDate();
        this.resetVersionData();
        if (this.showLobDropdown) {
            this.sourceList = [];
        }

        this.showTableError = false;
        this.showVersionError = false;
        this.showLobError = false;
        this.showStateError = false;
        this.setHeaderPicklistTables();
        event.resetFilter();
        event.moveAllLeft();
        this.showProgress = false;
    }

    resetLobData() {
        this.lobValue = undefined;
        this.userSelectedLob = undefined;
        this.lobLabel = undefined;

        if (this.lobList.length == 1) {
            this.lobValue = this.lobList[0].value;
            this.lobLabel = this.lobList[0].label;
        }

        if (this.lobList.length > 1) {
            this.showLobDropdown = true;
        }
    }

    resetStateData() {
        this.stateValue = undefined;
        this.userSelectedState = undefined;

        if (this.stateList.length === 1 && String(this.authenticationService.getUserState()).indexOf('WI') === -1) {
            this.stateValue = this.authenticationService.getUserState();
        }

        if (this.lobValue === 'MED') {
            if (this.stateList.length > 1 || String(this.authenticationService.getUserState()).indexOf('WI') > -1) {
                this.showStateDropdown = true;
                this.showStateSingleValue = false;
                this.pushDerivedStateByUserGroup();
            } else if (this.stateList.length === 1) {
                this.showStateDropdown = false;
                this.showStateSingleValue = true;
            }
        } else {
            this.showStateSingleValue = false;
            this.showStateDropdown = false;
        }
    }
    pushDerivedStateByUserGroup() {
        const stateSplitArr = String(this.authenticationService.getUserState()).indexOf(',') > -1 ? String(this.authenticationService.getUserState()).split(',') : null;
        let stateArray = false;
        if (stateSplitArr) {
            stateSplitArr.forEach(element => {
                if (['ALL', 'WI'].indexOf(String(element)) !== -1)
                    return stateArray = true;
            });
        } else
            stateArray = ['ALL', 'WI'].indexOf(String(this.authenticationService.getUserState())) !== -1;
        const bool = this.stateList.findIndex(element => element.value == 'WC') === -1;
        if (stateArray && bool) {
            this.stateList.push({ "label": "WC", "value": "WC" });
        }
        this.stateList = [...this.stateList];
    }
    resetVersionData() {
        if (this.lobValue) {
            if (this.lobValue == "VIS") {
                this.versionArray = [
                    {
                        label: "Last Version",
                        value: "1"
                    }
                ];
            } else {
                this.versionArray = [
                    {
                        label: "Last Version",
                        value: "1"
                    },
                    {
                        label: "Last 2 Versions",
                        value: "2"
                    },
                    {
                        label: "Last 3 Versions",
                        value: "3"
                    },
                    {
                        label: "Last 4 Versions",
                        value: "4"
                    },
                    {
                        label: "Last 5 Versions",
                        value: "5"
                    }
                ];
            }
            if(this.lobValue == "VIS" || this.lobValue == "MED"){
                let allVersion = {
                    label: "All Versions",
                    value: "-1"
                };
                this.versionArray.push(allVersion)
            }
            this.userSelectedVersion = this.versionArray[0];
            this.showVersionDropdown = true;
            this.showVersionError = false;
        } else {
            this.versionArray = [];
            this.showVersionDropdown = false;
            this.showVersionError = true;
        }
    }

    moveToTarget(event) {
        if (this.showTableError) {
            this.showTableError = false;
        }
        this.eventTest = event;
        this.targetList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
    }

    moveToSource(event) {
        this.sourceList = [...event.source];
        this.sourceList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
    }

    /*On Dropdown changed*/
    lobChanged() {
        this.lobValue = this.userSelectedLob.value;
        this.resetStateData();
        this.resetQuoteEffectiveDate();
        this.resetFactorEffectiveDate();
        this.resetVersionData();

        if (this.lobValue == undefined) {
            this.showLobError = true;
        } else {
            this.showLobError = false;
        }

        if (this.eventTest) {
            this.eventTest.moveAllLeft();
        }
        this.showStateError = false;
        this.showTableError = false;

        this.targetList = [];
        this.map = this.commonService.getMapOfRoleAndTableNames();

        let tableArray = this.map.get(this.lobValue);

        this.sourceList = JSON.parse(JSON.stringify(<TableNames[]>tableArray));

        this.setHeaderPicklistTables();
    }

    stateChanged() {
        this.stateValue = this.userSelectedState.value;
        this.showStateError = false;
        this.quoteeffectivedate = null;
        this.factoreffectivedate = null;
    }

    versionChanged() {
        if (this.userSelectedVersion != undefined) {
            this.showVersionError = false;
        }
    }


    ngOnDestroy() {
        if (this.eventTest != undefined) {
            this.eventTest.moveAllLeft();
            this.sourceList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
        }
        this.eventSources.forEach(source => source.close());
    }

    resetQuoteEffectiveDate() {
        this.quoteeffectivedate = undefined;
        this.selcetedQuoteEffectiveDate = undefined;
        if (this.lobValue && this.lobValue !== "VIS") {

            this.quoteeffectivedate = this.selcetedQuoteEffectiveDate;
            this.showQuoteEfftDate = true;
        } else {
            this.showQuoteEfftDate = false;
            this.quoteeffectivedate = null;
        }
    }

    resetFactorEffectiveDate() {
        this.factoreffectivedate = undefined;
        this.selcetedFactorEffectiveDate = undefined;
        if (this.lobValue &&
            (this.lobValue === "MED" || this.lobValue === "DEN")) {
            this.factoreffectivedate = this.selcetedFactorEffectiveDate;
            this.showFactorEfftDate = true;

        } else {
            this.showFactorEfftDate = false;
            this.factoreffectivedate = null;
        }
    }

    focusQuoteEffectiveDateEle() {
      if(this.selcetedQuoteEffectiveDate){
        this.selcetedQuoteEffectiveDate.focus();
      }
    }

    clickedQuoteEffectiveDate() {
        let element: HTMLElement = document.querySelectorAll('.quoteeffectivedate .p-inputtext')[0] as HTMLElement;
        this.selcetedQuoteEffectiveDate = element;
        element.click();
    }

    focusFactorEffectiveDateEle() {
      if( this.selcetedFactorEffectiveDate){
        this.selcetedFactorEffectiveDate.focus();
      }
    }

    clickedFactorEffectiveDate() {
        let element: HTMLElement = document.querySelectorAll('.factoreffectivedate .p-inputtext')[0] as HTMLElement;
        this.selcetedFactorEffectiveDate = element;
        element.click();
    }

    dateFormat(date) {
        if (date != null) {
            return this.dateFormatPipe.transform(date, "dd-MMM-yyyy")
        } else {
            return null;
        }
    }
}
