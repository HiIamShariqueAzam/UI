import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { MessageService } from 'primeng/api';
import { FileUpload } from 'primeng/fileupload';
import { PickList } from 'primeng/picklist';
import { Observable, Subscription } from 'rxjs';
import { ErrorDetails, TableNames } from 'src/app/shared/models';

@Component({
    selector: 'app-import-factors',
    templateUrl: './import-factors.component.html',
    styleUrls:['./import-factors.component.css'],
    standalone: false,
})
export class ImportFactorsComponent implements OnInit, OnDestroy {
    private eventSources: EventSource[] = [];
    @ViewChild('myInput') myInputVariable: FileUpload;

    sourceList: any[];
    targetList: any[];
    file: File;
    imageFile:File[];
    jsonobj: any;
    showFileError: boolean = false;
    showTableError: boolean = false;
    showLobDropdown: boolean = false;
    showStateSingleValue: boolean = false;
    showStateDropdown: boolean = false;
    showdrop = false;
    showLobError: boolean = false;
    showStateError: boolean = false;
    failedTables: any[] = [];
    userSelectedLob: any;
    lobValue: any;
    lobLabel: any;
    userSelectedState: any;
    stateValue: any;
    lobList: any[] = [];
    stateList: any[] = [];
    map = new Map<string, string[]>();
    sourceHeaderPicklist: string;
    targetHeaderPicklist: string;
    sourcePlaceholder: string;
    public _subscription_user_role$: Observable<string>;
    private subscribeImportSubmit: Subscription;
    eventTest: PickList;
    div_visible: boolean = false;
    title = 'Click here to select a file';
    showProgress: boolean = false;
    progressPercent: number = 0;
    progressMessage: any;
    progressStyle: String;
    processId: any;
    displayDialog: boolean;
    readonly messages = {
        errorMessage: `The following sheet(s) encountered error during import. \
            Please correct and re-import.  Other sheets were successfully imported.`,
        successMessage: 'All selected sheets were imported successfully !!!',
        errorMessageReqTable: 'Please select the table',
        errorMessageLob: 'Please select the LOB',
        errorMessageState: 'Please select the table'
    };
    constructor(private commonService: CommonService, private messageService: MessageService,
        private authenticationService: AuthenticationService) {
        this.lobList = this.commonService.getLobList();
        this.stateList = this.commonService.getStateList().slice(0);
        this.resetLobData();
        this.resetStateData();
    }
    ngAfterViewInit() {
        var eles = document.getElementsByClassName('ui-fileupload-choose');
        if (eles[0] != undefined)
            eles[0].setAttribute('title', 'Click here to select a file');
    }

    setHeaderPicklistTables() {
        this.sourceHeaderPicklist = 'Available Factor Tables';
        this.targetHeaderPicklist = 'Selected Factor Tables';
        this.sourcePlaceholder = 'Search by table name';
    }

    ngOnInit() {
        this.targetList = [];
        this.setHeaderPicklistTables();
        //Fill the source list of the pick list
        this.fillPicklistSource();
    }
    fillPicklistSource() {
        if (this.lobValue) {
            this.map = this.commonService.getMapOfRoleAndTableNames();
            let tableArray = this.map.get(this.lobValue);
            this.sourceList = <TableNames[]>tableArray;
        }
    }

    /*Event called on Uploading*/
    fileName:string="Please select file"
    myUploader(event) {
        this.file = undefined;
        this.file = event.files[0];
        this.showFileError = false;
        this.fileName=event.files[0].name;
    }
    imageFileName:string="Please select image"
    myUploaderImage(event) {
        this.imageFile = undefined;
        this.imageFile=event.files;
        this.imageFileName=undefined
    }

    /*On Submitting the Form**/
    onSubmit(event) {
        (!this.file) ? (this.showFileError = true) : (this.showFileError = false);
        (!this.userSelectedLob) ? (this.showLobError = true) : (this.showLobError = false);
        (!this.userSelectedState && this.lobValue === 'MED') ? (this.showStateError = true) : (this.showStateError = false);
        (!this.targetList.length) ? (this.showTableError = true) : (this.showTableError = false);

        if (this.lobValue === 'MED') {
            this.jsonobj = { 'tables': this.targetList, 'cacheRefresh': 'true', 'state': (this.stateValue) ? this.stateValue : '' };
        }
        else {
            this.jsonobj = { 'tables': this.targetList, 'cacheRefresh': 'true' };
        }

        if ((this.file) && (this.targetList.length > 0)) {
            this.subscribeImportSubmit =
                this.commonService.submitImportFactorTables(this.lobValue, this.jsonobj, this.file,this.imageFile).subscribe(response => {
                    this.div_visible = false;
                    this.messageService.clear();
                    if (response.status === 200) {
                        this.processId = response.body.processId;
                        if (undefined != this.processId) {
                            this.showProgress = true;
                            this.progressPercent = 1;
                            this.progressStyle = "progress-bar-warning";
                            var source = this.commonService.listenForStream(this.processId);
                            this.eventSources.push(source);
                            source.addEventListener("FACTOR_IMPORT_GENERATION_STATUS", (event: any) => {
                                this.progressStyle = "";
                                let eventData = JSON.parse(event.data);
                                var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
                                this.progressPercent = percent;
                                this.progressMessage = eventData.message;
                            });
                            source.addEventListener('FACTOR_IMPORT_GENERATION_STATUS_COMPLETE', (message: any) => {
                                source.close();
                                let eventData = JSON.parse(message.data);
                                this.progressStyle = "progress-bar-success";
                                this.progressPercent = 100;
                                this.progressMessage = eventData.message;
                                this.parseHttpResponse(eventData.payload.dataLoadStatus, event);
                                setTimeout( ()=>{
                                    this.showProgress = false;
                                    }, this.commonService.getProgressBarTimeOut());
                            });
                            source.addEventListener('FAILED', (message: any) => {
                                source.close();
                                let eventData = JSON.parse(message.data);
                                console.error("Received event : ", JSON.stringify(message.data));
                                this.progressPercent=90;
                                this.progressStyle = "progress-bar-danger";
                                this.progressMessage = "Error in getting response for Import";
                                this.parseHttpResponse(eventData.payload.dataLoadStatus, event);
                            });
                        }
                    }
                }, error => {
                    this.div_visible = false;
                    alert('Error in getting response for Import: ' );
                    console.error(error);
                })
                ;

    }
}

    /*On Resetting the Form*/
    reset(event: PickList) {
        this.resetLobData();
        this.resetStateData();
        if (this.showLobDropdown) {
            this.sourceList = [];
        }
        this.file = undefined;
        this.myInputVariable.clear();
        this.showFileError = false;
        this.showTableError = false;
        this.showLobError = false;
        this.showStateError = false;
        this.setHeaderPicklistTables();
        this.showProgress=false;
        event.resetFilter();
        event.moveAllLeft();
        this.showupload=false;
        this.imageFile=undefined;
        this.showProgress = false;
    }

    resetLobData() {
        this.lobValue = undefined;
        this.lobLabel = undefined;
        this.userSelectedLob = undefined;

        if (this.lobList.length === 1) {
            this.lobValue = this.lobList[0].value;
            this.lobLabel = this.lobList[0].label;
        }

        if (this.lobList.length > 1) {
            this.showLobDropdown = true;
        }
    }

    resetStateData() {
        this.stateValue = undefined;
        this.userSelectedState = undefined;

        if (this.stateList.length === 1 && String(this.authenticationService.getUserState()).indexOf('WI') === -1) {
            this.stateValue = this.authenticationService.getUserState();
        }

        if (this.lobValue === 'MED') {
            if (this.stateList.length > 1 || String(this.authenticationService.getUserState()).indexOf('WI') > -1) {
                this.showStateDropdown = true;
                this.showStateSingleValue = false;
                this.pushDerivedStateByUserGroup();
            } else if (this.stateList.length === 1) {
                this.showStateDropdown = false;
                this.showStateSingleValue = true;
            }
        } else {
            this.showStateSingleValue = false;
            this.showStateDropdown = false;
        }
    }
    pushDerivedStateByUserGroup() {
        const stateSplitArr = String(this.authenticationService.getUserState()).indexOf(',') > -1 ? String(this.authenticationService.getUserState()).split(',')  : null;
        let stateArray = false;
        if(stateSplitArr) {
             stateSplitArr.forEach(element =>{
              if (['ALL','WI'].indexOf(String(element)) !== -1)
                    return stateArray =true;
            });
        } else
        stateArray = ['ALL','WI'].indexOf(String(this.authenticationService.getUserState())) !== -1;
        const bool = this.stateList.findIndex(element => element.value =='WC') === -1;
        if(stateArray && bool){
            this.stateList.push({ "label": "WC", "value": "WC" });
        }
        this.stateList = [...this.stateList];
    }
    showupload=false
    moveToTarget(event) {
        if (this.showTableError) {
            this.showTableError = false;
        }
        this.eventTest = event;
        this.targetList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
        this.targetList.forEach(x => {
            if (x.displayName.indexOf("REF_TBL_PE_SIGNORS") >= 0||x.displayName.indexOf("REF_TYPE_TO_BLOB_MAP") >= 0)
                this.showupload = true;

        })
    }

    moveToSource(event) {
        this.sourceList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
        this.sourceList.forEach(x => {
            if (x.displayName.indexOf("REF_TBL_PE_SIGNORS") >= 0||x.displayName.indexOf("REF_TYPE_TO_BLOB_MAP") >= 0)
                this.showupload = false;
        })
    }

    parseHttpResponse(data, event) {
        let flagStatus: boolean = true;
        this.failedTables = [];
        for (var item of data) {
            if (item['status'] === 'failed') {
                var tableName = item['sheetName'];
                flagStatus = false;
                var errorDetails = item['errors'];

                /*showing only the first element in the error array list */
                let errorFirst = errorDetails[0];
                var rowNumber = errorFirst.rowNumber === null || errorFirst.rowNumber === 0 ? '' : 'in Row '+errorFirst.rowNumber;
                var columnName = (errorFirst.columnName===undefined || errorFirst.columnName === null || errorFirst.columnName === 'NA') ? '' : 'with ' + errorFirst.columnName + ' Column, ';
                var errorItem: ErrorDetails = {
                    tableName: tableName,
                    rowNumber: rowNumber,
                    columnName: columnName,
                    errorText: errorFirst.columnName === null ? 'Error Message: ' + errorFirst.errorMessage :
                        'An error was encountered ' + columnName +
                        rowNumber + ' in ' + tableName + ' Sheet. ' + '[Error Message: ' + errorFirst.errorMessage + '].'
                }
                this.failedTables.push(errorItem);
            }
        }

        /*Resetting the form after successfull Import*/
        if (flagStatus) {
        }
        else {
            this.displayDialog = true;
            this.messageService.add({ key: 'error', severity: 'error', life: 1000000 });
        }
    }

    /*On Dropdown changed*/
    lobChanged() {
        this.lobValue = this.userSelectedLob.value;
        this.resetStateData();

        if (this.lobValue === undefined) {
            this.showLobError = true;
        } else {
            this.showLobError = false;
        }

        if (this.eventTest) {
            this.eventTest.moveAllLeft();
        }

        this.showTableError = false;
        this.targetList = [];
        this.map = this.commonService.getMapOfRoleAndTableNames();
        let tableArray = this.map.get(this.lobValue);
        this.sourceList = JSON.parse(JSON.stringify(<TableNames[]>tableArray));
        this.setHeaderPicklistTables();
    }

    stateChanged() {
        this.stateValue = this.userSelectedState.value;
        this.showStateError = false;
    }

    /*Close button of a file in fileupload*/
    removeFile() {
        this.file = undefined;
        this.fileName="Please select file"
    }
    removeImageFile() {
        if (this.imageFile.length == 1) {
            this.imageFileName = "Please select image"
        }
    }

    ngOnDestroy() {
        if (this.eventTest != undefined) {
            this.eventTest.moveAllLeft();
            this.sourceList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
        }
        if (this.subscribeImportSubmit) {
            this.subscribeImportSubmit.unsubscribe();
        }
        this.eventSources.forEach(source => source.close());
    }

    hasReadOnly(){

        return this.commonService.hasReadOnlyRole();

      }
}
