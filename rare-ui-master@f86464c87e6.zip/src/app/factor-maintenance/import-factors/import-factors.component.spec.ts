import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';
import { ImportFactorsComponent } from './import-factors.component';
import { DropdownModule, PickList, FileUpload } from 'primeng/primeng';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, ElementRef, NgZone} from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services';
import { MessageService } from 'primeng/api';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs/internal/observable/of';
import { By, DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { OidcSecurityService, AuthModule } from 'angular-auth-oidc-client';
import { mockLobListAll, mockLobList,targetList,response,response1,lobList,lobList1,stateList,stateList1,sortedList,sourceList,targetList1 } from './import-factors.mock';

describe('ImportFactorsComponent', () => {
    let component: ImportFactorsComponent;
    let fixture: ComponentFixture<ImportFactorsComponent>;
    var http: HttpClient;
    let commonService: CommonService;
    let messageService: MessageService;
    let pickList: PickList;
    var file;
    var submitButton;
    var picklistEl;
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ImportFactorsComponent],
            imports: [
                DropdownModule,
                AuthModule.forRoot()
            ],
            providers: [provideHttpClient(), MessageService,CommonService, {
                provide: Router,
                useClass: class { navigate = jasmine.createSpy("navigate"); },
                OidcSecurityService
            }
            ],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ImportFactorsComponent);
        //.addservice
        component = fixture.componentInstance;
        file = new File(["3555"], 'test-file.jpg', { lastModified: 456565656, type: 'image/jpeg' });
        submitButton = fixture.debugElement.query(By.css('#submit'));
        picklistEl = fixture.debugElement.query(By.css('#picklistId'));
        fixture.detectChanges();
        commonService = TestBed.get(CommonService);
        messageService = TestBed.get(MessageService);
    });
    afterEach(() => {
        fixture=null;
        component=null;
        file=null;
        submitButton=null;
        picklistEl=null;
        commonService=null;
        messageService=null;
    });
    //aftereach
    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    it("should call the constructor", () => {
        component = new ImportFactorsComponent(commonService, messageService);
    });

    it("should call #ngOnInit", () => {
        spyOn(component, 'setHeaderPicklistTables');
        component.ngOnInit();
        expect(component.setHeaderPicklistTables).toHaveBeenCalled();

        spyOn(component, 'fillPicklistSource');
        component.ngOnInit();
        expect(component.fillPicklistSource).toHaveBeenCalled();
    });

    it("should call setHeaderPicklistTables", () => {
        expect(component.sourceHeaderPicklist).toEqual("Available Factor Tables");
        expect(component.targetHeaderPicklist).toEqual("Selected Factor Tables");
        expect(component.sourcePlaceholder).toEqual("Search by table name");
    });

    it("should define fillPicklistSource and must call #getLobList in the constructor", () => {
        component.fillPicklistSource();
        component.lobList = mockLobListAll;
        expect(component.lobList.toString()).toContain(mockLobList.toString());
    });

    it('should call the myuploader event', () => {
        component.file = file;
        expect(component.file).toBeDefined();
        expect(component.showFileError).toEqual(false);
    });

    it('should submit the form', () => {
        component.lobValue = "MED";
        spyOn(commonService, 'submitImportFactorTables').and.returnValue(of(response));
        component.file = file;
        component.targetList = targetList;
        submitButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(commonService.submitImportFactorTables).toHaveBeenCalled();
        expect(component.showStateError).toEqual(true);

        component.stateValue = "CA";
        submitButton.triggerEventHandler('click', null);
        fixture.detectChanges();
    });

    it('should call parsehttpresponse', () => {
        component.parseHttpResponse(response.dataLoadStatus, "event");

        component.parseHttpResponse(response1.dataLoadStatus, "event");
        expect(component.failedTables.length).toEqual(1);
    });

    it('should set the error text on click of Submit form', () => {
        let file1;
        component.file = file1;
        component.showTableError = true;
        component.lobValue = "VIS";

        submitButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.showFileError).toEqual(true);


        component.file = file;
        component.lobValue = "ADMIN";
        component.userSelectedLob = { value: "VIS" };
        submitButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.showFileError).toEqual(false);

    });

    it('should create the Picklist', () => {
        fixture.detectChanges();
        expect(picklistEl).toBeTruthy();
    });

    it('should reset the Picklist', () => {
        let el: ElementRef;
        let sanitizer: DomSanitizer;
        let zone: NgZone;
        let picklistelement: ElementRef;
        component.sourceList = sourceList;
        component.showFileError = true;
        component.showTableError = true;
        component.lobValue = "DEN";
        component.showLobDropdown = false;
        let myInputVariable: FileUpload;
        myInputVariable = new FileUpload(el, sanitizer, zone, http);
        component.myInputVariable = myInputVariable;
        component.myInputVariable.clear();
        pickList = new PickList(picklistelement);
        spyOn(component, 'resetLobData');

        expect(pickList).toBeDefined();
        const resetButton = fixture.debugElement.query(By.css('#reset'));
        resetButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.resetLobData).toHaveBeenCalled();

        spyOn(component, 'resetStateData');
        resetButton.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(component.resetStateData).toHaveBeenCalled();

        expect(component.showFileError).toEqual(false);
        expect(component.showTableError).toEqual(false);
        expect(component.showStateDropdown).toEqual(false);
    });

    it('should enter resetLobdata', () => {
        component.lobList = lobList;
        component.resetLobData();
        expect(component.lobValue).toEqual("DEN");
    });

    it('should enter resetLobdata if loblist > 1', () => {

        component.lobList = lobList1;
        component.resetLobData();
        expect(component.showLobDropdown).toEqual(true);
    });

    it('should enter resetStatedata', () => {
        component.stateValue = "CA";
        component.userSelectedState = "CA";
        component.lobValue = "MED";
        component.showStateDropdown = true;
        component.showStateSingleValue = false;
        component.resetStateData();
        expect(component.stateValue).toBe(undefined);

        expect(component.userSelectedState).toBe(undefined);


        component.stateList = stateList;
        component.resetStateData();
        expect(component.stateValue).toEqual("CA");
        expect(component.showStateDropdown).toEqual(false);
        expect(component.showStateSingleValue).toEqual(true);

        component.stateList = stateList1;
        component.resetStateData();
        expect(component.showStateDropdown).toEqual(true);
        expect(component.showStateSingleValue).toEqual(false);

        component.lobValue = "DEN";
        component.resetStateData();
        expect(component.showStateDropdown).toEqual(false);
        expect(component.showStateSingleValue).toEqual(false);

    });

    it('should call moveToTarget', () => {
        let picklistelement: ElementRef;
        component.showTableError = true;

        component.targetList = targetList1;
        pickList = new PickList(picklistelement);
        component.moveToTarget(pickList);
        expect(component.showTableError).toEqual(false);
        expect(component.eventTest).toEqual(pickList);
        expect(component.targetList).toEqual(sortedList);

        component.targetList = sortedList;
        component.moveToTarget(pickList);
        expect(component.targetList).toEqual(sortedList);

    });

    it('should call moveToSource', () => {
        let picklistelement: ElementRef;

        component.sourceList = sourceList;
        pickList = new PickList(picklistelement);
        component.moveToSource(pickList);
        expect(component.sourceList).toEqual(sortedList);

        component.targetList = sourceList;
        component.moveToSource(pickList);
        expect(component.sourceList).toEqual(sortedList);
    });

    it('should define lobChanged', () => {
        component.userSelectedLob = { value: undefined };
        component.lobChanged();
        fixture.detectChanges();
        expect(component.showLobError).toBe(true);
    });

    it('should define stateChanged', () => {
        component.userSelectedState = { value: "CA" };
        component.showStateError = true;
        component.stateChanged();
        fixture.detectChanges();
        expect(component.stateValue).toEqual("CA");
        expect(component.showStateError).toEqual(false);
    });

    it('should define removeFile', () => {
        component.file = file;
        component.removeFile();
        expect(component.file).toBeUndefined();
    });

    it("should call #ngOnDestroy", () => {
        let picklistelement: ElementRef;
        pickList = new PickList(picklistelement);
        component.eventTest = pickList;
        component.sourceList = sourceList;
        component.ngOnDestroy();
        expect(component.sourceList).toEqual(sortedList);

        component.sourceList = sortedList;
        component.ngOnDestroy();
        expect(component.sourceList).toEqual(sortedList);

    });

});
