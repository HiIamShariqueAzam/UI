import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ImportFactorsComponent } from "./import-factors.component";
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { FileUploadModule } from 'primeng/fileupload';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { TabsModule } from 'primeng/tabs';
import { SelectModule } from 'primeng/select';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DialogModule } from 'primeng/dialog';
import { SharedModule } from 'src/app/shared/shared.module';
@NgModule({
    declarations: [
        ImportFactorsComponent
    ],
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule, ButtonModule, DialogModule,
        FileUploadModule, ToastModule, FlexLayoutModule, ProgressSpinnerModule, TabsModule, SelectModule,
        PickListModule, SharedModule, RouterModule.forChild([
            { path: '', component: ImportFactorsComponent, pathMatch: 'full' }
        ])
    ],
    exports: [
        ImportFactorsComponent
    ],
    providers: [
        MessageService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ImportFactorsModule {
}
