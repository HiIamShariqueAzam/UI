export  const mockLobListAll = [
    {
        "VIS": [
            {
                "displayName": "CA",
                "tableName": "VIS_RATE"
            },
            {
                "displayName": "CO",
                "tableName": "VIS_RATE"
            },
            {
                "displayName": "CT",
                "tableName": "VIS_RATE"
            },
            {
                "displayName": "GA",
                "tableName": "VIS_RATE"
            }
        ],
        "DEN": [
            {
                "displayName": "DEN_GEO_GRP",
                "tableName": "DEN_GEO_GRP"
            },
            {
                "displayName": "DEN_IMPCT_UTIL_FCTR",
                "tableName": "DEN_IMPCT_UTIL_FCTR"
            },
            {
                "displayName": "DEN_OON_REIMB_FCTR",
                "tableName": "DEN_OON_REIMB_FCTR"
            }
        ],
        "SYS": [
            {
                "displayName": "RT_FCTR",
                "tableName": "RT_FCTR"
            }
        ],
        "MED": [
            {
                "displayName": "MED_ACA_INSURER_FEE_FCTR",
                "tableName": "MED_ACA_INSURER_FEE_FCTR"
            },
            {
                "displayName": "MED_ADMIN_RETNTN_FCTR",
                "tableName": "MED_ADMIN_RETNTN_FCTR"
            },
            {
                "displayName": "MED_AGE_SEX_FCTR",
                "tableName": "MED_AGE_SEX_FCTR"
            },
            {
                "displayName": "MED_AREA_FCTR",
                "tableName": "MED_AREA_FCTR"
            }

        ]
    }
];

export const mockLobList = {
    "VIS": [
        {
            "displayName": "CA",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "CO",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "CT",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "GA",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "IN",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "KY",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "ME",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "MO",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "NH",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "NV",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "NY",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "OH",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "VA",
            "tableName": "VIS_RATE"
        },
        {
            "displayName": "WI",
            "tableName": "VIS_RATE"
        }
    ]
};
export const targetList = [
    { displayName: "DEN_ACA_FEE_FCTR", tableName: "DEN_ACA_FEE_FCTR" },
    { displayName: "DEN_ANNL_MAX_FCTR", tableName: "DEN_ANNL_MAX_FCTR" }
];

export const response = {
    "dataLoadStatus": [
        {
            "sheetName": "DEN_ACA_FEE_FCTR",
            "status": "failed",
            "errors": [
                {
                    "rowNumber": 1,
                    "columnName": null,
                    "errorMessage": null
                },
                {
                    "rowNumber": 2,
                    "columnName": null,
                    "errorMessage": null
                },
                {
                    "rowNumber": 3,
                    "columnName": null,
                    "errorMessage": null
                },
                {
                    "rowNumber": 4,
                    "columnName": null,
                    "errorMessage": null
                },
                {
                    "rowNumber": 5,
                    "columnName": null,
                    "errorMessage": null
                }]
        }]
};

export const response1 = {
    "dataLoadStatus": [
        {
            "sheetName": "DEN_ACA_FEE_FCTR",
            "status": "failed",
            "errors": [
                {
                    "rowNumber": null,
                    "columnName": "column1",
                    "errorMessage": 0
                },
            ]
        }]
};


export const lobList = [{ "label": "DEN", "value": "DEN" }];

export const lobList1 = [{ "label": "DEN", "value": "DEN" }, { "label": "VIS", "value": "VIS" }];

export const stateList = [{ "label": "CA", "value": "CA" }];

export const stateList1 = [{ "label": "CA", "value": "CA" }, { "label": "GA", "value": "GA" }];

export const sortedList = [
    { displayName: "DEN_ACA_FEE_FCTR", tableName: "DEN_ACA_FEE_FCTR" },
    { displayName: "DEN_ANNL_MAX_FCTR", tableName: "DEN_ANNL_MAX_FCTR" }
];

export const sourceList = [
    { displayName: "DEN_ANNL_MAX_FCTR", tableName: "DEN_ANNL_MAX_FCTR" },
    { displayName: "DEN_ACA_FEE_FCTR", tableName: "DEN_ACA_FEE_FCTR" },
];
export const sourceList1 = [    
    { displayName: "DEN_ACA_FEE_FCTR", tableName: "DEN_ACA_FEE_FCTR" },
    { displayName: "DEN_ANNL_MAX_FCTR", tableName: "DEN_ANNL_MAX_FCTR" }
];
export const targetList1 = [
    { displayName: "DEN_ANNL_MAX_FCTR", tableName: "DEN_ANNL_MAX_FCTR" },
    { displayName: "DEN_ACA_FEE_FCTR", tableName: "DEN_ACA_FEE_FCTR" }
];

export const unsortedList1 = [
    { displayName: "DEN_ANNL_MAX_FCTR", tableName: "DEN_ANNL_MAX_FCTR" },
    { displayName: "DEN_ACA_FEE_FCTR", tableName: "DEN_ACA_FEE_FCTR" }
];
export const sortedList1 = [
    { displayName: "DEN_ACA_FEE_FCTR", tableName: "DEN_ACA_FEE_FCTR" },
    { displayName: "DEN_ANNL_MAX_FCTR", tableName: "DEN_ANNL_MAX_FCTR" }
];