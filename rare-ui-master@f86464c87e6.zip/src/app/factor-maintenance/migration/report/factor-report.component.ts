import { Component, OnInit } from '@angular/core';
import { CommonService, AuthenticationService, DateFormatPipe } from 'src/app/shared/services';
import { Router } from '@angular/router';
import { System, Environment, MigrationBaseComponent } from 'src/app/factor-maintenance/migration/common/migration-base.component';
import { StringUtils } from "src/app/shared/utils/string-utils";
import { MigrationService } from '../services/migration.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonConstants } from 'src/app/shared/constants/common.constants';


@Component({
    selector: 'app-factor-report',
    templateUrl: 'factor-report.component.html',
    styleUrls: ["factor-report.component.css"],
    standalone: false,
})
export class FactorReportComponent extends MigrationBaseComponent implements OnInit {
    public reportForm: FormGroup;
    public systems: System[] = [];
    public systemTables: any[] = [];
    public factorTables = new Map<string, any>();
    public tableCategoryList: any;
    public createdUser: Environment[] = [{
        name: 'All Users',
        code: 'all_users'
    }];
    public isReportFormSubmit: boolean = false;
    public isSystemEmpty: boolean = false;
    public noData: string = "Not Available";
    public formLabels: any = {
        tableCategory: 'tableCategory',
        factorTables: 'factorTables',
        createdDateStart: 'createdDateStart',
        createdDateEnd: 'createdDateEnd',
        createdUser: 'createdUser',
        system: 'system'
    }
    public alert = {
        show: false,
        message: "",
        type: "",
        cssClass: "",
        header: "",
        headerVisibility: true,
      };
    showProgress: boolean = false;
    progressPercent: number = 0;
    progressMessage: any;
    progressStyle: string;
    processId: any;

    constructor(private router: Router, private fb: FormBuilder, private commonService: CommonService, private authenticationService: AuthenticationService, private factorMigrationService: MigrationService, private dateFormatPipe: DateFormatPipe) {
        super();
    }
    ngOnInit() {
        const setDefaultValue = '';
        this.reportForm = this.fb.group({
            system: [setDefaultValue],
            factorTables: [{ value: setDefaultValue, disabled: true }],
            tableCategory: [{ value: setDefaultValue, disabled: true }],
            createdUser: [setDefaultValue],
            createdDateStart: [setDefaultValue],
            createdDateEnd: [{ value: setDefaultValue, disabled: true }],
        },
            {
                validator: this.validateDate(this.formLabels.createdDateStart, this.formLabels.createdDateEnd),
            })
        this.factorMigrationService.getUniqueCreatedUsers().subscribe(response => {
            if (response && response.length > 0) {
                response.forEach(user => {
                    this.createdUser.push({ name: user, code: user })
                })
                this.reportForm.get(this.formLabels.createdUser).setValue([{
                    name: this.authenticationService.getUserName(),
                    code: this.authenticationService.getUserName()
                }]);
            }
            const loginedUserName = this.authenticationService.getUserName();
            if (response?.indexOf(loginedUserName) === -1) {
                this.reportForm.get(this.formLabels.createdUser).setValue(this.createdUser.filter((user) => StringUtils.isEqualIgnoreCase(user.code, 'all_users')));
            }
        }, error => {
            console.log(error);
        });
        this.fetchSystemDetails();
    }
    goToFactorSearch(): void {
        this.router.navigate(["factor-migration"]);
    }
    fetchSystemDetails() {
        this.commonService.getFactorSystems().subscribe((response: any) => {
            if (response) {
                // Handle response as array of objects (new format)
                if (Array.isArray(response)) {
                    response.forEach((system: any) => {
                        const systemName = system.SYSTEM || system;
                        if (this.factorMigrationService.verifyUserRolewithSystem(systemName)) {
                            this.systems.push({ 
                                label: systemName, 
                                value: systemName,
                                skipBackup: system.SKIP_DATABACKUP || 'N'
                            });
                        }
                    });
                } else {
                    // Backward compatibility for old response format (object)
                    for (const system in response) {
                        if (this.factorMigrationService.verifyUserRolewithSystem(response[system])) {
                            this.systems.push({ 
                                label: response[system], 
                                value: response[system],
                                skipBackup: 'N'
                            });
                        }
                    }
                }
                this.systems.sort((sysPrev, sysNext) => (sysPrev.value < sysNext.value ? -1 : 1));
            }
        }, error => {
            console.log(error);
        });
    }
    updateSystem(event) {
        if (this.reportForm.get(this.formLabels.system)?.value) {
            this.systemTables =[];
            this.tableCategoryList = [];
            this.fetchFactorTables(this.reportForm.get(this.formLabels.system).value);
            Object.keys(this.reportForm.controls).forEach((key) => {
                if(StringUtils.isEqual(key,this.formLabels.tableCategory) || StringUtils.isEqual(key,this.formLabels.factorTables)){
                    this.reportForm.get(key).enable();
                    this.reportForm.get(key).reset();
                }
            })
        }
    }
    fetchFactorTables(system) {
        this.commonService.getFactorTables(system?.value).subscribe((response) => {
            this.buildFactorTables(response, system?.value);
        }, error => {
            console.log(error);
        });
    }
    buildFactorTables(response: any,system:string) {
        let fullTablesList: any[] = [];
        let allAvailableLobList: any[] = [];
        this.factorTables = new Map<string, any>();
        Object.keys(response).forEach((key) => {
            if (StringUtils.isEqual(key, this.formLabels.tableCategory)) {
                response[key].forEach(tableCategory => {
                    allAvailableLobList.push({
                        label: tableCategory.categoryDescription,
                        value: tableCategory.categoryName
                    });
                });
            } else {
                if(this.factorMigrationService.verifyUserRolewithLOB(key,system)){
                this.factorTables.set(key, response[key]);
                fullTablesList.push(response[key]);
                this.commonService.setFullTablesList(fullTablesList);
                }
            }
        });
        this.tableCategoryList = this.factorMigrationService.getSelectedLOBList(allAvailableLobList,system);
        if (this.tableCategoryList && this.tableCategoryList?.length) {
            this.tableCategoryList.sort((tabPrev, tabNext) => (tabPrev.label < tabNext.label ? -1 : 1));
        }
        if (Array.isArray(fullTablesList)) {
            let allSystemTables = [].concat(...Array.from(fullTablesList));
            if (allSystemTables && allSystemTables?.length) {
                this.systemTables = allSystemTables;
                this.systemTables.sort((tab1, tab2) => (tab1.displayName < tab2.displayName ? -1 : 1));
            }
        }
    }
    clickedCalendar(dateType, fieldType) {
        let elementId = '#' + dateType;
        if (StringUtils.isEqual(fieldType, CommonConstants.DATE)) {
            let element: HTMLElement = document.querySelector(`${elementId} .p-inputtext`) as HTMLElement;
            this.dateButtonClick(element);
        }
    }
    dateButtonClick(element: HTMLElement) {
        if (!StringUtils.isEmpty(typeof (element))) {
            element.click();
        }
    }

    clearPlan() {
        this.reportForm.reset();
        this.isReportFormSubmit = false;
        this.tableCategoryList =[];
        this.systemTables = [];
        this.reportForm.get(this.formLabels.tableCategory).disable();
        this.reportForm.get(this.formLabels.factorTables).disable();
        this.reportForm.get(this.formLabels.createdDateEnd).disable();

    }
    updateTableCategory(event) {
        if (event.value?.value && this.factorTables) {
            let factorListTables = Array.from(this.factorTables, ([key, value]) => ({ key, value }));
            let matchedCategoryList = factorListTables?.find((tab) => tab.key == event.value?.value)
            if (matchedCategoryList && matchedCategoryList?.value) {
                const setTableValue = '';
                this.reportForm.get(this.formLabels.factorTables).setValue(setTableValue);
                this.systemTables = matchedCategoryList?.value;
                this.systemTables.sort((tab1, tab2) => (tab1.displayName < tab2.displayName ? -1 : 1));
            }
        }
    }

    validateDate(dateFrom: string, dateTo: string) {
        return (formGroup: FormGroup) => {
            const datefrom = formGroup.controls[dateFrom];
            const dateto = formGroup.controls[dateTo];
            const dateFromValue = new Date(datefrom.value);
            const dateToValue = new Date(dateto.value);
            if (new Date(datefrom.value) > new Date(dateto.value)) {
                datefrom.setErrors({ invalidFromDate: true });
            }
            let months = (dateToValue.getFullYear() - dateFromValue.getFullYear()) * 12;
            months -= dateFromValue.getMonth();
            months += dateToValue.getMonth();
            let daydiff = (dateToValue.getDate() - dateFromValue.getDate());
            if ((new Date(datefrom.value)) > (new Date(dateto.value))) {
                datefrom.setErrors({ invalidFromDate: true });
                dateto.setErrors(null);
            }
            else if (months > 12 || (months == 12 && daydiff >= 0)) {
                dateto.setErrors({ invalidDateRange: true });
                datefrom.setErrors(null);
            }
            else {
                datefrom.setErrors(null);
            }
        };
    }
    updateFromDate(event) {
        if (event) {
            const setDate ='';
            this.reportForm.get(this.formLabels.createdDateEnd).setValue(setDate);
            this.reportForm.get(this.formLabels.createdDateEnd).enable();
            this.reportForm.get(this.formLabels.createdDateEnd).setErrors({ required: true });
        }
    }

    submitReport() {
        this.isReportFormSubmit = false;
        this.isSystemEmpty=false;
        this.reportForm.get(this.formLabels.createdUser).setErrors(null);
        if (this.reportForm && this.reportForm?.value) {
            Object.keys(this.reportForm.value).forEach((key) => {
                if(StringUtils.isEqual(key, this.formLabels.createdUser) && !this.reportForm.value[key]?.length){
                    this.reportForm.get(key).reset();
                }
                if(!this.authenticationService.isUserRoleAdmin(this.authenticationService.getUserRole()) && StringUtils.isEqual(key, this.formLabels.system) && !this.reportForm.value[key]){
                    this.reportForm.get(key).reset();
                    this.isSystemEmpty=true;
                }
                if (this.reportForm.value[key]) {
                    this.isReportFormSubmit = true;
                }
            })
        }
        if (!this.isReportFormSubmit) {
            this.reportForm.get(this.formLabels.createdUser).setErrors({ required: true })
        }
        if (this.isSystemEmpty) {
            this.reportForm.get(this.formLabels.system).setErrors({ required: true })
            this.isReportFormSubmit = false;
        }
        if (this.reportForm.valid && this.isReportFormSubmit) {
            this.generateReport();
        }
    }
    generateReport() {
        this.factorMigrationService.fetchFactorReports(this.reportForm, this.formLabels).subscribe((response) => {
            if (response != null) {
                this.processId = response.processId;
                if (this.processId) {
                    this.showProgress = true;
                    this.progressPercent = 1;
                    this.progressStyle = "progress-bar-warning";
                    let eventSourceStream = this.commonService.listenForStream(this.processId);
                    eventSourceStream.addEventListener("REPORT_GENERATION_STATUS", (event: any) => {
                        if (event && event.data) {
                            this.progressStyle = "";
                            let eventData = JSON.parse(event.data);
                            this.progressPercent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
                            this.progressMessage = eventData.message;
                        }
                    });
                    eventSourceStream.addEventListener("REPORT_GENERATION_STATUS_COMPLETE", (event: any) => {
                        eventSourceStream.close();
                        if (event && event.data) {
                            let eventData = JSON.parse(event.data);
                            this.progressStyle = "progress-bar-success";
                            this.progressPercent = 100;
                            this.progressMessage = eventData.message;
                            if (eventData && eventData.payload) {
                                let contentData = eventData.payload.contentData;
                                const arrayBuffer = this.base64ToArrayBuffer(contentData);
                                this.createAndDownloadBlobFile(arrayBuffer, eventData.metaData.fileName);
                            }
                        }
                        setTimeout(() => {
                            this.showProgress = false;
                        }, this.commonService.getProgressBarTimeOut());
                    });
                    eventSourceStream.addEventListener('FAILED', (message: any) => {
                        eventSourceStream.close();
                        this.progressPercent = 90;
                        this.progressStyle = "progress-bar-danger";
                        this.progressMessage = "Error occurred while generating report";
                    });
                }
            }
        }, error => {
            const status ='failed';
            const alertClass ="alert-danger";
            const errorMessage = (error && error?.exceptions && error?.exceptions?.length) ? error.exceptions[0].message : "Something went wrong !";
            this.setAlertVisibility(true,status, errorMessage, alertClass);
            console.error(error);
        })
    }
    setAlertVisibility(isAdd: boolean, headerMessage: string, messageInfo: string='', statusClass: string) {
        this.alert = {
            show: isAdd,
            message: messageInfo,
            type: "",
            cssClass: statusClass,
            header: headerMessage,
            headerVisibility: isAdd,
        };
    }
    removeAlertMsg() {
        this.alert = {
            show: false,
            message: "",
            type: "",
            cssClass: "",
            header: "",
            headerVisibility: true,
        };
    }
}