import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { FileUploadModule } from 'primeng/fileupload';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CheckboxModule } from 'primeng/checkbox';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DialogModule } from 'primeng/dialog';
import { TooltipModule } from 'primeng/tooltip';
import { RouterModule } from '@angular/router';
import { MigrationSearchComponent } from "./search/migration-search.component";
import { MigrationPlanComponent } from "./plan/migration-plan.component";
import { MigrationBaseComponent } from './common/migration-base.component';
import { PickListModule } from "primeng/picklist";
import { FactorExportComponent } from './export/factor-export.component';
import { BulkImportComponent } from './bulk-import/bulk-import.component';
import { CardModule } from 'primeng/card';
import { FactorReportComponent } from './report/factor-report.component';
import { MigrationPlanStatusComponent } from "./plan/migration-plan-status.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';


@NgModule({
  declarations: [MigrationSearchComponent, MigrationPlanComponent, MigrationBaseComponent, FactorExportComponent, FactorReportComponent, MigrationPlanStatusComponent, BulkImportComponent],
  imports: [
    CommonModule,
    TableModule,
    ReactiveFormsModule,
    FormsModule,
    DialogModule,
    NgbModule,
    SelectModule,
    CommonModule, TableModule, ButtonModule, ReactiveFormsModule, RadioButtonModule, FlexLayoutModule,
    AutoCompleteModule, CheckboxModule, FormsModule, MultiSelectModule, ButtonModule, FileUploadModule, ProgressSpinnerModule,
    TooltipModule, PickListModule, CardModule, DatePickerModule,
    RouterModule.forChild([
      { path: '', component: MigrationSearchComponent, pathMatch: 'full' },
      { path: 'bulkImport', component: BulkImportComponent, pathMatch: 'full'},
      { path: 'plan', component: MigrationPlanComponent, pathMatch: 'full' },
      { path: 'export', component: FactorExportComponent, pathMatch: 'full' },
      { path: 'report', component: FactorReportComponent, pathMatch: 'full' }
    ])
  ],
  exports: [
    MigrationSearchComponent,
    MigrationPlanComponent,
    MigrationBaseComponent,
    FactorExportComponent,
    FactorReportComponent,
    MigrationPlanStatusComponent,
    BulkImportComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MigrationModule { }
