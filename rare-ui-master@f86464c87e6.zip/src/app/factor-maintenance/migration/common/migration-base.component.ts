import {Component} from "@angular/core";
import {FactorMigrationConstants} from "../../constants/factor-migration-constants";

export interface Environment {
  name: string,
  code: string
}

export interface System {
  label: string,
  value: string,
  skipBackup?: string;
}

export interface MigrationType {
  label: string,
  value: string
}

export interface ExportFilterCriteria {
  fieldDisabled: string;
  criteriaId: string;
  fieldName: string;
  fieldType: string;
  mandatory: string;
  fieldLabel: string;
  fieldDefault:string;
  whereColumn: string;
  whereCondition: string;
  tableName: string;
}

@Component({
  template: '',
  standalone: false,
})
export class MigrationBaseComponent {
  headerColumns = FactorMigrationConstants.HEADER_COLUMNS;
  constructor() {}

  base64ToArrayBuffer(base64: string) {
    const binaryString = window.atob(base64); // Comment this if not using base64
    const bytes = new Uint8Array(binaryString.length);
    return bytes.map((byte, index) => binaryString.charCodeAt(index));
  }

  createAndDownloadBlobFile(body, filename) {
    const blob = new Blob([body]);
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement("a");
      // Browsers that support HTML5 download attribute
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }
}
