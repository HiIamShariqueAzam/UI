
export class migrationPlan {
    id: string;
    migrationName: string;
    system: string;
    tableCategory: string;
    createdUser: string;
    createdTime: string;
    updatedUser: string;
    updateTime: string;
    typeOfUpdate: string;
    tableStateMapping: any;
    migratedEnvironments: Array<any>;
    toBeMigratedEnvironments: Array<any>;
    selectedFactorTableList: Array<any>;
    migrationStatus: string;
    migrationHistory: Array<any>;
    selectedEnvironment: Array<any>;
    factorMigrationStatus: any;
    skipBackupDelete: boolean;  
}