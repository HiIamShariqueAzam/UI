import { Inject, Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { AuthenticationService, CommonService } from "../../../shared/services";
import { SESSION_STORAGE, WebStorageService } from "ngx-webstorage-service";
import { FormGroup } from '@angular/forms';
import { StringUtils } from "../../../shared/utils/string-utils";
import { FactorMigrationConstants } from "../../constants/factor-migration-constants";
import { CommonConstants } from "src/app/shared/constants/common.constants";

@Injectable({
  providedIn: 'root'
})
export class MigrationService {
  public searchMigrationPlan: any;

  constructor(private httpClient: HttpClient,
              private commonService: CommonService,
              private authenticationService: AuthenticationService,
              @Inject(SESSION_STORAGE) private storage: WebStorageService,) { }

  /**
   * Function to save migration plan to mongo repository
   * @param migrationPlan
   * @param file
   * @param images the array of uploaded blob files, sent as multiple images parameters of request
   */
  saveMigrationPlanDetails(migrationPlan: any, file: File, images: File[]): Observable<any> {
    const header = this.commonService.setRequestHeaders();
    let formData: FormData = new FormData();
    if(file)
      formData.append("file", file);
    if (images) {
      for (let i = 0; i < images.length; i++) {
        formData.append("images", images[i]);
      }
    }
    let migrationPlanRequest = {
      "metadata": {
        "userid": this.authenticationService.getUserID(),
        "username": this.authenticationService.getUserName() ?  this.authenticationService.getUserName() : 'Local User'
      },
      "data": migrationPlan
    }
    formData.append("request", JSON.stringify(migrationPlanRequest));
    return this.httpClient.post<any>( this.commonService.getRareUiUrl() + '/migration/plan/save', formData, { headers: header });
  }

  fetchMigrationPlans(form?: FormGroup ,pageLimit?: number, cursor?: any, sortMetaData?: any):Observable<any> {
    let queryObject = {};
    let dateArray = <any>[];
    let flagFromdate: boolean = false;
    let flagTodate: boolean = false;
    const systemKey = 'system';
    const tableCategory = "tableCategory";
    Object.keys(form.controls).forEach(key => {
      if (form.value[key] != "" && form.value[key] != null) {
        if (key == "fromdate" || key == "todate") {
          let day = form.value[key].getDate();
          let month = form.value[key].getMonth() + 1;
          let year = form.value[key].getFullYear();
          let date = year + '-' + month + '-' + day;
          dateArray.push(date);
        } else {
          let keyValue = form.value[key];
          if (StringUtils.isEqual(key,'createdUser')) {
            let keyData = keyValue.map((item) => item.code.trim());
            if(keyData.indexOf('all_users') == -1) {
              queryObject[key] =  {"$in":keyData};;
            }
          }else if(StringUtils.isEqual(key,systemKey) && keyValue?.length){
            queryObject[key] = {"$in":keyValue.map((item) => item.code.trim())};
          } else {
            keyValue = { "$regex": ".*" + this.commonService.escapeRegExp(keyValue.trim()) + ".*" };
            queryObject[key] = keyValue;
          }
        }
      }
      else {
        if (key === "fromdate") {
          flagFromdate = true;
        }
        else if (key === "todate") {
          flagTodate = true;
        }
      }
    });
    if (dateArray.length) {
      let key = 'createdTime';
      let value1;
      if (dateArray.length === 2) {
        value1 = { '$gte': dateArray[0] + ' 00:00:00', '$lte': dateArray[1] + ' 23:59:59' };
      }
      else {
        if (flagFromdate) {
          value1 = { '$lte': dateArray[0] + ' 23:59:59' };
        }
        if (flagTodate) {
          value1 = { '$gte': dateArray[0] + ' 00:00:00' };
        }
      }
      queryObject[key] = value1;
    }
    if(!this.authenticationService.isUserRoleAdmin(this.authenticationService.getUserRole()) && !queryObject[systemKey]){
      const keyValue = this.storage.get("availableSystems");
      if(keyValue?.length){
      queryObject[systemKey] = {"$in":keyValue.map((item) => item.code.trim())};
      }
    }
    if(this.isActuarialUserRoleOnly() && !queryObject[tableCategory] && !this.authenticationService.getUserLob().includes(FactorMigrationConstants.LOB_ALL)){
      let categoryList = this.authenticationService.getUserLob()?.split(',');
      if(!this.isMedicalActuarialUserRole(FactorMigrationConstants.LOB_MED)){
        categoryList = categoryList?.filter((lob) => !StringUtils.isEqual(lob,FactorMigrationConstants.LOB_MED));
      }
      queryObject[tableCategory] = {"$in":categoryList};
    }
    let queryString = JSON.stringify(queryObject);
    this.storage.set('batchSearchQuery', queryString);
    let urlComponents = "?searchQuery=" + encodeURIComponent(queryString);
    if (pageLimit) {
      this.storage.set('batchpageLimit', pageLimit);
      urlComponents = urlComponents + "&pageLimit=" + pageLimit;
    }
    if (cursor) {
      this.storage.set('batchcursor', cursor);
      urlComponents = urlComponents + '&cursor=' + encodeURIComponent(JSON.stringify(cursor));
    }
    if (sortMetaData) {
      urlComponents = urlComponents + '&sortMetaData=' + encodeURIComponent(sortMetaData);
    }
    let headers = this.commonService.setRequestHeaders();
    return this.httpClient.get<any>(this.commonService.getRareUiUrl() + '/migration/plan/filter' + urlComponents, { headers: headers });
  }

  getMigrationByPlanId(planID: string, migrationStatus: string) {
    let headers = this.commonService.setRequestHeaders();
    return this.httpClient.get<any>(this.commonService.getRareUiUrl() + `/migration/plan/${planID}?migrationStatus=` + migrationStatus , { headers: headers });
  }

  getMigrationFileFromFilenet(migrationFileID) {
    let headers = this.commonService.setRequestHeaders();
    let request = {
      "migrationFileID": migrationFileID
    }
    let rareUiRequest = this.commonService.getRareUiRequest(request)
    return this.httpClient.post<any>(this.commonService.getRareUiUrl() + '/migration/plan/get-migration-file', rareUiRequest, { headers: headers });
  }

  getUniqueCreatedUsers() {
    let headers = this.commonService.setRequestHeaders();
    return this.httpClient.get<any>(this.commonService.getRareUiUrl() + '/factor/users', { headers: headers });
  }

  bulkImportTables(migrationPlan: any){
    let headers = this.commonService.setRequestHeaders();
    let formData: FormData = new FormData();
    let migrationPlanRequest = {
      "metadata": {
        "userid": this.authenticationService.getUserID(),
        "username": this.authenticationService.getUserName() ? this.authenticationService.getUserName() : 'Local User'
      },
      "data": migrationPlan
    }
    formData.append("request", JSON.stringify(migrationPlanRequest));
    return this.httpClient.post<any>(this.commonService.getRareUiUrl() + '/migration/plan/save', formData, { headers: headers });
  }

  fetchFactorTables(migrationPlan: any, file: File = null) {
    let headers = this.commonService.setRequestHeaders();
    let formData: FormData = new FormData();
    let migrationPlanRequest = {
      "metadata": {
        "userid": this.authenticationService.getUserID(),
        "username": this.authenticationService.getUserName() ? this.authenticationService.getUserName() : 'Local User'
      },
      "data": migrationPlan
    }
    if (file) {
      formData.append("file", file);
    }
    formData.append("request", JSON.stringify(migrationPlanRequest));
    return this.httpClient.post<any>(this.commonService.getRareUiUrl() + '/migration/export/data', formData, { headers: headers });
  }

  fetchFactorTablesValidation(system:string){
    let headers = this.commonService.setRequestHeaders();
      return this.httpClient.get<any>( this.commonService.getRareUiUrl() + '/export/dynamicFields?system=' + system, { headers: headers });
  }

  setSearchPlan(migrationPlan: any) {
    this.searchMigrationPlan = migrationPlan;
  }

  getSearchPlan() {
    return this.searchMigrationPlan;
  }

  fetchFactorReports(form: any, formLabels: any) {
    let headers = this.commonService.setRequestHeaders();
    let queryObject = {};
    let dateArray = <any>[];
    let flagFromdate: boolean = false;
    let flagTodate: boolean = false;
    let systemName: any;
    Object.keys(form.controls).forEach(key => {
      if (form.value[key] != "" && form.value[key] != null) {
        if (StringUtils.isEqual(key, formLabels.createdDateStart) || StringUtils.isEqual(key, formLabels.createdDateEnd)) {
          const day = form.value[key].getDate();
          const month = form.value[key].getMonth() + 1;
          const year = form.value[key].getFullYear();
          const date = year + '-' + month + '-' + day;
          dateArray.push(date);
        } else {
          let keyValue = form.value[key];
          if (StringUtils.isEqual(key, formLabels.createdUser)) {
            let keyData = keyValue.map((item) => item.code.trim());
            if (keyData.indexOf('all_users') == -1) {
              queryObject[key] = { "$in": keyData };
            }
          }
          if ((StringUtils.isEqual(key, formLabels.tableCategory) || StringUtils.isEqual(key, formLabels.system)) && keyValue) {
			  if(StringUtils.isEqual(key, formLabels.system)){
				  systemName=keyValue;
			  }
            queryObject[key] = { "$in": [keyValue?.value] };
          }else if (this.isActuarialUserRoleOnly() && StringUtils.isEqual(systemName.value,FactorMigrationConstants.RARE) && !queryObject['tableCategory']) {
				let categoryList = this.authenticationService.getUserLob()?.split(',');
				if (!this.isMedicalActuarialUserRole(FactorMigrationConstants.LOB_MED)) {
					categoryList = categoryList?.filter((lob) => !StringUtils.isEqual(lob, FactorMigrationConstants.LOB_MED));
				}
				queryObject['tableCategory'] = { "$in": categoryList };
			}

          if (StringUtils.isEqual(key, formLabels.factorTables) && keyValue?.length) {
            let keyData = keyValue.map((item) => item.displayName.trim());
            const factorTables = "selectedFactorTables.value.displayName";
            queryObject[factorTables] = { "$in": keyData };
          }
        }
      }
      else {
        if (StringUtils.isEqual(key,formLabels.createdDateStart)) {
          flagFromdate = true;
        }
        else if (StringUtils.isEqual(key,formLabels.createdDateEnd)) {
          flagTodate = true;
        }
      }
    });
    if (dateArray?.length) {
      let key = 'createdTime';
      let value1;
      if (dateArray?.length === 2) {
        value1 = { '$gte': dateArray[0] + ' 00:00:00', '$lte': dateArray[1] + ' 23:59:59' };
      }
      else {
        if (flagFromdate) {
          value1 = { '$lte': dateArray[0] + ' 23:59:59' };
        }
        if (flagTodate) {
          value1 = { '$gte': dateArray[0] + ' 00:00:00' };
        }
      }
      queryObject[key] = value1;
    }
    let queryString = JSON.stringify(queryObject);
    let urlComponents = "?reportQuery=" + encodeURIComponent(queryString);
    return this.httpClient.get<any>(this.commonService.getRareUiUrl() + '/migration/plan/report' + urlComponents, { headers: headers });
  }
  /*
  * Method to get selected LOB list for table category
  */
  getSelectedLOBList(categoryList,system) {
    if (StringUtils.isEqual(system,FactorMigrationConstants.RARE) && this.isActuarialUserRoleOnly()  && categoryList?.length && this.authenticationService.getUserLob()) {
      const userLob = this.authenticationService.getUserLob().split(',');
      return categoryList.filter((item) => {
        let lob = item.code ? item.code : item.value;
        if(StringUtils.isEqual(lob,FactorMigrationConstants.LOB_MED)){
          return this.isMedicalActuarialUserRole(lob);
        }
        return StringUtils.checkStrExitsInArr(lob,userLob);
      });
    }
    return categoryList;
  }
  /*
  * Method to verify user role with LOB for update DMT table list(Export and Report)
  */
  verifyUserRolewithLOB(key,system) {
    if (StringUtils.isEqual(system,FactorMigrationConstants.RARE) && this.isActuarialUserRoleOnly()) {
      if(StringUtils.isEqual(key,FactorMigrationConstants.LOB_MED)){
        return this.isMedicalActuarialUserRole(key);
      }
      return this.authenticationService.getUserLob().includes(key)
    }
    return this.authenticationService.getUserLob().includes(FactorMigrationConstants.LOB_ALL)
  }
  /*
  * Method to verify user role with System for update system selection dropdown
  */
  verifyUserRolewithSystem(system) {
    return (this.authenticationService.isUserRoleAdmin(this.authenticationService.getUserRole()) || this.authenticationService.getUserRole().includes(FactorMigrationConstants.RARE_FACTOR_TABLE + system) || (system.indexOf(FactorMigrationConstants.BMS_SYSTEM) >= 0 &&
      this.authenticationService.getUserRole().includes(FactorMigrationConstants.RARE_FACTOR_TABLE + FactorMigrationConstants.BMS_SYSTEM)) || (this.isActuarialUserRoleOnly() && system?.indexOf(FactorMigrationConstants.RARE) >= 0) || (this.authenticationService.getUserRole().includes(FactorMigrationConstants.RARE_FACTOR_TABLE + FactorMigrationConstants.ERE) && (StringUtils.isEqualIgnoreCase(FactorMigrationConstants.COMIX_SYSTEM, system) || StringUtils.isEqualIgnoreCase(FactorMigrationConstants.ERE_EKS_SYSTEM, system))))
  }
  /*
  * Method to verify user role having only Acturial not ADMIN role
  */
  isActuarialUserRoleOnly() {
    return (this.authenticationService.isUserRoleActuarial(this.authenticationService.getUserRole()) && StringUtils.checkArrayObjectExitsInArr(this.commonService.getAssignedUserGroup(), CommonConstants.RARE_DMT_ACCESS_FOR_ACTUARIAL));
  }
  isMedicalActuarialUserRole(key) {
    return this.authenticationService.getUserLob().includes(key) && this.commonService.getAssignedUserGroup().includes(FactorMigrationConstants.MEDICAL_ACTUARIAL);
  }
}
