import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { AuthenticationService, CommonService, DateFormatPipe } from 'src/app/shared/services';
import { Router } from '@angular/router';
import { ExportFilterCriteria, MigrationBaseComponent, System } from '../common/migration-base.component';
import { StringUtils } from "src/app/shared/utils/string-utils";
import * as XLSX from 'xlsx';
import { MigrationService } from '../services/migration.service';
import { PickList } from 'primeng/picklist';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CommonConstants } from 'src/app/shared/constants/common.constants';
import { FileUpload } from 'primeng/fileupload';


@Component({
  selector: 'app-factor-export',
  templateUrl: 'factor-export.component.html',
  styleUrls: ["factor-export.component.css"],
  standalone: false,
})
export class FactorExportComponent extends MigrationBaseComponent implements OnInit, OnDestroy {
  private eventSources: EventSource[] = [];
  userSelectedLob: any;
  systems: System[] = [];
  availableEnvironments: System[] = [];
  file: File;
  targetList: any = [];
  factorTables = new Map<string, any>();
  tableCategoryList: any[];
  selectedEnvError: boolean = false;
  systemError: boolean = false;
  factorTablesExport: any = {
    userSelectedSystem: {},
    selectedEnvironments: "",
    fileName: "",
    tableCategory: []
  }

  noData: string = "Not Available";
  eventTest: PickList;
  sourceList:any[]=[];
  selectedFactorTableMap = new Map<string, any>();
  sourceHeaderPicklist: string;
  targetHeaderPicklist: string;
  sourcePlaceholder: string;
  originalFactorTableMap = new Map<string, any>();
  targetListError:boolean = false;
  public dynamic_exportForm: FormGroup = this.formBuilder.group({});
  ui_filter_criteria: ExportFilterCriteria[];
  formData: any;
  fieldRequired: boolean = false;
  selectedForm: any[] = [];
  uploadSheetNames: any[] = [];
  isFileSelected: boolean = false;
  originalSourceList: any =[];
  alert = {
    show: false,
    message: "",
    type: "",
    cssClass: "",
    header: "",
    headerVisibility: true,
  };

  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: String;

  @ViewChild('myInput') txtUploadFile: FileUpload;
  @ViewChild('picklist') pickList: PickList;
  defaultSourceHeight = '170px';
  targetHeight: string = this.defaultSourceHeight;
  sourceHeight: string = this.defaultSourceHeight;
  categoryOptions: any = [];

  constructor(private router: Router, private commonService: CommonService, private authenticationService: AuthenticationService,
    private factorMigrationService: MigrationService, private formBuilder: FormBuilder, private dateFormatPipe: DateFormatPipe, public datepipe: DatePipe) {
      super();
     }

  ngOnInit() {
    this.fetchSystemDetails();
  }

  fetchSystemDetails() {
    let shouldUpdateMigrationType = false;
    this.commonService.getFactorSystems().subscribe((response:any) => {
      if (response) {
        // Handle response as array of objects (new format)
        if (Array.isArray(response)) {
          response.forEach((system: any, index: number) => {
            const systemName = system.SYSTEM || system;
            if (this.factorMigrationService.verifyUserRolewithSystem(systemName)) {
              this.systems.push({ 
                label: systemName, 
                value: systemName,
                skipBackup: system.SKIP_DATABACKUP || 'N'
              });
              if (response.length - 1 === index || this.authenticationService.getUserRole().includes('RARE_FACTOR_TABLE_' + systemName)) {
                shouldUpdateMigrationType = true;
              }
            }
          });
        } else {
          // Backward compatibility for old response format (object)
          for (const system in response) {
            if (this.factorMigrationService.verifyUserRolewithSystem(response[system])) {
              this.systems.push({ 
                label: response[system], 
                value: response[system],
                skipBackup: 'N'
              });
              if (response?.length - 1 === parseInt(system) || this.authenticationService.getUserRole().includes('RARE_FACTOR_TABLE_' + response[system])) {
                shouldUpdateMigrationType = true;
              }
            }
          }
        }
        this.systems.sort((sysPrev, sysNext) => (sysPrev.value < sysNext.value ? -1 : 1));
        this.fetchFactorTablesValidations();
        this.setPicklistTablesHeaders();
        if (shouldUpdateMigrationType) {
          this.updateMigrationType();
        }
      }
    });
  }
  updateMigrationType() {
    this.ui_filter_criteria = [];
    this.targetList = [];
    this.selectedFactorTableMap = new Map<string, any>();
    this.file = null;
    this.factorTablesExport.fileName = "";
    this.factorTablesExport.tableCategory = [];
    this.factorTablesExport.selectedEnvironments = "";
    if(this.txtUploadFile){
    this.txtUploadFile.clear();
    }
    this.dynamic_exportForm.reset();
    if(this.factorTablesExport.userSelectedSystem?.value){
      this.systemError = false;
      this.fetchFactorTables();
      this.fetchFactorTablesValidations();
      this.fetchTargetDatabases();
  }
  }
  fetchFactorTables() {
    this.commonService.getFactorTables(this.factorTablesExport.userSelectedSystem?.value).subscribe((response) => {
      this.buildFactorTables(response);
      this.updatePickListFilters(true);
    });
  }
  fetchTargetDatabases() {
    this.availableEnvironments = [];
    this.commonService.getTargetDatabases(this.factorTablesExport.userSelectedSystem?.value, 'REAL').subscribe((response: any) => {
      if (response) {
        response.forEach((database) => {
          this.availableEnvironments.push({ label: database.dataBase, value: database.dataBase });
        });
      }
    });
  }
  onFileUpload() { }
  fileUploader(event) {
    this.uploadSheetNames =[];
    this.file = event.files[0];
    this.isFileSelected = true;
    this.factorTablesExport.fileName = event.files[0].name;
    const reader: FileReader = new FileReader();
    reader.readAsBinaryString(event.files[0]);
    reader.onload = (data: any) => {
      /* read workbook */
      const workBook: XLSX.WorkBook = XLSX.read(data.target.result, { type: 'binary' });
      this.uploadSheetNames = workBook.SheetNames;
      if(this.uploadSheetNames && this.uploadSheetNames?.length){
        this.uploadSheetNames = this.uploadSheetNames.map((sheet) => sheet.toLowerCase());
      }
      let sheets = workBook.SheetNames;
      this.buildSourceTargetList(false, sheets);
      this.ui_filter_criteria =[];
      if(this.targetList && this.targetList?.length){
        this.targetListError= false;
      }
      this.createForm(this.formData);
      this.isFileSelected = false;
      this.updateSourceTargetHeight(false);
    }
  }

  goToFactorSearch(): void {
    this.router.navigate(["factor-migration"]);
  }
  buildFactorTables(response: any) {
    let fullTablesList: any[] = [];
    let allAvailableLobList: any[] = [];
    const selectedSystem = this.factorTablesExport.userSelectedSystem?.value;
    this.factorTables = new Map<string, any>();
    Object.keys(response).forEach((key) => {
      if (StringUtils.isEqual(key, 'tableCategory')) {
        response[key].forEach(tableCategory => {
          allAvailableLobList.push({
            label: tableCategory.categoryDescription,
            value: tableCategory.categoryName
          });
        });
      } else {
        if(this.factorMigrationService.verifyUserRolewithLOB(key,selectedSystem)){
        this.factorTables.set(key, response[key]);
        fullTablesList.push(response[key]);
        this.commonService.setFullTablesList(fullTablesList);
        }
      }
    });
    this.tableCategoryList = allAvailableLobList;
    this.categoryOptions = allAvailableLobList?.map((tab) => {
      return {'name': tab.label, 'code': tab.value}});
    this.categoryOptions = this.factorMigrationService.getSelectedLOBList(this.categoryOptions,selectedSystem);
    this.buildSourceTargetList(true, null);
  }

  disableUploadBtn() { }

  removeFile() {
    this.file = undefined;
    this.factorTablesExport.fileName = "";
    this.selectedFactorTableMap = new Map<string, any>();
    this.targetList = this.targetList.filter((item) => {
      return (this.uploadSheetNames.indexOf(item.displayName?.toLowerCase()) == -1) && (this.uploadSheetNames.indexOf(item.tableName?.toLowerCase()) == -1)
    });
    this.updateSourceList();
    this.ui_filter_criteria=[];
    this.createForm(this.formData);
    this.removeAlertMsg();
    const selectedCategory = this.factorTablesExport.tableCategory;
    this.updateTableCategory({value: selectedCategory});
    this.updateSourceTargetHeight(false);
  }

  exportFactorTables() {
    this.showProgress = false;
    if (this.exportFieldsValidation()) {
      return;
    }else if(this.ui_filter_criteria && this.ui_filter_criteria?.length && this.dynamic_exportForm.invalid) {
      this.fieldRequired = true
      return;
    } else {
      if (this.ui_filter_criteria && this.ui_filter_criteria?.length) {
        this.selectedForm = JSON.parse(JSON.stringify(this.ui_filter_criteria));
        this.updateExportPayload();
      } else {
        this.selectedForm = [];
      }
      let selectedTableMap;
      if(this.selectedFactorTableMap){
        selectedTableMap = Array.from(this.selectedFactorTableMap, ([key, value]) => ({ key, value }));
      }

      this.alert = {
        show: true,
        message: "Export file download is in progress...",
        type: "",
        cssClass: "",
        header: "Export Status",
        headerVisibility: true,
      };

      let request = {
        "system": this.factorTablesExport.userSelectedSystem?.value,
        "selectedEnvironments": [this.factorTablesExport.selectedEnvironments?.value],
        "selectedFactorTables": selectedTableMap,
        "exportFilterCriteria": this.selectedForm
      };

      this.factorMigrationService.fetchFactorTables(request, this.file).subscribe(response => {
        if (response != null) {
          let processId = response.processId;
          if (processId) {
            this.showProgress = true;
            this.progressPercent = 1;
            this.progressStyle = "progress-bar-warning";
            let sourceStream = this.commonService.listenForStream(processId);
            this.eventSources.push(sourceStream);
            sourceStream.addEventListener("FACTOR_EXPORT_GENERATION_STATUS", (event: any) => {
              this.progressStyle = "";
              let eventData = JSON.parse(event.data);
              let percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            });
            sourceStream.addEventListener('FACTOR_EXPORT_GENERATION_STATUS_COMPLETE', (message: any) => {
              sourceStream.close();
              let eventData = JSON.parse(message.data);
              this.progressStyle = "progress-bar-success";
              this.progressPercent = 100;
              this.progressMessage = eventData.message;
              let contentData = eventData.payload.contentData;
              const arrayBuffer = this.base64ToArrayBuffer(contentData);
              this.createAndDownloadBlobFile(arrayBuffer, eventData.metaData.fileName);
              setTimeout(() => {
                this.showProgress = false;
              }, this.commonService.getProgressBarTimeOut());
            });
            sourceStream.addEventListener('FAILED', (message: any) => {
              sourceStream.close();
              let eventData = JSON.parse(message.data);
              console.error("Received event : ", JSON.stringify(message.data));
              this.progressPercent = 90;
              this.progressStyle = "progress-bar-danger";
              this.progressMessage = "Error in getting response for Export";
            });
          }
          this.removeAlertMsg();
        }
      }, error => {
        console.error(error);
        this.removeAlertMsg();
      });
    }
  }

  exportFieldsValidation() {
    this.selectedEnvError = false;
    this.systemError = false;
    this.targetListError = false;
    let isNotValid = false;
    if (!this.factorTablesExport.userSelectedSystem?.value) {
      this.systemError = true;
      isNotValid = this.systemError;
    } if (!this.targetList?.length) {
      this.targetListError = true;
      isNotValid = this.targetListError;
    } if (!this.factorTablesExport.selectedEnvironments || !this.factorTablesExport.selectedEnvironments?.value) {
      this.selectedEnvError = true;
      isNotValid = this.selectedEnvError;
    }
    return isNotValid;
  }
  moveToSource(event, isAllListMoved) {
    this.sourceList.forEach(sourceTable => {
      this.selectedFactorTableMap.forEach((tables, key) => {
        const index = tables.findIndex(table => table.displayName === sourceTable.displayName);
        if (index != -1) {
          tables.splice(index,1);
          if (tables.length === 0) {
            this.selectedFactorTableMap.delete(key);
          }
        }
      });
    });
    this.sourceList.sort((source1, source2) => (source1.displayName < source2.displayName ? -1 : 1));

    this.ui_filter_criteria=[];
    if(isAllListMoved){
      this.dynamic_exportForm = this.formBuilder.group({});
    }
    const selectedCategory = this.factorTablesExport.tableCategory;
    this.updateTableCategory({value: selectedCategory});
    this.createForm(this.formData);
    this.updateSourceTargetHeight(false);
  }

  moveToTarget(event: any) {
    this.updateListFromTarget();
    this.eventTest = event;
    this.targetList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
    if(this.targetList && this.targetList?.length){
      this.targetListError= false;
      this.updateSourceTargetHeight(true);
    }
    this.createForm(this.formData);
  }
  setPicklistTablesHeaders() {
    this.sourceHeaderPicklist = 'Available Factor Tables';
    this.targetHeaderPicklist = 'Selected Factor Tables';
    this.sourcePlaceholder = 'Search by table name';
  }
  buildSourceTargetList(isSource, sheets) {
    if (isSource) {
      this.sourceList = []
      this.tableCategoryList.forEach(tableCategory => {
        let categoryTables = this.factorTables.get(tableCategory.value);
        categoryTables?.forEach(categoryTable => {
          this.sourceList.push(categoryTable);
        });
      });
      this.originalFactorTableMap = new Map(JSON.parse(JSON.stringify(Array.from(this.factorTables))));
      this.originalSourceList = JSON.parse(JSON.stringify(Array.from(this.sourceList)));
      this.targetHeight = this.defaultSourceHeight;
      this.sourceHeight = this.defaultSourceHeight;
      this.updateSourceTargetHeight(false);
    } else {
      sheets.forEach(sheet => {
      this.tableCategoryList.forEach(tableCategory => {
        let categoryTables = this.factorTables.get(tableCategory.value);
        let categoryTable = categoryTables.find(categoryTable => {
          return (StringUtils.isEqualIgnoreCase(categoryTable.displayName, sheet)) ||  (StringUtils.isEqualIgnoreCase(categoryTable.tableName, sheet))
        });
        let isExistInTarget = this.targetList.some((tab) => tab.displayName === categoryTable?.displayName);
        if (categoryTable && !isExistInTarget) {
          this.targetList.push(categoryTable);
          this.updateSelectedFactorTables(tableCategory.value, categoryTable);
          this.sourceList = this.sourceList.filter((table) => table.displayName !== categoryTable.displayName);
        }
      });
    });
    if(this.targetList && this.targetList?.length){
      this.sourceList = this.sourceList.filter((tab,ind) => {
        return this.targetList.findIndex((table) => StringUtils.isEqualIgnoreCase(tab.displayName, table.displayName)) == -1;
      })
    }
    }
    this.sourceList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
  }
  updateSelectedFactorTables(key, factorTable) {
    if (this.selectedFactorTableMap) {
      if (this.selectedFactorTableMap.has(key)) {
        this.selectedFactorTableMap.get(key).push(factorTable);
      } else if (Array.isArray(factorTable)) {
        this.selectedFactorTableMap.set(key, factorTable);
      } else {
        this.selectedFactorTableMap.set(key, [factorTable]);
      }
    }
  }

  fetchFactorTablesValidations() {
    if (this.factorTablesExport.userSelectedSystem?.value){
    this.factorMigrationService.fetchFactorTablesValidation(this.factorTablesExport.userSelectedSystem?.value).subscribe((response) => {
      if (response && response?.length) {
        this.formData = JSON.parse(JSON.stringify(response));
      }else{
        this.formData = [];
      }
    })
  }
  }
  createForm(formdata: any) {
    for (const tab of this.targetList) {
      let selectedTableValidation: any = formdata?.filter((form) => (form.tableName == tab.displayName) || (form.tableName == tab.tableName));
      if (selectedTableValidation && selectedTableValidation?.length) {
        if (this.ui_filter_criteria && this.ui_filter_criteria?.length) {
          this.ui_filter_criteria = this.updateFilterCriteria(selectedTableValidation);
        } else {
          this.ui_filter_criteria = selectedTableValidation;
        }
        this.sortFilterCriteria();
        this.ui_filter_criteria.sort((a, b) => (+a["fieldOrder"] > +b["fieldOrder"]) ? 1 : ((+b["fieldOrder"] > +a["fieldOrder"]) ? -1 : 0));
        for (const control of selectedTableValidation) {
          const validatorsToAdd = [];
          if (StringUtils.isEqual(control.mandatory, 'Y')) {
            validatorsToAdd.push(Validators.required);
          }
          if (!this.dynamic_exportForm.controls[control.fieldName]) {
            this.dynamic_exportForm.addControl(
              control.fieldName,
              this.formBuilder.control('', validatorsToAdd)
            );
          }
          if (StringUtils.isEqual(control.fieldDisabled, 'Yes')) {
            this.dynamic_exportForm.controls[control.fieldName].disable();
          }
        }
      }
    }

  }
  clickedCalendar(dateType, fieldType) {
    let elementId = '#' + dateType;
    if (StringUtils.isEqual(fieldType, CommonConstants.DATE)) {
      let element: HTMLElement = document.querySelector(`${elementId} .p-inputtext`) as HTMLElement;
      this.dateButtonClick(element);
    }
  }
  dateButtonClick(element: HTMLElement) {
    if (!StringUtils.isEmpty(typeof (element))) {
      element.click();
    }
  }
  updateExportPayload() {
    for (const params of this.selectedForm) {
      Object.keys(this.dynamic_exportForm.controls).forEach(key => {
        delete params.fieldDefaultValues;
        delete params.selectedDefaultValue;
        delete params.fieldDisabled
        delete params.fieldLabel
        delete params.fieldOrder
        delete params.tableName
        if (params.fieldName == key) {
          params[CommonConstants.SELECTED_VALUES] = this.dynamic_exportForm.controls[key].value?.toString().replaceAll('"', '');
        }
        if (StringUtils.isEqual(params.fieldType, CommonConstants.DATE)) {
          params.selectedValues = this.dateFormatPipe.transform(params.selectedValues, CommonConstants.DATE_FORMAT);
          params.selectedValues = params.selectedValues? params.selectedValues:"";
        }
      });
    }
  }
  updateFilterCriteria(newValidationList) {
    if (newValidationList && newValidationList?.length) {
      newValidationList.forEach((item) => {
        const newFilterField: any = this.ui_filter_criteria.some((param: any) => param.fieldName === item.fieldName);
        if (!newFilterField) {
          this.ui_filter_criteria.push(item);
        } else {
          let oldFilterField = this.ui_filter_criteria.findIndex((param) => param.fieldName === item.fieldName);
          if (this.ui_filter_criteria[oldFilterField] && this.ui_filter_criteria[oldFilterField]?.['fieldDefaultValues']) {
            this.ui_filter_criteria[oldFilterField]['fieldDefaultValues'] = this.ui_filter_criteria[oldFilterField]['fieldDefaultValues'].concat(item['fieldDefaultValues']);
            let fieldDefaultValues = this.ui_filter_criteria[oldFilterField]['fieldDefaultValues'];
            this.ui_filter_criteria[oldFilterField]['fieldDefaultValues'] = fieldDefaultValues.filter((item, ind, self) => {
              return ind == self.findIndex((tab) => {
                if (tab.value) {
                  return tab.value === item.value;
                } else if (tab.code) {
                  return tab.code === item.code;
                }
              })
            });
          }
        }
      })
    }
    return this.ui_filter_criteria;
  }
  updateSourceList() {
    this.sourceList = [];
    this.tableCategoryList.forEach(tableCategory => {
      let categoryTables = this.factorTables.get(tableCategory.value);
      categoryTables.forEach(categoryTable => {
        if (!this.targetList.some((item) => item.displayName == categoryTable.displayName)) {
          this.sourceList.push(categoryTable);
        }
      });
    });
    this.sourceList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
    this.updateListFromTarget();
  }
  updateListFromTarget() {
    this.targetList.forEach(targetTable => {
      this.originalFactorTableMap.forEach((tables, key) => {
        if (tables.findIndex(table => table.displayName === targetTable.displayName) != -1) {
          let selectedTables = this.selectedFactorTableMap.get(key);
          if (selectedTables) {
            if (selectedTables.findIndex(table => table.displayName === targetTable.displayName) === -1) {
              this.updateSelectedFactorTables(key, tables.find(table => table.displayName === targetTable.displayName));
            }
          } else {
            this.updateSelectedFactorTables(key, tables.find(table => table.displayName === targetTable.displayName));
          }
        }
      });
    });
  }
  sortFilterCriteria(){
    this.ui_filter_criteria.forEach((tab: any) => {
      if(tab.fieldDefaultValues && tab.fieldDefaultValues?.length){
        tab.fieldDefaultValues = tab.fieldDefaultValues.sort((taget1, target2) => {
          if(taget1.value){
          return (taget1.value < target2.value ? -1 : 1);
          } else if(taget1.code){
            return (taget1.code < target2.code ? -1 : 1);
          }
        });
      }
    })
  }

  updateSourceDatabase(){
    if(this.factorTablesExport.selectedEnvironments?.value){
      this.selectedEnvError = false;
    }
  }
  clearPlan() {
    this.file = null;
    this.factorTablesExport.userSelectedSystem = {};
    this.factorTablesExport.fileName='';
    this.ui_filter_criteria = [];
    this.txtUploadFile.clear();
    this.dynamic_exportForm = this.formBuilder.group({});
    this.targetList = [];
    this.selectedFactorTableMap = new Map<string, any>();
    this.sourceList = [];
    this.availableEnvironments = [];
    this.selectedEnvError = false;
    this.systemError = false;
    this.targetListError = false;
    if(this.eventTest) {
      this.eventTest.resetSourceFilter();
      this.eventTest.resetTargetFilter();
    }
    this.removeAlertMsg();
    this.targetHeight = this.defaultSourceHeight;
    this.sourceHeight = this.defaultSourceHeight;
    this.factorTablesExport.tableCategory = [];
    this.showProgress=false;
  }
  removeAlertMsg(){
    this.alert = {
      show: false,
      message: "",
      type: "",
      cssClass: "",
      header: "",
      headerVisibility: true,
    };
  }
  updateSourceTargetHeight(isSource){
    let pickListElement = this.pickList?.listViewSourceChild;
      setTimeout(() => {
        if(isSource){
        this.sourceHeight  = this.targetHeight;
        } else{
          if(pickListElement && pickListElement?.el && pickListElement?.el?.nativeElement?.offsetHeight){
          this.targetHeight  = pickListElement?.el?.nativeElement?.offsetHeight+'px';
          }
        }
        this.updatePickListFilters(false);
    })
  }
  updateTableCategory(event) {
    if (event.value?.length && this.factorTables) {
      const selectedCategory = event.value;
        const factorListTables = JSON.parse(JSON.stringify(Array.from(this.factorTables, ([key, value]) => ({ key, value }))));
        const matchedCategoryList = factorListTables?.filter((tab) => {
          return selectedCategory?.find((category) => tab.key  == category.code)
        });
        if (matchedCategoryList && matchedCategoryList?.length) {
            if(matchedCategoryList?.length && this.targetList){
              this.sourceList= [].concat.apply([],matchedCategoryList.map((tableList,ind) => {
                return tableList.value?.filter((table) => {
                return this.targetList.findIndex((tab)=> StringUtils.isEqualIgnoreCase(table.displayName,tab.displayName)) == -1;
              })
            }));
            }else{
                this.sourceList = [].concat.apply([],matchedCategoryList?.map((tab) => tab.value));
              }
            this.sourceList.sort((tab1, tab2) => (tab1.displayName < tab2.displayName ? -1 : 1));
        }
    }else{
      this.resetSourceTables();
      if(this.targetList && this.targetList?.length){
        this.sourceList = this.sourceList.filter((tab,ind) => {
          return this.targetList.findIndex((table) => StringUtils.isEqualIgnoreCase(tab.displayName, table.displayName)) == -1;
        })
      }
    }
    this.updateSourceTargetHeight(false);
}
resetSourceTables(){
  if(this.originalSourceList?.length){
    this.sourceList = JSON.parse(JSON.stringify(this.originalSourceList));
    this.sourceList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
  }
}
updatePickListFilters(isClearFilter) {
  if (this.pickList) {
    if (isClearFilter) {
      this.pickList.resetFilter();
    } else {
      if (this.pickList.filterValueSource) {
        this.pickList.filterSource(this.pickList.filterValueSource);
      }if(this.pickList.filterValueTarget) {
        this.pickList.filterTarget(this.pickList.filterValueTarget);
      }
    }
    this.pickList.cd.detectChanges();
  }
}

ngOnDestroy() {
  this.eventSources.forEach(source => source.close());
}
}
