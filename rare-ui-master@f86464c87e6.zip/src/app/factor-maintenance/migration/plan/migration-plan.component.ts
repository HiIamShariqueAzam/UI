import { Component, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute, Router } from "@angular/router";
import { migrationPlan } from "../models/migrationPlan";
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { PickList } from 'primeng/picklist';
import { StringUtils } from "../../../shared/utils/string-utils";
import { MigrationService } from "../services/migration.service";
import { Environment, MigrationBaseComponent, MigrationType, System } from "../common/migration-base.component";
import { FactorMigrationConstants } from "../../constants/factor-migration-constants";
import * as XLSX from 'xlsx';
import { FileRemoveEvent, FileUpload, FileUploadEvent } from 'primeng/fileupload';
import { CommonConstants } from "../../../shared/constants/common.constants";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector: "migration-plan",
  templateUrl: "migration-plan.component.html",
  styleUrls: ["migration-plan.component.css"],
  standalone: false,
})
export class MigrationPlanComponent extends MigrationBaseComponent implements OnInit, OnDestroy {
  private eventSources: EventSource[] = [];
  isEmpty: boolean = true;
  targetListError:boolean = false;
  selectedEnvError:boolean = false;
  showNextButton: boolean = false;
  showPrevButton: boolean = false;
  nextButtonClicked: boolean;
  prevButtonClicked: boolean;
  selectedPageSize: any;
  rowsPerPage: any[] = FactorMigrationConstants.ROWS_PER_PAGE;
  onRowSelect: any;
  first = 0;
  rows: any;
  file: File;
  fileName: string = "";
  migrationName: string;
  userSelectedSystem: any;
  fileUpload: boolean = false;
  tableCategory: any;
  systems: System[] = [];
  skipBackupDelete: boolean = false;
  showSkipBackupCheckbox: boolean = false;
  isSkipBackupFeatureEnabled: boolean = false;
  tableCategoryList: any[];
  sourceList: any[] = [];
  targetList: any[] = [];
  disableField: string = 'create';
  sourceHeaderPicklist: string;
  targetHeaderPicklist: string;
  sourcePlaceholder: string;
  migrationPlan: any;
  factorTables = new Map<string, any>();
  eventTest: PickList;
  availableEnvironments: Environment[] = [];
  selectedEnvironments: Environment[];
  originalFactorTableMap = new Map<string, any>();
  selectedFactorTableMap = new Map<string, any>();
  multiSortMeta: any = FactorMigrationConstants.MULTI_SORT_META;
  noData: string = "Not Available";
  stateMap = {};
  statesName:string;
  factorMigrationImportFileSize: number;
  migrationProgressStatus: any[] = [];

  selectedFactorTablesHeaders = [
    {
      header: 'Table Category',
      field: 'TableCatergory'
    },
    {
      header: 'Selected Factor Table List',
      field: 'SelectedFactorTableList'
    },
    {
      header: 'State',
      field: 'State'
    }
  ];

  saveMultiSortMeta(event) {
    this.multiSortMeta = event.multisortmeta;
  }

  selectedOpportunity: any;
  userSelectedMigrationType: any = { label: 'Full', value: 'full' };
  migrationReason: boolean = false;
  migrationTypes: MigrationType[] = FactorMigrationConstants.MIGRATION_TYPES;
  showFileError: boolean = false;
  showSystemError: boolean = false;
  showMigrationNameError: boolean = false;
  showMissingImageUploadError: boolean = false;
  showTableCatError: boolean = false;
  showMigrationTypeError: boolean = false;
  planId: string = "";
  allAvailableLobListForRemove: any[];
  fileMismatchError: boolean = false;
  historyPlanSheet: any;
  isMigrationPlanFailed: boolean = false;
  isLoadResponse: boolean = false;
  duplicatePlanErrorMsg: string = "";
  errorMessage: string = CommonConstants.EMPTY_STRING;
  isExportOnlyError: boolean = false;
  selectedTableList: any[] = [];
  fileSizeError: boolean = false;
  alert = {
    show: false,
    message: "",
    type: "",
    cssClass: "",
    header: "",
    headerVisibility: false,
  };
  unMatchedTables: any[] =[];

  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  showMigrationHistory: boolean = false;
  showStatus: boolean = false;
  migrationStatus: any;
  selectedModalEnvironment: string;
  skipEventListen: boolean;
  progressColumns = [
    {
      header: "Execution Environment ",
      field: "ExecutionEnv",
    },
    {
      header: "Migration Status",
      field: "MigrationStatus"
    }
  ];
  showMigrationTables: boolean = true;
  showImageUploader: boolean = false;
  uploadFiles = null;
  uploadSpreadSheet = [];
  fileNamesMatchUploadedImages: boolean = false;
  imageFileName: string = "Please select image";
  readonly MIGRATION_PLAN_EXISTS = "Migration plan already exists.";
  migrationExecutionStatus:any = {success: 'Success',failed:'Failed'};
  showPartialStatus:  number | null = null;
  factorExecutionStatuses:any = FactorMigrationConstants.FACTOR_EXECUTION_STATUSES;

  @ViewChild('myInput') txtUploadFile: FileUpload;
  @ViewChild('migrationPlanStatus') migrationPlanStatusTemplate;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private factorMigrationService: MigrationService,
    private authenticationService: AuthenticationService,
    private modalService: NgbModal
  ) {
    super();
  }

  ngOnInit() {
   this.factorMigrationImportFileSize = this.commonService.getFactorMigrationImportFileSize();
   this.commonService.getFactorSystems().subscribe((response) => {
   if(response) {
    // Handle response as array of objects (not just strings)
    if (Array.isArray(response)) {
      // Get environment-specific feature flag from first element
      if (response.length > 0 && response[0].FEATURE_ENABLED !== undefined) {
        this.isSkipBackupFeatureEnabled = response[0].FEATURE_ENABLED;
      }
      
      response.forEach((system: any) => {
        const systemName = system.SYSTEM || system;
        if(this.factorMigrationService.verifyUserRolewithSystem(systemName)) {
          this.systems.push({ 
            label: systemName, 
            value: systemName,
            skipBackup: system.SKIP_DATABACKUP || 'N'  // Default to 'N' if undefined
          });
        }
      });
    } else {
      // Backward compatibility for old response format
      for (const system in response) {
        if(this.factorMigrationService.verifyUserRolewithSystem(response[system])) {
          this.systems.push({ 
            label: response[system], 
            value: response[system],
            skipBackup: 'N'
          });
        }
      }
    }
    this.systems.sort((sysPrev, sysNext) => (sysPrev.value < sysNext.value ? -1 : 1));
    this.fetchMigrationPlan();
  }
});
    this.setPicklistTablesHeaders();
    this.migrationPlan = this.migrationPlan ? this.migrationPlan : new migrationPlan();
    if (!this.migrationPlan.uploadFileName) {
      this.migrationPlan.uploadFileName = this.fileName ? this.fileName : '';
    }
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }

  updateMigrationTypeExclusion() {
    if(this.userSelectedSystem.value) {
      if(this.commonService.factorMigrationPartialExclusionSystems && this.commonService.factorMigrationRemoveExclusionSystems.length > 0
        && this.commonService.factorMigrationPartialExclusionSystems.find(system => system === this.userSelectedSystem.value)) {
        this.migrationTypes = this.migrationTypes.filter(migrationType => migrationType.value !== 'partial');
      }
      if ((this.commonService.factorMigrationRemoveExclusionSystems && this.commonService.factorMigrationRemoveExclusionSystems.length > 0
        && this.commonService.factorMigrationRemoveExclusionSystems.find(system => system === this.userSelectedSystem.value)) ||
        (this.factorMigrationService.isActuarialUserRoleOnly() && !this.authenticationService.isUserFactorTable(this.commonService.getUserRoles()))) {
        this.migrationTypes = this.migrationTypes.filter(migrationType => migrationType.value !== 'remove');
      }
    }
  }

  fetchMigrationPlan(skipEventProcessing?) {
    this.route.queryParams.subscribe(param => {
      let params = (param && param.planId)? param : {planId: this.planId};
      if (params && params.planId) {
        this.factorMigrationService.getMigrationByPlanId(params.planId, 'save').subscribe(migrationPlan => {
          this.fileUpload = true;
          this.migrationName = migrationPlan.migrationPlanName;
          this.userSelectedSystem = this.systems.find(system => system.value === migrationPlan.system);
          this.userSelectedMigrationType = this.migrationTypes.find(migrationType => migrationType.value === migrationPlan.typeOfUpdate);
          this.migrationPlan.uploadFileName = migrationPlan.uploadFileName;
          this.migrationReason = StringUtils.isEqual(migrationPlan.migrationReason, CommonConstants.TEST);
          this.skipBackupDelete = migrationPlan.skipBackupDelete || false;
          this.migrationPlan = migrationPlan;
          this.checkSkipBackupDisplay();
          this.isMigrationPlanFailed = false;
          this.fileMismatchError = false;
          if (!this.planId) {
            this.fetchFactorTables();
            this.fetchTargetDatabases();
          }
          this.disableField = this.migrationPlan?.event;
          this.fetchMigrationStatus();
          this.planId = "";
          this.stateMap = migrationPlan.tableStateMapping;
          this.setStates(this.stateMap);
          this.isLoadResponse =  false;
          if (this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory?.length > 0) {
            this.isEmpty = false;
          }
          if(this.migrationPlan.fileSaveStatus && StringUtils.isEqual(this.migrationPlan.fileSaveStatus, CommonConstants.FAILED)) {
            this.isMigrationPlanFailed = true;
          }
          if(!skipEventProcessing) {
            this.processExecuteEvents();
          }
        });
      }
    });
  }

  setStates(states) {
    let statesArray = [];
    if(states){
      Object.values(states).forEach(stateValue => {
        statesArray.push(stateValue)
      });
      statesArray = [].concat(...statesArray);
      statesArray = [...new Set(statesArray)];
      this.statesName = statesArray.toString().replace('[', '').replace(']', '');
    }
    this.statesName = (this.statesName && this.statesName?.length)? this.statesName: 'NA';
  }

  updateMigrationType(event) {
    if (this.userSelectedSystem == undefined) {
      this.showSystemError = true;
    } else {
      this.showSystemError = false;
    }
    if(this.txtUploadFile){
      this.txtUploadFile.clear();
    }
    this.removeFile();
    this.fetchFactorTables();
    this.fetchTargetDatabases();
    this.checkSkipBackupDisplay();
    if (StringUtils.isEqual(this.userSelectedSystem.value, 'RARE')) {
      this.userSelectedMigrationType = {label: 'Partial', value: 'partial'};
    } else {
      this.userSelectedMigrationType = {label: 'Full', value: 'full'};
    }
    this.updateMigrationTypeExclusion();
    this.clearAlert();
  }
  /**
   * Check if skip backup delete checkbox should be displayed
   * Show checkbox ONLY if Feature is enabled in the environment and selected system has SKIP_BACKUP='Y'
   */
   checkSkipBackupDisplay() {
   if (!this.isSkipBackupFeatureEnabled) {
    this.showSkipBackupCheckbox = false;
    this.skipBackupDelete = false;
    return;
   }
  // Check if selected system allows skip backup
  const systemAllowsSkip = this.userSelectedSystem?.skipBackup === 'Y';
  if (!systemAllowsSkip) {
    this.showSkipBackupCheckbox = false;
    this.skipBackupDelete = false;
    return;
  }
  // Show checkbox if both conditions are met
  this.showSkipBackupCheckbox = true;
  }

  fetchFactorTables() {
    if(this.userSelectedSystem?.value){
      this.commonService.getFactorTables(this.userSelectedSystem.value).subscribe((response) =>  {
        this.buildFactorTables(response);
      });
    }
  }

  fetchTargetDatabases() {
    this.availableEnvironments =[];
    if(this.userSelectedSystem?.value){
      this.commonService.getTargetDatabases(this.userSelectedSystem.value, this.migrationReason ? 'TEST': 'REAL').subscribe((response: any) =>  {
        if(response) {
          response.forEach((database) => {
            this.availableEnvironments.push( { name: database.dataBase, code: database.dataBase });
          });
          if (this.migrationPlan && this.migrationPlan.selectedEnvironments) {
            this.selectedEnvironments = [];
            this.migrationPlan.selectedEnvironments.forEach(selectedEnvironment => {
              this.selectedEnvironments.push(this.availableEnvironments.find(availableEnvironment => availableEnvironment.code === selectedEnvironment))
            });
          }
        }
      });
    }
  }

  buildFactorTables(response: any) {
    let fullTablesList: any[] = [];
    let allAvailableLobList: any[] = [];
    this.factorTables = new Map<string, string[]>();
    Object.keys(response).forEach((key) => {
      if (StringUtils.isEqual(key, 'tableCategory')) {
        response[key].forEach(tableCategory => {
          allAvailableLobList.push({
            label: tableCategory.categoryDescription,
            value: tableCategory.categoryName
          });
        });
      } else {
        if(this.factorMigrationService.verifyUserRolewithLOB(key,this.userSelectedSystem.value)){
        this.factorTables.set(key, response[key]);
        fullTablesList.push(response[key]);
        this.commonService.setFullTablesList(fullTablesList);
        }
      }
    });
    this.allAvailableLobListForRemove = allAvailableLobList;
    this.tableCategoryList = allAvailableLobList;
    if(this.migrationPlan && this.migrationPlan.selectedFactorTables) {
      this.selectedFactorTableMap = new Map<string, any>();
      this.migrationPlan.selectedFactorTables.forEach(selectedFactorTable => {
          this.updateSelectedFactorTables(selectedFactorTable.key, selectedFactorTable.value);
          selectedFactorTable.value.forEach(factorTable => this.targetList.push(factorTable));
          this.tableCategory = this.tableCategoryList.find(tableCategory => tableCategory.value === selectedFactorTable.key);
        });
      if (this.targetList && this.targetList.length) {
        const updatedTargetList = this.targetList.filter((tab, ind, tables) => {
          return ind === tables.findIndex((tableObj) => StringUtils.isEqualIgnoreCase(tab.displayName, tableObj.displayName))
        })
        this.targetList = updatedTargetList;
      }
      this.originalFactorTableMap = new Map(JSON.parse(JSON.stringify(Array.from(this.selectedFactorTableMap))));
    }
  }

  setPicklistTablesHeaders() {
    this.sourceHeaderPicklist = 'Available Factor Tables';
    this.targetHeaderPicklist = 'Selected Factor Tables';
    this.sourcePlaceholder = 'Search by table name';
  }

  goToBatchSearch(): void {
    this.router.navigate(["factor-migration"]);
  }

  resetClicked() {
  }

  updateSelectedFactorTables(key, factorTable) {
    if (this.selectedFactorTableMap) {
      if (this.selectedFactorTableMap.has(key)) {
        this.selectedFactorTableMap.get(key).push(factorTable);
      } else if (Array.isArray(factorTable)) {
        this.selectedFactorTableMap.set(key, factorTable);
      } else {
        this.selectedFactorTableMap.set(key, [factorTable]);
      }
    }
  }

  moveToTarget(event) {
    this.targetList.forEach(targetTable => {
      this.originalFactorTableMap.forEach((tables, key) => {
        if(tables.findIndex(table => table.displayName === targetTable.displayName) != -1) {
          let selectedTables = this.selectedFactorTableMap.get(key);
          if(selectedTables) {
            if(selectedTables.findIndex(table => table.displayName === targetTable.displayName) === -1) {
              this.updateSelectedFactorTables(key, tables.find(table => table.displayName === targetTable.displayName));
            }
          } else {
            this.updateSelectedFactorTables(key, tables.find(table => table.displayName === targetTable.displayName));
          }
        }
      });
    });
    this.eventTest = event;
    this.targetList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
    if(this.targetList && this.targetList?.length){
      this.targetListError = false;
    }
  }

  moveToSource(event) {
    this.sourceList.forEach( sourceTable => {
      this.selectedFactorTableMap.forEach((tables, key) => {
        const index = tables.findIndex(table => table.displayName === sourceTable.displayName);
        if(index != -1) {
          tables.splice(index,1);
          if(tables.length === 0) {
            this.selectedFactorTableMap.delete(key);
          }
        }
      });
    });
    this.sourceList.sort((source1, source2) => (source1.displayName < source2.displayName ? -1 : 1));
  }

  clearPlan() {
    this.showFileError = false;
    this.showSystemError = false;
    this.showMigrationNameError = false;
    this.showMigrationTypeError = false;
    this.showTableCatError = false;
    this.file = undefined;
    this.fileUpload = false;
    this.migrationName = CommonConstants.EMPTY_STRING;
    this.userSelectedSystem = null;
    this.userSelectedMigrationType = { label: 'Full', value: 'full' };
    this.tableCategory = undefined;
    this.selectedEnvironments=[];
    this.sourceList = [];
    this.targetList = [];
    this.disableField = 'reset';
    this.targetListError = false;
    this.selectedFactorTableMap = new Map<string, any>();
    this.migrationPlan.selectedFactorTables=undefined;
    this.tableCategoryList = [];
    this.migrationReason = false;
    this.isExportOnlyError = false;
    this.skipBackupDelete = false;
    this.showSkipBackupCheckbox = false;
    this.selectedTableList = [];
    this.targetListError = false;
    this.fileSizeError = false;
    this.setOrRemoveAlertMsg(false, CommonConstants.EMPTY_STRING);
    this.isMigrationPlanFailed = false;
    this.migrationPlan.fileSaveStatus = CommonConstants.EMPTY_STRING;
    this.showMigrationTables = true;
    this.showImageUploader = false;
    this.uploadFiles = null;
  }

  saveOrExecutePlan(event: string) {
    this.clearAlert();
    if (this.checkIfSpreadsheetHasFilenameColumns()) {
      // Check if the uploaded file has non-blank file names, else will check matching with file uploads
      if (this.countFilenames() === 0) {
        this.fileNamesMatchUploadedImages = true;
      } else {
        this.checkMatchingFilenames();
      }
      if (this.showImageUploader && !this.fileNamesMatchUploadedImages) {
        this.showMissingImageUploadError = true;
        return;
      } else {
        this.fileNamesMatchUploadedImages = true;
        this.showMissingImageUploadError = false;
      }
    } else {
      this.showMissingImageUploadError = false;
    }
    this.selectedEnvError=false;
    this.showFileError = StringUtils.isEmpty(this.migrationPlan.uploadFileName) && !this.file;
    (!this.userSelectedSystem) ? (this.showSystemError = true) : (this.showSystemError = false);
    (!this.migrationName) ? (this.showMigrationNameError = true) : (this.showMigrationNameError = false);
    (!this.userSelectedMigrationType?.value) ? (this.showMigrationTypeError = true) : (this.showMigrationTypeError = false);
    (this.tableCategory?.length<1) ? (this.showTableCatError = true) : (this.showTableCatError = false);
    if (this.targetList?.length < 1 && !this.showFileError) {
      this.targetListError = true;
    }
    if (!this.selectedEnvironments?.length && StringUtils.isEqual(event, 'execute')) {
      this.selectedEnvError = true;
    }
    if(StringUtils.isEqual(event, 'save')) {
      this.migrationPlan.processId = '';
    }
    if (!this.showFileError && !this.showSystemError && !this.showMigrationNameError && !this.showMigrationTypeError && !this.showTableCatError && this.targetList.length > 0 && !this.selectedEnvError && !this.fileMismatchError && !this.isExportOnlyError) {
      this.formMigrationPlan(event);
      if (this.file && this.file?.name && this.migrationPlan?.filenetContentID) {
        this.migrationPlan.filenetContentID = "";
      }
      this.isLoadResponse = true;
      this.duplicatePlanErrorMsg = "";
      this.handleSpecialCharactersForXss();
      this.handleSpecialCharactersfactorMigrationStatusForXss();
      this.factorMigrationService.saveMigrationPlanDetails(this.migrationPlan, this.file, this.uploadFiles).subscribe(
        migrationPlan => {
          this.disableField = event;
          this.migrationPlan = migrationPlan;
          this.showImageUploader = false;
          if (migrationPlan.processId) {
            if(StringUtils.isEqual(event, 'execute')) {
              this.setOrRemoveAlertMsg(true, 'Migration plan execution initiated Successfully.', 'alert-success');
              this.processExecuteEvents();
            } else {
              this.processSaveEvents();
            }
          }

          if (StringUtils.isEqualIgnoreCase(event, 'execute')) {
            this.planId = migrationPlan.id;
            this.fetchMigrationPlan();
          } else {
            this.fetchMigrationStatus();
            this.isLoadResponse = false;
          }
          this.file = undefined;
          this.fileMismatchError = false;
          this.targetListError = false;
          if (this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory.length > 0) {
            this.isEmpty = false;
          }
          this.fetchTargetDatabases();
        }, err => {
          this.isLoadResponse = false;
          this.verifyErrors(err);
          if (!StringUtils.isEmpty(this.errorMessage)) {
            this.setOrRemoveAlertMsg(true, this.errorMessage);
          }
        }
      )
    }
  }

  handleSpecialCharactersForXss() {
    if (this.migrationPlan.factorMigrationPlanHistory) {
      this.migrationPlan.factorMigrationPlanHistory.forEach(history => {
        if (history?.factorMigrationStatus) {
          Object.keys(history?.factorMigrationStatus).forEach((env) => {
            this.factorMigrationEnvironmentStatus(history.factorMigrationStatus, env)
          });
        }
      })
    }
  }
  handleSpecialCharactersfactorMigrationStatusForXss() {
    if (this.migrationPlan?.factorMigrationStatus)
      Object.keys(this.migrationPlan?.factorMigrationStatus).forEach((env) => {
        this.factorMigrationEnvironmentStatus(this.migrationPlan?.factorMigrationStatus, env)
      })
  }
  factorMigrationEnvironmentStatus(factorMigrationStatus, env) {
    if (StringUtils.isEqual(factorMigrationStatus[env]?.executionStatus, CommonConstants.FAILED)) {
      factorMigrationStatus[env]?.executionDetails.forEach(sheet => {
        if (sheet?.errors.length > 0 && StringUtils.isEqual(sheet?.status, CommonConstants.FAILED.toLowerCase())) {
          sheet.errors.forEach(errorObject => {
            errorObject.errorMessage = CommonUtil.stringToAscii(errorObject.errorMessage);
          })
        }
        sheet?.migrationSteps?.forEach(migrationStep => {
          migrationStep.step = CommonUtil.stringToAscii(migrationStep.step);
        })
      })
    }
  }
  processExecuteEvents() {

    let eventSourceStream = this.commonService.listenForStream(this.migrationPlan.processId);
    this.eventSources.push(eventSourceStream);
    let allEnvironmentStatus = {};

    eventSourceStream.addEventListener("FACTOR_IMPORT_GENERATION_STATUS", (message: any) => {
      let eventData = JSON.parse(message.data);
      if (eventData && eventData.payload) {
        this.migrationPlan = eventData.payload;
        let env : string = '';
        this.migrationPlan?.selectedEnvironments?.forEach( environment => {
          if(this.migrationPlan?.factorMigrationStatus?.[environment]) {
            env = environment;
          }
        })
        let migrationHistory = {
          environment: env,
          factorMigrationStatus : this.migrationPlan.factorMigrationStatus
        }
        if (this.migrationProgressStatus?.findIndex(history => StringUtils.isEqual(history.environment, migrationHistory.environment)) === -1) {
          this.migrationProgressStatus.push(migrationHistory);
          allEnvironmentStatus[env] = env;
        }

        this.addEventListener(this.migrationPlan.factorMigrationStatus);
        if (this.migrationPlan?.factorMigrationStatus && !StringUtils.isObjectEmpty(allEnvironmentStatus)) {
          let allEnvironmentStatusKeys = Object.keys(allEnvironmentStatus);
          if (allEnvironmentStatusKeys?.length === this.migrationPlan.selectedEnvironments?.length && this.migrationPlan.selectedEnvironments?.every(env => allEnvironmentStatusKeys?.indexOf(env) > -1) && 
          this.migrationPlan.selectedEnvironments?.length === this.migrationProgressStatus?.length) {
            eventSourceStream.close();
            this.setOrRemoveAlertMsg(false, '');
            allEnvironmentStatus = {};
          }
        }
      }
    });
     eventSourceStream.addEventListener(CommonConstants.FAILED, (message: any) => {
      eventSourceStream.close();
      this.setOrRemoveAlertMsg(false,'');
      this.showProgress=true;
      let eventData = JSON.parse(message.data);
      console.error("Received event : ", JSON.stringify(message.data));
      this.progressPercent = 100;
      this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
      this.progressMessage = eventData.message;
      
      setTimeout(() => {
        //this.showProgress = false;
      }, this.commonService.getProgressBarTimeOut());
    });

    eventSourceStream.addEventListener('error', (message: any) => {
      eventSourceStream.close();
    });
  }

  processSaveEvents() {
    let eventSourceStream = this.commonService.listenForStream(this.migrationPlan.processId);
    this.eventSources.push(eventSourceStream);

    eventSourceStream.addEventListener("DATA_MIGRATION_FILE_SAVE_START", (event: any) => {
      this.showProgress = true;
      this.progressPercent = 1;
      this.progressStyle = "progress-bar-warning";
      if (event && event.data) {
        this.progressStyle = CommonConstants.EMPTY_STRING;
        this.progressPercent = 30;
        let eventData = JSON.parse(event.data);
        this.progressMessage = eventData.message;
      }
    });

    eventSourceStream.addEventListener("DATA_MIGRATION_IMAGE_SAVE_START", (event: any) => {
      if (event && event.data) {
        this.progressStyle = CommonConstants.EMPTY_STRING;
        this.progressPercent = 40;
        let eventData = JSON.parse(event.data);
        this.progressMessage = eventData.message;
      }
    });

    eventSourceStream.addEventListener("DATA_MIGRATION_IMAGE_SAVE_COMPLETE", (event: any) => {
      if (event && event.data) {
        this.progressStyle = CommonConstants.EMPTY_STRING;
        this.progressPercent = 70;
        let eventData = JSON.parse(event.data);
        this.progressMessage = eventData.message;
      }
    });

    eventSourceStream.addEventListener("DATA_MIGRATION_FILE_SAVE_COMPLETE", (event: any) => {
      if (event && event.data) {
        this.progressStyle = CommonConstants.EMPTY_STRING;
        this.progressPercent = 90;
        let eventData = JSON.parse(event.data);
        if (eventData && eventData.payload) {
          this.progressMessage = eventData.message;
          this.migrationPlan = eventData.payload;
          this.fetchMigrationStatus();
        }
      }
    });

    /**
     * Expected as last SSE event in the stream, this one closes the listener
     */
    eventSourceStream.addEventListener("DATA_MIGRATION_FILE_SAVE_STATUS_COMPLETE", (event: any) => {
      eventSourceStream.close();
      this.commonService.cleanUpSSEEvents(this.migrationPlan.processId);
      if (event && event.data) {
        this.progressStyle = "progress-bar-success";
        this.progressPercent = 100;
        let eventData = JSON.parse(event.data);
        if (eventData && eventData.payload) {
          this.progressMessage = eventData.message;
          this.migrationPlan = eventData.payload;
          this.fetchMigrationStatus();
        }
      }
      setTimeout(() => {
        this.showProgress = false;
      }, this.commonService.getProgressBarTimeOut());
    });

    eventSourceStream.addEventListener(CommonConstants.FAILED, (message: any) => {
      eventSourceStream.close();
      let eventData = JSON.parse(message.data);
      console.error("Received event : ", JSON.stringify(message.data));
      this.showProgress = true;
      this.progressPercent = 100;
      this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
      this.progressMessage = eventData.message;
      if (eventData && eventData.payload) {
        this.migrationPlan = eventData.payload;
        this.fetchMigrationStatus();
      }
      setTimeout(() => {
        //this.showProgress = false;
      }, this.commonService.getProgressBarTimeOut());
    });
  }

  formMigrationPlan(event): void {
    this.migrationPlan = this.migrationPlan ? this.migrationPlan : new migrationPlan();
    this.migrationPlan.migrationPlanName = this.migrationName;
    this.migrationPlan.system = this.userSelectedSystem.value;
    this.migrationPlan.tableCategory = Array.from(this.selectedFactorTableMap.keys());
    this.migrationPlan.typeOfUpdate = this.userSelectedMigrationType.value;
    this.migrationPlan.migrationReason = this.migrationReason ? 'TEST': 'REAL';
    this.migrationPlan.skipBackupDelete = this.skipBackupDelete;
    this.migrationPlan.tableStateMapping = this.stateMap;
    if (this.selectedEnvironments && this.selectedEnvironments.length > 0) {
      this.migrationPlan.selectedEnvironments = [];
      this.selectedEnvironments.forEach(selectedEnvironment => this.migrationPlan.selectedEnvironments.push(selectedEnvironment.code));
    }
    if (this.selectedFactorTableMap) {
      this.migrationPlan.selectedFactorTables = [];
      this.migrationPlan.tableCategory.forEach(tableCategory => {
        this.migrationPlan.selectedFactorTables.push({
          key: tableCategory,
          value: Array.from(this.selectedFactorTableMap.get(tableCategory))
        })
      });
    }
    this.migrationPlan.event = event;
    if (!this.migrationPlan.uploadFileName) {
      this.migrationPlan.uploadFileName = this.fileName ? this.fileName : '';
    }
  }

  myUploader(event) {
    this.disableField = 'create';
    this.file = event.files[0];
    this.showFileError = false;
    this.fileSizeError = false;
    this.isLoadResponse = false;
    this.fileName = event.files[0].name;
    this.selectedFactorTableMap = new Map<string, any>();
    const isFileSizeAllow = this.fileSizeComparision(event.files[0].size, 2);
    if(!isFileSizeAllow){
      this.fileSizeError = !isFileSizeAllow;
      const msg = `Please upload a file with file size not greater than ${this.factorMigrationImportFileSize}MB`
      this.setOrRemoveAlertMsg(true, msg);
      return;
    }
    this.showMigrationTables = false;
    const reader: FileReader = new FileReader();
    reader.readAsBinaryString(event.files[0]);
    let stateList = [];
    reader.onload = async (data: any) => {
      /* read workbook */
      const workBook: XLSX.WorkBook = XLSX.read(data.target.result, { type: 'binary' });
      let sheets = workBook.SheetNames;
      this.showImageUploader = await this.checkForBlobColumns(sheets, this.userSelectedSystem?.value);
      sheets.forEach(sheet => {
        const ws: XLSX.WorkSheet = workBook.Sheets[sheet];
        const sheetData = XLSX.utils.sheet_to_json(ws);
        this.uploadSpreadSheet = [];
        this.uploadSpreadSheet.push(sheetData);
        let states = [];
        sheetData.forEach(stateCode => {
          if (stateCode['ST_CD']) {
            if (!StringUtils.isEmpty(stateCode['ST_CD']))
              states.push(stateCode['ST_CD'])
          }
          if (stateCode['STATE']) {
            if (!StringUtils.isEmpty(stateCode['STATE']))
              states.push(stateCode['STATE'])
          }
        })
        states = [...new Set(states)];
        let isVerifiedTable=false;
        this.tableCategoryList?.forEach(tableCategory => {
          let categoryTables = this.factorTables.get(tableCategory.value);
          let categoryTable = categoryTables?.find(categoryTable => {
            if(StringUtils.isEqualIgnoreCase(categoryTable.displayName, sheet)){
              isVerifiedTable = false;
            } else if(StringUtils.isEqualIgnoreCase(categoryTable.tableName, sheet)){
              isVerifiedTable = true;
            }
            return (StringUtils.isEqualIgnoreCase(categoryTable.displayName, sheet)) || (StringUtils.isEqualIgnoreCase(categoryTable.tableName, sheet))
          });
          let isDuplicateTabMatch =  this.sheetNameValidation(categoryTable,tableCategory, isVerifiedTable);
          if (categoryTable && !isDuplicateTabMatch) {
            stateList.push(states);
            this.stateMap[categoryTable.displayName] = states;
            this.targetList.push(categoryTable);
            this.updateSelectedFactorTables(tableCategory.value, categoryTable);
            this.originalFactorTableMap = new Map(JSON.parse(JSON.stringify(Array.from(this.selectedFactorTableMap))));
          } else {
            //TODO: Display error that Sheet doesn't have matching Table. Please check and upload the right file
            // for the selected system
          }
        });
      });
      if(stateList) {
        stateList = [].concat(...stateList);
        stateList = [...new Set(stateList)];
        this.statesName = stateList.toString().replace('[', '').replace(']', '');
      }
      this.statesName = (this.statesName && this.statesName?.length)? this.statesName: 'NA';

      this.fileUpload = true;
      this.migrationPlan.selectedFactorTables = this.selectedFactorTableMap;
      this.originalFactorTableMap = new Map(JSON.parse(JSON.stringify(Array.from(this.selectedFactorTableMap))));
      let categories: any[] = [];
      Array.from(this.selectedFactorTableMap.keys()).forEach(key => {
        categories.push(this.tableCategoryList.find(tableCategory => StringUtils.isEqual(tableCategory.value, key)))
      });
      this.tableCategoryList = this.tableCategory = categories;
      this.validateSelectedTables();
      this.validateUploadedTables(sheets);
      this.showMigrationTables = true;
    }
  }

  nextClicked() {
    if (this.showNextButton) {
      this.nextButtonClicked = true;
      // this.searchClicked();
      this.nextButtonClicked = false;
    }
  }

  prevClicked() {
    if (this.showPrevButton) {
      this.prevButtonClicked = true;
      // this.searchClicked();
      this.prevButtonClicked = false;
    }
  }

  searchClicked(isRefresh?: boolean) {
    if (isRefresh) {
      this.factorMigrationService.fetchMigrationPlans().subscribe(
        response => {
          if (response !== null)
            this.isEmpty = false;
          response.forEach(migrationPlan => {
              // this.migrationPlans.push({
              //   migrationPlanName: migrationPlan.migrationPlanName,
              //   createdUser: migrationPlan.createdUser,
              //   createdTime: migrationPlan.createdTime,
              //   updatedUser: migrationPlan.updatedUser,
              //   updatedTime: migrationPlan.lastUpdatedTime,
              //   migratedEnv: "",
              //   id: migrationPlan.id
              // });
            }
          );
        });
    }
  }

  getwidth(column) {
    let width = "16.6%";
    return width;
  }

  paginate(event) {
    // this.pageIndex = event.first / event.rows + 1;
    //this.storage.set("batchfirst", event.first);
    //this.storage.set("batchpageIndex", this.pageIndex);
  }

  onFileUpload() {
    //TODO:Sukumar
  }

  disableUploadBtn() {
    //TODO:Sukumar
  }

  /**
   * Called when removing the sheet from the file upload
   */
  removeFile() {
    this.duplicatePlanErrorMsg = CommonConstants.EMPTY_STRING;
    this.showImageUploader = false;
    this.showMissingImageUploadError = false;
    this.file = undefined;
    this.fileUpload = false;
    this.selectedFactorTableMap = new Map<string, any>();
    this.targetList = [];
    this.tableCategory = undefined;
    this.targetListError=false;
    this.isExportOnlyError = false;
    this.selectedTableList = [];
    this.migrationPlan.selectedFactorTables=undefined;
    this.tableCategoryList = this.allAvailableLobListForRemove;
    this.migrationPlan.uploadFileName = CommonConstants.EMPTY_STRING;
    this.uploadFiles = null;
    this.sourceList = [];
    this.fileSizeError = false;
    this.isLoadResponse = false;
    this.setOrRemoveAlertMsg(false, '');
  }

  downloadMigrationFile(migrationFileID){
    if(migrationFileID){
      this.factorMigrationService.getMigrationFileFromFilenet(migrationFileID).subscribe(response => {
        if (response != null) {
          let contentData = response.contentData ? response.contentData : this.noData;
          let contentName = response.contentName ? response.contentName : this.noData;
          const arrayBuffer = this.base64ToArrayBuffer(contentData);
          this.createAndDownloadBlobFile(arrayBuffer, contentName);
        }
      },error => {
        console.error(error);
      });
    }
  }

  fetchMigrationStatus() {
    let migrationPlanStatus: any[] = [];
    if (this.migrationPlan && this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory.length) {
      this.showMigrationHistory = true;
      this.migrationPlan.factorMigrationPlanHistory.forEach((plan) => {
        migrationPlanStatus = [];
        let matchedEnviornment = plan.targetEnvironments.split(',');
        if (plan.factorMigrationStatus) {
          Object.keys(plan.factorMigrationStatus).forEach((status) => {
            if (matchedEnviornment.indexOf(status) != -1) {
              migrationPlanStatus.push({ environment: status });
              plan.factorMigrationStatus[status].executionDetails.forEach((planList) => {
                if (migrationPlanStatus && !migrationPlanStatus[migrationPlanStatus.length - 1]['executionDetails']) {
                  migrationPlanStatus[migrationPlanStatus.length - 1]['executionDetails'] = []
                }
                if (migrationPlanStatus && migrationPlanStatus.length) {
                  migrationPlanStatus[migrationPlanStatus?.length - 1]['executionDetails'].push({
                    status: planList.status, sheetName: planList.sheetName, errorList: planList.errors,
                    dataRemoveFileNetID: plan.factorMigrationStatus[status]?.dataRemoveFileNetID,
                    filenetContentID: plan.filenetContentID,cacheRefreshStatus: planList.cacheRefreshStatus,
                    deletedBackupStatus: planList.deletedBackupStatus
                  })
                }
              })
              plan['MigratedStatus'] = migrationPlanStatus;
            }
          })
        }
      })
      this.updatedMigrationStatusHistory();
    }
  }

  updatedMigrationStatusHistory() {
    let migrationStatus = this.migrationPlan.factorMigrationPlanHistory;
    let statusSuccess = 'success', statusFailed = 'failed';
    let obj: any = new Object();
    obj.fileName = this.migrationPlan.uploadFileName;
    obj.filenetContentID = this.migrationPlan.filenetContentID;
    this.isMigrationPlanFailed = false;
    this.showPartialStatus = null;
    this.historyPlanSheet = Object.freeze(obj);
    if (this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory.length > 0) {
      let lastPlanExecutionHistory =  this.migrationPlan.factorMigrationPlanHistory[this.migrationPlan.factorMigrationPlanHistory.length - 1];
      if (lastPlanExecutionHistory?.factorMigrationStatus) {
        Object.keys(lastPlanExecutionHistory.factorMigrationStatus).forEach((key) => {

          if(lastPlanExecutionHistory.factorMigrationStatus[key]){
            if(StringUtils.isEqualIgnoreCase(lastPlanExecutionHistory.factorMigrationStatus[key]?.executionStatus, statusFailed)){
              this.isMigrationPlanFailed = true;
            }
          }
        })
      }
      if (this.isMigrationPlanFailed && !StringUtils.isEqualIgnoreCase(this.disableField,"save")) {
        this.migrationPlan.filenetContentID = "";
        this.migrationPlan.uploadFileName = "";
      } else {
        this.migrationPlan.uploadFileName = this.historyPlanSheet.fileName;
        this.migrationPlan.filenetContentID = this.historyPlanSheet.filenetContentID;
      }
    }
    migrationStatus.forEach((plan) => {
      if (plan.MigratedStatus && plan.MigratedStatus.length) {
        plan.MigratedStatus.forEach((planHistory) => {
          planHistory.isExecutionFailed  = false;
          planHistory.cacheRefreshStatus = statusSuccess;
           planHistory.deletedBackupStatus = statusSuccess;
          if (planHistory.executionDetails?.every((history) => history.status == statusSuccess && history.errorList?.length == 0 && history.cacheRefreshStatus !== 'failed')) {
            planHistory.executionStatus = statusSuccess;
            planHistory = this.updateFileUploadDetails(planHistory);
          } else {
            const isCacheRefreshFailed = planHistory.executionDetails?.every((history) => history.status == statusSuccess) && planHistory.executionDetails?.some((history) => history.cacheRefreshStatus == 'failed');
            if(isCacheRefreshFailed){
              planHistory.executionStatus = statusSuccess;
              planHistory.cacheRefreshStatus = statusFailed;
              planHistory = this.updateFileUploadDetails(planHistory);
              this.migrationPlan.uploadFileName = this.historyPlanSheet.fileName;
              this.migrationPlan.filenetContentID = this.historyPlanSheet.filenetContentID;
            }else{
            planHistory.executionStatus = statusFailed;
            if (!Array.isArray(planHistory.errorList)) {
              planHistory.errorList = [];
            }
            planHistory.executionDetails?.forEach((err) => {
              let errorDetails: any = err.errorList;
              if (errorDetails && errorDetails?.length) {
                errorDetails.forEach((error) => {
                  error['sheetName'] = err.sheetName;
                  planHistory.errorList.push(error);
                  if(!StringUtils.isUndefined(error.errorMessage))
                  error.errorMessage = CommonUtil.asciiToCharacter(error.errorMessage);
                })
              }
              planHistory.sheetName = err.sheetName;
              planHistory.dataRemoveFileNetID = err.dataRemoveFileNetID;
              planHistory.filenetContentID = err.filenetContentID;
            })
          }
          }
          if(planHistory.executionDetails?.some((history) => history.deletedBackupStatus == 'FAILED')){
              planHistory.deletedBackupStatus = statusFailed;
            }
        })
        if (plan.MigratedStatus.some((status) => StringUtils.isEqual(status.executionStatus, statusFailed))) {
          plan.MigratedStatus.forEach((status) => status.isExecutionFailed = true);
        }
      }
    })
  }

  renderFactorErrors(migrateErrors: any) {
    var displayableErrors: string;
    if (migrateErrors && migrateErrors.errorList) {
      let errMsgs = [];
      for (let error of migrateErrors.errorList) {
        if (!errMsgs.includes(error.sheetName)) {
          errMsgs.push(error.sheetName);
          if (displayableErrors)
            displayableErrors = displayableErrors + " , " + (error.sheetName + ": " + error.errorMessage);
          else displayableErrors = error.sheetName + ": " + error.errorMessage;
        }
      }
    }
    return displayableErrors;
  }
  migrationUpload(event) {
    this.file = event.files[0];
    this.showFileError = false;
    const reader: FileReader = new FileReader();
    reader.readAsBinaryString(event.files[0]);
    let stateList = [];
    reader.onload = (data: any) => {
      const workBook: XLSX.WorkBook = XLSX.read(data.target.result, { type: 'binary' });
      let sheets = workBook.SheetNames;
      let sheetMatchedList: any = [];
      sheets.forEach(sheet => {
        const ws: XLSX.WorkSheet = workBook.Sheets[sheet];
        const sheetData = XLSX.utils.sheet_to_json(ws);
        let states = [];
        sheetData.forEach(stateCode => {
          if (stateCode['ST_CD']) {
            if (!StringUtils.isEmpty(stateCode['ST_CD']))
              states.push(stateCode['ST_CD'])
          }
          if (stateCode['STATE']) {
            if (!StringUtils.isEmpty(stateCode['STATE']))
              states.push(stateCode['STATE'])
          }
        })
        states = [...new Set(states)];
        this.tableCategoryList.forEach(tableCategory => {
          let categoryTables = this.factorTables.get(tableCategory.value);
          let categoryTable = categoryTables?.find(categoryTable => {
            return (StringUtils.isEqualIgnoreCase(categoryTable.displayName, sheet)) || (StringUtils.isEqualIgnoreCase(categoryTable.tableName, sheet))
          });
          if (categoryTable) {
            stateList.push(states);
            sheetMatchedList.push(categoryTable);
            this.stateMap[categoryTable.displayName] = states;
            this.originalFactorTableMap = new Map(JSON.parse(JSON.stringify(Array.from(this.selectedFactorTableMap))));
          }
        });
      });

      if (stateList) {
        stateList = [].concat(...stateList);
        stateList = [...new Set(stateList)];
      }
      stateList = (stateList && stateList?.length) ? stateList : ['NA']

      this.sheetValidations(stateList, sheetMatchedList, event);
      this.fileUpload = true;
    }
  }
  removeSelectedFile(){
    this.file = undefined;
    this.fileMismatchError = false;
  }
  sheetValidations(stateList, sheetMatchedList, event) {
    if (sheetMatchedList && sheetMatchedList?.length && sheetMatchedList?.length === this.targetList?.length) {
      let validateMatchedList = sheetMatchedList.filter((plan) => {
        return this.targetList.find((sheet) => sheet.tableName == plan.tableName);
      })
      if (validateMatchedList && validateMatchedList?.length == this.targetList?.length) {
        this.fileMismatchError = false;
        this.migrationPlan.uploadFileName = event.files[0].name;
        if (stateList) {
          this.statesName = stateList.toString().replace('[', '').replace(']', '');
        }
      } else {
        this.fileMismatchError = true;
      }
    } else {
      this.fileMismatchError = true;
    }
  }

  verifyErrors(err) {
    if (err.error?.exceptions?.exceptions) {
      let exception = err.error?.exceptions?.exceptions;
      if (exception && exception.length) {
        exception.forEach((e) => {
          if (StringUtils.isEqualIgnoreCase(this.MIGRATION_PLAN_EXISTS, e.message)) {
            this.duplicatePlanErrorMsg = e.message;
          } else {
            this.errorMessage += e.message;
          }
        })
      }
    }
  }
  changeDatabase() {
    if (this.selectedEnvironments && this.selectedEnvironments?.length) {
      this.selectedEnvError = false;
    }
  }
  validateSelectedTables() {
    this.isExportOnlyError = false;
    this.selectedTableList = [];
    this.selectedTableList = this.targetList.filter((tab) => tab.exportOnly === 'Y');
    if (this.selectedTableList?.length) {
      this.isExportOnlyError = true;
    }
  }
  migrationNameChange(){
    if(this.migrationName){
      this.showMigrationNameError = false;
    }
  }
  sheetNameValidation(matchedTable,lob, isVerifiedTable){
    let allFactorKeys = [].concat(...Array.from(this.factorTables.keys()));
    let isDuplicateMatch = false;
    if(matchedTable && allFactorKeys && allFactorKeys?.length && isVerifiedTable){
      allFactorKeys = allFactorKeys.filter(key => key != lob?.value);
      allFactorKeys.forEach((item)=>{
        let categoryTables = this.factorTables.get(item);
        if(categoryTables.some((tab) => tab.tableName === matchedTable.tableName)){
          isDuplicateMatch = true;
        }
      })
    }
    return isDuplicateMatch;
  }
  fileSizeComparision(bytes, decimals) {
    let isFileSizeAllow = true;
    if (!bytes) return false;
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    const fileSizesAfterMB = ['GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const fileDimension ='MB';
    if(fileSizesAfterMB.indexOf(sizes[i]) != -1){
      isFileSizeAllow = false;
    }
    const fileSize:any = parseFloat((bytes / Math.pow(k, i)).toFixed(dm));
    if(fileSize && parseFloat(fileSize) > this.factorMigrationImportFileSize && sizes[i] == fileDimension){
      isFileSizeAllow = false;
    }
    return isFileSizeAllow;
  }

  setOrRemoveAlertMsg(isVisible, msg, alertClass?){
    this.alert = {
      show: isVisible,
      message: msg,
      type: "",
      cssClass: alertClass? alertClass: "alert-danger",
      header: "",
      headerVisibility: isVisible,
    };
  }
  validateUploadedTables(sheets) {
    let msg = '', isSheetMismatch = false;
    const alertClass = 'alert-warning';
    if (sheets && sheets?.length) {
      this.unMatchedTables = sheets.filter((tab) => this.targetList?.findIndex((table) => {
        return StringUtils.isEqualIgnoreCase(table.displayName, tab)
      }) == -1)
    }
    if (this.unMatchedTables?.length == 1) {
      msg = `The sheet name ${this.unMatchedTables.toString()} is not matching to the database tables. Please check and update the sheet name.`;
    } else if (this.unMatchedTables?.length) {
      msg = `The sheet names ${this.unMatchedTables.toString()} are not matching to the database tables. Please check and update the sheet names.`;
    }
    if(msg){
      isSheetMismatch = true;
    }
    this.setOrRemoveAlertMsg(isSheetMismatch, msg, alertClass);
  }

  viewMigrationStatus(migrationPlanHistory, environment, skipListening) {
    this.showStatus = true;
    this.skipEventListen = skipListening;
    this.selectedModalEnvironment = environment;
    this.migrationStatus = migrationPlanHistory?.factorMigrationStatus;
    if (this.migrationPlanStatusTemplate) {
      this.modalService.open(this.migrationPlanStatusTemplate, { backdrop: 'static' });
    }
  }

  addEventListener(factorMigrationStatus) {
    let processId;
    Object.keys(factorMigrationStatus).forEach((status) => {
      processId = factorMigrationStatus[status].execProcessId;
    });

    let eventSourceStream = this.commonService.listenForStream(processId);
    this.eventSources.push(eventSourceStream);

    eventSourceStream.addEventListener("FACTOR_IMPORT_GENERATION_STATUS", (event: any) => {
      let eventData = JSON.parse(event.data);
      if (eventData && eventData?.payload && eventData?.payload?.factorMigrationStatus) {
        factorMigrationStatus = eventData?.payload?.factorMigrationStatus;
        let objIndex = this.migrationProgressStatus?.findIndex(history => StringUtils.isEqual(history.environment, Object.keys(factorMigrationStatus)[0]));
        if (objIndex !== -1) {
          this.migrationProgressStatus[objIndex].factorMigrationStatus = factorMigrationStatus;
          this.migrationStatus = factorMigrationStatus;
        }
      }
    });

    eventSourceStream.addEventListener("FACTORS_IMPORTED", (event: any) => {
      let eventData = JSON.parse(event.data);
      if (eventData && eventData?.payload && eventData?.payload?.factorMigrationStatus) {
        factorMigrationStatus = eventData?.payload?.factorMigrationStatus;
        let objIndex = this.migrationProgressStatus?.findIndex(history => StringUtils.isEqual(history.environment, Object.keys(factorMigrationStatus)[0]));
        if (objIndex !== -1) {
          this.migrationProgressStatus[objIndex].factorMigrationStatus = factorMigrationStatus;
          this.migrationStatus = factorMigrationStatus;
        }
      }
    });

    eventSourceStream.addEventListener("FACTOR_IMPORT_GENERATION_STATUS_COMPLETE", (event: any) => {
      eventSourceStream.close();
     this.processEventData(event.data);
    });

    eventSourceStream.addEventListener(CommonConstants.FAILED, (event: any) => {
      eventSourceStream.close();
      this.processEventData(event.data);
    });

  }

  processEventData(data) {
    let eventData = JSON.parse(data);
    let factorMigrationStatus: any;
    if (eventData && eventData?.payload && eventData?.payload?.factorMigrationStatus) {
      factorMigrationStatus = eventData?.payload?.factorMigrationStatus;
      this.migrationStatus = factorMigrationStatus;
    }
    if (this.migrationProgressStatus.length > 0 && factorMigrationStatus) {
      let env = Object.keys(factorMigrationStatus)[0];
      let index = this.migrationProgressStatus.findIndex( status => status.environment === env);
      if (index !== -1) {
        this.migrationProgressStatus.splice(index, 1);
      }
      if (this.migrationProgressStatus.length === 0) {
        this.migrationProgressStatus = [];
        this.planId = this.migrationPlan.id;
        this.fetchMigrationPlan(true);
        this.commonService.cleanUpSSEEvents(factorMigrationStatus[env].execProcessId);
        this.commonService.cleanUpSSEEvents(this.migrationPlan.processId);
      }
    }
  }

  /**
   * Calls factor/metadata API to check if the tables contain blob columns
   * @param tables
   */
  checkForBlobColumns(tables, system: string): Promise<boolean> {
    const commaDelimitedString = (tables || []).join(",") || "";

    return this.commonService.getFactorTableMetadata(commaDelimitedString, system).toPromise()
        .then(response => {
          return response && this.checkFactorMetadataForBlob(response);
        })
        .catch(error => {
          console.error(error);
          return false;
        });
  }

  /**
   * Checks if the factor metadata contains any blob columns
   * Expects an object with table names as keys and array metadata object as values
   * @param tables
   */
  checkFactorMetadataForBlob(tables) {
    let hasBlob = false;
    Object.keys(tables).forEach(system => {
      tables[system].forEach(table => {
        if (StringUtils.isEqualIgnoreCase(table.hasBlobColumns, CommonConstants.YES)) {
          hasBlob = true;
        }
      });
    });
    return hasBlob;
  }

  /**
   * Check spreadsheet for _FILENAME columns
   * If _FILENAME column are present but has empty values, returns false
   */
  checkIfSpreadsheetHasFilenameColumns() {
    let hasFilenameColumns = false;
    this.uploadSpreadSheet.forEach(sheet => {
      sheet.forEach(row => {
        if (Object.keys(row).some(key => key.endsWith('_FILENAME'))) {
          hasFilenameColumns = true;
        }
      })
    })
    return hasFilenameColumns;
  }
  /**
   * Compares all Worksheet FILENAME column values with uploaded file names
   */
  checkMatchingFilenames() {
    if (this.uploadFiles && this.uploadFiles?.length > 0) {
      let checkAllFilesUploaded = true;
      this.uploadSpreadSheet.forEach(sheet => {
        sheet.forEach(row => {
          Object.keys(row).forEach(key => {
            if (key.endsWith('_FILENAME')) {
              if (row[key] && !StringUtils.isEmpty(row[key]) && !this.checkUploadedFiles(row[key])) {
                checkAllFilesUploaded = false;
              }
            }
          });
        })
      })
      this.fileNamesMatchUploadedImages = checkAllFilesUploaded;
    } else {
      this.fileNamesMatchUploadedImages = false;
    }
  }

  /**
   * Counts the number of file names in FILENAME columns in the spreadsheet
   * Blank spaces also will not count, and numbers will be ignored
   */
  countFilenames() {
    let count = 0;
    this.uploadSpreadSheet.forEach(sheet => {
      sheet.forEach(row => {
        Object.keys(row).forEach(key => {
          if (key.endsWith('_FILENAME')) {
            if (row[key] && row[key].trim && !StringUtils.isEmpty(row[key].trim())) {
              count++;
            }
          }
        });
      })
    })
    return count;
  }

  /**
   * Returns true if the file name is found in the list of uploaded files
   * @param fileName name of the file in the spreadsheet field
   */
  checkUploadedFiles(fileName: string) {
    return this.uploadFiles?.some(file =>
        StringUtils.isEqualIgnoreCase(fileName, file.name)
    );
  }

  /**
   * Handles the file uploads to the server
   * @param event contains the up-to-date list of uploaded files
   */
  handleUploadFile(event: FileUploadEvent) {
    this.duplicatePlanErrorMsg = CommonConstants.EMPTY_STRING;
    this.uploadFiles = null;
    this.uploadFiles = event.files;
    this.imageFileName = null;
    this.showMissingImageUploadError = false;
    this.checkMatchingFilenames();
    this.clearAlert();
  }

  /**
   * Removes the image file from the list of uploaded files
   * @param event contains the file to be removed
   */
  removeImageFile(event: FileRemoveEvent) {
    this.duplicatePlanErrorMsg = CommonConstants.EMPTY_STRING;
    this.showMissingImageUploadError = false;
    this.uploadFiles = this.uploadFiles.filter(file => file !== event.file);
    if (this.uploadFiles.length === 0) {
      this.imageFileName = "Please select an image"
    }
    this.checkMatchingFilenames();
    this.clearAlert();
  }

  /**
   * Clears the alert message at top of Migration page
   */
  clearAlert() {
    this.showProgress = false;
    this.setOrRemoveAlertMsg(false, '');
    this.errorMessage = CommonConstants.EMPTY_STRING;
    this.duplicatePlanErrorMsg = CommonConstants.EMPTY_STRING;
  }

  onMigrationTypeChange() {
    this.clearAlert();
  }
  updateFileUploadDetails(planHistory) {
    planHistory.executionDetails?.forEach((err) => {
      planHistory.dataRemoveFileNetID = err.dataRemoveFileNetID;
      planHistory.filenetContentID = err.filenetContentID;
    });
    return planHistory;
  }

  protected readonly Object = Object;
}
