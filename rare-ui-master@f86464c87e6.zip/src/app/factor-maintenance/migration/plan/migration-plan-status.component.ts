import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  OnInit,
  OnDestroy,
  SimpleChanges,
  ElementRef,
  ViewChild,
  AfterViewInit
} from "@angular/core";
import {NgbModalConfig, NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {StringUtils} from "../../../shared/utils/string-utils";
import {CommonService} from "../../../shared/services";
import {CommonConstants} from "../../../shared/constants/common.constants";
import { CommonUtil } from "src/app/shared/utils/common-util";

@Component({
  selector:'migration-plan-status',
  templateUrl: "migration-plan-status.component.html",
  styleUrls: ["migration-plan.component.css"],
  standalone: false,
  providers: [NgbModalConfig, NgbModal]
})
export class MigrationPlanStatusComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {

  @ViewChild('modalContent', { static: false }) modalContent!: ElementRef;
  @ViewChild('modalHeader', { static: false }) modalHeader!: ElementRef;
  @ViewChild('modalFooter', { static: false }) modalFooter!: ElementRef;
  @Output() close = new EventEmitter<void>();
  private eventSources: EventSource[] = [];
  @Input() migrationStatus: any;
  @Input() environment: string;
  @Input() skipEventListen: boolean;
  showProgress: boolean;
  progressPercent: number;
  progressMessage: any;
  progressStyle: string;
  planStatus: any;

  columns = [
    {
      header: "Table Name",
      field: "ExecutedBy",
    },
    {
      header: "Migration Status",
      field: "ExecutedDate"
    }
  ];
  constructor( config: NgbModalConfig, private commonService: CommonService) {
    config.backdrop = "static";
    config.keyboard = false;
  }



  ngAfterViewInit(): void {
    const content = this.modalContent.nativeElement;
    const header = this.modalHeader.nativeElement;
    const footer = this.modalFooter.nativeElement;


    CommonUtil.modalPopup(content, [header, footer]);
  }

  ngOnInit() {

    if(Array.isArray(this.migrationStatus)) {
      this.migrationStatus?.forEach(status => {
        if (StringUtils.isEqual(status.environment, this.environment)) {
          this.planStatus = this.migrationStatus?.factorMigrationStatus?.executionDetails;
          this.listenEvents(this.migrationStatus?.factorMigrationStatus?.execProcessId);
        }
      })
    } else {
      this.planStatus = this.migrationStatus[this.environment]?.executionDetails;
      this.listenEvents(this.migrationStatus[this.environment]?.execProcessId);
    }
  }

  listenEvents(processId) {
    if(!this.skipEventListen && processId) {
      let eventSourceStream = this.commonService.listenForStream(processId);
      this.eventSources.push(eventSourceStream);
      eventSourceStream.addEventListener("FACTOR_IMPORT_GENERATION_STATUS", (event: any) => {
        this.showProgress = true;
        this.progressPercent = 1;
        this.progressStyle = "progress-bar-warning";
        let eventData = JSON.parse(event.data);
        this.progressStyle = "progress-bar-warning";
        this.progressMessage = eventData.message;
        this.progressPercent = 50;
      });

      eventSourceStream.addEventListener("FACTORS_IMPORTED", (event: any) => {
        let eventData = JSON.parse(event.data);
        this.progressStyle = "progress-bar-success";
        this.progressMessage = eventData.message;
        this.progressPercent = 80;
      });

      eventSourceStream.addEventListener("FACTOR_IMPORT_GENERATION_STATUS_COMPLETE", (event: any) => {
        let eventData = JSON.parse(event.data);
        this.progressStyle = "progress-bar-success";
        this.progressMessage = eventData.message;
        this.progressPercent = 100;
        eventSourceStream.close();
      });

      eventSourceStream.addEventListener(CommonConstants.FAILED, (event: any) => {
        eventSourceStream.close();
        let eventData = JSON.parse(event.data);
        this.progressPercent = 100;
        this.progressStyle = CommonConstants.PROGRESS_BAR_DANGER;
        this.progressMessage = eventData.message;
        setTimeout(() => {
          this.showProgress = false;
        }, this.commonService.getProgressBarTimeOut());
      });
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.migrationStatus && StringUtils.isEqualIgnoreCase(this.environment, Object.keys(this.migrationStatus)[0])) {
      this.planStatus = this.migrationStatus[this.environment]?.executionDetails;
    }
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }

  getStatusIcon(status){
    return StringUtils.isEqualIgnoreCase(status, "success") ? "pi pi-check step-success tooltipfontInfoMsg" : "pi pi-times step-failed tooltipfontErrMsg";
  }

}
