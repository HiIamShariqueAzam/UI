import { Component, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { migrationPlan } from "../models/migrationPlan";
import { AuthenticationService, CommonService } from 'src/app/shared/services';
import { PickList } from 'primeng/picklist';
import { StringUtils } from "../../../shared/utils/string-utils";
import { MigrationService } from "../services/migration.service";
import { MigrationBaseComponent, System } from "../common/migration-base.component";
import { FactorMigrationConstants } from "../../constants/factor-migration-constants";
import { CommonConstants } from "../../../shared/constants/common.constants";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-bulk-import',
  templateUrl: 'bulk-import.component.html',
  styleUrl: './bulk-import.component.css',
  standalone: false,
})
export class BulkImportComponent extends MigrationBaseComponent implements OnInit, OnDestroy {

  private eventSources: EventSource[] = [];
  systems: System[] = [];
  availableEnvironments: System[] = [];
  targetList: any = [];
  factorTables = new Map<string, any>();
  tableCategoryList: any[];
  sourceList: any[] = [];
  fromMigratedEnvironmentError: boolean = false;
  selectedEnvError: boolean = false;
  systemError: boolean = false;
  planNameError: boolean = false;
  sourceTargetSameError: boolean = false;
  migrationName: string;
  showMigrationNameError: boolean = false;
  showMigrationHistory: boolean = false;
  isMigrationPlanFailed: boolean = false;
  showNextButton: boolean = false;
  showPrevButton: boolean = false;
  nextButtonClicked: boolean;
  prevButtonClicked: boolean;
  multiSortMeta: any = FactorMigrationConstants.MULTI_SORT_META;
  onRowSelect: any;
  first = 0;
  rows: any;
  selectedOpportunity: any;
  isEmpty: boolean = true;
  duplicatePlanErrorMsg: string = "";
  errorMessage: string = CommonConstants.EMPTY_STRING;
  bulkImportTable: any = {
    userSelectedSystem: {},
    fromMigratedEnvironment: "",
    selectedEnvironments: "",
    tableCategory: []
  }
  eventTest: PickList;
  selectedFactorTableMap = new Map<string, any>();
  sourceHeaderPicklist: string;
  targetHeaderPicklist: string;
  sourcePlaceholder: string;
  originalFactorTableMap = new Map<string, any>();
  targetListError: boolean = false;
  public dynamic_exportForm: FormGroup = this.formBuilder.group({});
  formData: any;
  selectedForm: any[] = [];
  originalSourceList: any = [];
  alert = {
    show: false,
    message: "",
    type: "",
    cssClass: "",
    header: "",
    headerVisibility: true,
  };

  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: String;
  migrationPlan:any;
  planId: string = "";
  bulkImport: boolean = true;
  showStatus: boolean = false;
  skipEventListen: boolean;
  selectedModalEnvironment: string;
  migrationStatus: any;
  defaultSourceHeight = '170px';
  targetHeight: string = this.defaultSourceHeight;
  sourceHeight: string = this.defaultSourceHeight;
  categoryOptions: any = [];
  @ViewChild('picklist') pickList: PickList;
  @ViewChild('migrationPlanStatus') migrationPlanStatusTemplate;
  readonly MIGRATION_PLAN_EXISTS = "Migration plan already exists.";
  headerColumns = FactorMigrationConstants.HEADER_COLUMNS_BULK_IMPORT;
  constructor(private router: Router, private route: ActivatedRoute, private commonService: CommonService, private authenticationService: AuthenticationService,
    private factorMigrationService: MigrationService, private formBuilder: FormBuilder, public datepipe: DatePipe, private modalService: NgbModal) {
    super();
  }

  ngOnInit() {
    let isfromSearch = !StringUtils.isEmpty(this.route.snapshot.queryParamMap.get('planId'));
    this.fetchSystemDetails(isfromSearch);
    if (isfromSearch){
     this.fetchMigrationPlan();
    }
  }

  fetchSystemDetails(isfromSearch) {
    let shouldUpdateMigrationType = false;
    this.commonService.getFactorSystems().subscribe((response: any) => {
      if (response) {
        // Handle response as array of objects (new format)
        if (Array.isArray(response)) {
          response.forEach((system: any, index: number) => {
            const systemName = system.SYSTEM || system;
            if (this.factorMigrationService.verifyUserRolewithSystem(systemName)) {
              this.systems.push({ 
                label: systemName, 
                value: systemName,
                skipBackup: system.SKIP_DATABACKUP || 'N'
              });
              if (response.length - 1 === index || this.authenticationService.getUserRole().includes('RARE_FACTOR_TABLE_' + systemName)) {
                shouldUpdateMigrationType = true;
              }
            }
          });
        } else {
          // Backward compatibility for old response format (object)
          for (const system in response) {
            if (this.factorMigrationService.verifyUserRolewithSystem(response[system])) {
              this.systems.push({ 
                label: response[system], 
                value: response[system],
                skipBackup: 'N'
              });
              if (response?.length - 1 === parseInt(system) || this.authenticationService.getUserRole().includes('RARE_FACTOR_TABLE_' + response[system])) {
                shouldUpdateMigrationType = true;
              }
            }
          }
        }
        
        this.systems.sort((sysPrev, sysNext) => (sysPrev.value < sysNext.value ? -1 : 1));
        this.fetchFactorTablesValidations();
        this.setPicklistTablesHeaders();
        if (shouldUpdateMigrationType && !isfromSearch) {
          this.updateMigrationType();
        }
      }
    });
  }
  updateMigrationType() {
    this.targetList = [];
    this.selectedFactorTableMap = new Map<string, any>();
    this.bulkImportTable.tableCategory = [];
    this.bulkImportTable.selectedEnvironments = "";
    this.dynamic_exportForm.reset();
    if (this.bulkImportTable.userSelectedSystem?.value) {
      this.systemError = false;
      this.planNameError = false;
      this.fetchFactorTables();
      this.fetchFactorTablesValidations();
      this.fetchTargetDatabases();
    }
  }
  fetchFactorTables() {
    this.commonService.getFactorTables(this.bulkImportTable.userSelectedSystem?.value).subscribe((response) => {
      this.buildFactorTables(response);
      this.updatePickListFilters(true);
    });
  }
  fetchTargetDatabases() {
    this.availableEnvironments = [];
    this.commonService.getTargetDatabases(this.bulkImportTable.userSelectedSystem?.value, 'REAL').subscribe((response: any) => {
      if (response) {
        response.forEach((database) => {
          this.availableEnvironments.push({ label: database.dataBase, value: database.dataBase });
        });
      }
      if (this.migrationPlan && this.migrationPlan.selectedEnvironments.length>0) {
        this.bulkImportTable.selectedEnvironments = this.migrationPlan.selectedEnvironments[0];
    }
       if (this.migrationPlan && this.migrationPlan.fromMigratedEnvironment.length>0) {
         this.bulkImportTable.fromMigratedEnvironment = this.migrationPlan.fromMigratedEnvironment[0];
       }
    });
  }

  goToFactorSearch(): void {
    this.router.navigate(["factor-migration"]);
  }
  buildFactorTables(response: any) {
    let fullTablesList: any[] = [];
    let allAvailableLobList: any[] = [];
    const selectedSystem = this.bulkImportTable.userSelectedSystem?.value;
    this.factorTables = new Map<string, any>();
    Object.keys(response).forEach((key) => {
      if (StringUtils.isEqual(key, 'tableCategory')) {
        response[key].forEach(tableCategory => {
          allAvailableLobList.push({
            label: tableCategory.categoryDescription,
            value: tableCategory.categoryName
          });
        });
      } else {
        if (this.factorMigrationService.verifyUserRolewithLOB(key, selectedSystem)) {
          this.factorTables.set(key, response[key]);
          fullTablesList.push(response[key]);
          this.commonService.setFullTablesList(fullTablesList);
        }
      }
    });
    this.tableCategoryList = allAvailableLobList;
    this.categoryOptions = allAvailableLobList?.map((tab) => {
      return { 'name': tab.label, 'code': tab.value }
    });
    this.categoryOptions = this.factorMigrationService.getSelectedLOBList(this.categoryOptions, selectedSystem);
    this.buildSourceTargetList(true, null);



    if (this.migrationPlan && this.migrationPlan.selectedFactorTables) {
      this.selectedFactorTableMap = new Map<string, any>();
      this.migrationPlan.selectedFactorTables.forEach(selectedFactorTable => {
        this.updateSelectedFactorTables(selectedFactorTable.key, selectedFactorTable.value);
        selectedFactorTable.value.forEach(factorTable => this.targetList.push(factorTable));
      });
      if (this.targetList && this.targetList.length) {
        const updatedTargetList = this.targetList.filter((tab, ind, tables) => {
          return ind === tables.findIndex((tableObj) => StringUtils.isEqualIgnoreCase(tab.displayName, tableObj.displayName))
        })
        this.targetList = updatedTargetList;
      }
      this.originalFactorTableMap = new Map(JSON.parse(JSON.stringify(Array.from(this.selectedFactorTableMap))));
    }

    if (this.migrationPlan && this.migrationPlan.selectedEnvironments) {
      this.bulkImportTable.tableCategory = this.migrationPlan.tableCategory?.map(category => {
        const matchedObject = this.categoryOptions.find(option => option.name.toLowerCase() === category.toLowerCase());
        return matchedObject ? { name: matchedObject.name, code: matchedObject.code } : ''
      }) || [];
    }

    
  }

  bulkImportTables() {
    this.showProgress = false;
    
    if (this.bulkImportFieldsValidation()) {
      return;
    }  
    else {
      this.updateBulkImportPayload();
      let selectedTableMap;
      if (this.selectedFactorTableMap) {
        selectedTableMap = Array.from(this.selectedFactorTableMap, ([key, value]) => ({ key, value }));
      }
      this.alert = {
        show: true,
        message: "Bulk Import is in progress...",
        type: "",
        cssClass: "",
        header: "Import Status",
        headerVisibility: true,
      };
      this.migrationPlan = this.migrationPlan ? this.migrationPlan : new migrationPlan();
      // Update the existing migrationPlan object
      this.migrationPlan.processId = '';
      this.migrationPlan.migrationPlanName = this.migrationName;
      this.migrationPlan.system = this.bulkImportTable.userSelectedSystem?.value; 
      this.migrationPlan.tableCategory = this.bulkImportTable.tableCategory ? this.bulkImportTable.tableCategory.map((category: { name: string }) => category.name) : [];
      this.migrationPlan.createdUser = ""; 
      this.migrationPlan.createdTime = ""; 
      this.migrationPlan.updatedUser = ""; 
      this.migrationPlan.lastUpdatedTime = ""; 
      this.migrationPlan.typeOfUpdate = "full"; 
      this.migrationPlan.selectedEnvironments = this.bulkImportTable.selectedEnvironments ? [this.bulkImportTable.selectedEnvironments]:[];
      this.migrationPlan.fromMigratedEnvironment = this.bulkImportTable.fromMigratedEnvironment ? [this.bulkImportTable.fromMigratedEnvironment]:[];
      this.migrationPlan.selectedFactorTables = selectedTableMap;
      this.migrationPlan.bulkImport = this.bulkImport;
	  this.factorMigrationService.bulkImportTables(this.migrationPlan).subscribe(
	         response => {
	           if (response != null) {
	             this.migrationPlan = response;
	             this.showMigrationHistory = true;
	             if (this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory.length > 0) {
	               this.isEmpty = false;
	             }
	             let processId = response.processId;
	             if (processId) {
	               this.showProgress = true;
	               this.progressPercent = 1;
	               this.progressStyle = "progress-bar-warning";
	               let eventSourceStream = this.commonService.listenForStream(processId);
	               this.eventSources.push(eventSourceStream);

	               // Event: FACTOR_IMPORT_GENERATION_STATUS
				   eventSourceStream.addEventListener("BULK_FACTOR_IMPORT_GENERATION_STATUS", (event: any) => {
				                  this.progressStyle = "progress-bar-warning";
				                  if (event && event.data) {
				                    let eventData = JSON.parse(event.data);
				                    this.progressMessage = eventData.message;
				                    // Update progress percentage based on the event message
                            switch (eventData.message) {
                              case CommonConstants.BULK_IMPORT_FACTOR_MESSAGES.INITIATED:
                                this.progressPercent = 30;
                                break;
                              case CommonConstants.BULK_IMPORT_FACTOR_MESSAGES.VALIDATION_COMPLETE:
                                this.progressPercent = 40;
                                break;
                               case CommonConstants.BULK_IMPORT_FACTOR_MESSAGES.READING_AND_MIGRATION_DATA_INPROGRESS:
                                 this.progressPercent = 50;
                                 break;
                              case CommonConstants.BULK_IMPORT_FACTOR_MESSAGES.READING_DATA_COMPLETE:
                                this.progressPercent = 60;
                                break;
                              case CommonConstants.BULK_IMPORT_FACTOR_MESSAGES.CONNECTION_ESTABLISHED:
                                this.progressPercent = 70;
                                break;
                              case CommonConstants.BULK_IMPORT_FACTOR_MESSAGES.DATA_INSERT_COMPLETE:
                                this.progressPercent = 90;
                                break;
                              case CommonConstants.BULK_IMPORT_FACTOR_MESSAGES.EXECUTION_FAILED:
                                this.progressPercent = 90;
                                this.progressStyle = "progress-bar-danger";
                                break;
				                    }
				                  }
				                });


	               // Event: FACTOR_IMPORT_GENERATION_STATUS_COMPLETE
	               eventSourceStream.addEventListener("BULK_FACTOR_IMPORT_GENERATION_STATUS_COMPLETE", (event: any) => {
	                 eventSourceStream.close();
	                 this.commonService.cleanUpSSEEvents(this.migrationPlan.processId);
	                 if (event && event.data) {
	                   this.progressStyle = "progress-bar-success";
	                   this.progressPercent = 100;
	                   let eventData = JSON.parse(event.data);
	                   if (eventData && eventData.payload) {
	                     this.progressMessage = eventData.message;
	                     this.migrationPlan = eventData.payload;
	                     this.fetchMigrationStatus();
	                   }
	                 }
	                 setTimeout(() => {
	                   this.showProgress = false;
	                 }, this.commonService.getProgressBarTimeOut());
	               });

	               // Event: FAILED
	               eventSourceStream.addEventListener("FAILED", (message: any) => {
	                 eventSourceStream.close();
	                 let eventData = JSON.parse(message.data);
					 if (eventData && eventData.payload) {
					                  this.progressMessage = eventData.message;
					                  this.migrationPlan = eventData.payload;
					                  this.fetchMigrationStatus();
					                }
	                 console.error("Received event : ", JSON.stringify(message.data));
	                 this.progressPercent = 90;
	                 this.progressStyle = "progress-bar-danger";
	                 this.progressMessage = "Error in getting response for Import";
	               });
	             }
               this.removeAlertMsg();
	           }
	         },
	         error => {
	           console.error("API Error:", error);
             this.verifyErrors(error);
             this.removeAlertMsg();
	         }
	       );
    }
  }
  bulkImportFieldsValidation() {
    // Reset all error flags
    this.planNameError = !this.migrationName?.trim();
    this.systemError = !this.bulkImportTable.userSelectedSystem?.value;
    this.targetListError = !this.targetList?.length;

    this.sourceTargetSameError =
      this.bulkImportTable.fromMigratedEnvironment &&
      this.bulkImportTable.selectedEnvironments &&
      this.bulkImportTable.fromMigratedEnvironment === this.bulkImportTable.selectedEnvironments;

    this.fromMigratedEnvironmentError =
      !this.bulkImportTable.fromMigratedEnvironment ||
      (Array.isArray(this.bulkImportTable.fromMigratedEnvironment) &&
        this.bulkImportTable.fromMigratedEnvironment.length === 0);

    this.selectedEnvError =
      !this.bulkImportTable.selectedEnvironments ||
      (Array.isArray(this.bulkImportTable.selectedEnvironments) &&
        this.bulkImportTable.selectedEnvironments.length === 0);

    // Determine if any validation error exists
    return this.planNameError ||
      this.systemError ||
      this.targetListError ||
      this.sourceTargetSameError ||
      this.fromMigratedEnvironmentError ||
      this.selectedEnvError;
  }
  moveToSource(event, isAllListMoved) {
    this.sourceList.forEach(sourceTable => {
      this.selectedFactorTableMap.forEach((tables, key) => {
        const index = tables.findIndex(table => table.displayName === sourceTable.displayName);
        if (index != -1) {
          tables.splice(index, 1);
          if (tables.length === 0) {
            this.selectedFactorTableMap.delete(key);
          }
        }
      });
    });
    this.sourceList.sort((source1, source2) => (source1.displayName < source2.displayName ? -1 : 1));

    if (isAllListMoved) {
      this.dynamic_exportForm = this.formBuilder.group({});
    }
    const selectedCategory = this.bulkImportTable.tableCategory;
    this.updateTableCategory({ value: selectedCategory });
    this.createForm(this.formData);
    this.updateSourceTargetHeight(false);
  }

  moveToTarget(event) {
    this.updateListFromTarget();
    this.eventTest = event;
    this.targetList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
    if (this.targetList && this.targetList?.length) {
      this.targetListError = false;
      this.updateSourceTargetHeight(true);
    }
    this.createForm(this.formData);
  }
  setPicklistTablesHeaders() {
    this.sourceHeaderPicklist = 'Available Factor Tables';
    this.targetHeaderPicklist = 'Selected Factor Tables';
    this.sourcePlaceholder = 'Search by table name';
  }
  buildSourceTargetList(isSource, sheets) {
    if (isSource) {
      this.sourceList = []
      this.tableCategoryList.forEach(tableCategory => {
        let categoryTables = this.factorTables.get(tableCategory.value);
        categoryTables?.forEach(categoryTable => {
          this.sourceList.push(categoryTable);
        });
      });
      this.originalFactorTableMap = new Map(JSON.parse(JSON.stringify(Array.from(this.factorTables))));
      this.originalSourceList = JSON.parse(JSON.stringify(Array.from(this.sourceList)));
      this.targetHeight = this.defaultSourceHeight;
      this.sourceHeight = this.defaultSourceHeight;
      this.updateSourceTargetHeight(false);
    } else {
      sheets.forEach(sheet => {
        this.tableCategoryList.forEach(tableCategory => {
          let categoryTables = this.factorTables.get(tableCategory.value);
          let categoryTable = categoryTables.find(categoryTable => {
            return (StringUtils.isEqualIgnoreCase(categoryTable.displayName, sheet)) || (StringUtils.isEqualIgnoreCase(categoryTable.tableName, sheet))
          });
          let isExistInTarget = this.targetList.some((tab) => tab.displayName === categoryTable?.displayName);
          if (categoryTable && !isExistInTarget) {
            this.targetList.push(categoryTable);
            this.updateSelectedFactorTables(tableCategory.value, categoryTable);
            this.sourceList = this.sourceList.filter((table) => table.displayName !== categoryTable.displayName);
          }
        });
      });
      if (this.targetList && this.targetList?.length) {
        this.sourceList = this.sourceList.filter((tab, ind) => {
          return this.targetList.findIndex((table) => StringUtils.isEqualIgnoreCase(tab.displayName, table.displayName)) == -1;
        })
      }
    }
    this.sourceList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
  }
  updateSelectedFactorTables(key, factorTable) {
    if (this.selectedFactorTableMap) {
      if (this.selectedFactorTableMap.has(key)) {
        this.selectedFactorTableMap.get(key).push(factorTable);
      } else if (Array.isArray(factorTable)) {
        this.selectedFactorTableMap.set(key, factorTable);
      } else {
        this.selectedFactorTableMap.set(key, [factorTable]);
      }
    }
  }
  fetchMigrationPlan() {
    this.route.queryParams.subscribe(param => {
      let params = (param && param.planId) ? param : { planId: this.planId };
      if (params && params.planId) {
        this.factorMigrationService.getMigrationByPlanId(params.planId, 'save').subscribe(migrationPlan => {
          // Set migration plan
          this.migrationPlan = migrationPlan;
          this.isMigrationPlanFailed = false;
          // Map migration plan name
          this.migrationName = migrationPlan.migrationPlanName || '';

          // Map user-selected system
          this.bulkImportTable.userSelectedSystem.label = migrationPlan.system;
          this.bulkImportTable.userSelectedSystem.value = migrationPlan.system;
          this.updateMigrationType();

         
          // Fetch additional data if planId is not set
          if (!this.planId) {
            this.fetchFactorTables();
            this.fetchTargetDatabases();
          }
          this.fetchMigrationStatus();
          if (this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory?.length > 0) {
            this.isEmpty = false;
          }
          // Reset planId
          this.planId = "";
        });
      }
    });
  }
 
  fetchFactorTablesValidations() {
    if (this.bulkImportTable.userSelectedSystem?.value) {
      this.factorMigrationService.fetchFactorTablesValidation(this.bulkImportTable.userSelectedSystem?.value).subscribe((response) => {
        if (response && response?.length) {
          this.formData = JSON.parse(JSON.stringify(response));
        } else {
          this.formData = [];
        }
      })
    }
  }
  createForm(formdata: any) {
    for (const tab of this.targetList) {
      let selectedTableValidation: any = formdata?.filter((form) => (form.tableName == tab.displayName) || (form.tableName == tab.tableName));
      if (selectedTableValidation && selectedTableValidation?.length) {
        for (const control of selectedTableValidation) {
          const validatorsToAdd = [];
          if (StringUtils.isEqual(control.mandatory, 'Y')) {
            validatorsToAdd.push(Validators.required);
          }
          if (!this.dynamic_exportForm.controls[control.fieldName]) {
            this.dynamic_exportForm.addControl(
              control.fieldName,
              this.formBuilder.control('', validatorsToAdd)
            );
          }
          if (StringUtils.isEqual(control.fieldDisabled, 'Yes')) {
            this.dynamic_exportForm.controls[control.fieldName].disable();
          }
        }
      }
    }

  }


updateBulkImportPayload() {
  // Iterate through the selected form fields
  for (const params of this.selectedForm) {
    Object.keys(this.dynamic_exportForm.controls).forEach((key) => {
      // Remove unnecessary properties from params
      delete params.fieldDefaultValues;
      delete params.selectedDefaultValue;
      delete params.fieldDisabled;
      delete params.fieldLabel;
      delete params.fieldOrder;
      delete params.tableName;

      // Update the form control value
      if (params.fieldName === key) {
        const control = this.dynamic_exportForm.controls[key];
        params[CommonConstants.SELECTED_VALUES] = control.value?.toString().replaceAll('"', '');
        control.markAsTouched();
        control.updateValueAndValidity(); 
      }
    });
  }
}
  updateSourceList() {
    this.sourceList = [];
    this.tableCategoryList.forEach(tableCategory => {
      let categoryTables = this.factorTables.get(tableCategory.value);
      categoryTables.forEach(categoryTable => {
        if (!this.targetList.some((item) => item.displayName == categoryTable.displayName)) {
          this.sourceList.push(categoryTable);
        }
      });
    });
    this.sourceList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
    this.updateListFromTarget();
  }
  updateListFromTarget() {
    this.targetList.forEach(targetTable => {
      this.originalFactorTableMap.forEach((tables, key) => {
        if (tables.findIndex(table => table.displayName === targetTable.displayName) != -1) {
          let selectedTables = this.selectedFactorTableMap.get(key);
          if (selectedTables) {
            if (selectedTables.findIndex(table => table.displayName === targetTable.displayName) === -1) {
              this.updateSelectedFactorTables(key, tables.find(table => table.displayName === targetTable.displayName));
            }
          } else {
            this.updateSelectedFactorTables(key, tables.find(table => table.displayName === targetTable.displayName));
          }
        }
      });
    });
  }
  updateSourceDatabase() {
    if (this.bulkImportTable.fromMigratedEnvironment?.value) {
      this.fromMigratedEnvironmentError = false;
    }
  }

  updateTargetDatabase(){
    if (this.bulkImportTable.selectedEnvironments?.value) {
      this.selectedEnvError = false;
    }
  }



  fetchMigrationStatus() {
    let migrationPlanStatus: any[] = [];
    if (this.migrationPlan && this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory.length) {
      this.showMigrationHistory = true;
      this.migrationPlan.factorMigrationPlanHistory.forEach((plan) => {
        migrationPlanStatus = [];
        let matchedEnvironment = plan.targetEnvironments.split(',');
        let spu
        if (plan.factorMigrationStatus) {
          Object.keys(plan.factorMigrationStatus).forEach((status) => {
            if (matchedEnvironment.indexOf(status) != -1) {
              let environmentStatus = {
                environment: status,
                executionDetails: []
              };

              // Check if executionDetails exists and is not empty
              if (plan.factorMigrationStatus[status].executionDetails && plan.factorMigrationStatus[status].executionDetails.length) {
                plan.factorMigrationStatus[status].executionDetails.forEach((planList) => {
                  environmentStatus.executionDetails.push({
                    status: planList.status,
                    errorList: planList.errors,
                    cacheRefreshStatus: planList.cacheRefreshStatus
                  });
                });
              } else {
                // Handle case where executionDetails is empty
                environmentStatus.executionDetails.push({
                  status: plan.factorMigrationStatus[status].executionStatus,
                  executedUser: plan.factorMigrationStatus[status].executedUser,
                  executionStartTime: plan.factorMigrationStatus[status].executionStartTime,
                  executionFinishTime: plan.factorMigrationStatus[status].executionFinishTime,
                  cacheRefreshStatus: null // Default value if cacheRefreshStatus is not available
                });
              }

              migrationPlanStatus.push(environmentStatus);
            }
          });
          plan['MigratedStatus'] = migrationPlanStatus;
        }
      });
      this.updatedMigrationStatusHistory();
    }
  }

  updatedMigrationStatusHistory() {
    let migrationStatus = this.migrationPlan.factorMigrationPlanHistory;
    let statusSuccess = 'success', statusFailed = 'failed';
    this.isMigrationPlanFailed = false;
    if (this.migrationPlan.factorMigrationPlanHistory && this.migrationPlan.factorMigrationPlanHistory.length > 0) {
      let lastPlanExecutionHistory = this.migrationPlan.factorMigrationPlanHistory[this.migrationPlan.factorMigrationPlanHistory.length - 1];
      if (lastPlanExecutionHistory?.factorMigrationStatus) {
        Object.keys(lastPlanExecutionHistory.factorMigrationStatus).forEach((key) => {

          if (lastPlanExecutionHistory.factorMigrationStatus[key]) {
            if (StringUtils.isEqualIgnoreCase(lastPlanExecutionHistory.factorMigrationStatus[key]?.executionStatus, statusFailed)) {
              this.isMigrationPlanFailed = true;
            }
          }
        })
      }
    }
    migrationStatus.forEach((plan) => {
      if (plan.MigratedStatus && plan.MigratedStatus.length) {
        plan.MigratedStatus.forEach((planHistory) => {
          planHistory.isExecutionFailed = false;
          planHistory.cacheRefreshStatus = 'success';
          if (planHistory.executionDetails?.every((history) => history.status == statusSuccess && history.errorList?.length == 0)) {
            planHistory.executionStatus = statusSuccess;
          } else {
            const isCacheRefreshFailed = planHistory.executionDetails?.every((history) => history.status == statusSuccess) && planHistory.executionDetails?.some((history) => history.cacheRefreshStatus == 'failed');
            if (isCacheRefreshFailed) {
              planHistory.executionStatus = statusSuccess;
              planHistory.cacheRefreshStatus = 'failed';
            } else {
              planHistory.executionStatus = statusFailed;
              if (!Array.isArray(planHistory.errorList)) {
                planHistory.errorList = [];
              }
            }
          }
        })
        if (plan.MigratedStatus.some((status) => StringUtils.isEqual(status.executionStatus, statusFailed))) {
          plan.MigratedStatus.forEach((status) => status.isExecutionFailed = true);
        }
      }
    })
  }


  clearPlan() {
    this.bulkImportTable.userSelectedSystem = {};
    this.dynamic_exportForm = this.formBuilder.group({});
    this.targetList = [];
    this.selectedFactorTableMap = new Map<string, any>();
    this.sourceList = [];
    this.availableEnvironments = [];
    this.fromMigratedEnvironmentError = false;
    this.selectedEnvError = false;
    this.systemError = false;
    this.planNameError = false;
    this.targetListError = false;
    this.sourceTargetSameError = false;
    this.migrationName = CommonConstants.EMPTY_STRING;
    this.showMigrationNameError = false;
    if (this.eventTest) {
      this.eventTest.resetSourceFilter();
      this.eventTest.resetTargetFilter();
    }
    this.removeAlertMsg();
    this.targetHeight = this.defaultSourceHeight;
    this.sourceHeight = this.defaultSourceHeight;
    this.bulkImportTable.tableCategory = [];
    this.showProgress = false;
  }
  removeAlertMsg() {
    this.alert = {
      show: false,
      message: "",
      type: "",
      cssClass: "",
      header: "",
      headerVisibility: true,
    };
  }
  updateSourceTargetHeight(isSource) {
    let pickListElement = this.pickList?.listViewSourceChild;
    setTimeout(() => {
      if (isSource) {
        this.sourceHeight = this.targetHeight;
      } else {
        if (pickListElement && pickListElement?.el && pickListElement?.el?.nativeElement?.offsetHeight) {
          this.targetHeight = pickListElement?.el?.nativeElement?.offsetHeight + 'px';
        }
      }
      this.updatePickListFilters(false);
    })
  }
  updateTableCategory(event) {
    if (event.value?.length && this.factorTables) {
      const selectedCategory = event.value;
      const factorListTables = JSON.parse(JSON.stringify(Array.from(this.factorTables, ([key, value]) => ({ key, value }))));
      const matchedCategoryList = factorListTables?.filter((tab) => {
        return selectedCategory?.find((category) => tab.key == category.code)
      });
      if (matchedCategoryList && matchedCategoryList?.length) {
        if (matchedCategoryList?.length && this.targetList) {
          this.sourceList = [].concat.apply([], matchedCategoryList.map((tableList, ind) => {
            return tableList.value?.filter((table) => {
              return this.targetList.findIndex((tab) => StringUtils.isEqualIgnoreCase(table.displayName, tab.displayName)) == -1;
            })
          }));
        } else {
          this.sourceList = [].concat.apply([], matchedCategoryList?.map((tab) => tab.value));
        }
        this.sourceList.sort((tab1, tab2) => (tab1.displayName < tab2.displayName ? -1 : 1));
      }
    } else {
      this.resetSourceTables();
      if (this.targetList && this.targetList?.length) {
        this.sourceList = this.sourceList.filter((tab, ind) => {
          return this.targetList.findIndex((table) => StringUtils.isEqualIgnoreCase(tab.displayName, table.displayName)) == -1;
        })
      }
    }
    this.updateSourceTargetHeight(false);
  }
  resetSourceTables() {
    if (this.originalSourceList?.length) {
      this.sourceList = JSON.parse(JSON.stringify(this.originalSourceList));
      this.sourceList.sort((taget1, target2) => (taget1.displayName < target2.displayName ? -1 : 1));
    }
  }
  updatePickListFilters(isClearFilter) {
    if (this.pickList) {
      if (isClearFilter) {
        this.pickList.resetFilter();
      } else {
        if (this.pickList.filterValueSource) {
          this.pickList.filterSource(this.pickList.filterValueSource);
        } if (this.pickList.filterValueTarget) {
          this.pickList.filterTarget(this.pickList.filterValueTarget);
        }
      }
      this.pickList.cd.detectChanges();
    }
  }

  migrationNameChange() {
    if (this.migrationName && this.migrationName.trim() !== "") {
      this.planNameError = false; 
      this.showMigrationNameError = false;
    }
  }

  verifyErrors(err) {
    if (err.error?.exceptions?.exceptions) {
      let exception = err.error?.exceptions?.exceptions;
      if (exception && exception.length) {
        exception.forEach((e) => {
          if (StringUtils.isEqualIgnoreCase(this.MIGRATION_PLAN_EXISTS, e.message)) {
            this.duplicatePlanErrorMsg = e.message;
          } else {
            this.errorMessage += e.message;
          }
        })
      }
    }
  }

  saveMultiSortMeta(event) {
    this.multiSortMeta = event.multisortmeta;
  }


  searchClicked(isRefresh?: boolean) {
    if (isRefresh) {
      this.factorMigrationService.fetchMigrationPlans().subscribe(
        response => {
          if (response !== null)
            this.isEmpty = false;
        });
    }
  }

  getMigratedStatus(rowData: any): any[] {
    const migratedStatus = [];
    if (rowData.factorMigrationStatus) {
      Object.keys(rowData.factorMigrationStatus).forEach((environment) => {
        const status = rowData.factorMigrationStatus[environment];

        migratedStatus.push({
          environment: environment,
          executionStatus: status.executionStatus,
          executionStartTime: status.executionStartTime,
          executionFinishTime: status.executionFinishTime,
          executedUser: status.executedUser
        });
      });
    }
    return migratedStatus;
  }

  viewMigrationStatus(migrationPlanHistory, environment, skipListening) {
    this.showStatus = true;
    this.skipEventListen = skipListening;
    this.selectedModalEnvironment = environment;
    this.migrationStatus = migrationPlanHistory?.factorMigrationStatus;
    if (this.migrationPlanStatusTemplate) {
      this.modalService.open(this.migrationPlanStatusTemplate, { backdrop: 'static' });
    }
  }

  ngOnDestroy() {
    this.eventSources.forEach(source => source.close());
  }
}

