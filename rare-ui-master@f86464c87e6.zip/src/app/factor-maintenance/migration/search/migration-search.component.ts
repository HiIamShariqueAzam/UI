import {Component, Inject, inject, OnInit} from "@angular/core";
import {Router, NavigationEnd} from "@angular/router";
import {FormBuilder, FormGroup} from "@angular/forms";
import {MigrationService} from "../services/migration.service";
import {migrationPlan} from "../models/migrationPlan";
import {SESSION_STORAGE, WebStorageService} from "ngx-webstorage-service";
import {AuthenticationService, CommonService} from "../../../shared/services";
import { Environment } from '../common/migration-base.component';
import { Subscription } from 'rxjs';
import { StringUtils } from 'src/app/shared/utils/string-utils';

@Component({
  selector: "migration-search",
  templateUrl: "migration-search.component.html",
  styleUrls: ["migration-search.component.css"],
  standalone: false,
})
export class MigrationSearchComponent implements OnInit {

  factor_migration_form: FormGroup<any>;
  showMigrationSearch: boolean = false;
  isSearched: boolean = false;
  isEmpty: boolean = false;
  showNextButton: boolean = false;
  showPrevButton: boolean = false;
  nextButtonClicked: boolean;
  prevButtonClicked: boolean;
  selectedPageSize: any;
  rowsPerPage: any[];
  onRowSelect: any;
  first = 0;
  totalPages;
  rows: any;
  nextCursor: any;
  prevCursor: any;
  selectedOpportunity: any;
  pageIndex = 1;
  numberOfPlans: number;
  showEmptyFromDate: boolean = false;
  canViewBulkImport: boolean = false;
  selectedFromDate: any;
  selectedToDate: any;
  showBulkImportButton: boolean = false;
  cols = [
    {
      header: "Migration Name",
      field: "migrationPlanName",
    },
    {
      header: "Created By",
      field: "createdUser",
    },
    {
      header: "Created Date & Time",
      field: "createdTime",
    },
    {
      header: "System",
      field: "system",
    }
  ];

  createdUser: Environment[] = [{
    name: 'All Users',
    code: 'all_users'
  }];
  migrationPlans: any[] = [];
  systems: Environment[] = []
  subscriptions:Subscription[] = [];

  private factorMigrationService = inject(MigrationService);

  constructor(private router: Router, private formBuilder: FormBuilder, @Inject(SESSION_STORAGE) private storage: WebStorageService, private authenticationService: AuthenticationService,
  private commonService: CommonService) {
    let routerSybscription = this.router.events.subscribe((event) => {
      if( event instanceof NavigationEnd){
        if(!event.url.includes('factor-migration')){
          this.factorMigrationService.setSearchPlan(null);
          this.subscriptions.forEach((e) => e.unsubscribe());
        }
      }
    })
    this.subscriptions.push(routerSybscription);
  }

  ngOnInit(): void {
    const userRole = this.authenticationService.getUserRole();
    this.canViewBulkImport = this.authenticationService.isUserRoleAdmin(userRole) ||
      (this.authenticationService.isUserFactorTableERE(userRole) &&
        this.authenticationService.isUserFactorTableAdmin(userRole));
    this.factorMigrationService.getUniqueCreatedUsers().subscribe(response => {
      if (response && response.length > 0) {
        response.forEach(user => {
          this.createdUser.push({name: user, code: user})
        })
      }
      this.factor_migration_form = this.formBuilder.group({
        migrationPlanName: [""],
        system: [""],
        createdUser: [[{
          name: this.authenticationService.getUserName(),
          code: this.authenticationService.getUserName()
        }]],
        fromdate: [""],
        todate: [""],
      },
      {
        validator: this.validateDate("fromdate", "todate"),
      });
      const loginedUserName = this.authenticationService.getUserName();
      const createUser = "createdUser";
      if (response?.indexOf(loginedUserName) === -1) {
        this.factor_migration_form.get(createUser).setValue(this.createdUser.filter((user) => StringUtils.isEqualIgnoreCase(user.code, 'all_users')));
      }
      this.fetchSystemDetails();
    });

    this.rowsPerPage = [
      {label: "10", value: 10},
      {label: "20", value: 20},
      {label: "30", value: 30},
    ];
    this.selectedPageSize = this.rowsPerPage[0];
    this.multiSortMeta = this.storage.get("multiSortMeta");
    
    this.showBulkImportButton = this.commonService.getRareEnableBulkImport();

  }

  getwidth(column) {
    let width = "16.6%";
    return width;
  }

  validateDate(dateFrom: string, dateTo: string) {
    return (formGroup: FormGroup) => {
      const datefrom = formGroup.controls[dateFrom];
      const dateto = formGroup.controls[dateTo];
      if (new Date(datefrom.value) > new Date(dateto.value) && dateto?.value) {
        datefrom.setErrors({invalidFromDate: true});
      } else {
        if (datefrom.hasError("required")) {
          datefrom.setErrors(null);
          datefrom.setErrors({required: true});
        } else {
          datefrom.setErrors(null);
        }
      }
    };
  }

  paginate(event) {
    this.pageIndex = event.first / event.rows + 1;
    this.storage.set("batchfirst", event.first);
    this.storage.set("batchpageIndex", this.pageIndex);
  }

  saveMultiSortMeta(event) {
    this.multiSortMeta = event.multisortmeta;
  }

  multiSortMeta = [
    {
      field: "MigrationName",
      order: 1,
    },
    {
      field: "Created By",
      order: 1,
    },
    {
      field: "Created Date",
      order: 1,
    },
    {
      field: "System",
      order: 1,
    }
  ];

  searchMigrationPlan() {
    this.isSearched = true;
    this.isEmpty = true;
  }

  resetMigrationSearch() {
    this.factor_migration_form.reset();
    this.showMigrationSearch = false;
    this.migrationPlans = [];
    this.isEmpty = false;
    this.isSearched = false;
    this.totalPages = 0;
    this.multiSortMeta = null;
    this.showEmptyFromDate = false;
  }

  clickedFromORToDate(selector, selector2, selector3) {
    let element: HTMLElement = document.querySelectorAll(selector)[0] as HTMLElement;
    this.selectedFromDate = element;
    if (typeof element != "undefined") {
      element.click();
    }
    if (document.querySelector(selector2))
      (<HTMLImageElement>document.querySelector(selector2)).src =
        "./assets/calendar-blue.svg";
    (<HTMLImageElement>document.querySelector(selector3)).src =
      "./assets/calendar.svg";
  }

  focusFromDateEle() {
    if (this.selectedFromDate) {
      this.selectedFromDate.focus();
    }
  }

  focusToDateEle() {
    if (this.selectedToDate) {
      this.selectedToDate.focus();
    }
  }

  /**
   *
   * @param isRefresh
   */
  searchClicked(isRefresh?: boolean) {
    let cursor: any;
    let sortMetaData: any;
    let pageLimit = 10;
    let form = this.factor_migration_form;

    this.isEmpty = false;
    this.isSearched = true;

    if (this.nextButtonClicked) {
      cursor = this.nextCursor;
    }
    if (this.multiSortMeta != undefined) {
      sortMetaData = JSON.stringify(this.multiSortMeta);
    }
    if (this.prevButtonClicked) {
      cursor = this.prevCursor;
    }

    if (form.get("fromdate").value && !form.get("todate").value) {
      this.showEmptyFromDate = true;
    } else {
      this.showEmptyFromDate = false;
    }

    if (this.selectedPageSize) pageLimit = this.selectedPageSize.value;
    if (this.factor_migration_form.invalid) {
      this.isEmpty = true;
      return;
    } else {
      if (!this.showEmptyFromDate) {
        this.migrationPlans = [];
        this.showMigrationSearch = false
        this.totalPages = 0;
        this.factorMigrationService.setSearchPlan(this.factor_migration_form);
        this.storage.set("pageLimit", pageLimit);
        const selectedSystem: any = this.factor_migration_form.get('system')?.value;
        if(!this.authenticationService.isUserRoleAdmin(this.authenticationService.getUserRole()) && !selectedSystem?.length){
          this.storage.set("availableSystems", this.systems);
        }
        this.getMigrationPlans(pageLimit, cursor, sortMetaData, isRefresh);
      } else {
        this.isSearched = false;
        this.showMigrationSearch = false
        this.storage.set("showFactorSearch", "false");
      }
    }
  }

  /**
   *
   * @param pageLimit
   * @param cursor
   * @param sortMetaData
   * @param isRefresh
   */
  getMigrationPlans(pageLimit: number, cursor: any, sortMetaData: any, isRefresh?: boolean) {
    this.factorMigrationService.fetchMigrationPlans(this.factor_migration_form, pageLimit, cursor, sortMetaData).subscribe(
      response => {
        if (response.factorMigrationPlans.length) {
          this.isEmpty = false;
          this.showMigrationSearch = true;
          this.showNextButton = response.hasNextCursor;
          this.showPrevButton = response.hasPrevCursor;
          this.nextCursor = response.nextCursor;
          this.prevCursor = response.prevCursor;
          this.migrationPlans = response.factorMigrationPlans;
          if(this.migrationPlans && this.migrationPlans?.length){
          this.first = 0;
          this.pageIndex = 1;
          this.storage.set("migrationfirst", 0);
          this.storage.set("migrationtotalPages", this.totalPages);
          this.storage.set("migrationpageIndex", 1);
          this.storage.set("showMigrationPlans", true);
          this.storage.set("migrationPlanName", this.factor_migration_form.controls.migrationPlanName.value);
          this.storage.set("system", this.factor_migration_form.controls.system.value);
          this.storage.set("fromdate", this.factor_migration_form.controls.fromdate.value);
          this.storage.set("todate", this.factor_migration_form.controls.todate.value);

          this.totalPages = Math.ceil(this.numberOfPlans / 10);
          if (isRefresh) this.storage.remove("batchcursor");
          }else {
            this.noDisplayRecords();
          }
        } else {
          this.noDisplayRecords();
        }
      },
      (error) => {
        this.showMigrationSearch = false;
        this.storage.set("showRenewal", "false");
      });
  }

  nextClicked() {
    if (this.showNextButton) {
      this.nextButtonClicked = true;
      this.searchClicked();
      this.nextButtonClicked = false;
    }
  }

  prevClicked() {
    if (this.showPrevButton) {
      this.prevButtonClicked = true;
      this.searchClicked();
      this.prevButtonClicked = false;
    }
  }

  bulkImport(){
    this.router.navigate(['factor-migration/bulkImport']);
  }

  createMigrationPlan() {
    this.router.navigate(['factor-migration/plan']);
  }

  navigateToExecutor(data) {
    console.log("data:::", data);

    if (data["bulkImport"] === true) {
      // Navigate to the bulk import screen
      this.router.navigate(['factor-migration/bulkImport'], {
        queryParams: {
          planId: data["id"]
        }
      });
    } else {
      // Navigate to the plan screen
      this.router.navigate(['factor-migration/plan'], {
        queryParams: {
          planId: data["id"]
        }
      });
    }
  }
  exportFactors(){
    this.router.navigate(['factor-migration/export']);
  }
  reportFactors(){
    this.router.navigate(['factor-migration/report']);
  }

  fetchSystemDetails() {
    this.commonService.getFactorSystems().subscribe((response: any) => {
      if (response) {
        // Handle response as array of objects (new format)
        if (Array.isArray(response)) {
          response.forEach((system: any) => {
            const systemName = system.SYSTEM || system;
            if (this.factorMigrationService.verifyUserRolewithSystem(systemName)) {
              this.systems.push({ 
                name: systemName, 
                code: systemName 
              });
            }
          });
        } else {
          // Backward compatibility for old response format (object)
          for (const system in response) {
            if (this.factorMigrationService.verifyUserRolewithSystem(response[system])) {
              this.systems.push({ 
                name: response[system], 
                code: response[system] 
              });
            }
          }
        }
        
        this.systems.sort((sysPrev, sysNext) => (sysPrev.code < sysNext.code ? -1 : 1));
        if (this.factorMigrationService.getSearchPlan()) {
          this.updateFactorMigrationForm();
        }
        const selectedSystem = this.factor_migration_form.get('system')?.value;
        if (!this.authenticationService.isUserRoleAdmin(this.authenticationService.getUserRole()) && !selectedSystem?.length && !this.factorMigrationService.getSearchPlan()) {
          this.factor_migration_form.get('system').setValue(this.systems);
        }
        this.searchClicked();
      }
    });
  }
  updateFactorMigrationForm(){
    const searchPlan: any = this.factorMigrationService.getSearchPlan();
    if(searchPlan?.value){
      this.factor_migration_form = this.formBuilder.group({
        migrationPlanName: [searchPlan?.value.migrationPlanName],
        system: [searchPlan?.value.system],
        createdUser: [searchPlan?.value.createdUser],
        fromdate: [searchPlan?.value.fromdate],
        todate: [searchPlan?.value.todate],
      },
      {
        validator: this.validateDate("fromdate", "todate"),
      });
      const pageLimit = this.storage.get("pageLimit");
      if(pageLimit){
        this.selectedPageSize = {label: pageLimit.toString(), value: pageLimit};
      }
    }
  }
  noDisplayRecords() {
    this.showMigrationSearch = false;
    this.storage.set("showRenewal", "false");
    this.isEmpty = true;
  }
}
