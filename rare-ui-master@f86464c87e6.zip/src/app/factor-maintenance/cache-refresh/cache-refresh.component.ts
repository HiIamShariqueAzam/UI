import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from 'src/app/shared/services';
import { SESSION_STORAGE, WebStorageService } from 'ngx-webstorage-service';
import { MessageService } from 'primeng/api';
import { PickList } from 'primeng/picklist';
import { TableNames } from 'src/app/shared/models';
import { OpportunityService } from 'src/app/opportunity/services/opportunity.service';

@Component({
  selector: 'app-cache-refresh',
  templateUrl: './cache-refresh.component.html',
  styleUrls: ['./cache-refresh.component.css'],
  standalone: false,
})
export class CacheRefreshComponent implements OnInit {
  userSelectedLob: any;
  lobValue: any;
  showLobError: boolean = false;
  errorMessageLob = 'Please select the LOB';
  tableErrorMessage = 'Please select the Table';
  lobList: any[];
  map = new Map<string, string[]>();
  sourceList: any[];
  showLobDropdown: boolean = false;
  sourceHeaderPicklist: String;
  targetHeaderPicklist: String;
  sourcePlaceholder: String;
  eventTest: PickList;
  targetList: any[];
  showTableError: boolean = false;
  tableList: any;
  tableStatus: any;

  constructor(
    private commonService: CommonService,
    private messageService: MessageService,
    @Inject(SESSION_STORAGE) private storage: WebStorageService,
    private opportunityService: OpportunityService
  ) {}

  ngOnInit() {
    this.targetList = [];
    this.lobList = [
      { label: 'Medical', value: 'MED' },
      { label: 'Vision', value: 'VIS' },
      { label: 'Dental', value: 'DEN' },
      { label: 'Supp Health', value: 'SHP' },
      { label: 'System', value: 'SYS' },
      { label: 'Gateway', value: 'Gateway' },
      { label: 'Rating', value: 'Rating' }
    ];
    this.setHeaderPicklistTables();
    this.fillPicklistSource();
  }

  lobChanged() {
    this.tableStatus = null;
    this.lobValue = this.userSelectedLob.value;
    if (this.lobValue == undefined) {
      this.showLobError = true;
    } else {
      this.showLobError = false;
    }
    if (this.eventTest) {
      this.eventTest.moveAllLeft();
    }
    this.showTableError = false;
    this.targetList = [];
    if (this.lobValue != 'Gateway' && this.lobValue != 'Rating') {
      this.map = this.commonService.getMapOfRoleAndTableNames();
      let tableArray = JSON.parse(JSON.stringify(this.map.get(this.lobValue)));
      this.sourceList = <TableNames[]>tableArray;
      this.includeTablesToSourceList();
      this.excludeTablesFromSourceList();
      this.setHeaderPicklistTables();
    }
  }

  moveToTarget(event) {
    this.tableStatus = null;
    if (this.showTableError) {
      this.showTableError = false;
    }
    this.eventTest = event;
    this.targetList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
  }

  moveToSource(event) {
    this.tableStatus = null;
    this.sourceList.sort((one, two) => (one.displayName < two.displayName ? -1 : 1));
  }

  fillPicklistSource() {
    if (this.lobValue) {
      this.map = this.commonService.getMapOfRoleAndTableNames();
      let tableArray = this.map.get(this.lobValue);
      this.sourceList = <TableNames[]>tableArray;
    }
  }

  reset(event: PickList) {
    this.resetLobData();
    if (this.showLobDropdown) {
      this.sourceList = [];
    }
    this.showTableError = false;
    this.showLobError = false;
    this.setHeaderPicklistTables();
    event.resetFilter();
    event.moveAllLeft();
    this.tableStatus = null;
  }

  resetGateway() {
    this.tableStatus = null;
    this.resetLobData();
  }

  resetRating() {
    this.tableStatus = null;
    this.resetLobData();
  }

  resetLobData() {
    this.lobValue = undefined;
    this.userSelectedLob = undefined;

    if (this.lobList.length == 1) {
      this.lobValue = this.lobList[0].value;
    }

    if (this.lobList.length > 1) {
      this.showLobDropdown = true;
    }
  }

  callCacheRefresh(event) {
    this.tableStatus = null;
    if (!this.hasReadOnly()) {
      if (this.lobValue == undefined) {
        this.showLobError = true;
        this.showTableError = true;
        return;
      }

      if (this.targetList.length == 0) {
        this.showTableError = true;
        return;
      }

      if (this.lobValue !== 'Gateway' && this.lobValue !== 'Rating') {
        this.tableList = this.targetList;
        if (this.lobValue === 'VIS' || this.lobValue === 'DEN') {
          if (this.sourceList.length === 0) {
            this.tableList = null;
          }
        }
      }

      this.opportunityService.callCacheRefresh(this.tableList, this.lobValue).subscribe((res) => {
        this.tableStatus = false;
        if (res.status == 200) {
          this.tableStatus = true;
        }
      });
    }
  }

  callGatewayCacheRefresh() {
    if (!this.hasReadOnly()) {
      let event = null;
      this.callGatewayCache();
    }
  }

  callRatingCacheRefresh() {
    if (!this.hasReadOnly()) {
      let event = null;
      this.callRatingCache();
    }
  }

  callGatewayCache() {
    this.tableStatus = null;
    this.opportunityService.callGatewayCache().subscribe((res) => {
      this.tableStatus = false;
      if (res.status == 200) {
        this.tableStatus = true;
      }
    });
  }

  callRatingCache() {
    this.tableStatus = null;
    this.opportunityService.callRatingCache().subscribe((response) => {
      this.tableStatus = false;
      if (response.status == 200) {
        this.tableStatus = true;
      }
    });
  }

  hasReadOnly() {
    return this.commonService.hasReadOnlyRole();
  }

  setHeaderPicklistTables() {
    this.sourceHeaderPicklist = 'Available  Tables';
    this.targetHeaderPicklist = 'Selected  Tables';
    this.sourcePlaceholder = 'Search by table name';
  }

  includeTablesToSourceList() {
    if (this.lobValue == 'MED') {
      let includeList = [
        'REF_TBL_SLD_PRCSS_FCTR',
        'REF_ASMPTN_CNDTN',
        'MED_FCTR_GRP_PRIORITY',
        'MED_SSL_BASE_RATES',
        'REF_TIER_RATIO_TYPE',
        'REF_GUARD_RAIL_FCTR',
        'REF_CMPLNC_CHK',
        'REF_TBL_MBU_MAP',
        'REF_TBL_PE_SHEET_SLCT',
        'REF_TBL_ATTR_SET_VAL',
        'REF_TBL_SPCLTY_ADJ_FCTR'
      ];
      this.addList(includeList);
    } else if (this.lobValue == 'VIS') {
      let includeList = [
        'VIS_RATE',
        'REF_GUARD_RAIL_FCTR',
        'REF_TBL_ATTR_SET_VAL',
        'VIS_TBL_STATE_FCTRS',
        'VIS_FCTR_GRP_PRIORITY',
        'VIS_FCTR_TBL_FLD_LOOKUP',
        'SPCLTY_ZIP_CLASS',
		'SPCLTY_SIC_CLASS',
        'SPCLTY_ZIP_MAPPINGS',
        'SPCLTY_RATE_FEE_TAB',
        'SPCLTY_VIS_ASSOC_CONTCODE',
        'SPCLTY_VIS_BUNDLING_FACT',
        'SPCLTY_RENEWAL_CLASS',
        'SPCLTY_RENEWAL_TREND',
        'SPCLTY_SIC_MAPPINGS',
        'SPCLTY_SPLIT_PREM',
        'REF_TBL_PE_SHEET_SLCT'
      ];
      this.addList(includeList);
    } else if (this.lobValue == 'DEN') {
      let includeList = [
        'VIEW_DEN_SIC_DESCR',
        'DEN_TBL_STATE_FCTRS',
        'SPCLTY_ZIP_CLASS',
		'SPCLTY_SIC_CLASS',
        'SPCLTY_ZIP_MAPPINGS',
        'SPCLTY_RATE_FEE_TAB',
        'SPCLTY_ASSOCIATION_FCTR',
        'SPCLTY_BUNDLE_CLASS',
        'SPCLTY_BUNDLE_FCTR',
        'SPCLTY_RENEWAL_CLASS',
        'SPCLTY_RENEWAL_TREND',
        'SPCLTY_BNFT_WAIT_PRD',
        'SPCLTY_NTWRK_USE_FCTR',
        'SPCLTY_PRTCPTN_FCTR',
        'SPCLTY_REIMB_ADJ_FCTR',
        'SPCLTY_UTLZTN_ADJ_FCTR',
        'SPCLTY_PRIME_BASE_RATE',
        'AREA_FCTR',
        'GRP_SIZE_FCTR',
        'ADMIN_RETNTN_FCTR',
        'VRGN_GRP_FCTR',
        'TIER_FCTR',
        'MNUAL_TRND',
        'SIC_FCTR',
        'DSCNT_FCTR',
        'PLAN_STRNG_FCTR',
        'AREA_RGN',
        'SPCLTY_ACA_FEE'
      ];
      this.addList(includeList);
    } else if (this.lobValue == 'SHP') {
      let includeList = ['REF_TBL_SPCLTY_ADJ_FCTR', 'REF_TBL_ATTR_SET_VAL', 'REF_TBL_PE_SHEET_SLCT'];
      this.addList(includeList);
    }
  }

  excludeTablesFromSourceList() {
    if (this.lobValue == 'MED') {
      let excludeList = [
        'MED_TBL_SLD_PRCSS_FCTR',
        'MED_CMPLNC_CHK',
        'MED_FCTR_TBL_PRIORITY',
        'MED_GUARD_RAIL_FCTR',
        'MED_MBU_MAP',
        'MED_TIER_RATIO_TYPE',
        'MED_TBL_PE_SHEET_SLCT',
        'MED_ASMPTN_CNDTN',
        'MED_TBL_ATTR_SET_VAL',
        'MED_SPCLTY_ADJ_FCTR'
      ];
      this.removeList(excludeList);
    } else if (this.lobValue == 'VIS') {
      let excludeList = [
        'VIS_RATE_CA',
        'VIS_RATE_CO',
        'VIS_RATE_CT',
        'VIS_RATE_GA',
        'VIS_RATE_IN',
        'VIS_RATE_KY',
        'VIS_RATE_ME',
        'VIS_RATE_MO',
        'VIS_RATE_NH',
        'VIS_RATE_NV',
        'VIS_RATE_NY',
        'VIS_RATE_OH',
        'VIS_RATE_VA',
        'VIS_RATE_WI',
        'VIS_GUARD_RAIL_FCTR',
        'VIS_TBL_PE_SHEET_SLCT'
      ];
      this.removeList(excludeList);
    } else if (this.lobValue == 'SYS') {
      let excludeList = ['REF_TBL_RTGW_ROUTING', 'PMT_BNFT', 'REF_TBL_UW_ST_CD', 'REF_TBL_UI_IE_LST', 'REF_TBL_ATTR_SET_VAL'];
      this.removeList(excludeList);
    } else if (this.lobValue == 'SHP') {
      let excludeList = ['SHP_SPCLTY_ADJ_FCTR', 'SHP_TBL_ATTR_SET_VAL', 'SHP_TBL_PE_SHEET_SLCT'];
      this.removeList(excludeList);
    }
  }

  addList(includeList) {
    includeList.forEach((table) => {
      this.sourceList.push({ displayName: table, tableName: table });
    });
  }

  removeList(excludeList) {
    excludeList.forEach((table) => {
      this.sourceList.forEach((element, i) => {
        if (element.displayName === table) {
          this.sourceList.splice(i, 1);
        }
      });
    });
  }
}
