import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { CacheRefreshComponent } from './cache-refresh.component';

describe('CacheRefreshComponent', () => {
  let component: CacheRefreshComponent;
  let fixture: ComponentFixture<CacheRefreshComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CacheRefreshComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CacheRefreshComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
