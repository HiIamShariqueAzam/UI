import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CacheRefreshComponent } from './cache-refresh.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { MultiSelectModule } from'primeng/multiselect';
import { CheckboxModule } from'primeng/checkbox';
import { ToastModule } from 'primeng/toast';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
    declarations: [
        CacheRefreshComponent
    ],
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule, ButtonModule, ProgressSpinnerModule, ToastModule,
        TableModule,
        CheckboxModule, FormsModule, MultiSelectModule,
        PickListModule, SelectModule, FlexLayoutModule, SharedModule, RouterModule.forChild([
            { path: '', component: CacheRefreshComponent }
        ])
    ],
    exports: [
        CacheRefreshComponent
    ],
    providers: []
})

export class CacheRefreshModule { }
