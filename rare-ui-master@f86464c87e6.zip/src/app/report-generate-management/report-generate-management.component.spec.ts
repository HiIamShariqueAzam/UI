import { ComponentFixture, TestBed, waitForAsync as  } from '@angular/core/testing';

import { ReportGenerateManagementComponent } from './report-generate-management.component';

describe('ReportGenerateManagementComponent', () => {
  let component: ReportGenerateManagementComponent;
  let fixture: ComponentFixture<ReportGenerateManagementComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportGenerateManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportGenerateManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
