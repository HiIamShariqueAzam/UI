export class ReportConstants {
    public static DOWNLOAD_REPORT_DATA_STATUS_STARTED = "DOWNLOAD_REPORT_DATA_STATUS_STARTED";
    public static DOWNLOAD_REPORT_DATA_STATUS_COMPLETE = "DOWNLOAD_REPORT_DATA_STATUS_COMPLETE";
    public static ERROR = "error";
    public static FAILED = "FAILED";
    public static FAILED_MESSAGE = "Failed to fetch progress because of communication failure";
    public static PROGRESS_BAR_DANGER = "progress-bar-danger";
    public static PROGRESS_BAR_SUCCESSS = "progress-bar-success";
    public static PROGRESS_BAR_WARNING = "progress-bar-warning";
    public static XSLX = '.xlsx';
    public static FROM_DATE = "fromDate";
    public static TO_DATE = "toDate";
    public static DATE_FORMAT = "yyyy-MM-dd";
    public static DATE_ERROR = "From Date should not be greater than To Date";
    public static SELECTED_OPP_ID = ["New Business Local"];
    public static AVAILABLE_STATUS = [
        { "label": "Pending Review", "value": "Pending Review" },
        { "label": "Released", "value": "Released" },
        { "label": "Declined", "value": "Declined" },
        { "label": "Modified", "value": "Modified" },
        { "label": "Pre-Sold", "value": "Pre-Sold" },
        { "label": "Sold", "value": "Sold" },
        { "label": "Failed", "value": "Failed" },
        { "label": "Partial Success", "value": "Partial Success" },
        { "label": "Sold Modified", "value": "Sold Modified" },
        { "label": "Lost", "value": "Lost" },
        { "label": "Missing Information", "value": "Missing Information" },
        { "label": "In Analysis", "value": "In Analysis" },
        { "label": "Awaiting P2A data", "value": "Awaiting P2A data" },
        { "label": "Termed", "value": "Termed" },
        { "label": "Transfer", "value": "Transfer" },
        { "label": "Pending Exhibit", "value": "Pending Exhibit" },
        { "label": "Close", "value": "Close" }
      ];
    public static L0B_OPTIONS = [
        { label: 'Medical', value: 'Medical', disabled: false },
        { label: 'Vision', value: 'Vision', disabled: false },
        { label: 'Dental', value: 'Dental', disabled: false },
        { label: 'Supp Health', value: 'Supp Health', disabled: false },
    ];
    public static DATE_TYPES = [
        { label: 'Eff Date', value: 'contractEffectiveDate' },
        { label: 'Quoted Date', value: 'insertedTimestamp' }
    ]
    public static T3ST_FILTER_VALUES = [
        { label: 'Yes', value: 'yes' },
        { label: 'No', value: 'no' }
    ];
    public static REPORT_DATA_TYPE = [
        { label: 'Quote Level', value: 'quoteLevel' },
        { label: 'Plan Level', value: 'planLevel' }
    ];
    public static AVAILABLE_FUNDINGTYPE = [
        { "label": "FI", "value": "FI" },
        { "label": "ABF", "value": "ABF" }
    ];
    public static AVAILABLE_OPP_TYPE = [
        { "label": "Renewal Local", "value": "Renewal Local" },
        { "label": "New Business Local", "value": "New Business Local" }
    ];
    public static AVAILABLE_MBS = [
        { "label": "LG", "value": "LG" },
        { "label": "SG", "value": "SG" }
    ];
    public static SELECTED_LOB = { label: 'Medical', value: 'Medical' };
}