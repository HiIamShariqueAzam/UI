import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DateFormatPipe } from 'src/app/shared/pipes/date-format-pipe';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { CommonService } from 'src/app/shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  constructor(private dateFormatPipe: DateFormatPipe,
    private http: HttpClient,
    private commonService: CommonService, private authenticationService: AuthenticationService) { }

  getGeneratedReport(lob?, fromDate?: Date, toDate?: Date, state?,
    opportunityID?, quoteHeaderID?, fundingType?, opportunityType?, fileName?, states?, t3stFilter?, reportDataType?, status?, dateField?, marketSegment?, restructure = false, action = null): Observable<any> {
    let dateArray = <any>[];
    let flagFromdate: boolean = false;
    let flagTodate: boolean = false;
    let reportName;
    if (fromDate && toDate) {
      dateArray.push(this.formatDate(fromDate));
      if (reportName !== 'CURIA')
        dateArray.push(this.formatDate(toDate));
      else
        dateArray.push(this.formatToDateByMonth(toDate));
    } else if (fromDate && !toDate) {
      dateArray.push(this.formatDate(fromDate));
      flagFromdate = true;
    } else if (!fromDate && toDate) {
      if (reportName !== 'CURIA')
        dateArray.push(this.formatDate(toDate));
      else
        dateArray.push(this.formatToDateByMonth(toDate));
      flagTodate = true;
    }
    let request = {
      "query": null,
      "lob": null,
      "state": null,
      "includeT3ST": null,
      "reportDataType": null
    };
    let url: string;
    if (opportunityID) {
      const printUrl = restructure ? "/ui/print/restructured/soldRates?opportunityID=" : "/ui/print/soldRates?opportunityID=";
      url = `${this.commonService.getRareUiUrl()}${printUrl}${opportunityID}&quoteHeaderID=${quoteHeaderID}&action=${action}`;
      localStorage.setItem("sheetName", fileName ? fileName : "Sold-Rate-Sheet_" + opportunityID + "_" + quoteHeaderID);
    } else {
      localStorage.setItem("sheetName", lob + "_" + this.dateFormatPipe.transform(
        new Date(),
        "yyyyMMdd-hhmmss"
      ));
      const dateFrom = dateArray.length == 2 || flagFromdate ? encodeURIComponent(dateArray[0] + " 00:00:00") : null;
      const dateTo = dateArray.length == 2 ? encodeURIComponent(dateArray[1] + " 23:59:59") : flagTodate ? encodeURIComponent(dateArray[0] + " 23:59:59") : null;
      url = this.commonService.getRareUiUrl() + "/ui/getmanagementreport?fromDate=" + dateFrom + "&toDate=" + dateTo + "&lob=" + lob + "&state=" + state + "&status=" + status + "&dateField=" + dateField + "&includeT3ST=" + t3stFilter + "&reportDataType=" + reportDataType + "&fundingType=" + fundingType + "&opportunityType=" + opportunityType + "&marketSegment=" + marketSegment;
    }

    let headers = new HttpHeaders()
      .set('Access-Control-Allow-Origin', '*')
      .set("Content-Type", "application/json")
      .set("Access-Control-Expose-Headers", "TestHeaderToExpose")
      .set("meta-transid", "abc")
      .set("userid", this.authenticationService.getUserID())
      .set("username", this.authenticationService.getUserName());
    if (reportName !== 'CURIA') {
      return this.http.get<any>(url, { headers: headers, observe: 'response' });
    }
    else {
      let rareUiRequest = this.commonService.getRareUiRequest(request)
      return this.http.post<any>(url, rareUiRequest, { headers: headers, observe: 'response' });
    }
  }

  formatDate(date: Date) {
    return date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
  }

  formatToDateByMonth(date: Date) {
    const getDate = new Date(date.getFullYear(), (date.getMonth() + 1), 0).getDate();
    return date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + getDate;
  }
}
