import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReportForm } from 'src/app/shared/models/reports';
import { CommonService, AuthenticationService, PrintExhibitService } from 'src/app/shared/services';
import { ReportConstants } from './report-constants';
import { ReportsService } from './services/reports.service';
@Component({
  selector: 'app-report-generate-management',
  templateUrl: './report-generate-management.component.html',
  styleUrls: ['./report-generate-management.component.css'],
  standalone: false
})

export class ReportGenerateManagementComponent implements OnInit {

  constructor(private fb: FormBuilder, private commonService: CommonService,
        private authenticationService: AuthenticationService,private peService: PrintExhibitService,private reportsService: ReportsService) { }
  div_visible: boolean = false;
  lobOptions:any[];
  selectedLob: any;
  availableStatus: any[];
  showEmptyFromDate: boolean = false;
  showEmptyToDate: boolean = false;
  value: Date;
  report_form: FormGroup<ReportForm>;
  testDate: boolean = false;
  selectedState: any = [];
  selectedStatus: any[];
  selectedDate: any;
  showT3STFilter :boolean=false;
  availableStates: any = [];
  availableStatesLength: any;
  dateTypes: any[];
  reportDataType: any[];
  t3stFilterValues: any[];
  showProgress: boolean = false;
  progressPercent: number = 0;
  progressMessage: any;
  progressStyle: string;
  processId: any;
  multiselectEle: any;
  availableFT: any[];
  selectedFT: any;
  selectedOT: any;
  availableOT :any[];
  isDivVisible: boolean = false;
  user_roles: any;
  availableMbs: any[];
  selectedMbs: any;
  ngAfterViewInit() {
    this.multiselectEle = (document.querySelector('.ui-multiselect'));
    if(this.multiselectEle!=null){
    this.multiselectEle.setAttribute('tabindex', -1);
    }
  }
  displayOptionsPannel() {
		if (this.multiselectEle) {
			this.multiselectEle.focus();
    }
	}
  ngOnInit() {
    this.loadUserGroups();
    this.lobOptions = ReportConstants.L0B_OPTIONS;
    this.dateTypes = ReportConstants.DATE_TYPES;
    this.t3stFilterValues = ReportConstants.T3ST_FILTER_VALUES;
    this.reportDataType =ReportConstants.REPORT_DATA_TYPE;
    this.availableFT = ReportConstants.AVAILABLE_FUNDINGTYPE;
    this.availableOT = ReportConstants.AVAILABLE_OPP_TYPE;
    this.selectedOT= ReportConstants.SELECTED_OPP_ID;
    this.availableStatus = ReportConstants.AVAILABLE_STATUS;
    this.availableMbs = ReportConstants.AVAILABLE_MBS;
    this.selectedLob = ReportConstants.SELECTED_LOB;
    this.report_form = this.fb.group({
      lob: ['Medical'],
      state: [''],
      dateField: [this.dateTypes[1].value],
      fromdate: [''],
      todate: [''],
      t3stFilter: [this.t3stFilterValues[1].value],
      reportDataType: [this.reportDataType[1].value],
      status: [''],
      fundingType: [''],
      opportunityType:[''],
      marketSegment: ['']
    },
      {
        validator: this.validateDate('fromdate', 'todate'),
      }
    );

    if(this.authenticationService.isUserRoleAdmin(this.authenticationService.getUserRole())){
    	this.showT3STFilter=true;
    }
    this.user_roles = this.authenticationService.getUserRole();
    if (this.user_roles.includes('MANAGEMENT') && !this.user_roles.includes('ADMIN')) {
      this.isDivVisible = true;
    }
  }
  private getStateList(userGroups):void {
    this.availableStates = [];
    userGroups.forEach(item => {
      if (item.lob === 'MED' && item.state !== 'ALL') { // hiding the ALL option, as we changed state dropdown to multiselect dropdown
        this.availableStates.push({ "label": item.state, "value": item.state });
      }
    });
  }
  private loadUserGroups() {
    this.authenticationService.getUserRoleGroups().then(data => {
      this.getStateList(data);
      });
  }
  validateDate(dateFrom: string, dateTo: string) {

    this.testDate = true;
    return (formGroup: FormGroup<ReportForm>) => {

      const datefrom = formGroup.controls[dateFrom];
      const dateto = formGroup.controls[dateTo];
      const currentState = formGroup.controls['state'].value;
      const dateFromValue = new Date(datefrom.value);
      const dateToValue = new Date(dateto.value);

      let months = (dateToValue.getFullYear() - dateFromValue.getFullYear()) * 12;
      months -= dateFromValue.getMonth();
      months += dateToValue.getMonth();
      let daydiff = (dateToValue.getDate() - dateFromValue.getDate());
      if ((new Date(datefrom.value)) > (new Date(dateto.value))) {
        datefrom.setErrors({ invalidFromDate: true });
        dateto.setErrors(null);
      }

      else if ((currentState.length <= 0 || currentState.length == this.availableStates.length) && (months > 3|| months == 3 && daydiff >= 0)
      || currentState.length > 0 && (months > 6 || months == 6 && daydiff >= 0)) {
      dateto.setErrors({ invalidDateRange: true });
      datefrom.setErrors(null);
    }
      else {
        if (datefrom.hasError('required')) {
          datefrom.setErrors(null);
          datefrom.setErrors({ required: true });
        }
        else {
          datefrom.setErrors(null);
          dateto.setErrors(null);
        }
      }
    }
  }
  onSubmit(form: FormGroup<ReportForm>) {
    /*If Fromdate has no value*/
    if (form.get("fromdate").value === "" || form.get("fromdate").value === null) {
      this.showEmptyFromDate = true;
      return;
    }
    if ((form.get("todate").value === "" || form.get("todate").value === null)) {
      this.showEmptyToDate = true;
      return;
    }
    else {
      this.showEmptyFromDate = false;
      this.showEmptyToDate = false;
    }
    if (form.invalid) {
      return;
    }
    this.getGeneratedReport(form);
  }

  getGeneratedReport(form){
    this.reportsService.getGeneratedReport(form.get("lob").value, form.get("fromdate").value, form.get("todate").value
      , this.selectedState, null, null, form.get("fundingType").value,form.get("opportunityType").value,null,null,form.get("t3stFilter").value, form.get('reportDataType').value,
      this.selectedStatus, form.get("dateField").value, form.get("marketSegment").value).subscribe(response => {
        this.div_visible = false;
        if (response.status === 200) {
          this.processId = response.body.processId;
            this.showProgress = true;
            this.progressPercent = 1;
            this.progressStyle = "progress-bar-warning";
            var source = this.commonService.listenForStream(this.processId);
            source.addEventListener("REPORT_GENERATION_STATUS", (event: any) => {
              this.progressStyle = "";
              let eventData = JSON.parse(event.data);
              var percent = Math.floor((eventData.currentEvent / eventData.totalEvents) * 100);
              this.progressPercent = percent;
              this.progressMessage = eventData.message;
            });
            source.addEventListener('REPORT_GENERATION_STATUS_COMPLETE', (message: any) => {
              source.close();
              let eventData = JSON.parse(message.data);
              this.progressStyle = "progress-bar-success";
              this.progressPercent = 100;
              this.progressMessage = eventData.message;
              let fileExt = '.xlsx';
              CommonService.exportFilename = (localStorage.getItem("sheetName") ? localStorage.getItem("sheetName") : "sheet") + fileExt;
              let fileName = this.commonService.getExportFilename();
              let contentData = eventData.payload.contentData;
              const arrayBuffer = this.peService.base64ToArrayBuffer(contentData);
              this.peService.createAndDownloadBlobFile(arrayBuffer, fileName);
              setTimeout( ()=>{
                this.showProgress = false;
                }, this.commonService.getProgressBarTimeOut());
              });
            source.addEventListener('FAILED', (message: any) => {
              source.close();
              console.error("Received event : ", JSON.stringify(message.data));
              this.progressPercent=90;
              this.progressStyle = "progress-bar-danger";
              this.progressMessage = "Error in getting response for Export";
            });
            source.addEventListener('error', (message: any) => {
              console.error("Received error event, with ready status :"+source.readyState);
              if (source.readyState == EventSource.CLOSED) {
                this.progressPercent=90;
                this.progressStyle = "progress-bar-danger";
                this.progressMessage = "Failed to fetch progress because of communication failure";
              }
            });
        }
      }, error => {
        this.div_visible = false;
        alert("Error in getting response for Export: " + error);
      });
  }

  downloadFile(blob: any, type: string, filename: string) {

    var binaryData = [];
    binaryData.push(blob);

    /*Workaround for IE11 download issue*/
    // IE doesn't allow using a blob object directly as link href
    // instead it is necessary to use msSaveOrOpenBlob
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(new Blob(binaryData, { type: "" }), filename);
    }
    else {
      // create hidden dom element (so it works in all browsers)
      const url = window.URL.createObjectURL(new Blob(binaryData, { type: "" })); // <-- work with blob directly
      const a = document.createElement('a');
      a.setAttribute('style', 'display:none;');
      document.body.appendChild(a);

      // create file, attach to hidden element and open hidden element
      a.href = url;
      a.download = filename;
      a.click();
    }
  }

  clickedFromDate() {
    this.showEmptyFromDate = this.showEmptyToDate = false;
    let element: HTMLElement = document.querySelectorAll('.fromdate .p-inputtext')[0] as HTMLElement;
    if(typeof(element) != 'undefined'){
      element.click();
  }
    (<HTMLImageElement>document.querySelector(".fromDateCalendar")).src = "./assets/calendar-blue.svg";
  }

  clickedToDate() {
    this.showEmptyFromDate = this.showEmptyToDate = false;
    let element: HTMLElement = document.querySelectorAll('.todate .p-inputtext')[0] as HTMLElement;
    if(typeof(element) != 'undefined'){
      element.click();
  }
    (<HTMLImageElement>document.querySelector(".toDateCalendar")).src = "./assets/calendar-blue.svg";
  }

}
