import { NgModule } from '@angular/core';
import { ReportGenerateManagementComponent } from "./report-generate-management.component";
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { MessageService } from 'primeng/api';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MultiSelectModule } from 'primeng/multiselect';
import { DatePickerModule } from 'primeng/datepicker';



@NgModule({
    declarations: [ReportGenerateManagementComponent],
    imports: [
        CommonModule, RouterModule.forChild([
            { path: '', component: ReportGenerateManagementComponent }
        ]), ProgressSpinnerModule, ReactiveFormsModule, FormsModule, ButtonModule, FlexLayoutModule, MultiSelectModule, DatePickerModule
    ],
    providers: [
        MessageService
    ],
    exports: [
        ReportGenerateManagementComponent
    ]
})
export class ReportGenerateManagementModule { }
