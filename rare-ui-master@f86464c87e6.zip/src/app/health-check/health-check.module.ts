import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HealthCheckComponent } from "./health-check.component";
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { SharedModule } from 'src/app/shared/shared.module';
@NgModule({
    declarations: [
        HealthCheckComponent
    ],
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule, SharedModule, RouterModule.forChild([
            { path: '', component: HealthCheckComponent, pathMatch: 'full' }
        ]), ButtonModule, TableModule, DialogModule
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    exports: [
        HealthCheckComponent
    ],
    providers: [
        RouterModule
    ]
})
export class HealthCheckModule {
}
