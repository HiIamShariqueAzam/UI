import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { CommonService } from 'src/app/shared/services';

@Component({
    selector: 'app-health-check',
    templateUrl: './health-check.component.html',
    styleUrls: ['./health-check.component.scss'],
    standalone: false,
})
export class HealthCheckComponent implements OnInit {
    showNoRecordsFound: boolean = false;
    isPopupVisible: boolean = false;
   	showtableContent: boolean = true;
   	showFilenetStatus: boolean;
   	showFilenetStreamingStatus: boolean;
    httpResponse: any;
    filenetresponse:any;
    filenetStreamingresponse:any;
    filestatus:number;
    fileStreamingStatus:number;
    tableHeaders = [
        {
            'index': 0,
            'headerName': 'Service Name'
        },
        {
            'index': 1,
            'headerName': 'Service Status'
        },
        {
            'index': 2,
            'headerName': 'HTTP Status'
        },
        {
            'index': 3,
            'headerName': 'HTTP Response'
        }
    ];

    tableContent: any = [];

    constructor(
        private router: Router,
        private commonService: CommonService,
        private messageService: MessageService) {
    }
    servicesList: any = [];
    ngOnInit() {
      this.filestatus=3;
      this.fileStreamingStatus=3;
      this.getHealthCheckInfo();
      this.openFileNetModalPopup();
    }
    navigate(pageName: string) {
        this.router.navigate(['/' + pageName]);
        this.messageService.clear();
    }
    flag = true;
    displayingtable(flag: boolean) {
        this.flag = flag;
    }
    openModalPopup(app: any) {
		let response:any;
		if (app.serviceStatus === 'UP') {
			response = app.httpResponse;
			this.httpResponse = JSON.parse(response);
		} else {
			this.httpResponse = app.httpResponse;
		}
        this.isPopupVisible = true;
    }
    getHealthCheckInfo() {
        this.showtableContent = true;
        this.commonService.getHealthCheckInfo().subscribe(res => {
            this.tableContent = [];
			this.tableContent.push(res);
            this.servicesList = res['servicesList'];
            if (this.servicesList.length === 0) {
                this.showNoRecordsFound = true;
            }
            this.showtableContent = false;
        })
        this.showFilenetStatus = false;
        this.showFilenetStreamingStatus = false;

        this.getFilenetInfo();
        this.getFilenetStreamingInfo();
    }

    openFileNetModalPopup() {
      if(this.filenetresponse!=undefined){
      this.httpResponse  = this.filenetresponse;
          this.isPopupVisible = true;
       }
    }

    filenetstatus(){
      this.getFilenetInfo();
      this.filestatus=4;
    }

    getFilenetInfo() {
     this.commonService.getFileNetInHealthCheckInfo().subscribe(res=>{
      this.filenetresponse=res as any;
      this.showFilenetStatus = true;
     },error => {
      this.filenetresponse = error.error as any;
     })
    }

  openFileNetStreamingModalPopup() {
    if(this.filenetStreamingresponse!=undefined){
      this.httpResponse  = this.filenetStreamingresponse;
      this.isPopupVisible = true;
    }
  }

  filenetStreamingStatus(){
    this.getFilenetStreamingInfo();
    this.fileStreamingStatus=4;
  }

  getFilenetStreamingInfo() {
    this.commonService.getFileNetStreamingHealthCheckInfo().subscribe(res=>{
      this.filenetStreamingresponse=res as any;
      this.showFilenetStreamingStatus = true;
    },error => {
      this.filenetStreamingresponse = error.error as any;
    })
  }
}
