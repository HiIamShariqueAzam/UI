import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-admin',
    templateUrl: './admin.component.html',
    standalone: false
})
export class AdminComponent implements OnInit {

    constructor(
        private router: Router, 
        private messageService: MessageService) {
    }

    ngOnInit() {

    }

    navigate(pageName: string) {
        this.router.navigate(['/' + pageName]);
        this.messageService.clear();
    }
}
