import { NgModule } from '@angular/core';
import { AdminComponent } from "./admin.component";
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {ButtonModule} from 'primeng/button';
import { SharedModule } from '../shared/shared.module';
@NgModule({
    declarations: [
        AdminComponent
    ],
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule, SharedModule, RouterModule.forChild([
            { path: '', component: AdminComponent, pathMatch: 'full' }
        ]), ButtonModule
    ],
    exports: [
        AdminComponent
    ],
    providers: [
        RouterModule
    ]
})
export class AdminModule {
}
